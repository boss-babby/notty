# Static Harbor: Open Atlas

Static Harbor is an offline, top-down action game featuring four connected cities, a seeded frontier, two story campaigns, and a supernatural survival mode. Play as Mara Venn, a courier whose working day can take her from a painted rickshaw lane to a skyline ferry or a desert resort.

## Play

Open **[`index.html`](index.html)** in a current browser. It opens the included **[`play/index.html`](play/index.html)**, which also works on its own: you can move or share that single file. No server, build, internet connection, images, fonts, or sound downloads are needed. Click a menu control or start a run to unlock audio. The selector at the bottom of the title screen switches modes:

- **Open Atlas** (default): Start in Mirage Coast or Neon Basin, choose Continental, Island Chains, or Badlands, and optionally name the world. The same key and style reproduce the same layout. The default atlas shares the original campaigns' city coordinates.
- **Monsoon Lines**: Meet Samira Noor at the tea awning. Follow amber diamonds through eight operations and two endings.
- **Vesper Bay**: Play the original ten operations and three endings. Find the pink Vanta and follow the first pink diamond. Existing version 1 saves remain in this slot.
- **Outbreak**: Open the shelter cache, restore three beacons in any order, and signal the ghat ferry. Exit after completing evacuation or choose **Keep surviving**. Noise from sprinting, horns, and weapons draws enemies. Supply drops, escalating shamblers/runners/brutes, a personal best, a death report, and checkpoint retries are part of the mode.
- **Training Bay**: Run Plate Line, Break & Cover, or Sparring Ring with the same mechanics as the city. Your campaign and Outbreak saves are never written from the bay. Only drill scores are stored. In a campaign, the Anchor Training Bay in Shapla Center offers a save-and-enter shortcut.

The game autosaves periodically and at checkpoints. Use **F6** or **Pause > Save checkpoint** for a manual save. **Load Game** opens the selected mode's independent slot. Storage is browser- and file-dependent; keep the same offline file location to preserve your slot. If storage is blocked, the in-memory slot lasts until reload or close. The offline file and Vite development URL have separate storage.

## Controls

| Action | Keyboard / mouse | Standard gamepad |
| --- | --- | --- |
| Move / steer | W A S D or arrows | Left stick |
| Aim / fire | Mouse / left click | Right stick / RT |
| Brace / directional guard | Hold X or right mouse | LT |
| Slow walk | Hold Z | Partial left-stick tilt |
| Interact / enter or exit | E | A |
| Sprint | Shift | LB |
| Dodge / vault / handbrake | Space / hold Space in a car | B / hold B in a car |
| Sneak / cover | Ctrl near a wall | RB |
| Reload / weapon wheel | R / Q | X / Y |
| Map / phone | M / Tab | View / D-pad up |
| Radio / horn or siren | C / H | D-pad down / keyboard only |
| Toggle headlights | L | Keyboard |
| Heal / pause | F / Esc | D-pad right / Start |
| Debug overlay / quick save | F3 / F6 | Pause menu |
| Cycle street camera | V | Right stick click |
| Outbreak noisemaker / barricade | G / B | D-pad left / HUD button |

Use **World** for the four hubs, a city tab for district detail, or **Frontier** for a local chart that follows you and can pan. Click the chart or pick a landmark to pin it. Number keys select owned equipment, and the wheel includes all eleven slots. Touch devices show directional and action buttons automatically. The Bastion uses normal aim/fire input for its fictional pulse. The Kheya water taxi uses the driving controls, but stays in navigable water; line up next to land before disembarking.

## Open Atlas Expansion

- **Mirage Coast** is Dubai-inspired but entirely fictional: terraced and glass towers, courtyards in Saffron Souk, landscaped jasmine neighborhoods, a crescent marina, Windglass International, and a waterfront listening lounge. Its airport, ferry and viewing gallery are enterable.
- **Neon Basin** is Las Vegas-inspired: a neon resort strip, separated frontage streets, motels, dry service washes, the Halation club, Jacklight's free score game, Basin Regional Airport, and the fictional Fort Ember field office. Its public relief contract is available from the field desk.
- **30 district and biome identities** include the original districts plus dunes, canyons, salt flats, oases, outer islands, open gulf and juniper ranges. World coordinates are signed; walking, driving, flight, and the minimap work beyond the old rectangle. Terrain and shared road edges stream deterministically. Landmarks stay recognizable across keys, while layouts and remote terrain vary.
- **Air and sea links.** Walk inside and use the terminal counter. Flights link Vesper Sky Gate, Windglass International, and Basin Regional. Public ferries link Pier 07, Shapla Ghat, and Crescent Sea Terminal. These are ticketed travel transitions, not flyable passenger jets or full ferry timetables. Small boats and the helicopter still use their existing player controls.
- **Local activities.** Six regional contracts cover cargo, relay territory, resort racing and civilian relief. Other frontier discoveries include seeded beacons and field stations. Factions have standings and contested districts. Nightlife has working DJs and other adult characters, including independent escorts with non-explicit dialogue; there is no sexual transaction mechanic.
- **Save isolation.** Open Atlas stores seed, style, position, charted cells, and survey records in its own slot. Original checkpoints load on the enlarged map. Take a road or a terminal ticket rather than creating a separate game just to visit the new cities.
- **Detail pass.** Authored-city chunks now add infill blocks, cafés, scooters, planters, banners, streetlights, local signs, crosswalks, animated fountain water, marquee pulses and shoreline reflections. The World chart labels all four cities; Frontier charts follow and pan with the player. Roads no longer run flat over water except signed trunk causeways, which are drawn with rails and pilings.
- **Flight read.** While the helicopter is airborne, its body and rotor are drawn above street traffic, its ground shadow stays below, and the camera pulls back with altitude. An altimeter and airspeed band appear at the bottom of the screen.

## The City

- **Original core preserved:** The 264 original seeded chunks keep the same geometry and coordinates. Three causeways connect the old harbor to Monsoon City; highways now continue beyond that core to the new cities and frontier.
- **Eighteen story operations in two campaigns:** The original courier campaign stays intact. Monsoon adds a rickshaw delivery, flood-reader survey, water-taxi crossing, lakeside circuit, tracked clearing job, and relief run. Free roam continues after either campaign.
- **Street life:** Bengali and English signs, rooftop tanks, corrugated roofs, cloth awnings, roadside cha and fruit, electrical lines, drains, sports courts, launch steps, fields, mills, and a moving metro. Enter a metro station and use its counter for an $8 ride. The fictional map's reference study is in [MONSOON.md](MONSOON.md); it is not a 1:1 Dhaka map.
- **Free roam:** Take a night cab or courier contract, stop a marked runner, race, take the pier ramp, find lost tapes, complete the import list, try the arena and arcade, or buy Morrow Loft for hourly income. Visit the market, garage, bank, precinct, clinic, and safehouse.
- **Movement and combat:** Sprint on stamina, roll over low props, swim, take cover, and use eleven arcade weapons with individual spread, mag sizes, reload times, and sound. Damage, healing, armor, hospital respawn, experience by use, and destructible street props affect a run.
- **Driving:** Twenty-one models, including the original compact, sedan, sports and muscle cars, van, pickup, motorcycle and bus, plus rickshaws, a water taxi, tracked rides, a bicycle, helicopter, and Hearth fire engine. Use W to lift off and Space to descend in the helicopter. At a garage, choose **Customize** for paint and a local plate, or **Service** for upgrades and repairs.
- **City conditions:** Rain, fog, storms, day and night, a five-level pursuit and search system, field units, roadblocks, and a search helicopter. Traffic, witness reactions, and faction ownership shift around the player.
- **Presentation:** Animated pixel-art launcher, camera cues and dialogue, gamepad and touch input, adjustable mix and quality, key rebinding, high-contrast signals, reduced motion, CRT, photo capture, and career stats.

## The Living City Update

- **Dispatch:** A lead unit, intercept units, and search units get different goals. Car spacing is enforced in the movement code, not only by a steering preference. Units route through junctions, reverse out of jams, and search a remembered sighting. Press **F3** to see labels and route traces.
- **The Quiet:** Zombies remember sounds and sightings, see in a forward cone, route around corners, and telegraph attacks. Runners close faster; brutes can break barricades. Supply caches replenish noisemakers and boards. Use **G** to throw a decoy or **B** to place a temporary barricade while on foot.
- **40 listed interiors:** Room-specific geometry, different floor materials and lights, and physical interaction points. Related locations such as metro stations and airports share architectural motifs. The training interior has moving targets and destructible drill geometry.
- **Venue games:** Carrom at Nodi Cha, Neon Darts at Soft Reset, and a dyno challenge at the two workshops. Walk to a marked station and interact. Scores and rewards are saved under **Pause > Activity records**.
- **Service and exploration contracts:** Open **Jobs** on the phone. Ambulance work, towing, and air surveys are in Vesper Bay; the Megh bus shift and Jheel photo walk are in Monsoon. To record a landmark, use **Photo mode > Frame landmark**. Regular photo mode still captures a local PNG and now has zoom.
- **Trade and progression:** Move civilian salvage between the Pier Trading Desk and the Lantern Exchange as prices change. Use skills to unlock longer sprints, steadier aim, cheaper rolls, and better wet-road handling. The career screen shows the unlocks.

## The Contact Update

- **Weight and timing.** Movement has acceleration and settling, with independent upper-body aim and foot placement. Rolls have a short safe window. Vaults check the landing area. Melee actions have windup, contact, and recovery; holding guard helps against attacks from the front. Medkits take a moment to apply and can be interrupted.
- **Eleven fictional handling profiles.** Tap single-action equipment and hold automatic gear. Focus tightens the reticle, moving widens it, and successive shots take longer to settle. Shared ammo reserves follow the ammunition family. The Dock Sweeper loads one shell at a time and can interrupt loading after a shell is in. Older per-weapon reserves migrate to the shared inventory on load.
- **Surface feedback.** Swept collision checks the first hit against prop shapes, cover, or the rotated outline of a vehicle. Wood splinters, concrete chips, glass breaks and persists, and vehicle scuffs build up. Thrown charges bounce before their delayed effect. Solid obstacles reduce nearby blast damage; none of the values are calibrated to real equipment.
- **Sound and presentation.** Equip and reload stages, material sounds, indoor reflections, wet steps, directional damage, and distinct handling animations are generated in the game. Rain dries gradually. **Settings > Combat** includes hold-to-fire assist, automatic reload, visible-target aim assist, and reduced flashes.
- **Story and activities.** **Phone > Messages** keeps briefing dialogue and can replay the current briefing with an in-engine camera pass. Market Watch and Closing Time are parcel recovery jobs. Quay Line and Community Frequency let you decide local district control in play; toggle it on the city map. The shop now carries clothes, and the ghat and promenade have two income-producing properties.

### Sections 3-5 Mechanics

| Area | Implemented behavior |
| --- | --- |
| Player | Slow walk, run, sprint, swim, directional guard, recovery windows, obstacle-checked vaults, and animated vehicle entry and exit. Clothing changes silhouette; color and hair can be changed separately. |
| Equipment | Fists, bat, blade, pistol, SMG, shotgun, rifle, sniper, bouncing charge, breakable flask, and launcher all have their own game handling. Glass, cover, and oriented vehicle surfaces stop or alter the incoming projectile. Character hit flecks are stylized and can be disabled in **Settings > Combat**. |
| Traffic and damage | Intersection queues, cross-traffic yielding, safe lateral moves around danger, horns, and vehicle separation. Dents, glass damage, and tire damage persist on the saved vehicle. Garage repairs remove visible damage. |
| Wanted | Patrols and separate dispatch objectives, collision-aware cruisers, roadblocks, distinct spike strips, heavier SWAT and military crews, a search helicopter, and remembered last-seen positions. The normal alert cooldown and Ghost Relays still apply. |
| People and events | Local schedules and shop vendors, crowd separation, bounded A* routes, hearing and sight, witness calls, filming, and defensive reactions. Live robberies, paired chases and races, ambulance and fire responses, vigils, disputes, and parcel recoveries rotate through the city. |

## Signature Ideas

1. **Ghost Relays.** Inez unlocks a second network. Trigger a relay to cut a district's lights and interrupt tracking long enough to change your route.
2. **The Wire.** Vesper Bay's dispatch feed rewrites its headlines around witnesses, pursuits, blackouts, turf shifts, purchases, and the campaign's outcome. Read it on the Pocket Relay.
3. **Night Frequencies.** Neon FM, Dockside Dub, and Ghost Carrier generate their music live. Alert levels alter tempo and percussion. Each station has its own jingle, plus fictional ads and DJ chatter during quiet drives.

## Debug Bench

Open **Pause > Debug & cheats**. Add cash, restore health, spawn any vehicle, unlock the arsenal, teleport to landmarks, change hour and weather, set heat, jump to an operation, or force a named street event while outside. Outbreak omits campaign and wanted settings. **F3** reports frame rate, active entities, and police route labels. Debug changes can be saved, so use a separate browser profile if you want to preserve a clean run.

## Source & Build

The simulation is native JavaScript ES modules and Canvas 2D. React renders the launcher, HUD, and menus. Vite packages their JavaScript and CSS into a single HTML file for the offline release. For source development only, use `npm ci` and `npm run dev`. Rebuild the bundled release with `npm run build && node scripts/package-offline.mjs`.

| Source | Responsibility |
| --- | --- |
| [`DESIGN.md`](DESIGN.md) | Phase 0 brief, loop, and system diagram |
| [`MONSOON.md`](MONSOON.md) | Dhaka research, map references, and design translations |
| [`CONTACT.md`](CONTACT.md) | The defensive, audiovisual, and practice design for this update |
| [`ATLAS.md`](ATLAS.md) | The new cities, world generation, places, and travel network |
| [`src/App.tsx`](src/App.tsx), [`src/ui/`](src/ui/) | Launcher, loading flow, HUD, and accessible menus |
| [`src/game/core.js`](src/game/core.js) | Fixed 60 Hz loop, input, RNG, pools, spatial hash, storage |
| [`src/game/world.js`](src/game/world.js) | Chunk streaming, A* street graph, terrain, collisions, room layouts |
| [`src/game/geography.js`](src/game/geography.js), [`src/game/monsoon-world.js`](src/game/monsoon-world.js) | Causeways, river and lake geometry, district generation, and procedural street artwork |
| [`src/game/frontier-geo.js`](src/game/frontier-geo.js), [`src/game/frontier-world.js`](src/game/frontier-world.js), [`src/game/atlas-runtime.js`](src/game/atlas-runtime.js) | Terrain fields and road edges, streamed terrain artwork, surveys, travel, and venues |
| [`src/game/game.js`](src/game/game.js), [`src/game/actors.js`](src/game/actors.js) | Simulation, combat, camera, driving, traffic, pedestrians, pursuit |
| [`src/game/contact.js`](src/game/contact.js), [`src/game/contact-data.js`](src/game/contact-data.js), [`src/game/contact-geometry.js`](src/game/contact-geometry.js) | Fictional handling data, committed actions, swept contact and material effects |
| [`src/game/movement.js`](src/game/movement.js), [`src/game/contact-art.js`](src/game/contact-art.js), [`src/game/practice.js`](src/game/practice.js) | Weighted movement, procedural poses, and isolated live drills |
| [`src/game/traffic.js`](src/game/traffic.js), [`src/game/crowds.js`](src/game/crowds.js), [`src/game/street-events.js`](src/game/street-events.js) | Traffic behavior, civilian decisions, response crews, faction disputes, and recoverable encounters |
| [`src/game/campaign.js`](src/game/campaign.js), [`src/game/data.js`](src/game/data.js) | Objectives, contracts, endings, stations, and equipment catalogs |
| [`src/game/outbreak.js`](src/game/outbreak.js) | Survival state, noise, enemy types, supplies, and evacuation |
| [`src/game/dispatch.js`](src/game/dispatch.js), [`src/game/horde.js`](src/game/horde.js), [`src/game/navigation.js`](src/game/navigation.js) | Patrol orders, zombie perception and attack timing, shared clearance routing |
| [`src/game/interiors.js`](src/game/interiors.js), [`src/game/interior-art.js`](src/game/interior-art.js) | Interior floor plans, interactions, and cached pixel art |
| [`src/game/parlor.js`](src/game/parlor.js) | Carrom physics, darts, dyno challenges, and records |
| [`src/game/renderer.js`](src/game/renderer.js), [`src/game/vista.js`](src/game/vista.js), [`src/game/maps.js`](src/game/maps.js) | Layered pixel art, light buffer, effects, minimap, full map |
| [`src/game/audio.js`](src/game/audio.js) | Synthesized score, master/music/SFX mix, and positional effects |

## Tradeoffs & Roadmap

- The shared world has no nearby map-edge wall or final chunk. The procedural frontier is reproducible; an upper numeric guard prevents impractical coordinates. Only nearby chunks are kept active. Authored cities are finite, and distant terrain recombines biome rules rather than generating an endless series of bespoke metros. Travel charting and A* work on bounded views and searches. Bridge height and rooftops remain graphical layers.
- Traffic, driving, swimming, and patrol/search are arcade systems. Police, the horde, and nearby civilians combine a street graph or local clearance grid with steering. Parked cars and local traffic still simplify collision shapes. Faction control changes through events and contracts; it is not a region-wide strategy simulation.
- The simulation uses a fixed 60 Hz step. Rendering caches chunks and light sprites, batches rain, pools effects, and lowers Canvas resolution when frame rate drops. Use Low if a high-DPI or software-rendered browser still struggles.
- Interiors are handcrafted cutaways, not multistory buildings. Metro travel is fast travel; the survey helicopter uses arcade flight. Fuel, an equities market, a freely climbable map, and full faction campaigns are not implemented. The trading desks support civilian commodities instead of stocks. Campaign scenes are camera and dialogue sequences, not full cinematic production. Combat stays fictional and stylized, not real-world ballistics or anatomical injury simulation.
- Saves restore the player, owned vehicle, campaign checkpoint, skill abilities, cargo, and activity records. They do not restore traffic, heat, deployed gear, or active side-job actors. Playing from disk was tested in Chromium and Firefox; storage and Gamepad API behavior may vary.
- Next: longer ambient event chains, faction-specific questlines, more cinematic sequences, more accessible aiming options, and physical-controller QA.

## Self-Review

- [x] Offline title and gameplay launch from the included HTML without HTTP requests.
- [x] Type check and single-file production build pass.
- [x] Desktop and touch Chromium tests reported no console or network errors and verified controls, audio startup, map, phone, debug controls, wardrobe, equipment, photo capture, save, and reload.
- [x] The opening mission was completed in offline Firefox using keyboard input, and its payout and next checkpoint were saved. No console errors were observed in this run.
- [x] The expanded Chromium walkthrough plays the first Monsoon job, switches atlas views, rides the metro, drives the tank, and verifies Outbreak's cache, noise, and independent save on the offline build.
- [x] Simulation suite exercises city streaming, collision, driving, combat and reload, pursuit and evasion, and hospital respawn.
- [x] Simulation suite advances all eighteen operations and verifies all five campaign endings. It uses teleports for long routes and controlled combat outcomes rather than replaying both campaigns in real time.
- [x] Simulation tests verify route connectivity, boat navigation, tracked barriers, metro travel, Outbreak pressure, supply drops, beacons, evacuation, and independent history.
- [x] Regression tests cover loading the original checkpoint format without merging its progress into the new modes.
- [x] Economy, contracts, inventory, character changes, manual save and restore, debug controls, and simulated standard-gamepad input are covered by simulation tests.
- [x] Regression tests check same-lane cruiser spacing, independent dispatch assignments, remembered search, zombie sound investigation, corner routing, attack windup, and barricade damage.
- [x] A reachability check covers the interior layouts. Simulation also covers service contracts, venue games, trading, and earned perks.
- [x] Atlas simulation checks distant signed coordinates, deterministic geometry, shared edge alignment, cross-city road paths, bounded caches, venue interactions, travel, and save restoration.
- [x] Offline Chromium Atlas checks cover distinct city previews, custom world creation, local chart panning, regional jobs, air and sea journeys, Jacklight, reload, and mobile entry with no console or HTTP errors.
- [x] Contact regression checks nearest collision, persistent glass, throwing and bouncing, shared ammo migration, firearm triggers, partial reloads, melee windups, guard, vaults, medkits, drill completion, and save isolation.
- [x] New world checks cover the inbox, briefing replay, parcel recovery, territory changes, clothing, and property income.
- [x] The weapon acceptance loop exercises all eleven items individually, including damage, action timing, projectile count or throw result, and ammunition use. Additional assertions cover animated vehicle transitions, garage changes, traffic queues, the SWAT/spike tier, and all eight ambient scenarios.
- [x] The Contact Chromium walkthrough exercises aiming, firing, reloading, guard, settings, save isolation, and street-event reporting. The touch run verifies the brace and reload buttons.
- [x] The Living City Chromium walkthrough navigates the tea-house floor, plays carrom, trades at the Lantern Exchange, and verifies mobile Outbreak equipment and camera controls without HTTP or console errors.
- [x] Final reflected pass verified denser authored-city chunks, labelled all-city World chart, water-safe road edges, animated atlas details, airborne helicopter layering and the altimeter in the offline browser build.
- [ ] A physical controller, Safari, and sustained 60 FPS on a range of laptop hardware have not been verified.

Run the dependency-free simulation suite with `node tests/simulation.mjs`. The optional [`tests/atlas.cjs`](tests/atlas.cjs), [`tests/browser.cjs`](tests/browser.cjs), [`tests/expansion.cjs`](tests/expansion.cjs), [`tests/depth.cjs`](tests/depth.cjs), [`tests/contact.cjs`](tests/contact.cjs), and [`tests/firefox.cjs`](tests/firefox.cjs) suites use Playwright. Install Playwright in a separate test environment and set `PLAYWRIGHT_PACKAGE` to its module path if needed.