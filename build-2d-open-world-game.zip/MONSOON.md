# Static Harbor: Monsoon Lines

## The Map Study

Monsoon City is fictional. The layout borrows Dhaka's relationships between places, not its exact streets or building footprints. It joins Vesper Bay by three causeways; the campaign, expansion, and supernatural survival mode have separate saves but share the same physical world.

| Dhaka reference | Design translation |
| --- | --- |
| [OpenStreetMap contributors](https://www.openstreetmap.org/#map=12/23.7740/90.4020), reviewed at zoom 12 across the north, central lakes, and southern river | Place the planned north and terminal at the top, the inland lakes across the middle, business districts along the spine, and compact market lanes against a bend in the southern river. Long north-south roads connect farther than many east-west streets. No tiles or map data are bundled. |
| [Banglapedia: Dhaka](https://en.banglapedia.org/index.php/Dhaka) and [Sadarghat](https://en.banglapedia.org/index.php/Sadarghat) | Ghat steps, a parallel market street, produce unloading, launch jetties, and a habitable opposite bank. |
| [UNESCO: Rickshaws and rickshaw painting in Dhaka](https://ich.unesco.org/en/RL/rickshaws-and-rickshaw-painting-in-dhaka-01589) and [Shankhari Bazaar](https://en.wikipedia.org/wiki/Shankhari_Bazaar) | Small frontage, narrow service lanes, workshop signs, and decorated three-wheelers with original floral motifs. A slow rickshaw can take a lane an armored vehicle cannot. |
| [The Daily Star: Hatirjheel development](https://www.thedailystar.net/news-detail-63627) and [Hatirjheel map](https://www.openstreetmap.org/#map=15/23.7712/90.4108) | Long retention basin, promenade, crossing bridges, water taxi, and lakeside driving, separate from the larger southern river. |
| [Dhaka MRT Line 6 route map](https://commons.wikimedia.org/wiki/File:MRT_Line_6_Route_Map_(en).svg) | A visible elevated line tying together north, market, and office stops. The fictional line can be ridden as a fast-travel service. |

Roadside detail covers both daily work and recreation: cha stalls, fruit carts, umbrella sellers, repair bays, office drop-offs, corrugated roofs, planted terraces, rain drains, footpaths, football courts, school grounds, river steps, and agricultural plots. Bengali signs use short real words for these places and services. No real people, critical-facility layouts, or incidents are portrayed.

## Play Loops

**Monsoon Lines:** Mara helps dispatcher Samira Noor reopen a volunteer river route. The work turns into eight jobs across the city, from hand-painted rickshaw transport to a lake bridge survey, motors, boats, and a municipal repair vehicle. A contractor has been locking public access behind a private gate. Decide how to return it.

**Outbreak:** An alternate, supernatural night. Use a supply cache, restore three beacons, and reach the evacuation ferry. Weapons and horns attract the Quiet. Sprinting is louder than sneaking. The longer you stay, the more varied the creatures become. Evacuate or keep surviving.

**Shared world:** A 264-chunk map (previously 80), with a hierarchy of major roads and narrow internal lanes, visible transit, and short optional jobs. Three causeways carry road traffic across the old outer shoreline. Boats and swimmers can use the water.