import { copyFile, mkdir, readFile } from 'node:fs/promises';

const artifact = new URL('../dist/index.html', import.meta.url);
const target = new URL('../play/', import.meta.url);
const html = await readFile(artifact, 'utf8');
if (/<script[^>]+src=|<link[^>]+rel=["'](?:stylesheet|modulepreload)/i.test(html)) {
  throw new Error('The offline artifact unexpectedly references external scripts or styles.');
}
await mkdir(target, { recursive: true });
await copyFile(artifact, new URL('index.html', target));
console.log('Standalone browser release: play/index.html');