# Static Harbor: Design Brief

Vesper Bay is a port city that rents its entire radio spectrum to a private utility. Mara Venn, a former night courier, intercepts a recording that implicates the utility in a deliberate blackout. Her mentor Inez Sable wants the truth on the air. Courier-turned-fixer Halden Rook wants Mara to hear the part of the recording Inez left out.

**Art direction:** Pixel-rendered dockside noir: ink-violet silhouettes, acid-pink signage, sea-green instrumentation, wet asphalt, amber security lights. The launch screen is a separate hand-drawn-in-code harbor vista, not a screenshot of the top-down world.

**Core loop:** Pick up a lead, drive or walk across the city, choose how to handle a complication, then spend the payout or follow the next signal. Free roam remains available after the campaign.

**Signature ideas:** Ghost relays temporarily black out a district and break surveillance; The Wire rewrites the local news around player actions; Night Frequencies turns three synthesized radio stations into a live score that reacts to the city.

```text
React launcher / menus / HUD
     |  snapshots and actions
     v
Fixed-step game -- input / save / mixer
     |          |             |
     v          v             v
Seeded city   Simulation   Campaign and activities
chunks + hash traffic / AI   objectives / economy / Wire
     |          |             |
     +----------+-------------+
                v
          Canvas renderer
```

The launcher and simulation ship together in one offline HTML file. The editable source is split into ES modules. The campaign prioritizes short missions with checkpoints and avoids locking the player out of free roam.