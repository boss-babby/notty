import assert from 'node:assert/strict';
import { buildChunk, City, isWater, roadPath } from '../src/game/world.js';
import { HarborGame, readSave, readSettings } from '../src/game/game.js';
import { CAMPAIGN, COLS, DEFAULTS, DISTRICTS, GARAGE, GEAR, MONSOON_CAMPAIGN, PLACES, ROWS, SEED, modelIndex, place } from '../src/game/data.js';
import { addCar, addPerson, debugStreetEvent, hitCar, hurtPerson } from '../src/game/actors.js';
import { bridgeDeck, navigable, roadConnection, wetland } from '../src/game/geography.js';
import { BEACONS, CACHES, EVAC } from '../src/game/outbreak.js';
import { clearSegment, localPath } from '../src/game/navigation.js';
import { createDispatch, driveUnit, isUnit } from '../src/game/dispatch.js';
import { roomGeometry } from '../src/game/interiors.js';
import { newTable } from '../src/game/parlor.js';
import { physicalAttack, spawnRound, weaponSpread } from '../src/game/contact.js';
import { circleContact, hullContact, rectContact } from '../src/game/contact-geometry.js';
import { HANDLING } from '../src/game/contact-data.js';
import { updateTraffic } from '../src/game/traffic.js';
import { perceiveCivilian } from '../src/game/crowds.js';
import { streetMarker } from '../src/game/street-events.js';
import { atlasConfig, destinations } from '../src/game/atlas-runtime.js';
import { edgeWidths, outerZone, surveyAt } from '../src/game/frontier-geo.js';
import { cellKey, regionOf } from '../src/game/geography.js';

// The same fixed-timestep simulation runs here without display or audio hardware.
const fakeGradient = () => ({ addColorStop() {} });
const fakeContext = () => ({ createLinearGradient: fakeGradient, createRadialGradient: fakeGradient, beginPath() {}, moveTo() {}, lineTo() {}, closePath() {}, fill() {}, fillRect() {} });
const fakeCanvas = () => ({ addEventListener() {}, removeEventListener() {}, getContext: fakeContext, getBoundingClientRect() { return { width: 1200, height: 800 }; } });
const storage = new Map();
globalThis.window = { addEventListener() {}, removeEventListener() {} };
globalThis.document = { createElement: fakeCanvas };
globalThis.localStorage = { getItem: key => storage.get(key), setItem: (key, value) => storage.set(key, value) };
globalThis.requestAnimationFrame = () => 1;
globalThis.cancelAnimationFrame = () => {};

const sound = { play() {}, advance() {}, updateSettings() {} };
const dt = 1 / 60;
const fresh = (record,mode='campaign') => {
  const game = new HarborGame(fakeCanvas(), { ...DEFAULTS, bindings: {} }, sound, () => {}, () => {}, record,mode);
  game.loop.stop(); game.people.clear(); game.cars = game.cars.slice(0, 1); game.spawnTimer = game.eventTimer = game.policeTimer = 999;
  return game;
};
const run = (g, seconds) => { for (let i = 0; i < Math.ceil(seconds / dt); i++) g.tick(dt); };
const go = (g, point) => g.teleport(point.x, point.y);
const use = g => { g.input.presses.add(g.binding('use')); g.tick(dt); };
const indoors = (g, id) => { go(g, place(id)); use(g); run(g, .66); assert.equal(g.room, id); };
const atDesk = g => { Object.assign(g.player,g.interior.service); };
const outside = g => { Object.assign(g.player,g.interior.exit);use(g);run(g,.67);assert.equal(g.room,null); };

{
  assert.deepEqual(buildChunk(2, 2, SEED), buildChunk(2, 2, SEED));
  const zones = new Set();
  for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) zones.add(buildChunk(x, y, SEED).zone);
  assert.equal(zones.size,13);
  const city = new City(SEED); city.stream(1100, 1000);
  assert.equal(city.active.length, 25);
  assert.ok(city.block(1100, 1070, 8)); assert.equal(city.block(1100, 985, 8), null);
  city.stream(4120, 2880); assert.ok(!city.cache.has(22));
  assert.equal(isWater(3530, 1190), true); assert.equal(isWater(3530, 1440), false);
  const path = roadPath({ x: 900, y: 959 }, { x: 3850, y: 1950 });
  assert.ok(path.length >= 7); assert.deepEqual(path.at(-1), { x: 3840, y: 1920 });
  console.log('PASS: seeded districts, chunks, collisions, bridges and A*');
}

{
  const g = fresh();
  const x = g.player.x;
  g.input.keys.add('KeyD'); run(g, .34); g.input.keys.delete('KeyD'); assert.ok(g.player.x > x + 25);
  use(g); assert.equal(g.car?.model.id, 'vanta');
  g.input.keys.add('KeyW'); run(g, .75); g.input.keys.delete('KeyW'); assert.ok(g.car.speed > 140);
  use(g); assert.equal(g.car, null);
  const model = addCar(g, 6, g.player.x + 21, g.player.y); use(g);
  assert.equal(g.hotwire?.car, model);
  g.hotwire.t = Math.acos(1 - 2 * g.hotwire.zone) / 6.4 - dt; use(g); assert.equal(g.car, model);
  g.exitCar(); g.cars = []; g.teleport(1070, 960); run(g, .28);
  const target = addPerson(g, 'enemy', 1155, 960, { hp: 25, cd: 999 });
  g.player.a = 0; const startingAmmo = g.armory[3].mag; g.fire(); run(g, .22);
  assert.ok(target.dead > 0); assert.equal(g.armory[3].mag, startingAmmo - 1);
  g.reload(); run(g, 1.25); assert.equal(g.armory[3].mag, startingAmmo);
  const chunk = g.city.get(2, 2), barrel = chunk.props.find(p => p.kind === 'barrel');
  g.breakProp(barrel, 60, 'player'); assert.ok(g.city.broken.has(barrel.id)); assert.ok(g.lights.items.some(p => p.active));
  g.teleport(1440,960);g.dev('heat',5);run(g,.75);assert.ok(g.heli);assert.equal(g.blockade.length,2);assert.ok(g.cars.some(v=>v.mode==='military'));
  g.cars = []; g.heat = 2; g.policeTimer = 999; g.lastSeen = { x: 0, y: 0 }; run(g, 28); assert.equal(g.heat, 0);
  g.player.inv = 0; g.playerHurt(1000); assert.equal(g.player.hp, 100); assert.ok(Math.hypot(g.player.x - place('hospital').x, g.player.y - place('hospital').y) < 19);
  console.log('PASS: input movement, driving, timing lock, projectiles, reload, explosion, pursuit/search, respawn');
}

{
  const g = fresh(); g.player.inv = 999;
  const op = n => assert.equal(g.chapter, n, `expected operation ${n + 1}: ${CAMPAIGN[n]?.title}`);
  const interact = point => { go(g, point); use(g); };

  interact(g.stage()); interact(g.stage()); op(1);
  go(g, g.stage()); run(g, .05);
  assert.equal(g.missionState.ride.model.id, 'regent');
  for (let i = 0; i < 60; i++) { go(g, g.missionState.ride); g.tick(dt); }
  use(g); interact(g.stage()); op(2);

  indoors(g, 'archive'); assert.equal(g.missionState.actors.length, 2);
  g.input.keys.add('ControlLeft'); g.input.keys.add('KeyW'); run(g, 2.16);
  g.input.keys.delete('KeyW'); use(g); g.input.keys.delete('ControlLeft');
  assert.equal(g.step, 1); assert.ok(g.skills.stealth >= 4);
  outside(g); go(g, g.stage()); run(g, .02); op(3);

  go(g, g.stage()); g.tick(dt); const mule = g.missionState.ride;
  use(g); assert.equal(g.car, mule); go(g, g.stage()); g.tick(dt); op(4);
  g.exitCar(); go(g, g.stage()); run(g, .1); assert.ok(g.missionState.ally);
  for (let i = 0; i < 280 && g.step === 0; i++) {
    const ally = g.missionState.ally; go(g, { x: ally.x, y: ally.y - 28 }); run(g, .05);
  }
  assert.equal(g.step, 1, 'Inez reaches the north gate'); go(g, g.stage()); run(g, .03); op(5);
  g.player.inv = 60; go(g, g.stage()); run(g, 18.15); assert.equal(g.step, 1, 'hold the exchange for the required duration');
  indoors(g, 'switch'); atDesk(g); use(g); op(6); use(g);
  assert.equal(g.blackout?.time > 30, true); outside(g);

  indoors(g, 'archive'); atDesk(g); use(g); assert.ok(g.heat >= 2); outside(g);
  g.cars = []; g.policeTimer = 999; go(g, g.stage()); run(g, 34); op(7);

  const racer = addCar(g, 2, g.stage().x, g.stage().y, 0, 'parked', { owned: true });
  g.enterCar(racer); go(g, g.stage()); const gates = g.stage().gates; g.tick(dt);
  for (const [x, y] of gates) { go(g, { x, y }); g.tick(dt); }
  op(8); g.exitCar(); go(g, g.stage()); run(g, .05);
  assert.ok(g.missionState.actors.some(n => n.boss));
  for (const n of g.missionState.actors) hurtPerson(g, n, 999, 'player');
  run(g, .04); interact(g.stage()); assert.equal(g.panel, 'choice');
  g.action('choose', 0); op(9); assert.equal(g.rook, 0);

  g.heat = 0; go(g, g.stage()); g.tick(dt); assert.equal(g.step, 1);
  for (const outcome of [0, 1, 2]) {
    const end = fresh({ version: 1, chapter: 9, step: 1 });
    indoors(end, 'coast'); atDesk(end); use(end); assert.equal(end.panel, 'choice');
    end.action('choose', outcome); assert.equal(end.chapter, 10); assert.equal(end.ending, outcome);
    run(end, 3); assert.equal(end.panel, 'ending');
  }
  indoors(g, 'coast'); atDesk(g); use(g); g.action('choose', 0); op(10);
  assert.equal(g.stats.missions, 10); assert.ok(g.news.some(n => n.title.startsWith('OPEN FREQUENCY')));
  console.log('PASS: all ten campaign operations and all three endings');
}

{
  const g = fresh(); const cash = g.cash;
  g.action('job', 'delivery');
  for (const [x,y] of g.job.nodes) { go(g, { x,y }); use(g); }
  assert.equal(g.stats.jobs, 1); assert.equal(g.cash, cash + 115);
  g.dev('cash'); g.buy('gear', 4); assert.ok(g.armory[4]); g.buy('deposit'); assert.equal(g.bankBalance, 100);
  g.buy('property'); assert.ok(g.properties.includes('loft')); g.day = 15.9999; run(g, .1); assert.equal(g.bankBalance, 138);
  g.action('look', { color: '#91dfc3', hair: 2 });
  g.dev('weather', 3); assert.equal(g.weather, 3); g.dev('time', 14); assert.equal(g.day, 14);
  g.dev('arsenal'); assert.equal(Object.keys(g.armory).length, GEAR.length); assert.ok(GARAGE.length >= 8);
  g.setWaypoint(1600, 1800); g.action('radio'); g.save();
  const saved = readSave(); const r = fresh(saved); assert.equal(r.cash, g.cash); assert.equal(r.player.hair, 2); assert.equal(r.weather, 3); assert.equal(r.station, g.station); assert.equal(r.waypoint.x, 1600);
  storage.set('static-harbor/1/settings', 'null'); assert.equal(readSettings().quality, 'High');
  console.log('PASS: contracts, shops, bank, property income, outfits, debug controls, manual save and restore');
}

{
  const g = fresh(); g.player.inv = 120;
  const ride = addCar(g, 2, g.player.x, g.player.y, 0, 'parked', { owned: true }); g.enterCar(ride);
  const pathJob = id => {
    g.action('job', id);
    for (const [x,y] of g.job.nodes) { go(g, { x,y }); if (g.job.kind === 'taxi') use(g); else g.tick(dt); }
  };
  pathJob('taxi'); pathJob('race');
  g.action('job', 'stunt'); go(g, { x: 4330, y: 2400 }); ride.vx = 249; g.tick(dt); assert.ok(g.jump > 0);
  g.exitCar(); g.action('job', 'vigilante'); go(g, { x: 680, y: 1450 }); g.tick(dt);
  assert.ok(g.job.ride); g.job.ride.hp = 4; g.tick(dt); assert.equal(g.job, null);
  g.action('job', 'arena'); go(g, { x: 979, y: 2419 }); g.tick(dt);
  for (const n of g.job.actors) hurtPerson(g, n, 999, 'player');
  g.tick(dt); assert.equal(g.job, null);
  g.action('job', 'collect');
  const seededTape = (() => { for (let i = 0; i < 7; i++) { const t = g.city.get(i, 2)?.tape; if (t) return t; } })();
  assert.ok(seededTape); go(g, seededTape); use(g); assert.ok(g.tapes.has(seededTape.id));
  g.action('job', 'catalog');
  for (const model of [3, 5, 6]) {
    const v = addCar(g, model, 1580, 1015, 0, 'parked', { owned: true });
    g.enterCar(v); g.teleport(1580, 1015); use(g); g.exitCar();
  }
  assert.equal(g.stats.jobs, 7);
  indoors(g, 'arcade'); const money = g.cash; g.buy('arcade');
  g.hotwire.t = Math.acos(1 - 2 * g.hotwire.zone) / 6.4 - dt; use(g); assert.equal(g.cash, money + 50);
  console.log('PASS: cab, circuit, stunt, vigilante, arena, tapes, imports, and arcade outcomes');
}

{
  const pad = { axes: [0, 0, 0, 0], buttons: Array.from({ length: 17 }, () => ({ pressed: false })) };
  Object.defineProperty(globalThis, 'navigator', { value: { getGamepads: () => [pad] }, configurable: true });
  const g = fresh(); pad.axes[0] = 1; run(g, .33); pad.axes[0] = 0; pad.buttons[0].pressed = true; g.tick(dt);
  assert.equal(g.car?.model.id, 'vanta');
  pad.buttons[0].pressed = false; pad.axes[1] = -1; run(g, .55); assert.ok(g.car.speed > 100);
  pad.buttons[1].pressed = true; g.tick(dt); assert.equal(g.car.brake, true);
  pad.buttons[9].pressed = true; g.tick(dt); assert.equal(g.panel, 'pause');
  delete globalThis.navigator;
  console.log('PASS: standard gamepad mapping, vehicle handbrake, and pause');
}

{
  assert.equal(COLS*ROWS,264);
  for(const y of [2,5,7])for(let x=9;x<=11;x++)assert.ok(roadConnection(x,y,x+1,y));
  assert.ok(!roadConnection(10,4,11,4));assert.ok(bridgeDeck(5060,2400));
  const route=roadPath({x:1160,y:990},{x:6886,y:3403});
  assert.ok(route.length>12&&route.some(p=>p.x>4450&&p.x<5500&&p.y%480===0));
  assert.ok(wetland(7720,4620)&&navigable(7720,4620));
  const city=new City(SEED);city.stream(7324,4480);assert.equal(city.block(7324,4480,8),null);assert.ok(!isWater(7324,4488));
  assert.ok(city.active.some(b=>b.street?.some(s=>s.kind==='fruit')));
  assert.notEqual(buildChunk(14,7,SEED).id,buildChunk(4,7,SEED).id);
  const key='static-harbor/1/save', previous=storage.get(key);
  storage.set(key,JSON.stringify({version:1,x:1130,y:988,chapter:4,cash:817,territory:DISTRICTS.slice(0,5).map(d=>d.faction)}));
  const legacy=fresh(readSave());assert.equal(legacy.chapter,4);assert.equal(legacy.territory.length,DISTRICTS.length);assert.equal(legacy.cash,817);
  assert.equal(readSave('monsoon'),null);storage.set(key,previous);
  console.log('PASS: 264 chunks, three connected causeways, distinct Monsoon lots and jetty');
}

{
  const g=fresh(null,'monsoon');g.player.inv=900;
  const at=n=>assert.equal(g.chapter,n,MONSOON_CAMPAIGN[n]?.title);
  const interact=point=>{go(g,point);use(g);};
  const leaveCar=()=>{g.exitCar();g.player.inv=900;};
  const ride=()=>{go(g,g.stage().approach||g.stage());g.tick(dt);assert.ok(g.missionState.ride);use(g);assert.ok(g.car);};
  interact(g.stage());interact(g.stage());at(1);
  ride();assert.equal(g.car.model.id,'rickshaw');go(g,g.stage());g.tick(dt);at(2);leaveCar();
  for(const [x,y] of g.stage().nodes)interact({x,y});
  indoors(g,'citymetro');atDesk(g);use(g);at(3);outside(g);
  ride();assert.equal(g.car.model.id,'launch');g.input.keys.add('KeyW');
  run(g,.53);assert.ok(g.car.speed>90&&navigable(g.car.x,g.car.y));
  for(let i=0;i<260&&g.step===1;i++)g.tick(dt);
  g.input.keys.delete('KeyW');assert.equal(g.step,2,'navigate the real river ribbon under forward throttle');
  leaveCar();assert.ok(!isWater(g.player.x,g.player.y));go(g,g.stage());g.tick(dt);at(4);
  const c=addCar(g,2,g.stage().x,g.stage().y,0,'parked',{owned:true});g.enterCar(c);const gates=g.stage().gates;g.tick(dt);
  for(const [x,y] of gates){go(g,{x,y});g.tick(dt);}at(5);leaveCar();
  ride();assert.equal(g.car.model.id,'floodworks');g.input.keys.add('KeyW');run(g,4.3);g.input.keys.delete('KeyW');
  assert.equal(g.step,2,'Track Work clears actual barriers under throttle');leaveCar();
  indoors(g,'works');atDesk(g);use(g);at(6);outside(g);
  ride();assert.equal(g.car.model.id,'rescue');go(g,g.stage());g.tick(dt);assert.equal(g.step,2);leaveCar();go(g,g.stage());run(g,16.3);at(7);
  go(g,g.stage());g.tick(dt);assert.equal(g.step,1);
  indoors(g,'garden');atDesk(g);use(g);assert.equal(g.panel,'choice');g.action('choose',1);at(8);assert.equal(g.ending,1);assert.equal(g.stats.missions,8);
  run(g,3);assert.equal(g.panel,'ending');g.open(null);outside(g);
  indoors(g,'oldmetro');atDesk(g);use(g);assert.equal(g.panel,'transit');const money=g.cash;g.action('transit','northmetro');assert.equal(g.cash,money-8);assert.ok(g.discovered.has('northmetro'));
  const original=readSave(),saved=readSave('monsoon');assert.equal(saved.mode,'monsoon');assert.equal(saved.chapter,8);assert.notEqual(original.mode,saved.mode);
  const clone=fresh(saved,'monsoon');assert.equal(clone.chapter,8);assert.equal(clone.cash,g.cash);
  const alternate=fresh({version:1,chapter:7,step:1},'monsoon');indoors(alternate,'garden');atDesk(alternate);use(alternate);alternate.action('choose',0);assert.equal(alternate.ending,0);
  console.log('PASS: all eight Monsoon missions, both outcomes, rickshaw, boat, tracked physics and metro');
}

{
  const t=fresh(null,'monsoon');t.cars=[];t.teleport(7300,3360);t.dev('spawn',modelIndex('bastion'));
  const tank=t.cars[0];t.enterCar(tank);t.input.keys.add('KeyA');run(t,.31);t.input.keys.delete('KeyA');
  assert.ok(Math.abs(tank.a)>.24);t.input.mouse.fire=true;t.tick(dt);t.input.mouse.fire=false;
  assert.ok(t.bolts.items.some(b=>b.active&&b.style==='rocket'));const pulse=tank.pulse;run(t,.06);assert.ok(tank.pulse<pulse);
  tank.hp=360;t.save();const record=readSave('monsoon');assert.equal(fresh(record,'monsoon').car.hp,360);
  console.log('PASS: tank pivot, fictional turret ability, and damage persists');
}

{
  const g=fresh(null,'outbreak');g.player.inv=60;
  assert.ok(g.outbreak);assert.equal(g.heat,0);go(g,CACHES[0]);const previous=g.armory[3].stash;use(g);
  assert.equal(g.outbreak.used.length,1);assert.ok(g.armory[3].stash>previous);
  g.signalNoise(500);run(g,.8);assert.ok(g.people.items.some(p=>p.active&&p.type==='infected'));assert.ok(g.outbreak.noise<500);
  for(let i=0;i<4;i++){const z=addPerson(g,'infected',g.player.x+35,g.player.y+40,{hp:3,variantZ:'runner'});hurtPerson(g,z,5,'player');}
  assert.equal(g.outbreak.kills,4);assert.equal(g.outbreak.drops.length,1);
  g.outbreak.clock=166;run(g,.03);assert.ok(g.outbreak.phase>=3);
  for(const b of BEACONS){go(g,b);use(g);assert.ok(g.outbreak.signal.includes(b.id));}
  go(g,EVAC);use(g);assert.equal(g.panel,'outbreak-end');assert.ok(g.outbreak.escaped&&g.best.score>1000);
  const saved=readSave('outbreak');assert.equal(saved.outbreak.signal.length,3);
  const again=fresh(saved,'outbreak');assert.equal(again.outbreak.escaped,true);again.player.inv=0;again.playerHurt(900);
  assert.equal(again.panel,'outbreak-end');assert.ok(again.outbreak.dead);assert.equal(again.save(),false);
  assert.ok(readSave('monsoon')&&readSave('campaign'));
  console.log('PASS: Outbreak spawns, noise, supply drops, escalation, three beacons, evac, death, independent checkpoint');
}

{
  const g=fresh();g.cars=[];g.teleport(1440,960);g.player.inv=999;
  const p=g.player, points=[[1754,976,Math.PI],[1458,1275,-Math.PI/2],[1153,979,0],[1422,674,Math.PI/2]];
  const squad=points.map(([x,y,a])=>addCar(g,8,x,y,a,'cruiser'));
  g.dev('heat',3);g.policeTimer=999;run(g,2.2);
  assert.ok(squad.every(v=>v.order));
  assert.equal(squad.filter(v=>v.order?.kind==='lead').length,1);
  assert.ok(squad.some(v=>v.order?.kind==='intercept')||squad.some(v=>v.order?.kind==='hold'));
  assert.ok(new Set(squad.map(v=>`${Math.round(v.order.x)}:${Math.round(v.order.y)}`)).size>=3);
  for(const a of squad)for(const b of squad)if(a!==b)assert.ok(Math.hypot(a.x-b.x,a.y-b.y)>=a.r+b.r,'squad keeps its physical spacing');
  const mark={...g.lastSeen};
  assert.ok(g.seen);g.teleport(2340,1720);g.policeTimer=999;run(g,3.9);
  assert.ok(!g.seen);assert.deepEqual(g.lastSeen,mark);assert.equal(g.dispatch.stage,'SECTOR SEARCH');
  assert.ok(g.cars.some(v=>isUnit(v)&&['sweep','search'].includes(v.order?.kind)));
  g.cars=[];g.people.clear();g.heat=1;g.dispatch=createDispatch();g.teleport(1350,960);
  const a=addCar(g,8,1130,959,0,'cruiser'),b=addCar(g,8,1097,959,0,'cruiser');
  a.order={kind:'intercept',x:1590,y:958,stop:25};b.order={...a.order};
  for(let i=0;i<232;i++){g.clock+=dt;driveUnit(g,a,dt,addPerson,()=>{});driveUnit(g,b,dt,addPerson,()=>{});assert.ok(Math.hypot(a.x-b.x,a.y-b.y)>a.r+b.r,'same-lane vehicles cannot overlap');}
  assert.ok(a.x>1375&&b.x>1190);
  console.log('PASS: distinct dispatch roles, remembered search, same-lane spacing and forward progress');
}

{
  const g=fresh(null,'outbreak');g.outbreak.timer=999;g.outbreak.used=['shelter'];g.cars=[];
  const from={x:1010,y:1115}, target={x:1207,y:1115};go(g,target);
  const path=localPath(g,from,target,7,1200,true);
  assert.ok(!clearSegment(g,from,target,7,true));assert.ok(path.length>=2);
  for(let i=0;i<path.length;i++)assert.ok(clearSegment(g,path[i-1]||from,path[i],7,true));
  assert.ok(Math.hypot(path.at(-1).x-target.x,path.at(-1).y-target.y)<26);
  const z=addPerson(g,'infected',from.x,from.y,{variantZ:'shambler',drift:0});
  const sound={x:1009,y:1030};g.signalNoise(306,sound,'decoy');run(g,.1);
  assert.equal(z.brain.state,'listen');assert.deepEqual(z.brain.memory,sound);
  go(g,{x:1209,y:1127});run(g,.7);assert.deepEqual(z.brain.memory,sound);
  g.people.clear();go(g,{x:1120,y:960});g.player.a=0;g.raiseBarricade();g.tick(dt);
  const board=g.city.playerProps[0];assert.ok(board?.solid&&g.city.block(board.x+4,board.y+20,7,true));
  const brute=addPerson(g,'infected',board.x+27,board.y+25,{variantZ:'brute',a:Math.PI,cd:0});
  g.signalNoise(350,g.player,'shot');run(g,2.6);assert.ok(board.hp<68&&brute.active);
  g.people.clear();go(g,{x:1070,y:960});g.player.hp=100;g.player.armor=0;
  const fast=addPerson(g,'infected',1052,960,{variantZ:'runner',a:0,cd:0});
  run(g,.11);assert.ok(fast.brain.attack);assert.equal(g.player.hp,100);
  go(g,{x:1126,y:955});run(g,.55);assert.equal(g.player.hp,100,'a committed lunge can miss');
  g.people.clear();go(g,{x:1110,y:913});g.player.a=Math.PI;const count=g.decoys;g.throwDecoy();run(g,.48);
  assert.equal(g.decoys,count-1);assert.ok(g.outbreak.acoustic.events.some(e=>e.kind==='decoy'));
  console.log('PASS: local corner routing, horde perception, damageable barricade, dodgeable windup and noisemakers');
}

{
  const layouts=PLACES.map(p=>roomGeometry(p.id));
  assert.equal(new Set(layouts.map(l=>l.id)).size,PLACES.length);
  for(const l of layouts){
    const walk=q=>{const b=l.bounds;return q.x>=b.x+8&&q.y>=b.y+8&&q.x<=b.right-8&&q.y<=b.bottom-8&&!l.walls.some(w=>q.x+8>w.x&&q.x-8<w.x+w.w&&q.y+8>w.y&&q.y-8<w.y+w.h);};
    const checks=[l.service,l.exit,...l.spots], done=new Set(), stack=[l.spawn];
    while(stack.length){const q=stack.pop(),k=`${q.x},${q.y}`;if(done.has(k)||!walk(q))continue;done.add(k);
      for(let i=checks.length-1;i>=0;i--)if(Math.hypot(q.x-checks[i].x,q.y-checks[i].y)<20)checks.splice(i,1);
      for(const [x,y] of [[8,0],[-8,0],[0,8],[0,-8]])stack.push({x:q.x+x,y:q.y+y});
    }
    assert.equal(checks.length,0,`blocked entrance or interactable in ${l.id}`);
  }
  const g=fresh({version:1,chapter:1},'monsoon');indoors(g,'cha');Object.assign(g.player,g.interior.spots.find(x=>x.id==='carrom'));use(g);
  assert.equal(g.table.id,'carrom');g.action('table-power',95);g.action('table-play');assert.equal(g.table.round,1);run(g,.5);assert.ok(g.table.pieces.some(x=>x.y<190&&Math.abs(x.vy)>3));
  g.open(null);g.table=newTable(g,'dyno');g.open('table');const money=g.cash;
  for(let i=0;i<5;i++){g.table.marker=g.table.goal;g.action('table-play');run(g,.41);}
  assert.ok(g.table.ended&&g.records.dyno.wins===1&&g.cash>money);
  g.open(null);g.table=newTable(g,'darts');g.open('table');
  for(let i=0;i<5;i++){g.table.clock=5.82;g.action('table-play');run(g,.38);}
  assert.ok(g.table.ended&&g.records.darts.plays===1);g.open(null);outside(g);
  indoors(g,'swapmeet');atDesk(g);use(g);assert.equal(g.panel,'exchange');
  const quote=g.quote(0);g.action('trade-buy',0);assert.equal(g.cargo.parts,1);const cash=g.cash;g.action('trade-sell',0);assert.equal(g.cash,cash+quote.sell);
  g.open(null);g.skills={aim:13,drive:11,stamina:8,stealth:9};g.skillTick();assert.equal(g.perks.length,4);
  assert.equal(fresh(readSave('monsoon'),'monsoon').perks.length,4);
  console.log('PASS: every venue is navigable; three playable activities, rewards, trade, and earned perks');
}

{
  const g=fresh();g.cars=[];
  const pick=id=>{g.action('job',id);const [x,y]=g.job.nodes[0];go(g,{x,y});g.tick(dt);const v=g.job.ride;assert.ok(v);g.enterCar(v);g.tick(dt);assert.equal(g.job.idx,1);return v;};
  pick('first-aid');for(const [x,y] of g.job.nodes.slice(1)){go(g,{x,y});use(g);run(g,.35);}assert.equal(g.job,null);g.exitCar();
  pick('tow-shift');let [x,y]=g.job.nodes[1];go(g,{x,y});g.tick(dt);use(g);assert.ok(g.car.tow?.towed);[x,y]=g.job.nodes[2];go(g,{x,y});use(g);assert.equal(g.job,null);g.exitCar();
  const air=pick('air-pass');g.input.keys.add('KeyW');run(g,.7);g.input.keys.delete('KeyW');assert.ok(air.alt>23);
  const gates=g.job.nodes.slice(1,-1);for(const [x,y] of gates){go(g,{x,y});run(g,.42);}
  [x,y]=g.job.nodes.at(-1);go(g,{x,y});g.input.keys.add('Space');run(g,1.44);g.input.keys.delete('Space');assert.equal(g.job,null);g.exitCar();
  pick('bus-shift');for(const [x,y] of g.job.nodes.slice(1)){go(g,{x,y});use(g);run(g,.35);}assert.equal(g.job,null);g.exitCar();
  g.action('job','lake-photo');for(const [x,y] of g.job.nodes){go(g,{x,y});g.action('photo-compose');g.action('photo-frame');}assert.equal(g.job,null);
  assert.ok(g.records['air-pass'].wins===1&&g.records['lake-photo'].wins===1);
  console.log('PASS: ambulance, tow hook, air survey gates and landing, bus stops, street photography');
}

{
  assert.ok(Math.abs(rectContact(0,0,90,0,{x:40,y:-2,w:1,h:4}).t-40/90)<1e-10);
  assert.ok(circleContact(0,0,80,0,{x:40,y:1,r:4}).t<.5);
  assert.equal(rectContact(0,8,90,0,{x:40,y:-2,w:1,h:4}),null);
  assert.ok(hullContact(0,0,70,0,{x:49,y:0,a:.4,model:{l:33,w:18}}).t<.59);
  const g=fresh();g.cars=[];go(g,{x:1060,y:960});g.player.a=0;
  const pane={x:1096,y:953,w:3,h:14,material:'glass',hp:17,type:'prop',kind:'window',id:'test-pane',mission:true,projectileOnly:true};
  g.city.temporary=[pane];g.city.changed=true;g.tick(dt);
  const npc=addPerson(g,'enemy',1151,960,{hp:84,cd:999,stun:999});
  g.fire();run(g,.19);assert.equal(pane.hp,0);assert.ok(npc.hp<84);
  const solid={x:1091,y:913,w:16,h:106,material:'stone',hp:Infinity};g.city.temporary=[solid];g.city.changed=true;run(g,.4);
  const before=npc.hp;g.player.a=0;g.fire();run(g,.21);assert.equal(npc.hp,before);assert.ok(g.scars.items.some(v=>v.active&&v.mat==='stone'));
  const thrown=spawnRound(g,1061,960,0,50,150,'charge','player',{speed:252});run(g,.24);
  assert.ok(thrown.active&&thrown.hops>0&&thrown.vx<0);run(g,1.13);assert.ok(!thrown.active);
  const original=g.city.get(2,2).panels[0];assert.ok(original);
  g.breakProp(original,50,'player');g.teleport(6820,3402);go(g,original);
  assert.equal(g.city.get(2,2).panels.find(v=>v.id===original.id).hp,0);
  console.log('PASS: swept shapes, nearest cover, glass persistence, delayed bouncing game projectile');
}

{
  const rec={version:1,chapter:0,cash:300,armory:{3:{mag:10,stash:32},4:{mag:24,stash:20}}};
  const g=fresh(rec);g.cars=[];go(g,{x:1120,y:960});
  assert.equal(g.armory[3].stash,52);assert.equal(g.armory[4].stash,52);assert.equal(g.armory[3].mag,10);
  g.player.a=0;g.input.mouse.fire=true;g.input.mouseTap=true;run(g,.70);g.input.mouse.fire=false;
  assert.equal(g.armory[3].mag,9,'semi-auto fires once per input edge');
  g.selectWeapon(4);run(g,.24);g.input.mouse.fire=true;run(g,.39);g.input.mouse.fire=false;
  assert.ok(g.armory[4].mag<21,'automatic gear can fire continuously');
  g.selectWeapon(3);run(g,.23);const loose=weaponSpread(g);g.input.keys.add('KeyX');run(g,.26);g.input.keys.delete('KeyX');
  assert.ok(weaponSpread(g)<loose);g.reload();run(g,1.3);assert.equal(g.armory[3].mag,12);assert.equal(g.armory[4].stash,49);
  g.dev('arsenal');g.selectWeapon(5);g.armory[5].mag=0;run(g,.3);g.reload();run(g,.55);
  assert.equal(g.armory[5].mag,1);assert.ok(g.contact.reload);
  assert.ok(g.fire());assert.equal(g.armory[5].mag,0);assert.equal(g.contact.reload,null);
  const keep=g.ammoPools.LIGHT;g.save(true);const restored=fresh(readSave());
  assert.equal(restored.ammoPools.LIGHT,keep);assert.equal(restored.armory[4].stash,keep);
  console.log('PASS: shared ammo migration, semi and automatic behavior, brace spread, interruptible shell reload');
}

{
  const g=fresh();g.cars=[];go(g,{x:1100,y:960});g.player.a=0;g.player.armor=0;
  const n=addPerson(g,'enemy',1127,960,{hp:64,stun:999,cd:999});
  g.selectWeapon(0);run(g,.2);assert.ok(g.fire());
  run(g,.061);assert.equal(n.hp,64);run(g,.12);assert.ok(n.hp<64,'windup must cross before damage');
  run(g,.3);g.player.a=0;g.input.keys.add('KeyX');run(g,.09);
  const health=g.player.hp;physicalAttack(g,n,40,22);assert.ok(health-g.player.hp<5);g.input.keys.delete('KeyX');
  assert.ok(g.player.stamina<100);
  g.people.clear();g.teleport(1090,960);g.player.a=0;
  const crate={x:1109,y:953,w:14,h:14,type:'prop',kind:'crate',hp:30,id:'vault-test',mission:true};g.city.temporary=[crate];g.city.changed=true;g.tick(dt);
  g.input.presses.add('Space');g.tick(dt);assert.ok(g.player.vault);run(g,.36);assert.ok(g.player.x>1138&&!g.player.vault&&g.player.lift===0);
  g.player.hp=71;const packs=g.medkits;g.heal();run(g,.4);assert.equal(g.medkits,packs);run(g,.53);assert.equal(g.medkits,packs-1);assert.equal(g.player.hp,100);
  console.log('PASS: committed melee, directional guard, collision-safe vault, delayed medkit');
}

{
  const citySave=storage.get('static-harbor/1/save');
  const g=fresh(null,'practice');assert.equal(g.panel,'practice');assert.equal(g.mode,'practice');assert.equal(g.room,'bay');
  g.action('drill','plates');assert.equal(g.panel,null);assert.ok(g.practice.active);
  for(let i=0;i<8;i++){
    let n=g.people.items.find(x=>x.active&&x.type==='target'&&!x.dead);
    if(!n){run(g,1.3);n=g.people.items.find(x=>x.active&&x.type==='target'&&!x.dead);}
    assert.ok(n);
    g.player.x=n.x;g.player.y=n.y+37;g.player.a=-Math.PI/2;g.player.cd=0;g.contact.bias=0;g.fire();run(g,.09);
  }
  assert.equal(g.panel,'practice-results');assert.ok(g.practice.last?.passed);assert.ok(g.practice.best.plates.score>=1000);
  assert.equal(g.save(true),false);assert.equal(storage.get('static-harbor/1/save'),citySave);assert.equal(readSave('practice'),null);
  g.action('drill','materials');assert.equal(g.interior.walls.filter(w=>w.material==='glass').length,3);
  g.action('drill','spar');assert.equal(g.weapon,0);assert.ok(g.people.items.some(n=>n.type==='spar'&&n.active));
  console.log('PASS: shared live simulation in training, draw targets, completion, scores and save isolation');
}

{
  const g=fresh(null,'monsoon');g.cars=[];g.cash=2500;g.save(true);
  const copy=fresh(readSave('monsoon'),'monsoon');assert.ok(copy.inbox.some(m=>m.speaker==='Samira Noor'));
  g.action('briefing');assert.equal(g.briefing.title,'Rain Check');run(g,.24);assert.ok(g.briefing.time<4.6);
  g.input.keys.add('KeyD');g.tick(dt);g.input.keys.delete('KeyD');assert.equal(g.briefing,null);
  g.dev('chapter',4);g.action('job','shop-watch');const points=g.job.nodes;
  go(g,{x:points[0][0],y:points[0][1]});use(g);g.tick(dt);assert.ok(g.job.courier);
  go(g,g.job.courier);use(g);go(g,{x:points[2][0],y:points[2][1]});use(g);assert.equal(g.job,null);
  g.action('job','jheel-line');const [x,y]=g.job.nodes[0];go(g,{x,y});g.tick(dt);assert.ok(g.job.actors.length);
  for(const n of g.job.actors)hurtPerson(g,n,900,'player');run(g,18);assert.equal(g.job,null);assert.ok(g.rep.River>2);
  indoors(g,'ghat');g.buy('holding',0);assert.ok(g.properties.includes('ghat-counter'));outside(g);
  indoors(g,'lake');g.buy('holding',1);assert.ok(g.properties.includes('lake-stall'));g.day=19.9998;
  const previous=g.bankBalance;run(g,.1);assert.equal(g.bankBalance,previous+78);
  g.buy('outfit',1);assert.equal(g.player.outfit,1);assert.ok(g.clothes.includes(1));
  console.log('PASS: inbox, replayable briefing, parcel recovery, district control, properties and wardrobe');
}

{
  const expected=[['hands','melee'],['bat','melee'],['blade','melee'],['pistol','bolt'],['smg','bolt'],['shotgun','bolt'],['rifle','bolt'],['sniper','bolt'],['grenade','charge'],['molotov','flask'],['rocket','rocket']];
  for(const [id,kind] of expected){
    const g=fresh();g.cars=[];g.dev('arsenal');go(g,{x:1050,y:960});
    const index=GEAR.findIndex(w=>w.id===id), w=GEAR[index],h=HANDLING[id],p=g.player;
    g.selectWeapon(index);run(g,.32);p.a=0;const m=g.armory[index].mag;
    if(kind==='melee'){
      const n=addPerson(g,'enemy',1076,960,{hp:100,stun:999,cd:999});
      assert.equal(g.fire(),true,id);assert.equal(n.hp,100,id+' windup');
      run(g,h.wind+.045);assert.ok(n.hp<100,id+' makes contact');assert.equal(g.contact.swing.slot,index);
    }else if(kind==='charge'||kind==='flask'){
      const witness=addPerson(g,'enemy',1194,960,{hp:90,stun:999,cd:999});
      assert.ok(g.fire());assert.ok(g.contact.throwing);assert.equal(g.armory[index].mag,m);
      run(g,h.wind+.047);assert.equal(g.armory[index].mag,m-1);assert.ok(g.bolts.items.some(b=>b.active&&b.style===kind));
      run(g,1.28);assert.ok(!g.bolts.items.some(b=>b.active&&b.style===kind));
      if(kind==='flask')assert.ok(g.fires.items.some(f=>f.active));
      assert.ok(witness.hp<90,id+' affects actors after landing');
    }else{
      const target=addPerson(g,'enemy',1118,960,{hp:125,stun:999,cd:999});
      assert.ok(g.fire(),id);assert.equal(g.armory[index].mag,m-1);
      assert.equal(g.bolts.items.filter(b=>b.active&&b.style===kind).length,w.count);
      assert.ok(g.contact.kick>0);assert.ok(!g.fire(),id+' cadence');run(g,w.rate+.05);
      assert.ok(target.hp<125,id+' fires a round that actually hits its target');
    }
    if(w.mag){
      const reserve=g.armory[index].stash;g.player.cd=0;g.reload();run(g,w.reload+.48);
      assert.equal(g.armory[index].mag,m,id+' reload restores usable state');assert.ok(g.armory[index].stash<reserve);
    }
  }
  assert.notEqual(GEAR[8].ammo,GEAR[9].ammo);
  console.log('PASS: all eleven weapon profiles, hit timing, pellet counts, recoil, throws, magazine and reserve behavior');
}

{
  const g=fresh();g.cars=[];go(g,{x:1120,y:960});
  const car=addCar(g,2,1153,966,0,'parked',{owned:true});
  assert.ok(g.enterCar(car));assert.equal(g.player.vanim.kind,'enter');assert.equal(car.door.kind,'enter');run(g,.31);assert.equal(g.player.vanim,null);
  const previous=car.light;g.input.presses.add('KeyL');g.tick(dt);assert.notEqual(car.light,previous);
  assert.ok(g.exitCar());assert.equal(g.player.vanim.kind,'exit');run(g,.28);assert.equal(g.player.vanim,null);
  assert.ok(Math.hypot(g.player.x-car.x,g.player.y-car.y)>16);
  const near=place('garage');car.x=near.x;car.y=near.y-32;go(g,near);g.cash=1000;
  g.buy('paint',2);g.buy('plate','river-7');g.buy('upgrade');
  assert.equal(car.color,'#699b8a');assert.equal(car.plate,'RIVER-7');assert.equal(car.boost,1);
  hitCar(g,car,29,'world',{ax:8,ay:3,material:'glass'});assert.equal(car.scuffs.length,1);g.buy('repair');assert.equal(car.scuffs.length,0);assert.equal(car.hp,car.model.hp);
  g.input.keys.add('KeyZ');g.input.keys.add('KeyA');run(g,.6);g.input.keys.delete('KeyZ');g.input.keys.delete('KeyA');assert.ok(Math.abs(g.player.vx)<80);
  g.cars=[];const metro=place('northmetro');go(g,{x:metro.x,y:metro.y-18});g.dev('spawn',16);
  g.input.keys.add('KeyD');run(g,.41);g.input.keys.delete('KeyD');assert.equal(g.streetAccess().ride?.model.id,'bastion');
  go(g,{x:3530,y:1190});run(g,.19);assert.ok(g.player.swim);assert.ok(!g.fire());
  console.log('PASS: player vehicle animation, headlights, customization, repair, slow walk and swim restrictions');
}

{
  const g=fresh();g.cars=[];go(g,{x:1415,y:1090});
  const n=addCar(g,0,1314,981,0,'traffic',{speed:96,vx:96}), q=addCar(g,1,1364,981,0,'parked');
  g.clock=8.7;
  for(let i=0;i<218;i++){
    g.clock+=dt;updateTraffic(g,n,dt);assert.ok(Math.hypot(n.x-q.x,n.y-q.y)>=n.r+q.r,'queued traffic must not overlap');
  }
  assert.ok(n.speed<3.5);g.cars=[n];for(let i=0;i<380;i++){g.clock+=dt;updateTraffic(g,n,dt);}
  assert.ok(n.x>1414||n.y!==981,'normal traffic resumes after the light and obstacle clear');
  g.cars=[];go(g,{x:1440,y:960});g.player.inv=999;g.dev('heat',4);run(g,.84);
  assert.ok(g.heli&&g.cars.some(v=>v.mode==='swat'));assert.ok(g.blockade.some(b=>b.kind==='spikes'));
  const b=g.blockade.find(q=>q.kind==='spikes'),ride=addCar(g,2,b.x,b.y,0,'parked',{owned:true});
  g.enterCar(ride);g.tick(dt);assert.ok(ride.tireWear>.9);
  console.log('PASS: traffic queues, crossing release, tier-four SWAT, helicopter and distinct spike strip');
}

{
  const types=['robbery','chase','race','ambulance','fire','protest','turf','lost'];
  for(const id of types){
    const g=fresh();g.cars=[];go(g,{x:1440,y:960});g.player.inv=999;
    assert.ok(debugStreetEvent(g,id),id);const incident=g.streetEvent;assert.equal(incident.kind,id);
    if(id==='robbery'||id==='lost'){const point=streetMarker(g);assert.ok(point);go(g,point);use(g);assert.equal(g.streetEvent,null);assert.ok(g.cash>240);}
    else if(id==='chase'||id==='race'){assert.equal(incident.rides.length,2);run(g,1.3);assert.ok(incident.rides[0].speed>20);}
    else if(id==='ambulance'||id==='fire'){assert.equal(incident.rides[0].model.id,id==='fire'?'hearth':'rescue');run(g,12);assert.ok(['working','cleared'].includes(incident.stage));}
    else if(id==='protest'){assert.ok(incident.people.filter(n=>n.active&&n.routine==='vigil').length>=3);}
    else if(id==='turf'){for(const n of incident.people)if(n.sideGroup===1)hurtPerson(g,n,400,'world');run(g,4);assert.equal(g.territory[incident.zone],incident.teams[0]);}
  }
  const g=fresh();g.cars=[];go(g,{x:1110,y:960});const citizen=addPerson(g,'ped',1160,960,{mood:.56,a:Math.PI});
  g.alarm=2;g.emitStreetNoise(g.player.x,g.player.y,235);assert.equal(perceiveCivilian(g,citizen).action,'call');
  run(g,2);assert.ok(g.heat>0&&g.news.some(q=>q.title.includes('witness')));
  console.log('PASS: eight ambient event types, local territory resolution and witnessed dispatch');
}

{
  const config=atlasConfig({key:'Palm Circuit',style:'islands',start:'basin'});
  assert.equal(atlasConfig({key:'Palm Circuit'}).seed,config.seed);
  assert.notEqual(atlasConfig({key:'Basin Circuit'}).seed,config.seed);
  const g=fresh({start:config.start,seed:config.seed,style:config.style,worldKey:config.key},'atlas');
  assert.equal(regionOf(g.player.x,g.player.y),'basin');
  const city=g.city;const markers=new Set();
  for(let i=0;i<43;i++){
    const x=-i-5,y=19-i;city.stream(x*480+233,y*480+225);markers.add(cellKey(x,y));
    assert.equal(city.active.length,25);assert.ok(city.cache.size<=25);assert.ok(city.tiles.size<=25);
  }
  assert.equal(markers.size,43);assert.ok(city.charted.size>=44);
  assert.deepEqual(buildChunk(-13,43,config.seed,new Set(),config.style),buildChunk(-13,43,config.seed,new Set(),config.style));
  const key=`${config.seed}:${config.style}`;assert.ok(key.includes('islands'));
  const [n,e,s,w]=edgeWidths(-10,-12,config.seed,config.style);
  assert.equal(n,edgeWidths(-10,-13,config.seed,config.style)[2]);assert.equal(e,edgeWidths(-9,-12,config.seed,config.style)[3]);
  assert.equal(s,edgeWidths(-10,-11,config.seed,config.style)[0]);assert.equal(w,edgeWidths(-11,-12,config.seed,config.style)[1]);
  let variants=0;for(let y=-18;y<22;y++)for(let x=36;x<46;x++)if(outerZone(x,y,config.seed,'islands')!==outerZone(x,y,config.seed,'badlands'))variants++;
  assert.ok(variants>50);
  go(g,{x:-23,y:960});g.cars=[];const x=g.player.x;g.input.keys.add('KeyA');run(g,.71);g.input.keys.delete('KeyA');assert.ok(g.player.x<x-38);
  g.setWaypoint(-14500,17000);assert.equal(g.waypoint.x,-14500);
  g.save(true);const restored=fresh(readSave('atlas'),'atlas');assert.equal(restored.worldKey,config.key);assert.equal(restored.city.style,'islands');assert.ok(restored.player.x<0);assert.ok(restored.city.charted.size>=g.city.charted.size);
  const mirage=place('marina'),basin=place('jacklight');
  assert.ok(roadPath({x:6886,y:3403},mirage,SEED).length>12);
  assert.ok(roadPath(mirage,basin,SEED).length>10);
  console.log('PASS: open atlas signed streaming, bounded caches, deterministic seeds and style-dependent biomes');
}

{
  const g=fresh(null,'atlas');g.cars=[];
  for(const [id,other,kind] of [['marina','ghat','sea'],['air-mirage','basin-air','air']]){
    indoors(g,id);atDesk(g);use(g);assert.equal(g.panel,`travel-${kind}`);
    const before=g.cash, route=destinations(kind,id).find(p=>p.id===other);g.action(`fare-${kind}`,other);
    assert.ok(g.flight);run(g,1.8);assert.equal(g.flight,null);assert.equal(g.room,null);assert.equal(g.cash,before-route.cost);
    assert.ok(g.discovered.has(other));
  }
  indoors(g,'halation');const cast=g.people.items.filter(n=>n.active&&n.indoor);assert.ok(cast.some(n=>n.type==='dancer')&&cast.some(n=>n.type==='host'));
  atDesk(g);use(g);assert.equal(g.panel,'club');g.action('club-talk',1);assert.equal(g.line.speaker,'Rae Serrano');g.open(null);outside(g);
  indoors(g,'jacklight');atDesk(g);use(g);assert.equal(g.panel,'jacklight');g.action('jacklight');assert.equal(g.tableRoll.numbers.length,3);assert.ok(g.records.jacklight.plays);g.open(null);outside(g);
  indoors(g,'ember');atDesk(g);use(g);assert.equal(g.panel,'field-office');g.action('start-ember');assert.equal(g.job.id,'fort-relief');run(g,.66);assert.equal(g.room,null);
  let beacon=null;
  for(let x=-40;x<-3&&!beacon;x++)for(let y=22;y<41&&!beacon;y++)beacon=surveyAt(x,y,g.city.seed,g.city.style);
  assert.ok(beacon);g.cars=[];go(g,beacon);const prior=g.cash;use(g);assert.equal(g.cash,prior+55);assert.ok(g.surveys.has(beacon.id));use(g);assert.equal(g.cash,prior+55);
  assert.ok(readSave('atlas').surveys.includes(beacon.id));
  console.log('PASS: airport and sea travel, club dialogue, free score game, field office and persistent frontier survey');
}