const assert=require('node:assert/strict');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium,devices}=require(process.env.PLAYWRIGHT_PACKAGE||'playwright');

const url=pathToFileURL(path.resolve(__dirname,'../index.html')).href;
const button=(p,name)=>p.getByRole('button',{name,exact:true});
const heading=(p,name)=>p.getByRole('heading',{name,exact:true}).waitFor();
const slots=['save','save-monsoon','save-outbreak'];

(async()=>{
  const browser=await chromium.launch(), issues=[];
  function observe(p){
    p.on('pageerror',e=>issues.push(e.message));
    p.on('console',m=>{if(m.type()==='error')issues.push(m.text());});
    p.on('request',r=>{if(/^https?:/.test(r.url()))issues.push(r.url());});
  }
  try{
    const p=await browser.newPage({viewport:{width:1440,height:900},offline:true});observe(p);p.setDefaultTimeout(9000);
    await p.goto(url);await heading(p,'Open Atlas');await button(p,'Vesper Bay').click();await button(p,'New Game').click();await heading(p,'Dead Drop');
    await p.keyboard.press('Tab');await heading(p,'Pocket Relay');await button(p,'Messages').click();assert.ok(await p.locator('.inbox').getByText('Inez Sable',{exact:true}).isVisible());
    await button(p,'Replay mission briefing').click();await p.locator('.dialogue').getByText('Inez Sable',{exact:true}).waitFor();
    await p.keyboard.press('d');await p.keyboard.press('F6');await p.getByText('Game saved',{exact:true}).waitFor();
    await button(p,'Pause game').click();await button(p,'Return to title').click();await button(p,'Exit without saving').click();await heading(p,'Static Harbor');
    const before=await p.evaluate(keys=>keys.map(k=>localStorage.getItem(`static-harbor/1/${k}`)),slots);assert.ok(before[0]);

    await button(p,'Training Bay').click();await heading(p,'Training Bay');await button(p,'Enter the Bay').click();await heading(p,'Choose a Drill');
    await button(p,'Start Break & Cover').click();await heading(p,'Break & Cover');await p.waitForTimeout(160);
    const target=await p.evaluate(()=>{
      const canvas=document.querySelector('.world-canvas'), c=canvas.getContext('2d'), box=canvas.getBoundingClientRect(), data=c.getImageData(0,0,canvas.width,canvas.height);
      let match=null;
      for(let y=135;y<Math.min(370,data.height);y++)for(let x=550;x<Math.min(875,data.width);x++){
        const k=(y*data.width+x)*4,[r,g,b]=[data.data[k],data.data[k+1],data.data[k+2]];
        if(r>=173&&g>=118&&r-g>20&&g-b>14&&r-g<69){const score=Math.abs(x-data.width*.5)+Math.abs(y-data.height*.245);if(!match||score<match.score)match={x,y,score};}
      }
      return match?{x:box.left+match.x*box.width/data.width,y:box.top+match.y*box.height/data.height}:null;
    });
    const main=await p.locator('.world-canvas').boundingBox();
    await p.mouse.move(target?.x||main.width*.5,target?.y||main.height*.255);await p.waitForTimeout(100);
    await p.mouse.down();await p.waitForTimeout(510);await p.mouse.up();
    await p.waitForFunction(()=>document.querySelector('.hud-instrument > strong')?.textContent?.trim().startsWith('11'));
    assert.match(await p.locator('.hud-instrument > strong').textContent(),/^11/);
    await p.keyboard.down('x');await p.locator('.hud-instrument').getByText('BRACED',{exact:true}).waitFor();await p.keyboard.up('x');
    await p.keyboard.press('r');await p.locator('.hud-instrument').getByText('RELOADING',{exact:true}).waitFor();
    await p.waitForFunction(()=>document.querySelector('.hud-instrument > strong')?.textContent?.trim().startsWith('12'));
    await p.keyboard.press('q');await heading(p,'Weapon Wheel');await button(p,'Dock Sweeper').click();
    await p.locator('.hud-instrument').getByText('Dock Sweeper',{exact:true}).waitFor();
    await p.keyboard.press('Tab');await heading(p,'Choose a Drill');await button(p,'Start Sparring Ring').click();await heading(p,'Sparring Ring');
    await p.mouse.move(720,240);await p.keyboard.down('x');await p.locator('.hud-instrument').getByText('GUARD',{exact:true}).waitFor();await p.keyboard.up('x');
    await p.keyboard.press('Escape');await heading(p,'Paused');await button(p,'Settings').click();await button(p,'Combat').click();
    await p.getByRole('switch',{name:/Full flash effects/}).uncheck();await p.getByRole('switch',{name:/Hold-to-fire assist/}).check();await p.keyboard.press('Escape');
    await button(p,'Return to title').click();await heading(p,'Training Bay');
    const after=await p.evaluate(keys=>keys.map(k=>localStorage.getItem(`static-harbor/1/${k}`)),slots);assert.deepEqual(after,before);
    console.log('PASS: inbox, briefing, practice, semi-auto, bracing, reload, wheel, guard, combat settings and isolated saves');

    await button(p,'Vesper Bay').click();await button(p,'Load Game').click();await button(p,'Continue').click();await heading(p,'Dead Drop');
    await button(p,'Pause game').click();await button(p,'Debug & cheats').click();
    await p.getByLabel('Street event',{exact:true}).selectOption('fire');await button(p,'Start event').click();
    await p.getByText('Street event started',{exact:true}).waitFor();
    await p.keyboard.press('Tab');await heading(p,'Pocket Relay');await button(p,'The Wire').click();
    assert.ok(await p.getByText('Hearth Response was dispatched to a smoking street kiosk.',{exact:true}).isVisible());
    console.log('PASS: real street event selection and dynamic reporting on the offline build');

    const mobile=await browser.newPage({...devices['iPhone 13'],offline:true});observe(mobile);
    await mobile.goto(url);await button(mobile,'Training Bay').tap();await button(mobile,'Enter the Bay').tap();await heading(mobile,'Choose a Drill');
    await button(mobile,'Start Plate Line').tap();await heading(mobile,'Plate Line');
    assert.ok(await button(mobile,'Brace or guard').isVisible());assert.ok(await button(mobile,'Reload').isVisible());
    assert.ok(await mobile.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
    assert.deepEqual(issues,[]);console.log('PASS: offline mobile drills and touch combat controls with no console or network errors');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});