const assert=require('node:assert/strict');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium,devices}=require(process.env.PLAYWRIGHT_PACKAGE||'playwright');

const offline=pathToFileURL(path.resolve(__dirname,'../index.html')).href;
const button=(p,name)=>p.getByRole('button',{name,exact:true});
const heading=(p,name)=>p.getByRole('heading',{name,exact:true}).waitFor();
async function hold(p,key,ms){await p.keyboard.down(key);await p.waitForTimeout(ms);await p.keyboard.up(key);}
async function choose(p,name){await button(p,name).click();}
async function pause(p){await p.keyboard.press('Escape');await heading(p,'Paused');}

(async()=>{
  const browser=await chromium.launch();const errors=[];
  const watch=p=>{p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text());});p.on('request',r=>{if(/^https?:/.test(r.url()))errors.push(r.url());});};
  try {
    const p=await browser.newPage({viewport:{width:1440,height:900},offline:true});watch(p);p.setDefaultTimeout(8500);
    await p.goto(offline);await heading(p,'Open Atlas');await choose(p,'Monsoon Lines');await heading(p,'Monsoon Lines');await choose(p,'New Game');await heading(p,'Rain Check');
    await p.keyboard.press('e');await p.getByText('Get the boat roster from the curbside stand',{exact:true}).first().waitFor();
    await hold(p,'s',230);await p.waitForTimeout(100);await hold(p,'d',875);await hold(p,'w',405);
    await p.locator('.use-prompt').getByText('Get the boat roster from the curbside stand').waitFor();await p.keyboard.press('e');await heading(p,'Paint and Pedals');

    await p.keyboard.press('m');await heading(p,'City Map');await choose(p,'World');await choose(p,'ZOOM +');
    await choose(p,'Monsoon City');await p.getByLabel('Pin discovered location').selectOption('cha');assert.ok(await button(p,'Clear pin').isEnabled());
    await choose(p,'Clear pin');await p.keyboard.press('Escape');
    await pause(p);await choose(p,'Debug & cheats');await p.getByLabel('Teleport location').selectOption('oldmetro');await choose(p,'Teleport');
    await p.keyboard.press('e');await p.locator('.hud-loc strong').filter({hasText:'Puran Metro'}).waitFor();await p.waitForTimeout(400);
    await hold(p,'w',1100);await p.getByText('Read metro timetable',{exact:true}).waitFor();await p.keyboard.press('e');await heading(p,'Monsoon Metro');
    await p.locator('.transit-list .terminal-row').filter({hasText:'Enclave Metro'}).getByRole('button',{name:'Ride / $8'}).click();
    await p.getByText('Metro arrival',{exact:true}).waitFor();
    await pause(p);await choose(p,'Debug & cheats');await p.getByLabel('Vehicle model').selectOption({label:'Bastion Carrier'});await choose(p,'Spawn');await p.keyboard.press('Escape');
    await hold(p,'d',375);
    const enterTank=p.getByText('Enter Bastion Carrier',{exact:true});
    for(let i=0;i<4&&!(await enterTank.isVisible());i++){await hold(p,'d',75);await p.waitForTimeout(110);}
    await enterTank.waitFor();await p.keyboard.press('e');await p.getByText('Bastion Carrier',{exact:true}).waitFor();
    await p.locator('.world-canvas').click({position:{x:845,y:435}});await p.keyboard.press('F6');await p.getByText('Game saved',{exact:true}).waitFor();
    await pause(p);await choose(p,'Return to title');await choose(p,'Save and exit');await heading(p,'Monsoon Lines');

    await choose(p,'Outbreak');await choose(p,'Start Survival');await heading(p,'Outbreak');await p.getByRole('meter',{name:'Noise'}).waitFor();
    const cache=p.locator('.use-prompt').getByText('Open Shelter supply cache',{exact:true});
    for(let i=0;i<4&&!(await cache.isVisible());i++){await hold(p,'d',i===0?320:105);await p.waitForTimeout(140);}
    await cache.waitFor();await p.keyboard.press('e');
    await p.getByText('Cache secured',{exact:true}).waitFor();
    await p.mouse.move(780,412);await p.mouse.down();await p.waitForTimeout(160);await p.mouse.up();
    await p.waitForFunction(()=>Number(document.querySelector('[aria-label="Noise"]')?.getAttribute('aria-valuenow'))>20);
    await p.keyboard.press('F6');await p.getByText('Game saved',{exact:true}).waitFor();
    const slots=await p.evaluate(()=>({monsoon:JSON.parse(localStorage.getItem('static-harbor/1/save-monsoon')),outbreak:JSON.parse(localStorage.getItem('static-harbor/1/save-outbreak'))}));
    assert.equal(slots.monsoon.chapter,1);assert.equal(slots.monsoon.car.model,16);assert.equal(slots.outbreak.outbreak.used[0],'shelter');
    await p.reload();await heading(p,'Open Atlas');await choose(p,'Outbreak');await choose(p,'Load Game');await choose(p,'Continue');await heading(p,'Outbreak');
    assert.match(await p.locator('.mission-strip').innerText(),/Restore/);
    console.log('PASS: offline Monsoon opening, atlas tabs, metro travel, drivable tank, survival noise, pickup, and separate checkpoint reload');

    const mobile=await browser.newPage({...devices['iPhone 13'],offline:true});watch(mobile);await mobile.goto(offline);await heading(mobile,'Open Atlas');
    assert.ok(await mobile.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
    await button(mobile,'Outbreak').tap();await heading(mobile,'Outbreak');await button(mobile,'Start Survival').tap();
    await mobile.getByRole('meter',{name:'Noise'}).waitFor();assert.ok(await button(mobile,'Use medkit').isVisible());
    assert.deepEqual(errors,[]);console.log('PASS: mobile mode switch and survival touch HUD, no HTTP or console errors');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});