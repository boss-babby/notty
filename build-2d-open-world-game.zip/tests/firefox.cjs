const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { firefox } = require(process.env.PLAYWRIGHT_PACKAGE || 'playwright');

(async () => {
  const browser = await firefox.launch();
  try {
    const page = await browser.newPage({ viewport: { width: 1152, height: 768 }, offline: true });
    page.setDefaultTimeout(8000);
    const issues = [];
    page.on('pageerror', error => issues.push(error.message));
    page.on('console', msg => { if (msg.type() === 'error') issues.push(msg.text()); });
    page.on('request', r => { if (/^https?:/.test(r.url())) issues.push(r.url()); });
    const title = name => page.getByRole('heading', { name, exact: true }).waitFor();
    const snapshot = async () => {
      await page.keyboard.press('F6'); await page.waitForTimeout(110);
      return page.evaluate(() => JSON.parse(localStorage.getItem('static-harbor/1/save')));
    };

    // Navigate with actual key events. The checkpoint reports position so the test can correct for browser timing.
    const walk = async (axis, goal) => {
      for (let i = 0; i < 4; i++) {
        const gap = goal - (await snapshot())[axis];
        if (Math.abs(gap) < 14) return;
        const key = axis === 'x' ? (gap > 0 ? 'd' : 'a') : (gap > 0 ? 's' : 'w');
        await page.keyboard.down(key); await page.waitForTimeout(Math.max(38, Math.min(2700, Math.abs(gap) / 113 * 1000))); await page.keyboard.up(key);
      }
    };
    await page.goto(pathToFileURL(path.resolve(__dirname, '../index.html')).href);
    await page.getByRole('button',{name:'Vesper Bay',exact:true}).click();
    await page.getByRole('button', { name: 'New Game', exact: true }).click(); await title('Dead Drop');
    // Go around the parked Vanta rather than walking through the vehicle collider.
    await walk('y', 935); await walk('x', 1423); await walk('y', 1117);
    await page.locator('.use-prompt').getByText('Recover the pouch at Rill and Fourth').waitFor(); await page.keyboard.press('e');
    await page.locator('.mission-strip').getByText('Bring the pouch to Inez at The Relay').waitFor();
    // The first objective is in a service lane; rejoin the street before crossing back.
    await walk('y', 965); await walk('x', 1090); await walk('y', 1012);
    await page.locator('.use-prompt').getByText('Bring the pouch to Inez at The Relay').waitFor(); await page.keyboard.press('e');
    await title('Tail Lights');
    const save = await snapshot();
    assert.equal(save.chapter, 1); assert.equal(save.cash, 390); assert.deepEqual(issues, []);
    console.log('PASS: first operation completed offline in Firefox using keyboard play, checkpoint and payout saved, no console or network errors');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });