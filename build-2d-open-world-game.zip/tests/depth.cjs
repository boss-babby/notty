const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium, devices } = require(process.env.PLAYWRIGHT_PACKAGE || 'playwright');

const url = pathToFileURL(path.resolve(__dirname,'../index.html')).href;
const heading = (p,name) => p.getByRole('heading',{name,exact:true}).waitFor();
const button = (p,name) => p.getByRole('button',{name,exact:true});
async function hold(p,key,ms){await p.keyboard.down(key);await p.waitForTimeout(ms);await p.keyboard.up(key);await p.waitForTimeout(130);}

(async()=>{
  const browser=await chromium.launch(), errors=[];
  function watch(p){
    p.on('pageerror',e=>errors.push(e.message));
    p.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
    p.on('request',r=>{if(/^https?:/.test(r.url()))errors.push(r.url());});
  }
  try{
    const p=await browser.newPage({viewport:{width:1440,height:900},offline:true});watch(p);p.setDefaultTimeout(10000);
    await p.goto(url);await heading(p,'Open Atlas');await button(p,'Monsoon Lines').click();await heading(p,'Monsoon Lines');
    await p.getByRole('link',{name:'BUILD 4.0.0'}).click();
    assert.ok(await p.getByRole('heading',{name:'The city after the rain.'}).isVisible());
    await p.getByRole('link',{name:'BACK TO THE TITLE'}).click();
    await button(p,'New Game').click();await heading(p,'Rain Check');
    await p.keyboard.press('e');await p.locator('.mission-strip').getByText('Get the boat roster from the curbside stand').waitFor();
    await hold(p,'a',165);await hold(p,'s',110);
    await p.locator('.use-prompt').getByText('Enter Nodi Cha House',{exact:true}).waitFor();
    await p.keyboard.press('e');await p.locator('.hud-loc strong').filter({hasText:'Nodi Cha House'}).waitFor();await p.waitForTimeout(420);
    await hold(p,'d',530);await hold(p,'w',210);
    const table=p.getByText('Play a carrom table',{exact:true});
    if(!(await table.isVisible()))await hold(p,'d',110);
    if(!(await table.isVisible()))await hold(p,'w',210);
    await table.waitFor();await p.keyboard.press('e');await heading(p,'Carrom Table');
    assert.ok(await p.getByRole('img',{name:'Carrom board'}).isVisible());
    await p.getByRole('slider',{name:'Power',exact:true}).fill('90');
    await button(p,'Shoot').click();assert.ok(await button(p,'Shoot').isDisabled());
    await p.locator('.parlor-heading').getByText('1 / 6',{exact:true}).waitFor();
    await p.keyboard.press('Escape');await p.keyboard.press('Escape');await heading(p,'Paused');
    await button(p,'Career stats').click();assert.ok(await p.getByText('Long Stride',{exact:true}).isVisible());await p.keyboard.press('Escape');
    await p.keyboard.press('Escape');await button(p,'Debug & cheats').click();await p.getByLabel('Teleport location').selectOption('swapmeet');await button(p,'Teleport').click();
    await p.keyboard.press('e');await p.locator('.hud-loc strong').filter({hasText:'Lantern Exchange'}).waitFor();await p.waitForTimeout(405);
    await hold(p,'w',1040);await p.getByText('Use counter',{exact:true}).waitFor();await p.keyboard.press('e');await heading(p,'Lantern Exchange');
    const row=p.locator('.terminal-row').filter({hasText:'Salvage coils'});await row.getByRole('button',{name:/BUY/}).click();await row.getByText('1 in your cargo / capacity 12').waitFor();
    await row.getByRole('button',{name:/SELL/}).click();await row.getByText('0 in your cargo / capacity 12').waitFor();
    console.log('PASS: title field notes, walkable tea house, carrom controls, field abilities, and trading venue');

    const mobile=await browser.newPage({...devices['iPhone 13'],offline:true});watch(mobile);mobile.setDefaultTimeout(10000);
    await mobile.goto(url);await heading(mobile,'Open Atlas');await button(mobile,'Outbreak').tap();await button(mobile,'Start Survival').tap();
    await mobile.getByRole('meter',{name:'Noise'}).waitFor();
    assert.ok(await button(mobile,'Throw a noisemaker').isVisible());assert.ok(await button(mobile,'Place a barricade').isVisible());
    await mobile.keyboard.press('v');await mobile.getByText('Camera view',{exact:true}).waitFor();
    assert.ok(await mobile.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
    assert.deepEqual(errors,[]);
    console.log('PASS: Outbreak gear and camera on mobile, no HTTP requests or browser errors');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});