const assert=require('node:assert/strict');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium,devices}=require(process.env.PLAYWRIGHT_PACKAGE||'playwright');
const url=pathToFileURL(path.resolve(__dirname,'../index.html')).href;
const button=(p,n)=>p.getByRole('button',{name:n,exact:true});
const heading=(p,n)=>p.getByRole('heading',{name:n,exact:true}).waitFor();

(async()=>{
  const b=await chromium.launch(), faults=[];
  const watch=p=>{p.on('pageerror',e=>faults.push(e.message));p.on('console',m=>{if(m.type()==='error')faults.push(m.text());});p.on('request',r=>{if(/^https?:/.test(r.url()))faults.push(r.url());});};
  const hold=async(p,key,t)=>{await p.keyboard.down(key);await p.waitForTimeout(t);await p.keyboard.up(key);await p.waitForTimeout(110);};
  const go=async(p,id)=>{await button(p,'Pause game').click();await button(p,'Debug & cheats').click();await p.getByLabel('Teleport location').selectOption(id);await button(p,'Teleport').click();};
  const venue=async(p,id,name)=>{await go(p,id);await p.keyboard.press('e');await p.locator('.hud-loc strong').getByText(name,{exact:true}).waitFor();await p.waitForTimeout(690);};
  try{
    const p=await b.newPage({viewport:{width:1440,height:900},offline:true});p.setDefaultTimeout(10000);watch(p);
    await p.goto(url);await heading(p,'Open Atlas');
    const canvas=p.locator('.harbor-vista');
    const coastImage=await canvas.evaluate(c=>c.toDataURL());
    await p.getByRole('group',{name:'Preview city'}).getByRole('button',{name:/Neon Basin/}).click();
    await p.waitForTimeout(280);assert.notEqual(await canvas.evaluate(c=>c.toDataURL()),coastImage);
    await button(p,'Explore the Atlas').click();await heading(p,'Chart a New World');
    await p.getByRole('group',{name:'Starting city'}).getByRole('button',{name:/Mirage Coast/}).click();
    await p.getByLabel('Frontier style').selectOption('islands');await p.getByLabel('World key').fill('Amber Atlas');
    await button(p,'Start Exploring').click();await heading(p,'Mirage Coast');
    await p.keyboard.press('m');await heading(p,'City Map');await button(p,'World').click();await button(p,'Frontier').click();
    assert.ok(await p.getByText(/cells charted/).isVisible());await button(p,'East').click();await button(p,'Center').click();
    assert.ok(await button(p,'Neon Basin').isVisible());await p.keyboard.press('Escape');
    await p.keyboard.press('Tab');await heading(p,'Pocket Relay');assert.ok(await p.getByText('Marina Manifest',{exact:true}).isVisible());await p.keyboard.press('Escape');
    await venue(p,'air-mirage','Windglass International');await hold(p,'w',1270);
    await p.getByText('Use counter',{exact:true}).waitFor();await p.keyboard.press('e');await heading(p,'Air Departures');
    await p.locator('.departures .terminal-row').filter({hasText:'Basin Regional Airport'}).getByRole('button',{name:'Travel / $26'}).click();
    await heading(p,'Neon Basin');await p.getByText('Arrival',{exact:true}).waitFor();
    await venue(p,'jacklight','Jacklight Resort');await hold(p,'w',1240);await p.keyboard.press('e');await heading(p,'Jacklight Score Table');
    await button(p,'Spin').click();assert.match(await p.getByLabel('Reel result').innerText(),/[1-9]/);await p.keyboard.press('Escape');
    await venue(p,'marina','Crescent Sea Terminal');await hold(p,'w',1240);await p.keyboard.press('e');await heading(p,'Sea Departures');
    await p.locator('.departures .terminal-row').filter({hasText:'Shapla Ghat'}).getByRole('button',{name:'Travel / $12'}).click();
    await heading(p,'Monsoon City');
    await p.keyboard.press('F6');await p.getByText('Game saved',{exact:true}).waitFor();
    const save=await p.evaluate(()=>JSON.parse(localStorage.getItem('static-harbor/1/save-atlas')));
    assert.equal(save.worldKey,'Amber Atlas');assert.equal(save.style,'islands');assert.ok(save.discovered.includes('basin-air')&&save.discovered.includes('ghat'));
    await p.reload();await heading(p,'Open Atlas');await button(p,'Load Game').click();await p.getByText('Open Atlas Expedition',{exact:true}).waitFor();await button(p,'Continue').click();await heading(p,'Monsoon City');
    console.log('PASS: distinct city previews, seed/style selection, frontier chart, regional jobs, air and sea transit, venue and save reload');

    const mobile=await b.newPage({...devices['iPhone 13'],offline:true});watch(mobile);
    await mobile.goto(url);await heading(mobile,'Open Atlas');await button(mobile,'Explore the Atlas').tap();await heading(mobile,'Chart a New World');
    await mobile.getByRole('group',{name:'Starting city'}).getByRole('button',{name:/Neon Basin/}).tap();
    await button(mobile,'Start Exploring').tap();await heading(mobile,'Neon Basin');assert.ok(await button(mobile,'Move right').isVisible());
    assert.ok(await mobile.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));assert.deepEqual(faults,[]);
    console.log('PASS: mobile Atlas start, touch controls, no HTTP requests or console errors');
  }finally{await b.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});