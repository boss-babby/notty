const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium, devices } = require(process.env.PLAYWRIGHT_PACKAGE || 'playwright');

const url = pathToFileURL(path.resolve(__dirname, '../index.html')).href;
const button = (page, name) => page.getByRole('button', { name, exact: true });
const press = (page, key) => page.keyboard.press(key);
async function heading(page, name) { await page.getByRole('heading', { name, exact: true }).waitFor({ state: 'visible' }); }
async function hold(page, key, ms) { await page.keyboard.down(key); await page.waitForTimeout(ms); await page.keyboard.up(key); }

(async () => {
  const browser = await chromium.launch();
  const problems = [];
  const watch = page => {
    page.on('pageerror', err => problems.push(err.message));
    page.on('console', message => { if (message.type() === 'error') problems.push(message.text()); });
    page.on('request', request => { if (/^https?:/.test(request.url())) problems.push(`Network request: ${request.url()}`); });
  };
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 }, offline: true, acceptDownloads: true });
    page.setDefaultTimeout(8000); watch(page);
    await page.addInitScript(() => {
      const Native = window.AudioContext;
      window.testSound = [];
      if (Native) window.AudioContext = class extends Native { constructor(...args) { super(...args); window.testSound.push(this); } };
    });
    await page.goto(url);
    await heading(page,'Open Atlas');await button(page,'Vesper Bay').click();
    await heading(page, 'Static Harbor');
    assert.ok(page.url().endsWith('/play/index.html'));
    await button(page, 'Load Game').click(); await heading(page, 'Load Game');
    assert.equal(await page.getByText('No checkpoint found').count(), 1); await press(page, 'Escape');
    await button(page, 'Field Guide').click(); await button(page, 'Controls').click();
    assert.ok(await page.getByRole('table').isVisible()); await button(page, 'Districts').click();
    assert.ok(await page.getByText('Iron Docks', { exact: true }).isVisible()); await press(page, 'Escape');
    await button(page, 'Settings').click(); await heading(page, 'Settings');
    await page.getByLabel('Graphics quality', { exact: true }).selectOption('Medium');
    await button(page, 'Audio').click(); await page.getByRole('slider', { name: 'music volume' }).fill('35');
    await button(page, 'Bindings').click(); await button(page, 'Rebind Interact / Enter or exit').click(); await press(page, 'g');
    await press(page, 'Escape');
    await button(page, 'New Game').click(); await heading(page, 'Dead Drop');
    assert.ok(await page.evaluate(() => window.testSound.some(c => c.state === 'running')), 'Web Audio unlocked after a control click');
    await hold(page, 'd', 350); await page.getByText('Enter Vanta GT', { exact: true }).waitFor(); await press(page, 'g');
    await page.getByText('Vanta GT', { exact: true }).waitFor(); await hold(page, 'w', 570); await press(page, 'F6');
    await page.getByText('Game saved', { exact: true }).waitFor();
    const save = await page.evaluate(() => JSON.parse(localStorage.getItem('static-harbor/1/save')));
    assert.ok(save.car.inCar && save.car.x > 1210);

    await press(page, 'm'); await heading(page, 'City Map');
    await page.getByLabel('Pin discovered location').selectOption('relay');
    assert.ok(await button(page, 'Clear pin').isEnabled()); await button(page, 'Clear pin').click(); await press(page, 'Escape');
    await press(page, 'Tab'); await heading(page, 'Pocket Relay'); await button(page, 'The Wire').click();
    assert.ok(await page.getByText('LIVE DISPATCH', { exact: false }).isVisible());
    await button(page, 'Contacts').click(); await page.getByRole('button', { name: /Inez Sable/ }).click();
    assert.ok(await page.getByText('I left you a car. Make it back in one piece.').isVisible());
    await button(page, 'Radio').click(); await button(page, 'Next frequency').click();
    assert.ok(await page.getByText('ON AIR', { exact: true }).isVisible()); await press(page, 'Escape');

    await press(page, 'Escape'); await heading(page, 'Paused'); await button(page, 'Debug & cheats').click();
    await heading(page, 'Debug & Cheats'); await button(page, 'Add $1,000').click();
    await page.getByLabel('Weather', { exact: true }).selectOption('Storm'); await page.getByLabel('Wanted level', { exact: true }).selectOption('5');
    await page.getByRole('slider', { name: 'City hour' }).fill('13');
    await button(page, 'Spawn').click(); await button(page, 'Unlock arsenal').click();
    assert.ok(await page.getByText('$1,240 / 100% vitality', { exact: true }).isVisible());
    await page.getByLabel('Wanted level', { exact: true }).selectOption('0');
    await page.getByLabel('Teleport location').selectOption('relay'); await button(page, 'Teleport').click();
    await press(page, 'g'); await page.getByText('Enter The Relay', { exact: true }).waitFor(); await press(page, 'g');
    await page.locator('.hud-loc strong').filter({ hasText: 'The Relay' }).waitFor();
    await page.waitForTimeout(370); await hold(page, 'w', 1100); await page.getByText('Customize Mara', { exact: true }).waitFor(); await press(page, 'g');
    await heading(page, 'Safehouse Wardrobe'); await button(page, 'Jacket color 2').click(); await button(page, 'Crest').click(); await press(page, 'Escape');
    await press(page, 'q'); await heading(page, 'Weapon Wheel'); await button(page, 'Kite Rifle').click();
    assert.ok(await page.getByText('Kite Rifle', { exact: true }).isVisible());

    await press(page, 'Escape'); await button(page, 'Photo mode').click();
    const image = page.waitForEvent('download'); await button(page, 'Capture PNG').click();
    assert.equal((await image).suggestedFilename(), 'static-harbor.png'); await button(page, 'Exit photo mode').click();
    await press(page, 'Escape'); await button(page, 'Career stats').click(); await heading(page, 'Career Stats'); await press(page, 'Escape');
    await press(page, 'Escape'); await button(page, 'Return to title').click(); await button(page, 'Save and exit').click();
    await heading(page, 'Static Harbor'); await button(page, 'Load Game').click(); await button(page, 'Continue').click(); await heading(page, 'Dead Drop');
    assert.equal(await page.locator('.wallet > span').textContent(), '$1,240');
    console.log('PASS: offline desktop launch, no network, audio unlock, controls, map, phone, debug, interior, wardrobe, weapon wheel, photo, save and load');

    const mobile = await browser.newPage({ ...devices['iPhone 13'], offline: true });
    mobile.setDefaultTimeout(8000);watch(mobile);await mobile.goto(url);await heading(mobile,'Open Atlas');await button(mobile,'Vesper Bay').tap();await heading(mobile,'Static Harbor');
    assert.ok(await mobile.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    await button(mobile, 'New Game').tap(); await heading(mobile, 'Dead Drop');
    assert.ok(await button(mobile, 'Move right').isVisible());
    const dpad = await button(mobile, 'Move right').boundingBox();
    const cd = await mobile.context().newCDPSession(mobile);
    await cd.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: dpad.x + 12, y: dpad.y + 12 }] });
    await mobile.waitForTimeout(350); await cd.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    await mobile.getByText('Enter Vanta GT', { exact: true }).waitFor(); await button(mobile, 'Interact').tap();
    await mobile.getByText('Vanta GT', { exact: true }).waitFor();
    console.log('PASS: mobile viewport, touch movement and vehicle interaction');
    assert.deepEqual(problems, [], 'No JavaScript, console, or external network errors');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });