# Static Harbor: The Contact Update

## Phase 0: Design

The goal is readable weight, not a real-world weapons simulator. All handling values, ammunition, animations, and effects are invented for this game. The update keeps the two city campaigns, Outbreak, and the three original save slots. Training Bay is a fourth launch option with a dedicated, isolated score board.

**Loop:** Settle into a stance, commit to an action, see and hear what it touches, then use the recovery window to move, reload, or guard. There is a difference between a miss, a stopped round, a cracked pane, and a clean hit. All of those outcomes have visible and audible feedback.

**Three signatures:** Contact materials (dust, spark, break, and cover), committed movements (guard, windup, swing, recovery, and load), and a practice room that uses the exact same simulation as the city without changing the city saves.

```text
Input + player movement -> combat action clock -> swept collision
                                  |                    |
                            aim / swing / load    hit / block / break
                                  +--------+-----------+
                                           |
                             Canvas, Web Audio, HUD, drill scores
```

## Implementation Phases

1. Preserve the fixed-step game engine and file-based release; migrate old ammunition data without discarding progress.
2. Add procedural breakable window panes to the streamed city without changing the seeded street layout.
3. Add weighted movement, committed melee, cover, recoil recovery, and different reload actions to the existing eleven fictional weapons.
4. Add visible enemy shot windups and close combat reactions; keep existing patrol and Outbreak pathfinding.
5. Supply three drills and a persistent phone inbox. Preserve both campaigns and side activities.
6. Update HUD, animations, directional hits, sound and room reflections. Leave motion and intensity settings under the player's control.
7. Test game actions in the simulation, run offline browser checks, and regenerate the single-file release.