export function WorldGuide(){
  return <section className="world-guide" id="world-notes" aria-labelledby="world-notes-heading">
    <div className="guide-editorial">
      <div className="guide-index"><i/> FIELD NOTES <span>02.5 / THE LIVING CITY</span></div>
      <h2 id="world-notes-heading">The city after<br/><em>the rain.</em></h2>
      <p>There is more to Vesper Bay and Monsoon City than the next marker. Head inside, pick up a shift, or see how long the streets stay quiet.</p>
      <a href="#title" className="guide-back">BACK TO THE TITLE <span aria-hidden="true">^</span></a>
    </div>
    <div className="guide-atlas" aria-label="Illustrated locator map showing Vesper Bay and Monsoon City">
      <div className="guide-map-title"><span>01 / CITY ATLAS</span><span>DO NOT USE FOR NAVIGATION</span></div>
      <svg viewBox="0 0 600 300" role="img" aria-label="Vesper Bay, Silt Strait, Monsoon City and the southern river">
        <defs>
          <pattern id="field-grid" width="18" height="18" patternUnits="userSpaceOnUse"><path d="M18 0H0v18" fill="none" stroke="#6c59753d" strokeWidth="1"/></pattern>
          <pattern id="land-grid" width="21" height="21" patternUnits="userSpaceOnUse"><path d="M21 0H0v21" fill="none" stroke="#bd9b8851" strokeWidth="1"/></pattern>
          <pattern id="blue-grid" width="18" height="19" patternUnits="userSpaceOnUse"><path d="M18 0H0v19" fill="none" stroke="#9e93874d" strokeWidth="1"/></pattern>
          <linearGradient id="atlantic" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#191829"/><stop offset="1" stopColor="#2d283c"/></linearGradient>
        </defs>
        <rect width="600" height="300" fill="url(#atlantic)"/><rect width="600" height="300" fill="url(#field-grid)"/>
        <path d="M22 31h187l16 21-5 50 20 24-5 39 11 13-14 40 8 47H22z" fill="#47384c" stroke="#916a80"/>
        <path d="M22 31h187l16 21-5 50 20 24-5 39 11 13-14 40 8 47H22z" fill="url(#land-grid)"/>
        <path d="M310 28h263v249H308l12-27-19-20 6-25-16-20 9-37-13-39 16-29-7-26z" fill="#584946" stroke="#a48076"/>
        <path d="M310 28h263v249H308l12-27-19-20 6-25-16-20 9-37-13-39 16-29-7-26z" fill="url(#blue-grid)"/>
        <path d="M309 223c48-36 54 6 113 9s68-51 151-45" fill="none" stroke="#354d5f" strokeWidth="15"/>
        <path d="M309 223c48-36 54 6 113 9s68-51 151-45" fill="none" stroke="#8c9ba364" strokeWidth="1"/>
        <path d="M406 96c14 7 1 14 25 13s28 7 38 10 21-3 30 5" fill="none" stroke="#57737a" strokeWidth="10"/>
        <path d="M217 76h81m-60 62h58m-52 58h57" stroke="#d5a186" strokeWidth="3.3" opacity=".84"/>
        <path d="M402 52v80l-33 30v35M405 52v80l-33 30v35" stroke="#91c9b8" strokeWidth="1.1" opacity=".83" fill="none"/>
        <path d="M165 32v213m-118-60h190m111-151v247m128-251v249m-173-123h269" stroke="#a599a3" strokeWidth="1.3" opacity=".55"/>
        <g fontFamily="monospace" fontSize="11" fontWeight="700" letterSpacing="1.7">
          <text x="58" y="99" fill="#efb3c5">VESPER BAY</text><text x="386" y="63" fill="#f0c19c">MONSOON CITY</text>
          <text x="404" y="168" fill="#f4ccaf">PURAN BAZAAR</text><text x="439" y="260" fill="#c2d4ab">CHAR GARDENS</text>
          <text x="171" y="273" fill="#a398b0" fontSize="8">STRAIT / 03 CAUSEWAYS</text>
          <text x="552" y="20" fill="#dac6c3" fontSize="9">N</text>
        </g>
        <path d="M562 11v15m-4-11 4-4 4 4" stroke="#e8b394" fill="none"/>
        {[[82,125],[177,213],[395,155],[434,112],[475,222]].map(([x,y],i)=><g key={x}><circle cx={x} cy={y} r="8" fill="none" stroke={i>1?'#f0bb8e':'#e590b0'} opacity=".74"/><circle cx={x} cy={y} r="2.8" fill={i>1?'#f0bb8e':'#e590b0'}/></g>)}
      </svg>
      <div className="guide-map-foot"><i/> ORIGINAL CARTOGRAPHY <span>2 REGIONS / 13 DISTRICTS</span></div>
    </div>
    <div className="guide-rows">
      <div><span>01 / PURSUIT</span><strong>Different drivers. Different orders.</strong><p>One lead cruiser, separate intercepts, real spacing, and a search that stays at the last sighting.</p></div>
      <div><span>02 / OUTBREAK</span><strong>Noise travels. The Quiet follow it.</strong><p>Distract them with a decoy, put up a barricade, and watch for a committed lunge.</p></div>
      <div><span>03 / AFTER HOURS</span><strong>Places worth stopping for.</strong><p>Play carrom at Nodi Cha, tune a dyno, fly a survey, or catch a shift at Megh Terminal.</p></div>
    </div>
  </section>;
}