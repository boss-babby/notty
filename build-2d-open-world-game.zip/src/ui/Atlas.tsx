import { useEffect, useRef, useState } from 'react';
import { ATLAS_STARTS, VENUE_CAST, WORLD_STYLES } from '../game/atlas-data.js';
import { destinations } from '../game/atlas-runtime.js';
import { Icon } from './icons';
import { mountAtlasVista } from '../game/atlas-vista.js';
import type { AtlasSetup, GameAPI, Snapshot } from './types';

export function AtlasConfigurator({start,change,launch,hasSave}:{start:string;change:(s:string)=>void;launch:(s:AtlasSetup)=>void;hasSave:boolean}){
  const [key,setKey]=useState(''),[style,setStyle]=useState('continental');
  return <form className="atlas-form" onSubmit={e=>{e.preventDefault();launch({key,style,start});}}>
    <div className="atlas-choice-label">01 <span>Starting City</span></div>
    <div className="atlas-starts" role="group" aria-label="Starting city">
      {(ATLAS_STARTS as {id:string;name:string;copy:string}[]).map(p=><button type="button" key={p.id} className="atlas-start" aria-pressed={start===p.id} onClick={()=>change(p.id)}><Icon name={p.id==='mirage'?'rain':'dash'}/><strong>{p.name}</strong><small>{p.copy}</small></button>)}
    </div>
    <label className="atlas-rule"><span><i>02</i> Frontier style</span><select aria-label="Frontier style" value={style} onChange={e=>setStyle(e.target.value)}>{(WORLD_STYLES as {id:string;name:string}[]).map(s=><option value={s.id} key={s.id}>{s.name}</option>)}</select></label>
    <p className="small-note atlas-style-note">{WORLD_STYLES.find((s:{id:string})=>s.id===style)?.blurb}</p>
    <label className="atlas-rule"><span><i>03</i> World key</span><input aria-label="World key" placeholder="Default atlas" value={key} maxLength={32} onChange={e=>setKey(e.target.value)}/></label>
    <p className="small-note">Same key and style, same geography. {hasSave?'Starting replaces only the Open Atlas checkpoint.':'Your campaign and survival saves are separate.'}</p>
    <button className="action-button is-primary" type="submit"><Icon name="play"/><span>Start Exploring</span></button>
  </form>;
}

type Site={id:string;name:string;region:string;cost:number;distance:number};
export function Panorama({s}:{s:Snapshot}){
  const canvas=useRef<HTMLCanvasElement>(null),basin=s.region==='basin';
  useEffect(()=>{if(canvas.current)return mountAtlasVista(canvas.current,false,basin);},[basin]);
  return <div className="sky-gallery"><canvas ref={canvas} aria-label={basin?'Procedural panorama of the Neon Basin resort strip':'Procedural panorama of Mirage Coast and its skyline'}/><p className="small-note">{basin?'The strip gives way to service roads and the dry wash.':'Meridian Spire overlooks the souk, the crescent, and the public ferry lanes.'}</p></div>;
}
export function Departures({s,game,air}:{s:Snapshot;game:GameAPI;air:boolean}){
  const list=destinations(air?'air':'sea',s.room) as Site[];
  return <div className="departures">
    <p className="terminal-lead">{air?'Regional flights':'Public ferry routes'}</p>
    <p className="small-note">{s.heat?'Travel is temporarily unavailable during an alert.':'Tickets are paid in game credits. A parked vehicle stays behind.'}</p>
    {list.map(route=><div className="terminal-row" key={route.id}><Icon name={air?'dash':'pin'}/><div><strong>{route.name}</strong><small>{route.region} / {(route.distance/1000).toFixed(1)} km</small></div><button type="button" className="line-button" disabled={s.cash<route.cost||s.heat>0} onClick={()=>game.action(air?'fare-air':'fare-sea',route.id)}>Travel / ${route.cost}</button></div>)}
    {s.note&&<p className="small-note" role="status">{s.note.message}</p>}
  </div>;
}

export function ClubDesk({s,game}:{s:Snapshot;game:GameAPI}){
  const hosts=VENUE_CAST[s.room||''] as {name:string;role:string;line:string}[]||[];
  const [active,setActive]=useState(-1);
  return <div className="club-desk"><p className="terminal-lead">Meet the people working the late shift.</p>{hosts.map((c,i)=><div key={c.name} className="terminal-row"><div><strong>{c.name}</strong><small>{c.role}</small>{active===i&&<p className="contact-message">{c.line}</p>}</div><button className="line-button" type="button" aria-expanded={active===i} onClick={()=>{setActive(active===i?-1:i);if(active!==i)game.action('club-talk',i);}}>Talk</button></div>)}</div>;
}

export function Jacklight({s,game}:{s:Snapshot;game:GameAPI}){
  const results=s.tableRoll;
  return <div className="jacklight"><p className="terminal-lead">Match three reels for a score bonus.</p><p className="small-note">Free to play. New qualifying records earn fictional city credits. No wagers.</p>
    <div className="jack-reels" aria-label="Reel result">{(results?.numbers||[0,0,0]).map((n,i)=><span key={i}>{n||'0'}</span>)}</div>
    <div className="parlor-result"><span>SCORE <b>{results?.score||0}</b></span><span>BEST <b>{s.records.jacklight?.best||0}</b></span></div>
    <button className="action-button is-primary" type="button" onClick={()=>game.action('jacklight')}><Icon name="play"/><span>Spin</span></button>
  </div>;
}