import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import type { KeyboardEvent as ReactKeyEvent, ReactNode } from 'react';
import { campaignFor, CONTROLS, DISTRICTS, GARAGE, GARAGE_PAINT, GEAR, HOLDINGS, JOBS, MODES, PLACES, STATIONS, WARDROBE, WEATHER } from '../game/data.js';
import { keyName } from '../game/core.js';
import { fullMap } from '../game/maps.js';
import { BrandMark, Icon } from './icons';
import { ActivityBody, RecordBook } from './Activity';
import { TABLES } from '../game/parlor.js';
import { DrillBrief, DrillResults } from './Drills';
import { HANDLING } from '../game/contact-data.js';
import { EVENT_OPTIONS } from '../game/street-events.js';
import { ClubDesk, Departures, Jacklight, Panorama } from './Atlas';
import type { District, GameAPI, GameMode, Gear, Job, Place, RecordData, Settings, Snapshot, Vehicle } from './types';

export const currency = (n: number) => `$${Math.round(n).toLocaleString('en-US')}`;
const FOCUS = 'button:not(:disabled), select:not(:disabled), input:not(:disabled), [tabindex="0"]';

export function Action({ children, onClick, icon, primary = false, className = '', disabled = false }: { children: ReactNode; onClick: () => void; icon?: string; primary?: boolean; className?: string; disabled?: boolean }) {
  return <button type="button" className={`action-button ${primary ? 'is-primary' : 'is-secondary'} ${className}`} onClick={onClick} disabled={disabled}>{icon && <Icon name={icon}/>}<span>{children}</span></button>;
}

export function Modal({ title, tag = 'FIELD TERMINAL', children, onClose, wide = false, dismissible=true }: { title: string; tag?: string; children: ReactNode; onClose: () => void; wide?: boolean;dismissible?:boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const prior = document.activeElement;
    const frame = requestAnimationFrame(() => (ref.current?.querySelector<HTMLElement>('[data-default]') || ref.current)?.focus({ preventScroll: true }));
    return () => { cancelAnimationFrame(frame); if (prior instanceof HTMLElement && prior.isConnected) prior.focus({ preventScroll: true }); };
  }, []);
  const key = (e: ReactKeyEvent) => {
    if (e.key !== 'Tab') return;
    const items = Array.from(ref.current?.querySelectorAll<HTMLElement>(FOCUS) || []).filter(node => node.getClientRects().length);
    const at = items.indexOf(document.activeElement as HTMLElement);
    if (!items.length) return;
    if (e.shiftKey && at <= 0) { e.preventDefault(); items.at(-1)?.focus(); }
    else if (!e.shiftKey && (at >= items.length - 1 || at < 0)) { e.preventDefault(); items[0].focus(); }
  };
  return <div className="modal-layer" onPointerDown={event => { if (dismissible&&event.target === event.currentTarget) onClose(); }}>
    <section ref={ref} className={`terminal-modal ${wide ? 'terminal-wide' : ''}`} role="dialog" aria-modal="true" aria-labelledby="terminal-heading" tabIndex={-1} onKeyDown={key}>
      <header className="terminal-header">
        <div><div className="mono terminal-tag"><i/> {tag}</div><h2 id="terminal-heading">{title}</h2></div>
        {dismissible&&<button type="button" className="terminal-close" aria-label="Close" onClick={onClose}><Icon name="close"/></button>}
      </header>
      <div className="terminal-body">{children}</div>
    </section>
  </div>;
}

function Tabs({ labels, value, change }: { labels: string[]; value: number; change: (n: number) => void }) {
  return <div className="tabs" aria-label="Sections">{labels.map((label, i) => <button type="button" key={label} onClick={() => change(i)} aria-pressed={i === value} className={i === value ? 'selected' : ''}>{label}</button>)}</div>;
}

const controlRows = [
  ['Move / steer', 'W A S D', 'Left stick'], ['Aim / fire', 'Mouse / LMB', 'Right stick / RT'], ['Interact / enter vehicle', 'E', 'A'],
  ['Sprint', 'SHIFT', 'LB'], ['Roll / handbrake', 'SPACE', 'B / hold B'], ['Sneak / cover near wall', 'CTRL', 'RB'],
  ['Reload', 'R', 'X'], ['Weapon wheel', 'Q', 'Y'], ['Map / phone', 'M / TAB', 'View / D-pad up'], ['Radio / horn or siren', 'C / H', 'D-pad down / keyboard only'],
  ['Medkit / pause', 'F / ESC', 'D-pad right / Start'], ['Quick save / debug', 'F6 / F3', 'Pause menu'],
  ['Street camera / noisemaker', 'V / G','Right stick click / D-pad left'],
  ['Outbreak barricade', 'B','HUD button'],
  ['Brace / guard, then attack', 'X / RMB','LT'],['Slow walk','Z','Partial left stick'],
  ['Headlights','L','Keyboard'],
];

export function Guide({ close, play, mode='campaign' }: { close: () => void; play?: () => void; mode?: GameMode }) {
  const [tab, setTab] = useState(0);
  const descriptions=['Relay safehouse, markets, and the corporate core.','Warehouses and freight piers. Watch the crossings.','Residential hills, parks, and Morrow Loft.','Boardwalk speed traps and a quiet arcade.','The broadcasting towers and North Exchange.','Tidal flats and three roads between the cities.','Residential lanes, schools and sports courts.','Megh bus stands and workshops.','Retention lakes, bridge gates and a promenade.','Office towers and the metro spine.','Rickshaw art, tea sellers and narrow market lanes.','Gardens, river landings and the cooperative.','Tin mills, clinic traffic and the tracked works rig.'];
  return <Modal title="Field Guide" tag={`${MODES[mode].name.toUpperCase()} / FIELD MANUAL`} onClose={close}>
    <Tabs labels={['Start here','Controls','Districts']} value={tab} change={setTab}/>
    {tab === 0 && <div className="guide-intro">
      <p className="terminal-lead">{mode==='practice'?'Find your timing in the bay.':mode==='outbreak'?'Get the lights back. Get to the water.':mode==='monsoon'?'Every neighborhood has a route.':'A courier on the wrong frequency.'}</p>
      <p>{mode==='practice'?'The three drills share the same movement, materials, and handling as the city. Aim at plates, test glass and cover, or spar with the training partners.':mode==='outbreak'?'Open the first cache, restore three beacons in any order, and signal the ferry. Move quietly to avoid drawing a crowd.':mode==='monsoon'?'Meet Samira at Nodi Cha House. The amber diamond leads to local jobs. The metro, canals, and three causeways all take different routes.':'You are Mara Venn. Follow Inez Sable\'s first lead, pick up the Vanta, and see what is waiting under the streetlight. The pink diamond marks your next objective.'}</p>
      <ol className="brief-list"><li><span>01</span> {mode==='practice'?'Tap single-action equipment; hold automatic gear.':mode==='outbreak'?'Check the atlas for supply caches.':'Follow the operation tracker.'}</li><li><span>02</span> {mode==='practice'?'Hold X or right mouse to brace or guard.':mode==='outbreak'?'Sneak or use melee to keep your noise down.':'Pull over, approach a door, and interact to enter.'}</li><li><span>03</span> {mode==='practice'?'Open the drill console with Tab to try another lane.':mode==='outbreak'?'Leave on the ferry or continue the survival run.':mode==='monsoon'?'Take the metro from a station counter for $8.':'Lose line of sight to make the grid start searching.'}</li></ol>
      {play && <Action primary icon="play" onClick={play}>{mode==='outbreak'?'Start Survival':mode==='practice'?'Enter the Bay':'New game'}</Action>}
    </div>}
    {tab === 1 && <div className="control-grid" role="table" aria-label="Default controls">
      <div role="row" className="table-head"><span role="columnheader">Action</span><span role="columnheader">Keyboard</span><span role="columnheader">Gamepad</span></div>
      {controlRows.map(([name, keyboard, pad]) => <div role="row" key={name}><span role="cell">{name}</span><span role="cell"><kbd>{keyboard}</kbd></span><span role="cell">{pad}</span></div>)}
    </div>}
    {tab===2&&<div className="terminal-list">{(DISTRICTS as District[]).map((d,i)=><div className="terminal-row" key={d.code}><span className="district-index" style={{color:d.color}}>{d.code}</span><div><strong>{d.name}</strong><small>{descriptions[i]||d.faction}</small></div></div>)}</div>}
  </Modal>;
}

export function Options({ value, change, close }: { value: Settings; change: (s: Settings) => void; close: () => void }) {
  const [tab, setTab] = useState(0), [waiting, setWaiting] = useState<string | null>(null);
  const patch = (partial: Partial<Settings>) => change({ ...value, ...partial });
  useEffect(() => {
    if (!waiting) return;
    const take = (e: KeyboardEvent) => {
      e.preventDefault(); e.stopImmediatePropagation();
      if (e.code !== 'Escape' && !['MetaLeft','MetaRight','AltLeft','AltRight'].includes(e.code)) {
        const used = Object.keys(CONTROLS).find(k => k !== waiting && (value.bindings[k] || CONTROLS[k][0]) === e.code);
        const next = { ...value.bindings, [waiting]: e.code };
        if (used) next[used] = value.bindings[waiting] || CONTROLS[waiting][0];
        change({ ...value, bindings: next });
      }
      setWaiting(null);
    };
    window.addEventListener('keydown', take, true);
    return () => window.removeEventListener('keydown', take, true);
  }, [waiting, change, value]);
  const toggles: [keyof Settings, string, string][] = [
    ['shake','Screen shake','Impacts and hard landings shift the camera.'], ['motion','Motion and lightning','Cinematic pans, title motion, and storm flashes.'],
    ['crt','CRT filter','Draw screen lines over the game and title.'], ['contrast','High-contrast signals','Gold objectives and more legible alert colors.'], ['touch','Touch controls','Show an on-screen directional pad and actions.'],
  ];
  const combat: [keyof Settings,string,string][]=[['autoTap','Hold-to-fire assist','Allows holding fire for single-action equipment. Automatic gear is unchanged.'],['autoReload','Auto-reload empty equipment','Start loading automatically after an empty trigger pull.'],['assist','Gamepad and touch aim assist','Helps aim toward visible nearby targets, not through cover.'],['flashes','Full flash effects','Disable bright muzzle flashes and storm flashes.'],['impactTint','Blood-tinted hit effects','Disable the red pixel flecks on character impacts.']];
  return <Modal title="Settings" tag="CONTROL PANEL / LOCAL" onClose={close}>
    <Tabs labels={['Display','Audio','Bindings','Combat']} value={tab} change={n => { setWaiting(null); setTab(n); }}/>
    {tab === 0 && <div className="terminal-list options-list">
      <label className="terminal-row"><div><strong>Graphics quality</strong><small>Canvas detail, actor count, and weather density.</small></div><select aria-label="Graphics quality" value={value.quality} onChange={e => patch({ quality: e.target.value })}>{['Low','Medium','High'].map(x => <option key={x}>{x}</option>)}</select></label>
      {toggles.map(([id, title, description]) => <label className="terminal-row" key={id}><div><strong>{title}</strong><small>{description}</small></div><input type="checkbox" role="switch" checked={Boolean(value[id])} onChange={e => patch({ [id]: e.target.checked })}/></label>)}
    </div>}
    {tab === 1 && <div className="terminal-list options-list">
      {(['master','music','sfx'] as const).map(id => <label className="terminal-row range-row" key={id}><div><strong>{id === 'sfx' ? 'Sound effects' : `${id[0].toUpperCase()}${id.slice(1)} volume`}</strong><small>{id === 'master' ? 'All synthesized signals.' : id === 'music' ? 'Radio stations and score.' : 'World ambience and feedback.'}</small></div><input type="range" min="0" max="100" aria-label={`${id} volume`} value={Math.round(value[id] * 100)} onChange={e => patch({ [id]: Number(e.target.value) / 100 })}/><output>{Math.round(value[id] * 100)}%</output></label>)}
      <label className="terminal-row"><div><strong>Mute all audio</strong><small>Preserve individual mixer levels.</small></div><input type="checkbox" role="switch" checked={value.muted} onChange={e => patch({ muted: e.target.checked })}/></label>
    </div>}
    {tab === 2 && <><p className="small-note">Choose a binding, then press a key. Escape cancels. Shared keys swap.</p><div className="terminal-list bind-list">{Object.entries(CONTROLS as Record<string, [string, string]>).map(([id, [code, label]]) => <div className="terminal-row" key={id}><strong>{label}</strong><button type="button" aria-label={`Rebind ${label}`} className={`key-button ${waiting === id ? 'listening' : ''}`} onClick={() => setWaiting(waiting === id ? null : id)}>{waiting === id ? 'PRESS A KEY' : keyName(value.bindings[id] || code)}</button></div>)}</div><Action icon="back" onClick={() => patch({ bindings: {} })}>Reset bindings</Action></>}
    {tab===3&&<div className="terminal-list options-list">{combat.map(([id,title,desc])=><label className="terminal-row" key={id}><div><strong>{title}</strong><small>{desc}</small></div><input type="checkbox" role="switch" checked={Boolean(value[id])} onChange={e=>patch({[id]:e.target.checked})}/></label>)}</div>}
  </Modal>;
}

export function LoadMenu({ record, load, start, close, mode }: { record: RecordData | null; load: () => void; start: () => void; close: () => void; mode:GameMode }) {
  const missions=campaignFor(mode);
  return <Modal title="Load Game" tag={`${MODES[mode].name.toUpperCase()} / LOCAL CHECKPOINT`} onClose={close}>
    {record ? <div className="load-slot"><Icon name="save"/><div><strong>{mode==='atlas'?'Open Atlas Expedition':mode==='outbreak'?'Quarantine Run':missions[record.chapter]?.title||'Free roam'}</strong><small>{mode==='atlas'?`${record.worldKey||'Default atlas'} / ${record.style||'continental'}`:record.outbreak?`${record.outbreak.signal.length} / 3 BEACONS / ${record.outbreak.score} PTS`:`OPERATION ${Math.min(missions.length,record.chapter+1)} / ${currency(record.cash)} / ${Math.floor(record.stats.playtime/60)} MIN PLAYED`}</small></div><Action primary icon="play" onClick={load}>Continue</Action></div> : <div className="empty-slot"><Icon name="save"/><strong>No checkpoint found</strong><p>This mode has its own checkpoint. Start a run to make one.</p><Action primary icon="play" onClick={start}>{mode==='atlas'?'Explore the Atlas':mode==='outbreak'?'Start survival':'New game'}</Action></div>}
  </Modal>;
}

function CityMap({ state, game, close }: { state: Snapshot; game: GameAPI; close: () => void }) {
  const canvas = useRef<HTMLCanvasElement>(null), coords = useRef<{ left: number; top: number; scale: number;bounds:number[] } | null>(null);
  const [view,setView]=useState(({harbor:1,monsoon:2,mirage:3,basin:4,wilds:5})[state.region]),[zoom,setZoom]=useState(1),[control,setControl]=useState(false),[pan,setPan]=useState<[number,number]>([0,0]);
  useLayoutEffect(() => {
    const draw=()=>{if(canvas.current)coords.current=fullMap(canvas.current,state,game,['world','harbor','monsoon','mirage','basin','frontier'][view],zoom,control,pan);};
    draw(); window.addEventListener('resize', draw);
    return () => window.removeEventListener('resize', draw);
  }, [state,game,view,zoom,control,pan]);
  return <Modal title="City Map" tag={`${state.district.toUpperCase()} / ${state.time}`} onClose={close} wide>
    <div className="atlas-controls"><Tabs labels={['World','Vesper Bay','Monsoon City','Mirage Coast','Neon Basin','Frontier']} value={view} change={n=>{setView(n);setZoom(1);setPan([0,0]);}}/><button type="button" className="key-button" onClick={()=>setZoom(zoom===1?1.7:1)} aria-pressed={zoom!==1}>{zoom===1?'ZOOM +':'RESET VIEW'}</button></div>
    <div className={`map-frame ${view===0?'world-view':''}`}><canvas ref={canvas} aria-label="Regional map. Click to pin a waypoint." onClick={event => {
      if (!coords.current) return;
      const { left, top, scale,bounds } = coords.current, rect = event.currentTarget.getBoundingClientRect();
      const x=(event.clientX-rect.left-left)/scale,y=(event.clientY-rect.top-top)/scale;
      if(x>=bounds[0]&&x<=bounds[2]&&y>=bounds[1]&&y<=bounds[3])game.setWaypoint(x,y);
    }}/></div>
    <div className="map-legend"><span><i/> YOU</span><span><i/> {state.outbreak?'BEACON / EVAC':'OPERATION'}</span><span><i/> {state.outbreak?'SUPPLY CACHE':'DISCOVERED'}</span><span><i/> WAYPOINT</span></div>
    {!state.outbreak&&<button className="key-button territory-toggle" type="button" aria-pressed={control} onClick={()=>setControl(!control)}>{control?'Hide district control':'Show district control'}</button>}
    {view===5&&<div className="chart-near" aria-label="Pan frontier chart"><small>{state.atlas.charted} cells charted / {state.atlas.surveys} surveys recorded</small>{([['West',-710,0],['North',0,-490],['South',0,490],['East',710,0]] as const).map(([label,x,y])=><button className="key-button" type="button" key={label} onClick={()=>setPan([pan[0]+x,pan[1]+y])}>{label}</button>)}<button className="key-button" type="button" onClick={()=>setPan([0,0])}>Center</button></div>}
    <div className="form-line map-control"><span>Click the map to set a waypoint.</span><select aria-label="Pin discovered location" value="" onChange={e => { const p = (PLACES as Place[]).find(p => p.id === e.target.value); if (p) game.setWaypoint(p.x, p.y); }}><option value="">Pin a discovered location</option>{(PLACES as Place[]).filter(p => state.discovered.includes(p.id)).map(p => <option value={p.id} key={p.id}>{p.name}</option>)}</select><Action onClick={() => game.setWaypoint(null)} disabled={!state.waypoint}>Clear pin</Action></div>
  </Modal>;
}

function Phone({ state: s, game, close }: { state: Snapshot; game: GameAPI; close: () => void }) {
  const [tab, setTab] = useState(0);
  const [contact, setContact] = useState<string | null>(null);
  const contacts=s.outbreak?[['Samira Noor','EMERGENCY BAND','The shelter, metro and ghat caches are on your atlas. Wait for the ferry signal.']]:s.region==='mirage'?[['Crescent Pilots','MARINA','The public sea terminal sells tickets to Monsoon and Vesper.'],['Copper Lantern','SAFFRON SOUK','Check Regional Jobs for the Lantern Quarter contract.']]:s.region==='basin'?[['Velvet Circuit','JACKLIGHT','The east relay needs a driver. Ask for Velvet Block.'],['Ember Desk','RELIEF NETWORK','Scheduled civilian deliveries are posted at the field office.']]:s.mode==='monsoon'?[['Samira Noor','RIVER COOPERATIVE','If you are at Nodi Cha, the curbside roster is under the awning.'],['Rafi Sen','METRO OPERATIONS','You can catch a train at a station counter. The fare is eight credits.'],['Kadam Works','MUNICIPAL DEPOT','For heavy repair jobs, take the tracked rig. For everything else, try the CNG.']]:[['Inez Sable','COIL UNION',s.chapter < 5 ? 'I left you a car. Make it back in one piece.' : 'The old relays are yours. Use them when you need a quiet night.'], ['Halden Rook','GRID CONTRACTOR',s.chapter < 7 ? 'Someone is asking about your delivery. Think about who sent you.' : 'Did you hear the unedited tape yet?'], ['Sable Motorworks','NEON QUARTER','Need repairs? Park by my door and come inside.']];
  const jobs=(JOBS as Job[]).filter(j=>(j.region||'harbor')===s.region);
  return <Modal title="Pocket Relay" tag={`VESPER CELL / ${s.time}`} onClose={close}>
    <Tabs labels={[s.outbreak?'Survival':'Jobs','The Wire','Contacts','Radio','Messages']} value={tab} change={setTab}/>
    {tab===0&&<><div className="phone-operation"><label>{s.outbreak?'EVACUATION PLAN':s.mode==='atlas'?'REGIONAL JOBS':'ACTIVE OPERATION'}</label><strong>{s.title}</strong><span>{s.objective}</span><button type="button" onClick={()=>game.open('map')}><Icon name="map"/> Open map</button></div>{s.outbreak?<p className="terminal-lead">{s.outbreak.beacons} of 3 beacons live. {s.outbreak.score} points this run.</p>:<><div className="terminal-list">{jobs.length?jobs.map(j=><div className="terminal-row" key={j.id}><span className="job-icon">{j.icon}</span><div><strong>{j.name}</strong><small>{j.desc}</small></div><button type="button" className="line-button" onClick={()=>game.action('job',j.id)}>{s.job===j.name?'Active':j.pay?currency(j.pay):'Pin'}<Icon name="chevron"/></button></div>):<p className="small-note">No scheduled jobs here. Explore to find a survey station.</p>}</div>{s.job&&<Action onClick={()=>game.action('job','')}>Cancel contract</Action>}</>}</>}
    {tab === 1 && <div className="terminal-list wire-feed"><p className="small-note">LIVE DISPATCH / CITY FREQUENCIES</p>{s.news.map((n, i) => <div className="terminal-row" key={n.time + i}><time>{n.time}</time><p>{n.title}</p></div>)}</div>}
    {tab === 2 && <div className="terminal-list contacts">
      {contacts.map(([name, org, line]) => <div key={name}>
        <button type="button" className="terminal-row contact-row" aria-expanded={contact === name} onClick={() => setContact(contact === name ? null : name)}><span className="job-icon">{name[0]}</span><div><strong>{name}</strong><small>{org}</small></div><Icon name="chevron"/></button>
        {contact === name && <div className="contact-message">{line}</div>}
      </div>)}
    </div>}
    {tab === 3 && <><div className="terminal-list">{STATIONS.map((r: { name: string; genre: string; dial: string; blurb: string }, n: number) => <div className="terminal-row" key={r.dial}><span className="dial">{r.dial}</span><div><strong>{r.name}</strong><small>{r.genre} / {r.blurb}</small></div>{s.station === n && <span className="on-air">ON AIR</span>}</div>)}</div><Action primary icon="radio" onClick={() => game.action('radio')}>Next frequency</Action></>}
    {tab===4&&<div className="terminal-list inbox">{s.inbox.length?s.inbox.map(m=><article className="terminal-row" key={m.id}><div><strong>{m.speaker}</strong><small>{m.line}</small></div><time>{m.stamp}</time></article>):<p className="small-note">No messages in this checkpoint yet.</p>}</div>}
    {tab===4&&!s.outbreak&&s.chapter<s.total&&<Action icon="play" onClick={()=>game.action('briefing')}>Replay mission briefing</Action>}
  </Modal>;
}

function Shop({ state: s, game, close, street=false }: { state: Snapshot; game: GameAPI; close: () => void; street?:boolean }) {
  const [tab, setTab] = useState(0),[paint,setPaint]=useState('0'),[plate,setPlate]=useState('GHOST');
  const market=['market','bazaar','mirage-souk'].includes(s.room||''),garage=['garage','works','mirage-garage','basin-garage'].includes(s.room||'');
  const row = (title: string, info: string, money: string, kind: string, value?: number, disabled = false) => <div className="terminal-row" key={title}><div><strong>{title}</strong><small>{info}</small></div><button type="button" className="line-button" onClick={() => game.buy(kind, value)} disabled={disabled}>{money}<Icon name="chevron"/></button></div>;
  const property=(id:string,n:number)=>{const q=HOLDINGS[id],owned=s.properties.includes(id);return row(q.name,`Pays ${currency(q.rate)} per city hour into your bank.`,owned?'Owned':currency(q.price),'holding',n,owned);};
  return <Modal title={street?'Roadside Stall':s.district} tag={`${s.shop || 'COUNTER'} / WALLET ${currency(s.cash)}`} onClose={close}>
    {market && <Tabs labels={['Supplies','Equipment','Clothes']} value={tab} change={setTab}/>}
    {garage && <Tabs labels={['Service','Vehicles','Customize']} value={tab} change={setTab}/>}
    <div className="terminal-list">
      {market && (tab === 0 ? [row('Medkit',`${s.medkits} in your inventory`,'$38','kits'),row('Street food','Restores 34 vitality.','$18','food'),row('Light armor','Restores armor to full.','$55','armor')] : tab===1?(GEAR as Gear[]).map((g, n) => (!s.unlocked.includes(n) || g.mag > 0) && row(g.name, s.unlocked.includes(n) ? `Restock ${g.ammo} ammunition` : `${g.ammo} / ${HANDLING[g.id].cue}`, s.unlocked.includes(n) ? '$32' : currency(g.price), 'gear', n)):WARDROBE.map((q:{name:string;price:number},n:number)=>row(q.name,s.clothes.includes(n)?'Owned / available in the safehouse wardrobe.':'Buy and equip this outfit.',s.clothes.includes(n)?'Equip':currency(q.price),'outfit',n,s.look.outfit===n)))}
      {(street||s.room==='cha'||s.room==='garden')&&[row('Dudh Cha','Hot milk tea. Restores stamina and 16 vitality.','$12','cha'),row('Cut fruit','Fresh fruit restores 25 vitality.','$16','fruit')]}
    {s.room==='ghat'&&[row('Ghat plate','A warm snack from the river canteen.','$18','food'),row('Find the jetty','Pin the water taxi boarding point.','Pin','jetty'),property('ghat-counter',0)]}
      {s.room==='lake'&&[row('Promenade kiosk','Pick up a medkit before crossing the lake.','$38','kits'),property('lake-stall',1)]}
      {s.room==='bus'&&row('Terminal canteen','Quick food before the next departure.','$18','food')}
      {s.room === 'archive' && [row('Deposit',`Balance ${currency(s.bank)}`,'$100','deposit',undefined,s.cash < 100),row('Withdraw','Transfer to cash.','$100','withdraw',undefined,s.bank < 100)]}
      {s.room === 'station' && row('Settle alerts','Pay a dispatch fine to clear your wanted level.','$180','fine',undefined,!s.heat)}
      {['hospital','mclinic','mirage-clinic','basin-clinic'].includes(s.room||'')&&row('Treatment','Restore full vitality.','$45','treat',undefined,s.health>=100)}
      {s.room === 'loft' && [row('Purchase Morrow Loft','Earn $38 per city hour, deposited into Vesper Trust.',s.properties.includes('loft') ? 'Owned' : '$680','property',undefined,s.properties.includes('loft')),row('Rest','Pass two hours and recover vitality.','Free','rest',undefined,!s.properties.includes('loft'))]}
      {s.room === 'dock' && <>{[row('Dockside supplies','Restores vitality.','$18','food'),row('Field kit','Replenish your medkit supply.','$38','kits')]}<Action icon="arrow" onClick={()=>game.action('trade-open')}>Open trading desk</Action></>}
      {['dock','ghat'].includes(s.room||'')&&!s.outbreak&&<Action icon="pin" onClick={()=>game.open('travel-sea')}>Public ferry</Action>}
      {s.room === 'arcade' && row('Frequency Match','Hit the highlighted interval to win $65 in game credits.','$15','arcade')}
      {garage&&tab===0&&[row('Repair vehicle','Fix glass, bodywork, and tire damage on your nearest parked vehicle.','$65','repair'),row('Performance kit','Raises the top speed.','$165','upgrade')]}
      {garage&&tab===1&&(GARAGE as Vehicle[]).map((v,i)=>v.class!=='BOAT'&&(s.room!=='garage'||i<9)&&row(v.name,v.class,currency(v.price),'car',i))}
      {garage&&tab===2&&<>
        <div className="terminal-row"><label htmlFor="car-paint">Paint finish</label><div className="button-row"><select id="car-paint" value={paint} onChange={e=>setPaint(e.target.value)}>{GARAGE_PAINT.map((q:{name:string},i:number)=><option key={i} value={i}>{q.name}</option>)}</select><button type="button" className="line-button" onClick={()=>game.buy('paint',Number(paint))}>APPLY $35</button></div></div>
        <div className="terminal-row"><label htmlFor="car-plate">Local plate</label><div className="button-row"><input className="plate-input" id="car-plate" maxLength={7} value={plate} onChange={e=>setPlate(e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g,''))}/><button type="button" className="line-button" onClick={()=>game.buy('plate',plate)} disabled={!plate}>REGISTER $35</button></div></div>
      </>}
    </div>
    {s.note && <p className={`purchase-note ${s.note.tone}`} role="status">{s.note.title}: {s.note.message}</p>}
  </Modal>;
}

function Transit({state:s,game,close}:{state:Snapshot;game:GameAPI;close:()=>void}){
  return <Modal title="Monsoon Metro" tag="CROSSTOWN LINE / STATIONS" onClose={close}>
    <p className="terminal-lead">Three stops. One through fare.</p><div className="terminal-list transit-list">
    {(PLACES as Place[]).filter(p=>p.kind==='METRO').sort((a,b)=>a.y-b.y).map(p=><div className="terminal-row" key={p.id}><Icon name="train"/><div><strong>{p.name}</strong><small>{s.room===p.id?'You are here':p.id==='northmetro'?'North Enclave':p.id==='oldmetro'?'Puran Bazaar':'Shapla Center'}</small></div><button type="button" className="line-button" disabled={p.id===s.room||s.cash<8} onClick={()=>game.action('transit',p.id)}>{p.id===s.room?'Current':'Ride / $8'}<Icon name="chevron"/></button></div>)}
    </div>
  </Modal>;
}

function Customize({ state: s, game, close }: { state: Snapshot; game: GameAPI; close: () => void }) {
  const channels = [ ['Jacket', 'color', ['#ff6481','#91dfc3','#b894f6','#e9ad85','#76aad9','#ebded0']], ['Skin', 'skin', ['#e3ac93','#f4d0ab','#b78068','#935e50','#633c38']] ] as const;
  return <Modal title="Safehouse Wardrobe" tag="MARA VENN / CHARACTER" onClose={close}>
    <div className="custom-layout">
      <div className="pixel-profile" aria-label="Mara preview"><svg width="100" height="132" viewBox="0 0 30 40" shapeRendering="crispEdges" aria-hidden="true">
        <path fill="#2d243d" d="M4 36h22v3H4zM7 18h16v19H7z"/><path fill={s.look.color} d="M8 17h14v15H8zM5 19h4v10H5zm16 0h4v10h-4z"/>
        <path fill="#1d1a2c" d="M9 31h5v6H9zm7 0h5v6h-5zM11 4h9v3h-9zM9 6h13v9H9z"/>
        <path fill={s.look.skin} d="M10 9h11v8H10zM5 28h3v3H5zm17 0h3v3h-3z"/><path fill={s.look.hair === 2 ? '#ba7f65' : '#302038'} d={s.look.hair === 0 ? 'M10 5h10v4H10z' : s.look.hair === 1 ? 'M9 6h13v3H10v6H8V9h1z' : 'M11 1h9v3h2v6h-6V8h-6V5h1z'}/>
        <path fill="#211827" d="M13 11h2v1h-2zm5 0h2v1h-2z"/><path fill="#e8c0b3" d="M14 15h5v1h-5z"/>
      </svg></div>
      <div>{channels.map(([name, field, colors]) => <div className="custom-row" key={field}><strong>{name}</strong><div className="swatches">{colors.map((color, n) => <button type="button" key={color} aria-label={`${name} color ${n + 1}`} aria-pressed={s.look[field] === color} style={{ background: color }} onClick={() => game.action('look', { [field]: color })}/>)}</div></div>)}
      <div className="custom-row"><strong>Hairstyle</strong><div className="swatches">{['Cut','Bob','Crest'].map((name, n) => <button type="button" key={name} aria-pressed={s.look.hair === n} onClick={() => game.action('look', { hair: n })}>{name}</button>)}</div></div></div>
    </div>
    <div className="custom-row"><strong>Clothes</strong><div className="swatches">{WARDROBE.map((q:{name:string;price:number},n:number)=><button type="button" key={q.name} disabled={!s.clothes.includes(n)} title={!s.clothes.includes(n)?'Available at a market counter':undefined} aria-pressed={s.look.outfit===n} onClick={()=>game.action('look',{outfit:n})}>{q.name}</button>)}</div></div>
    <Action icon="heart" onClick={() => { game.buy('rest'); close(); }}>Rest at safehouse</Action>
  </Modal>;
}

function Debug({ state: s, game, close }: { state: Snapshot; game: GameAPI; close: () => void }) {
  const [model, setModel] = useState('2'), [where, setWhere] = useState('relay'),[scenario,setScenario]=useState('auto');
  const missions=campaignFor(s.mode);
  return <Modal title="Debug & Cheats" tag="SIMULATION / TEST BENCH" onClose={close}>
    <div className="terminal-list">
      <div className="terminal-row"><div><strong>Wallet and player</strong><small>{currency(s.cash)} / {s.health}% vitality</small></div><div className="button-row"><Action onClick={() => game.dev('cash')}>Add $1,000</Action><Action onClick={() => game.dev('heal')}>Heal</Action></div></div>
      <div className="terminal-row"><label htmlFor="dev-car">Vehicle model</label><div className="button-row"><select id="dev-car" value={model} onChange={e => setModel(e.target.value)}>{(GARAGE as Vehicle[]).map((v,i) => <option value={i} key={v.id}>{v.name}</option>)}</select><Action onClick={() => game.dev('spawn', Number(model))}>Spawn</Action></div></div>
      <div className="terminal-row"><label htmlFor="dev-where">Teleport location</label><div className="button-row"><select id="dev-where" value={where} onChange={e => setWhere(e.target.value)}>{(PLACES as Place[]).map(p => <option value={p.id} key={p.id}>{p.name}</option>)}</select><Action onClick={() => { game.dev('teleport', where); close(); }}>Teleport</Action></div></div>
      {!s.outbreak&&<label className="terminal-row"><strong>Wanted level</strong><select aria-label="Wanted level" value={s.heat} onChange={e => game.dev('heat', Number(e.target.value))}>{[0,1,2,3,4,5].map(n => <option value={n} key={n}>{n} / 5</option>)}</select></label>}
      <label className="terminal-row"><strong>Weather</strong><select aria-label="Weather" value={s.weather} onChange={e => game.dev('weather', WEATHER.indexOf(e.target.value))}>{WEATHER.map((w: string) => <option key={w}>{w}</option>)}</select></label>
      <label className="terminal-row"><strong>City hour <small>{s.time}</small></strong><input type="range" min="0" max="23" aria-label="City hour" value={Number(s.time.split(':')[0])} onChange={e => game.dev('time', Number(e.target.value))}/></label>
      {!s.outbreak&&<label className="terminal-row"><strong>Jump to operation</strong><select aria-label="Jump to operation" value={s.chapter} onChange={e => game.dev('chapter', Number(e.target.value))}>{missions.map((c: { title: string }, i: number) => <option value={i} key={c.title}>{i + 1}. {c.title}</option>)}{s.chapter >= missions.length && <option value={missions.length}>Campaign complete</option>}</select></label>}
      {!s.outbreak&&<div className="terminal-row"><label htmlFor="street-scenario">Street event</label><div className="button-row"><select id="street-scenario" value={scenario} onChange={e=>setScenario(e.target.value)}>{(EVENT_OPTIONS as [string,string][]).map(([id,label])=><option key={id} value={id}>{label}</option>)}</select><Action onClick={()=>game.dev('street',scenario)}>Start event</Action></div></div>}
    </div>
    <Action icon="gun" onClick={() => game.dev('arsenal')}>Unlock arsenal</Action>
  </Modal>;
}

function Stats({ game, close,total,perks }: { game: GameAPI; close: () => void;total:number;perks:string[] }) {
  const n = game.statsData();
  return <Modal title="Career Stats" tag="MARA VENN / COURIER PROFILE" onClose={close}>
    <div className="stat-grid">{[['Operations',`${n.missions} / ${total}`], ['Contracts',n.jobs], ['Pursuits escaped',n.escapes], ['Tapes found',n.tapes], ['Distance driven',`${(n.driven / 1650).toFixed(1)} km`], ['Time in the city',`${Math.floor(n.playtime / 60)} min`], ['Rounds used',n.shots], ['Confirmed contacts',n.hits]].map(([label, value]) => <div key={label}><span>{label}</span><strong>{value}</strong></div>)}</div>
    <p className="section-label">SKILLS / IMPROVE WITH USE</p><div className="terminal-list options-list">{Object.entries(n.skills).map(([key,v]) => <div key={key} className="terminal-row"><strong>{key}</strong><span className="skill-bar"><i style={{ width: `${Math.min(100, v * 4)}%` }}/></span><small>{Math.floor(v)}</small></div>)}</div>
    <p className="section-label">FIELD ABILITIES</p><div className="terminal-list">{[['long-stride','Long Stride','Sprint longer. Unlock with stamina 8.'],['steady-hand','Steady Hand','Less recoil. Unlock with aim 13.'],['quick-step','Quick Step','Rolls cost less stamina. Unlock with stealth 9.'],['smooth-ride','Smooth Ride','Keep more grip in the rain. Unlock with driving 11.']].map(([id,label,detail])=><div key={id} className="terminal-row"><div><strong>{label}</strong><small>{detail}</small></div><span className="small-note">{perks.includes(id)?'UNLOCKED':'LOCKED'}</span></div>)}</div>
    <p className="section-label">FACTION RELATIONSHIPS</p><div className="faction-list">{Object.entries(n.rep).map(([key,v]) => <div key={key}><span>{key}</span><strong>{v > 2 ? 'Allied' : v < -2 ? 'Hostile' : 'Neutral'}</strong></div>)}</div>
  </Modal>;
}

function Exchange({s,game,close}:{s:Snapshot;game:GameAPI;close:()=>void}){
  return <Modal title={s.room==='dock'?'Pier Trading Desk':'Lantern Exchange'} tag={`LOCAL PRICES / ${s.time} / ${currency(s.cash)}`} onClose={close}>
    <p className="terminal-lead">Buy and sell civilian salvage between the two cities.</p><p className="small-note">Prices change by the city hour. The two desks offer different rates.</p>
    <div className="terminal-list">{s.market.map((x,i)=><div key={x.id} className="terminal-row"><div><strong>{x.name}</strong><small>{x.held} in your cargo / capacity 12</small></div><div className="button-row"><button className="line-button" type="button" disabled={s.cash<x.buy||x.held>=12} onClick={()=>game.action('trade-buy',i)}>BUY {currency(x.buy)}</button><button type="button" className="line-button" disabled={!x.held} onClick={()=>game.action('trade-sell',i)}>SELL {currency(x.sell)}</button></div></div>)}</div>
    <Action icon="map" onClick={()=>game.action('dispatch-pin',s.room==='dock'?'swapmeet':'dock')}>Pin other exchange</Action>
  </Modal>;
}

function PhotoBar({s,game,close}:{s:Snapshot;game:GameAPI;close:()=>void}){
  const [zoom,change]=useState(1);
  return <div className="photo-toolbar"><span><Icon name="photo"/> PHOTO MODE</span>
    <label className="photo-zoom">ZOOM <input type="range" min=".6" max="1.65" step=".05" value={zoom} aria-label="Photo zoom" onChange={e=>{const v=Number(e.target.value);change(v);game.action('photo-zoom',v);}}/></label>
    {s.photoJob?<Action primary icon="check" onClick={()=>game.action('photo-frame')}>Frame landmark</Action>:null}
    <Action primary={!s.photoJob} icon="save" onClick={() => game.action('photo')}>Capture PNG</Action><button className="terminal-close" type="button" aria-label="Exit photo mode" onClick={close}><Icon name="close"/></button></div>;
}

export function GamePanel({ panel, state: s, game, close, title, restart, retry, practice }: { panel: string; state: Snapshot; game: GameAPI; close: () => void; title: () => void; restart:()=>void;retry:()=>void;practice:()=>void }) {
  if(panel==='travel-air'||panel==='travel-sea')return <Modal title={panel==='travel-air'?'Air Departures':'Sea Departures'} tag={`${s.district.toUpperCase()} / TICKET DESK`} onClose={close}><Departures s={s} game={game} air={panel==='travel-air'}/></Modal>;
  if(panel==='club')return <Modal title={s.district} tag="NIGHTLIFE / HOST DESK" onClose={close}><ClubDesk s={s} game={game}/></Modal>;
  if(panel==='jacklight')return <Modal title="Jacklight Score Table" tag="NEON BASIN / FREE PLAY" onClose={close}><Jacklight s={s} game={game}/></Modal>;
  if(panel==='scenic')return <Modal title={s.district} tag={`${s.regionName.toUpperCase()} / CITY VIEW`} onClose={close}><Panorama s={s}/><Action icon="map" onClick={()=>game.open('map')}>Open chart</Action></Modal>;
  if(panel==='field-office')return <Modal title="Fort Ember Field Office" tag="PUBLIC FIELD DESK / RELIEF DIVISION" onClose={close}><p className="terminal-lead">Civil road closures are posted at the gate.</p><p className="small-note">Take an openly scheduled relief run. The marker sends you to the volunteer van outside the public office.</p><Action icon="car" primary onClick={()=>game.action('start-ember')}>Accept Ember Relief</Action></Modal>;
  if(panel==='practice-entry')return <Modal title="Anchor Training Bay" tag="CONTACT LAB / VISITOR DESK" onClose={close}><p className="terminal-lead">Practice in a separate session.</p><p className="small-note">Your current campaign will be saved before the bay opens.</p><Action icon="cross" primary onClick={practice}>Save and enter</Action></Modal>;
  if(panel==='practice'&&s.practice)return <Modal title="Choose a Drill" tag="ANCHOR TRAINING BAY / CONTACT LAB" onClose={close}><DrillBrief state={s.practice} game={game}/></Modal>;
  if(panel==='practice-results'&&s.practice)return <Modal title="Drill Results" tag="ANCHOR TRAINING BAY / LOCAL RECORD" onClose={close}><DrillResults state={s.practice} game={game} title={title}/></Modal>;
  if (panel === 'map') return <CityMap state={s} game={game} close={close}/>;
  if (panel === 'phone') return <Phone state={s} game={game} close={close}/>;
  if (panel === 'shop') return <Shop state={s} game={game} close={close}/>;
  if(panel==='vendor')return <Shop state={s} game={game} close={close} street/>;
  if(panel==='transit')return <Transit state={s} game={game} close={close}/>;
  if (panel === 'custom') return <Customize state={s} game={game} close={close}/>;
  if (panel === 'stats') return <Stats game={game} close={close} total={s.total} perks={s.perks}/>;
  if(panel==='exchange')return <Exchange s={s} game={game} close={close}/>;
  if(panel==='records')return <Modal title="Activity Records" tag="LOCAL LEDGER / MARA VENN" onClose={close}><RecordBook s={s}/></Modal>;
  if(panel==='dispatch')return <Modal title="Dispatch Board" tag="GRID PRECINCT / PUBLIC BULLETINS" onClose={close}><p className="terminal-lead">{s.heat?`Current alert: ${s.alert.toLowerCase()}.`:'No active alerts.'}</p><div className="terminal-list wire-feed">{s.news.slice(0,5).map((n,i)=><div className="terminal-row" key={i}><time>{n.time}</time><p>{n.title}</p></div>)}</div></Modal>;
  if(panel==='table'&&s.table){const table=TABLES[s.table.id];return <Modal title={table.name} tag={table.subtitle} onClose={close}><ActivityBody s={s} game={game}/></Modal>;}
  if (panel === 'cheats') return <Debug state={s} game={game} close={close}/>;
  if (panel === 'wheel') return <Modal title="Weapon Wheel" tag="SELECT YOUR EQUIPMENT" onClose={close}>
    <div className="weapon-wheel" aria-label="Weapons">
      <div className="wheel-center"><Icon name="gun"/><strong>{GEAR[s.weapon].name}</strong><small>{GEAR[s.weapon].ammo} / {HANDLING[GEAR[s.weapon].id].mode}</small></div>
      {(GEAR as Gear[]).map((w, i) => {
        const a = i / GEAR.length * 2 * Math.PI - Math.PI / 2, unlocked = s.unlocked.includes(i);
        return <button type="button" key={w.id} title={unlocked ? w.name : `${w.name} / Locked`} aria-label={w.name} aria-pressed={s.weapon === i} disabled={!unlocked} style={{ left: `${50 + Math.cos(a) * 40}%`, top: `${50 + Math.sin(a) * 39}%` }} onClick={() => game.action('weapon', i)}><Icon name={w.style === 'melee' ? 'dash' : 'gun'}/><small>{w.name}</small></button>;
      })}
    </div><p className="small-note">Buy additional equipment at Rill Night Market.</p>
  </Modal>;
  if (panel === 'choice') return <Modal title="Make the Call" tag="THIS DECISION CHANGES YOUR STORY" onClose={close}><div className="pause-list">{game.stage()?.options?.map((option, i) => <button type="button" key={option} onClick={() => game.action('choose', i)}><i>{String(i + 1).padStart(2, '0')}</i><span>{option}</span><Icon name="chevron"/></button>)}</div></Modal>;
  if (panel === 'ending') return <Modal title={s.ending.split(' / ')[0]} tag="STATIC HARBOR / EPILOGUE" onClose={close}><div className="epilogue"><BrandMark/><p>{s.ending.split(' / ')[1]}</p><Action primary icon="play" onClick={close}>Continue free roam</Action></div></Modal>;
  if(panel==='outbreak-end'&&s.outbreak){const o=s.outbreak;return <Modal title={o.dead?'Signal Lost':'Ferry Secured'} tag="OUTBREAK / RUN REPORT" dismissible={!o.dead} onClose={close}>
    <p className="terminal-lead">{o.dead?'The Quiet got too close.':'The beacons held long enough to bring in the ferry.'}</p>
    <div className="stat-grid"><div><span>Run score</span><strong>{o.score}</strong></div><div><span>Personal best</span><strong>{o.best}</strong></div><div><span>Quiet repelled</span><strong>{o.kills}</strong></div><div><span>Beacons</span><strong>{o.beacons} / 3</strong></div></div>
    <div className="outbreak-choices button-row">{o.dead?<><Action primary icon="play" onClick={restart}>New survival run</Action>{s.save&&<Action icon="save" onClick={retry}>Retry checkpoint</Action>}</>:<Action primary icon="play" onClick={close}>Keep surviving</Action>}<Action icon="door" onClick={title}>Return to title</Action></div>
  </Modal>;}
  if (panel === 'photo') return <PhotoBar s={s} game={game} close={close}/>;
  if (panel === 'leave') return <Modal title="Return to Title?" tag="STATIC HARBOR / DISCONNECT" onClose={close}><p className="terminal-lead">Save your position before leaving the city.</p><div className="button-row"><Action primary icon="save" onClick={() => { game.save(true); title(); }}>Save and exit</Action><Action onClick={title}>Exit without saving</Action></div></Modal>;
  const rows = s.practice?[['play','Resume',''],['cross','Choose a drill','practice'],['gear','Settings','settings'],['photo','Photo mode','photo'],['door','Return to title','title']]:[['play','Resume',''],['save','Save checkpoint','save'],['gear','Settings','settings'],['book','Field Guide','guide'],['photo','Photo mode','photo'],['chart','Career stats','stats'],['check','Activity records','records'],['bug','Debug & cheats','cheats'],['door','Return to title','leave']];
  return <Modal title="Paused" tag={`${s.district.toUpperCase()} / ${s.time}`} onClose={close}>
    <div className="pause-list">{rows.map(([icon,label,action]) => <button type="button" className={!action ? 'resume-row' : ''} key={label} onClick={() => { if (action === 'save') { game.save(); close(); } else if(action==='photo')game.action('photo-compose');else if(action==='title')title();else if(action)game.open(action);else close(); }}><Icon name={icon}/><span>{label}</span><Icon name="chevron"/></button>)}</div>
    <div className="terminal-bottom"><kbd>{s.keys.pause}</kbd> RESUME <span>{s.practice?'ISOLATED PRACTICE':s.save?'CHECKPOINT AVAILABLE':'NO SAVED CHECKPOINT'}</span></div>
  </Modal>;
}