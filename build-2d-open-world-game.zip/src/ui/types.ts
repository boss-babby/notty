export type Settings = {
  master: number; music: number; sfx: number; muted: boolean; quality: string;
  shake: boolean; crt: boolean; contrast: boolean; motion: boolean; touch: boolean; bindings: Record<string, string>;
  autoTap:boolean;autoReload:boolean;assist:boolean;flashes:boolean;impactTint:boolean;
};

export type GameMode = 'campaign' | 'monsoon' | 'outbreak' | 'practice' | 'atlas';
export type RegionId = 'harbor' | 'monsoon' | 'mirage' | 'basin' | 'wilds';
export type AtlasSetup = {key:string;style:string;start:string};
export type BestRun = { score: number; kills: number; escaped: boolean };
export type RecordData = {
  chapter:number;day:number;cash:number;stats:{playtime:number};worldKey?:string;style?:string;
  outbreak?: { score: number; kills: number; signal: string[]; escaped: boolean } | null;
};

export type Speech = { speaker: string; line: string; time: number };
export type Notice = { title: string; message: string; tone: string; time: number };
export type Look = { color: string; hair: number; skin: string; outfit:number };
export type DrillResult = {passed:boolean;score:number;time:number;shots:number;hits:number;blocks:number};
export type PracticeState = {id:string;active:boolean;time:number;total:number;glass:number;blocks:number;rolls:number;goal:number;best:Record<string,DrillResult>;last:DrillResult|null};
export type RecordEntry = { best:number; plays:number; wins:number };
export type TableState = {
  id:'carrom'|'darts'|'dyno'; clock:number; round:number; score:number; last:string; ended:boolean; busy:boolean;
  offset:number; angle:number; power:number; marker:number; goal:number; best:number; wait?:number;
  marks:{x:number;y:number;kind:number}[]; pieces:{x:number;y:number;r:number;kind:string;down:boolean}[];
};

export type Snapshot = {
  mode:GameMode;region:RegionId;regionName:string;total:number;armored:boolean;
  alert:string; table:TableState|null; records:Record<string,RecordEntry>; altitude:number|null; decoys:number; boards:number;view:number;photoJob:boolean;interior:string|null;
  perks:string[];market:{id:string;name:string;buy:number;sell:number;held:number}[];
  contact:{label:string;mode:string;cue:string;progress:number|null;spread:number};
  practice:PracticeState|null;inbox:{id:string;stamp:string;speaker:string;line:string}[];clothes:number[];
  faction:{team:string;standing:string}|null;
  atlas:{charted:number;surveys:number;key:string;style:string};tableRoll:{numbers:number[];score:number}|null;
  outbreak: { score: number; kills: number; beacons: number; time: number; phase: number; noise: number; dead: boolean; escaped: boolean; best: number } | null;
  health: number; armor: number; stamina: number; cash: number; medkits: number; heat: number; seen: boolean;
  title: string; chapter: number; objective: string; distance: number | null; district: string; time: string; weather: string;
  vehicle: string | undefined; speed: number | null; integrity: number | null; station: number; weapon: number; ammo: number; store: number; reloading: boolean;
  prompt: string; control: string; room: string | null; line: Speech | null; note: Notice | null; special: string; tutorial: boolean;
  location: { x: number; y: number }; waypoint: { x: number; y: number } | null; unlocked: number[]; pad: string;
  hotwire: { needle: number; zone: number; mode: string; help: string | null } | null; debug: boolean;
  news: { title: string; time: string }[]; save: boolean; shot: boolean; job: string | null; blackout: boolean; ending: string;
  discovered: string[]; shop: string | null; bank: number; properties: string[]; rep: Record<string, number>; territory: string[]; keys: Record<string, string>; look: Look;
};

export type GameAPI = {
  open(panel: string | null): void;
  setSettings(settings: Settings): void;
  save(silent?: boolean): boolean;
  dispose(): void;
  setWaypoint(x: number | null, y?: number): void;
  action(type: string, value?: string | number | Partial<Look>): void;
  buy(action: string, value?: number|string): void;
  dev(action: string, value?: number | string): void;
  stage(): { options?: string[] } | null;
  statsData(): Record<string, number> & { skills: Record<string, number>; rep: Record<string, number> };
  input: { virtual(action: string, pressed: boolean): void };
};

export type Gear = { id: string; name: string; mag: number; price: number; ammo: string; style: string };
export type District = { name: string; code: string; color: string; faction: string };
export type Vehicle = { id: string; name: string; class: string; color: string; price: number };
export type Place = { id: string; name: string; kind: string; x: number; y: number };
export type Job = { id: string; name: string; desc: string; pay: number; icon: string; region?: string };