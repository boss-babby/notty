import { DRILLS } from '../game/practice.js';
import { Icon } from './icons';
import type { GameAPI, PracticeState } from './types';

type Drill = {id:string;n:string;name:string;intro:string;goal:number;duration:number;color:string};
export function DrillBrief({state,game}:{state:PracticeState;game:GameAPI}){
  return <div className="drill-brief">
    <p className="terminal-lead">Three ways to practice. No risk to your saves.</p>
    <div className="drill-list">
      {(DRILLS as Drill[]).map(d=><button type="button" className="drill-row" key={d.id} aria-label={`Start ${d.name}`} onClick={()=>game.action('drill',d.id)}>
        <span className="drill-number" style={{color:d.color}}>{d.n}</span><span className="drill-text"><strong>{d.name}</strong><small>{d.intro}</small></span>
        <span className="drill-meta">{d.duration} SEC<small>{state.best[d.id]?`${state.best[d.id].score.toLocaleString('en-US')} BEST`:'READY'}</small></span><Icon name="chevron"/>
      </button>)}
    </div>
    <p className="small-note">Hold right mouse or X to brace or guard. Q opens the weapon wheel. R reloads.</p>
  </div>;
}

export function DrillResults({state,game,title}:{state:PracticeState;game:GameAPI;title:()=>void}){
  const result=state.last;if(!result)return null;
  const metrics=[['Score',result.score.toLocaleString('en-US')],['Time',`${result.time.toFixed(1)}s`],['Contacts',String(result.hits)],['Guards',String(result.blocks)]];
  return <div className="drill-results">
    <p className="terminal-lead">{result.passed?'Drill complete.':'Drill ended.'} Your city checkpoints are unchanged.</p>
    <div className="stat-grid">{metrics.map(([k,v])=><div key={k}><span>{k}</span><strong>{v}</strong></div>)}</div>
    <div className="button-row drill-actions">
      <button type="button" className="action-button is-primary" onClick={()=>game.action('drill',state.id)}><Icon name="play"/><span>Run again</span></button>
      <button type="button" className="action-button is-secondary" onClick={()=>game.open('practice')}><Icon name="back"/><span>All drills</span></button>
      <button type="button" className="action-button is-secondary" onClick={title}><Icon name="door"/><span>Title</span></button>
    </div>
  </div>;
}