import { TABLES } from '../game/parlor.js';
import type { GameAPI, RecordEntry, Snapshot, TableState } from './types';
import { Icon } from './icons';

const labels:Record<string,string>={carrom:'Carrom Table',darts:'Neon Darts',dyno:'Workshop Dyno','first-aid':'First Response','tow-shift':'Wrecker Call','air-pass':'Roofline Survey','bus-shift':'Megh Bus Shift','lake-photo':'Jheel Photo Walk'};

export function RecordBook({s}:{s:Snapshot}){
  const entries=Object.entries(s.records) as [string,RecordEntry][];
  return <><p className="terminal-lead">The city keeps a record of your best runs.</p>
    {entries.length?<div className="terminal-list">{entries.sort(([a],[b])=>(labels[a]||a).localeCompare(labels[b]||b)).map(([id,r])=><div className="terminal-row" key={id}>
      <div><strong>{labels[id]||id.replace(/-/g,' ')}</strong><small>{r.plays} completed / {r.wins} successful</small></div>{['carrom','darts','dyno'].includes(id)&&<span className="record-score">{r.best} <small>BEST</small></span>}
    </div>)}</div>:<p className="small-note">No records yet. Play a table game or complete a city contract to start the ledger.</p>}
  </>;
}

export function ActivityBody({s,game}:{s:Snapshot;game:GameAPI}){
  const t=s.table;
  if(!t)return null;
  const spec=TABLES[t.id], unit=t.id==='dyno'?'SHIFTS':'POINTS';
  return <div className="parlor">
    <div className="parlor-heading"><p>{spec.description}</p><span>{t.round} / {spec.shots}</span></div>
    <div className={`parlor-field field-${t.id}`}>
      {t.id==='carrom'?<Carrom t={t}/>:t.id==='darts'?<Darts t={t}/>:<Dyno t={t}/>}
    </div>
    {t.id==='carrom'&&!t.ended&&<div className="parlor-inputs">
      {([['Angle','table-angle',-66,66,t.angle],['Power','table-power',25,100,t.power],['Striker','table-offset',-45,45,t.offset]] as const).map(([label,id,min,max,value])=><label key={id}><span>{label}</span><input aria-label={label} type="range" min={min} max={max} value={value} disabled={t.busy} onChange={e=>game.action(id,Number(e.target.value))}/><b>{value}</b></label>)}
    </div>}
    <div className="parlor-result"><span><b>{t.score}</b> {unit}</span><span>TARGET <b>{spec.target}</b></span><span>BEST <b>{t.best}</b></span></div>
    <div className="parlor-actions"><button type="button" className="action-button is-primary" disabled={!t.ended&&(t.busy||Boolean(t.wait))} onClick={()=>game.action(t.ended?'table-again':'table-play')}><Icon name={t.ended?'back':t.id==='dyno'?'dash':'cross'}/><span>{t.ended?'Play again':t.id==='carrom'?'Shoot':t.id==='darts'?'Throw':'Shift'}</span></button><p role="status">{t.last||`Win $${spec.prize} in game credits. No entry fee.`}</p></div>
  </div>;
}

function Carrom({t}:{t:TableState}){
  const striker=t.pieces.at(-1),a=t.angle*Math.PI/180;
  const fills:Record<string,string>={ink:'#434050',cream:'#f6dcad',queen:'#c66571',striker:'#e7dfbe'};
  return <svg viewBox="0 0 240 240" className="carrom-art" aria-label="Carrom board" role="img">
    <defs><linearGradient id="wood-parlor" x1="0" x2="1" y1="0" y2="1"><stop stopColor="#d9b07b"/><stop offset="1" stopColor="#a77158"/></linearGradient></defs>
    <rect x="2" y="2" width="236" height="236" rx="7" fill="#83605f" stroke="#c49375" strokeWidth="3"/>
    <rect x="11" y="11" width="218" height="218" rx="5" fill="url(#wood-parlor)" stroke="#673c48" strokeWidth="3"/>
    {Array.from({length:12},(_,i)=><path key={i} d={`M28 ${32+i*16}h184`} stroke="#73484e" opacity=".12"/>)}
    {[18,222].flatMap(x=>[18,222].map(y=><circle key={`${x}-${y}`} cx={x} cy={y} r="10" fill="#252235" stroke="#e2b488" strokeWidth="1.4"/>))}
    <circle cx="120" cy="106" r="40" fill="none" stroke="#795250" strokeWidth="1.7"/><circle cx="120" cy="106" r="33" fill="none" stroke="#9c6158" strokeWidth="1"/>
    <path d="M120 73l9 24 24 9-24 9-9 24-9-24-24-9 24-9z" fill="#8e5a59" fillOpacity=".66"/>
    <path d="M43 52h154M43 61h154M43 194h154M43 202h154" fill="none" stroke="#77494c" strokeWidth="1.4"/>
    {[43,197].flatMap(x=>[56,198].map(y=><circle key={`${x}/${y}`} cx={x} cy={y} r="4" fill="#ab6560" stroke="#79454f"/>))}
    {!t.busy&&!t.ended&&striker&&<line x1={striker.x} y1={striker.y} x2={striker.x+Math.sin(a)*79} y2={striker.y-Math.cos(a)*79} stroke="#452c40" strokeWidth="1.45" strokeDasharray="4 4"/>}
    {t.pieces.map((p,i)=>!p.down&&<g key={i}><ellipse cx={p.x+1.7} cy={p.y+1.6} rx={p.r} ry={p.r*.94} fill="#30283e66"/><circle cx={p.x} cy={p.y} r={p.r} fill={fills[p.kind]} stroke="#634750" strokeWidth="1"/><circle cx={p.x} cy={p.y} r={p.r*.61} fill="none" stroke={p.kind==='ink'?'#a48b9e':'#9c6e66'} opacity=".75"/></g>)}
  </svg>;
}

function Darts({t}:{t:TableState}){
  const x=Math.sin(t.clock*3.23)*.92,y=Math.sin(t.clock*2.32+.7)*.9;
  return <svg viewBox="0 0 240 240" className="darts-art" aria-label="Moving dart target" role="img">
    <circle cx="120" cy="120" r="107" fill="#231d30" stroke="#76546e" strokeWidth="3"/>
    {[['92','#51384d'],['72','#634a60'],['51','#b1728a'],['33','#82546e'],['16','#e2b299']].map(([r,fill])=><circle key={r} cx="120" cy="120" r={r} fill={fill} stroke="#d2a3ab5f"/>)}
    {Array.from({length:12},(_,i)=><path key={i} transform={`rotate(${i*30} 120 120)`} d="M120 17v13m0 22v37" stroke="#ecbfbc56"/>)}
    {t.marks.map((m,i)=><circle key={i} cx={120+m.x*100} cy={120+m.y*100} r="3.6" fill="#fff0c6" stroke="#2d2134"/>)}
    {!t.ended&&<g transform={`translate(${120+x*100} ${120+y*100})`}><circle r="9" fill="none" stroke="#9af0ca" strokeWidth="1.7"/><path d="M-14 0h8M6 0h8M0-14v8m0 12v8" stroke="#e2fce7" strokeWidth="1.6"/></g>}
  </svg>;
}

function Dyno({t}:{t:TableState}){
  const x=(v:number)=>26+v*248;
  return <svg viewBox="0 0 300 176" className="dyno-art" aria-label="Workshop RPM band" role="img">
    <rect x="12" y="14" width="276" height="148" rx="3" fill="#222836" stroke="#6c6575"/>
    <text x="26" y="43" fill="#e5b993" fontFamily="monospace" fontSize="10">POWER BAND / LIVE</text>
    <rect x="26" y="68" width="248" height="23" fill="#4b4556"/><rect x={x(t.goal-.13)} y="68" width="64.4" height="23" fill="#7aac80"/>
    {Array.from({length:11},(_,i)=><path key={i} d={`M${26+24.8*i} 93v9`} stroke="#c0aab0"/>)}
    <path d={`M${x(t.marker)} 60v38`} stroke="#ffe2ac" strokeWidth="3"/>
    {Array.from({length:5},(_,i)=><rect key={i} x={26+i*49} y="123" width="39" height="12" fill={t.marks[i]?.kind?'#99c58d':t.marks[i]?'#ae6c7a':'#454553'}/>)}
  </svg>;
}