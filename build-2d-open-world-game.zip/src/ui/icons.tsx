import type { SVGProps } from 'react';

const paths: Record<string, React.ReactNode> = {
  book: <><path d="M12 6.5C10 4.5 6 4 3 5v14c3-1 7-.5 9 1.5 2-2 6-2.5 9-1.5V5c-3-1-7-.5-9 1.5Z"/><path d="M12 7v13"/></>,
  gear: <><path d="m9 3-.7 2.6-2.2 1.3-2.6-.7L2 9l1.9 1.9v2.3L2 15.1l1.5 2.7 2.6-.7 2.2 1.3L9 21h3l.7-2.6 2.2-1.3 2.6.7 1.5-2.7-1.9-1.9v-2.3L19 9.1l-1.5-2.8-2.6.7-2.2-1.3L12 3Z" transform="translate(1.5)"/><circle cx="12" cy="12" r="3"/></>,
  volume: <><path d="M11 5 6 9H3v6h3l5 4V5Z"/><path d="M15 9c1.7 1.6 1.7 4.4 0 6m2.7-8.5a7.8 7.8 0 0 1 0 11"/></>,
  mute: <><path d="M11 5 6 9H3v6h3l5 4V5Zm5 4 5 6m0-6-5 6"/></>,
  play: <path fill="currentColor" stroke="none" d="M7 4.4c0-.6.7-1 1.2-.7l12 7.6a.8.8 0 0 1 0 1.4l-12 7.6a.8.8 0 0 1-1.2-.7Z"/>,
  folder: <><path d="M3 7h7l2 2h9l-2.5 10H3Z"/><path d="M3 7V5h7l2 2h7v2"/></>,
  keyboard: <><rect x="2.5" y="5.5" width="19" height="13" rx="2"/><path d="M6 9h.1m3.9 0h.1m3.9 0h.1m3.9 0h.1M6 12h.1m3.9 0h.1m3.9 0h.1m3.9 0h.1M8 15h8"/></>,
  gamepad: <><path d="M7 7h10c2.2 0 3.6 1.4 4 3.5l1 4.3c.5 2.6-1.6 3.8-3.4 2.6L16 15H8l-2.6 2.4c-1.8 1.2-3.9 0-3.4-2.6l1-4.3C3.4 8.4 4.8 7 7 7Z"/><path d="M7.7 9.5v4m-2-2h4m6 0h.1m2.7-1.5h.1"/></>,
  pin: <><path d="M19 10.5c0 4-7 10-7 10s-7-6-7-10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.3"/></>,
  close: <path d="m6 6 12 12M18 6 6 18"/>,
  arrow: <path d="M4 12h15m-6-6 6 6-6 6"/>,
  back: <path d="M20 12H5m6-6-6 6 6 6"/>,
  chevron: <path d="m9 5 7 7-7 7"/>,
  cross: <><circle cx="12" cy="12" r="7"/><path d="M12 2v5m0 10v5M2 12h5m10 0h5"/></>,
  pause: <><path d="M9 5v14m6-14v14" strokeWidth="3"/></>,
  heart: <><path d="M12 20S4 15 4 9.7C4 5.7 9 4 12 8c3-4 8-2.3 8 1.7C20 15 12 20 12 20Z"/></>,
  shield: <path d="M12 3 4.5 6v5.4c0 4.6 3 7.8 7.5 9.6 4.5-1.8 7.5-5 7.5-9.6V6Z"/>,
  star: <path d="m12 2.8 2.8 5.7 6.3.9-4.5 4.5 1.1 6.3-5.7-3-5.7 3 1.1-6.3-4.5-4.5 6.3-.9Z"/>,
  map: <><path d="m3 6 6-2.5L15 6l6-2.5v15L15 21l-6-2.5L3 21Zm6-2.5v15M15 6v15"/></>,
  phone: <><rect x="7" y="3" width="10" height="18" rx="1.5"/><path d="M10.5 17.6h3"/></>,
  dash: <><path d="m11 3-6 10h6l-1 8 9-12h-7l1-6Z"/></>,
  radio: <><rect x="3" y="7" width="18" height="13" rx="1"/><path d="m5 7 13-4M6 11h5m-5 3h5m-5 3h5"/><circle cx="16.5" cy="14" r="2.5"/></>,
  rain: <><path d="M6 14a4 4 0 1 1 1-7.9A5.3 5.3 0 0 1 17 8a3 3 0 1 1 .5 6H6Zm2 3-1 2m6-2-1 2m6-2-1 2"/></>,
  outbreak: <><path d="M6 15c-2.2-1.7-3-3.6-3-5.8a9 8 0 0 1 18 0c0 2.2-.8 4.1-3 5.8v2.5h-3V21H9v-3.5H6Z"/><path d="M8 10h.1m7.9 0h.1M11 14h2m-1 3.5V21" strokeWidth="2.1"/></>,
  waves: <path d="M2 8c2.4 0 2.4-2 5-2s2.6 2 5 2 2.5-2 5-2 2.5 2 5 2M2 13c2.4 0 2.4-2 5-2s2.6 2 5 2 2.5-2 5-2 2.5 2 5 2M2 18c2.4 0 2.4-2 5-2s2.6 2 5 2 2.5-2 5-2 2.5 2 5 2"/>,
  train: <><rect x="5" y="3" width="14" height="15" rx="2"/><path d="M5.5 11h13M8 21l2-3m6 3-2-3M9 14.5h.1m5.8 0h.1M12 3v8"/></>,
  save: <><path d="M5 3h12l3 3v15H4V3Zm3 0v6h8V3m0 18v-7H8v7"/></>,
  photo: <><path d="M3 7h4l2-3h6l2 3h4v13H3Z"/><circle cx="12" cy="13" r="3.5"/></>,
  chart: <><path d="M4 4v16h16M8 16v-5m5 5V8m5 8V5"/></>,
  bug: <><rect x="7" y="7" width="10" height="13" rx="5"/><path d="m9 7-2-3m8 3 2-3M3 10l4 2m10 0 4-2M3 16h4m10 0h4m-9-6v7"/></>,
  door: <path d="M6 20V4h9v16M4 20h16m-8-8h.1m3-8 4 2v14"/>,
  gun: <path d="M3 7h18v5H9l-2 6H3l2-7H3Zm5 5 4 3 2-3"/>,
  plus: <path d="M12 5v14m-7-7h14"/>,
  check: <path d="m5 12 5 5 9-10"/>,
  car: <><path d="M4 17v3m16-3v3M6 7h12l2 5v5H4v-5Zm-2 5h16M7 14.5h.1m9.9 0h.1"/></>,
  info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.1"/></>,
};

export function Icon({ name, ...props }: SVGProps<SVGSVGElement> & { name: string }) {
  return <svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" {...props}>{paths[name]}</svg>;
}

export function BrandMark({ className }: { className?: string }) {
  return <svg aria-hidden="true" className={className} width="34" height="36" viewBox="0 0 36 36" fill="none">
    <path d="M19 2 33 10v16l-14 8L4 26V10L19 2Z" stroke="currentColor" strokeWidth="1.7"/>
    <path d="m13 13 12-3v4L13 17v-4Zm0 6 12-3v4l-12 3v-4Zm0 6 8-2v3l-8 2v-3Z" fill="currentColor"/>
    <path d="M2 14v8m33-8v8" stroke="currentColor" strokeOpacity=".48"/>
  </svg>;
}

const glyphs: Record<string, [number, string]> = {
  S: [64, 'M12 0H64V19H21V39H52L64 51V88L52 100H0V81H43V61H12L0 49V12Z'],
  T: [66, 'M0 0H66V20H44V100H22V20H0Z'],
  A: [71, 'M16 0H55L71 100H49L46 79H25L22 100H0ZM28 60H43L37 20H34Z'],
  I: [24, 'M1 0H23V100H1Z'],
  C: [64, 'M12 0H64V20H21V80H64V100H12L0 88V12Z'],
  H: [68, 'M0 0H21V39H47V0H68V100H47V60H21V100H0Z'],
  R: [70, 'M0 0H54L67 12V50L55 63L70 100H47L33 65H21V100H0ZM21 20V45H46V20Z'],
  B: [67, 'M0 0H53L65 12V40L56 48L67 59V88L55 100H0ZM21 19V39H44V19ZM21 60V81H46V60Z'],
  O: [69, 'M12 0H57L69 12V88L57 100H12L0 88V12ZM22 20V80H47V20Z'],
};

export function TitleMark({mode='campaign'}: {mode?: string}) {
  const word = (text: string) => {
    let x = 0;
    return Array.from(text).map((char, i) => {
      const [w, d] = glyphs[char], at = x; x += w + 7;
      return <path key={i} transform={`translate(${at} 0)`} d={d} fillRule="evenodd"/>;
    });
  };
  if(mode!=='campaign')return <h1 className="edition-mark" aria-label={mode==='atlas'?'Open Atlas':mode==='monsoon'?'Monsoon Lines':mode==='practice'?'Training Bay':'Outbreak'}>
    <span className="edition-brand">STATIC HARBOR</span>
    {mode==='atlas'?<><span>OPEN</span><span>ATLAS</span></>:mode==='monsoon'?<><span>MONSOON</span><span>LINES</span></>:mode==='practice'?<><span>TRAINING</span><span>BAY</span></>:<><span>OUTBREAK</span><span className="edition-endnote">QUARANTINE AT THE GHAT</span></>}
  </h1>;
  return <h1 className="title-wordmark" aria-label="Static Harbor">
    <svg className="word word-static" aria-hidden="true" viewBox="0 0 450 100">{word('STATIC')}</svg>
    <svg className="word word-harbor" aria-hidden="true" viewBox="0 0 450 100">
      <defs><linearGradient id="title-pink" x1="0" x2="0" y1="0" y2="1" gradientUnits="objectBoundingBox"><stop stopColor="#ff6a82"/><stop offset="1" stopColor="#fb4f69"/></linearGradient></defs>
      <g fill="url(#title-pink)">{word('HARBOR')}</g>
    </svg>
  </h1>;
}