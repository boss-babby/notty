import { GEAR, STATIONS } from '../game/data.js';
import { BrandMark, Icon } from './icons';
import type { GameAPI, Snapshot } from './types';

const number = (n: number) => Math.round(n).toLocaleString('en-US');

export function Hud({ state: s, game, touch }: { state: Snapshot; game: GameAPI; touch: boolean }) {
  const weapon = GEAR[s.weapon];
  const actionKey = s.pad === 'GAMEPAD' ? 'A' : s.control;
  const station = STATIONS[s.station];
  const out=s.outbreak, drill=s.practice, contact=s.contact;
  return <div className="hud" aria-label="Game display">
    <div className="hud-mission hud-corner">
      <div className="hud-loc"><BrandMark/> <div><strong>{s.district}</strong><span>{s.interior||<>{s.time} <i/> {s.weather} {s.blackout ? '/ DEAD AIR' : ''}</>}</span></div></div>
      <div className="mission-strip">
        <small>{drill?'ANCHOR BAY / LIVE DRILL':out?`QUARANTINE / THREAT ${String(out.phase).padStart(2,'0')}`:s.mode==='atlas'?'OPEN ATLAS / FREE ROAM':s.chapter<s.total?`OPERATION ${String(s.chapter+1).padStart(2,'0')} / ${String(s.total).padStart(2,'0')}`:'CAMPAIGN COMPLETE'}</small>
        <h2>{s.title}</h2><p>{s.objective}</p>
        {s.distance !== null && <span className="hud-distance"><Icon name="cross"/> {s.distance} m</span>}
        {s.special && <strong className="special-status">{s.special}</strong>}
        {out&&<span className="beacon-status" aria-label={`${out.beacons} of 3 beacons restored`}><i className={out.beacons>0?'lit':''}/><i className={out.beacons>1?'lit':''}/><i className={out.beacons>2?'lit':''}/>{out.beacons} / 3 BEACONS</span>}
        {drill&&<span className="drill-hud-score">{drill.total} / {drill.goal} {drill.id==='spar'?'ROUNDS':'TARGETS'} {drill.id==='materials'?` / ${drill.glass} GLASS`:drill.id==='spar'?` / ${drill.blocks} GUARDS`:''}</span>}
        {s.job && <span className="contract-state">CONTRACT / {s.job}</span>}
        {s.faction&&s.faction.standing!=='Neutral'&&!s.room&&<span className="contract-state">{s.faction.team.toUpperCase()} / {s.faction.standing.toUpperCase()}</span>}
      </div>
    </div>
    <div className="hud-vitals hud-corner">
      <div className="wallet"><span>{drill?<>{Math.ceil(drill.time)}<small> SEC</small></>:out?<>{number(out.score)}<small> PTS</small></>:`$${number(s.cash)}`}</span><button type="button" className="hud-icon" aria-label="Pause game" onClick={() => game.open('pause')}><Icon name="pause"/></button></div>
      <div className="vitals-bars">
        <span className="health"><Icon name="heart"/><i role="meter" aria-label="Health" aria-valuenow={s.health} aria-valuemin={0} aria-valuemax={100}><b style={{ width: `${s.health}%` }}/></i><small>{s.health}</small></span>
        <span className="armor"><Icon name="shield"/><i role="meter" aria-label="Armor" aria-valuenow={s.armor} aria-valuemin={0} aria-valuemax={100}><b style={{ width: `${s.armor}%` }}/></i><small>{s.armor}</small></span>
        {s.stamina < 98 && !s.vehicle && <span className="energy"><Icon name="dash"/><i><b style={{ width: `${s.stamina}%` }}/></i><small>{s.stamina}</small></span>}
      </div>
      {out?<div className="noise-meter" role="meter" aria-label="Noise" aria-valuenow={out.noise} aria-valuemin={0} aria-valuemax={100}><span>NOISE</span><i><b style={{width:`${out.noise}%`}}/></i><small>{out.noise>50?'LOUD':'LOW'}</small></div>:!drill&&<div className="stars" aria-label={`Wanted level ${s.heat} of 5`}>
        {s.heat > 0 && <small>{s.alert}</small>}
        {[1,2,3,4,5].map(n => <Icon key={n} name="star" className={n <= s.heat ? 'wanted-on' : ''}/>)}
      </div>}
    </div>
    {s.note && <div key={s.note.title + s.note.message} className={`game-notice ${s.note.tone}`} role="status"><strong>{s.note.title}</strong><span>{s.note.message}</span></div>}
    <div className="hud-bottom-left hud-corner">
      {s.line && <div key={s.line.line} className="dialogue"><strong>{s.line.speaker}</strong><p>{s.line.line}</p></div>}
      <button type="button" className={`hud-instrument${contact.label?' weapon-live':''}`} onClick={() => game.open(s.vehicle ? 'phone' : 'wheel')} aria-label={s.vehicle ? 'Open phone radio' : 'Open weapon wheel'}>
        <Icon name={s.vehicle ? 'car' : 'gun'}/>
        <div><span>{s.vehicle?s.vehicle:weapon.name}</span><small>{s.vehicle?`${s.integrity}% INTEGRITY${s.armored?' / FIRE TO PULSE':s.altitude!==null?` / ALT ${s.altitude}`:''}`:contact.label||`${contact.mode}${weapon.mag?' / '+weapon.ammo:''}`}</small></div>
        <strong className={!s.vehicle&&weapon.mag&&s.ammo<1?'empty-ammo':''}>{s.vehicle ? <>{s.speed}<small> KM/H</small></> : weapon.mag ? <>{s.ammo}<small> / {s.store}</small></> : 'CC'}</strong>
        {!s.vehicle&&contact.progress!==null&&<i className="contact-progress" aria-hidden="true" style={{width:`${contact.progress*100}%`}}/>}
      </button>
      {station && <button type="button" className="hud-radio" onClick={() => game.action('radio')} aria-label="Cycle radio station"><Icon name="radio"/><b>{station.dial}</b><span>{station.name}</span></button>}
      {out&&<div className="survival-gear"><button type="button" className="hud-radio decoy-readout" aria-label="Throw a noisemaker" disabled={!s.decoys||Boolean(s.room)||Boolean(s.vehicle)} onClick={()=>game.action('throw-decoy')}><Icon name="dash"/><b>{s.decoys}</b><span>Decoy</span><kbd>{s.keys.utility}</kbd></button><button type="button" className="hud-radio decoy-readout" aria-label="Place a barricade" disabled={!s.boards||Boolean(s.room)||Boolean(s.vehicle)} onClick={()=>game.action('barricade')}><Icon name="shield"/><b>{s.boards}</b><span>Board</span><kbd>{s.keys.barricade}</kbd></button></div>}
    </div>
    <div className="hud-bottom-right hud-corner">
      {drill?<button className="bay-open" type="button" onClick={()=>game.open('practice')}><Icon name="cross"/> Drills <kbd>{s.keys.phone}</kbd></button>:<>
      <button className="minimap-button" type="button" onClick={() => game.open('map')} aria-label="Open city map">
        <canvas id="harbor-minimap" width="196" height="138" aria-hidden="true"/><span className="map-north">N</span><span className="map-tag">{s.regionName.toUpperCase()}</span>
      </button>
      <div className="hud-tools">
        <button type="button" onClick={() => game.open('map')}><Icon name="map"/><span>Map</span><kbd>{s.keys.map}</kbd></button>
        <button type="button" onClick={() => game.open('phone')}><Icon name="phone"/><span>Phone</span><kbd>{s.keys.phone}</kbd></button>
      </div>
      </>}
    </div>
    <div className="hud-context">
    {s.hotwire ? <div className="timing-prompt">
        <span>{s.hotwire.mode === 'car' ? 'FREQUENCY LOCK' : 'SOFT RESET'}</span>
        <div className="timing-track"><b style={{ left: `${(s.hotwire.zone - .145) * 100}%` }}/><i style={{ left: `${s.hotwire.needle * 100}%` }}/></div>
        <p><kbd>{actionKey}</kbd> {s.hotwire.help || 'Match the highlighted band'}</p>
    </div> : s.prompt ? s.photoJob&&s.prompt==='Capture landmark in Photo mode'?<button type="button" className="use-prompt" onClick={()=>game.action('photo-compose')}><Icon name="photo"/>{s.prompt}</button>:<div key={s.prompt} className="use-prompt"><kbd>{actionKey}</kbd><span>{s.prompt}</span></div> : s.tutorial && <div className="tutorial-tip"><Icon name={s.pad === 'GAMEPAD' ? 'gamepad' : 'keyboard'}/><span className="move-keys">{s.pad === 'GAMEPAD' ? 'Left stick to move' : `${s.keys.up} ${s.keys.left} ${s.keys.down} ${s.keys.right} to move`}</span><span className="move-touch">Use the arrows</span><i/> Look for the pink Vanta</div>}
    </div>
    <Touch game={game} visible={touch}/>
  </div>;
}

function Touch({ game, visible }: { game: GameAPI; visible: boolean }) {
    const rows = [['up','arrow','Move up'],['left','arrow','Move left'],['down','arrow','Move down'],['right','arrow','Move right'],['use','door','Interact'],['fire','cross','Fire'],['dash','dash','Dodge or handbrake'],['heal','heart','Use medkit'],['focus','shield','Brace or guard'],['reload','back','Reload']];
  return <div className={`touch-inputs ${visible ? 'touch-on' : ''}`}>
    {rows.map(([action, icon, label]) => <button type="button" className={`touch-${action}`} key={action} aria-label={label}
      onPointerDown={event => { event.currentTarget.setPointerCapture(event.pointerId); game.input.virtual(action, true); }}
      onPointerUp={() => game.input.virtual(action, false)} onLostPointerCapture={() => game.input.virtual(action, false)} onPointerCancel={() => game.input.virtual(action, false)}><Icon name={icon}/></button>)}
  </div>;
}