import { useCallback, useEffect, useRef, useState } from 'react';
import { HarborGame, readBest, readSave, readSettings, saveSettings } from './game/game.js';
import { MODES } from './game/data.js';
import { Soundscape } from './game/audio.js';
import { mountVista } from './game/vista.js';
import { mountMonsoonVista } from './game/monsoon-vista.js';
import { mountBayVista } from './game/bay-vista.js';
import { mountAtlasVista } from './game/atlas-vista.js';
import { atlasConfig } from './game/atlas-runtime.js';
import { BrandMark, Icon, TitleMark } from './ui/icons';
import { Action, GamePanel, Guide, LoadMenu, Modal, Options } from './ui/Panels';
import { Hud } from './ui/Hud';
import { WorldGuide } from './ui/WorldGuide';
import { AtlasConfigurator } from './ui/Atlas';
import type { AtlasSetup, BestRun, GameAPI, GameMode, RecordData, Settings, Snapshot } from './ui/types';

const LOADING_TIPS = ['Pink diamonds mark the next operation.', 'Brake before a wet corner, then get back on the throttle.', 'Press F6 to save a local checkpoint.', 'Leave a patrol\'s line of sight to lose its signal.'];
const EDITIONS:GameMode[]=['atlas','campaign','monsoon','outbreak','practice'];
const DEFAULT_MODE:GameMode=new URLSearchParams(window.location.search).get('mode')==='monsoon'?'monsoon':'atlas';

export default function App() {
  const [settings, setSettings] = useState<Settings>(() => readSettings());
  const [phase, setPhase] = useState<'title' | 'loading' | 'play'>('title');
  const [panel, setPanel] = useState<string | null>(null);
  const [state, setState] = useState<Snapshot | null>(null);
  const [mode,setMode]=useState<GameMode>(DEFAULT_MODE);
  const [record,setRecord]=useState<RecordData|null>(()=>readSave(DEFAULT_MODE));
  const [atlasCity,setAtlasCity]=useState('mirage');
  const [best,setBest]=useState<BestRun>(()=>readBest());
  const [session,setSession]=useState(0);
  const [error, setError] = useState('');
  const game = useRef<GameAPI | null>(null);
  const worldCanvas = useRef<HTMLCanvasElement>(null), vistaCanvas = useRef<HTMLCanvasElement>(null);
  const source=useRef<RecordData|null>(null),latest=useRef(settings),atlasOptions=useRef(null as ReturnType<typeof atlasConfig>|null);
  const menuPad = useRef({ buttons: [] as boolean[], direction: 0 });
  const sound = useRef<{ start(): void; play(name: string): void; updateSettings(state: Settings): void } | null>(null);
  if (!sound.current) sound.current = new Soundscape(settings);

  const change = useCallback((next: Settings) => {
    latest.current = next; setSettings(next); saveSettings(next); sound.current?.updateSettings(next); game.current?.setSettings(next);
  }, []);
  const begin = useCallback((stored: RecordData | null) => {
    sound.current?.start(); sound.current?.play('confirm');
    source.current = stored; setPanel(null); setState(null); setSession(n=>n+1); setPhase('loading'); setError('');
  }, []);
  const launchAtlas=(setup:AtlasSetup)=>{atlasOptions.current=atlasConfig(setup);begin(null);};
  const openTitle = (next: string) => {
    if(next==='load'||next==='new'||next==='atlas-setup')setRecord(readSave(mode));
    sound.current?.start(); sound.current?.play('click'); setPanel(next);
  };
  const newGame=()=>{if(mode==='atlas'){openTitle('atlas-setup');return;}if(readSave(mode))openTitle('new');else begin(null);};
  const goTitle = () => { setPanel(null); setState(null); setRecord(readSave(mode));setBest(readBest());setPhase('title'); };
  const selectMode=(next:GameMode)=>{if(next===mode)return;setMode(next);setRecord(readSave(next));sound.current?.start();sound.current?.play('click');};
  const dismiss = useCallback(() => {
    if (game.current) {if(panel==='outbreak-end'&&state?.outbreak?.dead)return;game.current.open(panel === 'settings' || panel === 'guide' ? 'pause' : null);}
    else { sound.current?.play('click'); setPanel(null); }
  }, [panel,state?.outbreak?.dead]);

  useEffect(() => {
    const canvas=vistaCanvas.current;
    if((phase==='title'||phase==='loading')&&canvas)return mode==='atlas'?mountAtlasVista(canvas,settings.motion,atlasCity==='basin'):(mode==='practice'?mountBayVista:mode==='campaign'?mountVista:mountMonsoonVista)(canvas,settings.motion);
  }, [phase,settings.motion,mode,atlasCity]);
  useEffect(() => {
    if (phase !== 'loading') return;
    const timer = window.setTimeout(() => setPhase('play'), 640);
    return () => window.clearTimeout(timer);
  }, [phase]);
  useEffect(() => {
    if (phase !== 'play' || !worldCanvas.current) return;
    let instance: GameAPI;
    try {const s=source.current,q=atlasOptions.current;instance=new HarborGame(worldCanvas.current,latest.current,sound.current,setState,setPanel,s||(mode==='atlas'&&q?{seed:q.seed,style:q.style,start:q.start,worldKey:q.key}:null),mode);}
    catch { setError('Canvas 2D could not be initialized. Try a current browser with Canvas enabled.'); setPhase('title'); return; }
    game.current = instance;
    return () => { instance.dispose(); if (game.current === instance) game.current = null; };
  }, [phase,mode,session]);
  useEffect(() => {
    if (!panel) return;
    const key = (e: KeyboardEvent) => {
      if (e.code === 'Escape' || (phase === 'play' && e.code === (settings.bindings.pause || 'Escape'))) { e.preventDefault(); dismiss(); }
      if (panel === 'map' && e.code === (settings.bindings.map || 'KeyM')) { e.preventDefault(); dismiss(); }
      if (panel === 'wheel' && e.code === (settings.bindings.wheel || 'KeyQ')) { e.preventDefault(); dismiss(); }
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [panel, phase, dismiss, settings.bindings]);

  // Menus share a simple directional focus model with standard-mapped controllers.
  useEffect(() => {
    if (phase === 'loading' || (phase === 'play' && !panel)) return;
    let frame = 0;
    const poll = () => {
      let pad: Gamepad | null | undefined;
      try { pad = Array.from(navigator.getGamepads?.() || []).find(Boolean); } catch { pad = null; }
      if (pad) {
        const down = (i: number) => Boolean(pad?.buttons[i]?.pressed);
        const step = down(13) || down(15) || (pad.axes[0] || 0) > .55 || (pad.axes[1] || 0) > .55 ? 1 : down(12) || down(14) || (pad.axes[0] || 0) < -.55 || (pad.axes[1] || 0) < -.55 ? -1 : 0;
        const range = panel ? (document.querySelector('.terminal-modal') || document.querySelector('.photo-toolbar')) : document.querySelector('.title-page');
        const controls = Array.from(range?.querySelectorAll<HTMLElement>('button:not(:disabled),select,input') || []).filter(n => n.offsetWidth && n.offsetHeight);
        let at = controls.indexOf(document.activeElement as HTMLElement);
        const previous = menuPad.current;
        menuPad.current = { buttons: pad.buttons.map(b => b.pressed), direction: step };
        if (step && step !== previous.direction && controls.length) {
          at = at < 0 ? (step > 0 ? 0 : controls.length - 1) : ((at + step + controls.length) % controls.length);
          controls[at].focus();
        }
        if (down(0) && !previous.buttons[0]) { if (at >= 0) controls[at].click(); else (range?.querySelector<HTMLElement>('[data-primary]') || controls[0])?.click(); }
        if (panel && down(1) && !previous.buttons[1]) dismiss();
        if (phase === 'title' && !panel && down(9) && !previous.buttons[9]) (range?.querySelector<HTMLElement>('[data-primary]'))?.click();
      }
      frame = requestAnimationFrame(poll);
    };
    frame = requestAnimationFrame(poll);
    return () => cancelAnimationFrame(frame);
  }, [phase, panel, dismiss]);

  const options = panel === 'settings' && <Options value={settings} change={change} close={dismiss}/>;
  const guide = panel === 'guide' && <Guide close={dismiss} play={phase === 'title' ? newGame : undefined} mode={mode}/>;
  const mood = ` edition-${mode}${settings.crt ? ' crt-on' : ''}${!settings.motion ? ' no-motion' : ''}${settings.contrast ? ' high-contrast' : ''}`;

  if (phase === 'play') return <main className={`play-page${mood}`} aria-label="Static Harbor game">
    <canvas className="world-canvas" ref={worldCanvas} aria-label={`${MODES[mode].name} gameplay canvas`}/>
    {state && game.current && panel !== 'photo' && <div inert={Boolean(panel)}><Hud state={state} game={game.current} touch={settings.touch}/></div>}
    {options}{guide}
    {panel && !options && !guide && state && game.current && <GamePanel key={panel} panel={panel} state={state} game={game.current} close={dismiss} title={goTitle} practice={()=>{game.current?.save(true);setMode('practice');begin(null);}} restart={()=>begin(null)} retry={()=>begin(readSave(mode))}/>}
  </main>;

  return <div className={`title-page${mood}`} id="title">
    <header className="page-header" inert={Boolean(panel) || phase === 'loading'}>
      <div className="brand"><BrandMark/><span>STATIC <b>HARBOR</b></span></div>
      <nav className="top-nav" aria-label="Game menu">
        <button type="button" className="top-link" onClick={() => openTitle('guide')}><Icon name="book"/><span>Field Guide</span></button>
        <button type="button" className="top-link" onClick={() => openTitle('settings')}><Icon name="gear"/><span>Settings</span></button>
        <div className="top-divider"/>
        <button type="button" className="audio-toggle" aria-label={settings.muted ? 'Unmute audio' : 'Mute audio'} aria-pressed={settings.muted} title={settings.muted ? 'Unmute audio' : 'Mute audio'} onClick={() => { sound.current?.start(); change({ ...settings, muted: !settings.muted }); if (settings.muted) sound.current?.play('click'); }}><Icon name={settings.muted ? 'mute' : 'volume'}/></button>
      </nav>
    </header>
    <main className="title-stage" aria-label="Static Harbor title screen">
      <canvas ref={vistaCanvas} className="harbor-vista" aria-hidden="true"/>
      <div className="stage-shade"/>
      <div key={mode} className="hero-content" inert={Boolean(panel) || phase === 'loading'}>
        <p className="hero-kicker mono"><i/> {mode==='atlas'?'WORLD EXPANSION / OPEN EXPLORATION':mode==='monsoon'?'THE DHAKA-INSPIRED EXPANSION':mode==='outbreak'?'AN ALTERNATE SURVIVAL MODE':mode==='practice'?'THE CONTACT UPDATE / PRACTICE':'AN OPEN-WORLD ACTION GAME'}</p>
        <TitleMark mode={mode}/>
        <p className="hero-copy">{mode==='atlas'?<>From glass towers to desert neon.<br/>Four cities, with a frontier beyond the last exit.</>:mode==='monsoon'?<>From the painted rickshaw lanes to the river.<br/>Eight jobs. One city to reconnect.</>:mode==='outbreak'?<>The Quiet are following the noise.<br/>Restore three beacons and catch the last ferry.</>:mode==='practice'?<>Learn the timing in three hands-on drills.<br/>Your campaign saves stay untouched.</>:<>One stolen signal. A city wired to burn.<br/>The night is yours to rewrite.</>}</p>
        <div className="hero-actions">
          <button data-primary type="button" className="action-button is-primary hero-play" onClick={newGame}><Icon name="play"/><span>{mode==='atlas'?'Explore the Atlas':mode==='outbreak'?'Start Survival':mode==='practice'?'Enter the Bay':'New Game'}</span></button>
          {mode==='practice'?<Action className="hero-load" icon="book" onClick={()=>openTitle('guide')}>Field Manual</Action>:<Action className="hero-load" icon="folder" onClick={() => openTitle('load')}>Load Game</Action>}
        </div>
        <div className="input-hints mono">{mode==='outbreak'?<span><Icon name="chart"/> PERSONAL BEST / {best.score.toLocaleString('en-US')} PTS</span>:<><span><Icon name="keyboard"/> KEYBOARD + MOUSE</span><i/><span><Icon name="gamepad"/> GAMEPAD SUPPORT</span></>}</div>
        {mode==='atlas'&&<div className="atlas-sky-switch" role="group" aria-label="Preview city"><button type="button" aria-pressed={atlasCity==='mirage'} onClick={()=>setAtlasCity('mirage')}>01 <span>Mirage Coast</span></button><button type="button" aria-pressed={atlasCity==='basin'} onClick={()=>setAtlasCity('basin')}>02 <span>Neon Basin</span></button></div>}
        {error && <p className="launch-error" role="alert">{error}</p>}
      </div>
      {phase==='loading'&&<div className="launch-screen" role="status"><BrandMark/><span className="mono">{mode==='atlas'?'CHARTING A NEW ROUTE':mode==='outbreak'?'EMERGENCY BAND / LIVE':mode==='practice'?'BAY CONTROL / LIVE':'ACQUIRING CITY SIGNAL'}</span><strong>{mode==='atlas'?'Opening the Atlas':mode==='outbreak'?'Into the quarantine':mode==='monsoon'?'Entering Monsoon City':mode==='practice'?'Opening the Training Bay':'Entering Vesper Bay'}</strong><div className="loading-line"><i/></div><p>{mode==='atlas'?'Press M to switch between regional and local charts.':mode==='outbreak'?'Footsteps, horns and weapons draw the Quiet.':mode==='monsoon'?'Open the atlas with M for bridge and metro routes.':mode==='practice'?'Hold right mouse or X to brace or guard.':LOADING_TIPS[(source.current?.chapter||0)%LOADING_TIPS.length]}</p></div>}
    </main>
    <footer className="page-footer mono" inert={Boolean(panel)||phase==='loading'}>
      <span className="online"><i/> <span className="online-caption">SYSTEM ONLINE</span></span>
      <nav className="edition-nav" aria-label="Game modes" inert={Boolean(panel)||phase==='loading'}>
        {EDITIONS.map(key=><button key={key} type="button" aria-pressed={mode===key} className={`edition-button mode-${key}`} onClick={()=>selectMode(key)}><Icon name={MODES[key].icon}/><span>{MODES[key].name}</span></button>)}
      </nav>
      <a className="build-id field-jump" href="#world-notes"><span>BUILD 4.0.0</span><Icon name="chevron"/></a>
    </footer>
    <div inert={Boolean(panel)||phase==='loading'}><WorldGuide/></div>
    {options}{guide}
    {panel==='atlas-setup'&&<Modal title="Chart a New World" tag="OPEN ATLAS / FIELD SURVEY" onClose={dismiss}><AtlasConfigurator start={atlasCity} change={setAtlasCity} launch={launchAtlas} hasSave={Boolean(record)}/></Modal>}
    {panel === 'load' && <LoadMenu mode={mode} record={record} load={() => record && begin(record)} start={newGame} close={dismiss}/>}
    {panel === 'new' && <Modal title="Start a New Game?" tag={`${MODES[mode].name.toUpperCase()} / RESET CHECKPOINT`} onClose={dismiss}>
      <p className="terminal-lead">This replaces only the {MODES[mode].name} checkpoint. Your other modes are safe.</p>
      <div className="button-row"><Action primary icon="play" onClick={() => begin(null)}>Start over</Action><Action onClick={dismiss}>Cancel</Action></div>
    </Modal>}
  </div>;
}