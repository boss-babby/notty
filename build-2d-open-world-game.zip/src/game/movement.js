import { angleDiff, clamp, dist, mix, unit } from './core.js';
import { GEAR } from './data.js';
import { profile } from './contact.js';

function blockedLine(g,p,n){
  if(g.room)return !g.roomLine(p,n);
  return !g.city.line(p.x,p.y,n.x,n.y);
}

function chooseAssist(g,a,wide){
  const p=g.player, c=g.contact;
  let choice=null, best=Infinity;
  for(const n of g.people.items){
    if(!n.active||n.dead||n.indoor!==Boolean(g.room)||!['enemy','officer','infected','target','spar','rival'].includes(n.type))continue;
    const d=dist(p,n);if(d>315)continue;
    const angle=Math.atan2(n.y-p.y,n.x-p.x), turn=Math.abs(angleDiff(a,angle));
    if(turn>(wide?Math.PI:.37)||blockedLine(g,p,n))continue;
    const cost=turn*(wide?24:240)+d*.55-(n.id===c.lock?26:0);
    if(cost<best){best=cost;choice={id:n.id,a:angle};}
  }
  c.lock=choice?.id||null;return choice?.a??a;
}

function lifeClear(g,x,y,r){
  if(g.room){const b=g.interior.bounds;if(x-r<b.x||y-r<b.y||x+r>b.right||y+r>b.bottom)return false;}
  else if(g.city.water(x,y))return false;
  return !g.block(x,y,r);
}

function tryVault(g,p,x,y){
  const q=g.block(p.x+x*21,p.y+y*21,p.r*.65);
  if(q?.type!=='prop'||q.solid||q.kind==='barrel'||q.hp<=0)return false;
  for(let d=53;d<=82;d+=7){
    const ex=p.x+x*d,ey=p.y+y*d;
    if(lifeClear(g,ex,ey,p.r)){
      for(let k=8;k<d;k+=8){const wall=g.block(p.x+x*k,p.y+y*k,p.r*.75,true);if(wall&&wall!==q)return false;}
      p.vault={x:p.x,y:p.y,ex,ey,time:0,total:.31};g.hear('vault',p.x,p.y,.76);return true;
    }
  }
  return false;
}

export function moveOnFoot(g,dt){
  const p=g.player,i=g.input,c=g.contact,h=profile(g), w=GEAR[g.weapon];
  const [ax,ay,rx,ry]=i.axes;
  const dx=(i.held('right')?1:0)-(i.held('left')?1:0)+ax, dy=(i.held('down')?1:0)-(i.held('up')?1:0)+ay;
  const length=Math.min(1,Math.hypot(dx,dy)), moving=length>.08;
  let [ux,uy]=unit(dx,dy);
  p.swim=!g.room&&g.city.water(p.x,p.y);p.cover=!p.swim&&Boolean(i.held('cover'));
  p.coverObject=p.cover?g.block(p.x,p.y,21):null;
  p.protected=Boolean(p.coverObject);
  const defensive=i.held('focus')&&!p.swim&&!p.vault&&p.dodge<=0;
  const guarding=defensive&&w.style==='melee'&&!c.swing;
  c.guard=mix(c.guard,Number(guarding),Math.min(1,dt*17));
  c.guardAge=guarding?c.guardAge+dt:0;
  c.aim=mix(c.aim,defensive&&!guarding?1:p.protected?.48:0,Math.min(1,dt*(h.carry&&h.carry<.65?3.7:7.9)));
  p.sprint=Boolean(i.held('sprint')&&p.stamina>3&&!p.cover&&!p.swim&&moving&&!defensive&&!c.reload&&!c.heal&&!c.swing&&!c.throwing);
  let a=p.a;
  if(Math.hypot(rx,ry)>.2){a=Math.atan2(ry,rx);i.mouse.active=false;}
  else if(i.mouse.active){const aim=g.aimWorld();if(dist(aim,p)>3)a=Math.atan2(aim.y-p.y,aim.x-p.x);}
  else if(moving&&!guarding&&!c.aim)a=Math.atan2(uy,ux);
  if(g.settings.assist&&(i.pad||i.touch.has('fire'))&&(i.fire||defensive)){
    if(g.clock>(c.assistAt||0)){
      c.assistAt=g.clock+.105;c.assistAngle=chooseAssist(g,a,i.touch.has('fire'));
    }
    if(c.lock!=null&&Number.isFinite(c.assistAngle))a+=angleDiff(a,c.assistAngle)*(i.touch.has('fire')?.93:.63);
  }else c.lock=null;
  if(c.swing)a=c.swing.angle;
  if(c.throwing)a=c.throwing.angle;
  const rate=i.mouse.active?42:19;
  p.a+=clamp(angleDiff(p.a,a),-dt*rate,dt*rate);

  const cost=g.perks.includes('quick-step')?13:18;
  if(i.hit('dash')&&p.stamina>=cost&&!p.swim&&p.dodge<=0&&!p.vault){
    const vx=moving?ux:Math.cos(p.a),vy=moving?uy:Math.sin(p.a);
    p.stamina-=cost;c.reload=null;g.pendingReload=0;c.heal=null;c.swing=null;c.throwing=null;
    c.aim=0;c.guard=0;
    if(!tryVault(g,p,vx,vy)){p.dodge=.29;p.dashTime=0;p.dashX=vx;p.dashY=vy;g.hear('roll',p.x,p.y,.74);}
    if(g.practice)g.practice.rolls++;
  }
  p.stamina=clamp(p.stamina+(p.swim?-6.5:p.sprint?-20+Math.min(g.skills.stamina*.16,6)+(g.perks.includes('long-stride')?3:0):guarding?8:24)*dt,0,100);
  if(p.swim&&p.stamina<=.1&&g.clock-(p.lastDrown||0)>.8){p.lastDrown=g.clock;g.playerHurt(10);}
  if(p.sprint)g.skills.stamina+=dt*.37;if(p.cover&&moving)g.skills.stealth+=dt*.17;
  const oldX=p.x,oldY=p.y;
  if(p.vault){
    const v=p.vault;v.time+=dt;const u=clamp(v.time/v.total,0,1),x=mix(v.x,v.ex,u),y=mix(v.y,v.ey,u);
    g.move(p,x-p.x,y-p.y,p.r,true);
    p.lift=Math.sin(u*Math.PI)*18;
    if(u===1){p.vault=null;p.lift=0;g.hear('landing',p.x,p.y,.65);}
  }else{
    p.lift=0;
    let speed=p.swim?64:p.cover?60:i.held('walk')?63:p.sprint?185:113;
    if(defensive)speed*=guarding?.70:h.carry||.84;
    if(c.reload||c.heal)speed*=.70;
    if(c.swing||c.throwing)speed*=.53;
    if(p.flinch>0)speed*=.74;
    speed*=length;
    let vx=ux*speed,vy=uy*speed;
    if(p.dodge>0){p.dashTime+=dt;p.dodge=Math.max(0,p.dodge-dt);const pace=227+Math.sin(clamp(p.dashTime/.29,0,1)*Math.PI)*37;vx=p.dashX*pace;vy=p.dashY*pace;}
    else {p.dashTime=0;}
    p.driveX=mix(p.driveX||0,vx,1-Math.exp(-dt*(p.swim?7.5:moving?20:24)));
    p.driveY=mix(p.driveY||0,vy,1-Math.exp(-dt*(p.swim?7.5:moving?20:24)));
    p.impactX=(p.impactX||0)*Math.exp(-dt*13);p.impactY=(p.impactY||0)*Math.exp(-dt*13);
    g.move(p,((p.dodge>0?vx:p.driveX)+p.impactX)*dt,((p.dodge>0?vy:p.driveY)+p.impactY)*dt,p.r);
  }
  p.vx=(p.x-oldX)/dt;p.vy=(p.y-oldY)/dt;
  const traveled=Math.hypot(p.x-oldX,p.y-oldY);
  if(traveled>.065){
    p.moveAngle=Math.atan2(p.vy,p.vx);p.stride+=traveled*.157;p.foot-=dt;g.stats.walked+=traveled;
    if(p.foot<=0){
      const wet=g.weather===1||g.weather===3;
      const step=p.swim?'water':g.room?'step-room':!g.city.road(p.x,p.y)&&['park','field','parkland','oasis','juniper'].includes(g.city.at(p.x,p.y)?.type)?'grass':wet?'step-wet':'step';
      if(!p.swim)g.signalNoise(p.cover?39:p.sprint?202:83,p,'step');
      g.hear(step,p.x,p.y,p.cover?.36:p.sprint?.83:.60);
      p.foot=p.sprint?.255:p.swim?.42:p.cover?.41:.34;
      if((p.swim||wet&&!g.room)&&g.settings.quality!=='Low')g.fx(p.x,p.y,'#a8c7d3',p.swim?3:2,23,'drop');
    }
  }else p.stride=mix(p.stride,Math.round(p.stride/Math.PI)*Math.PI,dt*8);
}