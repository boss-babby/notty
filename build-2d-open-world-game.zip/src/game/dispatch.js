import { CELL, modelIndex } from './data.js';
import { angleDiff, clamp, dist, mix, unit } from './core.js';
import { closestJunction, regionOf, roadConnection } from './geography.js';
import { districtOf, isRoad } from './world.js';
import { clearSegment, freeNear, landAt, localPath, streetRoute } from './navigation.js';

export const isUnit=v=>v.mode==='cruiser'||v.mode==='swat'||v.mode==='military'||v.mode==='patrol';
const cardinal=[[1,0],[0,1],[-1,0],[0,-1]];
const wheel=[1,-1,2,-2,0,3];
const bearing=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);

function approachPoints(g,where){
  const q=closestJunction(where,g.city.seed,g.city.style),result=[];
  for(let i=0;i<4;i++){
    const [dx,dy]=cardinal[i],x=q.x+dx,y=q.y+dy;
    if(roadConnection(q.x,q.y,x,y,g.city.seed,g.city.style))result.push({x:x*CELL,y:y*CELL,side:i,dx,dy});
  }
  return result;
}

export function pointClear(g, x, y, r=8){
  return landAt(g,x,y,r)&&!g.cars.some(v=>!v.wreck&&Math.hypot(v.x-x,v.y-y)<v.r+r+5);
}

function receive(v, order, point, stop=20){
  const previous=v.order;
  if(!previous || previous.kind!==order || dist(previous,point)>92){v.path=null;v.nextRoute=0;v.routeIndex=0;}
  v.order={kind:order,x:point.x,y:point.y,stop};
}

function spawn(g, addCar, level, incident){
  const p=g.outside||g.player,q=closestJunction(incident,g.city.seed,g.city.style),candidates=[];
  for(let i=0;i<4;i++){
    const [dx,dy]=cardinal[i];
    for(let n=1;n<=2;n++){
      const xx=q.x+dx*n, yy=q.y+dy*n;
      if(!roadConnection(xx,yy,xx-dx,yy-dy,g.city.seed,g.city.style))break;
      const x=xx*CELL-dx*77+dy*19, y=yy*CELL-dy*77-dx*19, d=Math.hypot(x-p.x,y-p.y);
      if(d<256||d>1080||!pointClear(g,x,y,21))continue;
      const near=g.cars.filter(v=>isUnit(v)&&!v.wreck).reduce((m,v)=>Math.min(m,Math.hypot(v.x-x,v.y-y)),840);
      if(near<187)continue;
      let score=near*.84-Math.abs(550-d)*.43;
      if(i===g.dispatch.lastSide)score-=260;
      candidates.push({x,y,score,side:i,a:Math.atan2(-dy,-dx)});
    }
  }
  const c=candidates.sort((a,b)=>b.score-a.score)[0];if(!c)return false;
  g.dispatch.lastSide=c.side;
  const mode=level>=5?'military':level>=4?'swat':'cruiser';
  const model=level>=5?(regionOf(c.x,c.y)==='monsoon'?modelIndex('bastion'):5):level>=4?4:8;
  const v=addCar(g,model,c.x,c.y,c.a,mode,{dispatch:true,approachSide:c.side,radioChirp:.58});
  receive(v,'respond',incident,65);return true;
}

export function ambientPatrol(g, addCar){
  if(g.outbreak||g.heat>0||g.room||g.cars.some(v=>isUnit(v)&&!v.wreck)||g.clock<(g.dispatch?.patrolAt||18))return;
  const p=g.player;
  const candidates=approachPoints(g,p).filter(d=>dist(d,p)>330&&dist(d,p)<790&&pointClear(g,d.x,d.y,20));
  const entry=candidates[Math.floor(g.rand()*candidates.length)];
  if(!g.dispatch)g.dispatch=createDispatch();
  g.dispatch.patrolAt=g.clock+24;
  if(entry){const v=addCar(g,8,entry.x,entry.y,Math.atan2(-entry.dy,-entry.dx),'patrol',{siren:false});choosePatrol(g,v,true);}
}

function choosePatrol(g,v,patrol=false){
  const p=g.outside||g.player,q=closestJunction(v,g.city.seed,g.city.style),dirs=cardinal.filter(([dx,dy])=>roadConnection(q.x,q.y,q.x+dx,q.y+dy,g.city.seed,g.city.style));
  const choices=dirs.map(([dx,dy])=>({x:(q.x+dx)*CELL,y:(q.y+dy)*CELL}));
  if(!choices.length){v.discardAt=g.clock+2;return;}
  choices.sort((a,b)=>patrol?Math.abs(dist(a,p)-490)-Math.abs(dist(b,p)-490):dist(b,p)-dist(a,p));
  receive(v,patrol?'patrol':'return',choices[v.id%Math.min(patrol?3:1,choices.length)],18);
}

export const createDispatch=()=>({lastSide:-1, leader:null, nextOrder:0, nextSight:0, velocity:{x:0,y:0}, huntFrom:0, nextLocal:0, patrolAt:18, stage:'PATROL'});

// Dispatch updates slower than the simulation. One car is the lead; every other car has an independent road goal.
export function updateDispatch(g,dt,addCar){
  const d=g.dispatch ||= createDispatch(), p=g.player, outside=g.outside||p, level=Math.ceil(g.heat);
  if(!d.perceptionAt||dist(outside,d.perceptionAt)>48){d.nextSight=0;d.perceptionAt={x:outside.x,y:outside.y};}
  const units=g.cars.filter(v=>isUnit(v)&&!v.wreck&&v!==g.car);
  if(!level){
    g.seen=false;g.sinceSeen=0;g.blockade=[];g.heli=null;d.leader=null;d.stage='PATROL';
    for(const v of units){v.siren=false;v.saw=false;if(v.mode!=='patrol'&&v.order?.kind!=='return')choosePatrol(g,v);}
    g.nearestSiren=g.car?.siren?g.car:null;return;
  }
  const blackout=g.blackout?.zone===g.city.zone(outside.x,outside.y);
  if(g.clock>=d.nextSight){
    d.nextSight=g.clock+.115;
    let seen=false;
    for(const v of units){
      const r=dist(v,outside), cone=Math.abs(angleDiff(v.a,bearing(v,outside)));
      v.saw=!g.room&&!blackout&&r<(g.weather===2?178:282)&&(r<51||cone<1.03)&&g.city.line(v.x,v.y,p.x,p.y);
      if(v.saw)seen=true;
    }
    if(!g.room&&!blackout)for(const n of g.people.items){
      if(!n.active||n.dead||n.type!=='officer'||n.indoor)continue;
      const r=dist(n,p);if(r<159&&(r<43||Math.abs(angleDiff(n.a,bearing(n,p)))<1.09)&&g.city.line(n.x,n.y,p.x,p.y)){seen=true;break;}
    }
    d.groundSight=seen;
  }
  let seen=!g.room&&!blackout&&d.groundSight;
  if(level>=4&&!g.room){
    const at=g.lastSeen;
    const h=g.heli ||= {x:at.x-220,y:at.y-185,beamX:at.x-130,beamY:at.y-48,charge:0};
    const t=g.clock*.68;
    h.x=mix(h.x,at.x+Math.cos(t)*174,dt*.8);h.y=mix(h.y,at.y+Math.sin(t)*137-51,dt*.8);
    h.beamX=mix(h.beamX,h.x+Math.sin(t*1.29)*88,dt*1.8);h.beamY=mix(h.beamY,h.y+69+Math.sin(t+2)*49,dt*1.8);
    if(!blackout&&dist({x:h.beamX,y:h.beamY},p)<45&&g.city.road(p.x,p.y)){seen=true;h.charge=Math.min(1,h.charge+dt*2.5);}
    else h.charge=Math.max(0,h.charge-dt*1.65);
  }else g.heli=null;
  if(seen){
    if(!g.seen)d.huntFrom=g.clock;
    g.lastSeen={x:p.x,y:p.y};g.sinceSeen=0;
    d.velocity={x:g.car?.vx||p.vx||0,y:g.car?.vy||p.vy||0};
  }else if(g.seen){d.nextOrder=0;d.huntFrom=g.clock;}
  g.seen=Boolean(seen);if(!g.seen)g.sinceSeen+=dt;
  d.stage=g.seen?'PURSUIT':g.sinceSeen>3.2?'SECTOR SEARCH':'RESPONDING';
  if(g.sinceSeen>(blackout?2.4:7+level*1.8)){
    const old=g.heat;g.heat=Math.max(0,g.heat-dt*((blackout||g.room) ? .31 : .15));
    if(old>0&&g.heat<=0){g.stats.escapes++;g.report('Grid dispatch calls off its search.');g.notify('Signal lost','You are off the grid.','ok');}
  }
  const assigned=units.filter(v=>v.order?.kind!=='return'||v.mode==='patrol');
  g.policeTimer-=dt;
  if(!g.room&&g.policeTimer<=0){
    if(assigned.length<Math.min(6,level+1)&&g.sinceSeen<7.2)g.policeTimer=spawn(g,addCar,level,g.lastSeen)?4.6-level*.41:.9;
    else g.policeTimer=.8;
  }
  let sound=g.car?.siren?g.car:null, near=sound?0:690;
  for(const v of g.cars)if(v.siren&&!v.wreck&&v!==g.car&&dist(v,outside)<near){near=dist(v,outside);sound=v;}
  g.nearestSiren=g.room?null:sound;
  if(g.clock>=d.nextOrder){
    d.nextOrder=g.clock+.52;
    const at=g.lastSeen,junctions=approachPoints(g,at),next={x:at.x+d.velocity.x*1.65,y:at.y+d.velocity.y*1.65};
    const squad=units.filter(v=>dist(v,g.seen?outside:at)<1080);
    let lead=squad.find(v=>v.id===d.leader&&v.order?.kind!=='dismount');
    const contender=squad.filter(v=>v.order?.kind!=='dismount').sort((a,b)=>(dist(a,at)-(a.saw?78:0))-(dist(b,at)-(b.saw?78:0)))[0];
    if(!lead||contender&&contender.saw&&!lead.saw&&dist(lead,at)>dist(contender,at)+70)lead=contender;
    d.leader=lead?.id||null;
    if(lead)receive(lead,g.seen?'lead':g.sinceSeen<4.8?'respond':'search',g.sinceSeen<4.8||g.seen?at:junctions[(Math.floor(g.sinceSeen/4)+lead.id)%junctions.length]||at,g.seen?(g.car?42:71):36);
    const second=squad.filter(v=>v!==lead&&v.order?.kind!=='dismount');
    const sorted=[...junctions].sort((a,b)=>dist(a,next)-dist(b,next));
    for(const [i,v] of second.entries()){
      const choice=sorted[(i+(g.seen?0:Math.floor(g.sinceSeen/4)))%sorted.length];
      const angle=wheel[i%wheel.length]*1.18;
      const point=choice?{x:choice.x-choice.dx*(89+(i>=4?97:0)),y:choice.y-choice.dy*(89+(i>=4?97:0))}:freeNear(g,{x:at.x+Math.cos(angle)*161,y:at.y+Math.sin(angle)*161},v.r)||at;
      const hold=g.seen&&i===1&&level>=3;
      receive(v,g.seen?hold?'hold':'intercept':'sweep',point,hold?22:31);
      v.siren=g.seen&&v.order.kind!=='hold';
    }
    if(lead)lead.siren=g.seen||g.sinceSeen<2;
    if(level>=3&&!g.room&&(!g.blockade.length||g.blockade.every(b=>dist(b,at)>810)||level>=4&&!g.blockade.some(b=>b.kind==='spikes'))){
      const side=sorted.find(x=>dist(x,at)>210)||sorted[0];
      if(side){const x=side.x-side.dx*114,y=side.y-side.dy*114;g.blockade=[-17,17].map((n,i)=>({x:x-side.dy*n,y:y+side.dx*n,a:Math.atan2(side.dy,side.dx),kind:i===1&&level>=4?'spikes':'barrier'}));}
    }
    if(level<3||g.room)g.blockade=[];
  }
}

export function driveUnit(g,v,dt,addPerson,damage){
  const p=g.player, d=g.dispatch ||= createDispatch();
  if(!v.order)choosePatrol(g,v,v.mode==='patrol');
  if(!v.order)return;
  if(v.radioChirp>0){v.radioChirp-=dt;if(v.radioChirp<=0){g.hear('radio-tick',v.x,v.y,.72);}}
  let target=v.order; const r=v.r+1;
  let away=dist(v,target);
  if(v.order.kind==='dismount'){
    const officer=g.people.items.find(n=>n.id===v.partner&&n.active&&!n.dead);
    if(!officer||g.car&&dist(v,p)>182||!g.heat){v.order=null;v.nextRoute=0;choosePatrol(g,v,v.mode==='patrol');if(!v.order)return;target=v.order;away=dist(v,target);}
    else{v.speed=0;v.vx=v.vy=0;v.siren=false;v.brake=true;return;}
  }
  if(g.heat>1.01&&g.seen&&!g.car&&v.saw&&dist(v,p)<121&&away<153&&!v.partner&&v.speed<89){
    const q=freeNear(g,{x:v.x-Math.sin(v.a)*26,y:v.y+Math.cos(v.a)*26},9,65);
    if(q){const n=addPerson(g,'officer',q.x,q.y,{hp:v.mode==='cruiser'?70:v.mode==='swat'?116:134,armor:v.mode==='cruiser'?0:v.mode==='swat'?32:44,color:v.mode==='military'?'#a7b48e':'#7f9dc2',dispatchOfficer:true,detailClass:v.mode});
      if(n){v.partner=n.id;g.hear('door',v.x,v.y);receive(v,'dismount',v,4);v.speed=0;v.vx=v.vy=0;return;}}
  }
  if(away<25&&(target.kind==='patrol'||target.kind==='return'||target.kind==='sweep'||target.kind==='search')){
    if(target.kind==='patrol'||target.kind==='return')choosePatrol(g,v,target.kind==='patrol');
    else {v.scanAt ||=g.clock+1.9;v.a+=dt*.75;if(v.scanAt<g.clock){g.dispatch.nextOrder=0;v.scanAt=0;}}
  }
  let point=target;
  if(away<240&&g.clock>=(v.nextLine||0)){
    v.nextLine=g.clock+.22;v.direct=clearSegment(g,v,target,r);
  }
  if(away>=240||!v.direct){
    if(!v.path||g.clock>=(v.nextRoute||0)&&(v.jam>.34||v.routeIndex>=v.path.length)){
      v.nextRoute=g.clock+1.55+(v.id%8)*.11;
      if(away>265)v.path=streetRoute(g,v,target,r,regionOf(v.x,v.y)==='monsoon'?-14:17);
      else v.path=localPath(g,v,target,r,470);
      v.routeIndex=0;
    }
    while(v.path?.[v.routeIndex]&&dist(v,v.path[v.routeIndex])<27)v.routeIndex++;
    point=v.path?.[v.routeIndex]||target;
    if(away>72&&v.jam>.43&&g.clock>d.nextLocal){
      d.nextLocal=g.clock+.13;
      const local=localPath(g,v,point,r,590);
      if(local.length){v.path=[...local,...(v.path||[]).slice(v.routeIndex+1)];v.routeIndex=0;point=v.path[0];}
    }
  }else v.path=null;
  const [ux,uy]=unit(point.x-v.x,point.y-v.y);
  let sx=ux,sy=uy, speedCap=Infinity;
  for(const other of g.cars){
    if(other===v||other===g.car&&target.kind==='lead')continue;
    const dx=other.x-v.x,dy=other.y-v.y,q=dx*dx+dy*dy;
    if(q<1||q>128**2)continue;
    const rr=Math.sqrt(q), ahead=dx*ux+dy*uy, side=dx*uy-dy*ux, min=v.r+other.r+7;
    if(ahead>0&&ahead<92&&Math.abs(side)<min*.91){
      speedCap=Math.min(speedCap,Math.max(0,((ahead-min-6)*2.55)+(other.vx*ux+other.vy*uy)*.59));
      const sign=Math.abs(side)>3?Math.sign(side):v.id%2?1:-1;
      sx-=uy*sign*.7*(1-ahead/112);sy+=ux*sign*.7*(1-ahead/112);
    }
    if(rr<min+15){const push=(1-rr/(min+16))*.88;sx-=dx/rr*push;sy-=dy/rr*push;}
  }
  const desired=Math.atan2(sy,sx), turn=angleDiff(v.a,desired);
  let maximum=target.kind==='lead'?(g.car?274:187):target.kind==='patrol'?86:target.kind==='return'?120:target.kind==='intercept'?228:159;
  if(away<target.stop)maximum=0;
  else if(away<target.stop+104)maximum=Math.min(maximum,(away-target.stop)*2.75);
  const reverse=v.reverseUntil>g.clock;
  if(!reverse&&v.jam>.98){v.reverseUntil=g.clock+.46;v.recovery=v.id%2?1:-1;v.jam=.11;v.path=null;}
  if(reverse){v.a+=dt*1.75*v.recovery;maximum=-64;}
  else{v.a+=clamp(turn,-dt*4.2,dt*4.2);maximum=Math.min(speedCap,maximum*(1-.74*clamp(Math.abs(turn)/1.7,0,1)));}
  const speed=mix(v.vx*Math.cos(v.a)+v.vy*Math.sin(v.a),maximum,Math.min(1,dt*(maximum===0?6.7:3.4)));
  v.vx=Math.cos(v.a)*speed;v.vy=Math.sin(v.a)*speed;v.brake=Math.abs(speed)>maximum+17||maximum===0;v.speed=Math.abs(speed);
  const x=v.x,y=v.y, nx=x+v.vx*dt,ny=y+v.vy*dt;
  let hit=false;
  // A hard occupancy test prevents overlap even when several vehicles arrive on the same frame.
  for(const other of g.cars){
    if(other===v)continue;
    const min=v.r+other.r+3;
    if((other.x-nx)**2+(other.y-ny)**2<min*min&&(other.x-nx)**2+(other.y-ny)**2<(other.x-x)**2+(other.y-y)**2){hit=true;break;}
  }
  if(!hit && landAt(g,nx,ny,r)){v.x=nx;v.y=ny;}else{v.vx*=.26;v.vy*=.26;}
  if(away>target.stop+32&&Math.hypot(v.x-x,v.y-y)<dt*18)v.jam=(v.jam||0)+dt;
  else v.jam=Math.max(0,(v.jam||0)-dt*1.5);
  if(g.seen&&g.car&&target.kind==='lead'&&dist(v,g.car)<r+g.car.r+6&&v.contact<=0&&v.speed>42){v.contact=.85;damage(g,g.car,5);g.bump(2);}
}