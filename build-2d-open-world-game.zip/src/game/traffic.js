import { CELL } from './data.js';
import { angleDiff, clamp, dist, mix } from './core.js';
import { regionOf, roadConnection } from './geography.js';
import { signalAt } from './world.js';
import { originalCell } from './frontier-geo.js';

const DIR=[[1,0],[-1,0],[0,1],[0,-1]];

export function setRoad(v,dx,dy,ix=Math.round(v.x/CELL),iy=Math.round(v.y/CELL)){
  if(dx>0&&v.x>ix*CELL)ix++;if(dx<0&&v.x<ix*CELL)ix--;
  if(dy>0&&v.y>iy*CELL)iy++;if(dy<0&&v.y<iy*CELL)iy--;
  v.road={dx,dy,ix,iy,turn:0,commit:false};
}

function turnAt(g,v,q,threat){
  const key=`${q.ix}:${q.iy}`, remembered=v.followVehicle?.turnLog?.get(key);
  if(remembered&&roadConnection(q.ix,q.iy,q.ix+remembered[0],q.iy+remembered[1],g.city.seed,g.city.style))return remembered;
  const options=DIR.filter(([x,y])=>(x!==-q.dx||y!==-q.dy)&&roadConnection(q.ix,q.iy,q.ix+x,q.iy+y,g.city.seed,g.city.style));
  if(!options.length)return [-q.dx,-q.dy];
  if(threat)return options.sort(([ax,ay],[bx,by])=>((v.x-threat.x)*(bx-ax)+(v.y-threat.y)*(by-ay)))[0];
  return options[Math.floor(g.rand()*options.length)];
}

function laneFree(g,v,dx,dy,offset){
  for(const k of [14,34,53]){
    const x=v.x+dx*k-dy*offset,y=v.y+dy*k+dx*offset;
    if(!g.city.road(x,y)||g.city.block(x,y,v.r*.87,true)||g.cars.some(o=>o!==v&&o.alt<18&&Math.hypot(o.x-x,o.y-y)<o.r+v.r+2))return false;
  }
  return true;
}

export function updateTraffic(g,v,dt){
  if(!v.road){const dx=Math.abs(Math.cos(v.a))>=.707?Math.sign(Math.cos(v.a)):0;setRoad(v,dx,dx?0:Math.sign(Math.sin(v.a))||1);}
  const q=v.road, ix=q.ix*CELL,iy=q.iy*CELL;
  let {dx,dy}=q;
  const offset=regionOf(v.x,v.y)==='monsoon'?-15:originalCell(Math.floor(v.x/CELL),Math.floor(v.y/CELL))?21:9, distance=(ix-v.x)*dx+(iy-v.y)*dy;
  const p=g.player, car=g.car, playerRide=car||p;
  let threat=null;
  if(!g.room&&dist(v,playerRide)<155){
    const px=playerRide.x-v.x,py=playerRide.y-v.y,closing=(playerRide.vx||0)*dx+(playerRide.vy||0)*dy-v.speed;
    const reckless=car&&car.speed>101&&(Math.abs(px*dy-py*dx)<57||Math.hypot(px,py)<82);
    if(reckless||g.alarm>0&&Math.hypot(px,py)<129)threat=playerRide;
    if(threat&&g.clock>(v.reactAt||0)){
      v.reactAt=g.clock+.37;v.threatTime=g.clock+1.6;
      const s=px*dy-py*dx>0?1:-1,lane=s*(closing<0?8:14);
      v.avoid=laneFree(g,v,dx,dy,lane)?lane:laneFree(g,v,dx,dy,-lane)?-lane:0;
      if(v.horn<=0){g.hear('horn',v.x,v.y,.48);v.horn=2.8+v.id%3*.23;}
    }
  }
  const emergency=v.mode==='runner'||v.serviceLights, target=Math.min(v.model.max*.9,emergency?(v.runnerSpeed||104):(v.cruise||96));
  let desired=target;
  const inside=distance<13&&distance>-32;
  if(distance>54)q.commit=false;
  if(inside)q.commit=true;
  if(!q.commit&&distance>9&&distance<152){
    const light=regionOf(v.x,v.y)==='wilds'||signalAt(ix,iy,g.clock,Boolean(dx));
    const cross=g.cars.some(o=>o!==v&&!o.wreck&&o.alt<18&&Math.hypot(o.x-ix,o.y-iy)<39&&Math.abs(Math.cos(o.a)*dx+Math.sin(o.a)*dy)<.63);
    if(!light&&!emergency||cross)desired=Math.min(desired,Math.max(0,(distance-35)*2.05));
  }
  let queue=false;
  for(const other of g.cars){
    if(other===v||other.alt>18)continue;
    const rx=other.x-v.x,ry=other.y-v.y;
    if(Math.abs(rx)>135||Math.abs(ry)>135)continue;
    const ahead=rx*dx+ry*dy, side=ry*dx-rx*dy, gap=(other.model.l+v.model.l)*.40+5;
    if(ahead>0&&ahead<110&&Math.abs(side)<(v.model.w+other.model.w)*.43){
      const ov=(other.vx||0)*dx+(other.vy||0)*dy;
      const safe=Math.max(0,ov*.71+(ahead-gap)*2.58);
      if(safe<desired){desired=safe;queue=true;}
      if(other===car&&desired<21&&v.horn<=0){g.hear('horn',v.x,v.y,.56);v.horn=3.2;}
    }
  }
  if(!car&&!g.room&&dist(v,p)<64){
    const px=p.x-v.x,py=p.y-v.y,ahead=px*dx+py*dy;
    if(ahead>0&&Math.abs(py*dx-px*dy)<v.model.w*.6){desired=Math.min(desired,Math.max(0,(ahead-23)*2.85));queue=true;}
  }
  if(v.threatTime>g.clock&&v.avoid&&!queue){desired=Math.min(desired,target*.86);v.trafficState='EVASIVE';}
  else v.trafficState=queue?'YIELD':desired<target*.46?'WAIT':'CRUISE';
  if(v.hp<15&&emergency)desired=0;
  const previous=v.speed;
  v.speed=mix(v.speed,desired,Math.min(1,dt*(desired<v.speed?4.7:2.28)));v.brake=v.speed<previous-1.6||desired<15;
  if(distance<1){
    const next=turnAt(g,v,q,threat);
    if(v.turnLog){v.turnLog.set(`${q.ix}:${q.iy}`,next);if(v.turnLog.size>12)v.turnLog.delete(v.turnLog.keys().next().value);}
    q.dx=dx=next[0];q.dy=dy=next[1];q.ix+=dx;q.iy+=dy;q.turn=.3;q.commit=false;
    v.signal=Math.sign(dx*Math.sin(v.a)-dy*Math.cos(v.a));
  }
  q.turn-=dt;if(q.turn<-.68)v.signal=0;
  const extra=v.threatTime>g.clock&&laneFree(g,v,dx,dy,v.avoid||0)?v.avoid||0:0;
  v.lateral=mix(v.lateral||0,extra,Math.min(1,dt*(v.threatTime>g.clock?5:2.7)));
  const shift=offset+v.lateral, centerX=(q.ix-dx)*CELL-dy*shift,centerY=(q.iy-dy)*CELL+dx*shift;
  let vx=dx*v.speed+(!dx?clamp((centerX-v.x)*4,-72,72):0),vy=dy*v.speed+(!dy?clamp((centerY-v.y)*4,-72,72):0);
  if(v.speed<.5){vx*=.15;vy*=.15;}
  const x=v.x+vx*dt,y=v.y+vy*dt;
  if(g.city.water(x,y)&&!g.city.water(v.x,v.y)){setRoad(v,-dx,-dy);v.speed*=.44;return;}
  for(const o of g.cars){
    if(o===v||o.alt>18||Math.abs(o.x-x)>64||Math.abs(o.y-y)>64)continue;
    const rr=(v.r+o.r+3)**2,rx=o.x-x,ry=o.y-y,ox=o.x-v.x,oy=o.y-v.y;
    if(rx*rx+ry*ry<rr&&rx*rx+ry*ry<ox*ox+oy*oy){v.speed*=.63;v.vx=v.vy=0;v.trafficState='YIELD';return;}
  }
  if(!g.room&&!g.car&&v.speed>70&&v.contact<=0&&Math.hypot(p.x-x,p.y-y)<v.r+5){
    v.contact=.82;g.playerHurt(Math.min(21,7+v.speed*.075),{kind:'collision',source:v});
  }
  v.x=x;v.y=y;v.vx=vx;v.vy=vy;
  const angle=Math.atan2(vy,vx);
  if(Math.abs(vx)+Math.abs(vy)>4)v.a+=angleDiff(v.a,angle)*Math.min(1,dt*7);
}