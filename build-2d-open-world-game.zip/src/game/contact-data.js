// All distances, timings and forces are game-feel values for fictional equipment.
export const HANDLING = {
  hands:   { mode:'MELEE', cue:'Quick chain', width:.79, wind:.12, recover:.22, cost:6, weight:1, length:7 },
  bat:     { mode:'MELEE', cue:'Wide swing', width:1.15, wind:.22, recover:.39, cost:12, weight:.94, length:14 },
  blade:   { mode:'MELEE', cue:'Fast recovery', width:.62, wind:.105, recover:.21, cost:8, weight:.98, length:7 },
  pistol:  { mode:'SEMI', cue:'Tap to fire', speed:1120, kick:.32, calm:3.5, carry:.88, length:13, load:'mag', hue:'#ffc999' },
  smg:     { mode:'AUTO', cue:'Hold to fire', speed:1080, kick:.22, calm:2.5, carry:.91, length:17, load:'mag', hue:'#f4bc99' },
  shotgun: { mode:'PUMP', cue:'Loads one shell at a time', speed:890, kick:.81, calm:2.75, carry:.76, length:23, load:'tube', hue:'#ffbc91' },
  rifle:   { mode:'AUTO', cue:'Settle for tighter groups', speed:1390, kick:.42, calm:2.55, carry:.75, length:23, load:'mag', hue:'#f5c895' },
  sniper:  { mode:'SINGLE', cue:'Brace to steady aim', speed:1810, kick:.79, calm:2.25, carry:.57, length:27, load:'single', hue:'#e7c5a4' },
  grenade: { mode:'THROW', cue:'Bounces before pulsing', speed:240, kick:0, calm:3.7, carry:.84, length:8, load:'throw', wind:.22 },
  molotov: { mode:'THROW', cue:'Breaks on contact', speed:232, kick:0, calm:3.7, carry:.82, length:8, load:'throw', wind:.23 },
  rocket:  { mode:'SINGLE', cue:'Slow and heavy', speed:414, kick:.96, calm:2.05, carry:.59, length:25, load:'single', hue:'#ffc17f' },
};

export const MATERIALS = {
  glass: { tint:'#a7e2e1', dark:'#4a777f', sound:'glass', mark:'chip', style:'shard' },
  stone: { tint:'#d0ada0', dark:'#594752', sound:'stone', mark:'pit', style:'dust' },
  wood:  { tint:'#d2a27c', dark:'#594248', sound:'wood-hit', mark:'splinter', style:'splinter' },
  metal: { tint:'#ffd595', dark:'#554655', sound:'metal', mark:'dent', style:'glint' },
  cloth: { tint:'#d4a5b6', dark:'#674750', sound:'body', mark:'scuff', style:'dust' },
  armor: { tint:'#b4cffb', dark:'#666080', sound:'armor', mark:'dent', style:'glint' },
  target:{ tint:'#a7e2c4', dark:'#4b786f', sound:'plate', mark:'dent', style:'glint' },
  quiet: { tint:'#b7c893', dark:'#54634f', sound:'body', mark:'scuff', style:'dust' },
};

export function materialOf(q) {
  if(q.material)return q.material;
  if(q.type==='car'||['sign','fence','barrel','foam','gate'].includes(q.kind||q.t))return 'metal';
  if(['crate','barricade','desk','bench','counter','shelf','kitchen','lowtable','tablegame'].includes(q.kind||q.t))return 'wood';
  if(['sofa','bed','hospitalbed'].includes(q.t))return 'cloth';
  return 'stone';
}