import { angleDiff, clamp, dist, mix, unit } from './core.js';
import { isWater, roadPath } from './world.js';
import { clearSegment, freeNear, landAt, localPath } from './navigation.js';

const fan=[0,.37,-.37,.76,-.76,1.18,-1.18,1.57,-1.57,2.38,-2.38,Math.PI];
const lanes=[0,1,-1,2,-2,3,-3,4];
const targetAngle=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);
export const noiseHistory=()=>({events:[],seq:0});

export function makeNoise(o, point, radius, kind){
  o.acoustic ||=noiseHistory();
  const a=o.acoustic, now=o.clock, previous=a.events.at(-1);
  if(previous?.kind===kind&&now-previous.at<.2&&dist(previous,point)<26)return;
  a.events.push({x:point.x,y:point.y,radius,at:now,seq:++a.seq,kind});
  if(a.events.length>14)a.events.shift();
}

function heard(g,n,b){
  const o=g.outbreak;
  let best=null, score=0;
  for(const sound of o.acoustic.events){
    const time=o.clock-sound.at;
    if(sound.seq<=b.lastSound||time>4.6)continue;
    const d=dist(n,sound);if(d>=sound.radius)continue;
    const clear=g.city.line(n.x,n.y,sound.x,sound.y);
    const radius=(clear?1:.56)*sound.radius*(1-time*.125);
    const value=radius-d+(sound.kind==='vehicle'?-20:0);
    if(value>score){best=sound;score=value;}
  }
  return best;
}

function remember(b,kind,p,until){
  if(!b.memory||b.state!==kind||dist(b.memory,p)>43)b.path=null;
  b.memory={x:p.x,y:p.y};b.state=kind;b.until=until;
}

export function thinkQuiet(g,n,p,dt){
  const o=g.outbreak, t=o.clock, fast=n.variantZ==='runner', heavy=n.variantZ==='brute', d=dist(n,p);
  const b=n.brain ||= {state:'roam',senseAt:0,until:0,lastSound:0,path:null,index:0,planAt:0,vx:0,vy:0,attack:null,home:{x:n.x,y:n.y},slot:lanes[n.id%lanes.length]};
  n.cd-=dt;n.hit-=dt;
  if(t>=b.senseAt){
    b.senseAt=t+.13+(n.id%7)*.018;
    const look=targetAngle(n,p), fog=g.weather===2?.76:1;
    const radius=(p.cover?92:190)*(fast?1.26:heavy?.9:1)*fog;
    const seen=d<radius&&(d<39||Math.abs(angleDiff(n.a,look))<(b.state==='chase'?1.55:1.04))&&g.city.line(n.x,n.y,p.x,p.y);
    b.sees=seen;
    if(seen){remember(b,'chase',p,t+(fast?4.3:6.5));b.heading=g.car?g.car.a:p.moveAngle??p.a;}
    else{
      const signal=heard(g,n,b);
      if(signal){b.lastSound=signal.seq;remember(b,'listen',signal,t+(heavy?11:8));b.heading=targetAngle(n,signal);}
      else if(b.memory&&(t>b.until||dist(n,b.memory)<19&&b.state!=='scan')){
        if(t<=b.until){b.state='scan';b.until=t+1.8+(n.id%3)*.3;b.scanFace=n.a;b.path=null;}
        else {b.memory=null;b.state='roam';b.path=null;b.probeAt=0;}
      }
    }
  }
  n.alert=b.state==='roam'?0:Math.max(.1,b.until-t);
  if(b.attack){
    const a=b.attack;a.time-=dt;n.a+=clamp(angleDiff(n.a,a.a),-dt*3.1,dt*3.1);
    b.vx*=.84;b.vy*=.84;
    if(!a.hit&&a.time<=(heavy?.15:.12)){
      a.hit=true;
      const range=(heavy?32:fast?27:24)+(g.car?g.car.r*.64:0);
      if(d<range&&!isWater(p.x,p.y)&&Math.abs(angleDiff(a.a,targetAngle(n,p)))<1.05&&g.city.line(n.x,n.y,p.x,p.y)){
         if(g.car)g.damageRide(heavy?34:fast?11:7);else g.playerHurt(heavy?23:fast?13:10,{kind:'melee',source:n});
        g.hear('growl',n.x,n.y,.62);
      }
    }
    if(a.time<=0){b.attack=null;n.cd=heavy?1.38:fast?.8:1.12;}
    return;
  }
  const startRange=(heavy?28:fast?23:20)+(g.car?g.car.r*.64:0);
  if(b.sees&&d<startRange&&n.cd<=0&&!isWater(p.x,p.y)&&g.city.line(n.x,n.y,p.x,p.y)){
    b.attack={time:heavy?.69:fast?.37:.51,a:targetAngle(n,p),hit:false};
    if(heavy)g.hear('growl',n.x,n.y,.43);
    return;
  }
  let destination=b.memory;
  if(destination&&b.sees&&d>45&&d<220){
    const angle=targetAngle(n,destination), side=b.slot*(fast?13:8)*(d/200);
    const lead=fast?Math.min(33,d*.19):0;
    const q={x:destination.x+Math.cos(b.heading||angle)*lead-Math.sin(angle)*side,y:destination.y+Math.sin(b.heading||angle)*lead+Math.cos(angle)*side};
    if(landAt(g,q.x,q.y,n.r,true))destination=q;
  }
  if(b.state==='scan'){
    n.a+=dt*(b.slot<0?-1:1)*1.5;
    return;
  }
  if(!destination){
    if(!b.probe||t>(b.probeAt||0)||dist(n,b.probe)<13){
      const a=(n.drift||0)+n.id*.27+t*.55;
      b.probe=freeNear(g,{x:b.home.x+Math.cos(a)*83,y:b.home.y+Math.sin(a)*83},n.r,58)||b.home;b.probeAt=t+3.1;
    }
    destination=b.probe;
  }
  const to=dist(n,destination), navR=Math.max(4,n.r-1);
  if(heavy&&b.memory&&n.cd<=0){
    const a=targetAngle(n,destination), prop=g.city.block(n.x+Math.cos(a)*(navR+10),n.y+Math.sin(a)*(navR+10),8,true);
    if(prop?.kind==='barricade'){g.breakProp(prop,24,'world');n.cd=.81;b.path=null;g.hear('wood',n.x,n.y,.8);return;}
  }
  if(b.memory&&to>26&&t>=b.planAt&&o.routeBudget<=0){
    b.planAt=t+(fast?.84:1.24)+(n.id%14)*.04;
    const direct=to<345&&clearSegment(g,n,destination,navR,true);
    if(direct)b.path=null;
    else{
      const last=b.path?.at(-1);
      if(!last||dist(last,destination)>88||b.index>=b.path.length||n.stuck>.3){
        const way=to>515?roadPath(n,destination,g.city.seed,g.city.style).find(p=>dist(n,p)>54)||destination:destination;
        b.path=localPath(g,n,way,navR,fast?695:825,true);b.index=0;o.routeBudget=.065;
      }
    }
  }
  while(b.path?.[b.index]&&dist(n,b.path[b.index])<13)b.index++;
  const q=b.path?.[b.index]||destination;
  const speed=(b.memory?(fast?141:heavy?57:78):22)*(n.hit>0?.64:1);
  let wanted=targetAngle(n,q), sx=0,sy=0;
  for(const other of g.people.items){
    if(other===n||!other.active||other.dead||other.type!=='infected')continue;
    const xx=n.x-other.x,yy=n.y-other.y,m=xx*xx+yy*yy,min=n.r+other.r+7;
    if(m>1&&m<min*min){const d2=Math.sqrt(m),f=(min-d2)/min;sx+=xx/d2*f;sy+=yy/d2*f;}
  }
  if(Math.abs(sx)+Math.abs(sy)>.01)wanted=Math.atan2(Math.sin(wanted)+sy*.7,Math.cos(wanted)+sx*.7);
  const look=Math.max(12,speed*.16), preference=n.id%2===0?-1:1;
  let steer=null;
  for(const delta of fan){
    const a=wanted+delta*preference,x=n.x+Math.cos(a)*look,y=n.y+Math.sin(a)*look;
    if(landAt(g,x,y,navR,true)&&landAt(g,n.x+(x-n.x)*.47,n.y+(y-n.y)*.47,navR,true)){steer=a;break;}
  }
  if(steer===null||to<7){n.stuck+=dt;b.vx*=.8;b.vy*=.8;n.a+=dt*.9;return;}
  let scale=1;
  if(b.sees&&d<startRange+10)scale=.33;
  b.vx=mix(b.vx,Math.cos(steer)*speed*scale,dt*8.7);b.vy=mix(b.vy,Math.sin(steer)*speed*scale,dt*8.7);
  const x=n.x,y=n.y;
  if(!isWater(x+b.vx*dt,y+b.vy*dt))g.city.move(n,b.vx*dt,b.vy*dt,navR,true);
  const movement=Math.hypot(n.x-x,n.y-y);
  if(movement<dt*7)n.stuck+=dt;else n.stuck=Math.max(0,n.stuck-dt*2.2);
  if(movement>.08){n.a+=clamp(angleDiff(n.a,Math.atan2(n.y-y,n.x-x)),-dt*8,dt*8);n.stride+=movement*.19;}
}