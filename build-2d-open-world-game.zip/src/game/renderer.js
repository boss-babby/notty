import { CELL, DISTRICTS, place } from './data.js';
import { clamp, hash, mix, angleDiff, mod, TAU, rng } from './core.js';
import { districtOf, signalAt } from './world.js';
import { jobMarker } from './campaign.js';
import { miniMap, primeAtlas } from './maps.js';
import { METRO_LINE, navigable } from './geography.js';
import { BEACONS, CACHES, EVAC } from './outbreak.js';
import { drawBody, drawImpact, drawMote } from './contact-art.js';
import { drawAtlasDetail } from './atlas-detail.js';
import { weaponSpread } from './contact.js';
import { GEAR } from './data.js';
import { streetMarker } from './street-events.js';
import { paintInterior } from './interior-art.js';
import { isUnit } from './dispatch.js';

const canvas2d = (canvas, options) => canvas.getContext('2d', options);
const rect = (c, x, y, w, h, color) => { c.fillStyle = color; c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); };
const shape = (c, color, ...v) => {
  c.fillStyle = color; c.beginPath(); c.moveTo(v[0], v[1]); for (let i = 2; i < v.length; i += 2) c.lineTo(v[i], v[i + 1]); c.closePath(); c.fill();
};
const stroke = (c, color, width, x, y, xx, yy) => {
  c.strokeStyle = color; c.lineWidth = width; c.beginPath(); c.moveTo(x, y); c.lineTo(xx, yy); c.stroke();
};
const oval = (c, x, y, rx, ry, color) => { c.fillStyle = color; c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, TAU); c.fill(); };

export class Renderer {
  constructor(canvas, game) {
    this.canvas = canvas; this.game = game; this.ctx = canvas2d(canvas, { alpha: false }); this.scale = 1;
    if (!this.ctx) throw new Error('Canvas 2D is not available');
    this.lightplane = document.createElement('canvas'); this.lightctx = canvas2d(this.lightplane);
    this.fringe = document.createElement('canvas'); this.halos = new Map(); this.rooms=new Map();this.adaptive = 1; this.nextCheck = 2.5;
    this.headlamp = this.makeHeadlamp();
    if(typeof window.requestIdleCallback==='function')primeAtlas(game.city.seed,game.city.style);
    this.resize = () => this.size();
    window.addEventListener('resize', this.resize);
    const random = rng(11224);
    this.rain = Array.from({ length: 202 }, () => [random(), random(), random(), random()]);
    this.lastMini = -1; this.mininode = null; this.size();
  }
  size() {
    const b = this.canvas.getBoundingClientRect(); this.width = Math.max(1, b.width); this.height = Math.max(1, b.height);
    const dpr = globalThis.devicePixelRatio || 1;
    const q = this.game.settings.quality;
    if (q !== this.quality) { this.quality = q; this.adaptive = 1; this.nextCheck = this.game.clock + 2.5; }
    const budget = q === 'Low' ? 880000 : q === 'Medium' ? 1450000 : 2550000;
    this.dpr = Math.min(q === 'Low' ? 1 : q === 'Medium' ? 1.45 : 2, dpr, Math.sqrt(budget / (this.width * this.height))) * this.adaptive;
    this.canvas.width = Math.round(this.width * this.dpr); this.canvas.height = Math.round(this.height * this.dpr);
    this.lightplane.width = Math.ceil(this.width * .42); this.lightplane.height = Math.ceil(this.height * .42);
    const f = this.fringe, fc = canvas2d(f);
    f.width = Math.max(1, Math.ceil(this.width * .3)); f.height = Math.max(1, Math.ceil(this.height * .3));
    if (fc) {
      const cx = f.width / 2, cy = f.height / 2;
      const gr = fc.createRadialGradient(cx, cy, Math.min(f.width,f.height)*.23, cx, cy, Math.max(f.width,f.height)*.65);
      gr.addColorStop(0,'transparent'); gr.addColorStop(1,'#110b1b8a'); fc.fillStyle=gr; fc.fillRect(0,0,f.width,f.height);
    }
    this.ctx.imageSmoothingEnabled = false; this.dirty = true;
  }
  dispose() { window.removeEventListener('resize', this.resize); }
  screen(x, y) { return [this.width / 2 + (x - this.x) * this.scale, this.height / 2 + (y - this.y) * this.scale]; }
  inView(x, y, spread = 47) { return Math.abs(x - this.x) < this.viewW + spread && Math.abs(y - this.y) < this.viewH + spread; }
  pose(a, alpha) { return [mix(a.ox, a.x, alpha), mix(a.oy, a.y, alpha), a.oa + angleDiff(a.oa, a.a) * alpha]; }
  draw(alpha, fps) {
    if (!this.game.panel && this.game.clock > this.nextCheck) {
      this.nextCheck = this.game.clock + 2.4;
      if (fps < 52 && this.adaptive > .72) { this.adaptive = Math.max(.72, this.adaptive - .14); this.size(); }
    }
    const c = this.ctx, g = this.game, cam = g.camera, w = this.width, h = this.height, d = this.dpr;
    this.dirty = false;
    const shake = g.settings.shake && g.settings.motion && !g.panel ? g.shake : 0;
    this.x = mix(cam.ox, cam.x, alpha) + Math.sin(g.clock * 95) * shake;
    this.y = mix(cam.oy, cam.y, alpha) + Math.cos(g.clock * 73) * shake;
    const lens=g.panel==='photo'?(g.photoZoom||1):g.room?1:[1,1.26,.77][g.view]||1;
    const indoor=g.room&&g.interior.base;
    const fit=indoor?Math.min(w/(indoor.w+62),h/(indoor.h+112)):1;
    this.scale = (indoor?Math.max(.31,Math.min(fit,1.86*cam.zoom)):clamp(w/1050,.91,1.48)*cam.zoom)*lens;
    this.viewW = w / this.scale / 2; this.viewH = h / this.scale / 2;
    c.setTransform(d, 0, 0, d, 0, 0); c.fillStyle = g.room?'#1b1524':'#151420'; c.fillRect(0, 0, w, h);
    c.setTransform(d * this.scale, 0, 0, d * this.scale, d * (w / 2 - this.x * this.scale), d * (h / 2 - this.y * this.scale));
    if (g.room) this.room(c);
    else this.world(c, g);
    if(g.settings.quality!=='Low')for(const s of g.scars.items)if(s.active&&s.room===g.room&&this.inView(s.x,s.y,8))drawImpact(c,s);
    for(const f of g.fires.items)if(f.active&&this.inView(f.x,f.y,45)){
      const r=15+Math.sin(g.clock*8)*2;oval(c,f.x,f.y,r*1.8,r*.9,'#8f5745a3');oval(c,f.x+1,f.y+1,r,r*.59,'#d491685e');
      for(let i=0;i<7;i++){
        const x=f.x+Math.sin(i*7.7+g.clock*5)*r*1.24,y=f.y+Math.cos(i*5.7)*r*.54, ht=3+mod(g.clock*24+i*4,8);
        shape(c,i%3?'#f5ad73':'#f3d895',x-2.8,y+1,x-1,y-ht,x+1.9,y-ht*.52,x+3.1,y+1);
      }
    }
    if(!g.room)for(const v of g.cars)if(v!==g.car&&this.inView(v.x,v.y)){this.car(c,v,alpha);if(g.debug&&isUnit(v)&&v.order)this.unitTrace(c,v);}
    for (const n of g.people.items) if (n.active && n.indoor === Boolean(g.room) && this.inView(n.x, n.y)) this.person(c, n, alpha, false);
    if(!g.car||g.player.vanim)this.person(c,g.player,alpha,true);
    if(!g.room&&g.player.x>5900&&g.player.y<3900&&!g.outbreak)this.metro(c,g.clock);
    for (const p of g.particles.items) if (p.active && this.inView(p.x, p.y, 8)) {
      drawMote(c,p,mix(p.ox,p.x,alpha),mix(p.oy,p.y,alpha));
    }
    for (const b of g.bolts.items) if (b.active && this.inView(b.x, b.y)) {
      const x = mix(b.ox, b.x, alpha), y = mix(b.oy, b.y, alpha);
      if (b.style==='charge'||b.style==='flask') {
        const lift=b.settled?0:Math.max(0,Math.sin(Math.min(b.t/.72,1)*Math.PI))*18;
        oval(c,x+2,y+3,4,2,'#110f18');rect(c,x-2,y-lift-2,4,4,b.style==='flask'?'#eaa59a':'#bfc6a1');
        if(b.style==='charge'&&(g.settings.flashes===false||Math.sin(b.life*22)>-.15))rect(c,x+1,y-lift-3,2,2,'#ffbb8c');
      }else{
        const tint=b.owner==='npc'?'#ff9e9a':'#fbd4a7',step=b.style==='rocket'?.047:.015;
        stroke(c,tint+'70',b.style==='rocket'?4:2.2,x,y,x-b.vx*step,y-b.vy*step);
        stroke(c,tint,b.style==='rocket'?2.3:1,x,y,x-b.vx*step*.67,y-b.vy*step*.67);
        rect(c,x-1,y-1,2,2,'#fff2d3');
      }
    }
    if(!g.room&&g.heli)this.helicopter(c,g.heli);
    if(g.car&&!g.room&&this.inView(g.car.x,g.car.y,120)){
      this.car(c,g.car,alpha);
      if(g.debug&&isUnit(g.car)&&g.car.order)this.unitTrace(c,g.car);
    }
    c.setTransform(d, 0, 0, d, 0, 0);
    this.light(c);
    if (!g.room) this.weather(c);
    this.post(c);
    if(g.car?.model.class==='AIR'&&!g.room&&g.car.alt>8){
      const alt=g.car.alt,bar=Math.min(w*.21,205),x=w*.5,y=h-48;
      c.fillStyle='#1b172ae0';c.fillRect(x-bar/2,y-7,bar,15);
      c.fillStyle=alt>72?'#9ae2c9':'#f1bd8e';c.fillRect(x-bar/2,y-6,bar*clamp(alt/106,0,1),4);
      c.font='700 9px monospace';c.textAlign='center';c.fillStyle='#f4d5b4';c.fillText(`ALT ${Math.round(alt)}  /  AIRSPEED ${Math.round(g.car.speed*.41)}`,x,y+17);
      c.strokeStyle='#bde6d470';c.lineWidth=1;c.beginPath();c.arc(w*.5,h*.5,22,0,TAU);c.moveTo(w*.5-31,h*.5);c.lineTo(w*.5-13,h*.5);c.moveTo(w*.5+13,h*.5);c.lineTo(w*.5+31,h*.5);c.stroke();
    }
    if(g.panel!=='photo'){this.waypoints(c);this.reticle(c);}
    if(g.briefing&&!g.panel){
      const b=g.briefing,t=1-b.time/b.total,fade=clamp(Math.min(t,1-t)*11,0,1),bar=Math.min(58,h*.1)*fade;
      c.fillStyle='#12101c';c.fillRect(0,0,w,bar);c.fillRect(0,h-bar,w,bar);
      if(fade>.7){c.textAlign='center';c.font='700 10px monospace';c.fillStyle='#ebc4b3';c.fillText(`BRIEFING / ${b.title.toUpperCase()}`,w/2,bar*.65);}
    }
    if(g.flight){
      const trip=g.flight,t=trip.time/trip.total,veil=Math.min(1,Math.min(t*8,(1-t)*8));
      c.globalAlpha=veil;c.fillStyle='#171a2a';c.fillRect(0,0,w,h);
      const cx=w*.5,cy=h*.49,ww=Math.min(280,w*.72);
      stroke(c,'#5f657d',1,cx-ww/2,cy,cx+ww/2,cy);stroke(c,'#e0af92',2,cx-ww/2,cy,cx-ww/2+ww*t,cy);
      c.textAlign='center';c.font='700 11px monospace';c.fillStyle='#f0d6ba';c.fillText(trip.type==='air'?'DEPARTURES / AIR LINK':'DEPARTURES / SEA LINK',cx,cy-13);
      c.font='800 15px monospace';c.fillStyle='#e2bfd0';c.fillText(place(trip.destination)?.name.toUpperCase()||'ARRIVAL',cx,cy+26);c.globalAlpha=1;
    }
    if (g.transition) { c.fillStyle = `rgba(11,8,16,${clamp(1 - Math.abs(.32 - g.transition.time) / .32, 0, 1)})`; c.fillRect(0, 0, w, h); }
    if (g.debug && g.panel !== 'photo') {
      const text = `${Math.round(fps)} FPS  /  ${g.city.active.length} CHUNKS  /  ${g.cars.length} CARS  /  ${g.people.items.filter(n => n.active).length} ACTORS`;
      c.font = '11px monospace'; c.textAlign = 'center'; rect(c, w / 2 - 186, 12, 372, 23, '#120d1ade'); c.fillStyle = '#e6ccdf'; c.fillText(text, w / 2, 27);
    }
    this.drawMini();
  }
  reticle(c){
    const g=this.game,p=g.player, a=g.contact;
    if(g.car||g.panel||!g.input.enabled||(!g.input.mouse.active&&!g.input.pad&&!g.input.touch.has('fire')))return;
    const pos=g.input.mouse.active?[g.input.mouse.x,g.input.mouse.y]:this.screen(p.x+Math.cos(p.a)*82,p.y+Math.sin(p.a)*82);
    const [x,y]=pos;
    if(x<0||y<0||x>this.width||y>this.height)return;
    const melee=GEAR[g.weapon].style==='melee', r=melee?5:3.6+Math.min(14,weaponSpread(g)*19);
    const tint=g.settings.contrast?'#ffffca':a.aim>.45?'#c4e6d7a6':'#fde3cecf';
    for(let i=0;i<4;i++){
      const s=i*Math.PI/2,dx=Math.cos(s),dy=Math.sin(s);
      stroke(c,'#1a1428d0',2.8,x+dx*r,y+dy*r,x+dx*(r+5),y+dy*(r+5));
      stroke(c,tint,1,x+dx*r,y+dy*r,x+dx*(r+5),y+dy*(r+5));
    }
    rect(c,x,y,1,1,tint);
    if(a.marker>0){
      c.globalAlpha=Math.min(1,a.marker*8);const col=a.markerKind==='blocked'?'#e9b18a':a.markerKind==='break'?'#a7eade':'#f6cac2';
      if(a.markerKind==='blocked'){c.strokeStyle=col;c.lineWidth=1;c.strokeRect(x-8,y-8,16,16);}
      else for(const s of [1,-1])for(const j of [1,-1])stroke(c,col,1.55,x+s*6,y+j*6,x+s*10,y+j*10);
      c.globalAlpha=1;
    }
  }
  unitTrace(c,v){
    const role=v.order.kind.toUpperCase(), tint=v.order.kind==='lead'?'#ec9fa3':'#a7cee7';
    c.font='700 8px monospace';c.textAlign='center';c.fillStyle=tint;c.fillText(role,v.x,v.y-19);
    if(v.path?.length){c.globalAlpha=.53;c.setLineDash([5,7]);c.strokeStyle=tint;c.lineWidth=1;c.beginPath();c.moveTo(v.x,v.y);for(const p of v.path.slice(v.routeIndex||0))c.lineTo(p.x,p.y);c.stroke();c.setLineDash([]);c.globalAlpha=1;}
  }
  // Paint light sprites once; every lamp then reuses the same soft mask or tint.
  haloSprite(color) {
    if (this.halos.has(color)) return this.halos.get(color);
    const a = document.createElement('canvas'); a.width = a.height = 96;
    const b = canvas2d(a), gr = b.createRadialGradient(48,48,0,48,48,48);
    gr.addColorStop(0, color); gr.addColorStop(.36, color === '#000000' ? '#00000080' : color + '44'); gr.addColorStop(1, 'transparent');
    b.fillStyle=gr; b.fillRect(0,0,96,96); this.halos.set(color,a); return a;
  }
  makeHeadlamp() {
    const a = document.createElement('canvas'); a.width = 128; a.height = 96;
    const b = canvas2d(a), gr=b.createLinearGradient(11,0,128,0);
    gr.addColorStop(0,'#000d'); gr.addColorStop(1,'transparent');
    shape(b,gr,12,35,12,61,128,96,128,0); return a;
  }
  drawMini() {
    const g = this.game;
    if(g.practice)return;
    if (!this.mininode?.isConnected) { this.mininode = document.getElementById('harbor-minimap'); this.lastMini = -1; }
    if (!this.mininode || (g.clock - this.lastMini < .10 && g.room === this.miniRoom && !g.panel)) return;
    if (g.panel && this.lastMini >= 0) return;
    const c = this.mininode.getContext('2d');
    if (c) miniMap(c, g, this.mininode.width, this.mininode.height);
    this.lastMini = g.clock; this.miniRoom = g.room;
  }
  world(c, g) {
    const wet = g.weather === 1 || g.weather === 3;
    const between = (b, pad = CELL / 2) => this.inView(b.x + CELL / 2, b.y + CELL / 2, pad);
    for(const b of g.city.active){
      if(!between(b))continue;
      c.drawImage(g.city.tile(b),b.x,b.y);
      if(b.frontier&&g.settings.quality!=='Low'){
        c.save();c.translate(b.x,b.y);drawAtlasDetail(c,g,b);c.restore();
      }
    }
    if((wet||g.weatherStyle.wet>.11)&&g.settings.quality!=='Low')for(const b of g.city.active){
      if(!between(b))continue;
      for(let i=0;i<5;i++){
        const x=b.x+52+(hash(b.cx,b.cy,29)+i*87)%385,y=b.y+(i%2?22:457);
        if(!this.inView(x,y,24))continue;
        c.globalAlpha=.2+g.weatherStyle.wet*.8;
        oval(c,x+6,y+1,13+i%3*5,2.5,'#29273a68');
        oval(c,x+6,y,11+i%3*5,1.7,i%2?'#be9ba86b':'#a8c1cb49');
        rect(c,x-2+Math.sin(g.clock*2+i)*2,y-1,9+i,1,i%2?'#e9beac68':'#d9eee95c');c.globalAlpha=1;
      }
    }
    for (const b of g.city.active) {
      if (!between(b, CELL / 2 + 33)) continue;
      const x = b.x, y = b.y;
      if(b.type==='canal'||b.type==='pier'||b.east&&['jheel','flats','bazaar'].includes(b.type)||b.frontier&&['marina','islands','sea'].includes(b.type)){
        for (let i = 0; i < 20; i++) {
          const xx = x + 77 + mod(i * 79.3 + g.clock * (i % 2 ? 8 : -6), b.type === 'pier' ? 400 : 328);
          const yy = y + 56 + mod(i * 38.1, 364);
          if(b.frontier?!g.city.water(xx,yy):b.east?!navigable(xx,yy):i%3&&Math.abs(yy-y-221)<18)continue;
          rect(c, xx, yy, i % 4 + 4, 1, i % 3 ? '#8196b14c' : '#b276a361');
        }
      }
      if(x>0&&y>0&&(!b.frontier||['towers','strip','souk','gardens','courts'].includes(b.type)&&b.roads[0]>0&&b.roads[3]>0)){
        for (const [a, side] of [[0,true],[Math.PI/2,false],[Math.PI,true],[-Math.PI/2,false]]) {
          c.save(); c.translate(x, y); c.rotate(a);
          rect(c, -48, -30, 2, 11, '#171622'); rect(c, -48, -30, 3, 4, signalAt(x, y, g.clock, side) ? '#8fe1b0' : '#e884a0');
          rect(c, -51, -17, 2, 40, '#796a7a71'); c.restore();
        }
      }
      if(b.survey&&this.inView(b.survey.x,b.survey.y)){const q=b.survey,done=g.surveys.has(q.id);rect(c,q.x-2,q.y-20,4,3,done?'#9eab94':Math.sin(g.clock*4)>.2?'#f0e4a5':'#b2d6b2');}
      for (const l of b.lights) if (this.inView(l.x, l.y, 69)) {
        const off = g.blackout?.zone === b.zone || g.outbreak&&((b.cx*3+b.cy*7)%5)>1;
        rect(c, l.x - 1, l.y - 9, 2, 12, '#282137'); rect(c, l.x - 4, l.y - 9, 7, 2, off ? '#7a717a' : l.hue);
        if (wet && !off) {
          for (let i = 0; i < (b.east?7:13); i++) {
            const xx = l.x - 24 + mod(i * 9 + l.y, 48), yy = l.y + 4 + mod(i * 19 + l.x, 30);
            rect(c, xx, yy, 3 + i % 7, 1, l.hue + (i % 3 ? '35' : '5d'));
          }
        }
      }
      for (const p of b.props) if (p.hp > 0 && this.inView(p.x,p.y)) this.prop(c,p);
      for(const p of b.panels||[])if(p.hp<=0&&this.inView(p.x,p.y,45))this.pane(c,p);
      if (!g.outbreak&&b.tape && !g.tapes.has(b.tape.id) && this.inView(b.tape.x, b.tape.y)) {
        const l = 2 + Math.sin(g.clock * 4) * 1.5;
        rect(c, b.tape.x - 7, b.tape.y - 4 - l, 14, 8, '#752b59');
        rect(c, b.tape.x - 6, b.tape.y - 5 - l, 12, 7, '#ff7da4'); rect(c, b.tape.x - 3, b.tape.y - 3 - l, 6, 2, '#3c294d');
      }
    }
    for(const p of g.city.temporary)if(p.hp>0&&this.inView(p.x,p.y))this.prop(c,p);
    for(const p of g.city.playerProps)if(p.hp>0&&this.inView(p.x,p.y))this.prop(c,p);
    const event=streetMarker(g);if(event&&this.inView(event.x,event.y))this.floorPin(c,event,'#9ee2bc',3);
    if(g.outbreak) {
      for(const n of g.decoyItems){
        const time=Math.min(1,(8-n.life)/n.delay),x=mix(n.fromX,n.x,time),y=mix(n.fromY,n.y,time),z=Math.sin(time*Math.PI)*26;
        if(!this.inView(x,y,31))continue;
        oval(c,x,y,6.2,3,'#181b26b8');rect(c,x-4,y-z-2,8,4,'#c9b289');rect(c,x+1,y-z-3,3,2,'#f6d799');
        if(time===1&&n.tick>.63){c.strokeStyle='#ddce8f6b';c.lineWidth=1;c.beginPath();c.ellipse(x,y,(.88-n.tick)*58+4,(.88-n.tick)*26+3,0,0,TAU);c.stroke();}
      }
      for(const p of BEACONS)if(this.inView(p.x,p.y)){
        const on=g.outbreak.signal.includes(p.id), color=on?'#c6f39d':'#de996e';
        oval(c,p.x,p.y,12,9,on?'#649c6e4e':'#241f2b91');rect(c,p.x-3,p.y-12,6,16,'#414a51');
        rect(c,p.x-6,p.y-13,12,4,color);rect(c,p.x-2,p.y-16,4,3,on?'#eaffc3':'#f0c297');
      }
      for(const p of CACHES)if(!g.outbreak.used.includes(p.id)&&this.inView(p.x,p.y))this.supply(c,p,'#a0c78e');
      for(const p of g.outbreak.drops)if(this.inView(p.x,p.y))this.supply(c,p,'#d9b785');
      if(g.outbreak.signal.length>=3&&this.inView(EVAC.x,EVAC.y)) {
        const r=13+mod(g.outbreak.clock*18,20);c.strokeStyle='#ddf29487';c.lineWidth=1;c.beginPath();c.ellipse(EVAC.x,EVAC.y,r,r*.6,0,0,TAU);c.stroke();
      }
    }
    for (const mark of g.marks.items) if (mark.active && this.inView(mark.x, mark.y, 4)) {
      c.globalAlpha = mark.life / 12 * .74;
      stroke(c, '#10101d', 2, mark.x, mark.y, mark.x + Math.cos(mark.a) * 11, mark.y + Math.sin(mark.a) * 11); c.globalAlpha = 1;
    }
    for (const b of g.blockade) if (this.inView(b.x,b.y)) {
      c.save();c.translate(b.x,b.y);c.rotate(b.a||0);
      if(b.kind==='spikes'){rect(c,-4,-16,7,32,'#2f2c3e');for(let n=-13;n<16;n+=5)shape(c,'#c9b4ad',-4,n,4,n+2,-3,n+3);}
      else {rect(c,-6,-15,11,30,'#201c2b');rect(c,-4,-14,7,28,'#6a5557');for(let n=-12;n<15;n+=6)stroke(c,'#ffd19c',1.7,-3,n,3,n+4);}
      rect(c,-6,-15,3,3,Math.sin(g.clock*8)>.0?'#ff7992':'#632f45');rect(c,3,12,3,3,'#f99599');c.restore();
    }
    if (this.inView(4340,2400)) {
      const x=4340,y=2400;
      rect(c,x-34,y-12,68,25,'#705565'); rect(c,x-32,y-11,61,3,'#bb9093'); rect(c,x+24,y-11,8,23,'#b27568');
      for(let i=0;i<3;i++) { stroke(c,'#f1bf98',2,x-15+i*10,y-5,x-8+i*10,y); stroke(c,'#f1bf98',2,x-8+i*10,y,x-15+i*10,y+5); }
    }
  }
  pane(c,p){
    const {x,y,w,h}=p;
    rect(c,x,y,w,h+2,'#252b37');
    if(p.hp>0){rect(c,x+1,y+1,w-2,Math.max(2,h-1),'#769da7');rect(c,x+3,y,w-6,1,'#bedecb');
      for(let k=6;k<w-4;k+=11){rect(c,x+k,y+1,1,h,'#524d65');rect(c,x+k-4,y+1,3,1,'#d1c4aa');}
    }else{
      rect(c,x+2,y+1,w-4,h-1,'#252537');
      for(let i=3;i<w;i+=6){shape(c,'#8dc2be82',x+i,y+h,x+i+4,y+h,x+i+2,y-1);rect(c,x+i,y+h+6,2,1,'#95b6bd86');}
    }
  }
  prop(c, p) {
    const { x, y, w, h } = p;
    if(p.kind==='window'){this.pane(c,p);return;}
    rect(c,x+3,y+4,w,h,'#17152290');
    if(p.kind==='barricade'){
      rect(c,x,y,w,h,'#534450');rect(c,x+1,y+1,w-2,h-2,'#ac8663');
      if(w<h){rect(c,x+2,y,2,h,'#cdab77');for(let i=4;i<h-1;i+=7)rect(c,x+1,y+i,w-2,2,'#594753');}
      else{rect(c,x,y+2,w,2,'#cdab77');for(let i=4;i<w-1;i+=7)rect(c,x+i,y+1,2,h-2,'#594753');}
      if(p.hp<39)stroke(c,'#5b4253',1,x,y,x+w,y+h);
    }else if(p.kind==='foam'){rect(c,x,y,w,h,'#e1a75c');for(let i=1;i<h-1;i+=6)rect(c,x+1,y+i,w-2,2,'#493e4a');rect(c,x,y,1,h,'#f9d995');}
    else if (p.kind === 'barrel') { oval(c,x+6,y+6,6,6,'#673b57'); oval(c,x+6,y+4,5,4,'#bc7087'); rect(c,x+2,y+4,8,2,'#693550'); rect(c,x+4,y+1,4,2,'#dfaaa1'); }
    else if (p.kind === 'fence') { rect(c,x,y+4,w,4,'#827085'); rect(c,x,y+4,w,1,'#b19aac'); for(let i=0;i<w;i+=6) rect(c,x+i,y,2,10,'#57485e'); }
    else if (p.kind === 'sign') { rect(c,x+4,y,2,10,'#9c7a85'); rect(c,x,y,10,6,'#cc8c73'); rect(c,x+3,y+1,5,2,'#463349'); }
    else { rect(c,x,y,w,h,'#9c6370'); rect(c,x+1,y+1,w-2,h-2,'#67485c'); stroke(c,'#bc827e',1,x+2,y+1,x+w-2,y+h-1); }
  }
  supply(c,p,color){
    const y=p.y+Math.sin(this.game.clock*3)*1.1;
    rect(c,p.x-8,y+2,16,8,'#1e2331');rect(c,p.x-7,y-5,14,11,'#4d5951');rect(c,p.x-7,y-6,14,4,color);rect(c,p.x-2,y-2,4,6,color);
  }
  metro(c,time){
    const distances=METRO_LINE.slice(1).map(([x,y],i)=>Math.hypot(x-METRO_LINE[i][0],y-METRO_LINE[i][1]));
    const length=distances.reduce((a,b)=>a+b,0), pos=mod(time*158+845,length*2);
    const track=(p)=>{
      let u=clamp(p,0,length), i=0;
      while(i<distances.length-1&&u>distances[i])u-=distances[i++];
      const [x,y]=METRO_LINE[i],[xx,yy]=METRO_LINE[i+1];return [mix(x,xx,u/distances[i]),mix(y,yy,u/distances[i]),Math.atan2(yy-y,xx-x)];
    };
    for(let n=0;n<5;n++){
      const a=pos<length?pos-n*39:length*2-pos+n*39;if(a<=0||a>=length)continue;
      const [x,y,d]=track(a);if(!this.inView(x,y,37))continue;
      c.save();c.translate(x,y);c.rotate(d);rect(c,-18,-7,36,14,'#d1c9ad');rect(c,-17,-5,34,10,'#d6d0bd');
      rect(c,-18,3,36,3,'#4a8c80');rect(c,-18,-6,35,2,'#7ab6a4');rect(c,-10,-1,14,3,'#808a87');
      if(n===0){rect(c,pos<length?13:-17,-4,4,8,'#385669');rect(c,pos<length?17:-18,-3,1,2,'#fff1aa');}c.restore();
    }
  }
  room(c) {
    const g=this.game, layout=g.interior;
    let art=this.rooms.get(layout.id);
    if(!art){art=document.createElement('canvas');paintInterior(art,layout);this.rooms.set(layout.id,art);}
    c.drawImage(art,0,0);
    if(layout.club){
      const pulse=g.settings.motion?Math.sin(g.clock*3.2)*.5+.5:.45;
      for(let y=169;y<304;y+=22)for(let x=232;x<489;x+=22)if((x+y)%4===1){c.globalAlpha=.13+pulse*.18;rect(c,x,y,19,19,(x+y)%3?'#d88fbf':'#9bd1c3');}
      c.globalAlpha=1;
    }
    if(g.practice){
      const stage=g.practice.snapshot();
      for(const q of layout.walls)if(q.dynamic){
        if(q.kind==='window')this.pane(c,q);
        else {rect(c,q.x+5,q.y+8,q.w,q.h,'#2323309a');rect(c,q.x,q.y,q.w,q.h,'#68677b');rect(c,q.x,q.y,q.w,3,'#c3b3a3');rect(c,q.x+4,q.y+7,q.w-9,q.h-10,'#484754');}
      }
      c.font='700 8px monospace';c.textAlign='center';c.fillStyle='#a2cdbb';c.fillText('RETURN TO CONSOLE',360,386);
      if(stage.active){
        for(const [i,x] of [193,274,360,439,526].entries()){
          rect(c,x-20,94,40,25,'#252e3c');rect(c,x-20,94,40,1,'#8fbbad');
          c.font='700 9px monospace';c.fillStyle='#b9d7c3';c.fillText(`L-${i+1}`,x,109);
        }
        for(let i=0;i<5;i++)rect(c,302+i*24,321,15,2,i<stage.total?'#b4d9af':'#696272');
      }
    }
    const clock=g.clock;
    for(const [i, f] of layout.furniture.entries()){
      if(f.t==='radio')for(let k=0;k<5;k++){
        const x=f.x+12+k*(f.w-18)/5,y=f.y+17;
        rect(c,x,y+4,15,8,'#313741');
        for(let n=0;n<7;n++){
          const ht=2+Math.floor((.5+.5*Math.sin(clock*5+n*1.6+k*2))*7);
          rect(c,x+n*2,y+12-ht,1,ht,i%2?'#d4c589':'#9bd6c4');
        }
      }
      if(f.t==='cabinet')rect(c,f.x+8,f.y+12,Math.min(9,f.w-16),3,i%2?'#f8a3c1':'#ba9af3');
    }
    for(const [i,spot] of layout.spots.entries())this.floorPin(c,spot,layout.colors[0],i);
    this.floorPin(c,layout.service,layout.colors[1],2);
    this.floorPin(c,layout.exit,'#beae9a',0);
  }
  floorPin(c,p,color,i){
    const amount=.7+.28*Math.sin(this.game.clock*2.4+i);
    c.globalAlpha=amount;
    oval(c,p.x,p.y+3,7,3,'#242034a4');
    shape(c,color,p.x,p.y-5,p.x+4,p.y-1,p.x,p.y+3,p.x-4,p.y-1);
    rect(c,p.x-1,p.y-2,2,2,'#443948');c.globalAlpha=1;
  }
  car(c, v, alpha) {
    const [x,y,a] = this.pose(v,alpha), { l, w } = v.model, f = l / 2, r = w / 2;
    const g=this.game, z=v===g.car&&g.jump>0?Math.sin(Math.min(1,g.jump/.75)*Math.PI)*12:0;
    if(v.tow)stroke(c,'#d9ad7994',1.2,x-Math.cos(a)*f,y-Math.sin(a)*f,v.tow.x,v.tow.y);
    c.save(); c.translate(x,y); c.rotate(a);
    const altitude=v.alt||0;
    if(v.model.class==='AIR'){
      oval(c,4,7,f+7+altitude*.13,r+3+altitude*.045,'#17213186');c.restore();
      c.save();c.translate(x,y-altitude*.62);c.rotate(a);
    }else rect(c,-f+3,-r+3,l+4,w+4,'#120f1bb4');
    c.translate(0,-z);
    const color=v.wreck?'#463442':v.color;
    if(['PEDAL','THREE-WHEELER','BOAT','TRACKED','TANK','HAULER','RESCUE','BICYCLE','AIR','SERVICE'].includes(v.model.class)){
      this.specialVehicle(c,v,color,f,r,a);this.doorPose(c,v,r);this.carScuffs(c,v);
      c.restore();return;
    }
    for(const k of [-1,1]) for(const j of [-1,1]) rect(c,k*f*.62-5,j*(r-1)-2,10,5,'#100f19');
    shape(c,'#1a1526',-f+2,-r-1,f-4,-r-1,f+1,-r+3,f+1,r-3,f-4,r+1,-f+2,r+1,-f-1,r-3,-f-1,-r+3);
    shape(c,color,-f+3,-r,f-5,-r,f,-r+4,f,r-4,f-5,r,-f+3,r,-f,r-3,-f,-r+3);
    rect(c,-f+4,-r+1,l-9,1,'#fff1df73'); rect(c,-f+4,r-2,l-9,2,'#4b274a78');
    if (v.model.id==='moth') { rect(c,-f+4,-r+2,9,w-4,'#2a2237'); rect(c,-5,-r+1,9,w-1,'#b995af'); rect(c,4,-r,3,w,'#1b192c'); }
    else if (v.model.class==='BUS' || v.model.class==='VAN') {
      rect(c,-f+6,-r+3,l-17,w-6,'#634a61'); rect(c,-f+8,-r+4,l-22,w-8,color);
      rect(c,f-14,-r+4,6,w-8,'#2b2c44'); rect(c,f-13,-r+5,2,w-10,'#7e9fa9');
      if(v.model.class==='BUS') for(let i=-f+7;i<f-17;i+=8) { rect(c,i,-r+3,5,2,'#2d304a'); rect(c,i,r-5,5,2,'#32223b'); }
      if(v.model.id==='megh'){rect(c,-f+10,-2,l-27,5,'#d7ba71');rect(c,-f+13,-1,22,3,'#e6d19b');rect(c,f-11,-4,3,8,'#416e65');}
    } else {
      shape(c,'#322a42',-f+8,-r+4,4,-r+3,10,-r+5,10,r-5,4,r-3,-f+8,r-4);
      shape(c,'#69818f',3,-r+3,10,-r+5,10,r-5,4,r-3,5,0);
      rect(c,-f+11,-r+5,Math.max(9,l*.3),w-10,color); rect(c,-f+12,-r+6,Math.max(7,l*.28),1,'#f4d5d36b');
      if(v.model.id==='ibis') { rect(c,-f+4,-r+3,13,w-6,'#2c2837'); for(let i=0;i<4;i++) rect(c,-f+5,-r+5+i*3,10,1,'#625b67'); }
    }
    if(!v.wreck) {
      rect(c,f-3,-r+2,3,4,v.light?'#fff2cb':'#b58187'); rect(c,f-3,r-6,3,4,v.light?'#fff2cb':'#b58187');
      rect(c,-f,-r+2,3,4,v.brake?'#ff9e95':'#f65078'); rect(c,-f,r-6,3,4,v.brake?'#ff9e95':'#f65078');
      if(v.signal&&Math.sin(g.clock*12)>.05) rect(c,-f+1,v.signal<0?-r:r-3,4,3,'#ffd184');
      if(v.siren) { rect(c,-4,-r+1,5,r-1,Math.sin(g.clock*16)>0?'#ff5479':'#643c6c'); rect(c,-4,0,5,r-1,Math.sin(g.clock*16)>0?'#49528a':'#8bc9ff'); }
      if(v.hp<v.model.hp*.58) { stroke(c,'#231d30',1,-f+5,-r+3,f*.78,-r+1); rect(c,f-8,r-3,6,2,'#5d3a51'); }
      if(v===g.car&&v.plate&&this.scale>1.2)rect(c,-f-1,-3,3,6,'#d5c2ae');
    }
    this.doorPose(c,v,r);this.carScuffs(c,v);c.restore();
  }
  doorPose(c,v,r){
    const d=v.door;if(!d||!this.game.settings.motion||v.model.w<15||v.model.class==='BOAT'||v.model.class==='AIR')return;
    const amount=Math.sin(Math.min(1,d.time/d.total)*Math.PI),side=d.side||1;
    if(amount<.07)return;
    c.save();c.translate(5,r*side);c.rotate(amount*.92*side);
    rect(c,-15,-1,15,3,'#332638');rect(c,-14,-1,12,1,v.color);rect(c,-11,0,9,1,'#d1c5b7');c.restore();
  }
  carScuffs(c,v){for(const q of v.scuffs||[]){rect(c,q.x-1,q.y-1,3,2,q.glass?'#b9d5d0':'#3c3948');rect(c,q.x+1,q.y,1,1,q.glass?'#7899a4':'#ca978a');}}
  specialVehicle(c,v,color,f,r,a){
    const k=v.model.class,g=this.game;
    if(k==='AIR'){
      shape(c,'#292c3b',-f,0,-7,-3,-4,-10,15,-9,23,-5,26,0,22,7,10,10,-5,8,-9,4);
      rect(c,-f,-1,28,3,color);rect(c,-f,-7,3,14,'#687483');rect(c,-f+1,-6,7,2,'#dcad95');
      oval(c,6,0,16,8,color);shape(c,'#516d7f',11,-6,23,-4,25,0,22,5,11,6,13,0);
      stroke(c,'#d3ede2a0',1,13,-4,20,-3);stroke(c,'#354754',2,-5,-9,14,-9);stroke(c,'#354754',2,-5,9,14,9);
      c.save();c.translate(4,0);c.rotate(g.clock*(v.alt>5?34:9));rect(c,-32,-1,64,2,'#beb6b57c');rect(c,-1,-24,2,48,'#a8b9c052');c.restore();
      rect(c,2,-2,4,4,'#4e5867');rect(c,20,2,3,2,'#f2dd9e');
    }else if(k==='BICYCLE'){
      rect(c,-f,-2,10,4,'#221e2d');rect(c,f-9,-2,10,4,'#221e2d');stroke(c,color,2,-8,0,10,0);
      rect(c,7,-5,2,10,'#8f9fa6');rect(c,-4,-3,5,6,'#564750');
      if(v.mode==='traffic'||v===g.car){oval(c,0,0,6,5,'#ccb39c');rect(c,-2,-4,5,7,'#9cae91');rect(c,2,-2,4,4,'#b68572');}
    }else if(k==='PEDAL'){
      rect(c,-13,-10,10,4,'#202632');rect(c,-13,6,10,4,'#202632');rect(c,12,-2,9,4,'#252634');
      rect(c,-5,-1,24,2,'#e2ac73');rect(c,8,-5,2,10,'#82998d');rect(c,6,-4,4,9,'#484956');
      shape(c,'#2c3441',-19,-7,-7,-8,-1,-5,-1,5,-7,8,-19,7);
      shape(c,color,-18,-6,-8,-7,-4,-4,-4,4,-8,7,-18,6);
      for(let i=-5;i<6;i+=5){rect(c,-16,i,7,2,'#e3c776');rect(c,-13,i-1,2,4,'#78ab90');rect(c,-12,i,1,2,'#f6dcaa');}
      rect(c,-20,-4,2,8,'#c9aa68');rect(c,-2,-5,4,10,'#6b6f65');
      if(v.driver||v===g.car||v.mode==='traffic'){rect(c,4,-4,5,8,'#c68e73');rect(c,7,-3,4,6,'#b78ff0');}
    }else if(k==='THREE-WHEELER'){
      rect(c,-13,-11,10,4,'#181e29');rect(c,-13,7,10,4,'#181e29');rect(c,13,-3,6,6,'#20222b');
      shape(c,color,-17,-8,-12,-10,7,-9,16,-5,18,0,16,5,7,9,-12,10,-17,8);
      rect(c,-15,-7,22,14,'#30463e');rect(c,-13,-6,17,12,'#496c56');rect(c,-12,-5,12,1,'#9db588');rect(c,6,-5,6,10,'#a1b5a5');
      rect(c,12,-4,2,8,'#374959');rect(c,15,-3,3,6,'#f2dfa0');rect(c,-17,-6,2,3,'#f68a80');rect(c,-17,3,2,3,'#f68a80');
    }else if(k==='BOAT'){
      shape(c,'#202b3a',-f,-r,f*.52,-r,f,0,f*.52,r,-f,r);
      shape(c,color,-f+2,-r+1,f*.52,-r+1,f-3,0,f*.52,r-1,-f+2,r-1);
      rect(c,-f+4,-r+3,25,v.model.w-6,'#8e7770');for(let i=-f+7;i<-2;i+=6){rect(c,i,-r+3,1,v.model.w-6,'#d7b486');}
      rect(c,-3,-r+3,16,v.model.w-6,'#eaebc8');rect(c,10,-r+4,4,v.model.w-8,'#4e7180');rect(c,-f,-2,5,4,'#682c4e');
    }else if(k==='TRACKED'||k==='TANK'){
      for(const yy of [-r,r-6]){rect(c,-f,yy,v.model.l,6,'#23282e');for(let i=-f+2;i<f-2;i+=5)rect(c,i,yy+1,2,4,'#4f5049');}
      shape(c,color,-f+3,-r+5,f-8,-r+5,f-2,-r+8,f-2,r-8,f-8,r-5,-f+3,r-5);
      rect(c,-f+6,-r+7,16,v.model.w-14,'#62654f');for(let i=-f+8;i<-f+20;i+=3)rect(c,i,-r+8,1,v.model.w-16,'#373e41');
      if(k==='TANK'){
        c.save();c.rotate((v.turret??a)-a);oval(c,0,0,12,10,'#525a54');oval(c,1,-1,11,8,color);
        rect(c,6,-3,25,6,'#5d6d63');rect(c,10,-2,18,1,'#b4bb97');rect(c,29,-4,3,8,'#455251');rect(c,-4,-3,5,5,'#434c4a');c.restore();
      }else{rect(c,-6,-6,18,12,'#57697a');rect(c,-3,-4,12,8,'#849a92');rect(c,14,-r+8,12,r*2-16,'#938463');for(let i=-6;i<7;i+=4)rect(c,17,i,8,2,'#e5c67d');}
      if(v.hp<v.model.hp*.55)stroke(c,'#493c4a',2,-13,-6,18,7);
    }else{
      for(const yy of [-r-1,r-4]){rect(c,-f+6,yy,11,5,'#20222d');rect(c,f-15,yy,11,5,'#20222d');}
      rect(c,-f+1,-r,v.model.l-2,v.model.w,color);rect(c,-f+4,-r+2,v.model.l-9,1,'#f4deb0');
      if(k==='HAULER'||k==='SERVICE'){rect(c,-f+3,-r+3,28,v.model.w-6,'#756e5d');for(let i=-f+4;i<-2;i+=4)rect(c,i,-r+4,1,v.model.w-8,'#b59572');if(k==='SERVICE'){stroke(c,'#bdc1a9',4,-f,0,4,0);rect(c,-f+12,-4,6,8,'#ead398');}}
      else if(v.model.id==='hearth'){rect(c,-f+4,-r+4,v.model.l*.49,v.model.w-8,'#705659');for(let i=-f+7;i<-5;i+=5)rect(c,i,-r+7,2,v.model.w-13,'#ae8d7e');rect(c,-f+6,-r+3,23,2,'#dcbb83');if(v.siren)rect(c,4,-r+1,5,v.model.w-2,Math.sin(g.clock*15)>0?'#ffa57b':'#6f4859');}
      else{rect(c,-f+4,-r+6,32,v.model.w-12,'#e7dfbf');rect(c,-14,-2,9,4,'#bb5e66');rect(c,-12,-5,4,10,'#bb5e66');if(v.siren)rect(c,2,-r+1,4,v.model.w-2,Math.sin(g.clock*16)>0?'#f38682':'#7ec5d8');}
      rect(c,f-15,-r+3,6,v.model.w-6,'#4c6973');rect(c,f-5,-r+3,2,4,v.light?'#ffefb6':'#846b6a');rect(c,f-5,r-7,2,4,v.light?'#ffefb6':'#846b6a');
    }
  }
  person(c,n,alpha,main){
    let [x,y,a]=this.pose(n,alpha);
    if(main&&n.vanim){const v=n.vanim,t=clamp(v.time/v.total,0,1),e=t*t*(3-2*t);x=mix(v.x,v.ex,e);y=mix(v.y,v.ey,e);if(v.kind==='enter'&&t>.81)return;}
    drawBody(c,this.game,n,x,y,a,main);
    if(main){c.strokeStyle='#ffe9da7b';c.lineWidth=1;c.beginPath();c.arc(x,y,13,Math.PI*.12,Math.PI*.87);c.stroke();}
    if(n.identity){c.font='700 8px monospace';c.textAlign='center';c.fillStyle=n.boss?'#ffbe91':'#82dac3';c.fillText(n.identity,x,y-18);}
  }
  helicopter(c,h) {
    oval(c,h.x+17,h.y+48,26,10,'#0e0e1669');
    shape(c,h.charge>.5?'#c8c7ad31':'#b2b9c719',h.x-7,h.y+6,h.beamX-41,h.beamY+4,h.beamX+43,h.beamY+11,h.x+8,h.y+6);
    rect(c,h.x-13,h.y-6,27,11,'#292538'); rect(c,h.x-10,h.y-7,12,3,'#a68b9d'); rect(c,h.x-31,h.y-1,22,3,'#584658');
    rect(c,h.x+8,h.y-4,7,6,'#5c738c'); rect(c,h.x+9,h.y+3,3,2,'#ee819f');
    c.save(); c.translate(h.x,h.y-4); c.rotate(this.game.clock*22); rect(c,-30,-1,60,2,'#abaaac80'); c.restore();
  }
  light(c) {
    const g=this.game, room=g.room, l=this.lightctx;
    if(!l) return;
    const w=this.lightplane.width,h=this.lightplane.height, cw=this.width,ch=this.height, kx=w/cw,ky=h/ch;
    const sun=clamp((Math.cos((g.day-13)/24*TAU)+.26)*1.24,0,1), dark=room ? .19 : g.outbreak ? .47 : .4*(1-sun)+.035;
    l.setTransform(kx,0,0,ky,0,0); l.globalCompositeOperation='source-over'; l.clearRect(0,0,cw,ch);
    l.fillStyle=g.outbreak?`rgba(19,28,29,${dark})`:`rgba(21,14,38,${dark})`; l.fillRect(0,0,cw,ch);
    l.globalCompositeOperation='destination-out';
    const point=(x,y,r,intensity)=> {
      if(!this.inView(x,y,r)) return;
      const [xx,yy]=this.screen(x,y), s=r*this.scale;
      l.globalAlpha=intensity; l.drawImage(this.haloSprite('#000000'),xx-s,yy-s,s*2,s*2); l.globalAlpha=1;
    };
    const low=g.settings.quality==='Low';
    if(room){for(const [x,y,r] of g.interior.lights)point(x,y,r,.82);point(g.player.x,g.player.y,63,.36);}
    else if(!low||sun<.45) for(const b of g.city.active) {
      if(g.blackout?.zone===b.zone||g.outbreak&&((b.cx*3+b.cy*7)%5)>1||!this.inView(b.x+240,b.y+240,302)) continue;
      for(const t of b.lights) point(t.x,t.y-7,66,.76);
      if(b.poi) point(b.poi.x,b.poi.y+7,45,.67);
    }
    if(!room && sun<.65) for(const v of g.cars) if (!v.wreck && this.inView(v.x,v.y,124) && (v===g.car||!low)) {
      const [vx,vy]=this.screen(v.x,v.y), size=this.scale*(v===g.car?128:83);
      if(v.light){l.save();l.translate(vx,vy);l.rotate(v.a);l.drawImage(this.headlamp,0,-size*.38,size,size*.76);l.restore();}
      if(v.siren) point(v.x,v.y,64,.75);
    }
    if(g.heli) point(g.heli.beamX,g.heli.beamY,62,.85);
    for(const f of g.lights.items) if(f.active) point(f.x,f.y,f.radius,.92);
    for(const f of g.fires.items)if(f.active)point(f.x,f.y,63+Math.sin(g.clock*9)*7,.64);
    l.globalCompositeOperation='source-over';
    c.imageSmoothingEnabled=true; c.drawImage(this.lightplane,0,0,cw,ch); c.imageSmoothingEnabled=false;
    const haze=(x,y,r,color,alpha=.4) => {
      if(!this.inView(x,y,r)) return;
      const [xx,yy]=this.screen(x,y), s=r*this.scale;
      c.globalAlpha=alpha; c.drawImage(this.haloSprite(color),xx-s,yy-s,s*2,s*2); c.globalAlpha=1;
    };
    if(!room&&sun<.8&&!low) {
      c.globalCompositeOperation='screen';
      for(const b of g.city.active) if(g.blackout?.zone!==b.zone&&this.inView(b.x+240,b.y+240,299)) {
        for(const t of b.lights)if(!g.outbreak||((b.cx*3+b.cy*7)%5)<2)haze(t.x,t.y-7,46,t.hue,.29*(1-sun));
        if(b.poi) haze(b.poi.x,b.poi.y+10,45,DISTRICTS[b.zone].color,.32);
      }
      for(const v of g.cars) if (v.siren && !v.wreck) haze(v.x,v.y,53,Math.sin(g.clock*16)>0?'#e24e8c':'#6293fa',.59);
      c.globalCompositeOperation='source-over';
    }
    if(room&&!low)for(const [x,y,r,tint] of g.interior.lights)haze(x,y,r*.74,tint,.125);
    for(const f of g.lights.items) if(f.active) haze(f.x,f.y,f.radius,f.color,.6*f.time/f.max);
  }
  weather(c) {
    const g=this.game,w=this.width,h=this.height,clock=g.clock;
    if(g.weather===1||g.weather===3) {
      const count=Math.round((g.settings.quality==='High'?155:g.settings.quality==='Medium'?91:57)*this.adaptive);
      c.lineWidth=1;
      for (const bright of [false,true]) {
        c.strokeStyle=bright?'#e0dcf035':'#bdd8fb21'; c.beginPath();
        for(let i=0;i<count;i++) {
          if ((i%5===0)!==bright) continue;
          const [a,b,d,s]=this.rain[i],x=mod(a*w+clock*(51+s*50),w+30)-15,y=mod(b*h+clock*(290+d*350),h+28)-14;
          c.moveTo(x,y); c.lineTo(x+2.8+s*4,y+6+d*14);
        }
        c.stroke();
      }
      if(g.weather===3&&g.lightning>0&&g.settings.motion&&g.settings.flashes!==false) { c.fillStyle=`rgba(216,213,252,${g.lightning*.26})`; c.fillRect(0,0,w,h); }
    }
    if(g.weather===2) {
      const gr=c.createLinearGradient(0,0,w,h); gr.addColorStop(0,'#a1a7cd3b'); gr.addColorStop(.57,'#8586aa0c'); gr.addColorStop(1,'#c0accf48'); c.fillStyle=gr; c.fillRect(0,0,w,h);
    }
  }
  post(c) {
    const { width:w,height:h,game:g }=this;
    c.imageSmoothingEnabled=true; c.drawImage(this.fringe,0,0,w,h); c.imageSmoothingEnabled=false;
    if(g.contact.hurt>.025) {
      const a=g.contact.hurtAngle, sx=Math.cos(a)*w*.49,sy=Math.sin(a)*h*.49;
      const grad=c.createLinearGradient(w*.5+sx,h*.5+sy,w*.5-sx,h*.5-sy);grad.addColorStop(0,'#b9416e72');grad.addColorStop(.2,'transparent');grad.addColorStop(.88,'transparent');grad.addColorStop(1,'#6174a72c');
      c.globalAlpha=clamp(g.contact.hurt*(g.settings.flashes===false?.43:1),0,.78);c.fillStyle=grad;c.fillRect(0,0,w,h);c.globalAlpha=1;
    }
    if(g.settings.crt) { c.fillStyle='#09071643'; for(let y=0;y<h;y+=4)c.fillRect(0,y,w,1); }
  }
  waypoints(c) {
    const g=this.game, p=g.player, {width:w,height:h}=this;
    const sources=[[g.objectiveMarker(),g.outbreak?'#d4f5a2':g.mode==='monsoon'?'#ffd89a':g.settings.contrast?'#ffd085':'#ff799b'],[jobMarker(g),'#86dfc2'],[g.room?null:g.waypoint,'#c5affc'],[streetMarker(g),'#a9ccad']];
    for(const [point,color] of sources) {
      if(!point) continue;
      const [sx,sy]=this.screen(point.x,point.y), m=w<660?45:81, n=w<660?110:87;
      let x=clamp(sx,m,w-m),y=clamp(sy,n,h-n);
      const outside=x!==sx||y!==sy, pulse=1+Math.sin(g.clock*4)*.15;
      if(outside) {
        const a=Math.atan2(sy-y,sx-x); c.save(); c.translate(x,y); c.rotate(a);
        shape(c,'#171020e8',-12,-11,4,-11,15,0,4,11,-12,11); shape(c,color,-6,-6,0,-6,7,0,0,6,-6,6,-1,0); c.restore();
      } else {
        c.strokeStyle=color+'4f'; c.lineWidth=1.25; c.beginPath(); c.ellipse(x,y+3,17*pulse,12*pulse,0,0,TAU); c.stroke();
        const yy=y-19-Math.sin(g.clock*3)*2;
        shape(c,'#1a1426',x,yy-12,x+12,yy,x,yy+12,x-12,yy);
        shape(c,color,x,yy-8,x+8,yy,x,yy+8,x-8,yy); shape(c,'#302038',x,yy-3,x+3,yy,x,yy+3,x-3,yy);
      }
      const text=`${Math.round(Math.hypot(p.x-point.x,p.y-point.y)/1.65)}m`;
      if(outside && w>600) { c.font='700 10px monospace'; c.textAlign='center'; rect(c,x-18,y+16,36,16,'#1b1422dd'); c.fillStyle=color; c.fillText(text,x,y+27); }
    }
  }
}