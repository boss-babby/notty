import { clamp, dist, read, write } from './core.js';
import { GEAR } from './data.js';

export const DRILLS=[
  {id:'plates',n:'01',name:'Plate Line',intro:'Track moving and stationary plates. Try bracing to steady your reticle.',goal:8,duration:42,color:'#8bd4c3'},
  {id:'materials',n:'02',name:'Break & Cover',intro:'Break all three glass panes and tag five plates. The tall partitions stop your shots.',goal:5,duration:52,color:'#f5be92'},
  {id:'spar',n:'03',name:'Sparring Ring',intro:'Practice guard, rolls and timed melee against three training partners.',goal:3,duration:58,color:'#ddb2e6'},
];

const box=(x,y,w,h,t)=>({x,y,w,h,t});
const point=(x,y)=>({x,y});

export function bayRoom(){
  const walls=[box(110,106,125,14,'rack'),box(486,106,125,14,'rack'),box(119,314,112,24,'counter'),box(489,314,112,24,'counter'),box(122,216,24,59,'pillar'),box(574,216,24,59,'pillar')];
  return {id:'bay',name:'ANCHOR TRAINING BAY',subtitle:'CONTACT LAB / AUTHORIZED PRACTICE',base:box(74,65,572,335),anchor:point(360,228),scale:1.16,
    spawn:point(360,337),exit:point(360,376),service:point(360,371),bounds:{x:82,y:74,right:637,bottom:391},colors:['#9acfbb','#9c8cba','#424557'],
    floors:[box(78,73,564,322,'concrete'),box(91,95,538,200,'service'),box(167,179,385,102,'linoleum'),box(202,302,318,90,'marble')],
    furniture:walls,walls:walls.map(w=>({...w})),spots:[],decor:[box(91,73,538,9,'glass'),box(161,302,401,9,'safety'),box(271,364,177,10,'queue'),box(78,224,68,2,'neonbar'),box(575,224,68,2,'neonbar')],
    lights:[[203,159,106,'#9ad5cc'],[518,159,106,'#e8b785'],[359,314,132,'#cfb2e2']]};
}

const wall=(x,y,w,h)=>({x,y,w,h,t:'partition',material:'stone',dynamic:true});
const pane=(x,y,i)=>({x,y,w:56,h:8,t:'window',kind:'window',type:'prop',material:'glass',dynamic:true,projectileOnly:true,mission:true,hp:16,id:`drill-glass-${i}`});

export class PracticeBay {
  constructor(game,addPerson){
    this.game=game;this.addPerson=addPerson;this.id='plates';this.active=false;this.elapsed=0;this.wave=0;this.total=0;this.glass=0;this.blocks=0;this.rolls=0;this.last=null;
    this.best=read('practice-results',{})||{};
  }
  get spec(){return DRILLS.find(r=>r.id===this.id)||DRILLS[0];}
  setup(id){
    const drill=DRILLS.find(d=>d.id===id);if(!drill)return false;
    const g=this.game,p=g.player;
    this.id=id;this.elapsed=0;this.wave=0;this.last=null;this.glass=0;this.blocks=0;this.rolls=0;this.total=0;this.active=true;this.delay=.4;this.waveReady=false;
    this.startShots=g.stats.shots;this.startHits=g.stats.hits||0;
    g.people.clear();g.scars.clear();g.bolts.clear();g.particles.clear();g.fires.clear();
    g.interior=bayRoom();Object.assign(p,g.interior.spawn,{a:-Math.PI/2,oa:-Math.PI/2,ox:g.interior.spawn.x,oy:g.interior.spawn.y,hp:100,armor:42,stamina:100,inv:.42,cd:0,dodge:0,dashTime:0,stance:0,flinch:0,driveX:0,driveY:0,impactX:0,impactY:0,vault:null,swim:false});
    g.contactReset();g.medkits=4;
    for(const [i,w] of GEAR.entries()){g.armory[i]={mag:w.mag,stash:w.mag?240:0};if(w.mag)g.ammoPools[w.ammo]=240;}
    g.weapon=id==='spar'?0:3;this.aimLesson=this.reloadLesson=false;
    if(id==='materials')g.interior.walls.push(wall(176,252,56,26),wall(476,229,57,28),wall(330,205,56,26),pane(183,181,1),pane(332,166,2),pane(483,181,3));
    if(id==='spar')g.interior.walls.push(wall(203,208,38,66),wall(476,190,42,63));
    g.open(null);this.spawnWave();g.publish(true);return true;
  }
  spawnWave(){
    const g=this.game;
    this.wave++;
    if(this.id==='spar'){
      const n=this.addPerson(g,'spar',360,153,{indoor:true,hp:45+this.wave*5,a:Math.PI/2,r:9,skin:'#be9f9e',color:this.spec.color,cd:.6,keep:true});
      if(n)n.sparTier=this.wave;
      return;
    }
    const points=this.id==='materials'?[[210,129],[360,125],[510,135],[269,163],[436,153]]:[[190,174],[273,141],[359,159],[445,134],[529,172]];
    const count=this.id==='materials'?5:4;
    for(let i=0;i<count;i++){
      const [x,y]=points[(i+this.wave-1)%points.length];
      const n=this.addPerson(g,'target',x,y,{indoor:true,r:10,hp:this.id==='materials'?18:22,color:this.spec.color,skin:'#c5e5d1',keep:true});
      if(n){n.trackX=x;n.trackY=y;n.trackRange=this.id==='plates'&&i%2?27+this.wave*6:0;n.phase=i*2.5;}
    }
  }
  hit(n,damage){
    if(n.dead||!this.active)return;
    n.hp-=damage;n.hit=.19;
    if(n.hp<=0){n.dead=.44;this.total++;}
  }
  tick(dt){
    const g=this.game;if(!this.active)return;
    this.elapsed+=dt;
    let live=0;
    for(const n of g.people.items)if(n.active&&n.indoor&&(n.type==='target'||n.type==='spar')){
      if(n.dead){n.dead-=dt;if(n.dead<=.001)n.active=false;continue;}
      live++;
      if(n.type==='target'){
        n.hit=Math.max(0,n.hit-dt);
        n.x=n.trackX+Math.sin(this.elapsed*(1+this.wave*.36)+n.phase)*n.trackRange;
      }
    }
    if(this.total>=this.spec.goal&&(this.id!=='materials'||this.glass>=3)){this.finish(true);return;}
    if(this.elapsed>=this.spec.duration){this.finish(false);return;}
    if(!live&&(this.total<this.spec.goal||this.id==='materials'&&this.glass<3)&&this.delay<=0){this.delay=.63;this.waveReady=true;}
    if(this.delay>0){this.delay-=dt;if(this.delay<=0&&this.waveReady){this.waveReady=false;this.spawnWave();}}
  }
  finish(passed){
    if(!this.active)return;
    this.active=false;
    const g=this.game,shots=g.stats.shots-this.startShots,hits=(g.stats.hits||0)-this.startHits;
    const score=Math.max(0,Math.round(this.total*125+this.glass*80+this.blocks*40+(passed?Math.max(0,this.spec.duration-this.elapsed)*12:0)));
    this.last={passed,score,time:this.elapsed,shots,hits,blocks:this.blocks};
    const old=this.best[this.id];
    if(!old||passed&&!old.passed||old.passed===passed&&score>old.score){this.best[this.id]=this.last;write('practice-results',this.best);}
    g.open('practice-results');g.hear(passed?'confirm':'hit');
  }
  offer(){return this.active?'Change drill / Reset the lane':'Select a drill';}
  near(){return dist(this.game.player,this.game.interior.service)<36;}
  snapshot(){
    const spec=this.spec,time=clamp(spec.duration-this.elapsed,0,spec.duration);
    return {id:this.id,active:this.active,time,total:this.total,glass:this.glass,blocks:this.blocks,rolls:this.rolls,goal:spec.goal,best:this.best,last:this.last};
  }
}

export const practiceBest=()=>read('practice-results',{})||{};