import { CELL, DISTRICTS, PLACES, SEED, STATIONS, modelIndex, place } from './data.js';
import { hash, clamp, dist, mod, rng } from './core.js';
import { AIR_PORTS, ATLAS_LABELS, SEA_PORTS, VENUE_CAST, WORLD_STYLES } from './atlas-data.js';
import { regionOf } from './geography.js';

export function atlasConfig(options={}){
  const name=typeof options.key==='string'?options.key.trim().slice(0,32):'';
  let seed=SEED;
  if(name){seed=2166136261;for(const t of name)seed=Math.imul(seed^t.charCodeAt(0),16777619);seed>>>=0;}
  return {seed:seed||SEED,key:name,style:WORLD_STYLES.some(s=>s.id===options.style)?options.style:'continental',start:options.start==='basin'?'basin':'mirage'};
}

export function atlasStart(which){
  const basin=which==='basin',p=place(basin?'jacklight':'marina');return {x:p.x+(basin?23:-19),y:p.y-16};
}

export function destinations(type,origin){
  const network=type==='air'?AIR_PORTS:SEA_PORTS;
  return network.filter(id=>id!==origin).map(id=>{
    const p=place(id),other=place(origin);
    const distance=other?Math.round(dist(p,other)/1.65):0;
    return {...p,region:ATLAS_LABELS[regionOf(p.x,p.y)],distance,cost:type==='air'?26:12};
  });
}

export function surveyNearby(g){
  if(g.room||g.car||g.outbreak||g.practice)return null;
  const p=g.player, b=g.city.at(p.x,p.y),q=b?.survey;
  if(q&&dist(q,p)<32)return q;
  return null;
}

export function surveyUse(g){
  const q=surveyNearby(g);if(!q)return false;
  if(g.surveys.has(q.id)){g.notify('Already logged','Follow the road to another chart cell.');return true;}
  g.surveys.add(q.id);g.cash+=55;g.stats.jobs++;
  g.notify('Survey recorded',`${q.label} / +$55`,'ok');g.hear('confirm');g.save(true);return true;
}

export function isAtlasPOI(id){return ['air-mirage','mirage-souk','spire','marina','tide-room','mirage-garage','mirage-clinic','jacklight','halation','basin-garage','basin-air','ember','basin-clinic','sky-gate'].includes(id);}

export function buyTicket(g,type,id){
  if(g.outbreak||g.practice||g.flight)return false;
  const inNetwork=(type==='air'?AIR_PORTS:SEA_PORTS).includes(g.room),choice=destinations(type,g.room).find(p=>p.id===id);
  if(!inNetwork||!choice)return false;
  if(g.heat>.03){g.notify('Departures paused','Clear the current alert before travelling.','warn');g.publish(true);return false;}
  if(g.cash<choice.cost){g.notify('Fare not available',`The ticket costs $${choice.cost}.`,'warn');g.publish(true);return false;}
  g.cash-=choice.cost;
  g.flight={type,destination:id,origin:g.room,total:type==='air'?1.65:1.31,time:0};
  g.open(null);g.hear(type==='air'?'door':'horn');g.publish(true);return true;
}

export function travelTick(g,dt){
  const t=g.flight;if(!t)return false;
  t.time+=dt;
  if(t.time<t.total)return true;
  const target=place(t.destination);g.flight=null;
  g.swapRoom(null);g.day=mod(g.day+(t.type==='air'?1.35:.74),24);
  g.teleport(target.x,target.y-16);g.discovered.add(target.id);
  g.arrivalDoor={id:target.id,until:g.clock+1};g.waypoint=null;
  g.notify('Arrival',`${target.name} / ${ATLAS_LABELS[regionOf(target.x,target.y)]}`,'ok');
  g.hear('confirm');g.save(true);return true;
}

export function localVista(g){
  const r=g.room;
  if(r==='spire'||r==='strip-overlook'){
    g.open('scenic');return true;
  }
  return false;
}

const starters={mirage:['vanta','regent','vox'],basin:['havoc','moth','regent']};

export function seedAtlasVehicles(g,addCar){
  if(g.room||g.outbreak||g.practice)return;
  const p=g.player,region=regionOf(p.x,p.y);
  if(g.clock<=(g.nextAtlasRide||0))return;
  g.nextAtlasRide=g.clock+1.95;
  if(['mirage','basin'].includes(region)){
    const isMirage=region==='mirage', gate=place(isMirage?'air-mirage':'basin-air');
    if(dist(p,gate)<450&&!g.cars.some(v=>v.hubTag===gate.id)){
      const x=gate.x+118,y=gate.y-15;
      if(!g.city.block(x,y,13)&&!g.city.water(x,y))addCar(g,modelIndex('aero'),x,y,Math.PI,'parked',{owned:true,hubTag:gate.id,color:isMirage?'#b8c8c7':'#cbc0d5'});
    }
    const pad=isMirage?place('marina'):place('jacklight');
    if(dist(p,pad)<480&&!g.cars.some(v=>v.hubTag===pad.id)&&!g.cars.some(v=>v.owned&&dist(v,pad)<95)){
      const x=pad.x+(isMirage?-56:92),y=pad.y-38;
      if(!g.city.water(x,y)&&!g.city.block(x,y,14))addCar(g,modelIndex(starters[region][0]),x,y,0,'parked',{owned:true,hubTag:pad.id});
    }
    if(isMirage&&dist(p,{x:14309,y:2161})<550&&!g.cars.some(v=>v.hubTag==='crescent-ferry')){
      addCar(g,modelIndex('launch'),14309,2179,0,'parked',{owned:true,hubTag:'crescent-ferry'});
    }
    const office=place('ember');
    if(!isMirage&&dist(p,office)<490&&!g.cars.some(v=>v.hubTag==='ember-ride')){
      addCar(g,modelIndex('rescue'),office.x-62,office.y-38,0,'parked',{owned:true,hubTag:'ember-ride'});
    }
  }
}

export function roomCast(g,addPerson){
  const crew=VENUE_CAST[g.room];if(!crew)return;
  for(const u of crew)addPerson(g,'host',u.x,u.y,{indoor:true,keep:true,color:u.color,a:Math.PI*.5,identity:u.name});
  for(let n=0;n<8;n++){
    const a=n*Math.PI*.25, x=360+Math.cos(a)*(55+n%2*15),y=226+Math.sin(a)*44;
    addPerson(g,'dancer',x,y,{indoor:true,keep:true,color:['#aeb6d0','#d7aa9f','#b6cda8','#c6a7ce'][n%4],a,pace:n*.61});
  }
}

export function clubTalk(g,i){
  const c=VENUE_CAST[g.room]?.[Number(i)];
  if(c){g.say({speaker:c.name,line:c.line},7.4);g.hear('click');g.publish(true);}
}

export function clubStation(g){
  return g.room==='tide-room'?1:g.room==='halation'?0:-1;
}

export function tablePlay(g){
  if(g.room!=='jacklight'||g.outbreak||g.practice)return false;
  const record=g.records.jacklight||{best:0,plays:0,wins:0};
  const R=rng(hash(g.city.seed,record.plays,2882));
  const numbers=Array.from({length:3},()=>1+Math.floor(R()*9));
  const score=numbers.reduce((sum,n)=>sum+n,0)+(numbers.every(n=>n===numbers[0])?14:0);
  g.records.jacklight={best:Math.max(record.best,score),plays:record.plays+1,wins:record.wins+Number(score>=21)};
  g.tableRoll={numbers,score};g.stats.jobs++;
  if(score>record.best&&score>=21){g.cash+=60;g.notify('New table record','Jacklight paid a $60 in-game prize.','ok');}
  g.hear('confirm');g.save(true);return true;
}