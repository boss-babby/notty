import { CELL } from './data.js';
import { angleDiff, dist, unit } from './core.js';
import { clearSegment, freeNear, landAt, localPath } from './navigation.js';

export function perceiveCivilian(g,n){
  const clock=g.clock,p=g.player,dx=p.x-n.x,dy=p.y-n.y,d=Math.hypot(dx,dy);
  const shot=g.streetNoise, recent=shot&&clock-shot.time<2.65;
  const heard=recent&&dist(n,shot)<shot.radius*.57;
  const reckless=Boolean(g.car&&g.car.speed>100&&d<103&&Math.abs(angleDiff(g.car.a,Math.atan2(-dy,-dx)))<1.72);
  const see=d<196&&(d<42||Math.abs(angleDiff(n.a,Math.atan2(dy,dx)))<1.75)&&g.city.line(n.x,n.y,p.x,p.y);
  if(!reckless&&!heard&&!(g.alarm>0&&d<132&&see))return null;
  const mood=n.mood??.5, action=reckless||!see?'flee':mood>.84&&d<57?'fight':mood>.68?'film':mood>.47?'call':'flee';
  return {action,point:reckless||!shot?{x:p.x,y:p.y}:{x:shot.x,y:shot.y},see};
}

export function readReaction(g,n){
  if(n.routine==='vigil'||n.routine==='victim'||n.routine==='response'||n.routine==='parcel')return;
  if(n.state!=='walk'||n.reactAt>g.clock)return;
  n.reactAt=g.clock+.17+(n.id%5)*.03;
  const event=perceiveCivilian(g,n);if(!event)return;
  n.state=event.action;n.fearAt=event.point;n.route=null;n.routeGoal=null;
  n.timer=event.action==='flee'?3.5+n.mood*2:event.action==='fight'?3:1.3+n.mood*.55;
  if(event.action==='flee')n.fleeGoal=escapePoint(g,n,event.point);
}

function escapePoint(g,n,p){
  const a=Math.atan2(n.y-p.y,n.x-p.x);
  for(const offset of [0,.58,-.58,1.05,-1.05]){
    const x=n.x+Math.cos(a+offset)*148,y=n.y+Math.sin(a+offset)*148;
    const q=freeNear(g,{x,y},n.r,39);
    if(q)return q;
  }
  return null;
}

export function fleeHeading(g,n){
  const p=n.fearAt||g.player;
  if(n.fleeGoal&&dist(n,n.fleeGoal)>18)return {x:n.fleeGoal.x,y:n.fleeGoal.y};
  n.fleeGoal=escapePoint(g,n,p);
  return n.fleeGoal||{x:n.x*2-p.x,y:n.y*2-p.y};
}

export function nextRoutine(g,n){
  const origin=n.home||n,bx=Math.floor(origin.x/CELL)*CELL,by=Math.floor(origin.y/CELL)*CELL;
  const lane=[[57,58],[221,57],[421,58],[422,223],[421,419],[235,421],[58,419],[58,237]];
  if(n.routine==='stall'&&g.day>8&&g.day<20&&n.stuck<.8)return origin;
  let close=0,len=Infinity;
  for(let i=0;i<lane.length;i++){
    const [x,y]=lane[i],d=Math.hypot(n.x-bx-x,n.y-by-y);
    if(d<len){len=d;close=i;}
  }
  const cycle=(g.day<7||g.day>19||n.routine==='night')?-1:1;
  for(let i=1;i<=lane.length;i++){
    const [x,y]=lane[(close+cycle*(i+(n.stuck>.8?1:0))+24)%lane.length];
    if(landAt(g,bx+x,by+y,8,true))return {x:bx+x,y:by+y};
  }
  return origin;
}

export function pedestrianRoute(g,n,goal){
  if(g.room||dist(n,goal)<12||g.city.water(goal.x,goal.y))return goal;
  g.crowdBudget ||= {next:0};
  if(g.clock>=(n.routeAt||0)&&g.clock>=g.crowdBudget.next){
    n.routeAt=g.clock+.78+(n.id%8)*.087;g.crowdBudget.next=g.clock+.042;
    if(clearSegment(g,n,goal,n.r,true))n.route=null;
    else if(n.stuck>.24||!n.route||!n.routeGoal||dist(n.routeGoal,goal)>44){
      n.route=localPath(g,n,goal,n.r,430,true);n.routeGoal={...goal};n.routeStep=0;
    }
  }
  while(n.route?.[n.routeStep]&&dist(n,n.route[n.routeStep])<14)n.routeStep++;
  return n.route?.[n.routeStep]||goal;
}

export function separatePeople(g,n,dx,dy){
  let [x,y]=unit(dx,dy);let sx=0,sy=0,flowX=0,flowY=0,count=0;
  for(const a of g.people.items){
    if(a===n||!a.active||a.dead||a.indoor!==n.indoor)continue;
    const rx=n.x-a.x,ry=n.y-a.y,d2=rx*rx+ry*ry;
    if(d2>1&&d2<23**2){const d=Math.sqrt(d2),force=(23-d)/23;sx+=rx/d*force;sy+=ry/d*force;}
    if(n.type==='ped'&&a.type==='ped'&&n.state==='walk'&&a.state==='walk'&&d2<46**2){flowX+=Math.cos(a.a);flowY+=Math.sin(a.a);count++;}
  }
  if(count){x+=flowX/count*.14;y+=flowY/count*.14;}
  return unit(x+sx*.72,y+sy*.72);
}