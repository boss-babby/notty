import { addPerson } from './actors.js';
import { clamp, dist, mix } from './core.js';
import { isWater } from './world.js';
import { noiseHistory, thinkQuiet } from './horde.js';
import { GEAR } from './data.js';

export const QUARANTINE_START={x:6854,y:2938};
export const BEACONS=[
  {id:'puran',x:6979,y:3384,label:'Puran market beacon'},
  {id:'metro',x:6860,y:2432,label:'Metro relay beacon'},
  {id:'river',x:7310,y:4372,label:'River landing beacon'},
];
export const CACHES=[
  {id:'shelter',x:6902,y:2927,label:'Shelter supply cache'}, {id:'market',x:6780,y:3364,label:'Dry goods cache'},
  {id:'rail',x:7047,y:2412,label:'Metro aid locker'}, {id:'dock',x:7280,y:3891,label:'Landing supply cache'},
];
export const EVAC={x:7324,y:4489,label:'Evac ferry'};

export function createOutbreak(saved={}) {
  return {clock:saved.clock||0, kills:saved.kills||0, score:saved.score||0, signal:saved.signal||[], used:saved.used||[], escaped:Boolean(saved.escaped),
    dead:false, noise:0, soundAt:null, timer:.24, drops:[], routeBudget:0, phase:1, active:0, surge:0, acoustic:noiseHistory()};
}
export const runRecord=o=>({clock:o.clock,kills:o.kills,score:o.score,signal:o.signal,used:o.used,escaped:o.escaped});
export function outbreakMarker(g) {
  const o=g.outbreak,p=g.player;if(!o)return null;
  if(g.room)return {...g.interior.exit,label:'Return to the quarantine streets'};
  if(!o.used.includes('shelter'))return {...CACHES[0],label:'Open the shelter supply cache'};
  const target=BEACONS.filter(b=>!o.signal.includes(b.id)).sort((a,b)=>dist(p,a)-dist(p,b))[0];
  if(target)return {...target,label:`Restore ${target.label.replace(' beacon','')} beacon`};
  return o.escaped?null:{...EVAC,label:'Signal the evacuation ferry'};
}

function nearby(g) {
  if(!g.outbreak||g.room)return null;
  const p=g.player,o=g.outbreak;
  const options=[...CACHES.filter(b=>!o.used.includes(b.id)).map(b=>({...b,type:'cache'})),...BEACONS.filter(b=>!o.signal.includes(b.id)).map(b=>({...b,type:'beacon'})),...o.drops];
  if(o.signal.length===BEACONS.length&&!o.escaped)options.push({...EVAC,type:'evac'});
  return options.filter(b=>dist(p,b)<(b.type==='evac'?38:29)).sort((a,b)=>dist(p,a)-dist(p,b))[0]||null;
}

export function outbreakPrompt(g) {
  const b=nearby(g);
  if(b)return `${b.type==='cache'?'Open':b.type==='beacon'?'Restore':b.type==='evac'?'Evacuate at':'Recover'} ${b.label}`;
  return '';
}

function resupply(g,quantity){
  const families=new Set(Object.keys(g.armory).filter(n=>GEAR[n].mag).map(n=>GEAR[n].ammo));
  for(const type of families)g.ammo(type,type==='SHELL'?Math.max(4,Math.floor(quantity/3)):quantity);
  if(quantity>12)g.medkits++;
}

export function outbreakUse(g) {
  const item=nearby(g),o=g.outbreak;
  if(!item||!o)return false;
  if(item.type==='cache'){
    o.used.push(item.id);resupply(g,item.id==='shelter'?22:18);
    g.decoys=Math.min(8,g.decoys+1);
    g.boards=Math.min(6,(g.boards||0)+2);
    g.player.armor=Math.min(100,g.player.armor+17);
    o.score+=60;g.notify('Cache secured','Ammo, a medkit, and portable defenses.','ok');
    if(item.id==='shelter')g.say({speaker:'Samira / Emergency Band',line:'Three beacons between here and the river. Lights first, ferry second. Keep the street quiet.'},8);
  }else if(item.type==='beacon'){
    o.signal.push(item.id);o.score+=300;resupply(g,12);g.light(item.x,item.y,'#e3fba7',140,2.1);
    g.signalNoise(570,item,'beacon');o.timer=Math.min(o.timer,.7);o.surge=3;
    g.notify('Beacon alive',o.signal.length===3?'Ferry signal received. Head for the ghat.':`${o.signal.length} / 3 restored. Noise is drawing the Quiet.`,'ok');
    g.report(`Emergency Band received a live signal from ${item.label}.`);
  }else if(item.type==='evac'){
    o.escaped=true;o.score+=1000;
    g.publishBest();g.save(true);g.open('outbreak-end');return true;
  }else{
    const n=o.drops.findIndex(d=>d.id===item.id);if(n>=0)o.drops.splice(n,1);
    resupply(g,8);g.notify('Pouch recovered','Eight rounds replenished.','ok');o.score+=25;
  }
  g.hear('confirm');g.publishBest();g.save(true);return true;
}

export function infectedDrop(g,n) {
  const o=g.outbreak;if(!o)return;
  o.kills++;o.score+=n.variantZ==='brute'?110:n.variantZ==='runner'?70:40;
  if(o.kills%4===0&&o.drops.length<11&&!isWater(n.x,n.y))o.drops.push({id:`drop-${n.id}`,x:n.x,y:n.y,label:'supply pouch',type:'drop',time:o.clock+47});
}

function spawn(g,p,phase){
  for(let i=0;i<15;i++){
    const a=g.rand()*Math.PI*2, r=205+g.rand()*174;
    const x=p.x+Math.cos(a)*r,y=p.y+Math.sin(a)*r;
    if(isWater(x,y)||g.city.block(x,y,9)||g.people.items.some(n=>n.active&&!n.dead&&n.type==='infected'&&Math.hypot(n.x-x,n.y-y)<23))continue;
    const kind=g.rand(),variantZ=phase>=3&&kind>.86?'brute':phase>=2&&kind>.62?'runner':'shambler';
    return addPerson(g,'infected',x,y,{variantZ,hp:variantZ==='brute'?139:variantZ==='runner'?48:60,r:variantZ==='brute'?10:8,
      skin:variantZ==='runner'?'#a8bd9a':'#92ad97',color:variantZ==='brute'?'#ab916d':variantZ==='runner'?'#a6929c':'#767d80',routeTime:0,alert:0,drift:g.rand()*6.28});
  }
  return null;
}

export function updateOutbreak(g,dt) {
  const o=g.outbreak;if(!o||o.dead)return;
  o.clock+=dt;o.noise=Math.max(0,o.noise-dt*115);o.routeBudget-=dt;
  const phase=clamp(1+Math.floor(o.clock/75)+Math.floor(o.signal.length/2),1,5);
  if(phase>o.phase&&o.clock>4)g.notify('Quarantine pressure rising',phase===2?'Runners are moving through the side streets.':phase===3?'Brutes are following the noise.':`Threat tier ${phase}`,'warn');
  o.phase=phase;
  if(g.room)return;
  const p=g.player;
  if(g.car?.speed>79)g.signalNoise(115+(g.car.model.class==='PEDAL'?0:55),p,'vehicle');
  let alive=0;
  for(const n of g.people.items) {
    if(!n.active||n.type!=='infected')continue;
    if(n.dead){n.dead=Math.max(.001,n.dead-dt);if(n.dead<=.002)n.active=false;continue;}
    if(dist(n,p)>770){n.active=false;continue;}
    alive++;thinkQuiet(g,n,p,dt);
    if(o.dead)return;
  }
  o.active=alive;o.timer-=dt;
  if(o.timer<=0){
    o.timer=o.surge>0?.69:mix(2.8,1.03,(phase-1)/4)*(o.noise>270?.6:1);
    const limit=g.settings.quality==='Low'?17:31;
    if(alive<Math.min(limit,8+phase*4)) {spawn(g,p,phase);if((o.noise>360||phase>2||o.surge>0)&&alive+1<limit)spawn(g,p,phase);}
    o.surge=Math.max(0,o.surge-1);
  }
  if(o.drops.length&&o.drops[0].time<o.clock)o.drops.shift();
}