import { rng } from './core.js';

const W=672,H=360;

export function mountMonsoonVista(canvas,motion=true){
  canvas.width=W;canvas.height=H;
  const c=canvas.getContext('2d',{alpha:false});if(!c)return()=>{};
  const page=document.createElement('canvas');page.width=W;page.height=H;const g=page.getContext('2d');
  const R=rng(73516), ri=(lo,hi)=>lo+Math.floor(R()*(hi-lo+1));
  const box=(x,y,w,h,color)=>{g.fillStyle=color;g.fillRect(Math.floor(x),Math.floor(y),Math.ceil(w),Math.ceil(h));};
  function poly(color,...xy){
    const ys=xy.filter((_,i)=>i%2);g.fillStyle=color;
    for(let y=Math.floor(Math.min(...ys));y<Math.max(...ys);y++){
      let k=[];
      for(let i=0;i<xy.length;i+=2){const j=(i+2)%xy.length,a=xy[i+1],b=xy[j+1];if(a<=y+.5&&b>y+.5||b<=y+.5&&a>y+.5)k.push(xy[i]+(xy[j]-xy[i])*(y+.5-a)/(b-a));}
      k.sort((a,b)=>a-b);for(let i=0;i+1<k.length;i+=2)g.fillRect(Math.round(k[i]),y,Math.round(k[i+1])-Math.round(k[i]),1);
    }
  }
  function line(x,y,a,b,color,n=1){const steps=Math.max(Math.abs(a-x),Math.abs(b-y),1);for(let i=0;i<=steps;i++)box(Math.round(x+(a-x)*i/steps),Math.round(y+(b-y)*i/steps),n,n,color);}
  function disk(x,y,r,lit){for(let v=Math.ceil(y-r);v<y+r;v++){const q=Math.sqrt(r*r-(v-y)**2);box(Math.round(x-q),v,q*2,1,typeof lit==='function'?lit(v):lit);}}
  function halo(x,y,r,color){const p=g.createRadialGradient(x,y,0,x,y,r);p.addColorStop(0,color);p.addColorStop(1,'transparent');box(x-r,y-r,r*2,r*2,p);}

  const sky=g.createLinearGradient(0,0,0,233);
  ['#211628','#342038','#71364e','#aa5263','#e3876d','#be7c72'].forEach((q,i)=>sky.addColorStop(i/5,q));box(0,0,W,H,sky);
  halo(500,110,196,'#f5906335');
  for(let i=0;i<2000;i++){const y=ri(0,210),x=ri(5,W);box(x,y,ri(1,4),1,i%3?'#e6afaa15':'#1f193d33');}
  halo(515,127,116,'#ffa65e42');
  disk(519,121,75,y=>{const d=(y-46)/150;return `rgb(255 ${Math.round(190-84*d)} ${Math.round(140-59*d)})`;});
  for(let y=54;y<=184;y+=5){const d=Math.sqrt(75**2-(y-121)**2);box(519-d,y,2*d,1,'#a0413c18');}
  for(let i=0;i<44;i++){
    const x=ri(5,W-40),y=ri(19,184), len=ri(30,215);
    poly(y<120?'#29203965':'#602c4e62',x,y+3,x+12,y,x+len*.57,y-2,x+len,y+1,x+len+19,y+4,x+24,y+5);
    box(x+19,y+6,len*.62,1,'#d87f793a');
  }
  function tower(x,y,w,z){
    const f=187+z*12, lifts=['#98566a','#75465c','#594052','#422f46','#332b40'], wall=lifts[z];
    box(x,y,w,f-y,wall); box(x+w-4,y+2,7,f-y,'#362b437d');box(x,y,w,1,'#dc9d8171');
    if(ri(0,3)>=2){box(x+4,y-4,w-7,4,wall);box(x+6,y-7,w-13,3,wall);box(x+w*.72,y-14,1,11,'#5b4056');}
    if (ri(0,3)===0) {box(x+2,y-7,7,6,'#665369');box(x+3,y-8,5,1,'#b27b74');box(x+5,y-10,1,2,'#9b7771');}
    for(let j=y+6;j<f-3;j+=5+z%2)for(let i=x+3;i<x+w-5;i+=4+z%2){if(ri(0,8)>=5)box(i,j,2,1,z<2?'#e095827d':['#daa17c','#ad6d74','#d3a381','#94a5a3'][ri(0,3)]);}
    if(z>=3)for(let j=y+18;j<f-5;j+=19){box(x,j,w-4,1,'#b781724e');box(x+2,j+1,w-6,1,'#252b3d98');}
  }
  for(let i=0,x=-10;x<672;i++){
    const w=ri(10,30);tower(x,ri(142,170),w,0);x+=w-2;
  }
  for(let i=0,x=-5;x<685;i++){
    const w=ri(14,33),yy=x>373&&x<523?ri(121,160):ri(104,159);
    tower(x,yy,w,1);x+=w+ri(1,5);
  }
  for(const [x,y,w,z] of [[25,142,19,2],[66,110,24,2],[96,133,32,3],[141,103,25,3],[210,142,29,2],[260,92,30,3],[296,125,35,3],[333,119,28,4],[357,90,22,3],[397,114,22,3],[423,139,35,4],[467,118,27,4],[504,137,26,3],[539,110,24,4],[574,92,32,4],[613,126,33,4],[649,81,26,3]])tower(x,y,w,z);

  poly('#4d273f',0,217,672,193,672,279,0,300);
  poly('#574151',262,211,456,202,672,202,672,248,624,255,424,252,219,284,120,276);
  for(let j=0;j<1370;j++){
    const x=ri(0,674),y=ri(206,296);box(x,y,ri(1,18),1,[ '#e9928422','#49364877','#c17f6d4a','#e4a38428','#29767b38'][ri(0,4)]);
  }
  // Waterside blocks have cloth awnings, corrugated shutters, water tanks and colored signs.
  function shop(x,t,w,b,k,sign){
    const wall=['#513e49','#62414b','#6e4c53','#6e5054','#54515b','#654b51'][k];
    poly('#302739',x,t+3,x+w-1,t,x+w+9,b,x+8,b+7);
    poly(wall,x,t,x+w-2,t+1,x+w,b,x,b);
    box(x-1,t,w+1,3,'#a1786f');box(x+2,t+3,w-3,2,'#422f41');
    for(let j=t+6;j<b-18;j+=12){box(x,j,w,1,'#9f78686a');for(let i=x+5;i<x+w-4;i+=9){box(i,j+4,4,4,'#303241');if(ri(0,4)!==0)box(i+1,j+4,2,2,ri(0,4)===0?'#82c9c3':'#ddb588');}}
    box(x+4,b-14,w-8,14,'#2a293a');
    if(sign){box(x+2,b-19,w-4,8,k%2?'#394c57':'#504156');g.fillStyle=k%2?'#8fe0b9':'#ffd08a';g.textAlign='center';g.font='bold 6px monospace';g.fillText(sign,x+w/2,b-13);}
    box(x+4,t-6,8,6,'#2d3445');box(x+5,t-7,6,2,'#747176');
    const awn=['#aa6558','#739e8d','#c49263','#89566b','#55847b','#b38174'][k];
    poly(awn,x-2,b-10,x+w,b-10,x+w+5,b-3,x-5,b-3);
    for(let i=x;i<x+w;i+=6)box(i,b-8,2,5,'#ecc29860');box(x-4,b-3,w+9,2,'#433044');
    if(k%2===0){box(x+6,b-2,4,5,'#bb826b');box(x+11,b-3,6,5,'#bdaf69');box(x+w-11,b-4,7,5,'#e5b07f');}
    else{box(x+10,b-2,2,6,'#c28b70');box(x+14,b-2,7,3,'#d99a79');}
  }
  for(const a of [[217,167,29,232,4,''],[247,153,23,231,1,''],[271,164,29,232,2,''],[302,143,31,231,3,''],[335,160,28,226,4,''],[364,146,37,222,3,''],[402,160,32,221,0,'NODI CHA'],[433,158,38,221,4,'KHEYA'],[471,150,26,215,1,''],[501,162,30,209,2,''],[543,145,34,208,5,'GHAT'],[575,156,28,204,1,'']])shop(...a);
  shop(623,129,28,254,0,'');shop(650,108,31,261,4,'CHA');

  // Raised railway slicing across the block, with regularly spaced piers and a passing train.
  const railY=x=>206-(x-319)*.255;
  for(const x of [323,404,485,567,649]){
    const y=railY(x);poly('#2d2638',x-8,y+9,x+7,y+4,x+8,y+48,x+13,y+59,x-6,y+61,x-7,y+51);
    poly('#61505d',x-8,y+9,x-1,y+8,x-1,y+57,x-7,y+61);box(x-8,y+43,12,3,'#372f45');box(x-6,y+50,4,4,'#9c7469');
  }
  poly('#332837',304,204,672,108,672,129,318,220);
  poly('#a18c7c',292,201,672,103,672,111,309,210);
  poly('#665969',308,210,672,110,672,121,311,217);
  line(315,215,672,120,'#c4a18a');line(309,208,671,108,'#d4a18b');line(312,218,672,125,'#27283a');
  for(let x=313;x<672;x+=15)box(x,railY(x)+1,7,1,'#c5a68c');
  for(let i=0;i<5;i++){
    const x=400+i*47,y=railY(x)-5;
    poly('#d5b5a3',x-1,y-10,x+4,y-15,x+42,y-24,x+47,y-21,x+47,y-7,x,y+5);
    poly('#a7afa4',x,y-9,x+44,y-21,x+45,y-8,x,y+4);
    poly('#497e79',x,y+1,x+46,y-11,x+46,y-6,x,y+5);
    for(let d=5;d<41;d+=8){const a=x+d,b=y-d*.26;poly('#394c59',a,b-8,a+5,b-9,a+5,b-3,a,b-2);box(a,b-4,4,1,'#e2b184');}
    line(x+3,y-13,x+41,y-23,'#ffe0b2');
  }

  // River access road, tar seams, long wet reflections and foreground lane markings.
  poly('#282638',0,290,350,261,520,229,672,214,672,360,0,360);
  poly('#3b3044',0,312,352,274,529,237,672,221,672,360,0,360);
  poly('#6c4f5c',140,326,391,277,531,239,672,219,672,222,531,242,391,280,146,329);
  poly('#252537',0,334,394,294,550,252,672,231,672,360,0,360);
  for(let i=0;i<2380;i++){
    const x=ri(0,W), y=ri(230,360);
    if(y<267-(x-326)*.13)continue;
    const hot=(x>405&&x<601), col=hot?['#d1776d46','#b46b7568','#527d7d4e','#ffac7540','#71899433']:['#916b7c61','#5c566b6b','#201e329e','#b7696e30'];
    box(x,y,ri(1,11)+Math.max(0,y-300)*.15,1,col[ri(0,col.length-1)]);
  }
  poly('#ab7b75',304,355,393,325,389,327,323,356);poly('#bb8b77',589,271,659,246,665,246,603,270);
  for(const [x,y] of [[331,270],[367,261],[604,226]]){
    box(x,y-35,2,35,'#3c3647');box(x+1,y-35,1,34,'#b08a7a');box(x,y-37,14,2,'#514353');box(x+9,y-36,5,2,'#fce1aa');halo(x+13,y-34,30,'#ffb88764');
  }

  // Green three-wheeler, seen from the rear. Pixel facets, thin chrome and original floral trim.
  poly('#191b2d',400,333,443,311,601,285,649,313,626,336,554,351,436,352);
  halo(493,329,114,'#309e8047');halo(465,338,73,'#e77c5d38');
  poly('#1c2030',425,300,443,292,469,295,481,322,469,343,446,350,426,337);
  poly('#1c1b2b',565,302,587,284,605,286,615,310,607,333,588,339,565,324);
  poly('#323345',575,304,591,291,603,294,607,313,599,328,586,333,576,321);
  poly('#665d67',583,307,592,300,599,300,601,314,594,324,585,326,580,317);
  poly('#292d3a',589,309,595,305,597,311,593,319,587,320,585,314);
  poly('#304c4c',414,286,422,246,441,223,474,211,516,205,540,208,567,221,592,249,609,274,606,300,572,321,509,340,446,339,416,324);
  poly('#39534f',417,281,426,247,440,225,466,215,510,205,541,208,569,224,589,250,551,265,512,271);
  poly('#65817a',423,257,432,240,453,223,507,210,539,211,562,223,541,222,510,215,468,224,447,235,434,254);
  poly('#9d9890',434,240,449,226,466,219,507,209,534,209,545,213,518,211,468,222,453,229,437,242);
  poly('#22293a',432,249,456,235,499,229,521,238,516,267,438,279,423,275);
  poly('#3d4a55',435,251,455,239,499,232,515,240,510,262,438,275,428,272);
  poly('#59666a',442,250,461,243,496,237,510,243,490,242,454,253,441,265,433,268);
  poly('#233b45',520,221,540,218,558,227,580,248,558,256,526,260,516,251);
  poly('#70928a',529,226,544,222,557,230,564,240,554,235,538,231,523,248);
  poly('#26363c',527,252,546,247,554,240,572,241,579,249,556,256,529,260);
  poly('#3f755f',520,268,555,261,589,250,608,271,605,293,580,308,551,322,509,337,516,304);
  poly('#68936e',519,278,560,266,586,255,596,264,568,274,529,289,518,304);
  poly('#4d745f',513,310,554,296,585,283,601,273,608,278,604,299,586,307,578,302,568,305,552,319,510,337);
  poly('#242f38',538,282,563,273,580,265,585,270,570,283,544,292,540,315,523,323,526,288);
  poly('#826f64',545,283,568,275,579,268,570,276,546,287,543,306,541,314);
  poly('#66a072',419,282,444,278,507,266,520,267,517,310,509,337,448,340,417,324);
  poly('#83ad7c',421,284,446,282,508,272,515,271,511,292,448,309,421,304);
  poly('#3f5b56',420,305,446,309,511,292,511,318,507,334,448,339,420,325);
  poly('#2c3845',426,307,449,311,504,299,502,324,450,335,425,325);
  poly('#76946e',434,307,451,307,500,297,502,304,452,316,434,314);
  line(426,289,505,273,'#b7c694');line(424,324,451,331,'#9fa88a');line(451,331,504,319,'#bac28d');line(521,313,554,301,'#a2b485');
  for(let n=0;n<11;n++){
    const x=439+n*5,y=296-Math.floor(n*.8);box(x,y,3,1,'#eac189');box(x+1,y-2,1,5,n%2?'#d9a86f':'#bcad7c');box(x+1,y,1,1,'#f9e4a5');
  }
  halo(436,319,30,'#ff514852');halo(497,310,26,'#fb5e4b49');
  poly('#a54b52',424,313,443,315,443,323,425,321);poly('#b24f51',494,305,509,302,508,310,493,314);
  line(425,315,440,318,'#fc867d',2);line(495,308,506,305,'#ff9988',2);
  poly('#d3c397',454,317,478,312,478,320,453,325);line(456,320,475,316,'#344f4d',2);
  box(453,313,7,1,'#fbe5ba');box(601,271,6,3,'#f9d7a1');
  for(let i=0;i<195;i++){
    const x=ri(396,625),y=ri(321,359);
    if(y<347-(x-462)*.16)continue;
    box(x,y,ri(1,18),1,['#e3756558','#ad52467e','#81958358','#bca47f5e','#49a07e40'][ri(0,4)]);
  }

  // A few near wires and balcony plants frame the far right, away from the title.
  for(const [x,tx,y,ty] of [[342,672,98,52],[397,672,113,64],[500,672,114,78],[559,672,95,68]]){
    let px=x,py=y;
    for(let i=1;i<=8;i++){const t=i/8,q=x+(tx-x)*t,v=y+(ty-y)*t+15*Math.sin(Math.PI*t);line(px,py,q,v,'#2d2136b4');px=q;py=v;}
  }
  for(let i=0;i<29;i++){
    const x=ri(634,685),y=ri(79,119);poly(i%3?'#322f3b':'#4a4047',x,y+23,x-5,y-6,x+5,y-14,x+12,y+5,x+4,y+20);
  }

  let request=0,last=-1, live=true;
  const reduce=!motion||matchMedia('(prefers-reduced-motion: reduce)').matches;
  const drop=Array.from({length:80},()=>[ri(190,686),ri(0,361),ri(2,6)]);
  const paint=t=>{
    if(!live)return;
    if(last<0||t-last>66){
      last=t;c.drawImage(page,0,0);
      if(!reduce){
        c.fillStyle='#edc79d';
        for(let i=0;i<21;i++){const x=340+((i*47+Math.floor(t/180))%289),y=235+(i*19)%116;c.globalAlpha=.08+(Math.sin(t/360+i)*.5+.5)*.14;c.fillRect(x,y,i%7+3,1);}
        c.globalAlpha=.24;c.fillStyle='#e0a99b';
        for(const [x,y,n] of drop){const xx=210+(x-210+Math.floor(t*.017))%464, yy=(y+Math.floor(t*(.052+n*.011)))%360;c.fillRect(xx,yy,1,n);}
        c.globalAlpha=1;
      }
    }
    if(!reduce)request=requestAnimationFrame(paint);
  };
  request=requestAnimationFrame(paint);return()=>{live=false;cancelAnimationFrame(request);};
}