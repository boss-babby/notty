import { CELL, DISTRICTS, PLACES } from './data.js';
import { hash, mod, rng } from './core.js';
import { bridgeDeck, cellKey, expansionWater, JETTY, laneWidth, METRO_LINE, wetland, widths, zoneFor } from './geography.js';

const TINTS = ['#5a9e91', '#db8b71', '#ddac6d', '#82a5ad', '#ba8ca1', '#aebc88'];
const AWNINGS = ['#bd583c','#4d8877','#cb954b','#54728c','#af595a','#6b7e9c'];
const LAYOUT = { 5:'flats',6:'homes',7:'terminal',8:'jheel',9:'offices',10:'bazaar',11:'fields',12:'mills' };
const WORDS = [
  '\u099a\u09be','\u09ab\u09b2','\u09ac\u09be\u099c\u09be\u09b0','\u09a6\u09cb\u0995\u09be\u09a8','\u09ac\u09be\u09b8','\u0998\u09be\u099f',
];

export function eastChunk(cx,cy,seed,broken) {
  const id=cellKey(cx,cy), x=cx*CELL,y=cy*CELL, zone=zoneFor(cx,cy), rand=rng(hash(cx,cy,seed));
  const pois=PLACES.filter(p=>p.cx===cx&&p.cy===cy), poi=pois[0];
  const blocks=[],props=[],trees=[],lights=[],street=[];
  const type=LAYOUT[zone] || 'flats';
  const land=(u,v,w,h)=>![[u,v],[u+w,v],[u+w,v+h],[u,v+h],[u+w/2,v+h/2]].some(([a,b])=>wetland(x+a,y+b));
  const block=(a,b,w,h,role,door=null)=>{
    if(x+a<JETTY.x+54&&x+a+w>JETTY.x-54&&y+b+h>9*CELL+60&&y+b<JETTY.end+6)return;
    if(!land(a-7,b-7,w+13,h+13) || blocks.some(q=>a+x<q.x+q.w+7&&x+a+w+7>q.x&&y+b<q.y+q.h+7&&y+b+h+7>q.y)) return;
    blocks.push({x:x+a,y:y+b,w,h,role,height:role==='tower'?16+Math.floor(rand()*19):role==='shop'?7+Math.floor(rand()*12):5+Math.floor(rand()*10),variant:Math.floor(rand()*TINTS.length),poi:door});
  };
  for(const p of pois) block(p.x-x-43,83,87,p.kind==='METRO'?107:78,p.kind==='METRO'?'station':p.kind==='GARAGE'?'shed':'shop',p);
  const gridX=type==='bazaar'||type==='jheel'?[[66,214,253,420],[45,150,229,350],[54,188,276,430]][hash(cx,cy,seed+241)%3]:null;
  const lots=[[64,82],[260,82],[66,269],[258,273]];
  if(type==='bazaar') {
    for(const [xx,yy] of lots) {
      for(let n=0;n<4;n++) {
        const a=xx+n*41+(n%2)*4, b=yy+(rand()*13|0), w=31+(rand()*9|0);
        if(a+w>426)continue;
        block(a,b,w,62+(rand()*46|0),'shop');
        if(rand()>.15)block(a-2,b+108,w,32+(rand()*16|0),'tin');
      }
    }
  } else if(type!=='fields'&&type!=='flats') {
    for(const [i,[xx,yy]] of lots.entries()) {
      if(type==='jheel'&&rand()<.54||type==='homes'&&i===2&&rand()<.5||type==='terminal'&&i===1)continue;
      const span=type==='mills'||type==='terminal'?138:type==='offices'?124:104;
      block(xx+(rand()*15|0),yy+(rand()*15|0),span+(rand()*19|0),type==='offices'?136+(rand()*10|0):91+(rand()*45|0),type==='offices'?'tower':type==='mills'||type==='terminal'?'shed':type==='homes'?'house':'tin');
      if(type==='homes'||type==='jheel')block(xx+118,yy+17,35,52,type==='homes'?'house':'tin');
    }
  } else if(type==='fields') {
    if(rand()>.19)block(105,89,72,54,'tin');
    if(rand()>.45)block(284,295,67,40,'tin');
  } else if(cx>=11&&rand()>.59)block(355,96,65,50,'tin');

  const free=(a,b,gap=13)=>!expansionWater(x+a,y+b)&&!blocks.some(q=>x+a>q.x-gap&&x+a<q.x+q.w+gap&&y+b>q.y-gap&&y+b<q.y+q.h+gap);
  for(let n=0;n<(type==='homes'||type==='fields'||type==='jheel'?27:11);n++) {
    const a=59+rand()*361,b=67+rand()*350;
    if(free(a,b,15)&&Math.abs(a-232)>22&&Math.abs(b-238)>22)trees.push({u:a,v:b,r:8+rand()*10,k:rand()>.68?'palm':'shade'});
  }
  for(const [i,[a,b]] of [[63,52],[413,52],[63,420],[413,420],[63,242],[256,54],[243,420]].entries()) {
    if(!free(a,b,5))continue;
    lights.push({x:x+a,y:y+b,hue:type==='bazaar'?(i%2?'#ffbd78':'#ffe3a7'):'#bff4e6'});
    street.push({u:a,v:b,kind:i%2?'pole':'drain',tone:i%6});
  }
  const scenery={bazaar:['tea','fruit','cart','bunting','sacks','kiosk'], offices:['median','steps','bench','planter','scooters','sign'], homes:['court','bench','planter','school','bikes','bunting'], terminal:['stop','cart','sacks','kiosk','barriers','scooters'], mills:['pallet','bricks','drums','crates','pallet','barriers'], jheel:['bench','steps','planter','bunting','kiosk','bikes'], fields:['sacks','cart','drums','bikes','pallet','bunting'], flats:['pallet','steps','drums','cart','sacks','bricks']}[type];
  for(let n=0;n<scenery.length;n++) {
    const a=[126,260,391,72,415,106][n]+(rand()*12|0), b=[54,49,248,234,333,421][n]+(rand()*7|0);
    if(free(a,b,10))street.push({u:a,v:b,kind:scenery[n],tone:(rand()*TINTS.length|0)});
  }
  if(type==='bazaar' && cx===14&&cy===7)street.push({u:119,v:62,kind:'tea',tone:2},{u:260,v:44,kind:'fruit',tone:1},{u:220,v:90,kind:'bunting',tone:3});
  for(let n=0;n<5;n++) {
    const a=[62,407,371,108,296][n]+(rand()*11|0),b=[137,169,249,419,418][n]+(rand()*6|0), kind=['crate','fence','sign','barrel','crate'][n];
    if(!free(a,b,14)||broken.has(`${id}:${n}`))continue;
    props.push({x:x+a,y:y+b,w:kind==='fence'?22:12,h:10,hp:27,type:'prop',kind,id:`${id}:${n}`});
  }
  const tape=rand()<.44&&type!=='flats'&&free(230,229,10)?{x:x+230,y:y+229,id:`tape-${id}`}:null;
  const vendors=street.filter(s=>s.kind==='tea'||s.kind==='fruit').map(s=>({x:x+s.u+8,y:y+s.v,kind:s.kind}));
  return {id,cx,cy,x,y,zone,type,blocks,props,trees,lights,tape,poi,pois,street,vendors,gridX,east:true};
}

function ink(g,x,y,w,h,c){g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
function line(g,c,w,pts){g.strokeStyle=c;g.lineWidth=w;g.beginPath();g.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=2)g.lineTo(pts[i],pts[i+1]);g.stroke();}
function oval(g,x,y,w,h,c){g.fillStyle=c;g.beginPath();g.ellipse(x,y,w,h,0,0,Math.PI*2);g.fill();}
function mono(g,t,x,y,color,size=10) {g.fillStyle=color;g.font=`700 ${size}px monospace`;g.textAlign='center';g.fillText(t,x,y);}

export function waterMask(g, bounds, scaleStep=5, onlyStrait=false, atlas=false) {
  const [x,y,w,h]=bounds;
  const tone=['','#293f54','#376366','#437078'];
  const wet=(a,b)=>{const n=wetland(a,b);return !onlyStrait||n===1?n:0;};
  const code=(a,b)=>{const n=wet(a,b);return n&&bridgeDeck(a,b,n)?n+3:n;};
  for(let v=0;v<h;v+=scaleStep) {
    let start=0, old=code(x+scaleStep/2,y+v+scaleStep/2);
    for(let u=scaleStep;u<=w;u+=scaleStep) {
      const next=u<w?code(x+u+scaleStep/2,y+v+scaleStep/2):-1;
      if(next===old)continue;
      if(old>0) {
        const fill=old>3?(atlas?'#707681':'#56545b'):tone[old];
        ink(g,start,v,u-start,scaleStep,fill);
        if(!atlas&&old<=3&&u-start>10) {
          if(mod(v+y,20)<scaleStep)ink(g,start+4,v+1,Math.min(18,u-start-4),1,'#8da69252');
        }
        if(!atlas&&old>3) {
          const band=old===4?mod(y+v+CELL/2,CELL)-CELL/2:mod(x+start+CELL/2,CELL)-CELL/2;
          if(old===4&&Math.abs(band)>29)ink(g,start,v,u-start,2,'#c1ad88');
          if(old!==4){ink(g,start+1,v,2,scaleStep,'#b4a086');ink(g,u-3,v,2,scaleStep,'#938783');}
          if(mod(y+v+23,48)<scaleStep&&old!==4)ink(g,start+(u-start)/2,v,2,scaleStep,'#dec597');
          else if(old===4&&Math.abs(band)<scaleStep)for(let q=start+4;q<u;q+=29)ink(g,q,v,10,2,'#e3be8b');
        }
      }
      start=u;old=next;
    }
  }
}

export function paintEast(g,b,seed) {
  const D=DISTRICTS[b.zone], R=rng(hash(b.cx,b.cy,seed+725)), {x,y}=b;
  const f=(...args)=>ink(g,...args);
  const road=b.type==='bazaar'?'#52494d':'#4c4c53', pavement=b.type==='bazaar'?'#857361':'#7d8179';
  f(0,0,CELL,CELL,D.ground);
  f(49,49,382,382,b.type==='fields'?'#65764c':b.type==='jheel'?'#526f61':b.type==='bazaar'?'#746052':D.ground);
  const [left,top]=widths(x,y),[right]=widths(x+CELL,y),[,bottom]=widths(x,y+CELL);
  f(0,0,left+11,CELL,pavement);f(CELL-right-11,0,right+11,CELL,pavement);
  f(0,0,CELL,top+11,pavement);f(0,CELL-bottom-11,CELL,bottom+11,pavement);
  f(0,0,left,CELL,road);f(CELL-right,0,right,CELL,road);f(0,0,CELL,top,road);f(0,CELL-bottom,CELL,bottom,road);
  const lane=laneWidth(b.cx,b.cy);
  if(['bazaar','homes','offices','mills','terminal'].includes(b.type)) {
    line(g,'#907d69',lane+6,[45,238,179,236,228,244,317,240,442,238]);
    line(g,'#524e52',lane,[45,238,179,236,228,244,317,240,442,238]);
    line(g,'#907d69',lane+5,[229,44,227,159,232,244,239,332,231,437]);
    line(g,'#554e51',lane,[229,44,227,159,232,244,239,332,231,437]);
  }
  if(b.gridX){
    const [a,d,q,k]=b.gridX;
    line(g,'#ac9679',9,[43,210,a,210,d,222,q,217,k,235,446,235]);
    line(g,'#655258',5,[43,210,a,210,d,222,q,217,k,235,446,235]);
  }
  for(let n=54;n<428;n+=34) {
    f(n,1,13,1,'#ae9c797d');f(n,478,13,1,'#ae9c797d');f(1,n,1,13,'#ae9c797d');f(478,n,1,13,'#ae9c797d');
    f(n,top+3,6,2,'#54504b');f(left+3,n,2,6,'#514b47');
  }
  for(const edge of [0,1])for(let k=6;k<28;k+=6) {
    f(edge?436:34,k,10,3,'#ccbe9a8e');f(k,edge?436:34,3,10,'#ccbe9a8e');
    f(edge?436:34,480-k-3,10,3,'#ccbe9a8e');f(480-k-3,edge?436:34,3,10,'#ccbe9a8e');
  }
  for(let n=0;n<1050;n++) {
    const u=R()*CELL,v=R()*CELL;
    f(u,v,1+(R()*5|0),1,R()>.46?'#d6bda325':'#25283032');
  }
  if(b.type==='fields')for(const [u,v,w,h] of [[68,164,135,54],[257,77,149,115],[72,267,131,120],[273,343,130,56]]){
    if(wetland(x+u+w/2,y+v+h/2))continue;
    f(u-5,v-5,w+10,h+10,'#a79a6b');f(u,v,w,h,'#3c5648');
    for(let i=5;i<w;i+=9){f(u+i,v,3,h,'#7c8857');for(let k=5;k<h;k+=8)f(u+i+1,v+k,5,1,'#a2b368');}
  }
  if(b.type==='homes'&&b.cx%2===0) {
    f(70,268,122,106,'#415b55');f(73,272,115,98,'#626f5d');
    g.strokeStyle='#cfc8a1';g.lineWidth=1;g.strokeRect(77,278,106,85);line(g,'#d4c6a0',1,[129,278,129,363]);oval(g,129,320,12,12,'#556958');
    f(70,309,7,21,'#ccc2a7');f(183,309,7,21,'#ccc2a7');
  }
  if(b.type==='terminal')for(let n=0;n<6;n++){
    f(264+n*24,86,1,81,'#c6b184');f(264+n*24,166,21,2,'#a79b7a');mono(g,`${n+1}`,271+n*24,99,'#e4c898',7);
  }

  waterMask(g,[x,y,CELL,CELL]);
  for(let n=0;n<260;n++) {
    const a=R()*CELL,v=R()*CELL;
    if(expansionWater(x+a,y+v))f(a,v,4+R()*15,1,R()>.52?'#8faf9c56':'#20373e57');
  }
  if(x<=JETTY.x && x+CELL>JETTY.x) {
    const a=JETTY.x-x,v=JETTY.y-y;
    if(v>-60&&v<CELL){
      f(a-43,v-25,86,30,'#817865');
      for(let s=0;s<5;s++)f(a-37+s*4,v-18+s*5,72-s*8,2,'#bfb28f');
      f(a-15,v-2,30,30,'#665947');f(a-15,v-2,2,29,'#d4b98c');f(a+13,v-2,2,29,'#d4b98c');
      for(let s=0;s<7;s++)f(a-12,v+s*4,24,1,'#b99468');
      mono(g,'KHEYA',a,v-7,'#ffddad',7);
    }
  }
  for(const t of b.trees) {
    const {u,v,r}=t;
    oval(g,u+5,v+6,r,r*.6,'#182b3175');
    if(t.k==='palm'){
      f(u-1,v,3,r,'#756650');
      for(let n=0;n<5;n++){const a=n*Math.PI*.4;line(g,n%2?'#596d4c':'#304e46',2,[u,v,u+Math.cos(a)*r*.68,v+Math.sin(a)*r*.68,u+Math.cos(a+.28)*r*1.4,v+Math.sin(a+.28)*r*1.4]);}
    }else{
      oval(g,u,v,r,r*.67,'#324c45');oval(g,u-r*.31,v-3,r*.67,r*.53,'#486251');oval(g,u+r*.29,v-4,r*.58,r*.43,'#546c50');f(u-4,v-5,r*.69,2,'#7d8b59');
    }
  }
  for(const q of b.blocks)paintBuilding(g,b,q,R);
  for(const s of b.street)if(!expansionWater(x+s.u,y+s.v))paintStreet(g,s);
  paintMetro(g,b);
}

function paintBuilding(g,b,q,R){
  const x=q.x-b.x,y=q.y-b.y,{w,h,height:z,variant:k,role}=q, door=q.poi;
  const f=(...args)=>ink(g,...args), c=TINTS[k];
  f(x+7,y+6,w+z,h+z,'#26303975');f(x+2,y+z/3,w+4,h+8,'#353b42');
  f(x-2,y-z*.44,w+4,h+z*.44,'#a39082');
  f(x+2,y-z*.44+3,w-4,h+z*.44-8,role==='tower'?'#747580':role==='tin'||role==='shed'?'#707c77':DISTRICTS[b.zone].roof);
  f(x+3,y-z*.44+3,w-6,1,'#d5bba780');
  f(x+w-3,y-z*.44+1,3,h+z*.44+7,'#574f54');
  if(role==='tin'||role==='shed') {
    for(let i=4;i<w-3;i+=5){f(x+i,y-z*.44+4,1,h+z*.44-10,'#d9c6a258');f(x+i+1,y-z*.44+4,1,h+z*.44-10,'#424d5369');}
    f(x+3,y+h*.65,w-6,3,c);
  } else if(role==='tower'||role==='station') {
    f(x+7,y+7,w-14,h-21,'#6e8392');f(x+11,y+9,w-22,h-26,'#465c6c');
    for(let n=0;n<5;n++){f(x+11,y+17+n*(h/7),w-22,2,'#9eb3adec');}
    for(let i=15;i<w-9;i+=11)f(x+i,y+11,1,h-29,'#536675');
    f(x+12,y+h-16,w-24,5,c);f(x+8,y+2,24,11,'#d2ccaf');f(x+9,y+3,22,2,'#ece0c4');
  } else {
    const count=role==='shop'?2:4;
    for(let n=0;n<count;n++){
      const u=x+5+R()*(w-13),v=y+6+R()*(h-21);f(u+2,v+3,8,8,'#38343a');f(u,v,8,7,n%2?'#9e9b79':'#a9907b');
    }
    if(w>43||k<3){oval(g,x+w*.7,y+h*.32,7,7,'#343d47');oval(g,x+w*.68,y+h*.29,6,6,'#596c74');f(x+w*.67,y+h*.26,5,2,'#85989a');}
    if(w>45&&k%2===1){f(x+5,y+h*.54,w*.39,12,'#bd826c');for(let n=0;n<5;n++)f(x+7+n*3,y+h*.54+n%2*3,2,4,'#eed1a1');}
  }
  f(x+1,y+h-2,w-2,3,'#655451');
  for(let n=6;n<w-4;n+=9){f(x+n,y+h+2,5,4,'#272e36');if((n+k)%3)f(x+n+1,y+h+2,3,2,k%2?'#e9ba82':'#b4bba3');}
  if(role==='shop'||door){
    const u=door?door.x-b.x:x+w*.53, hh=door?29:Math.min(w-3,30);
    f(u-hh/2,y-9,hh,10,AWNINGS[k]);
    for(let j=0;j<hh-2;j+=5)if(j%2===0)f(u-hh/2+j,y-9,2,8,'#efd7a071');
    f(u-hh/2,y-1,hh,2,'#272f3e');
    if(door){
      f(u-6,y-13,12,3,'#ffdc9f');f(x+12,y+h*.52-10,w-24,25,'#283f4b');
      if(door.bn){g.textAlign='center';g.font='bold 12px "Noto Sans Bengali", sans-serif';g.fillStyle='#f2cc9b';g.fillText(door.bn,u,y+h*.52+1);}
      mono(g,door.sign,u,y+h*.52+(door.bn?11:5),'#f1dfb3',7);
    }else if(w>31){f(x+4,y+7,w-8,9,'#4f5e61');g.textAlign='center';g.font='bold 7px "Noto Sans Bengali",sans-serif';g.fillStyle='#ddc997';g.fillText(WORDS[k],u,y+14);}
  }
}

function paintStreet(g,s){
  const x=s.u,y=s.v,k=s.tone,l=AWNINGS[k], f=(a,b,...rest)=>ink(g,x+a,y+b,...rest);
  if(['tea','fruit','kiosk','stop'].includes(s.kind)){
    f(-1,2,39,15,'#34333678');f(1,-3,33,13,s.kind==='stop'?'#4c787e':l);
    for(let i=3;i<33;i+=6)f(i,-3,2,11,'#e9cb9780');
    f(2,8,30,3,'#e7bc86');f(3,11,2,5,'#544b48');f(29,11,3,5,'#4b4748');
    if(s.kind==='fruit')for(let i=3;i<30;i+=6){f(i,12,5,4,['#ddab5b','#cc765a','#8ca45a'][i%3]);f(i+1,12,2,1,'#fbd88d');}
    if(s.kind==='tea'){f(9,11,5,5,'#b7ab8c');f(10,10,4,1,'#e7d4ac');f(21,12,3,3,'#e9cc9f');f(27,12,3,3,'#e9cc9f');}
    if(s.kind==='stop')mono(g,'BUS',x+17,y+5,'#f1dfac',6);
  }else if(s.kind==='pole'){
    f(1,-8,2,16,'#3b3a3c');f(-4,-7,11,2,'#544a46');let offset=(k%3-1)*9;
    for(let i=0;i<3;i++)line(g,'#242d39a0',1,[x-8,y-8+i,x+22,y-3+i,x+55,y+offset+i]);
  }else if(s.kind==='bunting'){
    line(g,'#b89974',1,[x-8,y-7,x+13,y+1,x+38,y-9]);for(let j=0;j<7;j++)f(j*6-5,j<3?j-5:2-j,4,3,AWNINGS[(j+k)%AWNINGS.length]);
  }else if(['bench','barriers','median','steps','drain'].includes(s.kind)){
    if(s.kind==='steps')for(let i=0;i<5;i++){f(i*2,-5+i*3,29-i*4,3,i%2?'#9a9080':'#b4a185');}
    else if(s.kind==='drain'){f(0,0,17,8,'#3f454a');for(let i=1;i<16;i+=3)f(i,1,1,6,'#797970');}
    else {f(0,5,28,5,'#353b3d');f(0,0,27,6,s.kind==='median'?'#738459':l);for(let j=3;j<24;j+=6)f(j,0,3,4,'#e0bd8c');}
  }else if(['bikes','scooters','cart'].includes(s.kind)){
    for(let i=0;i<3;i++) {f(i*8,2,5,9,'#30333b');f(i*8+1,1,3,9,AWNINGS[(k+i)%AWNINGS.length]);f(i*8+1,-2,3,3,'#34363c');}
    if(s.kind==='cart'){f(0,0,21,10,'#b38e60');for(let i=2;i<19;i+=5)f(i,2,3,3,'#aaba68');}
  }else{
    for(let j=0;j<6;j++){f(j*4,j%2*4,6,7,'#3a4545');f(j*4-1,j%2*4-2,5,6,s.kind==='planter'?'#829763':s.kind==='drums'?'#8caa9e':s.kind==='sacks'?'#bfab7d':'#b88768');}
  }
}

function paintMetro(g,b){
  const pts=METRO_LINE.flatMap(([x,y])=>[x-b.x,y-b.y]);
  if(b.cy>7||b.cx<13||b.cx>17)return;
  const f=(...a)=>ink(g,...a);
  g.save();g.beginPath();g.rect(0,0,CELL,CELL);g.clip();
  const shifted=pts.map((n,i)=>n+(i%2?13:13));
  line(g,'#242c3a8a',23,shifted);line(g,'#9f9e91',20,pts);line(g,'#656f76',15,pts);line(g,'#404957',10,pts);line(g,'#a8ae9c',2,pts);
  for(let i=1;i<METRO_LINE.length;i++){
    const [ax,ay]=METRO_LINE[i-1],[cx,cy]=METRO_LINE[i], len=Math.hypot(cx-ax,cy-ay);
    for(let d=35;d<len;d+=108){const x=ax+(cx-ax)*d/len-b.x,y=ay+(cy-ay)*d/len-b.y;if(x>-20&&x<490&&y>-20&&y<490){f(x-7,y-5,14,10,'#b0a796');f(x-6,y-3,12,2,'#d7cbb0');f(x+4,y+6,9,8,'#353b41');}}
  }
  g.restore();
}