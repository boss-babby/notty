import { VENUE_CAST } from './atlas-data.js';

const r=(x,y,w,h,t)=>({x,y,w,h,t});
export function atlasRoom(p,layout){
  const id=p.id,kind=p.kind,spot=(id,name,x,y)=>({id,name,x,y}),point=(x,y)=>({x,y});
  if(kind==='AIRPORT')return layout(id,p.name.toUpperCase(),'CIVIL AIR / DEPARTURES',r(52,68,616,338),['#b9dfd6','#8ba8c4','#4c5861'],
    [r(56,72,608,330,'marble'),r(66,90,581,80,'platform'),r(93,232,533,132,'tile')],
    [r(91,110,129,35,'ticket'),r(291,112,141,39,'counter'),r(492,112,127,42,'shelf'),r(103,211,144,23,'bench'),r(103,268,144,23,'bench'),r(469,213,141,25,'bench'),r(469,269,141,25,'bench'),r(276,177,8,128,'pillar'),r(432,194,8,116,'pillar')],
    [r(70,76,574,11,'glass'),r(283,317,144,31,'queue'),r(97,162,130,5,'queue'),r(494,163,123,5,'queue')],
    [[357,151,128,'#a9dcd0'],[155,229,126,'#d7c9b2'],[541,225,115,'#abd2de']],{service:point(358,181),spots:[spot('departures','Read the departure board',550,181)],scale:.95});
  if(kind==='SEA TERMINAL')return layout(id,p.name.toUpperCase(),'MARINA / PUBLIC FERRIES',r(81,70,563,332),['#b3e6d7','#6cbaa9','#456065'],
    [r(85,74,556,322,'wood'),r(103,101,512,80,'platform'),r(106,216,499,136,'stone')],
    [r(112,107,143,34,'windowbench'),r(288,104,153,54,'counter'),r(472,110,116,41,'ticket'),r(118,238,123,28,'bench'),r(131,307,102,39,'crate'),r(476,225,107,41,'desk'),r(480,303,106,32,'windowbench')],
    [r(100,80,522,13,'waterwindow'),r(265,244,171,55,'compass'),r(297,343,124,12,'safety')],
    [[352,147,136,'#b8e8d7'],[529,207,113,'#8ad9d2']],{service:point(362,181),spots:[spot('departures','Check sea departures',520,178)],scale:1});
  if(kind==='CLUB'){
    const sea=id==='tide-room', tint=sea?'#a1e0d0':'#f2a7ce';
    const crew=VENUE_CAST[id]||[];
    return layout(id,p.name.toUpperCase(),sea?'CRESCENT / LISTENING LOUNGE':'JACKLIGHT / AFTER HOURS',r(84,71,550,326),[tint,sea?'#78a3ad':'#996bc1','#3b354e'],
      [r(89,75,540,317,'arcadefloor'),r(221,158,275,157,'tile'),r(105,269,101,90,'carpet'),r(501,208,113,134,'carpet')],
      [r(282,98,149,34,'radio'),r(106,105,130,40,'counter'),r(491,105,112,39,'rack'),r(107,193,93,31,'sofa'),r(108,314,103,32,'sofa'),r(528,171,76,32,'bench'),r(525,314,79,35,'sofa')],
      [r(99,79,516,11,sea?'waterwindow':'neonbar'),r(232,305,248,4,'neonbar'),r(226,158,264,7,'safety'),r(274,205,154,55,'compass')],
      [[355,153,104,tint],[182,224,111,'#e0ad99'],[520,252,115,sea?'#82d8ca':'#cfa0d7']],{service:point(156,167),spots:crew.map((n,i)=>spot(`club-talk:${i}`,`Talk to ${n.name}`,n.x,n.y+14)),scale:1,club:true});
  }
  if(kind==='CASINO')return layout(id,p.name.toUpperCase(),'JACKLIGHT / FREE PLAY FLOOR',r(92,68,535,333),['#fac69d','#bd82bb','#543a52'],
    [r(97,74,524,320,'arcadefloor'),r(141,167,431,161,'carpet'),r(286,87,155,291,'marble')],
    [r(108,100,133,23,'cabinet'),r(470,97,132,25,'cabinet'),r(129,174,78,50,'tablegame'),r(216,262,63,53,'tablegame'),r(470,174,87,52,'tablegame'),r(478,265,76,55,'tablegame'),r(310,131,104,35,'counter'),r(116,313,90,32,'counter')],
    [r(107,76,501,9,'neonbar'),r(290,315,141,31,'rugframe'),r(271,190,177,17,'safety')],
    [[356,165,112,'#f3c1a0'],[175,245,126,'#eeb4c0'],[517,239,126,'#cba1e2']],{service:point(357,188),spots:[spot('jacklight','Play the Jacklight Score Table',246,240)],scale:1});
  if(kind==='ARMY CAMP')return layout(id,p.name.toUpperCase(),'EMBER DETAIL / PUBLIC FIELD OFFICE',r(79,70,562,322),['#ded7a2','#8fa293','#4d5b57'],
    [r(84,74,551,313,'concrete'),r(100,94,211,226,'service'),r(423,91,193,235,'service')],
    [r(106,109,147,35,'rack'),r(155,198,107,33,'workbench'),r(121,277,116,33,'crate'),r(473,106,122,42,'archive'),r(481,185,108,63,'crate'),r(488,286,102,44,'workbench'),r(302,120,115,32,'counter')],
    [r(92,79,530,12,'glass'),r(277,297,162,14,'safety'),r(284,234,149,21,'compass')],
    [[358,150,117,'#ded9af'],[493,202,127,'#a9c9b6']],{service:point(361,177),spots:[spot('quarters','Read the regional relief board',449,258)],scale:1});
  if(kind==='OBSERVATORY')return layout(id,p.name.toUpperCase(),'MERIDIAN / SKY GALLERY',r(101,71,518,324),['#b8e5d9','#87b8c8','#516673'],
    [r(105,76,508,313,'marble'),r(129,106,461,244,'platform')],
    [r(120,102,126,39,'windowbench'),r(464,104,130,40,'windowbench'),r(114,257,110,39,'bench'),r(489,260,101,38,'bench'),r(295,152,132,38,'counter')],
    [r(119,80,488,17,'waterwindow'),r(285,252,148,42,'compass'),r(276,212,164,7,'safety')],
    [[356,154,144,'#bce4d8'],[188,239,121,'#ecc494']],{service:point(357,211),spots:[spot('observer','Open the regional chart',372,279)],scale:1});
  const garage=kind==='GARAGE', clinic=kind==='CLINIC';
  return layout(id,p.name.toUpperCase(),garage?'ATLAS / MOTORWORKS':clinic?'ATLAS / PATIENT SERVICES':'ATLAS / SUPPLIES AND TEA',r(89,71,551,325),['#ecc49a',clinic?'#a2c8b6':'#bd967c','#51474c'],
    [r(94,76,541,313,garage?'concrete':clinic?'tile':'brick'),r(104,96,522,213,garage?'service':clinic?'linoleum':'checker')],
    [r(111,110,126,43,garage?'workbench':clinic?'hospitalbed':'shelf'),r(477,109,125,47,garage?'rack':clinic?'hospitalbed':'produce'),r(136,224,107,49,garage?'lift':clinic?'bench':'produce'),r(493,221,102,52,garage?'toolwall':clinic?'cold':'spices'),r(307,134,108,34,'counter'),r(124,320,106,25,'bench'),r(483,320,118,26,'crate')],
    [r(103,81,513,9,garage?'glass':clinic?'window':'awning'),r(294,327,133,15,'queue')],
    [[360,163,120,'#f1c798'],[183,233,103,'#bcd8bf']],{service:point(361,190),spots:garage?[spot('dyno','Try the workshop dyno',265,239)]:[],scale:1});
}