import { CELL, COLS, ROWS, SEED } from './data.js';
import { clamp, hash, mix, mod } from './core.js';

// Adjacent chunks sample the same low-frequency fields and the same undirected road edges.
export const MODELS=['continental','islands','badlands'];
const SOUK=14,TOWERS=15,MARINA=16,GARDENS=17,STRIP=18,COURTS=19,AIRSTRIP=20,CAMP=21,WORKS=22;
const DUNES=23,CANYON=24,SALT=25,OASIS=26,ISLANDS=27,SEA=28,JUNIPER=29;
const spans=new Map();
const smooth=x=>x*x*(3-2*x);
const grain=(x,y,seed)=>{let h=hash(x,y,seed);h=Math.imul(h^(h>>>16),0x7feb352d);h=Math.imul(h^(h>>>15),0x846ca68b);return ((h^(h>>>16))>>>0)/4294967295;};

export function terrainNoise(x,y,seed){
  const a=Math.floor(x),b=Math.floor(y),u=smooth(x-a),v=smooth(y-b);
  return mix(mix(grain(a,b,seed),grain(a+1,b,seed),u),mix(grain(a,b+1,seed),grain(a+1,b+1,seed),u),v);
}

export const originalCell=(x,y)=>x>=0&&x<COLS&&y>=0&&y<ROWS;
export const mirageCell=(x,y)=>x>=24&&x<=31&&y>=0&&y<=7;
export const basinCell=(x,y)=>x>=23&&x<=31&&y>=12&&y<=18;
const nearHome=(x,y)=>x>=-1&&x<=32&&y>=-1&&y<=19;

export function outerRegion(cx,cy){
  if(mirageCell(cx,cy))return 'mirage';if(basinCell(cx,cy))return 'basin';
  return 'wilds';
}

function coast(x,y){
  const t=clamp((y-980)/2760,0,1);
  const edge=15322-Math.sin(t*Math.PI)*1318+Math.sin(y*.003)*92;
  const sea=x>edge&&x<17880&&y>1080&&y<3560;
  if(!sea)return false;
  const u=x-15180,v=y-2430,r=Math.hypot(u,v*1.22),a=Math.atan2(v*1.22,u);
  const crescent=r>340&&r<444&&(a<-.18||a>1.36)&&x<15810;
  const pier=x<14540&&y>2022&&y<2169;
  return !crescent&&!pier;
}

function fieldCell(cx,cy,seed,style){
  if(cx===2&&cy===-1)return 13;
  if(mirageCell(cx,cy)){
    if(cy<=1&&cx<=27)return 13;
    if(cx>=29&&cy>=3&&cy<=6)return MARINA;
    if(cx<=26&&cy>=2&&cy<=4)return SOUK;
    if(cy<=4&&cx>=27)return TOWERS;
    return GARDENS;
  }
  if(basinCell(cx,cy)){
    if(cx>=30&&cy>=16)return CAMP;
    if(cy>=17&&cx<=26)return AIRSTRIP;
    if(cx>=29&&cy<=14)return WORKS;
    if(cx>=25&&cx<=29&&cy>=14&&cy<=16)return STRIP;
    return COURTS;
  }
  const elevation=terrainNoise(cx/10.7,cy/9.5,seed+143);
  const humidity=terrainNoise(cx/14+2,cy/12-2,seed+831);
  const cut=terrainNoise(cx/6.8-2,cy/8.5+1,seed+345);
  if(!nearHome(cx,cy)&&humidity>(style==='islands'?.44:style==='badlands'?.83:.665)&&elevation<.59)return elevation<.38?SEA:ISLANDS;
  if(style==='badlands'&&cut>.48||cut>.66&&elevation>.46)return CANYON;
  if(elevation<(style==='badlands'?.48:.322))return SALT;
  if(humidity>.60&&cut>.40)return JUNIPER;
  if(humidity>.51&&elevation<.59&&cut<.49)return OASIS;
  return DUNES;
}

export function outerZone(cx,cy,seed=SEED,style='continental'){
  const key=`${seed}:${style}:${cx}:${cy}`;
  const old=spans.get(key);if(old!==undefined)return old;
  const v=fieldCell(cx,cy,seed,style);spans.set(key,v);
  if(spans.size>2400)spans.delete(spans.keys().next().value);
  return v;
}

export function outerWater(x,y,seed=SEED,style='continental'){
  if(x>13940&&x<17900&&y>1000&&y<3600&&coast(x,y))return true;
  const cx=Math.floor(x/CELL),cy=Math.floor(y/CELL);
  if(nearHome(cx,cy))return false;
  const humidity=terrainNoise(x/(CELL*14)+2,y/(CELL*12)-2,seed+831);
  const elevation=terrainNoise(x/(CELL*10.7),y/(CELL*9.5),seed+143);
  const water=(style==='islands'?.49:style==='badlands'?.83:.68);
  const bay=terrainNoise(x/(CELL*2.92),y/(CELL*3.36),seed+24);
  return humidity>water&&elevation<.53&&elevation+bay*.135<.53;
}

export function trunk(x,y){
  const v=x<23||x>31?mod(x,8)===3:x===23||x===28||x===31;
  const h=y<0||y>18?mod(y,7)===2:[1,3,7,12,14,17,18].includes(y);
  return {v,h};
}

export function outerEdge(ax,ay,bx,by,seed=SEED,style='continental'){
  const horizontal=ay===by,x=Math.min(ax,bx),y=Math.min(ay,by);
  const main=horizontal?trunk(x,y).h:trunk(x,y).v;
  const urban=outerRegion(x,y)!=='wilds'||outerRegion(horizontal?x:x-1,horizontal?y-1:y)!=='wilds';
  const mx=(ax+bx)*CELL/2,my=(ay+by)*CELL/2;
  const water=outerWater(mx,my,seed,style);
  if(water&&!main)return 0;
  if(horizontal&&y>=1&&y<=7&&x>=30&&x<=36&&![3,4,7].includes(y))return 0;
  if(!horizontal&&x>=31&&x<=36&&y>=2&&y<7&&x!==31)return 0;
  if(main)return (horizontal?[3,7].includes(y)&&x>=22&&x<=30:false)?34:26;
  if(ax>=0&&ay>=0&&bx>=0&&by>=0&&(originalCell(ax,ay)||originalCell(bx,by)))return 24;
  if(urban){
    if(basinCell(x,y))return horizontal?(y%2===0?25:15):[24,26,27,30].includes(x)?24:grain(x,y,seed+905)>.27?13:0;
    if(mirageCell(x,y))return horizontal?(y%2?24:grain(x,y,seed+302)>.18?15:0):[25,27,29,30].includes(x)?24:grain(x,y,seed+72)>.42?13:0;
  }
  const junction=horizontal?trunk(x,y).v||trunk(x+1,y).v:trunk(x,y).h||trunk(x,y+1).h;
  const complete=grain(horizontal?x:y,horizontal?y:x,seed+(horizontal?228:417));
  if(junction&&complete>.40)return 13;
  if(mod(x+(horizontal?0:2),4)===0&&complete>.68)return 10;
  return 0;
}

export function edgeWidths(cx,cy,seed,style){return [outerEdge(cx,cy,cx+1,cy,seed,style),outerEdge(cx+1,cy,cx+1,cy+1,seed,style),outerEdge(cx,cy+1,cx+1,cy+1,seed,style),outerEdge(cx,cy,cx,cy+1,seed,style)];}

export function outerRoadAt(x,y,seed=SEED,style='continental'){
  const cx=Math.floor(x/CELL),cy=Math.floor(y/CELL),u=mod(x,CELL),v=mod(y,CELL);
  if(Math.min(u,v,CELL-u,CELL-v)>34)return false;
  const [a,b,c,d]=edgeWidths(cx,cy,seed,style);
  return (a>0&&v<a)||(b>0&&CELL-u<b)||(c>0&&CELL-v<c)||(d>0&&u<d);
}

export function pointKey(seed,style,x,y){return `survey:${seed}:${style}:${x}:${y}`;}
export function surveyAt(cx,cy,seed=SEED,style='continental'){
  if(originalCell(cx,cy)||outerRegion(cx,cy)!=='wilds'||cx===2&&cy===-1)return null;
  const sectorX=Math.floor(cx/3),sectorY=Math.floor(cy/3);
  const lucky=grain(sectorX,sectorY,seed+48)<.29;
  if(mod(cx,3)!==Math.floor(grain(sectorX,sectorY,seed+400)*3)||mod(cy,3)!==Math.floor(grain(sectorX,sectorY,seed+92)*3)||!lucky)return null;
  const x=cx*CELL+236,y=cy*CELL+213;
  if(outerWater(x,y,seed,style))return null;
  return {x,y,id:pointKey(seed,style,cx,cy),label:['Weather beacon','Trail relay','Survey cairn','Field receiver'][Math.floor(grain(cx,cy,seed+454)*4)]};
}