import { ATLAS_DISTRICTS, ATLAS_JOBS, ATLAS_PLACES } from './atlas-data.js';

export const CELL = 480;
export const COLS = 22;
export const ROWS = 12;
export const WIDTH = CELL * COLS;
export const HEIGHT = CELL * ROWS;
export const START = { x: 1128, y: 988 };
export const MONSOON_START = { x: 6886, y: 3403 };
export const SEED = 824719;

export const DISTRICTS = [
  { name: 'Neon Quarter', code: 'NQ', color: '#fe5779', roof: '#443151', ground: '#2f2937', faction: 'Prism Crew', label: [3.25, 2.85] },
  { name: 'Iron Docks', code: 'ID', color: '#ffad74', roof: '#51404a', ground: '#322a31', faction: 'Coil Union', label: [2.65, 6.7] },
  { name: 'Lark Terraces', code: 'LT', color: '#7ad8b0', roof: '#3c4b4c', ground: '#303738', faction: 'Coil Union', label: [5.85, 5.0] },
  { name: 'Glass Coast', code: 'GC', color: '#75d5f0', roof: '#3c4463', ground: '#2d3443', faction: 'Prism Crew', label: [8.8, 5.3] },
  { name: 'Uplink Hills', code: 'UH', color: '#bc9cfa', roof: '#48415a', ground: '#333140', faction: 'Civic Grid', label: [4.5, 1.25] },
  { name: 'Silt Flats', code: 'SF', color: '#83b6b1', roof: '#4b6056', ground: '#3e5550', faction: 'River Cooperative', label: [8.3, 9.5] },
  { name: 'North Enclave', code: 'NE', color: '#a9d697', roof: '#75837a', ground: '#59654d', faction: 'Civic Union', label: [15.2, 1.42] },
  { name: 'Terminal Ward', code: 'TW', color: '#eacc88', roof: '#858377', ground: '#625e53', faction: 'Civic Union', label: [20.1, 1.42] },
  { name: 'Jheel Lakes', code: 'JL', color: '#87e2d1', roof: '#626f76', ground: '#475e60', faction: 'River Cooperative', label: [18.3, 3.54] },
  { name: 'Shapla Center', code: 'SC', color: '#b0beed', roof: '#70778b', ground: '#575a69', faction: 'Verge Works', label: [15.3, 5.73] },
  { name: 'Puran Bazaar', code: 'PB', color: '#ffb079', roof: '#8e6b60', ground: '#65534f', faction: 'River Cooperative', label: [15.2, 7.62] },
  { name: 'Char Gardens', code: 'CG', color: '#c8dc86', roof: '#8c8161', ground: '#5d684b', faction: 'River Cooperative', label: [16.8, 10.65] },
  { name: 'Kadam Mills', code: 'KM', color: '#dd9986', roof: '#83665f', ground: '#635756', faction: 'Verge Works', label: [20.1, 7.14] },
  ...ATLAS_DISTRICTS,
];

export const PLACES = [
  ['relay', 'The Relay', 'SAFEHOUSE', 2, 2, 'THE RELAY'],
  ['garage', 'Sable Motorworks', 'GARAGE', 3, 2, 'MOTORWORKS'],
  ['market', 'Rill Night Market', 'SHOP', 4, 2, 'NIGHT MARKET'],
  ['archive', 'Vesper Trust', 'BANK', 3, 3, 'VESPER TRUST'],
  ['station', 'Grid Precinct 04', 'PRECINCT', 1, 3, 'GRID / 04'],
  ['hospital', 'St. Echo Medical', 'CLINIC', 2, 3, 'ST. ECHO'],
  ['loft', 'Morrow Loft', 'APARTMENT', 5, 3, 'MORROW LOFT'],
  ['dock', 'Pier 07 Exchange', 'EXCHANGE', 2, 5, 'PIER / 07'],
  ['arcade', 'Soft Reset', 'ARCADE', 8, 3, 'SOFT RESET'],
  ['switch', 'North Exchange', 'GHOST RELAY', 4, 1, 'NORTH UPLINK'],
  ['coast', 'End of the Line', 'GHOST RELAY', 8, 5, 'COAST UPLINK'],
  ['cha', 'Nodi Cha House', 'TEA & FOOD', 14, 7, 'NODI CHA', '\u099a\u09be'],
  ['ghat', 'Shapla Ghat', 'RIVER TERMINAL', 15, 8, 'SHAPLA GHAT', '\u0998\u09be\u099f'],
  ['bazaar', 'Kheya Produce Hall', 'SHOP', 13, 7, 'KHEYA BAZAAR', '\u09ac\u09be\u099c\u09be\u09b0'],
  ['citymetro', 'Shapla Metro', 'METRO', 14, 5, 'SHAPLA METRO', '\u09ae\u09c7\u099f\u09cd\u09b0\u09cb'],
  ['northmetro', 'Enclave Metro', 'METRO', 16, 1, 'ENCLAVE METRO', '\u09ae\u09c7\u099f\u09cd\u09b0\u09cb'],
  ['oldmetro', 'Puran Metro', 'METRO', 14, 7, 'PURAN METRO', '\u09ae\u09c7\u099f\u09cd\u09b0\u09cb', 328],
  ['works', 'Kadam Works Depot', 'GARAGE', 19, 6, 'KADAM WORKS', '\u0997\u09cd\u09af\u09be\u09b0\u09c7\u099c'],
  ['mclinic', 'Kheya Community Clinic', 'CLINIC', 15, 7, 'KHEYA CLINIC', '\u0995\u09cd\u09b2\u09bf\u09a8\u09bf\u0995'],
  ['lake', 'Jheel Promenade Office', 'VISITOR OFFICE', 17, 5, 'JHEEL WALK', '\u099d\u09bf\u09b2'],
  ['garden', 'Char Cooperative', 'FARM EXCHANGE', 17, 10, 'CHAR CO-OP', '\u099a\u09b0'],
  ['bus', 'Megh Terminal', 'BUS TERMINAL', 20, 1, 'MEGH TERMINAL', '\u09ac\u09be\u09b8'],
  ['shelter', 'Signal Shelter', 'SAFEHOUSE', 14, 6, 'SIGNAL SHELTER'],
  ['swapmeet','Lantern Exchange','SWAP MEET',18,5,'LANTERN EXCHANGE','\u09ac\u09be\u099c\u09be\u09b0'],
  ['bay','Anchor Training Bay','PRACTICE',16,6,'ANCHOR BAY'],
  ...ATLAS_PLACES,
].map(([id, name, kind, cx, cy, sign, bn, dx = 140]) => ({ id, name, kind, cx, cy, sign, bn, x: cx * CELL + dx, y: cy * CELL + 61 }));
export const place = id => PLACES.find(p => p.id === id);

export const GARAGE = [
  { id: 'vox', name: 'Vox Compact', class: 'COMPACT', color: '#a6b5c1', l: 36, w: 19, max: 295, power: 425, grip: 7, hp: 100, price: 180 },
  { id: 'regent', name: 'Regent LX', class: 'SEDAN', color: '#c58ba3', l: 43, w: 22, max: 322, power: 444, grip: 6.9, hp: 125, price: 280 },
  { id: 'vanta', name: 'Vanta GT', class: 'SPORT', color: '#f35876', l: 44, w: 23, max: 414, power: 565, grip: 7.8, hp: 110, price: 550 },
  { id: 'havoc', name: 'Havoc 8', class: 'MUSCLE', color: '#ef9365', l: 45, w: 23, max: 384, power: 536, grip: 5.4, hp: 148, price: 450 },
  { id: 'mule', name: 'Mule Parcel', class: 'VAN', color: '#e0bc87', l: 49, w: 24, max: 283, power: 375, grip: 5.6, hp: 162, price: 310 },
  { id: 'ibis', name: 'Ibis Flatbed', class: 'PICKUP', color: '#81b6ab', l: 47, w: 22, max: 302, power: 398, grip: 5.9, hp: 150, price: 320 },
  { id: 'moth', name: 'Moth Circuit', class: 'MOTORCYCLE', color: '#b694f6', l: 31, w: 10, max: 392, power: 554, grip: 8.6, hp: 68, price: 390 },
  { id: 'liner', name: 'Night Liner', class: 'BUS', color: '#779ec7', l: 71, w: 26, max: 242, power: 295, grip: 4.6, hp: 202, price: 510 },
  { id: 'patrol', name: 'Grid Interceptor', class: 'PATROL', color: '#7499ce', l: 45, w: 23, max: 375, power: 508, grip: 7.6, hp: 155, price: 640 },
  { id: 'rickshaw', name: 'Shapla Rickshaw', class: 'PEDAL', color: '#e88170', l: 41, w: 18, max: 169, power: 290, grip: 8.8, hp: 64, price: 120 },
  { id: 'cng', name: 'Kite CNG', class: 'THREE-WHEELER', color: '#62aa73', l: 36, w: 19, max: 254, power: 392, grip: 7.9, hp: 94, price: 240 },
  { id: 'megh', name: 'Megh Citylink', class: 'BUS', color: '#70ad82', l: 83, w: 29, max: 248, power: 284, grip: 4.9, hp: 225, price: 620 },
  { id: 'kadam', name: 'Kadam Mini Truck', class: 'HAULER', color: '#70baca', l: 56, w: 24, max: 278, power: 359, grip: 5.8, hp: 170, price: 370 },
  { id: 'rescue', name: 'Echo Relief Van', class: 'RESCUE', color: '#e1dbc3', l: 53, w: 24, max: 306, power: 420, grip: 6.5, hp: 165, price: 440 },
  { id: 'launch', name: 'Kheya Water Taxi', class: 'BOAT', color: '#7bbfba', l: 55, w: 20, max: 294, power: 392, grip: 3.8, hp: 125, price: 0 },
  { id: 'floodworks', name: 'Tread-6 Floodworks', class: 'TRACKED', color: '#cb9b5c', l: 64, w: 32, max: 198, power: 340, grip: 9.5, hp: 445, price: 850 },
  { id: 'bastion', name: 'Bastion Carrier', class: 'TANK', color: '#8a9b76', l: 67, w: 34, max: 229, power: 385, grip: 10.3, hp: 530, price: 1400 },
  { id: 'chain', name: 'Chainline Bicycle', class: 'BICYCLE', color: '#ccaf85', l: 30, w: 10, max: 195, power: 284, grip: 9.6, hp: 51, price: 80 },
  { id: 'warden', name: 'Warden Tow', class: 'SERVICE', color: '#d3ab6c', l: 62, w: 25, max: 247, power: 364, grip: 6.8, hp: 230, price: 400 },
  { id: 'aero', name: 'Aero Surveyor', class: 'AIR', color: '#b9ccd5', l: 55, w: 22, max: 345, power: 440, grip: 4.4, hp: 178, price: 1150 },
  { id:'hearth',name:'Hearth Response',class:'RESCUE',color:'#bd746f',l:73,w:29,max:244,power:325,grip:5.1,hp:241,price:760 },
];

export const modelIndex = id => GARAGE.findIndex(v => v.id === id);
export const MODES = {
  campaign: { name: 'Vesper Bay', short: 'The original campaign', n: '01', icon: 'pin', saveKey: 'save' },
  monsoon: { name: 'Monsoon Lines', short: 'The Dhaka-inspired expansion', n: '02', icon: 'rain', saveKey: 'save-monsoon' },
  outbreak: { name: 'Outbreak', short: 'Zombie survival', n: '03', icon: 'outbreak', saveKey: 'save-outbreak' },
  practice: { name: 'Training Bay', short: 'Isolated combat drills', n: '04', icon: 'cross', saveKey: 'practice-only' },
  atlas: {name:'Open Atlas',short:'The world beyond the old map',n:'05',icon:'map',saveKey:'save-atlas'},
};

// Numbers describe an arcade weapon model, not a physical simulation.
export const GEAR = [
  ['hands', 'Fists', 'MELEE', 0, 0, 14, .37, 0, 34, 1, 0, 'melee'],
  ['bat', 'Alley Bat', 'MELEE', 0, 0, 29, .54, 0, 45, 1, 30, 'melee'],
  ['blade', 'Coil Blade', 'MELEE', 0, 0, 22, .29, 0, 34, 1, 65, 'melee'],
  ['pistol', 'Relay Pistol', 'LIGHT', 12, 1.1, 25, .24, .09, 410, 1, 0, 'bolt'],
  ['smg', 'Pulse SMG', 'LIGHT', 24, 1.35, 13, .095, .20, 353, 1, 150, 'bolt'],
  ['shotgun', 'Dock Sweeper', 'SHELL', 5, 1.65, 13, .66, .39, 242, 7, 245, 'bolt'],
  ['rifle', 'Kite Rifle', 'CELL', 20, 1.45, 28, .17, .12, 540, 1, 335, 'bolt'],
  ['sniper', 'Farline', 'CELL', 4, 1.95, 78, .85, .02, 800, 1, 490, 'bolt'],
  ['grenade', 'Spark Charge', 'CHARGE', 1, .74, 68, .92, .03, 180, 1, 105, 'charge'],
  ['molotov', 'Glow Flask', 'FLASK', 1, .74, 44, .88, .09, 150, 1, 85, 'flask'],
  ['rocket', 'Signal Breaker', 'ROCKET', 1, 2.15, 92, 1.15, .05, 485, 1, 620, 'rocket'],
].map(([id, name, ammo, mag, reload, damage, rate, spread, range, count, price, style]) => ({ id, name, ammo, mag, reload, damage, rate, spread, range, count, price, style }));

export const WEATHER = ['Clear', 'Rain', 'Fog', 'Storm'];
export const MARKET_GOODS=[{id:'parts',name:'Salvage coils',base:48},{id:'cloth',name:'Dry canvas',base:36},{id:'battery',name:'Service cells',base:71}];
export const WARDROBE=[{name:'Courier jacket',price:0},{name:'Rain vest',price:42},{name:'Track kit',price:66},{name:'River sweater',price:49}];
export const GARAGE_PAINT=[{name:'Neon violet',color:'#b894f6'},{name:'Harbor red',color:'#e87579'},{name:'River green',color:'#699b8a'},{name:'Warm ivory',color:'#e6ccab'},{name:'Night blue',color:'#6884a9'}];
export const HOLDINGS={
  loft:{name:'Morrow Loft',price:680,rate:38},
  'ghat-counter':{name:'Shapla Ferry Counter',price:820,rate:47},
  'lake-stall':{name:'Jheel Promenade Stall',price:550,rate:31},
};
export const STATIONS = [
  { name: 'Neon FM', dial: '87.6', genre: 'Analog synth', bpm: 107, root: 45, notes: [0, 3, 7, 10, 12, 15], blurb: 'Late traffic, low lights. You are listening to Neon FM.', segments: ['This hour is brought to you by Rill Night Market. Dinner is whatever is still warm.', 'To whoever keeps requesting the sound of rain: step outside. You are welcome.'] },
  { name: 'Dockside Dub', dial: '94.2', genre: 'Harbor dub', bpm: 83, root: 38, notes: [0, 2, 5, 7, 10, 12], blurb: 'Pier 07 is open late. If the gate is down, knock twice.', segments: ['Sable Motorworks. Our warranty ends at the seawall, and for good reason.', 'A shout to the night crew at Pier 07. Keep the gate light on.'] },
  { name: 'Ghost Carrier', dial: '103.1', genre: 'Ambient drift', bpm: 65, root: 50, notes: [0, 2, 4, 7, 9, 14], blurb: 'No towers, no sponsors. You found the Ghost Carrier.', segments: ['This frequency is not listed on the dial. Neither are you.', 'If the lights go out, leave something on the air for the next driver.'] },
];

export const CONTROLS = {
  up: ['KeyW', 'Move up / Accelerate'], down: ['KeyS', 'Move down / Brake'], left: ['KeyA', 'Move left / Steer'], right: ['KeyD', 'Move right / Steer'],
  use: ['KeyE', 'Interact / Enter or exit'], sprint: ['ShiftLeft', 'Sprint'], dash: ['Space', 'Roll / Handbrake'], cover: ['ControlLeft', 'Cover / Sneak'],
  reload: ['KeyR', 'Reload'], wheel: ['KeyQ', 'Weapon wheel'], map: ['KeyM', 'City map'], phone: ['Tab', 'Phone'], radio: ['KeyC', 'Next radio station'],
  horn: ['KeyH', 'Horn / Siren'], lights:['KeyL','Toggle headlights'], heal: ['KeyF', 'Use medkit'], focus: ['KeyX','Brace / Guard'], walk: ['KeyZ','Walk'], utility: ['KeyG','Throw a noisemaker'], barricade: ['KeyB','Place a barricade'], camera: ['KeyV','Cycle gameplay view'], pause: ['Escape', 'Pause'], save: ['F6', 'Quick save'], debug: ['F3', 'Debug overlay'],
};

export const DEFAULTS = {
  master: .65, music: .48, sfx: .68, muted: false, quality: 'High', shake: true,
  crt: false, contrast: false, motion: true, touch: false, bindings: {},
  autoTap:false, autoReload:true, assist:true, flashes:true, impactTint:true,
};

const at = (x, y, kind, label, extra = {}) => ({ x, y, kind, label, ...extra });
const room = (id, label, flags = {}) => ({ ...place(id), kind: 'room', room: id, label, ...flags });
const say = (speaker, line) => ({ speaker, line });

export const CAMPAIGN = [
  { title: 'Dead Drop', pay: 150, brief: say('Inez Sable', 'You still know the night routes, Mara? A pouch is waiting under the light at Rill and Fourth. I left you the pink Vanta.'), steps: [
    at(1423, 1117, 'use', 'Recover the pouch at Rill and Fourth'), at(1100, 1012, 'use', 'Bring the pouch to Inez at The Relay'),
  ], end: say('Mara Venn', 'This is a radio tape, not a ledger. Who did you use to work for, Inez?') },
  { title: 'Tail Lights', pay: 240, brief: say('Inez Sable', 'That tape is one side of a conversation. The other side just left in a blue sedan. Stay close enough to grab its tag.'), steps: [
    at(1670, 983, 'pursue', 'Catch the courier and tag the sedan', { model: 'regent' }), at(1580, 1018, 'use', 'Decode the tag at the motorworks'),
  ], end: say('Mara Venn', 'Halden Rook. Of course it is.') },
  { title: 'Quiet Floor', pay: 315, brief: say('Inez Sable', 'Vesper Trust keeps a second copy under the public terminal. Crouch if you want the security team to keep looking the other way.'), steps: [
    room('archive', 'Copy the archive index inside Vesper Trust', { stealth: true }), at(1416, 1195, 'evade', 'Leave the bank and lose any pursuit'),
  ], end: say('Halden Rook', 'Best check which voice on that tape says to cut the lights, courier.') },
  { title: 'Night Freight', pay: 385, brief: say('Inez Sable', 'They are going to dump their transmitters in the bay. Bring me the unmarked Mule van before the dock gates close.'), steps: [
    at(2040, 1446, 'take', 'Get into the marked Mule van', { model: 'mule' }), at(1100, 2426, 'deliver', 'Deliver the Mule to Pier 07'),
  ], end: say('Mara Venn', 'Cargo intact. This equipment is older than the corporate grid.') },
  { title: 'Borrowed Time', pay: 470, brief: say('Inez Sable', 'Rook has someone on the pier. Get me to the north gate. We can walk if you keep them off our backs.'), steps: [
    at(1100, 2455, 'escort', 'Escort Inez to the north gate', { tx: 965, ty: 2040 }), at(961, 1920, 'reach', 'Cross back into the quarter'),
  ], end: say('Inez Sable', 'You can use our old ghost relays now. When the streetlights go down, the cameras go with them.') },
  { title: 'Soft Power', pay: 535, brief: say('Mara Venn', 'I can bring the old network up. I need a quiet window, or at least twenty seconds of a loud one.'), steps: [
    at(2060, 505, 'defend', 'Hold the North Exchange for 18 seconds', { duration: 18 }), room('switch', 'Bring the ghost network online'),
  ], end: say('Inez Sable', 'It works. I can hear my own voice across the bay again.') },
  { title: 'Inside Job', pay: 620, brief: say('Mara Venn', 'The original is in the Vesper Trust vault. Tonight I listen to the whole thing.'), steps: [
    room('archive', 'Retrieve the master tape from the vault', { vault: true }), at(1730, 1920, 'evade', 'Leave the trust and evade the grid'),
  ], end: say('Inez Sable', 'Yes, that is my voice. I pulled the switch. They told me the hospital was on a backup line.') },
  { title: 'Glass Mile', pay: 690, brief: say('Halden Rook', 'Meet me at the seawall. The freeway is closing, but I know you always liked the short way.'), steps: [
    at(3290, 1462, 'race', 'Run the Glass Mile checkpoints', { duration: 62, gates: [[3372,1462],[3832,1462],[3859,1884],[3862,2340],[4130,2422]] }),
  ], end: say('Mara Venn', 'Made it. Nobody closes the harbor on me.') },
  { title: 'False Signal', pay: 815, brief: say('Halden Rook', 'I wanted the tape to stay lost. Then you put a ghost back on the air. Come find me at the north exchange.'), steps: [
    at(1936, 475, 'boss', 'Confront Rook and his grid detail'), at(2060, 541, 'choice', 'Decide what to do with Rook', { options: ['Let him walk', 'Turn him in'] }),
  ], end: say('Halden Rook', 'They did it for the contract. And I helped keep it quiet. Whatever you do next, make it count.') },
  { title: 'Open Frequency', pay: 1000, brief: say('Inez Sable', 'The coastal antenna can reach every receiver in the bay. Do what you think is right, Mara. I mean it this time.'), steps: [
    at(3880, 2380, 'evade', 'Reach the coast without an active pursuit'), { ...room('coast', 'Choose what the city hears'), kind: 'choice', options: ['Broadcast the tape', 'Seal the evidence', 'Cut the grid'] },
  ], end: say('Mara Venn', 'Vesper Bay, if you can hear me, the frequency is yours.') },
];

const survey = (nodes, label) => at(nodes[0][0], nodes[0][1], 'survey', label, { nodes });
export const MONSOON_CAMPAIGN = [
  { title: 'Rain Check', pay: 175, brief: say('Samira Noor', 'Mara? Welcome to Puran. Meet me at the tea awning. Then help me find the volunteers who used the river crossing.'), steps: [
    at(6860,3421,'use','Meet Samira at the tea awning'), at(6981,3375,'use','Get the boat roster from the curbside stand'),
  ], end: say('Samira Noor','The contractor put a padlock on the public landing. We can still move supplies by road, for now.') },
  { title: 'Paint and Pedals', pay: 240, brief: say('Samira Noor', 'Take the painted rickshaw, not the van. The workshop lanes are too tight and the shopkeepers know that canopy.'), steps: [
    at(6950,3390,'take','Pick up the painted cycle rickshaw',{model:'rickshaw'}), at(6345,3418,'deliver','Deliver dry supplies to Kheya Produce Hall'),
  ], end: say('Mara Venn','Three wheels, ten bags, no broken eggs. Put that on my record.') },
  { title: 'Under the Line', pay: 310, brief: say('Rafi Sen', 'The metro is running again. There are three orange flood readers below the viaduct. Can you log them for our route map?'), steps: [
    survey([[6800,2993],[6860,2461],[7274,2414]],'Log the flood readers beneath the metro'), room('citymetro','Hand the readings to the station clerk'),
  ], end: say('Rafi Sen','The lake road is clear. The deep water is farther south, where the ferry should be.') },
  { title: 'Waterline', pay: 410, brief: say('Samira Noor', 'I borrowed a launch. The water is public even if the gate is not. Use the marked ghat boat and follow the channel flags.'), steps: [
    at(7324,4508,'take','Board the Kheya Water Taxi at the jetty',{model:'launch',angle:.42,approach:{x:7324,y:4482}}),
    at(7863,4767,'deliver','Pilot the launch to the south bank buoy'), at(7822,4800,'reach','Disembark and reach the south bank road'),
  ], end: say('Mara Venn','There is a whole second city on this shore. No wonder they are fighting over the route.') },
  { title: 'Across the Jheel', pay: 460, brief: say('Rafi Sen', 'I need a fast test of the crosstown route before the next cloudburst. Start on the west road and hit every bridge gate.'), steps: [
    at(7165,1455,'race','Drive all five Jheel circuit gates',{duration:65,quiet:true,gates:[[7198,1450],[8170,1451],[8171,1915],[8168,2396],[8765,2418]]}),
  ], end: say('Rafi Sen','That route will work. I am opening the public map now.') },
  { title: 'Track Work', pay: 575, brief: say('Samira Noor', 'Kadam lent us a tracked flood rig. Roll it through the three foam barriers at the works yard. Leave the river gate in one piece.'), steps: [
    at(9239,2919,'take','Get into the tracked Tread-6 flood rig',{model:'floodworks'}),
    at(9392,2919,'clear','Clear the works lane in the tracked rig',{model:'floodworks',nodes:[[9375,2919],[9443,2919],[9508,2919]]}),
    room('works','Sign off on the cleared works entrance'),
  ], end: say('Mara Venn','The gate is moving again. Nobody gets to charge the river for being here.') },
  { title: 'Last Clinic Run', pay: 675, brief: say('Samira Noor', 'The clinic is waiting for this relief van. Get there first, then hold the forecourt while the volunteers unload.'), steps: [
    at(9166,2926,'take','Collect the marked clinic van',{model:'rescue'}), at(7340,3386,'deliver','Bring the relief van to Kheya Clinic'),
    at(7340,3386,'defend','Keep the clinic forecourt clear for 16 seconds',{duration:16}),
  ], end: say('Samira Noor','All boxes accounted for. We have enough kits to keep the landing open through the storm.') },
  { title: 'Common Ground', pay: 950, brief: say('Samira Noor', 'The south bank wants a charter, not another contractor. Meet us at the cooperative and tell us what should happen next.'), steps: [
    at(8160,4800,'reach','Cross to the Char Gardens south bank'), { ...room('garden','Choose who will run the river service'), kind:'choice', options:['Give it to the river cooperative','Make it a free municipal route'] },
  ], end: say('Mara Venn','Post the timetable. This time, everyone gets a way home.') },
];

export const campaignFor = mode => mode === 'monsoon' ? MONSOON_CAMPAIGN : ['outbreak','practice','atlas'].includes(mode) ? [] : CAMPAIGN;

export const JOBS = [
  { id: 'taxi', name: 'Night Cab', desc: 'Pick up a passenger and cross the quarter by car.', icon: 'T', kind: 'taxi', pay: 125, nodes: [[1459,1282],[1900,1461]] },
  { id: 'delivery', name: 'Rush Parcel', desc: 'Run a sealed parcel across the docks.', icon: 'D', kind: 'delivery', pay: 115, nodes: [[1436,1950],[981,2405]] },
  { id: 'vigilante', name: 'Grid Scanner', desc: 'Stop a marked rogue vehicle.', icon: 'V', kind: 'vigilante', pay: 165, nodes: [[689,1449]] },
  { id: 'race', name: 'Afterhours Circuit', desc: 'Four gates between the grid and the sea.', icon: 'R', kind: 'race', pay: 195, nodes: [[2880,1923],[2892,2390],[3366,2422],[3844,2422]] },
  { id: 'stunt', name: 'Pier Jump', desc: 'Take the pier ramp at 70 km/h or faster.', icon: 'J', kind: 'stunt', pay: 145, nodes: [[4340,2400]] },
  { id: 'collect', name: 'Lost Frequencies', desc: 'Find and interact with hidden pink signal tapes.', icon: 'F', kind: 'collect', pay: 75, nodes: [] },
  { id: 'catalog', name: 'Sable Import List', desc: 'Bring a muscle car, pickup, and motorcycle to the garage.', icon: 'I', kind: 'catalog', pay: 420, nodes: [[1580,1015]] },
  { id: 'arena', name: 'Switchyard', desc: 'Survive a hostile wave at the docks.', icon: 'A', kind: 'arena', pay: 240, nodes: [[979,2419]] },
  { id: 'arcade', name: 'Soft Reset', desc: 'Play the signal timing machine for city credits.', icon: 'S', kind: 'point', pay: 0, nodes: [[3980,1501]] },
  { id: 'property', name: 'Morrow Loft', desc: 'Buy the loft to earn income every city hour.', icon: 'P', kind: 'point', pay: 0, nodes: [[2540,1501]] },
  { id: 'first-aid', name: 'First Response', desc: 'Pick up two patients in a relief van and deliver them to St. Echo.', icon: 'M', kind: 'service', vehicle:'rescue', pay: 310, time:115, nodes:[[1120,965],[1454,1325],[965,1443],[1092,1470]] },
  { id: 'tow-shift', name: 'Wrecker Call', desc: 'Take the tow truck, hook a disabled sedan, and return it to the garage.', icon: 'W', kind: 'service', vehicle:'warden', tow:true, pay: 295, time:92, nodes:[[1555,977],[1755,987],[1580,1007]] },
  { id: 'air-pass', name: 'Roofline Survey', desc: 'Fly through three survey gates and return to the marked helipad.', icon: 'A', kind: 'service', vehicle:'aero', flight:true, pay: 420, time:135, nodes:[[498,495],[1180,712],[1750,1230],[856,1420],[498,495]] },
  { id: 'cha-run', name: 'Hot Cha Run', desc: 'Carry a tea order from Puran to the metro crew.', icon: 'C', kind: 'delivery', region: 'monsoon', pay: 150, nodes: [[6860,3421],[6860,2461]] },
  { id: 'rickshaw-hire', name: 'Rickshaw Rank', desc: 'Take a paying passenger in a cycle rickshaw or CNG.', icon: 'H', kind: 'taxi', region: 'monsoon', pay: 215, models: ['rickshaw','cng'], nodes: [[6990,3382],[7340,3380]] },
  { id: 'jheel-sprint', name: 'Jheel Loop', desc: 'A lakeside time trial across four bridge gates.', icon: 'J', kind: 'race', region: 'monsoon', pay: 255, nodes: [[8168,1450],[8171,1915],[8168,2396],[8765,2418]] },
  { id: 'co-op-parcel', name: 'Two Banks', desc: 'Pick up a cooperative manifest in Char Gardens and bring it to the ghat.', icon: 'F', kind: 'delivery', region: 'monsoon', pay: 190, nodes: [[8300,4853],[7340,3888]] },
  { id: 'bus-shift', name: 'Megh Bus Shift', desc: 'Collect the bus, then stop for passengers at three shelters.', icon: 'B', kind:'service',vehicle:'megh',region:'monsoon',pay:390,time:150,nodes:[[9740,511],[9583,865],[9138,1448],[8164,1455]] },
  { id: 'lake-photo', name: 'Jheel Photo Walk', desc: 'Frame three landmarks along the promenade with the scene camera.', icon:'P', kind:'photo',region:'monsoon',pay:250,nodes:[[8321,2439],[8176,1976],[8678,2408]] },
  { id:'shop-watch',name:'Market Watch',desc:'Answer a stall alarm. Keep the marker in sight and recover the dropped parcel.',icon:'W',kind:'recover',region:'monsoon',pay:210,nodes:[[6834,3378],[7060,3358],[6860,3421]] },
  { id:'shop-watch-west',name:'Closing Time',desc:'Recover a missing stall parcel and bring it back to the west market.',icon:'W',kind:'recover',pay:195,nodes:[[2046,1005],[2182,977],[2060,1017]] },
  { id:'quay-line',name:'Quay Line',desc:'Hold the public loading zone for the Coil Union. The outcome changes district control.',icon:'T',kind:'turf',side:'Coil Union',rival:'Prism Crew',pay:335,nodes:[[500,2560]] },
  { id:'jheel-line',name:'Community Frequency',desc:'Keep the waterfront relay online and win the district for the River Cooperative.',icon:'T',kind:'turf',region:'monsoon',side:'River Cooperative',rival:'Verge Works',pay:390,nodes:[[8256,2435]] },
  { id: 'terminal-pin', name: 'Megh Terminal', desc: 'Pin the bus terminal in the north.', icon: 'M', kind: 'point', region: 'monsoon', pay: 0, nodes: [[9740,541]] },
  ...ATLAS_JOBS,
];