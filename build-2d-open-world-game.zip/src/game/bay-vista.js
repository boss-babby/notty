import { rng } from './core.js';

// A low-resolution painted scene, scaled by CSS without smoothing.
export function mountBayVista(canvas,motion=true){
  const w=672,h=360;canvas.width=w;canvas.height=h;
  const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)return ()=>{};
  const base=document.createElement('canvas');base.width=w;base.height=h;
  const c=base.getContext('2d');if(!c)return ()=>{};
  const r=rng(921019);
  const f=(x,y,ww,hh,col)=>{c.fillStyle=col;c.fillRect(Math.round(x),Math.round(y),Math.round(ww),Math.round(hh));};
  const p=(col,...v)=>{c.fillStyle=col;c.beginPath();c.moveTo(v[0],v[1]);for(let i=2;i<v.length;i+=2)c.lineTo(v[i],v[i+1]);c.closePath();c.fill();};
  const l=(col,sz,x,y,xx,yy)=>{c.strokeStyle=col;c.lineWidth=sz;c.beginPath();c.moveTo(x,y);c.lineTo(xx,yy);c.stroke();};
  const disk=(x,y,rr,col)=>{c.fillStyle=col;c.beginPath();c.arc(x,y,rr,0,Math.PI*2);c.fill();};
  const halo=(x,y,rad,col)=>{const g=c.createRadialGradient(x,y,0,x,y,rad);g.addColorStop(0,col);g.addColorStop(1,'transparent');f(x-rad,y-rad,rad*2,rad*2,g);};
  const ambient=c.createLinearGradient(0,0,0,h);ambient.addColorStop(0,'#182333');ambient.addColorStop(.54,'#26363f');ambient.addColorStop(1,'#232336');f(0,0,w,h,ambient);
  p('#222532',0,0,672,0,672,123,438,106,0,139);p('#2a3341',0,37,436,113,672,81,672,131,438,156,0,92);
  p('#2a313d',0,135,438,146,672,115,672,237,438,211,0,227);p('#263744',438,146,672,115,672,244,438,211);
  p('#303844',0,219,436,209,672,238,672,360,0,360);p('#384550',438,215,672,256,672,360,14,360);
  for(let i=0;i<34;i++){
    const x=5+i*24;
    l('#53637145',1,433,212,x,362);l('#171f336d',1,437,215,x+23,361);
  }
  for(const yy of [222,232,246,263,286,317,350])l('#1b2533ba',1,0,yy,672,yy+(yy-212)*.20);
  for(let i=0;i<3000;i++){
    const x=r()*w,y=176+r()*191;
    f(x,y,1+r()*6,1,r()>.46?'#8fa49c20':'#111a291f');
  }
  for(let i=0;i<10;i++){
    const x=681-i*28, t=(x-438)/244, upper=145-t*31, down=214+t*40;
    l('#434e59',1,x,upper,x,down);l('#1b2637',2,x+2,upper,x+2,down);
  }
  for(let i=0;i<13;i++){
    const x=31+i*33;
    l('#314653',1,x,145,x,225);if(i%2===0)l('#5865727a',1,x+1,148,x+1,219);
  }
  l('#7fa4a367',2,0,164,438,174);l('#77948c66',2,438,174,672,141);
  for(const [x,y,scale] of [[425,49,.55],[495,35,.8],[583,17,1.02],[653,4,1.4]]){
    p('#242536',x-6*scale,y,x+10*scale,y,x+7*scale,y+133*scale,x-3*scale,y+133*scale);
    l('#40515e',2*scale,x,y,x-4*scale,y+155*scale);
    f(x-16*scale,y+46*scale,46*scale,5*scale,'#27313e');f(x-10*scale,y+50*scale,37*scale,2,'#cccfac');
    halo(x+6*scale,y+61*scale,77*scale,'#c4d3b23b');
  }
  for(const [x,y,sz] of [[397,176,.53],[447,170,.66],[513,170,.79],[590,167,1.05]]){
    f(x-21*sz,y-43*sz,42*sz,59*sz,'#202736');f(x-17*sz,y-40*sz,34*sz,53*sz,'#49616a');
    f(x-17*sz,y-39*sz,34*sz,1,'#b5ced0');
    disk(x,y-15*sz,14*sz,'#9cbaa9');disk(x,y-15*sz,10*sz,'#36525d');disk(x,y-15*sz,6*sz,'#d4bfa0');disk(x,y-15*sz,2*sz,'#9b7d83');
    f(x-1,y+15*sz,2,25*sz,'#556272');f(x-9*sz,y+39*sz,18*sz,3,'#2f2b3b');
    for(let i=0;i<12;i++){const yy=y+36*sz+r()*38*sz;f(x+(r()-.5)*23*sz,yy,r()*12,1,'#9dc7b44b');}
  }
  p('#171b2d',591,210,672,195,672,360,548,360);p('#384551',588,210,595,207,572,360,548,360);l('#748a8b',1,587,214,553,359);
  p('#263544',496,266,565,252,614,280,561,317);p('#5d686f',497,265,566,250,607,269,554,291);p('#232637',554,291,607,269,608,283,559,307);
  for(let i=0;i<8;i++)l(i%2===0?'#c8ad80':'#4b5462',2,507+i*8,270-i*2,534+i*7,283-i);
  p('#bc9e74',318,334,436,281,445,283,330,340);p('#798c82',370,360,454,298,463,299,383,360);
  for(let i=0;i<17;i++){const x=350+r()*250,y=218+r()*130;halo(x,y,18+r()*12,i%2?'#95cfc821':'#d7a67b20');}
  f(485,111,92,27,'#243042');f(487,112,88,23,'#263948');f(489,112,84,1,'#8ac5bd');
  c.fillStyle='#d4d5b8';c.font='bold 10px monospace';c.textAlign='center';c.fillText('ANCHOR BAY',531,128);
  for(let i=0;i<106;i++){const x=412+r()*250,y=43+r()*72;f(x,y,1,1,'#aacfb523');}
  const reduce=!motion||matchMedia('(prefers-reduced-motion: reduce)').matches;
  let frame=0, live=true;
  const draw=t=>{if(!live)return;ctx.drawImage(base,0,0);if(!reduce){
    ctx.fillStyle='#a0d5bc';for(let i=0;i<5;i++){ctx.globalAlpha=.34+Math.sin(t*.002+i)*.23;ctx.fillRect(493+i*16,133,4,1);}
    ctx.globalAlpha=.24;ctx.fillStyle='#e0c59f';for(let i=0;i<8;i++)ctx.fillRect(378+((t*.012+i*34)%255),242+i*12,2,1);ctx.globalAlpha=1;frame=requestAnimationFrame(draw);
  }};
  draw(0);return ()=>{live=false;cancelAnimationFrame(frame);};
}