import { angleDiff, clamp, dist, mix } from './core.js';
import { GEAR } from './data.js';
import { HANDLING, MATERIALS, materialOf } from './contact-data.js';
import { circleContact, hullContact, rectContact } from './contact-geometry.js';

export const profile=g=>HANDLING[GEAR[g.weapon].id];
export const blankContact=()=>({aim:0,kick:0,bias:0,swap:0,reload:null,swing:null,throwing:null,guard:0,guardAge:0,chain:0,chainUntil:0,heal:null,marker:0,markerKind:'',hurt:0,hurtAngle:0});

export function hydrateKit(saved,kit,shared){
  const slots={}, reserve={};
  for(const [key,data] of Object.entries({...kit,...saved})){
    const item=GEAR[key];if(!item)continue;
    const mag=clamp(Number(data?.mag)||0,0,item.mag), stash=clamp(Number(data?.stash)||0,0,499);
    slots[key]={mag,stash};
    if(item.mag)reserve[item.ammo]=Math.min(499,(reserve[item.ammo]||0)+stash);
  }
  if(shared)for(const [key,v] of Object.entries(shared))if(Number.isFinite(v))reserve[key]=clamp(v,0,499);
  if(Number.isFinite(shared?.THROWN)){
    const old=clamp(shared.THROWN,0,499), both=slots[8]&&slots[9];
    if(slots[8]&&!Number.isFinite(shared.CHARGE))reserve.CHARGE=both?Math.ceil(old/2):old;
    if(slots[9]&&!Number.isFinite(shared.FLASK))reserve.FLASK=both?Math.floor(old/2):old;
    delete reserve.THROWN;
  }
  for(const [key,s] of Object.entries(slots))s.stash=reserve[GEAR[key].ammo]||0;
  return {slots,reserve};
}

export function reserveAmmo(g,type,amount){
  const n=g.ammoPools[type]||0;g.ammoPools[type]=clamp(n+amount,0,g.practice?999:499);
  for(const [i,slot] of Object.entries(g.armory))if(GEAR[i].ammo===type)slot.stash=g.ammoPools[type];
  return g.ammoPools[type]-n;
}

export function cancelContact(g){
  const c=g.contact;c.reload=null;c.swing=null;c.throwing=null;c.heal=null;c.swap=0;
  c.guard=0;c.guardAge=0;c.aim=0;g.pendingReload=0;
}

export function reloadKit(g){
  const c=g.contact,w=GEAR[g.weapon],s=g.armory[g.weapon],h=profile(g),p=g.player;
  if(!w.mag||!s.stash||s.mag>=w.mag||c.reload||c.swing||c.throwing||c.heal||g.car||p.swim||p.dodge>0)return false;
  const dur=h.load==='tube'?.5:w.reload+(s.mag===0&&h.load==='mag'?.23:0);
  c.reload={slot:g.weapon,type:h.load,elapsed:0,total:dur,stage:0};
  g.pendingReload=dur;g.hear(h.load==='tube'?'reload-open':'reload-out',p.x,p.y,.65);
  return true;
}

export function handleMedkit(g){
  const c=g.contact,p=g.player;
  if(c.heal||c.swing||c.throwing||p.swim||p.dodge>0)return false;
  if(!g.medkits){g.notify('No medkits','Look for a clinic or a supply cache.');return false;}
  if(p.hp>99.5)return false;
  c.reload=null;g.pendingReload=0;
  c.heal={elapsed:0,total:.83};g.hear('reload-out',p.x,p.y,.4);
  return true;
}

function tickReload(g,dt){
  const c=g.contact,r=c.reload;if(!r)return;
  const w=GEAR[r.slot],s=g.armory[r.slot];
  r.elapsed+=dt;g.pendingReload=Math.max(0,r.total-r.elapsed);
  if(r.type!=='tube'&&r.stage===0&&r.elapsed>r.total*.63){r.stage=1;g.hear('reload-in',g.player.x,g.player.y,.66);}
  if(r.elapsed<r.total)return;
  const added=Math.min(r.type==='tube'?1:w.mag-s.mag,s.stash);
  if(added>0){s.mag+=added;reserveAmmo(g,w.ammo,-added);}
  if(r.type==='tube'&&added){g.hear('shell',g.player.x,g.player.y,.68);if(s.mag<w.mag&&s.stash){r.elapsed=0;r.total=.44;g.pendingReload=r.total;return;}}
  else g.hear('reload-ready',g.player.x,g.player.y,.61);
  c.reload=null;g.pendingReload=0;
}

export function updateContact(g,dt){
  const c=g.contact,p=g.player,h=profile(g);
  c.swap=Math.max(0,c.swap-dt);c.marker=Math.max(0,c.marker-dt);c.hurt=Math.max(0,c.hurt-dt*2.35);
  c.kick*=Math.exp(-dt*h.calm);g.recoil=c.kick;
  c.bias*=Math.exp(-dt*5.6);
  if(c.swing){
    const a=c.swing, prev=a.time;a.time+=dt;
    if(prev<a.wind&&a.time>=a.wind)resolveSwing(g,p,a);
    if(a.time>=a.total)c.swing=null;
  }
  if(c.throwing){
    const t=c.throwing;t.time-=dt;
    if(t.time<=0){
      c.throwing=null;
      const w=GEAR[t.slot],s=g.armory[t.slot];
      if(s.mag>0){s.mag--;releaseThrown(g,w,t.angle);}
    }
  }
  tickReload(g,dt);
  if(c.heal){
    c.heal.elapsed+=dt;
    if(c.heal.elapsed>=c.heal.total){
      c.heal=null;g.medkits--;p.hp=Math.min(100,p.hp+55);
      g.notify('Medkit applied',`${g.medkits} remaining`,'ok');g.hear('confirm');
    }
  }
}

export function notifyHit(g,kind){
  g.contact.marker=.2;g.contact.markerKind=kind;
  if(kind==='hit'||kind==='break')g.stats.hits=(g.stats.hits||0)+1;
}

export function hurtPlayer(g,amount,detail={}){
  const p=g.player,c=g.contact;
  if(p.inv>0||p.dashTime>=.058&&p.dashTime<=.217)return 0;
  const source=detail.source, a=source?Math.atan2(source.y-p.y,source.x-p.x):p.a;
  const frontal=Math.abs(angleDiff(p.a,a))<1.27, close=detail.kind==='melee';
  c.hurtAngle=a;
  if(close&&c.guard>.44&&frontal&&p.stamina>7){
    const perfect=c.guardAge<.17;
    p.stamina=Math.max(0,p.stamina-amount*(perfect?.38:.81));
    amount*=perfect?.12:.42;
    if(source?.type&&perfect){source.stun=.45;source.attack=null;source.shotPlan=null;}
    g.hear(perfect?'parry':'guard',p.x,p.y,.8);
    if(g.practice)g.practice.blocks++;
    if(perfect)notifyHit(g,'guard');
  }
  const soak=Math.min(p.armor,amount*(close?.24:.7));
  p.armor-=soak;p.hp=Math.max(0,p.hp-amount+soak);p.hit=.28;c.hurt=Math.min(1,.25+amount*.018);
  p.flinch=Math.max(p.flinch||0,Math.min(.22,.09+amount*.002));
  if(source){p.impactX=-Math.cos(a)*Math.min(46,amount*2.1);p.impactY=-Math.sin(a)*Math.min(46,amount*2.1);}
  if(amount>6&&c.heal){c.heal=null;g.notify('Treatment interrupted','Find a moment out of contact.','warn');}
  if(amount>10&&c.swing&&c.swing.time<c.swing.wind)c.swing=null;
  g.bump(Math.min(3.8,amount*.12));g.hear(soak>amount*.46?'armor':'body',p.x,p.y,.61);
  if(p.hp<=0)g.respawn();
  return amount;
}

function actorContact(g,actor,amount,owner,at,force){
  const kind=actor.type==='target'?'target':actor.type==='infected'?'quiet':'cloth';
  if(actor.type==='target'){
    if(owner==='player'){g.practice.hit(actor,amount);notifyHit(g,'hit');g.hear('plate',at.x,at.y,.77);g.fx(at.x,at.y,'#c4e4c1',6,69,'glint');}
    return;
  }
  g.hurtActor(actor,amount,owner,{x:at.x,y:at.y,fx:force.x,fy:force.y,material:kind});
  if(owner==='player')notifyHit(g,'hit');
}

export function impact(g,mat,x,y,nx,ny,force=1){
  const p=MATERIALS[mat]||MATERIALS.stone;
  g.fx(x+nx,y+ny,p.tint,Math.ceil(6*force),44+force*26,p.style,{x:nx,y:ny});
  if(mat==='metal'||mat==='armor'||mat==='target')g.light(x,y,p.tint,18+force*9,.068);
  if(g.clock>(g.impactSound||0)){
    g.impactSound=g.clock+.035;
    g.hear(p.sound,x,y,Math.min(1.05,force*.85));
  }
  if(g.settings.quality!=='Low')g.scars.take({x,y,nx,ny,mat,room:g.room,life:mat==='glass'?11:29,seed:g.rand()});
}

function allowed(a,b,w){
  const u=Math.atan2(b.y-a.y,b.x-a.x);
  return Math.abs(angleDiff(w.angle,u))<=w.width;
}

function swingReach(g,actor,target){
  const dx=target.x-actor.x,dy=target.y-actor.y;
  const n=Math.max(1,Math.ceil(Math.hypot(dx,dy)/7));
  for(let i=1;i<n;i++)if(g.block(actor.x+dx*i/n,actor.y+dy*i/n,2))return false;
  return true;
}

function resolveSwing(g,p,a){
  const w=GEAR[a.slot];
  const targets=g.people.items.filter(n=>n.active&&!n.dead&&!['ally','host','dancer'].includes(n.type)&&n.indoor===Boolean(g.room)&&dist(p,n)<w.range+n.r*.55&&allowed(p,n,a)&&swingReach(g,p,n));
  targets.sort((x,y)=>dist(p,x)-dist(p,y));
  const force={x:Math.cos(a.angle),y:Math.sin(a.angle)};
  if(targets.length){
    actorContact(g,targets[0],w.damage*(a.chain===3?1.3:1),'player',targets[0],force);
    if(w.id==='bat'&&targets[1])actorContact(g,targets[1],w.damage*.47,'player',targets[1],force);
    g.hear(w.id==='blade'?'blade':'body',targets[0].x,targets[0].y,.82);g.bump(w.id==='bat'?2.2:1.25);
    return;
  }
  let hit=null;
  for(let k=12;k<w.range;k+=5){const x=p.x+force.x*k,y=p.y+force.y*k;const q=g.block(x,y,3);if(q){hit={q,x,y};break;}}
  if(hit){
    if(hit.q.type==='prop')g.breakProp(hit.q,w.damage,'player');
    impact(g,materialOf(hit.q),hit.x,hit.y,-force.x,-force.y,.82);
  }
}

export function physicalAttack(g,n,span,force){
  if(dist(n,g.player)>span||!swingReach(g,n,g.player))return false;
  if(g.car)g.damageRide(force*.48);else g.playerHurt(force,{kind:'melee',source:n});
  return true;
}

function releaseThrown(g,w,a){
  const p=g.player, dx=Math.cos(a),dy=Math.sin(a), h=HANDLING[w.id];
  const q=g.input.mouse.active?g.aimWorld():null;
  const ratio=q?clamp(dist(p,q)/w.range,.35,1.14):1;
  spawnRound(g,p.x+dx*10,p.y+dy*10,a,w.damage,w.range*ratio,w.style,'player',{speed:h.speed*ratio,origin:p});
  g.hear(w.id,p.x,p.y,.71);g.signalNoise(88,p,'throw');g.stats.shots++;
}

export function useWeapon(g,{edge=true}={}){
  const c=g.contact,p=g.player,w=GEAR[g.weapon],s=g.armory[g.weapon],h=profile(g);
  if(p.cd>0||c.swap>0||p.swim||p.dodge>.02||p.vault||p.stance>0||c.heal||c.swing||c.throwing||g.car||g.transition||c.guard>.65)return false;
  if(h.mode!=='AUTO'&&!edge&&!(g.settings.autoTap||g.input.touch.has('fire')))return false;
  if(c.reload){
    if(h.load==='tube'&&s.mag>0&&edge){c.reload=null;g.pendingReload=0;}else return false;
  }
  if(w.mag&&s.mag<=0){
    p.cd=.19;g.hear('dry',p.x,p.y,.72);
    if(g.settings.autoReload&&s.stash)reloadKit(g);
    return false;
  }
  if(w.style==='melee'){
    if(p.stamina<h.cost){g.hear('dry',p.x,p.y,.39);p.cd=.22;return false;}
    p.stamina-=h.cost;
    c.chain=g.clock<c.chainUntil?c.chain%3+1:1;c.chainUntil=g.clock+.82;
    const wind=h.wind*(c.chain===2?.81:1),time=wind+h.recover;
    c.swing={slot:g.weapon,angle:p.a,width:h.width,wind,time:0,total:time,chain:c.chain};
    p.cd=time*.92;g.hear(w.id==='bat'?'swish-heavy':'swish',p.x,p.y,.67);g.signalNoise(78,p,'melee');
    return true;
  }
  if(h.mode==='THROW'){
    c.throwing={time:h.wind,total:h.wind,slot:g.weapon,angle:p.a};p.cd=w.rate;g.hear('throw-ready',p.x,p.y,.44);
    return true;
  }
  p.cd=w.rate;s.mag--;
  const aim=p.a+c.bias, dx=Math.cos(aim),dy=Math.sin(aim);
  const start={x:p.x+dx*Math.min(12,h.length),y:p.y+dy*Math.min(12,h.length)};
  const nowSpread=weaponSpread(g);
  for(let k=0;k<w.count;k++){
    const offset=w.count>1?(k/(w.count-1)-.5)*nowSpread+(g.rand()-.5)*.08:(g.rand()-.5)*nowSpread;
    spawnRound(g,start.x,start.y,aim+offset,w.damage,w.range,w.style,'player',{speed:h.speed,origin:p,tool:w.id});
  }
  c.kick=Math.min(1.6,c.kick+h.kick*(g.perks.includes('steady-hand')?.76:1));
  c.bias+=h.kick*(g.stats.shots%2===0?.105:-.077)*(1-.37*c.aim);
  g.recoil=c.kick;p.recoil=.15;p.flash=.075;g.stats.shots++;
  g.hear(w.id,p.x,p.y,g.room?1.07:1);
  g.signalNoise(w.id==='shotgun'||w.id==='rocket'?610:w.id==='sniper'?565:465,p,'shot');
  g.emitStreetNoise(p.x,p.y,w.id==='smg'?225:w.id==='pistol'?254:337);
  if(g.settings.flashes!==false)g.light(start.x,start.y,h.hue,36+h.kick*27,.076+h.kick*.045);
  g.fx(start.x,start.y,h.hue,3+h.kick*4,63,'glint',{x:dx,y:dy});
  if(w.count<2&&g.settings.quality!=='Low')g.fx(p.x-dy*7,p.y+dx*7,'#d8b177',1,25,'casing',{x:-dy,y:dx});
  if(w.id==='shotgun')p.pump=.35;
  g.bump(.42+h.kick*1.84);g.alarm=2.2;
  if(!g.room&&g.people.items.some(n=>n.active&&n.type==='ped'&&!n.dead&&dist(n,p)<138))g.crime(.085,'Residents report a disturbance in the quarter.');
  return true;
}

export function weaponSpread(g){
  const p=g.player,h=GEAR[g.weapon],c=g.contact;
  const speed=clamp(Math.hypot(p.vx||0,p.vy||0)/148,0,1.6);
  const movement=1+speed*.74+(p.sprint?.36:0);
  return h.spread*movement*(1-.49*c.aim)*(1+c.kick*.95)*(1-clamp(g.skills.aim*.004,0,.26));
}

export function spawnRound(g,x,y,a,damage,range,style,owner,options={}){
  const speed=options.speed||(style==='rocket'?430:style==='charge'||style==='flask'?225:1020), dx=Math.cos(a),dy=Math.sin(a), o=options.origin;
  // The origin is swept as well, so a visible barrel cannot skip a wall beside the actor.
  return g.bolts.take({x:o?.x??x,y:o?.y??y,ox:o?.x??x,oy:o?.y??y,vx:dx*speed,vy:dy*speed,speed,style,owner,damage,range,
    life:style==='charge'?1.23:style==='flask'?.72:range/speed, traveled:0, t:0, tool:options.tool||'', hops:0, ignored:null, through:false, settled:false,
    fromX:o?.x??x,fromY:o?.y??y, indoor:Boolean(g.room), normalX:0, normalY:0});
}

function firstContact(g,b,dx,dy){
  let best=null;
  const pad=b.style==='charge'||b.style==='flask'?2.4:b.style==='rocket'?2:0.65;
  const x=Math.min(b.x,b.x+dx)-pad,y=Math.min(b.y,b.y+dy)-pad,w=Math.abs(dx)+pad*2,h=Math.abs(dy)+pad*2;
  const take=(q,hit,type)=>{if(hit&&(!best||hit.t<best.t))best={...hit,q,type};};
  if(g.room){
    for(const q of g.interior.walls)if(q.hp!==0&&q!==b.ignored)take(q,rectContact(b.x,b.y,dx,dy,q,pad),'block');
    const area=g.interior.bounds;
    const x=b.x+dx,y=b.y+dy,a=area.x+1,z=area.y+1,r=area.right-1,l=area.bottom-1;
    if(x<a&&dx<0)take(area,{t:clamp((a-b.x)/dx,0,1),nx:1,ny:0},'block');
    if(x>r&&dx>0)take(area,{t:clamp((r-b.x)/dx,0,1),nx:-1,ny:0},'block');
    if(y<z&&dy<0)take(area,{t:clamp((z-b.y)/dy,0,1),nx:0,ny:1},'block');
    if(y>l&&dy>0)take(area,{t:clamp((l-b.y)/dy,0,1),nx:0,ny:-1},'block');
  }else{
    for(const q of g.city.hash.query(x,y,w,h,g.projectileWalls))if(q!==b.ignored&&!(q.type==='prop'&&q.hp<=0))take(q,rectContact(b.x,b.y,dx,dy,q,pad),'block');
  }
  if(b.style==='charge'&&!b.settled)return best;
  for(const n of g.entities.query(x,y,w,h,g.near)){
    if(n===b.ignored||n.dead||['ally','host','dancer'].includes(n.type))continue;
    if(n.type==='car'){
      if(b.owner==='npc'&&n!==g.car||b.owner==='player'&&n===g.car||n.alt>25)continue;
      take(n,hullContact(b.x,b.y,dx,dy,n,pad),'car');
    }else if(b.owner==='player'&&b.traveled>3)take(n,circleContact(b.x,b.y,dx,dy,n,pad),'actor');
  }
  if(b.owner==='npc'&&!g.car)take(g.player,circleContact(b.x,b.y,dx,dy,g.player,pad-(g.player.protected?1.9:g.player.cover?1:0)),'player');
  return best;
}

function hasBlastCover(g,a,b){
  const dx=b.x-a.x,dy=b.y-a.y;
  const n=Math.ceil(Math.hypot(dx,dy)/11);
  for(let i=1;i<n;i++){
    const q=g.block(a.x+dx*i/n,a.y+dy*i/n,2);
    if(q&&materialOf(q)!=='glass')return true;
  }
  return false;
}

export function blastScale(g,a,b){return hasBlastCover(g,a,b)?.24:1;}

export function tickRounds(g,dt){
  if(!g.bolts.items.some(b=>b.active))return;
  g.entities.clear();
  for(const n of g.people.items)if(n.active&&!n.dead&&n.indoor===Boolean(g.room)&&n.type!=='ally')g.entities.add(n,n.x-n.r,n.y-n.r,n.r*2,n.r*2);
  if(!g.room)for(const v of g.cars){const r=(v.model.l+v.model.w)*.55;g.entities.add(v,v.x-r,v.y-r,2*r,2*r);}
  for(const b of g.bolts.items){
    if(!b.active)continue;
    b.ox=b.x;b.oy=b.y;b.life-=dt;b.t+=dt;
    const thrown=b.style==='charge'||b.style==='flask';
    if(b.settled){if(b.life<=0){g.explosion(b.x,b.y,b.damage,b.owner);b.active=false;}continue;}
    let remain=thrown?dt:Math.min(dt,Math.max(0,b.range-b.traveled)/b.speed);
    for(let tick=0;tick<3&&remain>0.0001&&b.active;tick++){
      const dx=b.vx*remain,dy=b.vy*remain,chosen=firstContact(g,b,dx,dy);
      const t=chosen?.t??1;
      b.x+=dx*t;b.y+=dy*t;b.traveled+=Math.hypot(dx,dy)*t;
      if(!chosen)break;
      const {q,type,nx,ny}=chosen;
      const direction={x:b.vx/b.speed,y:b.vy/b.speed}, at={x:b.x,y:b.y};
      b.normalX=nx;b.normalY=ny;
      if(thrown&&b.style==='charge'){
        const dot=b.vx*nx+b.vy*ny;
        b.vx=(b.vx-1.75*dot*nx)*.52;b.vy=(b.vy-1.75*dot*ny)*.52;
        b.x+=nx*3;b.y+=ny*3;b.hops++;g.hear('canister',b.x,b.y,.58);
        if(b.hops>=3||Math.hypot(b.vx,b.vy)<45){b.settled=true;break;}
        remain*=Math.max(.04,1-t);continue;
      }
      const ratio=clamp(1-Math.max(0,b.traveled/b.range-.24)*.34,.65,1), value=b.damage*ratio;
      if(type==='block'){
        const mat=materialOf(q), was=q.hp;
        if(q.type==='prop'&&b.style==='bolt')g.breakProp(q,b.damage,b.owner);
        impact(g,mat,b.x,b.y,nx,ny,b.tool==='shotgun'?.58:.79);
        if(mat==='glass'&&was>0&&q.hp<=0&&b.owner==='player'){notifyHit(g,'break');if(g.practice)g.practice.glass++;}
        if(mat==='glass'&&q.hp<=0&&!b.through&&b.style==='bolt'){
          b.ignored=q;b.through=true;b.damage*=.76;b.x+=direction.x*2;b.y+=direction.y*2;remain*=Math.max(.05,1-t);continue;
        }
        if(b.owner==='player'&&mat!=='glass')notifyHit(g,'blocked');
      }
      if(type==='actor'&&b.style==='bolt')actorContact(g,q,value,b.owner,at,direction);
      if(type==='car'&&b.style==='bolt'){
        const mat=Math.abs(chosen.ax)<q.model.l*.31&&Math.abs(chosen.ay)>q.model.w*.33&&!q.glassHit?'glass':'metal';
        if(mat==='glass')q.glassHit=true;
        g.hitRide(q,value*(b.owner==='npc'?.8:mat==='glass'?.91:.68),b.owner,{x:b.x,y:b.y,ax:chosen.ax,ay:chosen.ay,material:mat});
        impact(g,mat,b.x,b.y,nx,ny,.63);if(b.owner==='player')notifyHit(g,q.wreck?'blocked':'hit');
      }
      if(type==='player'&&b.style==='bolt')g.playerHurt(value,{kind:'shot',source:{x:b.fromX,y:b.fromY}});
      if(b.style==='flask')g.burnField(b.x+nx*3,b.y+ny*3,b.owner);
      if(b.style==='rocket')g.explosion(b.x+nx*3,b.y+ny*3,b.damage,b.owner);
      b.active=false;
    }
    if(!b.active)continue;
    if(b.indoor!==Boolean(g.room)){b.active=false;continue;}
    if(thrown){
      const drag=Math.exp(-dt*(b.style==='charge'?1.2:.44));b.vx*=drag;b.vy*=drag;
      if(!g.room&&g.city.water(b.x,b.y)){g.fx(b.x,b.y,'#b2c7d6',5,34,'dust');g.hear('water',b.x,b.y,.59);b.active=false;continue;}
    }
    if(b.life<=0){
      if(b.style==='flask')g.burnField(b.x,b.y,b.owner);
      else if(b.style==='charge'||b.style==='rocket')g.explosion(b.x,b.y,b.damage,b.owner);
      b.active=false;
    }else if(b.style==='rocket'&&g.rand()<.42)g.fx(b.x,b.y,'#d9a2a1',1,19,'smoke');
  }
}