import { place } from './data.js';
import { bayRoom } from './practice.js';
import { atlasRoom } from './atlas-rooms.js';

const r=(x,y,w,h,t)=>({x,y,w,h,t});
const p=(x,y)=>({x,y});
const use=(id,name,x,y)=>({id,name,x,y});
const basic={anchor:p(360,230),spawn:p(360,341),exit:p(360,361),service:p(360,197),scale:1};

function layout(id, name, sub, base, colors, floors, furniture, decor, lights, options={}){
  const spec={...basic,...options,id,name,sub,base,colors,floors,furniture,decor,lights};
  const {x,y,w,h}=base;spec.bounds={x:x+4,y:y+4,right:x+w-4,bottom:y+h-4};
  spec.walls=furniture.filter(q=>q.t!=='rug'&&q.t!=='platform'&&q.t!=='mark').map(q=>({...q}));
  return spec;
}

const Loft=layout('loft','MORROW LOFT','RESIDENTIAL / 07',r(131,80,460,303),['#e4b58f','#ad7a91','#443540'],
  [r(133,82,455,298,'wood'),r(423,100,155,130,'tile'),r(165,176,204,127,'carpet')],
  [r(157,111,111,29,'kitchen'),r(143,169,110,28,'sofa'),r(188,219,64,29,'lowtable'),r(360,100,32,49,'shelf'),r(452,115,89,68,'bed'),r(538,214,33,79,'shelf'),r(426,267,67,34,'desk'),r(381,109,9,58,'partition')],
  [r(153,85,194,10,'window'),r(439,85,125,10,'window'),r(149,283,24,23,'plant'),r(405,294,21,21,'plant')],
  [[213,245,105,'#ffc49d'],[473,143,95,'#f3b3aa']],{service:p(453,316),spots:[use('bed','Rest in the loft',493,203)],anchor:p(360,219),scale:1.13});

const Relay=layout('relay','THE RELAY','SAFEHOUSE / COIL UNION',r(89,67,540,326),['#f2b09e','#d47eab','#403046'],
  [r(92,71,534,319,'wood'),r(118,134,147,171,'carpet'),r(447,98,152,246,'concrete'),r(284,198,153,145,'carpet')],
  [r(119,95,118,39,'rack'),r(132,173,29,108,'sofa'),r(184,198,59,37,'lowtable'),r(130,320,114,38,'shelf'),r(282,107,154,58,'radio'),r(447,98,9,112,'partition'),r(493,111,91,69,'bed'),r(482,249,107,29,'desk'),r(510,310,64,32,'lockers')],
  [r(118,76,139,8,'window'),r(495,75,112,8,'window'),r(119,291,22,23,'plant'),r(389,91,36,7,'screen'),r(288,246,146,76,'rugframe')],
  [[194,223,120,'#ffc293'],[357,146,104,'#ff94bb'],[531,257,76,'#acb7ff']],{spots:[use('wardrobe','Use the wardrobe',530,287),use('bed','Rest at the safehouse',536,198),use('records','Open the case board',203,256)],anchor:p(359,226)});

const Archive=layout('archive','VESPER TRUST','PUBLIC HALL / PRIVATE ARCHIVE',r(75,55,570,348),['#b9d8d5','#7c9bbb','#343748'],
  [r(78,59,564,341,'marble'),r(88,71,543,73,'tile'),r(307,156,106,235,'carpet')],
  [r(111,76,143,24,'vault'),r(465,76,143,24,'vault'),r(300,107,120,26,'archive'),r(149,159,99,44,'counter'),r(472,159,99,44,'counter'),r(142,246,85,28,'bench'),r(491,246,85,28,'bench'),r(121,327,46,34,'planter'),r(553,327,46,34,'planter'),r(272,113,10,41,'pillar'),r(437,113,10,41,'pillar')],
  [r(87,64,546,9,'glass'),r(286,346,148,29,'compass'),r(248,205,47,9,'queue'),r(427,205,47,9,'queue'),r(248,233,47,9,'queue'),r(427,233,47,9,'queue')],
  [[208,193,116,'#b3dbef'],[507,192,116,'#b3dbef'],[357,134,98,'#a0a9df']],{guards:[p(246,117),p(473,287)],anchor:p(361,226)});

const Market=layout('market','RILL NIGHT MARKET','OPEN LATE / SUPPLY HALL',r(102,75,524,307),['#f5bc83','#e28485','#513a42'],
  [r(105,79,518,299,'tile'),r(113,124,497,224,'checker')],
  [r(130,100,133,34,'counter'),r(132,180,41,115,'shelf'),r(209,160,55,121,'produce'),r(343,151,52,129,'shelf'),r(485,143,40,159,'cold'),r(553,123,33,185,'shelf'),r(139,325,97,30,'crate')],
  [r(118,79,146,7,'awning'),r(290,83,157,7,'window'),r(162,146,44,13,'queue'),r(284,304,39,25,'mat'),r(532,317,37,25,'mat')],
  [[195,135,108,'#f8bd8f'],[305,239,80,'#f3a4aa'],[505,197,109,'#a9d4e8']],{exit:p(301,361),spawn:p(301,341),service:p(195,151),spots:[use('rack','Check the cold counter',471,222)],anchor:p(364,222)});

const Bazaar=layout('bazaar','KHEYA PRODUCE HALL','PURAN BAZAAR / EAST AISLE',r(80,67,555,331),['#ffca80','#6bad92','#524737'],
  [r(83,70,549,324,'brick'),r(103,224,510,131,'stone')],
  [r(109,92,130,63,'produce'),r(281,92,146,64,'produce'),r(475,93,125,62,'produce'),r(118,182,98,32,'counter'),r(284,180,129,45,'produce'),r(478,187,124,38,'spices'),r(104,280,84,57,'crate'),r(482,266,100,79,'spices'),r(276,324,154,30,'bench')],
  [r(107,79,505,8,'awning'),r(95,241,484,9,'queue'),r(224,262,28,30,'sacks'),r(439,296,30,32,'sacks')],
  [[176,198,105,'#ffd78d'],[359,206,113,'#f6ba80'],[536,212,102,'#d5e5a1']],{exit:p(246,377),spawn:p(246,356),service:p(181,236),spots:[use('tea','Buy tea from the aisle vendor',433,250)],anchor:p(356,231)});

const Clinic=layout('hospital','ST. ECHO MEDICAL','CLINIC / NIGHT SHIFT',r(91,75,546,310),['#cfe0d1','#6cadb0','#32515a'],
  [r(94,80,540,300,'tile'),r(100,89,165,282,'linoleum'),r(425,89,191,282,'linoleum')],
  [r(106,110,132,33,'cold'),r(113,202,111,31,'bench'),r(130,276,101,33,'bench'),r(252,101,10,108,'partition'),r(259,266,10,94,'partition'),r(452,111,78,43,'hospitalbed'),r(452,200,78,43,'hospitalbed'),r(452,289,78,43,'hospitalbed'),r(544,130,54,40,'desk'),r(560,250,40,55,'cold'),r(283,110,111,34,'counter'),r(407,94,11,59,'partition'),r(407,238,11,45,'partition')],
  [r(132,82,105,7,'window'),r(452,82,151,7,'window'),r(425,171,172,5,'curtain'),r(437,267,175,5,'curtain'),r(282,312,114,22,'medmark')],
  [[331,140,96,'#ddf3de'],[502,222,116,'#9ed7d2'],[161,241,77,'#b3d9d1']],{service:p(336,166),spots:[use('aid','Get a take-home medkit',560,190)],anchor:p(365,222)});

const CommunityClinic=layout('mclinic','KHEYA COMMUNITY CLINIC','MONSOON / FIRST AID',r(144,76,450,319),['#ffe0b1','#68ae96','#4a5e50'],
  [r(148,81,442,310,'checker'),r(163,100,205,135,'linoleum'),r(386,110,178,226,'linoleum')],
  [r(170,109,123,35,'counter'),r(160,237,22,105,'bench'),r(249,216,102,53,'desk'),r(384,85,11,115,'partition'),r(384,257,11,91,'partition'),r(430,109,101,53,'hospitalbed'),r(430,257,101,53,'hospitalbed'),r(517,191,45,48,'cold'),r(294,301,68,37,'crate')],
  [r(161,84,152,7,'window'),r(426,84,129,7,'window'),r(414,232,123,6,'curtain'),r(208,355,76,21,'medmark')],
  [[233,153,118,'#ffdbac'],[481,206,105,'#abddd0']],{spawn:p(239,354),exit:p(239,376),service:p(237,167),spots:[use('aid','Take a clinic medkit',464,202)],anchor:p(365,231),scale:1.07});

const Garage=layout('garage','SABLE MOTORWORKS','BAY 01 / SERVICE SHOP',r(54,66,613,336),['#f5bc8b','#ef896e','#473b45'],
  [r(57,69,607,330,'concrete'),r(103,112,181,230,'service'),r(448,111,162,221,'service')],
  [r(73,84,138,33,'workbench'),r(265,93,119,42,'rack'),r(447,82,157,29,'workbench'),r(485,148,62,136,'lift'),r(121,162,87,150,'lift'),r(565,183,61,101,'tires'),r(307,188,120,47,'counter'),r(307,75,22,14,'crate'),r(81,317,111,44,'tires')],
  [r(78,75,566,7,'glass'),r(300,305,131,37,'service'),r(114,381,132,9,'shutter'),r(456,381,141,9,'shutter'),r(218,303,28,32,'mat')],
  [[165,231,120,'#f6b78f'],[521,202,120,'#e9b097'],[363,211,105,'#c4d2dd']],{service:p(366,254),spots:[use('dyno','Start the workshop dyno',249,218)],anchor:p(362,232),scale:.95});

const Works=layout('works','KADAM WORKS','TRACKED SERVICE / EAST DEPOT',r(49,63,622,345),['#ffd285','#838f73','#48544a'],
  [r(52,67,616,337,'concrete'),r(107,112,237,261,'service'),r(444,108,178,234,'service')],
  [r(104,104,188,37,'rack'),r(136,186,153,137,'rig'),r(385,77,24,122,'partition'),r(438,84,194,34,'workbench'),r(481,166,123,60,'counter'),r(499,274,74,68,'crate'),r(72,174,34,107,'tires'),r(331,310,84,52,'toolwall')],
  [r(70,70,557,10,'glass'),r(103,375,210,9,'shutter'),r(475,369,136,9,'shutter')],
  [[209,210,144,'#ffca83'],[530,194,135,'#d1d9a7']],{spawn:p(443,367),exit:p(443,386),service:p(539,247),spots:[use('dyno','Calibrate the works dyno',329,212)],anchor:p(355,230),scale:.93});

const Precinct=layout('station','GRID PRECINCT 04','CIVIC / FRONT DESK',r(88,69,547,329),['#b0d7fa','#6789be','#374255'],
  [r(91,73,541,322,'tile'),r(104,103,207,225,'checker'),r(355,89,255,227,'concrete')],
  [r(123,106,170,35,'counter'),r(139,193,128,26,'bench'),r(150,287,122,28,'lockers'),r(328,93,12,130,'partition'),r(328,296,12,63,'partition'),r(386,99,188,39,'rack'),r(375,185,95,47,'desk'),r(493,181,96,45,'desk'),r(391,288,192,40,'lockers'),r(587,102,16,143,'shelf')],
  [r(106,76,500,8,'glass'),r(304,246,110,14,'queue'),r(292,328,59,29,'compass')],
  [[204,142,128,'#b0d1f7'],[433,213,105,'#b0bbec'],[555,205,80,'#a3e7df']],{service:p(210,163),exit:p(300,374),spawn:p(300,352),spots:[use('dispatch','Read the dispatch board',422,148)],anchor:p(363,229)});

function metro(id,name,sub,variant){
  const south=variant===2, left=variant===1;
  return layout(id,name,sub,r(61,81,598,298),[left?'#f7d1a3':'#c3e7b8','#659c89',south?'#374b46':'#3c5155'],
    [r(64,85,592,290,'tile'),r(66,94,586,77,'platform'),r(72,195,573,74,'linoleum')],
    [r(85,114,550,56,'platform'),r(118,203,south?80:130,38,south?'kiosk':'counter'),r(270,196,13,68,'pillar'),r(447,196,13,68,'pillar'),r(492,283,124,27,'bench'),r(100,288,67,38,'ticket'),r(199,307,96,15,'gate'),r(522,207,79,27,'ticket'),r(390,89,16,25,'pillar')],
    [r(69,93,574,74,'tracks'),r(76,174,566,7,'safety'),r(88,84,530,8,'glass'),r(306,337,115,16,'mat')],
    [[156,207,104,'#f9dda8'],[552,220,124,'#a4e5d9'],[363,137,126,'#cadfcc']],{service:left?p(555,255):south?p(419,211):p(177,259),exit:p(south?419:357,358),spawn:p(south?419:357,337),anchor:p(359,228),scale:.96});
}

const Arc=layout('arcade','SOFT RESET','ARCADE / TOKEN FLOOR',r(122,75,480,318),['#ffa5d7','#8175fa','#3e3055'],
  [r(125,79,474,310,'carpet'),r(138,100,444,254,'arcadefloor')],
  [r(152,117,37,44,'cabinet'),r(200,113,39,41,'cabinet'),r(252,117,38,43,'cabinet'),r(314,120,41,41,'cabinet'),r(368,118,42,41,'cabinet'),r(529,171,42,57,'cabinet'),r(528,242,42,60,'cabinet'),r(162,289,104,43,'counter'),r(360,271,101,55,'tablegame')],
  [r(139,82,445,8,'neonbar'),r(161,203,340,41,'safety'),r(218,348,148,16,'rugframe')],
  [[185,155,98,'#e893fa'],[366,151,99,'#a68bff'],[473,277,112,'#e884bd']],{spawn:p(296,356),exit:p(296,375),service:p(211,268),spots:[use('darts','Play Neon Darts',409,249),use('records','View your activity records',308,172)],anchor:p(356,226),scale:1.06});

const Cha=layout('cha','NODI CHA HOUSE','PURAN / TEA AND FRUIT',r(149,81,422,286),['#ffd195','#db876c','#554039'],
  [r(152,85,416,278,'brick'),r(171,103,379,233,'checker')],
  [r(169,103,142,43,'kitchen'),r(344,108,104,31,'counter'),r(437,179,91,36,'tablegame'),r(430,268,104,34,'tablegame'),r(181,213,102,35,'bench'),r(182,284,85,34,'spices'),r(297,104,12,80,'pillar'),r(512,107,32,40,'shelf')],
  [r(161,86,395,12,'awning'),r(377,165,143,8,'window'),r(471,317,22,23,'plant'),r(324,307,58,21,'mat')],
  [[228,154,112,'#ffc28f'],[470,209,94,'#faae81'],[344,304,92,'#ffe7a4']],{exit:p(342,346),spawn:p(342,325),service:p(391,158),spots:[use('carrom','Play a carrom table',409,249),use('carrom','Play a carrom table',407,306)],anchor:p(357,215),scale:1.15});

function exchange(id,name,sub,variant){
  const garden=variant==='garden', water=variant==='ghat'||variant==='lake';
  const accent=garden?'#d7e8a1':water?'#a0d9cd':'#f8b88d';
  if(variant==='ghat')return layout(id,name,sub,r(62,70,592,333),[accent,'#609b98','#476157'],
    [r(66,74,584,325,'wood'),r(83,103,367,173,'tile'),r(505,93,130,267,'platform')],
    [r(108,105,179,42,'ticket'),r(322,106,145,45,'windowbench'),r(121,256,193,32,'bench'),r(112,327,144,32,'crate'),r(462,103,12,193,'partition'),r(495,267,107,52,'desk'),r(508,108,112,83,'crate')],
    [r(73,78,572,13,'waterwindow'),r(341,221,92,24,'compass'),r(479,212,155,13,'safety'),r(336,354,107,20,'queue')],
    [[163,146,127,'#f6c7a2'],[556,216,122,'#9be1d9']],{exit:p(379,379),spawn:p(379,358),service:p(218,175),spots:[use('observer','Consult the river atlas',555,230)],anchor:p(356,230),scale:.97});
  if(variant==='lake')return layout(id,name,sub,r(156,80,412,291),[accent,'#8da59f','#445952'],
    [r(160,84,404,283,'wood'),r(174,125,264,219,'stone'),r(448,103,102,245,'turf')],
    [r(186,110,125,37,'counter'),r(192,216,133,32,'windowbench'),r(197,289,121,33,'bench'),r(400,118,34,190,'planter'),r(477,164,63,36,'desk'),r(482,242,61,51,'planter')],
    [r(163,89,392,11,'waterwindow'),r(459,311,38,23,'plant'),r(334,203,55,68,'compass')],
    [[259,159,103,'#f6d5ab'],[479,214,113,'#a8e8d7']],{exit:p(355,348),spawn:p(355,328),service:p(240,178),spots:[use('observer','Look out over the promenade',486,219)],anchor:p(359,216),scale:1.07});
  return layout(id,name,sub,r(82,75,556,317),[accent,'#8ba894','#435749'],
    [r(85,79,550,309,garden?'brick':water?'wood':'concrete'),r(94,89,531,61,garden?'turf':'platform'),r(108,266,498,96,'stone')],
    [r(100,103,122,42,garden?'produce':water?'ticket':'rack'),r(245,102,128,43,'counter'),r(431,103,153,41,garden?'produce':water?'windowbench':'crate'),r(124,208,96,33,'bench'),r(482,206,102,33,water?'desk':'crate'),r(109,304,133,41,garden?'produce':'crate'),r(478,301,121,42,garden?'produce':'bench')],
    [r(97,82,514,12,water?'waterwindow':'glass'),r(285,268,148,66,garden?'rugframe':'compass'),r(385,123,25,23,'plant'),r(254,299,20,20,'plant')],
    [[156,140,99,accent],[315,143,115,'#fbe0a4'],[524,204,103,accent]],{service:p(309,169),exit:p(360,365),spawn:p(360,343),spots:garden?[use('records','Read the cooperative records',357,233)]:[],anchor:p(361,227)});
}

function relay(id,name,sub,coast=false){
  const accent=coast?'#bceadf':'#bea7fb';
  return layout(id,name,sub,r(133,62,455,334),[accent,'#7c81bb','#393c56'],
    [r(137,66,447,326,'concrete'),r(155,89,408,237,'service')],
    [r(163,109,77,91,'rack'),r(481,107,76,94,'rack'),r(263,100,193,69,'radio'),r(167,242,75,58,'archive'),r(492,255,55,43,'crate'),r(336,241,49,54,'pillar')],
    [r(168,72,383,12,coast?'waterwindow':'glass'),r(272,323,163,24,'safety'),r(168,216,119,8,'neonbar'),r(442,216,103,8,'neonbar')],
    [[359,140,134,accent],[204,190,116,'#9ca6e6'],[512,190,120,'#8ea7d4']],{anchor:p(356,226),service:p(360,197),spots:[use('bands','Scan the live frequency board',266,241)],scale:1.05});
}

const Shelter=layout('shelter','SIGNAL SHELTER','EMERGENCY BAND / TRIAGE',r(105,77,515,314),['#e2e9ae','#9aae8d','#434f48'],
  [r(109,81,507,306,'concrete'),r(117,108,137,234,'linoleum'),r(426,111,171,233,'linoleum')],
  [r(127,111,91,49,'bed'),r(129,205,92,48,'bed'),r(132,290,99,48,'crate'),r(294,112,136,55,'radio'),r(468,115,114,39,'rack'),r(489,203,94,52,'hospitalbed'),r(455,303,129,33,'lockers'),r(244,117,10,123,'partition'),r(426,243,10,102,'partition')],
  [r(119,85,471,8,'glass'),r(255,312,166,26,'medmark'),r(472,170,78,8,'queue')],
  [[354,145,108,'#e5e5a7'],[178,237,100,'#b4c38d'],[527,227,113,'#d8e4b8']],{service:p(357,190),spots:[use('bands','Read the emergency-band log',356,218)],anchor:p(359,224)});

const Bus=layout('bus','MEGH TERMINAL','NORTH / DEPARTURES',r(55,70,611,328),['#f3cd8d','#81aca0','#454e53'],
  [r(59,74,603,320,'tile'),r(66,90,583,104,'platform'),r(77,234,553,125,'stone')],
  [r(103,111,156,42,'ticket'),r(301,112,128,41,'counter'),r(488,114,122,37,'kitchen'),r(109,224,163,24,'bench'),r(109,291,163,24,'bench'),r(443,224,160,24,'bench'),r(443,292,160,24,'bench'),r(322,260,83,35,'crate'),r(288,95,9,92,'pillar'),r(438,97,12,92,'pillar')],
  [r(70,76,570,11,'glass'),r(90,181,540,12,'safety'),r(299,334,132,21,'mat')],
  [[170,141,109,'#f9ddaf'],[350,148,112,'#d1dfc1'],[547,160,100,'#efd193']],{service:p(547,177),exit:p(360,366),spawn:p(360,343),spots:[use('shift','Take a scheduled bus route',179,174)],anchor:p(359,229),scale:.96});

const Rooms={relay:Relay,archive:Archive,market:Market,bazaar:Bazaar,hospital:Clinic,mclinic:CommunityClinic,garage:Garage,works:Works,station:Precinct,arcade:Arc,cha:Cha,loft:Loft,bus:Bus,shelter:Shelter,
  citymetro:metro('citymetro','SHAPLA METRO','CENTRAL CONCOURSE',0),northmetro:metro('northmetro','ENCLAVE METRO','NORTHERN PLATFORM',1),oldmetro:metro('oldmetro','PURAN METRO','MARKET CONCOURSE',2),
  ghat:exchange('ghat','SHAPLA GHAT','LAUNCH TERMINAL','ghat'),lake:exchange('lake','JHEEL WALK','PROMENADE PAVILION','lake'),garden:exchange('garden','CHAR COOPERATIVE','RIVER GROWERS / HALL','garden'),dock:exchange('dock','PIER 07','FREIGHT EXCHANGE','dock'),
  swapmeet:layout('swapmeet','LANTERN EXCHANGE','SWAP MEET / CIVIC MARKET',r(110,75,508,314),['#f0c18d','#b17887','#57454f'],
    [r(114,79,500,305,'brick'),r(132,97,455,60,'concrete'),r(140,293,431,75,'wood')],
    [r(133,115,111,42,'toolwall'),r(493,112,87,61,'crate'),r(159,205,72,69,'produce'),r(293,149,143,38,'counter'),r(469,205,99,63,'rack'),r(119,311,93,43,'bench'),r(479,324,82,34,'crate')],
    [r(133,84,448,12,'awning'),r(268,271,154,52,'compass'),r(274,109,172,6,'glass')],
    [[355,168,126,'#f8bb87'],[516,227,107,'#e7aeab']],{service:p(361,210),anchor:p(363,227),spots:[use('records','Review exchange records',341,124)]}),
  switch:relay('switch','NORTH EXCHANGE','GHOST NETWORK'),coast:relay('coast','END OF THE LINE','COASTAL UPLINK',true),
};

export function roomGeometry(id){
  if(id==='bay')return {...bayRoom(),place:place(id)};
  const poi=place(id), room=Rooms[id]||(poi?atlasRoom(poi,layout):Rooms.relay);
  return {...room,walls:room.walls.map(w=>({...w})),spots:room.spots||[],subtitle:room.sub,place:poi};
}