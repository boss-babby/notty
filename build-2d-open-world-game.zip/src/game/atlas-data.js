export const ATLAS_DISTRICTS = [
  {name:'Windglass Airfields', code:'WA', color:'#b5d2dd', roof:'#777e87', ground:'#676458', faction:'Meridian Guild', label:[25.45,1.3], type:'airport'},
  {name:'Saffron Souk', code:'SS', color:'#f3b172', roof:'#9a6c53', ground:'#876752', faction:'Copper Lantern', label:[26.3,3.65], type:'souk'},
  {name:'Meridian Mile', code:'MM', color:'#a2e8d5', roof:'#527b87', ground:'#666e68', faction:'Meridian Guild', label:[28.28,2.67], type:'towers'},
  {name:'Crescent Marina', code:'CM', color:'#87ded4', roof:'#9b9292', ground:'#62696b', faction:'Crescent Pilots', label:[29.75,4.55], type:'marina'},
  {name:'Jasmine Gardens', code:'JG', color:'#d9cd92', roof:'#a38366', ground:'#77735b', faction:'Meridian Guild', label:[27.5,6.1], type:'gardens'},
  {name:'Jacklight Strip', code:'JS', color:'#ff8bb9', roof:'#835978', ground:'#544858', faction:'Velvet Circuit', label:[27.05,14.65], type:'strip'},
  {name:'Sunbelt Courts', code:'SC2', color:'#efb095', roof:'#9a746f', ground:'#776355', faction:'Sunbelt Riders', label:[24.02,15.63], type:'courts'},
  {name:'Basin Airfields', code:'BA', color:'#c0bded', roof:'#807989', ground:'#676267', faction:'Sunbelt Riders', label:[24.7,17.25], type:'airstrip'},
  {name:'Ember Grounds', code:'EG', color:'#c7c99d', roof:'#6d7569', ground:'#6c6b5c', faction:'Ember Detail', label:[30.32,17.65], type:'camp'},
  {name:'Drywash Service', code:'DS', color:'#f2b680', roof:'#8d665b', ground:'#796354', faction:'Copper Lantern', label:[29.9,13.05], type:'works'},
  {name:'Ochre Dunes', code:'OD', color:'#eac288', roof:'#9a765f', ground:'#8e7257', faction:'Wayfarers', type:'dunes'},
  {name:'Rimrock Canyons', code:'RC', color:'#db9c8c', roof:'#966f69', ground:'#775d58', faction:'Wayfarers', type:'canyon'},
  {name:'Silver Salt Flats', code:'SF2', color:'#ded8be', roof:'#9c9183', ground:'#8b8275', faction:'Wayfarers', type:'salt'},
  {name:'Oasis Settlements', code:'OS', color:'#b8d3a0', roof:'#7d8369', ground:'#6d765f', faction:'Wayfarers', type:'oasis'},
  {name:'Outer Islands', code:'OI', color:'#9adad2', roof:'#7a9790', ground:'#637f74', faction:'Crescent Pilots', type:'islands'},
  {name:'Open Gulf', code:'OG', color:'#77aabf', roof:'#4f707c', ground:'#335463', faction:'Crescent Pilots', type:'sea'},
  {name:'Juniper Range', code:'JR', color:'#acbcaa', roof:'#64776f', ground:'#5a7566', faction:'Wayfarers', type:'juniper'},
];

export const ATLAS_PLACES=[
  ['air-mirage','Windglass International','AIRPORT',25,1,'WINDGLASS / INTL',null,157],
  ['mirage-souk','Saffron Market','MARKET',26,3,'SAFFRON MARKET',null,158],
  ['spire','Meridian Spire','OBSERVATORY',28,2,'MERIDIAN SPIRE',null,154],
  ['marina','Crescent Sea Terminal','SEA TERMINAL',29,4,'CRESCENT PIER',null,119],
  ['tide-room','The Tide Room','CLUB',28,4,'THE TIDE ROOM',null,155],
  ['mirage-garage','Jasmine Motorworks','GARAGE',27,5,'JASMINE MOTORS',null,155],
  ['mirage-clinic','Meridian Aid Center','CLINIC',27,2,'MERIDIAN AID',null,155],
  ['jacklight','Jacklight Resort','CASINO',26,14,'JACKLIGHT',null,156],
  ['halation','Halation Club','CLUB',27,15,'HALATION CLUB',null,156],
  ['basin-garage','Sunbelt Customs','GARAGE',28,15,'SUNBELT CUSTOMS',null,154],
  ['basin-air','Basin Regional Airport','AIRPORT',24,17,'BASIN REGIONAL',null,155],
  ['ember','Fort Ember Field Office','ARMY CAMP',30,17,'FORT EMBER',null,154],
  ['basin-clinic','Jacklight Medical','CLINIC',25,15,'JACKLIGHT MED',null,155],
  ['sky-gate','Vesper Sky Gate','AIRPORT',2,-1,'VESPER SKY GATE',null,155],
  ['strip-overlook','Overlook Court','OBSERVATORY',29,15,'OVERLOOK COURT',null,155],
];

export const ATLAS_LABELS={harbor:'Vesper Bay',monsoon:'Monsoon City',mirage:'Mirage Coast',basin:'Neon Basin',wilds:'The Frontier'};
export const ATLAS_CHARTS={world:[-1200,-1200,18660,11340],harbor:[-240,-560,5190,4520],monsoon:[5340,-180,5420,6160],mirage:[11200,-760,5620,4340],basin:[10560,5350,5560,4470]};
export const WORLD_STYLES=[{id:'continental',name:'Continental',blurb:'Dune roads, canyons and scattered coast.'},{id:'islands',name:'Island Chains',blurb:'Inlets, causeways and narrow outer islands.'},{id:'badlands',name:'Badlands',blurb:'Broad salt flats and layered rimrock.'}];
export const ATLAS_STARTS=[{id:'mirage',name:'Mirage Coast',copy:'Start beside the marina and skyline.',place:'marina'},{id:'basin',name:'Neon Basin',copy:'Start on the resort strip after dark.',place:'jacklight'}];
export const AIR_PORTS=['sky-gate','air-mirage','basin-air'];
export const SEA_PORTS=['dock','ghat','marina'];
export const VENUE_CAST={
  'tide-room':[
    {name:'Samira Qadir',role:'Resident DJ',x:350,y:147,color:'#a5ddd1',line:'The sunset set starts when the marina lights turn on. The last ferry is never the last story.'},
    {name:'Leena Noor',role:'Independent escort, off shift',x:181,y:257,color:'#ce9dc1',line:'I am off the clock. If you are looking for a quiet ride across town, use the public ferry. The dock crew knows me.'},
    {name:'Mika Das',role:'Floor host',x:513,y:220,color:'#a4abc8',line:'The Tide Room keeps a table for anybody waiting on a safe ride home.'},
  ],
  halation:[
    {name:'Nova Vale',role:'Resident DJ',x:361,y:135,color:'#ce9bd2',line:'Jacklight gets the tourists. We get the drivers who know the back roads.'},
    {name:'Rae Serrano',role:'Independent escort, off shift',x:473,y:268,color:'#e0ab9d',line:'I pick my own hours. Tonight I am here for the music. The club can call you a cab if you stay late.'},
    {name:'Eli Moss',role:'Door host',x:180,y:291,color:'#9faac8',line:'It is loud inside, quiet around back. Respect both.'},
  ],
};

export const ATLAS_JOBS=[
  {id:'marina-run',name:'Marina Manifest',desc:'Collect a dock manifest and deliver it to Windglass freight.',icon:'M',kind:'delivery',region:'mirage',pay:255,nodes:[[14072,1958],[12157,530]]},
  {id:'meridian-curve',name:'Meridian Loop',desc:'Take the boulevard gates along the glass skyline.',icon:'R',kind:'race',region:'mirage',pay:380,time:65,nodes:[[12983,1451],[13426,1450],[13420,1920],[13916,1919]]},
  {id:'saffron-watch',name:'Lantern Quarter',desc:'Hold the market beacon for the Copper Lantern crew. District control changes with the result.',icon:'T',kind:'turf',region:'mirage',side:'Copper Lantern',rival:'Meridian Guild',pay:360,nodes:[[12505,1462]]},
  {id:'strip-run',name:'Last Marquee',desc:'Race from the resort approach to the edge of the dry wash.',icon:'J',kind:'race',region:'basin',pay:410,time:65,nodes:[[12480,6739],[12950,6740],[12939,7194],[13434,7199]]},
  {id:'fort-relief',name:'Ember Relief',desc:'Collect the marked van at Fort Ember and deliver the civilian aid crates.',icon:'E',kind:'service',vehicle:'rescue',region:'basin',pay:410,time:125,nodes:[[14530,8202],[13920,8171],[12155,7240]]},
  {id:'velvet-block',name:'Velvet Block',desc:'Back the Velvet Circuit at its neighborhood relay. Win or lose the block.',icon:'V',kind:'turf',region:'basin',side:'Velvet Circuit',rival:'Sunbelt Riders',pay:420,nodes:[[12984,7703]]},
];

export const NEW_FACTIONS={'Copper Lantern':'Copper','Meridian Guild':'Meridian','Crescent Pilots':'Pilots','Velvet Circuit':'Velvet','Sunbelt Riders':'Sunbelt','Ember Detail':'Ember','Wayfarers':'Wayfarers'};