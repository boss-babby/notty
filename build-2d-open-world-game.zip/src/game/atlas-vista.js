import { rng } from './core.js';

// Separate palettes and silhouettes give each city its own title art. No assets or fonts are fetched.
export function mountAtlasVista(canvas,motion=true,basin=false){
  const W=680,H=360;canvas.width=W;canvas.height=H;
  const screen=canvas.getContext('2d',{alpha:false});if(!screen)return()=>{};
  const plate=document.createElement('canvas');plate.width=W;plate.height=H;
  const g=plate.getContext('2d');if(!g)return()=>{};
  const R=rng(basin?470291:693070), n=(a,b)=>a+Math.floor(R()*(b-a+1));
  function box(x,y,w,h,c){g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),Math.ceil(w),Math.ceil(h));}
  function poly(c,...p){
    g.fillStyle=c;const hs=p.filter((_,i)=>i%2);
    for(let y=Math.min(...hs)|0;y<=Math.max(...hs);y++){
      const xs=[];
      for(let i=0;i<p.length;i+=2){const j=(i+2)%p.length,a=p[i+1],b=p[j+1];if(a<=y+.5&&b>y+.5||b<=y+.5&&a>y+.5)xs.push(p[i]+(p[j]-p[i])*(y+.5-a)/(b-a));}
      xs.sort((a,b)=>a-b);for(let i=0;i+1<xs.length;i+=2)g.fillRect(Math.round(xs[i]),y,Math.round(xs[i+1])-Math.round(xs[i]),1);
    }
  }
  function line(x,y,a,b,c,w=1){const l=Math.max(Math.abs(a-x),Math.abs(b-y),1);for(let i=0;i<=l;i++)box(x+(a-x)*i/l,y+(b-y)*i/l,w,w,c);}
  function disk(x,y,r,c){for(let j=Math.ceil(y-r);j<y+r;j++){const q=Math.sqrt(r*r-(j-y)**2);box(x-q,j,q*2,1,typeof c==='function'?c(j):c);}}
  function glow(x,y,r,c){const a=g.createRadialGradient(x,y,0,x,y,r);a.addColorStop(0,c);a.addColorStop(1,'transparent');box(x-r,y-r,r*2,r*2,a);}
  const sky=g.createLinearGradient(0,0,0,248);
  (basin?['#191626','#36243f','#683b59','#b56b83','#d79892']:['#211926','#48304b','#8b5069','#d4827c','#f2a77c']).forEach((c,i)=>sky.addColorStop(i/4,c));
  box(0,0,W,H,sky);glow(526,125,200,basin?'#f29cc85f':'#ffb98560');
  const sx=524,sy=117,sr=72;
  disk(sx,sy,sr,y=>{const f=(y-sy+sr)/sr*.5;return `rgb(255 ${Math.round(204-83*f)} ${Math.round((basin?179:145)-57*f)})`;});
  for(let i=54;i<180;i+=6){const q=Math.sqrt(Math.max(0,sr*sr-(i-sy)**2));box(sx-q,i,q*2,1,'#a8516b25');}
  for(let i=0;i<3200;i++){const x=n(0,W),y=n(0,218);box(x,y,n(1,4),1,i%3?'#f4b6b019':'#20193618');}
  for(let i=0;i<38;i++){
    const x=n(0,640),y=n(24,188),w=n(15,211);
    poly(y<120?'#2d203a6d':'#60425b50',x,y+4,x+9,y+1,x+w*.4,y-2,x+w-2,y,x+w+18,y+5,x+17,y+7);
    box(x+14,y+7,w*.78,1,'#ef9c8744');
  }
  if(basin){
    poly('#6e4562',0,225,0,178,47,165,79,173,111,132,157,149,190,132,237,159,272,149,313,181,366,171,406,141,461,172,506,149,533,170,572,145,612,143,650,169,680,150,680,214);
    poly('#3c3247',0,245,0,194,48,176,106,189,148,173,179,189,240,171,294,187,336,183,399,198,456,178,514,193,566,181,614,190,680,169,680,246);
  }
  const floor=basin?224:232;
  function tower(x,top,w,tone,lux){
    const wall=['#42344a','#544053','#464458','#3d4e61','#725260','#4d5369'][tone], edge=['#836580','#92708a','#7792a0','#8eabb0','#a77d88','#8f939f'][tone];
    poly('#302a3e',x,top+6,x+w,top,x+w+13,top+8,x+w+9,floor,x,floor);
    poly(wall,x,top,x+w,top,x+w,floor,x,floor);
    box(x+2,top,w-3,2,edge);box(x+w-4,top+3,2,floor-top,edge+'94');
    if(w>20){box(x+4,top-5,w-9,5,wall);box(x+5,top-6,w-11,1,edge);}
    for(let j=top+8;j<floor-5;j+=6)for(let i=x+4;i<x+w-5;i+=5){
      const t=n(0,7);if(t<6)box(i,j,2,t>3?2:1,lux&&t<3?'#f3b790':t%3?'#a98390':'#9cc4c5');
    }
    for(let j=top+10;j<floor-16;j+=20)box(x,j,w-1,1,edge+'72');
  }
  for(let x=-10;x<W;){const w=n(12,30),y=n(151,208);tower(x,y,w,n(0,5),false);x+=w+n(2,7);}
  const skyline=basin?[[51,183,23],[130,167,28],[222,162,26],[276,159,44],[326,139,36],[389,168,25],[432,123,35],[475,158,26],[522,130,45],[586,147,39],[641,122,28]]:[[47,166,23],[135,153,24],[220,141,29],[280,149,38],[327,121,21],[378,141,32],[432,89,31],[473,111,24],[543,117,31],[590,89,27],[638,132,33]];
  for(const [x,y,w] of skyline)tower(x,y,w,n(0,5),true);
  if(basin){
    for(const [x,y,w] of [[373,189,60],[467,176,67],[569,165,89]]){
      box(x,y,w,floor-y,'#5d435a');box(x,y,w,3,'#c285a8');box(x+6,y+7,w-11,12,'#473349');
      for(let k=5;k<w-4;k+=7){box(x+k,y+3,2,2,'#ffcf9b');box(x+k,y+24,3,2,'#ef9ebd');}
    }
    g.textAlign='center';g.font='bold 10px monospace';g.fillStyle='#ffd4ac';g.fillText('JACKLIGHT',612,181);
    g.fillStyle='#eec1db';g.fillText('HALATION',498,192);glow(610,177,62,'#f59bb24a');
  }else{
    poly('#415b6c',495,227,503,81,508,72,510,53,513,39,516,49,519,72,526,82,534,227);
    poly('#86b1b8',499,227,506,86,512,72,516,50,519,76,525,88,529,227);
    poly('#a5ccca',508,86,514,62,515,50,520,80,523,105,512,154);
    box(515,25,2,22,'#b4d2bd');box(515,24,2,3,'#ffe3aa');
    for(let y=87;y<224;y+=6){box(507,y,12,2,'#516e81');if(y%4===1)box(518,y-1,5,1,'#dccbad');}
    glow(523,214,75,'#afdad246');
  }
  poly('#2a283c',0,220,417,225,680,206,680,360,0,360);
  if(!basin){
    poly('#527080',0,235,457,232,680,216,680,292,495,301,0,323);
    poly('#465a73',0,253,431,257,680,234,680,295,511,304,0,326);
    for(let i=0;i<900;i++){let x=n(0,W),y=n(228,313);if(y>321-x*.04||y<235-x*.026)continue;box(x,y,n(2,13),1,i%3?'#8bb2ad62':'#e8a4976f');}
    poly('#292839',0,349,432,305,680,275,680,360,0,360);
    poly('#635563',0,357,414,311,680,280,680,285,440,318,39,360);line(294,326,680,277,'#e1b5949d',2);
    poly('#718c8e',478,267,514,254,610,251,626,260,603,270,510,276);
    poly('#2d4253',487,268,519,277,607,272,621,263,603,256);
    poly('#c2c6b4',512,255,532,244,578,242,593,248,588,258,517,264);
    poly('#587684',532,249,579,245,586,250,579,254,529,257);
    line(517,263,604,258,'#e5ccad');box(592,256,9,2,'#f6c08d');glow(592,260,26,'#ffc09b4c');
  }else{
    poly('#343348',0,251,392,236,680,221,680,360,0,360);poly('#535064',0,294,431,253,680,227,680,232,453,264,0,305);
    for(let i=0;i<1320;i++){const x=n(0,W),y=n(231,H);if(y>252-x*.056)box(x,y,n(1,15),1,i%3?'#8a678a53':'#e690a368');}
    poly('#e7b68295',426,359,530,286,541,284,460,359);
    poly('#312c40',467,343,474,310,489,290,547,278,593,287,618,310,607,332,561,346,483,350);
    poly('#b66187',473,315,486,296,548,282,586,289,608,306,593,317,493,337,476,333);
    poly('#3d4058',496,297,548,285,580,291,591,301,568,312,499,320);
    poly('#546e82',499,298,549,289,578,294,586,300,532,315,503,316);
    poly('#594668',472,317,493,333,567,318,604,307,609,321,579,334,492,348,473,336);
    box(482,334,15,3,'#f7a0a1');box(582,321,18,3,'#f7a0a2');glow(490,334,26,'#ef7eab62');
  }
  for(let i=0;i<23;i++){
    const x=n(336,680),y=n(basin?235:268,358);glow(x,y,n(10,30),i%2?'#d6999152':'#9ab8c341');
  }
  function palm(x,y,r){
    poly('#393342',x-6,y,x-2,y-r*.85,x+6,y-r,x+4,y-r*.82,x+1,y);line(x-2,y-4,x+2,y-r*.77,'#8b6362',1);
    for(let k=0;k<7;k++){const a=k*Math.PI*.27,ax=x+4+Math.cos(a)*r*.58,ay=y-r*.87+Math.sin(a)*r*.28;
      poly(k%2?'#3b434a':'#34414c',x+4,y-r*.85,x+7+Math.cos(a)*r*.26,y-r*1.07,ax,ay,ax-Math.cos(a)*5,ay+2,x+1,y-r*.76);}
  }
  palm(655,325,117);palm(621,272,52);palm(343,337,66);
  box(0,H-2,W,2,'#44394a');
  const reduce=!motion||matchMedia('(prefers-reduced-motion: reduce)').matches;
  let frame=0,last=0,alive=true;
  const draw=t=>{
    if(!alive)return;
    if(!last||t-last>=66){last=t;screen.drawImage(plate,0,0);
      if(!reduce){for(let i=0;i<36;i++){
        const x=365+((i*43+Math.floor(t*.014))%312),y=(basin?229:246)+(i*19)%57;
        screen.fillStyle=i%2?'#fad7a9':'#b8dad1';screen.globalAlpha=.08+.17*(Math.sin(i+t*.002)*.5+.5);screen.fillRect(x,y,i%7+2,1);
      }screen.globalAlpha=1;}
    }
    if(!reduce)frame=requestAnimationFrame(draw);
  };draw(0);return()=>{alive=false;cancelAnimationFrame(frame);};
}