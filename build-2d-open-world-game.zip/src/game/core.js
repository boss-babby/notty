import { CONTROLS } from './data.js';

export const TAU = Math.PI * 2;
export const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
export const mix = (a, b, t) => a + (b - a) * t;
export const angleDiff = (a, b) => Math.atan2(Math.sin(b - a), Math.cos(b - a));
export const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
export const unit = (x, y) => { const d = Math.hypot(x, y) || 1; return [x / d, y / d]; };
export const mod = (n, d) => ((n % d) + d) % d;
export const hash = (x, y, seed = 47) => (Math.imul(x ^ seed, 374761393) ^ Math.imul(y, 668265263)) >>> 0;
export function rng(seed) {
  return () => {
    seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class SpatialHash {
  constructor(size) { this.size = size; this.buckets = new Map(); this.stamp = 0; }
  clear() { this.buckets.clear(); }
  range(x, y, w, h, visit) {
    const s = this.size;
    for (let i = Math.floor(x / s); i <= Math.floor((x + w) / s); i++) {
      for (let j = Math.floor(y / s); j <= Math.floor((y + h) / s); j++) visit(i + j * 8192);
    }
  }
  add(item, x, y, w, h) {
    this.range(x, y, w, h, key => {
      let bucket = this.buckets.get(key);
      if (!bucket) this.buckets.set(key, bucket = []);
      bucket.push(item);
    });
  }
  query(x, y, w, h, out = []) {
    out.length = 0;
    const stamp = ++this.stamp;
    this.range(x, y, w, h, key => {
      const bucket = this.buckets.get(key);
      if (bucket) for (const item of bucket) if (item._hash !== stamp) { item._hash = stamp; out.push(item); }
    });
    return out;
  }
}

export class Pool {
  constructor(max) { this.items = Array.from({ length: max }, () => ({ active: false })); this.cursor = 0; }
  take(values) {
    for (let i = 0; i < this.items.length; i++) {
      const idx = (this.cursor + i) % this.items.length, item = this.items[idx];
      if (!item.active) { this.cursor = (idx + 1) % this.items.length; return Object.assign(item, values, { active: true }); }
    }
    return null;
  }
  clear() { for (const item of this.items) item.active = false; }
}

export const KEY_ROOT = 'static-harbor/1/';
const memory = new Map();
export function read(key, fallback = null) {
  try {
    const text = globalThis.localStorage?.getItem(KEY_ROOT + key);
    return text ? JSON.parse(text) : (memory.get(key) ?? fallback);
  } catch { return memory.get(key) ?? fallback; }
}
export function write(key, value) {
  memory.set(key, value);
  try { globalThis.localStorage.setItem(KEY_ROOT + key, JSON.stringify(value)); return true; } catch { return false; }
}

const LEGACY = { up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight' };
const ICON_KEYS = { Space: 'SPACE', ShiftLeft: 'SHIFT', ControlLeft: 'CTRL', Escape: 'ESC', Tab: 'TAB' };
export const keyName = code => ICON_KEYS[code] || code.replace(/^Key|^Digit/, '').replace('Arrow', '').toUpperCase();

export class Input {
  constructor(canvas, lookup) {
    this.canvas = canvas;
    this.lookup = lookup;
    this.keys = new Set(); this.presses = new Set(); this.touch = new Set(); this.padPresses = new Set(); this.padOld = [];
    this.mouse = { x: 0, y: 0, active: false, fire: false, focus:false }; this.axes = [0, 0, 0, 0];
    this.pad = false; this.padFire = false; this.padFireEdge=false;this.touchFireEdge=false;this.mouseTap=false; this.enabled = true;
    this.listeners = [];
    const on = (el, event, callback) => { el.addEventListener(event, callback); this.listeners.push([el, event, callback]); };
    on(window, 'keydown', event => {
      const code = event.code;
      if (!this.enabled || event.metaKey || (event.ctrlKey && !['ControlLeft','ControlRight'].includes(code) && !(this.keys.has('ControlLeft') || this.keys.has('ControlRight')))) return;
      if ([...Object.keys(CONTROLS).map(lookup), ...Object.values(LEGACY), 'ControlRight', 'ShiftRight'].includes(code)) event.preventDefault();
      if (!this.keys.has(code)) this.presses.add(code);
      this.keys.add(code);
    });
    on(window, 'keyup', event => this.keys.delete(event.code));
    on(window, 'blur', () => this.reset());
    on(canvas, 'pointermove', event => {
      const rect = canvas.getBoundingClientRect();
      this.mouse.x = event.clientX - rect.left; this.mouse.y = event.clientY - rect.top;
      if (event.pointerType === 'mouse' || event.pointerType === 'pen') this.mouse.active = true;
    });
    on(canvas, 'pointerdown', event => {
      if ((event.button === 0||event.button===2) && event.pointerType !== 'touch' && this.enabled) {
        const rect=canvas.getBoundingClientRect();this.mouse.x=event.clientX-rect.left;this.mouse.y=event.clientY-rect.top;
        this.mouse.active=true;
        if(event.button===0){this.mouse.fire=true;this.mouseTap=true;}else this.mouse.focus=true;
      }
    });
    on(window, 'pointerup', event => {if(event.button===0)this.mouse.fire=false;if(event.button===2)this.mouse.focus=false;});
    on(canvas, 'contextmenu', event => event.preventDefault());
  }
  reset() { this.keys.clear(); this.presses.clear(); this.touch.clear(); this.padPresses.clear(); this.mouse.fire = false;this.mouse.focus=false;this.mouseTap=false;this.padFireEdge=false;this.touchFireEdge=false; }
  release() { for (const [el, event, fn] of this.listeners) el.removeEventListener(event, fn); }
  poll() {
    let pads;
    try { pads = navigator.getGamepads?.(); } catch { pads = null; }
    const pad = pads && Array.from(pads).find(Boolean);
    this.pad = Boolean(pad);
    if (!pad) { this.axes.fill(0); this.padFire = false; this.padBrake=false;this.padFireEdge=false;this.padOld = []; return; }
    for (let i = 0; i < 4; i++) { const v = pad.axes[i] || 0; this.axes[i] = Math.abs(v) > .19 ? v : 0; }
    const map = { 0: 'use', 1: 'dash', 2: 'reload', 3: 'wheel', 8: 'map', 9: 'pause', 11:'camera', 12: 'phone', 13: 'radio', 14:'utility',15: 'heal' };
    const b = n => Boolean(pad.buttons[n]?.pressed);
    for (const [n, key] of Object.entries(map)) if (b(n) && !this.padOld[n]) this.padPresses.add(key);
    this.padFireEdge ||= b(7)&&!this.padOld[7];
    this.padOld = pad.buttons.map(item => item.pressed);
    this.padFire = b(7); this.padBrake = b(6); this.padSprint = b(4); this.padCover = b(5); this.padDash = b(1);
  }
  held(action) {
    return this.touch.has(action) || this.keys.has(this.lookup(action)) || (LEGACY[action] && this.keys.has(LEGACY[action])) ||
      (action === 'sprint' && ((this.pad && this.padSprint) || this.keys.has('ShiftRight'))) || (action === 'cover' && ((this.pad && this.padCover) || this.keys.has('ControlRight'))) ||
      (action === 'dash' && this.pad && this.padDash) || (action==='focus'&&(this.mouse.focus||this.pad&&this.padBrake));
  }
  hit(action) {
    const key = this.lookup(action);
    const keyboard = this.presses.delete(key), pad = this.padPresses.delete(action);
    return keyboard || pad;
  }
  consume(code) { return this.presses.delete(code); }
  endTick() { this.presses.clear(); this.padPresses.clear();this.mouseTap=false;this.padFireEdge=false;this.touchFireEdge=false; }
  virtual(action, down) {
    if (down) { if(action==='fire'&&!this.touch.has(action))this.touchFireEdge=true;this.touch.add(action); this.padPresses.add(action); }
    else this.touch.delete(action);
  }
  get fire() { return this.mouse.fire || this.mouseTap || this.padFire || this.touch.has('fire')||this.touchFireEdge; }
  get fireEdge(){return this.mouseTap||this.padFireEdge||this.touchFireEdge;}
}

export class FixedLoop {
  constructor(tick, draw) { this.tick = tick; this.draw = draw; this.acc = 0; this.prev = 0; this.frameTime = 1 / 60; this.fps = 60; this.handle = 0; }
  start() {
    const step = 1 / 60;
    const frame = t => {
      const raw = this.prev ? (t - this.prev) / 1000 : step;
      this.prev = t;
      const delta = Math.min(.1, raw);
      this.frameTime = mix(this.frameTime, Math.max(.001, raw), .055);
      this.fps = 1 / this.frameTime;
      this.acc += delta;
      let iterations = 0;
      while (this.acc >= step && iterations < 6) { this.tick(step); this.acc -= step; iterations++; }
      if (iterations === 6) this.acc = Math.min(this.acc, step);
      this.draw(this.acc / step, this.fps);
      this.handle = requestAnimationFrame(frame);
    };
    this.handle = requestAnimationFrame(frame);
  }
  stop() { cancelAnimationFrame(this.handle); }
}