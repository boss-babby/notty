import { clamp, rng, TAU } from './core.js';
import { STATIONS } from './data.js';

const midi = n => 440 * 2 ** ((n - 69) / 12);

export class Soundscape {
  constructor(settings) { this.settings = settings; this.ctx = null; this.step = 0; this.station = -1; this.random = rng(81); }
  start() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {}); return; }
    const Audio = globalThis.AudioContext || globalThis.webkitAudioContext;
    if (!Audio) return;
    try {
      const ctx = this.ctx = new Audio();
      const gain = (value, to) => { const node = ctx.createGain(); node.gain.value = value; if (to) node.connect(to); return node; };
      const limit = ctx.createDynamicsCompressor(); limit.connect(ctx.destination);
      this.master = gain(0, limit); this.sfx = gain(0, this.master); this.music = gain(0, this.master);
      const noise = this.noise = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const samples = noise.getChannelData(0);
      for (let i = 0; i < samples.length; i++) samples[i] = this.random() * 2 - 1;
      this.space = ctx.createConvolver();
      const echo = this.space.buffer = ctx.createBuffer(2, Math.floor(ctx.sampleRate * .47), ctx.sampleRate);
      for (let i = 0; i < 2; i++) {
        const samples = echo.getChannelData(i);
        for (let j = 0; j < samples.length; j++) samples[j] = (this.random() * 2 - 1) * (1 - j / samples.length) ** 3;
      }
      this.space.connect(gain(.22, this.sfx));
      this.motorBus = gain(0, this.sfx);
      const engineTone = ctx.createBiquadFilter(); engineTone.type = 'lowpass'; engineTone.frequency.value = 510; engineTone.connect(this.motorBus);
      this.motor = ctx.createOscillator(); this.motor.type = 'triangle'; this.motor.frequency.value = 34; this.motor.connect(engineTone); this.motor.start();
      this.motorTop = ctx.createOscillator(); this.motorTop.type = 'sawtooth'; this.motorTop.frequency.value = 52; this.motorTop.connect(gain(.19, engineTone)); this.motorTop.start();
      this.rainBus = gain(0, this.sfx); this.cityBus = gain(0, this.sfx);
      this.ambience(830, this.rainBus); this.ambience(235, this.cityBus);
      this.sirenBus = gain(0, this.sfx); this.sirenPan = this.pan(this.sirenBus);
      this.sirenVoice = ctx.createOscillator(); this.sirenVoice.type = 'triangle'; this.sirenVoice.connect(this.sirenPan); this.sirenVoice.start();
      this.next = ctx.currentTime;
      this.updateSettings(this.settings);
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    } catch { this.close(); }
  }
  ambience(frequency, to) {
    const f = this.ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = frequency; f.Q.value = .4; f.connect(to);
    const node = this.ctx.createBufferSource(); node.buffer = this.noise; node.loop = true; node.connect(f); node.start();
  }
  close() { this.ctx?.close().catch(() => {}); this.ctx = null; }
  updateSettings(s) {
    this.settings = s;
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(s.muted ? 0 : s.master, t, .04);
    this.music.gain.setTargetAtTime(s.music * .65, t, .065);
    this.sfx.gain.setTargetAtTime(s.sfx, t, .05);
  }
  pan(to, amount = 0) {
    const p = this.ctx.createStereoPanner ? this.ctx.createStereoPanner() : this.ctx.createGain();
    if (p.pan) p.pan.value = clamp(amount, -1, 1);
    p.connect(to); return p;
  }
  note(freq, toFreq, len, amp, type, out, t, pan = 0) {
    const ctx = this.ctx; if (!ctx) return;
    const o = ctx.createOscillator(), env = ctx.createGain(), p = this.pan(out, pan);
    o.type = type; o.frequency.setValueAtTime(Math.max(18, freq), t);
    o.frequency.exponentialRampToValueAtTime(Math.max(18, toFreq), t + len * .85);
    env.gain.setValueAtTime(.0001, t);
    env.gain.exponentialRampToValueAtTime(Math.max(.0002, amp), t + Math.min(.023, len * .23));
    env.gain.exponentialRampToValueAtTime(.0001, t + len);
    o.connect(env); env.connect(p); o.start(t); o.stop(t + len + .01);
    o.onended = () => { o.disconnect(); env.disconnect(); p.disconnect(); };
  }
  burst(freq, len, amp, t, pan = 0, out = this.sfx, reverb = false) {
    const ctx = this.ctx; if (!ctx) return;
    const src = ctx.createBufferSource(), filter = ctx.createBiquadFilter(), env = ctx.createGain(), p = this.pan(out, pan);
    src.buffer = this.noise; filter.type = 'lowpass'; filter.frequency.value = freq; filter.Q.value = .6;
    env.gain.setValueAtTime(Math.max(.0002, amp), t); env.gain.exponentialRampToValueAtTime(.00015, t + len);
    src.connect(filter); filter.connect(env); env.connect(p);
    if (reverb) p.connect(this.space);
    src.start(t, this.random() * .6); src.stop(t + len + .01);
    src.onended = () => { src.disconnect(); filter.disconnect(); env.disconnect(); p.disconnect(); };
  }
  play(name, dx = 0, dy = 0, strength = 1, environment = 'street') {
    if (!this.ctx || this.settings.muted) return;
    const t = this.ctx.currentTime, pan = clamp(dx / 250, -1, 1), v = strength / (1 + Math.hypot(dx, dy) / 160);
    const note = (a, b, l, g, type = 'triangle', after = 0) => this.note(a, b, l, g * v, type, this.sfx, t + after, pan);
    const noise = (f, l, a, echo = false, delay = 0) => this.burst(f, l, a * v, t+delay, pan, this.sfx, echo);
    switch (name) {
      case 'click': note(520, 270, .065, .09); break;
      case 'radio-tick': noise(1590,.11,.085);note(816,757,.077,.048,'triangle');note(1124,904,.077,.041,'triangle',.086);break;
      case 'confirm': note(370, 390, .12, .12); note(626, 687, .18, .1, 'sine', .065); break;
      case 'reload': noise(2200, .12, .16); note(810, 320, .08, .04); break;
      case 'reload-out': noise(2350,.087,.17);note(550,262,.084,.055); break;
      case 'reload-in': noise(3120,.069,.15);note(815,412,.073,.068); break;
      case 'reload-ready': noise(4220,.093,.15);note(655,315,.083,.047);note(1670,827,.057,.034,'sine',.05);break;
      case 'reload-open': noise(1600,.13,.15);note(466,201,.11,.058);break;
      case 'shell': noise(1910,.074,.12);note(1224,618,.11,.043,'sine');break;
      case 'dry': noise(1670,.035,.14);note(600,210,.052,.07);break;
      case 'equip': noise(754,.094,.1);note(234,157,.062,.067);break;
      case 'door': noise(650, .18, .25); note(82, 36, .16, .1, 'sine'); break;
      case 'horn': note(218, 215, .43, .14, 'sawtooth'); note(310, 306, .39, .1); break;
      case 'bell': note(1270, 1200, .23, .12, 'sine'); note(2060, 1940, .16, .046, 'sine', .026); break;
      case 'ferry': note(103, 94, .72, .15, 'triangle'); note(177, 165, .55, .07, 'sine'); break;
      case 'growl': noise(520, .3, .13); note(98, 54, .33, .07, 'triangle'); break;
      case 'wood': noise(890,.085,.125); note(235,65,.12,.09,'sine'); break;
      case 'wood-hit': noise(1080,.141,.18);note(426,88,.092,.079,'triangle');break;
      case 'glass': noise(5800,.28,.225,true);note(2100,1500,.11,.048,'sine');note(3900,2110,.116,.034,'triangle',.037);break;
      case 'metal': noise(2940,.12,.18);note(1390,610,.19,.075,'triangle');break;
      case 'stone': noise(832,.15,.21);note(155,78,.103,.081,'sine');break;
      case 'plate': noise(1650,.12,.17);note(1250,620,.20,.076,'triangle');note(1800,1190,.13,.03,'sine');break;
      case 'body': noise(643,.13,.20);note(147,51,.13,.10,'sine');break;
      case 'armor': noise(2110,.09,.17);note(1100,490,.159,.06,'triangle');break;
      case 'guard': noise(710,.08,.15);note(166,77,.09,.064);break;
      case 'parry': note(1150,620,.14,.09,'triangle');noise(2200,.07,.15);break;
      case 'swish': noise(1720,.16,.09);break;
      case 'swish-heavy': noise(965,.23,.12);note(88,50,.13,.043,'sine');break;
      case 'throw-ready': noise(991,.083,.087);note(580,230,.08,.019);break;
      case 'canister': note(805,237,.124,.074);noise(1520,.107,.076);break;
      case 'tire-pop': noise(1450,.21,.2);note(120,38,.13,.14,'sine');break;
      case 'roll': noise(568,.16,.15);note(113,49,.142,.076,'sine');break;
      case 'vault': noise(710,.16,.12);note(201,87,.13,.063,'sine');break;
      case 'landing': noise(416,.132,.15);note(105,42,.14,.067,'sine');break;
      case 'decoy': note(470,960,.16,.11,'triangle'); note(880,510,.16,.08,'sine',.15); break;
      case 'flare': noise(770,.42,.22,true);note(155,58,.29,.084,'triangle');break;
      case 'screech': noise(1660, .18, .095); note(930, 590, .13, .028); break;
      case 'explosion': noise(420, .64, .44, true); note(77, 22, .61, .32, 'sine'); break;
      case 'thunder': noise(360, 1.28, .31); note(101, 24, 1.12, .14, 'sine'); break;
      case 'hit': noise(1000, .145, .17); note(114, 48, .16, .12, 'sine'); break;
      case 'step': noise(440, .09, .087); note(95, 48, .10, .04, 'sine'); break;
      case 'step-room': noise(530,.095,.102);note(175,69,.093,.059,'triangle');break;
      case 'step-wet': noise(1380,.125,.115);note(114,67,.1,.049,'sine');break;
      case 'grass': noise(960, .11, .074); break;
      case 'water': noise(1800, .18, .117); note(200, 80, .15, .025, 'sine'); break;
      case 'hands': noise(750, .095, .1); note(148, 62, .11, .065); break;
      case 'bat': noise(670, .15, .17); note(216, 55, .17, .11, 'sine'); break;
      case 'blade': noise(3650, .097, .11); note(1180, 355, .095, .021); break;
      case 'pistol': noise(3750,.14,.46,true);noise(710,.13,.21);note(204,59,.13,.15);break;
      case 'smg': noise(4640,.073,.31,true);noise(1190,.079,.115);note(245,88,.08,.09);break;
      case 'shotgun': noise(1800,.24,.57,true);noise(613,.19,.29);note(115,40,.17,.23,'sine');noise(2800,.082,.11,false,.29);break;
      case 'rifle': noise(2820,.17,.49,true);noise(470,.18,.22);note(157,68,.13,.15);break;
      case 'sniper': noise(2140,.28,.59,true);noise(676,.19,.31);note(133,40,.25,.24,'sine');break;
      case 'grenade': noise(2080, .12, .15); note(710, 320, .13, .08); break;
      case 'molotov': noise(4270, .17, .096); note(470, 190, .13, .038, 'sine'); break;
      case 'rocket': noise(2300, .45, .39, true); note(194, 70, .32, .24, 'sawtooth'); break;
      default: noise(1250, .10, .12);
    }
    if(environment==='room'&&['pistol','smg','shotgun','rifle','sniper','rocket'].includes(name)){
      noise(1420,.15,.135,true,.038);noise(840,.16,.081,true,.093);
    }
  }
  jingle(index) {
    if (!this.ctx || this.settings.muted) return;
    const station = STATIONS[index];
    if (!station) return;
    const t = this.ctx.currentTime;
    for (const [i, n] of [0, 2, 4, 5].entries()) {
      const root = midi(station.root + station.notes[n] + 24);
      this.note(root, root * .998, .23, .09, index === 2 ? 'sine' : 'triangle', this.music, t + i * .087, (i - 1.5) * .17);
    }
  }
  advance(sim, paused) {
    if (!this.ctx || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime, car = sim.car, weather = sim.weather;
    const set = (param, val, smooth = .12) => param.setTargetAtTime(val, t, smooth);
    const rpm = car ? clamp(Math.hypot(car.vx, car.vy) / car.model.max, 0, 1.23) : 0;
    set(this.motor.frequency, 34 + rpm * 99); set(this.motorTop.frequency, 54 + rpm * 176);
    set(this.motorBus.gain, !paused && car && !['PEDAL','BICYCLE'].includes(car.model.class) ? .085 + rpm * .125 : 0);
    set(this.rainBus.gain, paused || sim.room ? 0 : weather === 3 ? .22 : weather === 1 ? .138 : .025, .38);
    set(this.cityBus.gain, paused || sim.room ? 0 : .085 + Math.sin(sim.clock * .6) * .015, .42);
    const siren = sim.nearestSiren;
    if (siren && !paused) {
      const d = Math.hypot(siren.x - sim.player.x, siren.y - sim.player.y), doppler = clamp((this.oldSiren - d) * 3, -66, 84) || 0;
      set(this.sirenVoice.frequency, 538 + (Math.sin(sim.clock * 7) + 1) * 160 + doppler, .028);
      set(this.sirenBus.gain, .13 / (1 + d / 87));
      if (this.sirenPan.pan) set(this.sirenPan.pan, clamp((siren.x - sim.player.x) / 300, -1, 1));
      this.oldSiren = d;
    } else set(this.sirenBus.gain, 0);
    if (this.station !== sim.station) { this.station = sim.station; this.step = 0; this.next = t; }
    if (paused || this.station < 0 || this.settings.muted) { this.next = t + .04; return; }
    const s = STATIONS[this.station], danger = sim.outbreak ? Math.min(1,(sim.outbreak.phase-1)*.21+sim.outbreak.noise/900) : sim.heat > 1 ? 1 : sim.heat > 0 ? .5 : 0;
    const division = 60 / (s.bpm + danger * 16) / (this.station === 2 ? 2 : 4);
    if (this.next < t - .5) this.next = t;
    while (this.next < t + .085) {
      const n = this.step++, when = Math.max(t, this.next), beat = n % 16, chord = [0, 3, 1, 4][Math.floor(n / 16) % 4];
      const add = (key, length, amp, type, pan = 0) => this.note(midi(key), midi(key) * .999, length, amp, type, this.music, when, pan);
      if (this.station === 2) {
        if (beat % 8 === 0) for (const [i, shift] of [0,7,12].entries()) add(s.root + s.notes[chord] + shift, 2.4, .045, 'sine', i * .6 - .6);
        if (beat % 3 === 0) add(s.root + s.notes[(n * 3 + chord) % 6] + 19, 1.25, .057, 'triangle', Math.sin(n) * .65);
        if (danger && beat % 2 === 0) this.burst(1700, .095, .032, when, 0, this.music);
      } else {
        if (beat % 4 === 0 || (danger && beat === 14)) this.note(95, 28, .19, .19, 'sine', this.music, when);
        if (beat === 4 || beat === 12) this.burst(1200, .13, .15, when, -.17, this.music);
        if (beat % 2 === 0 || (danger && beat % 4 === 3)) this.burst(5400, .041, .055, when, .29, this.music);
        if ([0,3,6,8,11,14].includes(beat)) add(s.root + s.notes[chord] + (beat === 11 ? 12 : 0), this.station === 1 ? .29 : .23, .12, this.station === 1 ? 'sine' : 'triangle');
        if (this.station === 1 && beat % 4 === 2) for (const n of [0, 3, 7]) add(s.root + 24 + s.notes[chord] + n, .16, .043, 'triangle', n / 6 - .5);
        if (this.station === 0 && (beat % 4 !== 1 || danger)) add(s.root + s.notes[(n + chord) % 6] + 24, .16, .062, 'triangle', Math.sin(n) * .42);
      }
      this.next += division;
    }
  }
}