import { CELL, COLS, ROWS, SEED } from './data.js';
import { mix, mod } from './core.js';
import { originalCell, outerEdge, outerRegion, outerRoadAt, outerWater, outerZone } from './frontier-geo.js';

export const LEGACY_COLS = 10, LEGACY_ROWS = 8;
export const STRAIT_ROUTES = [2, 5, 7];
export const RIVER_CROSSINGS = [13, 17, 20];
export const LAKE_CROSSINGS = [15, 17, 19];
export const RIVER_GUIDE = [[5210,4330,154],[6030,4272,108],[6660,4380,112],[7324,4614,112],[7863,4669,119],[8520,4572,117],[9130,4328,125],[9820,4177,114],[10560,4315,145]];
export const LAKE_GUIDE = [[6880,1785,1],[7330,1845,77],[7790,1978,126],[8210,2010,132],[8610,1935,91],[9060,2025,116],[9540,2160,55],[9830,2168,1]];
export const METRO_LINE = [[16*CELL+14,360],[16*CELL+14,1412],[16*CELL-18,1436],[14*CELL+46,1436],[14*CELL+14,1470],[14*CELL+14,3650]];
export const JETTY = { x: 7324, y: 4478, end: 4503 };
export const FERRY_POINTS = [[7324,4508],[7863,4669],[8580,4562]];

export const legacyCell=(cx,cy)=>cx>=0&&cy>=0&&cx<LEGACY_COLS&&cy<LEGACY_ROWS;
export const cellKey=(x,y)=>legacyCell(x,y)?x+y*LEGACY_COLS:originalCell(x,y)?80+x+y*COLS:`${x}:${y}`;
export const regionOf=(x,y)=>{const cx=Math.floor(x/CELL),cy=Math.floor(y/CELL);return cx===2&&cy===-1?'harbor':originalCell(cx,cy)?cx>=11?'monsoon':'harbor':outerRegion(cx,cy);};
export const pointLimit=p=>Number.isFinite(p)?Math.max(-9e8,Math.min(9e8,p)):0;

export function zoneFor(cx,cy,seed=SEED,style='continental') {
  if(!originalCell(cx,cy))return outerZone(cx,cy,seed,style);
  if (legacyCell(cx,cy)) return cx >= 8 ? 3 : cy <= 1 ? 4 : cy >= 5 && cx <= 3 ? 1 : cx >= 5 && cy >= 3 ? 2 : 0;
  if (cx <= 11) return 5;
  if (cy <= 2) return cx >= 19 ? 7 : 6;
  if (cy >= 10) return 11;
  if (cx >= 19 && cy >= 5) return 12;
  if (cy >= 7) return 10;
  if ((cy === 3 || cy === 4) && cx >= 15 || cy === 5 && cx >= 17) return 8;
  return 9;
}

function ribbon(guide,x,y) {
  if(x < guide[0][0] || x > guide.at(-1)[0]) return false;
  for(let n=1;n<guide.length;n++) {
    const [b,by,bw]=guide[n]; if(x>b) continue;
    const [a,ay,aw]=guide[n-1], t=(x-a)/(b-a);
    return Math.abs(y-mix(ay,by,t)) < mix(aw,bw,t);
  }
  return false;
}

export function wetland(x,y,seed=SEED,style='continental') {
  const cx=Math.floor(x/CELL),cy=Math.floor(y/CELL);
  if(!originalCell(cx,cy))return outerWater(x,y,seed,style)?4:0;
  const west=STRAIT_ROUTES.some(r=>Math.abs(y-r*CELL)<54)?4320:4505;
  if(x>=west && x<5525+Math.sin(y*.0031)*100+Math.sin(y*.0013)*104) return 1;
  if(x>=5200 && y>4000 && y<4900 && ribbon(RIVER_GUIDE,x,y)) return 2;
  if(x>=6880 && y>1600 && y<2300 && ribbon(LAKE_GUIDE,x,y)) return 3;
  return 0;
}

export function bridgeDeck(x,y,water=wetland(x,y),seed=SEED,style='continental') {
  if(water===1) return STRAIT_ROUTES.some(r=>Math.abs(y-r*CELL)<=39);
  if(water===2) return RIVER_CROSSINGS.some(r=>Math.abs(x-r*CELL)<=36);
  if(water===3) return LAKE_CROSSINGS.some(r=>Math.abs(x-r*CELL)<=33);
  if(water===4)return outerRoadAt(x,y,seed,style);
  return false;
}

export function expansionWater(x,y,seed=SEED,style='continental') {
  const water=wetland(x,y,seed,style);
  if(!water||bridgeDeck(x,y,water,seed,style))return false;
  if(water===2 && Math.abs(x-JETTY.x)<17 && y>=JETTY.y && y<JETTY.end) return false;
  return true;
}

export function navigable(x,y,seed=SEED,style='continental') {
  const t=wetland(x,y,seed,style);
  return Boolean(t && !(t===2 && Math.abs(x-JETTY.x)<13 && y>=JETTY.y && y<JETTY.end));
}

export function widths(x,y) {
  if(x<4382 && y<8*CELL) return [42,42];
  const col=Math.round(x/CELL), row=Math.round(y/CELL), raw=wetland(x,y);
  if(raw) return [36,39];
  return [col % 4===0 || col===14 || col===17 || col===20 ? 39 : 25, row===2 || row===5 || row===8 || row===10 ? 40 : 27];
}

export const axisDist = p => Math.min(mod(p,CELL), CELL-mod(p,CELL));
export function arterial(x,y) { const [w,h]=widths(x,y); return axisDist(x)<=w || axisDist(y)<=h; }
export function laneWidth(cx,cy) { return zoneFor(cx,cy)===10 ? 13 : zoneFor(cx,cy)===6 ? 21 : 17; }

// Shared by traffic and the route map: only complete land or bridge segments can carry traffic.
const connections=new Map();
export function roadConnection(ix,iy,nx,ny,seed=SEED,style='continental') {
  if(Math.abs(nx-ix)+Math.abs(ny-iy)!==1)return false;
  const near=originalCell(ix,iy)&&originalCell(nx,ny);
  if(!near)return outerEdge(ix,iy,nx,ny,seed,style)>0;
  const a=ix+iy*COLS,b=nx+ny*COLS,key=Math.min(a,b)*COLS*ROWS+Math.max(a,b);
  if(connections.has(key)) return connections.get(key);
  let open=true;
  for(let n=0;n<=8;n++) {
    const x=mix(ix,nx,n/8)*CELL,y=mix(iy,ny,n/8)*CELL;
    // Legacy canal crossings were always carried by the grid; only the new strait interrupts it.
    if(expansionWater(x,y,seed,style)||n===3&&expansionWater(mix(ix,nx,.49)*CELL,mix(iy,ny,.49)*CELL,seed,style)){open=false;break;}
  }
  if(open&&ix===nx&&ix<=9&&iy!==ny&&Math.min(iy,ny)===7&&ix>=8)open=false;
  connections.set(key,open); return open;
}

export function closestJunction(from,seed=SEED,style='continental') {
  const cx=Math.round(from.x/CELL),cy=Math.round(from.y/CELL);
  let best={x:cx,y:cy}, score=Infinity;
  for(let y=cy-4;y<=cy+4;y++) for(let x=cx-4;x<=cx+4;x++) {
    if(![[x+1,y],[x-1,y],[x,y+1],[x,y-1]].some(([nx,ny])=>roadConnection(x,y,nx,ny,seed,style)))continue;
    const dist=(x*CELL-from.x)**2+(y*CELL-from.y)**2;
    if(dist<score){best={x,y};score=dist;}
  }
  return best;
}