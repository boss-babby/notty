import { CELL, GARAGE, DISTRICTS } from './data.js';
import { TAU, clamp, mix, mod, dist, unit, angleDiff } from './core.js';
import { roadPath } from './world.js';
import { navigable, regionOf, roadConnection, wetland } from './geography.js';
import { ambientPatrol, driveUnit, isUnit, updateDispatch } from './dispatch.js';
import { localPath } from './navigation.js';
import { physicalAttack } from './contact.js';
import { updateTraffic } from './traffic.js';
import { fleeHeading, nextRoutine, pedestrianRoute, readReaction, separatePeople } from './crowds.js';
import { factionDisposition, startStreetEvent, tickStreetEvents } from './street-events.js';

const PALETTE = ['#85a3a6', '#b48da5', '#de946e', '#918bc6', '#d7bf9c', '#77929c', '#b66386', '#729f7a'];
const SKIN = ['#e9bd9e', '#c18b70', '#99654f', '#f9d3b8', '#804e48'];
const COPS = new Set(['cruiser', 'swat', 'military','patrol']);

export function addCar(g, model, x, y, a = 0, mode = 'parked', options = {}) {
  const m = GARAGE[Math.floor(model)] || GARAGE[0];
  const v = { type: 'car', id: ++g.uid, x, y, ox: x, oy: y, a, oa: a, vx: 0, vy: 0, r: m.w * .57, model: m,
    mode, color: m.color, hp: m.hp, plate: `${64 + (g.uid % 30)}-VB`, owned: false, speed: 0, driver: false,
    signal: 0, brake: false, contact: 0, smoke: 0, horn: 0, boost: 0, fire: 0, wreck: false, siren: COPS.has(mode),
    path:null,road:null,steer:0,light:true,alt:0,scuffs:[],tireWear:0,...options };
  g.cars.push(v); return v;
}

export function addPerson(g, type, x, y, options = {}) {
  const n = g.people.take({ type, id: ++g.uid, x, y, ox: x, oy: y, a: 0, oa: 0, hp: type === 'ped' ? 42 : 84, r: 8, stride: 0, hit: 0,
    dead: 0, state: 'walk', timer: g.rand() * 3, count: 0, cd: g.rand() * .84, color: PALETTE[Math.floor(g.rand() * PALETTE.length)],
    skin: SKIN[Math.floor(g.rand() * SKIN.length)], hair: Math.floor(g.rand() * 3), indoor: false, keep: false, boss: false, path: null, stuck: 0,
    tx:x,ty:y,blocked:0,identity:null,home:null,routeIndex:0,routeTime:0,dispatchOfficer:false,brain:null,
    attack:null,shotPlan:null,flash:0,stun:0,pushX:0,pushY:0,fallA:null,sparTier:0,routine:'',outfit:0,
    mood:((g.uid*37)%101)/100,reactAt:0,fearAt:null,fleeGoal:null,route:null,routeGoal:null,routeAt:0,routeStep:0,team:null,sideGroup:null,armor:0,detailClass:'',...options });
  return n;
}

export function hitCar(g, car, amount, source = 'world',detail=null) {
  if (car.wreck) return;
  car.hp = Math.max(0, car.hp - amount);
  if(detail&&car.scuffs.length<11)car.scuffs.push({x:detail.ax,y:detail.ay,glass:detail.material==='glass'});
  if (car.hp <= 0 && !car.fire) car.fire = 1.1;
  if (source === 'player' && amount > 12 && car.mode !== 'mission' && !car.owned) g.crime(.32, 'Damage reported near the roadway.');
}

export function hurtPerson(g, n, amount, source = 'world',detail=null) {
  if (!n.active || n.dead || n.type === 'ally') return;
  const armor=Math.min(n.armor||0,amount*.47);n.armor=Math.max(0,(n.armor||0)-armor);amount-=armor;
  if(armor>1)g.hear('armor',n.x,n.y,.45);
  n.hp -= amount; n.hit = .18;
  const color=n.type==='infected'?'#adc49a':'#d7a5b2';
  if(detail){
    n.pushX=(detail.fx||0)*Math.min(67,amount*2.1);n.pushY=(detail.fy||0)*Math.min(67,amount*2.1);
    if(amount>=12){n.stun=Math.max(n.stun,.15+Math.min(.15,amount*.001));n.attack=null;n.shotPlan=null;if(n.brain)n.brain.attack=null;}
    const style=n.type==='spar'||n.type==='infected'||g.settings.impactTint===false?'dust':'ink';
    g.fx(detail.x??n.x,detail.y??n.y,style==='ink'?'#a65372':color,6,43,style,{x:detail.fx||0,y:detail.fy||0});
  }else g.fx(n.x,n.y,color,4,35,'dust');
  if (source === 'player' && (n.type === 'ped' || n.type === 'officer')) g.crime(n.type === 'officer' ? .65 : .52,
    n.type === 'officer' ? 'Grid dispatch requests backup.' : 'Witnesses report a street incident.');
  if(source==='player'&&n.team)g.adjustFaction(n.team,-.65);
  if (n.hp <= 0) {
    n.dead=n.type==='spar'?.82:3.2;n.state='down';n.fallA=detail?Math.atan2(n.pushY,n.pushX):n.a+Math.PI*.42;
    if(n.type==='spar'&&g.practice)g.practice.total++;
    if(n.type==='infected')g.outbreakDrop?.(n);
    if (source === 'player') { g.stats.takedowns++; g.skills.aim += 1; if (n.type === 'enemy') g.rep.Prism -= .7; }
  } else if (n.type === 'ped') { n.state = g.rand() < .3 ? 'fight' : 'flee'; n.timer = 4; }
}

export function updateDrive(g, dt) {
  const v = g.car, p = g.player, input = g.input;
  if (!v) return;
  if(input.hit('lights')){v.light=!v.light;g.hear('click',v.x,v.y,.44);}
  const tracked=v.model.class==='TRACKED'||v.model.class==='TANK', boat=v.model.class==='BOAT', pedal=['PEDAL','BICYCLE'].includes(v.model.class);
  if(boat){driveBoat(g,v,dt);return;}
  if(v.model.class==='AIR'){driveAir(g,v,dt);return;}
  const wet = g.weather === 1 || g.weather === 3;
  const gripWeather=wet?.55+.17*(1-(g.weatherStyle?.wet||0)):1-(g.weatherStyle?.wet||0)*.19;
  const road=g.city.road(v.x,v.y),water=g.city.water(v.x,v.y),surface=g.city.grip(v.x,v.y);
  const [padX, padY] = input.axes;
  const gas = (input.held('up') ? 1 : input.held('down') ? -1 : -padY) - (input.pad && input.padBrake ? .64 : 0);
  const turn = input.held('left') ? -1 : input.held('right') ? 1 : padX;
  const speed = Math.hypot(v.vx, v.vy);
  const forward = v.vx * Math.cos(v.a) + v.vy * Math.sin(v.a);
  const drift = input.held('dash');
  v.a += tracked ? turn * (1.25 + Math.max(0,1-speed/218)*.61) * dt : turn * (1.22 + Math.max(0, 1 - speed / 355) * 1.87) * clamp(Math.abs(forward) / (pedal?28:47), 0, 1) * Math.sign(forward) * (drift ? 1.24 : 1) * dt;
  const cx = Math.cos(v.a), sy = Math.sin(v.a);
  const speedLimit=(road?1:water?.3:tracked?.9:pedal?.86:surface)*(v.model.max+v.boost*54)*(v.tow?.towed?.79:1);
  const front = clamp((forward + gas * (gas * forward > -20 ? v.model.power : v.model.power * 1.6) * dt) * (1 - (gas === 0 ? .82 : .38) * dt), -105, speedLimit);
  const side=(-v.vx*sy+v.vy*cx)*Math.exp(-v.model.grip*(tracked?1:Math.min(1,gripWeather+(g.perks?.includes('smooth-ride')?.13:0)))*(road||tracked?1:surface*.82)*(drift&&!tracked?.23:1)*dt);
  v.vx = cx * front * (drift ? .991 : 1) - sy * side; v.vy = sy * front * (drift ? .991 : 1) + cx * side;
  if (water) { v.vx *= .95; v.vy *= .95; hitCar(g, v, 17 * dt); }
  if(v.tireWear>0){
    v.tireWear=Math.max(0,v.tireWear-dt*.042);
    v.a+=Math.sin(g.clock*14)*v.tireWear*dt*.21;v.vx*=1-v.tireWear*dt*.76;v.vy*=1-v.tireWear*dt*.76;
    if(speed>85&&v.smoke<=0){v.smoke=.12;g.fx(v.x-cx*13,v.y-sy*13,'#9d9baa',2,29,'smoke');}
  }
  if (v.wreck) { g.exitCar(true); return; }
  v.brake = drift || gas < 0; v.steer = turn; v.signal = turn > .55 ? 1 : turn < -.55 ? -1 : 0;
  const previous = { x: v.x, y: v.y };
  const hit = g.city.move(v, v.vx * dt, v.vy * dt, v.r);
  if (hit) {
    if (hit.type === 'prop' && speed > (tracked?34:94)) g.breakProp(hit, speed * (tracked?1.2:.38), 'player');
    if(speed>64&&v.contact<=0){g.hear('hit',v.x,v.y,clamp(speed/165,.3,1.3));g.fx(v.x+cx*13,v.y+sy*13,'#ffc991',10,speed/2);g.bump(speed/45);v.contact=.27;hitCar(g,v,speed*(tracked?.03:.09),'world',{ax:v.model.l*.44,ay:Math.abs(previous.x-v.x)<.1?-v.model.w*.26:v.model.w*.25});}
    if (Math.abs(previous.x - v.x) < .1) v.vx *= -.38;
    if (Math.abs(previous.y - v.y) < .1) v.vy *= -.38;
  }
  for (const o of g.cars) {
    if (o === v || o.wreck || o===v.tow || o.alt>18) continue;
    const d = dist(v, o), min = (v.model.l + o.model.l) * .32;
    if (d >= min || d < .01) continue;
    const [nx, ny] = unit(v.x - o.x, v.y - o.y);
    g.city.move(v, nx * (min - d) * .6, ny * (min - d) * .6, v.r);
    const closing = (v.vx - o.vx) * nx + (v.vy - o.vy) * ny;
    if (closing < 0) { v.vx -= closing * .98 * nx; v.vy -= closing * .98 * ny; if (!o.keep || o.mode === 'runner') { o.x -= nx * 2; o.y -= ny * 2; } }
    if (closing < -63 && v.contact <= 0) {
      hitCar(g, v, -closing * (tracked?.022:.073)); hitCar(g, o, -closing * (tracked?.48:.33), 'player');
      g.fx((v.x + o.x) / 2, (v.y + o.y) / 2, '#ffbd91', 10, 82); g.hear('hit', v.x, v.y); g.bump(-closing / 38); v.contact = .22;
    }
  }
  if (speed > 64) for (const n of g.people.items) {
    if (n.active && !n.indoor && !n.dead && n.type !== 'ally' && dist(v, n) < v.r + 7) { hurtPerson(g, n, speed * .65, 'player'); v.vx *= .94; v.vy *= .94; }
  }
  if (speed > 101 && (Math.abs(side) > 34 || (drift && Math.abs(turn) > .24))) {
    g.skid(v.x - cx * v.model.l * .35 - sy * 6, v.y - sy * v.model.l * .35 + cx * 6, v.a);
    if (v.smoke <= 0) { v.smoke = .095; g.fx(v.x - cx * 17, v.y - sy * 17, wet ? '#8794ba' : '#ab91aa', 2, 23, 'smoke'); }
    if (v.horn <= 0) { g.hear('screech', v.x, v.y); v.horn = .35; }
  }
  v.pulse=Math.max(0,(v.pulse||0)-dt);
  if (v.model.class==='TANK' && input.fire && !v.pulse) {
    const aim=input.mouse.active?g.aimWorld():null;
    const a=Math.hypot(input.axes[2],input.axes[3])>.21?Math.atan2(input.axes[3],input.axes[2]):aim?Math.atan2(aim.y-v.y,aim.x-v.x):v.a;
    v.turret=a;v.pulse=1.35;
    g.launchBolt(v.x+Math.cos(a)*32,v.y+Math.sin(a)*32,a,74,400,'rocket','player');
    g.light(v.x,v.y,'#ffe49e',65,.16);g.hear('rocket');g.bump(5);g.signalNoise?.(625);
  }
  if(input.hit('horn')){v.siren=v.model.class==='RESCUE'||v.model.id==='patrol'?!v.siren:false;g.hear(pedal?'bell':'horn',v.x,v.y);g.signalNoise?.(pedal?90:440);}
  v.speed = Math.hypot(v.vx, v.vy);
  if (v.speed > 35) { g.stats.driven += v.speed * dt; g.skills.drive += dt * .33; }
  p.x = v.x; p.y = v.y; p.a = v.a;
}

function driveAir(g,v,dt){
  const i=g.input,p=g.player;
  const down=i.held('dash'), rise=!down&&(i.held('up')||v.alt>18);
  if(down||rise)v.alt=clamp(v.alt+(down?-87:69)*dt,0,106);
  const forward=i.held('up')?1:i.held('down')?-.66:-i.axes[1];
  const turn=i.held('left')?-1:i.held('right')?1:i.axes[0];v.a+=turn*2.35*dt;
  const lift=clamp(v.alt/32,.12,1), desired=down?forward*v.model.max*.29:forward*v.model.max*lift;
  v.vx=mix(v.vx,Math.cos(v.a)*desired,dt*(down?4.5:2.35));v.vy=mix(v.vy,Math.sin(v.a)*desired,dt*(down?4.5:2.35));
  const x=v.x+v.vx*dt,y=v.y+v.vy*dt;
  if(v.alt<24&&(g.city.water(x,y)||g.city.block(x,y,16))){v.alt=Math.max(25,v.alt);v.vx*=.8;v.vy*=.8;}
  v.x=x;v.y=y;v.speed=Math.hypot(v.vx,v.vy);v.brake=down;
  p.x=x;p.y=y;p.a=v.a;g.stats.driven+=v.speed*dt;
  if(v.speed>42)g.skills.drive+=dt*.33;
  if(v.alt>6)g.signalNoise?.(218,p,'vehicle');
}

function driveBoat(g,v,dt){
  const i=g.input,p=g.player;
  const gas=i.held('up')?1:i.held('down')?-.7:-i.axes[1], turn=i.held('left')?-1:i.held('right')?1:i.axes[0];
  const speed=Math.hypot(v.vx,v.vy), brake=i.held('dash');
  v.a+=turn*(1.7+.5*(1-Math.min(1,speed/230)))*dt;
  const power=gas*v.model.power*dt;v.vx+=Math.cos(v.a)*power;v.vy+=Math.sin(v.a)*power;
  const drag=Math.exp(-(brake?4:1.13)*dt), final=Math.hypot(v.vx,v.vy), lim=Math.min(drag,v.model.max/(final||1));
  v.vx*=lim;v.vy*=lim;
  const x=v.x+v.vx*dt,y=v.y+v.vy*dt;
  const seed=g.city.seed,style=g.city.style,can=(a,b)=>navigable(a,b,seed,style)||!wetland(v.x,v.y,seed,style)&&wetland(a,b,seed,style);
  if(can(x,y)){v.x=x;v.y=y;}else if(can(x,v.y)){v.x=x;v.vy*=.87;}else if(can(v.x,y)){v.y=y;v.vx*=.87;}else{v.vx*=.8;v.vy*=.8;}
  v.speed=Math.hypot(v.vx,v.vy);v.brake=brake;
  if(v.speed>38&&v.smoke<=0){v.smoke=.095;g.fx(v.x-Math.cos(v.a)*22,v.y-Math.sin(v.a)*22,'#c4ead3',3,22,'smoke');}
  if(i.hit('horn')){g.hear('ferry');g.signalNoise?.(530);}
  p.x=v.x;p.y=v.y;p.a=v.a;g.stats.driven+=v.speed*dt;
}

export { setRoad } from './traffic.js';

function pedestrian(g, n, dt) {
  const p = g.player, d = dist(n, p);
  if(n.type==='target'||n.type==='host')return;
  if(n.type==='dancer'){
    const t=g.clock+(n.pace||0);n.a+=dt*(.8+Math.sin(t*2)*.37);n.stride+=dt*7.5;
    if(g.settings.motion){n.x+=Math.sin(t*2.7)*dt*9;n.y+=Math.cos(t*2.2)*dt*8;}
    return;
  }
  n.flash=Math.max(0,n.flash-dt);
  if (n.dead > 0) { n.dead = Math.max(.001, n.dead - dt); if (n.dead <= .002 && !n.keep) n.active = false; return; }
  n.hit -= dt; n.cd -= dt; n.timer -= dt;
  if (n.indoor !== Boolean(g.room)) return;
  if (n.type === 'ally') return;
  if(n.stun>0){n.stun-=dt;g.move(n,(n.pushX||0)*dt,(n.pushY||0)*dt,n.r);n.pushX*=.80;n.pushY*=.80;return;}
  if(n.attack){
    const swing=n.attack;swing.time+=dt;
    if(!swing.done&&swing.time>=swing.wind){swing.done=true;const heading=Math.atan2(p.y-n.y,p.x-n.x);if(Math.abs(angleDiff(swing.angle,heading))<1.02)physicalAttack(g,n,31,swing.force);}
    if(swing.time>=swing.total)n.attack=null;
    return;
  }
  if(n.shotPlan){
    const shot=n.shotPlan;shot.time-=dt;
    if(shot.time<=0){n.shotPlan=null;n.flash=.081;g.launchBolt(n.x+Math.cos(shot.angle)*10,n.y+Math.sin(shot.angle)*10,shot.angle,n.boss?13:8,302,'bolt','npc');g.hear('pistol',n.x,n.y,.55);}
    return;
  }
  if(n.type==='spar'){
    const a=Math.atan2(p.y-n.y,p.x-n.x),side=n.id%2===0?1:-1;
    n.a+=clamp(angleDiff(n.a,a),-dt*6,dt*6);
    if(d<27&&n.cd<=0){startPunch(g,n,a,9+n.sparTier*2,.26+n.sparTier*.025);return;}
    if(d<24)return;
    const speed=d>40?71+n.sparTier*8:23;
    const track=d>42?a:a+Math.PI*.63*side;
    const hit=g.move(n,Math.cos(track)*speed*dt,Math.sin(track)*speed*dt,n.r);
    if(hit)g.move(n,-Math.sin(track)*speed*.65*dt*side,Math.cos(track)*speed*.65*dt*side,n.r);
    n.stride+=dt*speed*.15;return;
  }
  let dx = n.tx - n.x, dy = n.ty - n.y, speed = 32;
  if (n.type === 'ped') {
    if(n.team&&n.state==='walk'&&n.mood>.71&&d<45&&!g.car&&factionDisposition(g,n.team)==='Hostile'&&g.alarm>0){n.state='fight';n.timer=2;}
    readReaction(g,n);
    if (n.state === 'call' || n.state === 'film') {
      n.a = Math.atan2(p.y - n.y, p.x - n.x);
      if(n.timer<0){if(n.state==='call')g.witness(n.fearAt||p,'Dispatch received a witness call.');else g.report('Witness clip circulates on the overnight Wire.');n.state='flee';n.timer=3.5;}
      return;
    }
    if(n.state==='flee'){
      const q=fleeHeading(g,n);dx=q.x-n.x;dy=q.y-n.y;speed=n.routine==='parcel'?103:97;
      if(n.timer<0&&n.routine!=='parcel'){n.state='walk';n.route=null;}
    }
    else if (n.state === 'fight') {
      dx = p.x - n.x; dy = p.y - n.y; speed = d < 17 ? 0 : 64;
      if(d<24&&n.cd<=0&&!g.car){startPunch(g,n,Math.atan2(dy,dx),7,.23);return;}
      if (d > 170 || n.timer < -2) n.state = 'walk';
    }else if(!['vigil','victim','response'].includes(n.routine)&&(Math.hypot(dx,dy)<8||n.stuck>.8||n.timer<-6)){
      const q=nextRoutine(g,n);n.tx=q.x;n.ty=q.y;n.timer=2.2+g.rand()*3;n.stuck=0;
    }
    if(n.state==='walk'){
      speed=n.routine==='stall'?25:32+n.mood*10;
      dx=n.tx-n.x;dy=n.ty-n.y;
    }
    if(n.state==='walk'||n.state==='flee'){
      const q=pedestrianRoute(g,n,{x:n.x+dx,y:n.y+dy});dx=q.x-n.x;dy=q.y-n.y;
    }
  } else {
    if (n.type === 'officer' && g.heat <= 0 && !n.indoor) { n.active = false; return; }
    if (n.type === 'officer' && !g.seen && !n.indoor) { dx = g.lastSeen.x - n.x; dy = g.lastSeen.y - n.y; }
    else { dx = p.x - n.x; dy = p.y - n.y; }
    const canSee = n.indoor ? g.roomLine(n,p) : g.city.line(n.x, n.y, p.x, p.y);
    if (!canSee && !n.indoor && n.stuck > .28) {
      if (!n.path || (n.routeTime || 0) < g.clock) {
        const aim=n.type==='officer'&&!g.seen?g.lastSeen:p;
        n.path=dist(n,aim)<390?localPath(g,n,aim,n.r,480):roadPath(n,aim,g.city.seed,g.city.style);n.routeIndex=0;n.routeTime=g.clock+2.4+(n.id%7)*.19;
      }
      let target = n.path[n.routeIndex];
      if (target && dist(n, target) < 19) target = n.path[++n.routeIndex];
      if (target) { dx = target.x - n.x; dy = target.y - n.y; }
    } else n.path = null;
    speed = d < 88 && canSee ? (d < 44 ? -28 : 10) : n.boss ? 95 : 72;
    if (n.indoor && g.stage()?.stealth && g.missionState.suspicion < 1) {
      speed = 30; dx = n.tx - n.x; dy = n.ty - n.y;
      if (Math.hypot(dx, dy) < 12) n.tx = n.tx < 360 ? 465 : 240;
    } else if (canSee && d < (n.boss ? 285 : 173) && n.cd <= 0 && (n.type !== 'officer' || g.seen || n.indoor)) {
      const allies=g.people.items.some(a=>a!==n&&a.active&&!a.dead&&a.shotPlan&&dist(n,a)<138);
      if(allies&&g.rand()<.68){n.cd=.18;return;}
      n.cd=(n.boss?.64:1.12)+g.rand()*.54;
      const a=Math.atan2(p.y-n.y,p.x-n.x)+(g.rand()-.5)*(n.boss?.12:.23), time=n.boss?.18:.30;
      n.shotPlan={angle:a,time,total:time};n.a=a;return;
    }
  }
  const [nx,ny]=separatePeople(g,n,dx,dy);
  if (Math.hypot(dx, dy) < 6) speed = 0;
  n.a = Math.atan2(ny, nx);
  if (speed !== 0) {
    const x = n.x, y = n.y, hit = g.move(n, nx * speed * dt, ny * speed * dt, n.r);
    if (hit) {
      n.stuck += dt;
      const sign = n.id % 2 ? 1 : -1;
      g.move(n, -ny * speed * dt * sign, nx * speed * dt * sign, n.r);
    } else n.stuck = Math.max(0, n.stuck - dt * 2);
    n.stride += Math.hypot(n.x - x, n.y - y) * .17;
  }
}

function startPunch(g,n,a,force,wind){
  n.a=a;n.cd=wind+.58;n.attack={angle:a,force,wind,time:0,total:wind+.28,done:false};g.hear('swish',n.x,n.y,.44);
}

function spawnLocal(g) {
  const p = g.player;
  const region=regionOf(p.x,p.y),local=region==='monsoon',quiet=region==='wilds',city=local||region==='mirage'||region==='basin',seed=g.city.seed,style=g.city.style;
  const carCap=g.settings.quality==='Low'?(city?18:14):(city?33:23);
  if(g.cars.length<carCap){
    const horizontal = g.rand() > .37;
    const direction = g.rand() > .5 ? 1 : -1;
    const jitter = 270 + g.rand() * 460;
    const lane=quiet||region==='mirage'||region==='basin'?8:21;
    const x=horizontal?p.x+(g.rand()>.5?jitter:-jitter):Math.round(p.x/CELL)*CELL-direction*lane+(g.rand()<.43?CELL*(g.rand()>.5?1:-1):0);
    const y=horizontal?Math.round(p.y/CELL)*CELL+direction*lane+(g.rand()<.43?CELL*(g.rand()>.5?1:-1):0):p.y+(g.rand()>.5?jitter:-jitter);
    const dir=horizontal?[direction,0]:[0,direction], a=horizontal?(direction>0?0:Math.PI):direction*Math.PI/2;
    const sets=local?[9,9,10,10,11,12,13,0,6,17]:region==='mirage'?[1,2,2,8,5,12,1,7]:region==='basin'?[2,3,3,1,6,0,13,8]:quiet?[5,12,4,0,17]:[0,1,2,3,4,5,6,7];
    const mdl=sets[Math.floor(g.rand()*sets.length)];
    if((!quiet||g.rand()<.37)&&!g.city.water(x,y)&&g.city.road(x,y)&&g.cars.every(v=>Math.hypot(v.x-x,v.y-y)>59)){
      const ix=horizontal?Math.floor(x/CELL):Math.round(x/CELL),iy=horizontal?Math.round(y/CELL):Math.floor(y/CELL);
      if((!local&&!quiet&&region==='harbor')||roadConnection(ix,iy,ix+(horizontal?1:0),iy+(horizontal?0:1),seed,style))addCar(g,mdl,x,y,a,'traffic',{cruise:mdl===9||mdl===17?42+g.rand()*31:72+g.rand()*57});
    }
  }
  const chunk = g.city.active[Math.floor(g.rand() * g.city.active.length)];
  if(!chunk||['pier','canal','flats','sea','salt','canyon'].includes(chunk.type)||quiet&&g.rand()>.23||Math.hypot(chunk.x+240-p.x,chunk.y+240-p.y)>930)return;
  const vendor=chunk.vendors?.length&&g.rand()>.4?chunk.vendors[Math.floor(g.rand()*chunk.vendors.length)]:null;
  const x = vendor?vendor.x:chunk.x + (g.rand() > .5 ? 57 : 421), y = vendor?vendor.y+11:chunk.y + 66 + g.rand() * 335;
  const crowd=g.people.items.filter(n=>n.active&&n.type==='ped').length,daytime=g.day>7&&g.day<20;
  const cap=quiet?8:city?(g.settings.quality==='Low'?42:69):daytime?33:24;
  const births=Math.max(1,Math.min(city?3:1,cap-crowd));
  for(let i=0;i<births;i++){
    const px=x+(i?(g.rand()-.5)*54:0),py=y+(i?(g.rand()-.5)*47:0);
    if(g.city.water(px,py)||g.city.block(px,py,8)||Math.hypot(px-p.x,py-p.y)<76)continue;
    const civilian=addPerson(g,'ped',px,py,{tx:px,ty:chunk.y+(g.rand()>.5?58:421),home:{x:px,y:py}});
    if(civilian){
      civilian.routine=vendor?'stall':daytime?'day':'night';civilian.outfit=(civilian.id+chunk.zone)%4;
      const team=g.territory[chunk.zone],disposition=factionDisposition(g,team);
      if(!vendor&&disposition!=='Neutral'&&civilian.id%5===0){civilian.team=team;civilian.outfit=2;civilian.color=disposition==='Allied'?'#acbea0':'#c294aa';}
    }
  }
  if (g.rand() < .3 && g.cars.filter(v => v.mode === 'parked').length < 7) {
    const ax = chunk.x + 222 + g.rand() * 190, ay = chunk.y + 63;
    if(!g.city.water(ax,ay)&&g.cars.every(v=>Math.hypot(v.x-ax,v.y-ay)>43)&&!g.city.block(ax,ay,12))addCar(g,local?[9,10,6,12][Math.floor(g.rand()*4)]:Math.floor(g.rand()*8),ax,ay);
  }
}

export function updateActors(g, dt) {
  if (g.room) {
    for (const n of g.people.items) if (n.active && n.indoor) pedestrian(g, n, dt);
    return;
  }
  const p = g.player;
  g.spawnTimer -= dt;
  if (g.spawnTimer <= 0 && g.mode!=='outbreak') { g.spawnTimer = .29; spawnLocal(g); }
  ambientPatrol(g,addCar);
  for (let i = g.cars.length - 1; i >= 0; i--) {
    const v = g.cars[i], d = dist(v, p);
    const activeSearch=isUnit(v)&&g.heat>0&&dist(v,g.lastSeen)<760&&d<1510;
    if (v !== g.car && !v.keep && (d > 1120&&!activeSearch || d > 660 && isUnit(v)&&v.mode!=='patrol'&&g.heat<=0 || v.discardAt&&v.discardAt<g.clock || v.wreck && v.wreckTime < g.clock)) { g.cars.splice(i, 1); continue; }
    v.contact -= dt; v.horn -= dt; v.smoke -= dt;
    if(v.door){v.door.time+=dt;if(v.door.time>=v.door.total)v.door=null;}
    if (v.wreck) continue;
    if (v.fire > 0) {
      v.fire -= dt;
      if (v.fire <= 0) {
        v.wreck = true; v.wreckTime = g.clock + 23;
        if (v === g.car) { g.exitCar(true); g.playerHurt(42); }
        g.explosion(v.x, v.y, 67, 'world'); continue;
      }
    }
    if (v.hp < v.model.hp * .4 && v.smoke <= 0 && d < 740) { v.smoke = .13; g.fx(v.x, v.y, v.fire > 0 ? '#f6976d' : '#898198', v.fire > 0 ? 4 : 2, 21, 'smoke'); }
    if (v !== g.car) {
      if (v.mode === 'traffic' || v.mode === 'runner') updateTraffic(g,v,dt);
      else if (isUnit(v)) driveUnit(g,v,dt,addPerson,hitCar);
    }
  }
  for (const n of g.people.items) {
    if (!n.active) continue;
    if(n.type==='infected'||n.type==='rival')continue;
    if (!n.keep && (n.indoor || dist(n, p) > 840)) { n.active = false; continue; }
    pedestrian(g, n, dt);
  }
}

export function updateWanted(g,dt) {
  updateDispatch(g,dt,addCar);
  if(g.car&&g.car.contact<=0&&g.car.alt<18)for(const b of g.blockade)if(dist(g.car,b)<18){
    const tires=!['TANK','TRACKED','BOAT'].includes(g.car.model.class),strip=b.kind==='spikes';
    g.car.vx*=strip?.67:.43;g.car.vy*=strip?.67:.44;g.car.contact=.55;
    if(strip&&tires){g.car.tireWear=1;g.hear('tire-pop',b.x,b.y,.72);}
    hitCar(g,g.car,strip?8:14);
    g.bump(4);g.fx(b.x,b.y,'#ffbd77',11,64);g.hear('hit',b.x,b.y);break;
  }
}

export function updateAmbient(g,dt){
  if(g.room||g.outbreak||g.practice)return;
  if(g.streetEvent){tickStreetEvents(g,dt,addPerson,hurtPerson);return;}
  g.eventTimer-=dt;
  if(g.eventTimer<=0){g.eventTimer=startStreetEvent(g,addCar,addPerson)?23+g.rand()*22:7;}
}
export function debugStreetEvent(g,id){return startStreetEvent(g,addCar,addPerson,id);}

export function savePos(item) { item.ox = item.x; item.oy = item.y; item.oa = mod(item.a + TAU, TAU); }