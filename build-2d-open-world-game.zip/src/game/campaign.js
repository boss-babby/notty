import { CAMPAIGN, DISTRICTS, JOBS, GARAGE, modelIndex, place } from './data.js';
import { dist, unit, clamp } from './core.js';
import { addCar, addPerson } from './actors.js';
import { districtOf, isWater, roadPath } from './world.js';
import { freeNear, landAt } from './navigation.js';
import { NEW_FACTIONS } from './atlas-data.js';

const endings = [
  'OPEN FREQUENCY / The city hears the tape. Vigils become hearings. Inez sends one final message: Thank you for not editing me out.',
  'PRIVATE CHANNEL / The archive stays sealed. The lights remain on, but the Wire keeps asking who paid for them.',
  'DEAD AIR / The private network falls silent. By morning, the docks are running their own radios again.',
];
const monsoonEndings=[
  'A RIVER HELD IN COMMON / The cooperative runs the landings. The late shift pays in tea, stories, and a few more seats on the last crossing.',
  'THE LAST FARE / The first municipal launch leaves at sunrise. Samira tears down the ticket board and posts a timetable in its place.',
];

const episodes=g=>g.campaign || CAMPAIGN;
const lastLines=g=>g.mode==='monsoon'?monsoonEndings:endings;
export const stageOf = g => episodes(g)[g.chapter]?.steps[g.step] || null;

export function newStage(g) {
  if (g.missionState?.actors) for (const n of g.missionState.actors) { n.keep = false; n.active = false; }
  if (g.missionState?.ride && g.missionState.ride !== g.car && !['deliver','clear'].includes(stageOf(g)?.kind)) {
    const old = g.missionState.ride; old.keep = false; if (old.mode === 'mission') old.mode = 'parked';
  }
  g.missionState = { actors: [], ride: null, started: false, progress: 0, clock: 0, suspicion: 0, seen: false, gate: 0, path: null };
  if(g.city.temporary?.length) {g.city.temporary=[];g.city.changed=true;}
}

export function marker(g) {
  const s = stageOf(g), m = g.missionState;
  if (!s) return null;
  if (g.room) return s.room === g.room ? { ...g.interior.service, label: s.label } : { ...g.interior.exit, label: 'Return to the street' };
  let point = s;
  if (s.kind==='take'&&s.approach && !g.player.swim) point=s.approach;
  else if (m.ride && (s.kind === 'pursue' || s.kind === 'take')) point = m.ride;
  else if (m.started && s.kind === 'escort') point = { x: s.tx, y: s.ty };
  else if (m.started && s.kind === 'race') { const [x, y] = s.gates[m.gate] || s.gates[0]; point = { x, y }; }
  else if(s.kind==='survey') {const [x,y]=s.nodes[m.gate]||s.nodes[0];point={x,y};}
  else if(s.kind==='clear'&&m.barriers?.find(p=>p.hp>0)) point=m.barriers.find(p=>p.hp>0);
  return { x: point.x, y: point.y, label: s.label };
}

function complete(g) {
  const list=episodes(g),mission = list[g.chapter];
  if (!mission) return;
  const previousRide = g.missionState.ride;
  g.step++;
  if (g.step >= mission.steps.length) {
    g.cash += mission.pay; g.stats.missions++; g.rep.Coil += 1; g.say(mission.end, 4.8);
    g.report(`${mission.title}: an overnight courier closes another open file.`);
    g.notify('Operation complete', `${mission.title}  /  +$${mission.pay}`, 'ok');
    g.chapter++; g.step = 0;
    if (list[g.chapter]) g.briefDelay = 4.8;
    else { g.report(endingLine(g)); g.finishDelay = 2.8; }
  } else {
    g.notify('Objective updated', list[g.chapter].steps[g.step].label);
  }
  newStage(g);
  if (['deliver','clear'].includes(stageOf(g)?.kind)) g.missionState.ride = previousRide;
  g.hear('confirm'); g.save(true);
}

function spawnHostiles(g, x, y, count, kind = 'enemy', boss = false) {
  const n = [];
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2 + .8;
    let px = x + Math.cos(a) * (106 + i * 15), py = y + Math.sin(a) * (91 + i * 11);
    for (let j = 0; j < 5 && g.city.block(px, py, 10); j++) { px = x + Math.cos(a + (j + 1) * 1.2) * 99; py = y + Math.sin(a + (j + 1) * 1.2) * 74; }
    if (g.city.block(px, py, 10)) { px = x + 54 + i * 14; py = y - 26; }
    const actor = addPerson(g, kind, px, py, { keep: true, hp: boss && i === 0 ? 207 : 56 + i * 3, color: boss && i === 0 ? '#fcd09b' : '#ea709b', boss: boss && i === 0, identity: boss && i === 0 ? 'ROOK' : null });
    if (actor) n.push(actor);
  }
  return n;
}

export function missionUse(g) {
  const s = stageOf(g), m = g.missionState;
  if (!s) return false;
  const p = g.player;
  if (s.kind === 'choice' && (s.room ? g.room === s.room && dist(p, g.interior.service) < 45 : !g.room && dist(p, s) < 48)) { g.open('choice'); return true; }
  if (s.kind === 'room' && g.room === s.room && dist(p, g.interior.service) < 44) {
    if (s.vault) { g.crime(g.bankBalance >= 80 ? .85 : 2.05, 'A silent alarm goes out from Vesper Trust.'); g.report('Vesper Trust confirms an item from the private vault is missing.'); }
    if (s.stealth && m.suspicion < 1) { g.skills.stealth += 4; g.rep.Coil += 1; }
    complete(g); return true;
  }
  if (g.room) return false;
  if (s.kind === 'use' && dist(p, s) < 42) { complete(g); return true; }
  if(s.kind==='survey'&&dist(p,marker(g))<44){
    m.gate++;g.hear('confirm');g.light(p.x,p.y,'#f7bb7a',45,.5);
    if(m.gate>=s.nodes.length)complete(g);else g.notify('Flood reader logged',`${m.gate} / ${s.nodes.length} readings saved`,'ok');
    return true;
  }
  if (s.kind === 'pursue' && m.ride && dist(p, m.ride) < 73 && (m.progress > .75 || m.ride.hp < 18)) {
    m.ride.mode = m.ride.wreck ? 'parked' : 'traffic'; complete(g); return true;
  }
  return false;
}

export function selectChoice(g, value) {
  const s = stageOf(g);
  if (!s?.options?.[value]) return;
  if(g.mode==='monsoon') {
    g.ending=value;
    if(value===0)g.cash+=225;
    g.open(null);complete(g);return;
  }
  if (g.chapter === 8) { g.rook = value; if (!value) { g.rep.Prism += 3; g.report('Rook disappears from the private grid roster.'); } else { g.rep.Coil += 2; g.cash += 175; } }
  if (g.chapter === 9) {
    g.ending = value;
    if (value === 2) g.useRelay(g.player, true);
    if (value === 1 && g.rook === 1) g.cash += 420;
  }
  g.open(null); complete(g);
}

export function updateMission(g, dt) {
  const s = stageOf(g), m = g.missionState, p = g.player;
  const list=episodes(g);
  if (g.briefDelay > 0) { g.briefDelay -= dt; if (g.briefDelay <= 0 && list[g.chapter]) g.say(list[g.chapter].brief, 7.4); }
  if (g.finishDelay > 0) { g.finishDelay -= dt; if (g.finishDelay <= 0) g.open('ending'); }
  if (!s) return;
  if (g.room) {
    if (s.room === g.room && s.stealth) {
      const close = m.actors.some(n => n.active && !n.dead && dist(n, p) < 106 && g.roomLine(n,p));
      m.suspicion = clamp(m.suspicion + dt * (close && !p.cover ? .58 : -.31), 0, 1.03);
      if (m.suspicion >= 1 && !m.seen) { m.seen = true; g.crime(1.1, 'Bank security reports an intruder.'); g.notify('Cover blown', 'Finish the transfer and get outside.', 'warn'); }
      if (m.seen) m.suspicion = 1.03;
    }
    return;
  }
  const d = dist(s, p);
  if (s.kind === 'reach' && d < 47) {complete(g);return;}
  if (s.kind === 'evade' && g.heat === 0 && d < (g.chapter === 9 ? 133 : 95)) complete(g);
  if ((s.kind === 'take' || s.kind === 'pursue') && (!m.ride || s.kind === 'take' && m.ride.wreck) && d < 590) {
    const id = GARAGE.findIndex(v => v.id === s.model);
    const docked=s.model==='launch'?g.cars.find(v=>v.publicLaunch&&dist(s,v)<72&&!v.wreck):null;
    m.ride = docked || addCar(g, id, s.x, s.y, s.angle||0, s.kind === 'take' ? 'mission' : 'runner', { keep: true, driver: s.kind !== 'take', owned: s.kind === 'take', color: s.kind === 'pursue' ? '#84b5e3' : GARAGE[id].color });
    if(docked)docked.a=s.angle||0;
  }
  if (s.kind === 'take' && g.car && g.car === m.ride) {complete(g);return;}
  if (s.kind === 'pursue' && m.ride) {
    const distance = dist(m.ride, p);
    m.progress = clamp(m.progress + dt * (distance < 86 ? 1 : -.65), 0, 3.2);
    if (m.progress > 3.1 && distance < 90) complete(g);
    else if (distance > 1240) { m.ride.keep = false; m.ride = null; m.progress = 0; g.notify('Courier signal reset', 'Head back to the last tag location.'); }
  }
  if (s.kind === 'deliver') {
    if (!m.ride || m.ride.wreck) {
      const pickup = list[g.chapter].steps[0];
      if (!m.ride) m.ride = g.cars.find(v => v.model.id === pickup.model && v.keep && !v.wreck) || addCar(g, modelIndex(pickup.model), pickup.x, pickup.y, pickup.angle||0, 'mission', { keep: true, owned: true });
      else { g.step = 0; newStage(g); g.notify('Freight lost', 'A replacement van is on its way.', 'warn'); }
    }
    if (g.car && g.car === m.ride && d < 65) complete(g);
  }
  if(s.kind==='clear') {
    const pickup=list[g.chapter].steps[0];
    if(!m.ride)m.ride=g.cars.find(v=>v.model.id===s.model&&v.keep&&!v.wreck)||addCar(g,modelIndex(s.model),pickup.x,pickup.y,0,'mission',{owned:true,keep:true});
    if(m.ride.wreck){g.step=0;newStage(g);g.notify('Rig out of service','A replacement is waiting at the start of the yard.','warn');return;}
    if(!m.barriers&&d<450){
      m.barriers=s.nodes.map(([x,y],i)=>({x:x-5,y:y-12,w:10,h:24,hp:34,id:`works-foam-${i}`,kind:'foam',type:'prop',mission:true}));
      g.city.temporary=m.barriers;g.city.changed=true;
    }
    if(m.barriers?.every(b=>b.hp<=0)&&dist(g.player,s)<300){complete(g);return;}
  }
  if (s.kind === 'escort') {
    if (!m.started && d < 65 && !g.car) {
      m.started = true;
      m.ally = addPerson(g, 'ally', s.x - 16, s.y - 12, { keep: true, identity: 'INEZ', color: '#86dcc8' });
      m.path = [...roadPath(s, { x: s.tx, y: s.ty }), { x: s.tx, y: s.ty }];
      m.actors = [m.ally, ...spawnHostiles(g, s.x, s.y - 110, 3)].filter(Boolean);
      g.say({ speaker: 'Inez Sable', line: 'Stay a block ahead. I can move when you give me room.' });
    }
    if (m.ally) {
      const a = m.ally, target = m.path[m.gate];
      if (target && dist(a, p) < 270) {
        const [nx, ny] = unit(target.x - a.x, target.y - a.y);
        a.a = Math.atan2(ny, nx); a.stride += dt * 12;
        g.move(a, nx * 98 * dt, ny * 98 * dt, a.r, true);
        if (dist(a, target) < 23) m.gate++;
      }
      if ((!target || dist(a, { x: s.tx, y: s.ty }) < 27) && dist(a, p) < 190) complete(g);
    }
  }
  if (s.kind === 'defend') {
    if (d < 105 && !m.started) { m.started = true; m.actors = spawnHostiles(g, s.x, s.y, 3); g.focusAt(s.x, s.y, 1.4); }
    if (m.started && d < 179) {
      m.clock += dt;
      if (m.clock > 9 && !m.wave) { m.wave = true; m.actors.push(...spawnHostiles(g, s.x - 48, s.y, 2)); }
      if (m.clock >= s.duration) complete(g);
    }
  }
  if (s.kind === 'boss') {
    if (d < 126 && !m.started) { m.started = true; m.actors = spawnHostiles(g, s.x + 26, s.y, 4, 'enemy', true); g.focusAt(s.x + 37, s.y + 12, 1.7); }
    if (m.started && m.actors.every(n => n.dead || !n.active)) complete(g);
  }
  if (s.kind === 'race') {
    if (d < 82 && g.car && g.car.model.class!=='BOAT' && !m.started) { m.started = true; m.clock = s.duration; if(!s.quiet)g.crime(1.05, 'Grid units are closing the coast lanes.'); g.hear('confirm'); }
    if (m.started) {
      m.clock -= dt;
      const [x, y] = s.gates[m.gate];
      if (g.car && Math.hypot(p.x - x, p.y - y) < 64) { g.hear('confirm'); m.gate++; if (m.gate >= s.gates.length) { complete(g); return; } }
      if (m.clock <= 0) { newStage(g); g.notify('Run expired', 'Return to the first gate to retry.', 'warn'); }
    }
  }
}

export function startJob(g, id) {
  const job = JOBS.find(v => v.id === id);
  if (!job) {
    if(g.job?.ride)g.job.ride.keep=false;
    if(g.job?.towCar){g.job.towCar.keep=false;g.job.towCar.towed=false;}
    if(g.job?.ride?.tow)g.job.ride.tow=null;
    if(g.job?.actors)for(const n of g.job.actors){n.keep=false;n.active=false;}
    g.job=null;return;
  }
  if (g.job?.id === id) { g.open(null); return; }
  if (job.kind === 'point') { const [x, y] = job.nodes[0]; g.setWaypoint(x, y); g.open(null); return; }
  startJob(g, '');
  g.job = { ...job, idx: 0, clock: 0, started: false, ride: null, actors: [] };
  g.notify('Contract accepted', job.name);
  if(g.room){g.setRoom(null);g.open(null);}else g.open(null);
}

export function jobMarker(g) {
  if (g.room || !g.job) return null;
  const j = g.job;
  if(j.kind==='recover'&&j.idx===1&&j.courier)return {x:j.courier.x,y:j.courier.y,label:j.courier.dead?'Pick up the parcel':'Recover the missing parcel'};
  if (j.kind==='service'&&j.ride&&!j.ride.wreck&&g.car!==j.ride)return {x:j.ride.x,y:j.ride.y,label:`Collect the ${j.ride.model.name}`};
  if (j.kind==='vigilante'&&j.ride&&!j.ride.wreck) return { x: j.ride.x, y: j.ride.y, label: j.name };
  if (j.nodes[j.idx]) {
    const [x, y] = j.nodes[j.idx];
    const label=j.kind==='service'?j.flight?'Survey gate':j.tow?j.idx===1?'Hook the disabled sedan':'Return to the service bay':j.vehicle==='megh'?'Board at the marked stop':j.idx<3?'Collect the waiting patient':'Drop passengers at St. Echo':j.kind==='photo'?'Frame the marked landmark':j.kind==='recover'?(j.idx===0?'Check the market stall':j.idx===1?'Pick up the parcel':'Return the parcel to the stall'):j.name;
    return { x, y, label };
  }
  return null;
}

function finishJob(g) {
  const j = g.job;
  if (!j) return;
  const time=Math.max(0,Math.round((j.time||47)-(j.clock||0)));
  const rec=g.records?.[j.id]||{best:0,plays:0,wins:0};
  if(g.records)g.records[j.id]={plays:rec.plays+1,wins:rec.wins+1,best:Math.max(rec.best,time||j.pay)};
  g.cash += j.pay; g.stats.jobs++; g.notify('Contract paid', `${j.name}  /  +$${j.pay}`, 'ok'); g.report(`${j.name} operator posts an overnight payout.`);
  startJob(g, ''); g.hear('confirm'); g.save(true);
}

export function jobUse(g) {
  if (g.room || !g.job) return false;
  const j = g.job, point = jobMarker(g);
  if (!point || dist(point, g.player) > 56) return false;
  if(j.kind==='recover'){
    if(j.idx===0){j.idx=1;j.clock=63;j.started=true;g.notify('Stall alarm','A runner took off with the parcel. Follow the mint marker.','warn');g.report('A market stall reports a missing delivery.');g.hear('confirm');return true;}
    if(j.idx===1&&j.courier&&dist(j.courier,g.player)<45){j.courier.active=false;j.idx=2;g.notify('Parcel recovered','Return it to the market stall.','ok');g.hear('confirm');return true;}
    if(j.idx===2){finishJob(g);return true;}
  }
  if(j.kind==='service'&&j.ride&&g.car===j.ride&&j.idx>0&&!j.flight){
    if(g.car.speed>42){g.notify('Slow down','Come to a stop to use the checkpoint.','warn');return true;}
    if(j.tow&&j.idx===1){
      if(!j.towCar)return false;
      j.towCar.towed=true;g.car.tow=j.towCar;
      g.notify('Tow line attached','Bring the sedan back to Sable Motorworks.','ok');
    }else if(j.tow&&!g.car.tow){g.notify('Towed car missing','Return to hook the disabled sedan.','warn');j.idx=1;return true;}
    else g.notify(j.vehicle==='megh'?'Passengers boarded':'Patient aboard',j.idx<j.nodes.length-1?'Continue to the next marked stop.':'Shift complete.','ok');
    j.idx++;j.wait=.47;g.hear('confirm');
    if(j.idx>=j.nodes.length)finishJob(g);
    return true;
  }
  if (j.kind === 'delivery' || j.kind === 'taxi' && g.car) {
    if(j.models&&!j.models.includes(g.car.model.id)){g.notify('Wrong ride','Use a cycle rickshaw or CNG to take this fare.','warn');return true;}
    j.idx++;
    if (j.idx >= j.nodes.length) finishJob(g); else g.notify('Destination set', 'Follow the mint marker to the drop-off.');
    return true;
  }
  if (j.kind === 'catalog' && g.car && ['havoc', 'ibis', 'moth'].includes(g.car.model.id)) {
    if (g.imports.includes(g.car.model.id)) { g.notify('Already listed', 'This model is on your import list.'); return true; }
    g.imports.push(g.car.model.id); g.notify('Import registered', `${g.imports.length} of 3 models`, 'ok');
    if (g.imports.length >= 3) { g.imports = []; finishJob(g); } else g.save(true);
    return true;
  }
  return false;
}

export function recordStreetPhoto(g) {
  const j=g.job, point=jobMarker(g);
  if(!j||j.kind!=='photo'||!point||g.room||dist(g.player,point)>108)return false;
  const ray=g.car?g.car.a:g.player.a;
  if(dist(g.player,point)>18&&Math.abs(Math.atan2(Math.sin(Math.atan2(point.y-g.player.y,point.x-g.player.x)-ray),Math.cos(Math.atan2(point.y-g.player.y,point.x-g.player.x)-ray)))>1.31){
    g.notify('Landmark out of frame','Face the green photo marker before capturing.','warn');return false;
  }
  j.idx++;g.hear('confirm');
  if(j.idx>=j.nodes.length)finishJob(g);
  else g.notify('Photo accepted',`${j.idx} / ${j.nodes.length} landmarks documented.`,'ok');
  return true;
}

export function contractStatus(g){
  const j=g.job;if(!j)return '';
  if(j.kind==='photo')return `PHOTO WALK / ${j.idx} OF ${j.nodes.length}`;
  if(j.kind==='recover'&&j.started)return `RECOVERY / ${Math.max(0,Math.ceil(j.clock))}s`;
  if(j.kind==='turf')return j.started?`DISTRICT HOLD / ${Math.min(100,Math.round(j.progress/19*100))}%`:'DISTRICT HOLD / REACH THE RELAY';
  if(j.kind==='service')return j.started?`SHIFT / ${Math.min(j.idx,j.nodes.length-1)} OF ${j.nodes.length-1} / ${Math.max(0,Math.ceil(j.clock))}s`:`SHIFT / COLLECT ${GARAGE[modelIndex(j.vehicle)]?.name.toUpperCase()}`;
  return '';
}

export function updateJob(g, dt) {
  const j = g.job, point = jobMarker(g), p = g.player;
  if (!j || !point) return;
  const d = dist(p, point);
  if(j.kind==='turf'){
    if(!j.started&&d<75&&!g.car){
      j.started=true;j.progress=0;j.clock=48;j.actors=spawnHostiles(g,point.x,point.y,3,'enemy',false);
      g.notify('Relay contested',`${j.rival} is trying to take the zone.`,'warn');g.hear('click');
    }
    if(!j.started)return;
    j.clock-=dt;
    if(d>195)j.progress=Math.max(0,j.progress-dt*.28);
    else j.progress+=dt*(j.actors.some(a=>a.active&&!a.dead&&dist(a,point)<155)?.57:1.14);
    const online=j.progress>=19;
    if(!online&&j.clock>0)return;
    const zone=districtOf(point.x,point.y),name=DISTRICTS[zone].name;
    const factions={'Coil Union':'Coil','Prism Crew':'Prism','River Cooperative':'River','Verge Works':'Verge',...NEW_FACTIONS};
    g.territory[zone]=online?j.side:j.rival;
    if(online){const k=factions[j.side];g.rep[k]=(g.rep[k]||0)+2.1;g.report(`${j.side} now holds the relay in ${name}.`);finishJob(g);g.notify('District secured',`${name} / ${g.territory[zone]}`,'ok');}
    else{g.report(`${j.rival} claims the contested relay in ${name}.`);startJob(g,'');g.notify('Hold lost',`${name} / ${g.territory[zone]}`,'warn');g.save(true);}
    return;
  }
  if(j.kind==='recover'&&j.started){
    j.clock-=dt;
    if(j.clock<=0){startJob(g,'');g.notify('Shift expired','The parcel was taken off the route.','warn');return;}
    if(j.idx===1&&!j.courier&&d<440){
      const pos=freeNear(g,point,9,65);
      if(pos){j.courier=addPerson(g,'ped',pos.x,pos.y,{state:'flee',timer:6.8,keep:true,routine:'parcel',fearAt:{x:p.x,y:p.y},identity:'PARCEL',color:'#a6c4a5'});if(j.courier)j.actors.push(j.courier);}
    }
  }
  if (j.kind === 'race') {
    if (d < 55 && g.car) { if (!j.started) { j.started = true; j.clock = j.time||47; } j.idx++; g.hear('confirm'); if (j.idx >= j.nodes.length) { finishJob(g); return; } }
    if (j.started) { j.clock -= dt; if (j.clock <= 0) { j.started = false; j.idx = 0; g.notify('Circuit reset', 'Return to the start gate.', 'warn'); } }
  }
  if (j.kind === 'stunt' && g.car && g.car.speed > 170 && d < 40) { g.jump = .75; g.bump(4); finishJob(g); }
  if (j.kind === 'arena') {
    if (!j.started && d < 110 && !g.car) { j.started = true; j.actors = spawnHostiles(g, point.x, point.y, 5); }
    if (j.started && j.actors.every(n => n.dead || !n.active)) finishJob(g);
  }
  if (j.kind === 'vigilante') {
    if (!j.ride && d < 530) j.ride = addCar(g, 3, point.x, point.y, 0, 'runner', { runnerSpeed: 108, keep: true, driver: true });
    if (j.ride && (j.ride.wreck || j.ride.hp < 5)) finishJob(g);
  }
  if(j.kind==='service'){
    j.wait=Math.max(0,(j.wait||0)-dt);
    if(!j.ride&&d<480){
      const q=freeNear(g,point,15,65);
      if(q)j.ride=addCar(g,modelIndex(j.vehicle),q.x,q.y,0,'job',{owned:true,keep:true,job:true});
    }
    if(j.ride?.wreck||j.started&&j.clock<=0){
      if(g.car===j.ride)g.exitCar(true);
      startJob(g,'');g.notify('Shift ended','Accept the contract again to retry.','warn');return;
    }
    if(!j.started&&g.car&&g.car===j.ride){
      j.started=true;j.idx=1;j.clock=j.time;g.hear('confirm');return;
    }
    if(j.started)j.clock-=dt;
    if(j.tow&&j.idx===1&&d<410&&!j.towCar){
      const q=freeNear(g,point,15,75);
      if(q)j.towCar=addCar(g,1,q.x,q.y,0,'parked',{hp:39,keep:true,color:'#ab9f91'});
    }
    if(j.ride?.tow){
      const v=j.ride,a=v.tow,x=v.x-Math.cos(v.a)*47,y=v.y-Math.sin(v.a)*47;
      if(landAt(g,x,y,a.r)&&!isWater(x,y)){a.x+=(x-a.x)*Math.min(1,dt*5);a.y+=(y-a.y)*Math.min(1,dt*5);a.a=v.a;}
    }
    if(j.flight&&j.started&&g.car===j.ride&&d<(j.idx===j.nodes.length-1?69:62)&&j.wait<=0){
      if(j.idx===j.nodes.length-1){if((j.ride.alt||0)<14)finishJob(g);}
      else if((j.ride.alt||0)>23){j.idx++;j.wait=.33;g.hear('confirm');}
    }
  }
}

export const endingLine = g => lastLines(g)[g.ending] || lastLines(g)[0];
export const objectivePlace = s => s?.room ? place(s.room) : null;