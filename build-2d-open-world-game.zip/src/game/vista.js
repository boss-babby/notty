import { rng } from './core.js';

const W = 672, H = 360;

// The title vista is painted in a low-resolution buffer so every edge stays on the pixel grid.
export function mountVista(canvas, motion = true) {
  canvas.width = W; canvas.height = H;
  const c = canvas.getContext('2d', { alpha: false });
  if (!c) return () => {};
  const surface = document.createElement('canvas');
  surface.width = W; surface.height = H;
  const g = surface.getContext('2d');
  const rand = rng(991433);
  const r = (min, max) => Math.floor(min + rand() * (max - min + 1));
  const box = (x, y, w, h, s) => { g.fillStyle = s; g.fillRect(Math.floor(x), Math.floor(y), Math.floor(w), Math.floor(h)); };
  const poly = (color, ...points) => {
    // Integer scan conversion avoids blurred edges on diagonals.
    const ys = points.filter((_, i) => i % 2);
    g.fillStyle = color;
    for (let y = Math.floor(Math.min(...ys)); y < Math.max(...ys); y++) {
      const line = y + .5, cuts = [];
      for (let i = 0; i < points.length; i += 2) {
        const j = (i + 2) % points.length, a = points[i + 1], b = points[j + 1];
        if ((a <= line && b > line) || (b <= line && a > line)) cuts.push(points[i] + (points[j] - points[i]) * (line - a) / (b - a));
      }
      cuts.sort((a, b) => a - b);
      for (let i = 0; i < cuts.length - 1; i += 2) g.fillRect(Math.round(cuts[i]), y, Math.round(cuts[i + 1]) - Math.round(cuts[i]), 1);
    }
  };
  const line = (x, y, tx, ty, color, w = 1) => {
    const steps = Math.max(Math.abs(tx - x), Math.abs(ty - y), 1);
    for (let i = 0; i <= steps; i++) box(Math.round(x + (tx - x) * i / steps), Math.round(y + (ty - y) * i / steps), w, w, color);
  };
  const halo = (x, y, radius, color) => {
    const grad = g.createRadialGradient(x, y, 0, x, y, radius);
    grad.addColorStop(0, color); grad.addColorStop(1, 'transparent');
    g.fillStyle = grad; g.fillRect(x - radius, y - radius, radius * 2, radius * 2);
  };

  const sky = g.createLinearGradient(0, 2, 0, 222);
  ['#1b112c', '#342044', '#573052', '#8f3d5c', '#bd5868', '#e67b72'].forEach((s, i) => sky.addColorStop(i / 5, s));
  box(0, 0, W, H, sky);
  halo(487, 131, 190, '#ed5c6962');
  for (let i = 0; i < 2590; i++) {
    const x = r(0, W), y = r(0, 218);
    box(x, y, r(1, 3), 1, rand() < .53 ? '#ec92ac12' : '#180e2c20');
  }
  for (let i = 0; i < 96; i++) {
    const x = r(194, 665), y = r(3, 99);
    box(x, y, rand() > .91 ? 2 : 1, 1, rand() > .66 ? '#da8ba990' : '#b981ac59');
  }
  const clouds = [
    [49,66,196,7], [134,55,149,5], [241,28,153,10], [293,49,128,8], [531,36,155,10], [579,65,113,6], [524,93,149,6],
    [18,116,228,9], [227,114,119,6], [101,136,200,11], [278,150,119,7], [508,141,182,6], [539,164,111,7],
  ];
  for (const [x, y, w, h] of clouds) {
    poly(y > 90 ? '#49234476' : '#2015336c', x, y + h, x + 16, y + h - 3, x + 37, y + h - 4, x + 58, y, x + w - 23, y + 1, x + w, y + h - 2, x + w + 37, y + h, x, y + h);
    box(x + 24, y + h, w - 23, 1, '#f1889b3b'); box(x + 59, y + h + 3, w - 35, 1, '#43244768');
    box(x + 13, y + h + 5, Math.floor(w * .33), 1, '#c774874e');
  }

  const sunX = 495, sunY = 134, radius = 87;
  halo(sunX, sunY, 141, '#ff9a673d');
  for (let y = sunY - radius; y < sunY + radius; y++) {
    const rel = y - sunY, d = Math.sqrt(radius ** 2 - rel ** 2);
    if (y > 135 && ((y - 135) % 13 >= (y > 186 ? 6 : 9))) continue;
    const t = (y - (sunY - radius)) / (radius * 2);
    box(Math.ceil(sunX - d), y, Math.floor(d * 2), 1, `rgb(255 ${Math.round(171 - 89 * t)} ${Math.round(119 - 18 * t)})`);
    if (y % 3 === 1) box(Math.ceil(sunX - d), y, Math.floor(d * 2), 1, '#e9656930');
  }
  for (let i = 0; i < 14; i++) {
    const y = r(77, 196), x = r(358, 532), length = r(12, 87);
    box(x, y, length, 1, i % 3 === 0 ? '#7f3f6243' : '#a64e684c');
  }

  poly('#713853', 0, 216, 0, 185, 37, 174, 62, 176, 95, 165, 123, 168, 155, 156, 177, 154, 218, 167, 241, 161, 279, 171, 301, 164, 350, 192, 399, 204, 459, 190, 484, 173, 533, 160, 577, 155, 613, 172, 672, 161, 672, 221);
  poly('#542c4b', 0, 218, 0, 199, 79, 192, 101, 187, 148, 193, 183, 179, 220, 185, 243, 176, 290, 182, 327, 194, 379, 184, 414, 200, 451, 192, 501, 192, 541, 179, 587, 172, 649, 184, 672, 179, 672, 223);

  function tower(x, y, w, type = 0, level = 0) {
    const base = level ? 224 : 218;
    const face = level ? '#221a31' : '#3e2745', side = level ? '#331e37' : '#52314b';
    const tilt = Math.max(3, Math.floor(w / 5));
    box(x, y, w, base - y, face);
    poly(side, x + w - tilt, y, x + w + 1, y + 3, x + w + 1, base, x + w - tilt, base);
    box(x, y, w - 2, 1, level ? '#865065' : '#8b485e');
    if (type === 1 || type === 3) {
      box(x + 3, y - 5, w - 7, 5, face); box(x + 4, y - 6, w - 9, 1, '#9b5565');
      box(x + 7, y - 9, w - 14, 3, face);
    }
    if (type === 2 || type === 3) {
      const ax = x + Math.floor(w / 2) - 3;
      box(ax, y - 17, 1, 17, '#42243e'); box(ax - 1, y - 18, 3, 1, '#f77f78');
      box(ax - 4, y - 12, 8, 1, '#452741'); box(ax + 5, y - 8, 1, 8, '#543047');
    }
    const palette = level ? ['#e87983', '#ffb173', '#7e586c', '#4e405b', '#85adb0', '#9c5472'] : ['#b57980', '#c27a7d', '#a15b71', '#925773'];
    const spacing = w > 22 ? 5 : 4;
    for (let yy = y + 5; yy < base - 3; yy += 5) {
      if (type === 1 && yy % 15 < 5) box(x + 1, yy + 2, w - 2, 1, '#8c53694c');
      for (let xx = x + 3; xx < x + w - 2; xx += spacing) {
        if (rand() < (level ? .38 : .48)) box(xx, yy, type === 1 ? 3 : 2, rand() > .28 ? 1 : 2, palette[r(0, palette.length - 1)]);
      }
    }
    if (level && type === 3 && w > 17) {
      box(x + 2, y + 15, 2, 21, '#7b3a60'); box(x + 2, y + 16, 1, 17, '#f46283');
      box(x + 3, y + 13, 8, 1, '#fa7c8f');
    }
  }

  let x = 23;
  while (x < W) {
    const w = r(8, 20); tower(x, r(167, 211), w, r(0, 2)); x += w + r(2, 8);
  }
  const skyline = [
    [8,202,27,0],[32,190,32,1],[69,174,22,0],[95,193,22,1],[126,170,18,1],[152,156,28,2],[179,180,30,0],
    [213,159,23,1],[247,180,22,0],[276,144,24,2],[313,164,18,0],[332,147,23,1],[358,119,27,3],
    [389,154,25,1],[425,171,21,0],[449,148,27,1],[485,177,29,0],[532,136,21,2],[554,115,30,3],
    [588,152,18,1],[604,171,24,0],[633,144,28,3],[658,168,30,1],
  ];
  for (const args of skyline) tower(...args, 1);

  function crane(x, y, reach) {
    const ink = '#2d2035';
    box(x, y, 3, 74, ink); box(x + 6, y + 5, 1, 66, '#572f49');
    line(x - 13, y + 15, x + reach, y + 15, ink); line(x - 12, y + 20, x + reach, y + 20, ink);
    line(x, y, x + reach - 3, y + 15, ink); line(x, y, x - 12, y + 15, ink);
    for (let u = x - 11; u < x + reach - 5; u += 6) line(u, y + 16, u + 5, y + 20, '#382139');
    for (let v = y + 23; v < y + 72; v += 8) line(x + 2, v, x + 6, v + 6, ink);
    box(x + reach - 8, y + 19, 1, 26, ink); box(x + reach - 8, y + 45, 4, 2, '#74374f');
    box(x - 1, y - 1, 3, 1, '#ffad85');
  }
  crane(304, 156, 44); crane(622, 162, 42);
  box(0, 219, W, 9, '#211a2e'); box(0, 221, W, 2, '#4d3046'); box(0, 226, W, 1, '#d37a78');
  for (let i = 0; i < 92; i++) box(r(0, W), r(219, 226), r(1, 4), 1, ['#6a536a','#fd9c85','#b55c74','#537883'][r(0, 3)]);

  const water = g.createLinearGradient(0, 227, 0, 304);
  water.addColorStop(0, '#663549'); water.addColorStop(.48, '#39243e'); water.addColorStop(1, '#231b35');
  box(0, 227, W, 83, water);
  for (let i = 0; i < 1780; i++) {
    const y = r(228, 297), xx = r(-18, W), perspective = (y - 223) / 70;
    const hot = Math.abs(xx - 497) < 49 + 35 * perspective && rand() < .57;
    const shades = hot ? ['#f480792f','#e3687a56','#ae4b666f','#fd99754b'] : ['#70456a66','#a8587251','#1211278a','#aa658634','#7b78a136'];
    box(xx, y, r(1, 9) + perspective * r(1, 20), 1, shades[r(0, shades.length - 1)]);
  }
  for (const xx of [363, 428, 489, 542, 560, 608, 640]) {
    for (let yy = 227; yy < 273; yy += r(1, 4)) {
      const span = (yy - 225) / 4;
      box(xx + r(-span, span), yy, r(1, span + 4), 1, yy % 9 === 0 ? '#ffc18e84' : '#e7737b64');
    }
  }

  poly('#141121', 0, 267, 191, 270, 389, 269, 569, 248, 672, 245, 672, 360, 0, 360);
  poly('#282031', 0, 269, 191, 274, 389, 273, 569, 254, 672, 250, 672, 360, 0, 360);
  poly('#3d293d', 0, 270, 191, 274, 389, 273, 567, 254, 671, 250, 671, 253, 567, 258, 389, 279, 191, 279, 0, 273);
  poly('#ab5462', 342, 276, 396, 273, 567, 253, 672, 248, 672, 249, 567, 255, 392, 275);
  poly('#171625', 0, 314, 396, 295, 572, 268, 672, 260, 672, 360, 0, 360);
  poly('#2c2031', 247, 360, 366, 327, 615, 276, 672, 274, 672, 360);
  for (let i = 0; i < 1980; i++) {
    const xx = r(0, W), yy = r(267, H), cutoff = xx > 389 ? 273 - (xx - 389) / 12 : 275;
    if (yy < cutoff) continue;
    const lit = Math.abs(xx - (505 - (yy - 288) * .55)) < 103;
    const colors = lit ? ['#ed5c7e30','#73537758','#63416852','#b046624f','#9d526957','#532d4790','#1716279f'] : ['#603f6066','#4c3e5455','#2a2948','#14121ee0','#86729140'];
    box(xx, yy, r(1, 8) + (yy - 259) / 9, 1, colors[r(0, colors.length - 1)]);
  }
  poly('#71505e', 304, 360, 384, 333, 427, 324, 414, 330, 337, 360);
  poly('#362b40', 302, 360, 384, 335, 413, 329, 355, 353, 337, 360);
  poly('#986068', 577, 298, 606, 288, 633, 284, 618, 291, 590, 298);
  poly('#6e4c5f', 646, 282, 665, 277, 672, 276, 672, 279, 652, 282);
  box(0, 264, 348, 2, '#26172b'); box(0, 274, 347, 2, '#1b1628');
  for (let px = 19; px < 356; px += 37) { box(px, 260, 3, 25, '#21172a'); box(px + 2, 262, 1, 14, '#734255'); }

  function lamp(px, py, tall) {
    box(px, py - tall, 2, tall, '#181326'); box(px + 2, py - tall + 2, 1, tall - 2, '#865064');
    poly('#23172a', px, py - tall + 4, px + 3, py - tall - 2, px + 14, py - tall - 2, px + 21, py - tall + 1, px + 20, py - tall + 4);
    box(px + 13, py - tall + 3, 8, 2, '#f9bb88'); box(px + 15, py - tall + 3, 5, 1, '#ffe3b7');
    halo(px + 16, py - tall + 6, 21, '#ffaf7433'); halo(px + 15, py + 3, 19, '#f4766627');
  }
  lamp(351, 269, 42); lamp(574, 252, 34);

  // A foreground palm and pier cables frame the skyline without obscuring the car.
  poly('#160f22', 646, 283, 640, 224, 634, 185, 625, 156, 613, 137, 616, 130, 630, 149, 642, 181, 650, 222, 658, 283);
  poly('#57304a', 646, 266, 640, 222, 634, 185, 624, 148, 628, 151, 637, 183, 644, 217, 651, 266);
  for (let yy = 170; yy < 266; yy += 7) {
    const xx = yy < 190 ? 633 + (yy - 184) / 3 : 635 + (yy - 190) / 5;
    line(xx, yy, xx + 5, yy - 2, '#865063');
  }
  const fronds = [
    [611,135,590,117,559,111,536,118,567,116,581,124,553,130,585,126,601,135],
    [611,136,591,100,570,91,558,91,573,98,591,114,582,111,604,143],
    [615,136,621,101,615,83,606,74,611,91,611,104,603,93,609,124],
    [614,138,635,107,652,95,672,92,651,102,644,114,663,106,636,130],
    [615,135,647,123,672,125,672,133,648,130,663,141,640,135,627,142],
    [612,137,584,142,565,166,561,185,571,169,582,161,573,179,592,160,609,149],
    [618,137,641,148,659,168,672,184,648,167,650,181,636,157,619,150],
  ];
  for (const pts of fronds) poly('#171222', ...pts);
  line(614, 138, 586, 121, '#4f2a45'); line(614, 136, 638, 113, '#593048'); line(610, 142, 578, 160, '#38223b');
  box(666, 175, 4, 91, '#191323'); box(664, 178, 9, 2, '#311c32');
  line(667, 181, 640, 191, '#412740'); line(640, 191, 615, 192, '#412740');

  // Vanta GT: tires and cast shadow, then rear plane, rear glass, roof and side facets.
  poly('#0e0c19', 344, 332, 354, 320, 431, 306, 566, 293, 608, 307, 599, 327, 546, 344, 467, 353, 386, 351);
  poly('#120f20', 356, 321, 405, 318, 418, 334, 412, 350, 398, 355, 365, 351, 357, 343);
  poly('#0d0c18', 533, 304, 578, 283, 595, 282, 602, 297, 601, 315, 591, 327, 574, 331, 558, 326);
  halo(455, 339, 101, '#fc486332'); halo(567, 328, 55, '#fc4d7725');
  for (let j = 0; j < 135; j++) {
    const xx = r(334, 593), yy = r(318, 359);
    if (yy < 351 - (xx - 355) / 9 || rand() < (yy - 318) / 77) continue;
    box(xx, yy, r(2, 19), 1, ['#f84f766d', '#c045657b', '#8b3c5c9c', '#ff746b57', '#bf4b7d72'][r(0,4)]);
  }
  poly('#25182d', 350, 301, 371, 285, 395, 278, 419, 253, 442, 243, 511, 238, 542, 242, 563, 250, 582, 264, 605, 273, 612, 291, 606, 305, 554, 327, 522, 339, 388, 342, 352, 331);
  poly('#58304a', 354, 302, 377, 287, 397, 279, 421, 253, 442, 244, 513, 238, 548, 243, 566, 253, 585, 266, 605, 274, 593, 281, 529, 300, 443, 322, 365, 315);
  poly('#7d405b', 393, 280, 423, 253, 444, 245, 513, 239, 546, 244, 562, 251, 479, 259, 445, 277, 408, 293);
  poly('#a2596d', 415, 261, 427, 253, 445, 245, 512, 239, 546, 244, 554, 247, 510, 244, 447, 250, 437, 255);
  poly('#e28b83', 430, 251, 444, 244, 512, 238, 537, 242, 504, 242, 449, 247, 440, 251);
  poly('#362840', 432, 256, 450, 250, 516, 245, 543, 248, 533, 253, 464, 260, 441, 270, 415, 274);
  poly('#17182d', 431, 258, 447, 253, 468, 252, 517, 247, 541, 250, 506, 254, 462, 262, 441, 271, 414, 275);
  poly('#73485c', 421, 271, 448, 260, 478, 255, 518, 250, 531, 251, 502, 255, 460, 263, 435, 271);
  poly('#a96470', 440, 264, 461, 258, 488, 255, 488, 256, 462, 261, 444, 266);
  poly('#42273e', 409, 278, 437, 273, 464, 261, 515, 255, 546, 249, 562, 252, 578, 265, 566, 271, 523, 280, 484, 287, 443, 305, 390, 300);
  poly('#232237', 524, 258, 549, 251, 558, 253, 573, 265, 548, 272, 474, 290, 463, 288, 488, 269);
  poly('#62435b', 494, 267, 527, 260, 548, 254, 556, 254, 568, 264, 553, 261, 527, 267, 495, 273, 478, 285);
  poly('#bc777d', 469, 288, 489, 270, 505, 264, 527, 260, 518, 263, 492, 273, 478, 288);
  poly('#965267', 383, 289, 406, 280, 417, 280, 406, 287, 398, 291, 477, 289, 533, 277, 584, 266, 592, 269, 540, 284, 477, 298, 373, 302);
  poly('#63354e', 533, 290, 589, 271, 598, 272, 608, 280, 598, 288, 564, 306, 530, 320, 503, 323, 507, 308);
  poly('#93475f', 517, 299, 553, 288, 594, 276, 606, 277, 578, 288, 538, 303, 512, 312);
  poly('#b65f70', 542, 295, 587, 280, 601, 277, 596, 280, 568, 290, 551, 299);
  poly('#281a31', 355, 303, 378, 299, 474, 299, 510, 291, 529, 293, 514, 319, 509, 333, 486, 340, 386, 342, 352, 330);
  poly('#171323', 357, 310, 380, 305, 469, 304, 515, 296, 518, 300, 505, 322, 489, 328, 387, 332, 355, 324);
  poly('#633345', 355, 326, 387, 334, 486, 331, 507, 325, 501, 334, 486, 339, 387, 339, 357, 332);
  poly('#a04f62', 355, 325, 387, 331, 485, 328, 507, 321, 505, 324, 486, 331, 386, 334, 356, 328);
  poly('#341b30', 507, 315, 566, 293, 605, 279, 612, 291, 606, 305, 595, 311, 598, 300, 590, 294, 578, 299, 570, 312, 569, 321, 526, 338, 500, 337);
  poly('#201728', 492, 332, 517, 321, 562, 304, 572, 301, 565, 314, 527, 331, 510, 338);
  poly('#171322', 524, 316, 537, 312, 546, 316, 547, 326, 541, 339, 532, 344, 520, 340, 516, 332, 517, 324);
  poly('#493046', 529, 318, 537, 315, 543, 320, 543, 327, 538, 337, 531, 341, 525, 339, 522, 331, 524, 323);
  poly('#6d5269', 531, 321, 537, 319, 540, 323, 539, 332, 534, 337, 529, 337, 525, 332, 527, 325);
  poly('#21192f', 532, 324, 537, 323, 538, 328, 533, 334, 529, 333, 530, 328);
  box(532, 327, 3, 3, '#be8390');
  poly('#493447', 582, 305, 590, 300, 596, 302, 597, 309, 593, 319, 586, 323, 580, 320, 578, 314);
  poly('#181527', 586, 305, 592, 304, 594, 310, 590, 317, 586, 319, 582, 316, 583, 310);
  box(587, 310, 3, 3, '#b07186');
  line(548, 319, 569, 310, '#99546e'); line(550, 324, 568, 316, '#69445e');
  line(549, 307, 605, 284, '#c47476'); line(569, 286, 571, 299, '#48263f');
  line(511, 299, 498, 301, '#e17b7a'); line(383, 299, 465, 297, '#dc7c80');
  box(376, 298, 32, 1, '#ed9290'); box(452, 299, 26, 1, '#b15f74');

  // Segmented hot LEDs, trunk badge, exhaust and blown-out rain reflections.
  halo(383, 315, 33, '#fd334843'); halo(481, 311, 37, '#ff325643');
  poly('#7e263d', 358, 312, 366, 308, 415, 309, 415, 322, 383, 324, 358, 319);
  poly('#7e263d', 451, 308, 486, 306, 510, 301, 510, 310, 488, 320, 452, 322);
  for (let bar = 0; bar < 15; bar++) {
    const xx = 361 + bar * 3, yy = 310 + Math.max(0, Math.floor((xx - 384) / 12));
    box(xx, yy, 2, 9 - Math.max(0, Math.floor((378 - xx) / 7)), bar % 3 ? '#ff5064' : '#ff6c71');
    box(xx, yy + 1, 2, 2, bar % 5 ? '#ff9691' : '#ffc3ae');
  }
  for (let bar = 0; bar < 17; bar++) {
    const xx = 455 + bar * 3, yy = 309 - Math.floor(Math.max(xx - 484, 0) / 4.4);
    box(xx, yy, 2, 9, bar % 4 ? '#ff4f63' : '#ff7779'); box(xx, yy + 1, 2, 2, '#ff9d92');
  }
  line(359, 312, 380, 309, '#ff656c'); line(456, 309, 486, 307, '#fc6a71');
  box(420, 310, 24, 11, '#432536'); box(423, 312, 18, 7, '#c29aa0'); box(423, 312, 18, 1, '#f6c1b0');
  box(426, 315, 3, 2, '#512c48'); box(431, 315, 3, 2, '#512c48'); box(436, 315, 2, 2, '#512c48');
  box(419, 305, 23, 1, '#ac6479'); box(430, 303, 5, 1, '#ef9295');
  box(372, 333, 14, 3, '#100e19'); box(373, 333, 10, 1, '#bf7884'); box(476, 333, 12, 3, '#100e19');
  box(478, 333, 8, 1, '#ab687d'); box(594, 287, 10, 2, '#ffa985'); box(602, 288, 4, 1, '#ffd9a9');

  // Fine glints are animated over the cached vista rather than repainting the scene.
  c.imageSmoothingEnabled = false;
  let frame = 0, last = -1, live = true;
  const reduced = !motion || matchMedia('(prefers-reduced-motion: reduce)').matches;
  const paint = t => {
    if (!live) return;
    if (t - last > 72 || last < 0) {
      last = t; c.drawImage(surface, 0, 0);
      if (!reduced) {
        const f = t / 1000;
        c.fillStyle = '#ffacab';
        for (const [i, xx, yy] of [[0,370,93],[1,566,89],[2,641,118],[3,288,126],[4,495,155]]) {
          c.globalAlpha = Math.sin(f * 2.2 + i * 1.2) > .19 ? .82 : .16;
          c.fillRect(xx, yy, 2, 1);
        }
        c.globalAlpha = .2 + Math.sin(f * 1.1) * .09;
        c.fillStyle = '#ff9b95';
        for (let i = 0; i < 22; i++) {
          const xx = 352 + (i * 17 + Math.floor(f * (2 + (i % 3)))) % 266;
          c.fillRect(xx, 230 + (i * 7) % 28, 2 + i % 6, 1);
        }
        c.globalAlpha = 1;
      }
    }
    if (!reduced) frame = requestAnimationFrame(paint);
  };
  frame = requestAnimationFrame(paint);
  return () => { live = false; cancelAnimationFrame(frame); };
}