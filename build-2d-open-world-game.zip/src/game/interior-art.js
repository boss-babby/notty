import { rng, TAU } from './core.js';

const W=720,H=470;
const floors={wood:['#5b4649','#ad7b6e','#302c3b'],tile:['#505763','#abb4b9','#303943'],carpet:['#50394e','#a6728f','#322b42'],marble:['#6e727a','#b2b8b7','#454c60'],concrete:['#494653','#787985','#31323f'],checker:['#57555c','#817a79','#383543'],linoleum:['#51706d','#72a99b','#384b52'],brick:['#64524e','#ab806b','#38333f'],stone:['#62615f','#8e8b75','#41414d'],platform:['#606569','#989c91','#3c424c'],service:['#5d5856','#8f877a','#3b3d47'],turf:['#4e6452','#879179','#354844'],arcadefloor:['#3d3450','#6b5679','#292437']};

const f=(g,x,y,w,h,color)=>{g.fillStyle=color;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
const h=(g,x,y,rx,ry,c)=>{g.fillStyle=c;g.beginPath();g.ellipse(x,y,rx,ry,0,0,TAU);g.fill();};
const line=(g,c,w,...pts)=>{g.strokeStyle=c;g.lineWidth=w;g.beginPath();g.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=2)g.lineTo(pts[i],pts[i+1]);g.stroke();};
const centered=(g,text,x,y,sz,col)=>{g.textAlign='center';g.font=`800 ${sz}px monospace`;g.fillStyle=col;g.fillText(text,x,y);};
const wear=(g,R,x,y,w,hgt,count=34)=>{
  for(let n=0;n<count;n++) f(g,x+R()*w,y+R()*hgt,1+R()*3,1,R()>.48?'#bfcbd00f':'#1915271e');
};

function ground(g,R,q){
  const {x,y,w,h}=q,[a,b,c]=floors[q.t]||floors.stone;
  f(g,x,y,w,h,a);
  if(q.t==='wood'||q.t==='brick'||q.t==='platform'){
    const stride=q.t==='wood'?11:q.t==='brick'?17:16;
    for(let v=0;v<h;v+=stride){
      f(g,x,y+v,w,1,c+'b0');f(g,x,y+v+1,w,1,b+'56');
      for(let u=(v/stride%2?24:13);u<w;u+=49)f(g,x+u,y+v,1,Math.min(stride,h-v),c+'82');
      for(let n=0;n<7;n++){const u=R()*(w-14);f(g,x+u,y+v+2+R()*(stride-4),R()*14,1,b+'55');}
    }
  }else if(['tile','marble','checker','stone'].includes(q.t)){
    const step=q.t==='marble'?28:19;
    for(let v=0;v<h;v+=step)for(let u=0;u<w;u+=step){
      const w2=Math.min(step-1,w-u),h2=Math.min(step-1,h-v), k=(Math.floor(v/step)+Math.floor(u/step))%2;
      if(q.t==='checker'&&k)f(g,x+u,y+v,w2,h2,c+'78');
      else if(R()>.64)f(g,x+u,y+v,w2,h2,b+'28');
      f(g,x+u,y+v,w2,1,c+'9d');f(g,x+u,y+v,1,h2,c+'9d');
      if(q.t==='marble'&&R()>.37)line(g,b+'26',1,x+u+2,y+v+3,x+u+7,y+v+7,x+u+11,y+v+8,x+u+w2-3,y+v+h2-2);
    }
  }else if(q.t==='carpet'||q.t==='arcadefloor'){
    for(let v=3;v<h-2;v+=8)for(let u=4;u<w-3;u+=8){if((v+u)%16===7)f(g,x+u,y+v,2,1,b+'4d');else f(g,x+u,y+v,1,2,c+'7d');}
    f(g,x+3,y+4,w-6,1,b+'80');f(g,x+3,y+h-5,w-6,1,b+'80');f(g,x+4,y+6,1,h-12,b+'80');f(g,x+w-5,y+6,1,h-12,b+'80');
  }else{
    for(let u=0;u<w;u+=48){f(g,x+u,y,1,h,c+'83');}
    for(let v=0;v<h;v+=47){f(g,x,y+v,w,1,c+'83');}
    if(q.t==='service'){f(g,x+5,y+2,2,h-5,b);f(g,x+w-7,y+2,2,h-5,b);}
  }
  wear(g,R,x+1,y+1,w-4,h-4,Math.max(12,w*h/600));
}

function furniture(g,R,v,colors){
  const {x,y,w,h:ht,t}=v, [a,b,c]=colors;
  const q=(dx,dy,ww,hh,col)=>f(g,x+dx,y+dy,ww,hh,col);
  if(t==='platform'){q(0,0,w,ht,'#686b71');q(0,ht-3,w,2,'#b7b298');return;}
  if(['partition','pillar'].includes(t)){
    q(6,6,w+5,ht+4,'#1515217d');q(0,0,w,ht,'#4a4455');q(0,0,w,3,a+'98');q(w-3,4,3,ht-4,'#282638');
    for(let z=9;z<ht-4;z+=13)q(2,z,w-4,1,'#8d7d8249');return;
  }
  if(t==='planter'){q(5,7,w,ht,'#1f27317a');q(0,1,w,ht,'#b69982');q(3,4,w-6,ht-6,'#343b3d');for(let u=7;u<w-4;u+=9)h(g,x+u,y+ht*.49,6,10,u%2?'#6e886d':'#8e9963');return;}
  q(5,7,w+4,ht+4,'#11152189');q(0,1,w,ht,'#242638');q(1,1,w-2,ht-5,c);q(1,1,w-2,1,a+'7a');
  if(['rack','archive','lockers','toolwall','cold','shelf','cabinet','ticket','gate'].includes(t)){
    const palette=t==='cold'?['#8bbdc2','#acd0bf','#7f9da5']:t==='cabinet'?['#d18ce6','#827ed0','#db81a4']:['#b18c75','#8b8da8','#b990a5','#7aada4'];
    q(2,3,w-4,ht-7,t==='cold'?'#323847':'#303041');
    const edge=t==='cabinet'?20:t==='rack'?17:t==='ticket'?22:12;
    for(let i=5;i<w-4;i+=edge){
      const cw=Math.min(edge-3,w-i-1), col=palette[Math.floor(R()*palette.length)];
      q(i,5,cw,ht-12,col);q(i+1,6,cw-2,3,'#e0c4ad7e');q(i+1,ht-11,cw-2,4,'#39414d');
      if(t==='archive'||t==='rack'||t==='shelf')for(let j=10;j<ht-10;j+=8){q(i+1,j,cw-2,3,'#4b5262');q(i+1,j+1,cw-3,1,col);}
      if(t==='cabinet'||t==='ticket'){q(i+1,9,cw-2,Math.ceil(ht*.32),'#272337');q(i+2,10,cw-4,3,b);q(i+2,ht-13,3,2,a);}
      if(t==='lockers')q(i+cw-2,ht*.52,2,5,'#d4c4b3');
    }
  }else if(['bed','hospitalbed','sofa','bench','windowbench','curtain'].includes(t)){
    const soft=t==='bed'||t==='hospitalbed';
    q(2,3,w-4,ht-8,soft?'#abab9e':b+'c9');q(5,7,w-10,ht-14,soft?t==='hospitalbed'?'#b3c9bb':'#af8d96':'#696173');
    q(6,6,w-12,Math.min(soft?11:3,ht-8),a+'af');
    if(soft){q(7,5,Math.min(w-14,41),10,'#ddd8c4');q(6,ht-15,w-12,8,t==='hospitalbed'?'#5f9c99':b);}
    else for(let i=22;i<w-12;i+=22)q(i,8,1,ht-16,'#3e384d');
  }else if(['radio','desk','counter','workbench','kitchen','kiosk','lowtable','tablegame'].includes(t)){
    q(3,3,w-6,ht-9,t==='radio'?'#454660':t==='kitchen'?'#6c7176':'#846669');q(4,4,w-8,2,a+'90');
    if(t==='radio'||t==='counter'||t==='desk'){
      const boxes=t==='radio'?5:t==='counter'?2:1;
      for(let i=0;i<boxes;i++){
        const u=8+i*(w-18)/boxes, ww=t==='desk'?24:Math.min(27,(w-18)/boxes-2);
        q(u,7,ww,Math.min(18,ht-13),'#212738');q(u+2,9,ww-4,Math.min(9,ht-15),i%2?b:'#7fb2af');
        q(u+3,11,ww-6,1,'#d8dfba');q(u+4,ht-11,ww-8,2,'#b9a9a0');
      }
    }else if(t==='tablegame'){
      q(7,5,w-14,ht-10,'#b89b73');q(12,8,w-24,ht-17,'#7b6a5c');h(g,x+w/2,y+ht/2,7,7,'#d8ad75');
      for(let i=0;i<5;i++)h(g,x+w*.37+R()*w*.28,y+ht*.34+R()*ht*.3,2,2,i%2?'#3a3f51':'#f1d5a1');
    }else for(let i=8;i<w-7;i+=12){q(i,8,7,ht*.38,'#3b3d4b');q(i+1,8,2,ht*.35,i%2?'#d8ae75':'#89aeb0');}
    q(6,ht-8,w-12,2,'#342937');
  }else if(['spices','produce','crate'].includes(t)){
    const palette=t==='spices'?['#d4915d','#c37667','#ccb878','#a39f71']:['#bd8c5e','#a5ad6f','#d3ad68','#bf6e6a'];
    for(let v0=4;v0<ht-5;v0+=13)for(let u=3;u<w-4;u+=14){
      q(u,v0,Math.min(13,w-u-1),Math.min(12,ht-v0-2),'#73604e');const c0=palette[Math.floor(R()*palette.length)];
      if(t==='crate'){q(u+1,v0+1,9,8,c0);q(u+2,v0+3,8,1,'#514a47');q(u+6,v0+1,1,7,'#d5ae76');}
      else for(let n=0;n<5;n++)h(g,x+u+2+R()*8,y+v0+2+R()*7,1.8,2.1,c0);
    }
  }else if(t==='lift'||t==='rig'||t==='tires'){
    if(t==='tires'){
      for(let v0=8;v0<ht-4;v0+=17)for(let u=7;u<w-3;u+=17){h(g,x+u,y+v0,7,7,'#292a35');h(g,x+u,y+v0,4,4,'#5d5b5e');h(g,x+u,y+v0,2,2,'#3c3e45');}
    }else{
      q(3,0,5,ht,'#ad956b');q(w-8,0,5,ht,'#ad956b');q(11,9,w-22,ht-18,t==='rig'?'#9e8c65':'#6e8292');q(14,13,w-28,ht-26,t==='rig'?'#a38e65':b);
      q(16,ht*.31,w-32,ht*.18,t==='rig'?'#525c52':'#394759');q(16,ht*.35,w-32,3,'#b9b7a2');
      q(16,ht-18,7,5,'#e89875');q(w-23,ht-18,7,5,'#e89875');
      if(t==='rig')for(let i=12;i<ht-9;i+=8){q(9,i,5,3,'#3a4043');q(w-14,i,5,3,'#3a4043');}
    }
  }else if(t==='vault'){
    q(3,4,w-6,ht-10,'#635e71');q(6,6,w-12,ht-14,'#8e8c99');
    for(let i=8;i<w-8;i+=13){q(i,7,9,ht-16,'#6d687e');q(i+2,ht*.46,4,3,'#d6bd94');}
  }else q(4,5,w-8,ht-12,b+'77');
  wear(g,R,x+2,y+2,w-4,ht-4,Math.max(5,w*ht/380));
}

function detail(g,R,d,colors){
  const {x,y,w,h:ht,t}=d,[a,b]=colors;
  if(['window','glass','waterwindow','neonbar','awning','shutter'].includes(t)){
    f(g,x-2,y-2,w+4,ht+4,'#272638');f(g,x,y,w,ht,t==='waterwindow'?'#426e7b':t==='window'||t==='glass'?'#61778a':b);
    f(g,x,y,w,1,a+'a9');f(g,x,y+ht-1,w,1,'#242a37');
    for(let i=4;i<w-3;i+=t==='shutter'?4:t==='awning'?8:16){
      f(g,x+i,y+1,2,ht-2,t==='awning'?'#f3c08c95':'#becce17e');
      if(t==='window'||t==='waterwindow')f(g,x+i+4,y+ht/2,3,1,i%3?'#add5ce':'#f2bd9d');
    }return;
  }
  if(t==='tracks'){
    f(g,x,y,w,ht,'#292d3a');f(g,x,y+ht*.3,w,3,'#8a8a8e');f(g,x,y+ht*.74,w,3,'#8a8a8e');
    for(let i=7;i<w;i+=13)f(g,x+i,y+ht*.21,4,ht*.65,'#65616c');return;
  }
  if(t==='plant'){h(g,x+w*.6,y+ht*.6,w*.42,ht*.34,'#212e38a4');h(g,x+w/2,y+ht*.57,w*.41,ht*.25,'#92786b');for(let i=0;i<6;i++){h(g,x+w/2+(R()-.5)*w*.68,y+R()*ht*.5,4,5,['#6a836d','#9aab74','#457366'][i%3]);}return;}
  if(t==='compass'||t==='medmark'){
    const cx=x+w/2,cy=y+ht/2;
    if(t==='medmark'){f(g,cx-15,cy-3,30,6,'#947b7d');f(g,cx-4,cy-10,8,20,'#a78d89');}
    else{h(g,cx,cy,Math.min(w*.2,26),ht*.45,'#4b495b');line(g,a+'b0',1,cx,cy-ht*.4,cx+ht*.45,cy,cx,cy+ht*.4,cx-ht*.45,cy,cx,cy-ht*.4);}
    return;
  }
  if(t==='queue'||t==='safety'||t==='curtain'){
    if(t==='curtain'){f(g,x,y,w,ht,b+'b4');for(let n=2;n<w;n+=6)f(g,x+n,y,2,ht,a+'76');}
    else for(let i=0;i<w-2;i+=10)f(g,x+i,y,6,Math.min(2,ht),a+'94');return;
  }
  f(g,x,y,w,ht,'#443c4ea0');f(g,x,y,w,2,b+'80');f(g,x,y+ht-3,w,1,a+'61');wear(g,R,x,y,w-2,ht-2,18);
}

export function paintInterior(canvas,layout){
  canvas.width=W;canvas.height=H;
  const g=canvas.getContext('2d'), {x,y,w,h:ht}=layout.base, [a,b]=layout.colors, R=rng(Array.from(layout.id).reduce((s,c)=>s*19+c.charCodeAt(0),153));
  if(!g)return;
  f(g,x-13,y-9,w+27,ht+31,'#090b15a9');f(g,x-7,y-6,w+14,ht+18,'#312b3c');
  f(g,x-3,y-5,w+6,ht+9,'#675969');f(g,x,y,w,ht,'#393747');
  for(const q of layout.floors)ground(g,R,q);
  for(const d of layout.decor)detail(g,R,d,layout.colors);
  const lamps=layout.lights;
  for(const [lx,ly,r,c] of lamps){
    const grad=g.createRadialGradient(lx,ly,0,lx,ly,r);
    grad.addColorStop(0,c+'38');grad.addColorStop(.48,c+'1b');grad.addColorStop(1,'transparent');
    f(g,lx-r,ly-r,r*2,r*2,grad);
  }
  for(const q of layout.furniture)furniture(g,R,q,layout.colors);
  // A continuous wall cap and a cutaway front edge keep room boundaries legible.
  f(g,x-4,y-4,w+8,4,'#aba091');f(g,x-4,y,w+8,6,'#494354');f(g,x-4,y+4,2,ht-6,'#96867e');f(g,x+w+1,y+4,2,ht-6,'#514958');
  f(g,x-3,y+ht-5,w+6,5,'#544557');f(g,x-3,y+ht,w+6,3,'#8b7783');
  const ex=layout.exit;f(g,ex.x-22,y+ht-8,44,10,'#252838');f(g,ex.x-20,y+ht-5,40,2,'#e2ca93');
  f(g,ex.x-19,ex.y+5,38,7,'#75675498');f(g,ex.x-19,ex.y+5,38,1,'#e8c994');
  for(let u=-12;u<13;u+=6)f(g,ex.x+u,ex.y+7,2,2,'#ccb578');
  const signW=Math.min(w-18,layout.name.length*7.3+22),sx=x+w/2;
  f(g,sx-signW/2,y-25,signW,17,'#2a2436');f(g,sx-signW/2,y-25,signW,1,b);centered(g,layout.name,sx,y-13,10,a);
  centered(g,layout.subtitle,sx,y+ht+20,7,'#ae9bad');
}