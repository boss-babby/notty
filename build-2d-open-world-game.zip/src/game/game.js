import { CELL, DEFAULTS, CONTROLS, DISTRICTS, GEAR, GARAGE, GARAGE_PAINT, HEIGHT, HOLDINGS, MARKET_GOODS, MODES, MONSOON_START, PLACES, SEED, START, STATIONS, WARDROBE, WEATHER, WIDTH, campaignFor, modelIndex, place } from './data.js';
import { clamp, mix, dist, angleDiff, unit, rng, Pool, SpatialHash, FixedLoop, Input, keyName, read, write, mod } from './core.js';
import { City, districtOf, isRoad, isWater, roomGeometry } from './world.js';
import { addCar, addPerson, debugStreetEvent, hitCar, hurtPerson, savePos, updateActors, updateAmbient, updateDrive, updateWanted } from './actors.js';
import { contractStatus, endingLine, jobMarker, jobUse, marker, missionUse, newStage, recordStreetPhoto, selectChoice, stageOf, startJob, updateJob, updateMission } from './campaign.js';
import { Renderer } from './renderer.js';
import { FERRY_POINTS, pointLimit, regionOf } from './geography.js';
import { AIR_PORTS, ATLAS_LABELS, NEW_FACTIONS, SEA_PORTS } from './atlas-data.js';
import { atlasStart, buyTicket, clubStation, clubTalk, localVista, roomCast, seedAtlasVehicles, surveyNearby, surveyUse, tablePlay, travelTick } from './atlas-runtime.js';
import { QUARANTINE_START, createOutbreak, infectedDrop, outbreakMarker, outbreakPrompt, outbreakUse, runRecord, updateOutbreak } from './outbreak.js';
import { makeNoise } from './horde.js';
import { adjustTable, newTable, tableTrigger, tableView, tickTable } from './parlor.js';
import { landAt } from './navigation.js';
import { blankContact, blastScale, cancelContact, handleMedkit, hurtPlayer, hydrateKit, impact, profile, reloadKit, reserveAmmo, spawnRound, tickRounds, updateContact, useWeapon, weaponSpread } from './contact.js';
import { materialOf } from './contact-data.js';
import { moveOnFoot } from './movement.js';
import { bayRoom, PracticeBay } from './practice.js';
import { factionDisposition, streetMarker, streetUse } from './street-events.js';

export function readSettings() {
  const saved = read('settings', {}) || {};
  const reduce = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
  return { ...DEFAULTS, motion: !reduce, ...saved, bindings: { ...saved.bindings } };
}
export const saveSettings = s => write('settings', s);
export function readSave(mode='campaign') {
  if(mode==='practice')return null;
  const s = read(MODES[mode]?.saveKey||'save');
  return s?.version === 1 && Number.isFinite(s.x) && Number.isFinite(s.y) && Number.isInteger(s.chapter) ? s : null;
}
export const readBest = () => read('outbreak-best', {score:0, kills:0, escaped:false});

const initialStats = { driven: 0, walked: 0, shots: 0, hits:0, takedowns: 0, escapes: 0, missions: 0, jobs: 0, tapes: 0, playtime: 0, vehicles: 0, blackouts: 0 };
const look = { color: '#ff6481', skin: '#e3ac93', hair: 1 };
const itemData = index => ({ mag: GEAR[index].mag, stash: index === 3 ? 54 : GEAR[index].mag * 4 });
const timecode = n => `${String(Math.floor(mod(n, 24))).padStart(2, '0')}:${String(Math.floor((n % 1) * 60)).padStart(2, '0')}`;

export class HarborGame {
  constructor(canvas, settings, sound, send, screen, record = null, mode='campaign') {
    this.canvas = canvas; this.settings = settings; this.sound = sound; this.send = send; this.screen = screen;
    const s = record || {};
    this.mode=MODES[mode]?mode:'campaign';this.campaign=campaignFor(this.mode);
    this.practice=this.mode==='practice'?new PracticeBay(this,addPerson):null;
    this.outbreak=this.mode==='outbreak'?createOutbreak(s.outbreak):null;this.best=this.outbreak?readBest():null;
    const start=this.outbreak?QUARANTINE_START:this.mode==='monsoon'?MONSOON_START:this.mode==='atlas'?atlasStart(s.start):START;
    this.uid=0;this.city=new City(s.seed||SEED,s.style||'continental');this.rand=rng(this.city.seed^(Math.floor(s.stats?.playtime||0)+87234));
    this.atlasStart=s.start||'mirage';this.worldKey=s.worldKey||'';this.surveys=new Set(s.surveys||[]);this.flight=null;this.tableRoll=null;
    this.city.charted=new Set(s.charted||[]);
    this.player = { x:pointLimit(s.x??start.x), y:pointLimit(s.y??start.y), a:s.a||0, r:8,
      hp: s.hp ?? 100, armor: s.armor ?? 32, stamina: 100, stride: 0, cover: false, hit: 0, dodge: 0, cd: 0, swim: false, foot: 0, stance: 0, inv: 0, ...look, ...s.look };
    savePos(this.player);
    this.cash = s.cash ?? 240; this.bankBalance = s.bankBalance ?? 0; this.medkits = s.medkits ?? 2;
    const kit=hydrateKit(s.armory,{0:itemData(0),3:itemData(3),...(this.outbreak?{1:itemData(1),5:itemData(5)}:{})},s.ammoPools);
    this.armory=kit.slots;this.ammoPools=kit.reserve;this.contact=blankContact();this.weapon=this.armory[s.weapon]?s.weapon:3;this.pendingReload=0;this.recoil=0;
    this.chapter = clamp(s.chapter || 0, 0, this.campaign.length); this.step = this.campaign[this.chapter]?.steps[s.step] ? s.step : 0;
    this.rook = s.rook ?? null; this.ending = s.ending ?? null;
    this.stats={...initialStats,...s.stats};this.rep={Coil:0,Prism:0,Grid:0,River:0,Verge:0,Civic:0,...Object.fromEntries(Object.values(NEW_FACTIONS).map(k=>[k,0])),...s.rep};
    this.skills = { drive: 0, aim: 0, stamina: 0, stealth: 0, ...s.skills };
    this.territory = DISTRICTS.map((d,i)=>s.territory?.[i]||d.faction);
    this.tapes=new Set(s.tapes||[]);this.discovered=new Set(s.discovered||[this.outbreak?'shelter':this.mode==='monsoon'?'cha':this.mode==='atlas'?this.atlasStart==='basin'?'jacklight':'marina':'relay']);this.city.broken=new Set(s.broken||[]);this.imports=s.imports||[];
    this.properties = s.properties || []; this.news = s.news || (this.outbreak?[{title:'Emergency Band: stay clear of blocked roads and listen for the ferry.',time:'22:48'}]:this.mode==='monsoon'?[{title:'Puran volunteers keep hot tea and dry blankets at the north gate.',time:'16:08'}]:[{ title: 'Overnight transmission interrupts the Vesper Bay weather service.', time: '22:10' }, { title: 'Vesper Trust to keep its public lobby open after dark.', time: '21:28' }]);
    this.day=s.day??(this.outbreak?23.25:this.mode==='monsoon'?16.45:this.mode==='atlas'&&this.atlasStart==='mirage'?17.14:22.17);this.weather=s.weather??(this.outbreak?2:this.mode==='atlas'?0:1);this.weatherTimer=72;this.thunder=1;this.lightning=0;
    this.cars = []; this.people = new Pool(74); this.particles = new Pool(540); this.bolts = new Pool(208); this.lights = new Pool(40); this.marks = new Pool(340);this.fires=new Pool(18);this.scars=new Pool(130);
    this.entities = new SpatialHash(72); this.near = [];this.projectileWalls=[];this.skidAt=0;
    this.room = null; this.interior = null; this.outside = null; this.transition = null;
    this.table=null;this.records=s.records||{};this.view=0;this.weatherStyle={wet:0};this.decoys=this.outbreak?(s.decoys??3):0;this.boards=this.outbreak?(s.boards??2):0;this.decoyItems=[];
    this.perks=s.perks||[];this.cargo=s.cargo||{};this.streetEvent=null;
    this.clothes=[...new Set([0,...(s.clothes||[]),this.player.outfit||0])];
    this.car = null; this.panel = null; this.job = null; this.waypoint = s.waypoint || null; this.hotwire = null; this.hotSide = null;
    this.heat = 0; this.seen = false; this.sinceSeen = 0; this.policeTimer = 0; this.lastSeen = { x: this.player.x, y: this.player.y }; this.blockade = []; this.heli = null;
    this.clock = 0; this.eventTimer = 21; this.spawnTimer = .2; this.autosave = 20; this.radioTimer = 31; this.radioCue = 0; this.alarm = 0; this.shake = 0; this.jump = 0; this.station = clamp(s.station ?? (this.outbreak?2:0), -1, STATIONS.length - 1);this.inbox=s.inbox||[];
    this.note = null; this.line = null; this.briefDelay = 0; this.finishDelay = 0; this.debug = false; this.lastDisplay = -1; this.renderRev = 0; this.camera = { x: this.player.x, y: this.player.y, ox: this.player.x, oy: this.player.y, zoom: 1 }; this.focus = null;
    this.input = new Input(canvas, key => this.binding(key));
    this.renderer = new Renderer(canvas, this);
    this.loop = new FixedLoop(dt => this.tick(dt), (alpha, fps) => this.draw(alpha, fps));
    this.city.stream(this.player.x, this.player.y);
    if(this.practice){
      this.room='bay';this.interior=bayRoom();const q=place('bay');this.outside={x:q.x,y:q.y};
      Object.assign(this.player,this.interior.spawn,{a:-Math.PI/2});savePos(this.player);
      Object.assign(this.camera,this.interior.anchor,{ox:this.interior.anchor.x,oy:this.interior.anchor.y,zoom:this.interior.scale});
      this.station=-1;newStage(this);this.open('practice');this.loop.start();return;
    }
    const parked = s.car;
    if (parked && GARAGE[parked.model]) {
      const v = addCar(this, parked.model, parked.x, parked.y, parked.a, 'parked', { owned: true, keep: true, boost: parked.boost || 0, plate: parked.plate || '61-VB' });
      if (parked.color) v.color = parked.color;
      if(Number.isFinite(parked.hp))v.hp=clamp(parked.hp,1,v.model.hp);
      v.light=parked.light!==false;v.scuffs=Array.isArray(parked.scuffs)?parked.scuffs.slice(0,11):[];v.glassHit=Boolean(parked.glassHit);v.tireWear=clamp(parked.tireWear||0,0,1);
      this.lastOwned=v;
      if (parked.inCar) { this.car = v; this.player.x = v.x; this.player.y = v.y; savePos(this.player); }
    } else if(this.outbreak){
      addCar(this,10,6778,2916,0,'parked',{owned:true,keep:true});
    } else if(this.mode==='atlas'){
      const basin=this.atlasStart==='basin',x=start.x+(basin?77:-45),y=start.y-14;
      addCar(this,modelIndex(basin?'havoc':'vanta'),x,y,0,'parked',{owned:true,keep:true});
      const trafficModels=basin?[2,3,8,1,6,0]:[2,1,8,7,0,3];
      for(let i=0;i<5;i++){
        const ax=start.x+(i%2?1:-1)*(116+i*19),ay=start.y+(i<3?-73:86)+i*9;
        if(!this.city.water(ax,ay)&&!this.city.block(ax,ay,14)&&!this.cars.some(v=>dist(v,{x:ax,y:ay})<57))
          addCar(this,trafficModels[i],ax,ay,i%2?Math.PI/2:0,'traffic',{cruise:70+i*11});
      }
      for(let i=0;i<13;i++){
        const px=start.x+(this.rand()-.5)*276,py=start.y+(this.rand()-.5)*218;
        if(!this.city.water(px,py)&&!this.city.block(px,py,9)){
          const n=addPerson(this,'ped',px,py,{tx:px+(this.rand()-.5)*116,ty:py+(this.rand()-.5)*116});
          if(n){n.outfit=(n.id+(basin?2:0))%4;n.routine=basin&&i%5===0?'vigil':'day';}
        }
      }
    } else if(this.mode==='monsoon'){
      addCar(this,10,6890,3376,0,'parked',{owned:true,keep:true});
    } else {
      addCar(this, 2, 1178, 986, 0, 'parked', { owned: true, keep: true, color: '#ef5386', plate: 'RELAY' });
    }
    if(this.mode==='campaign'){
    addCar(this, 0, 1464, 1039, Math.PI / 2, 'parked');
    addCar(this, 1, 1522, 1018, 0, 'parked');
    addCar(this, 4, 1000, 1322, -Math.PI / 2, 'parked');
    for (let i = 0; i < 8; i++) {
      const x = 967 + (i % 3) * CELL, y = 765 + i * 39;
      addCar(this, i % 8, x + 14, y, -Math.PI / 2, 'traffic', { cruise: 70 + i * 8 });
      const px = 1017 + i * 38, py = i % 2 ? 917 : 1016;
      addPerson(this, 'ped', px, py, { tx: px + 26, ty: py });
    }
    } else if(this.mode!=='atlas'){
      addCar(this,12,6774,3375,0,'parked',{owned:true});
      addCar(this,6,7030,3414,0,'parked',{owned:true});
      addCar(this,14,7324,4508,0,'parked',{owned:true,keep:true,publicLaunch:true});
      if(this.outbreak){
        addCar(this,16,7290,3863,Math.PI/2,'parked',{owned:true,keep:true});
        addCar(this,11,6980,2900,Math.PI,'parked',{hp:0,owned:true,wreck:true,keep:true});
        addCar(this,13,7044,3375,0,'parked',{owned:true,hp:81});
      }else{
        addCar(this,9,6912,3399,Math.PI,'parked',{owned:true});
        addCar(this,11,6650,3345,0,'traffic',{cruise:99});
        for(let i=0;i<7;i++){const x=6670+i*45,y=i%2?3316:3417;if(!this.city.block(x,y,9))addPerson(this,'ped',x,y,{tx:x+39,ty:y});}
      }
    }
    newStage(this);
    if (this.campaign[this.chapter]) this.say(this.campaign[this.chapter].brief, 8.4);
    else if(this.outbreak&&!s.outbreak)this.say({speaker:'Emergency Band',line:'If you can hear this, open the cache ahead. There is a ferry waiting, but it needs three beacons.'},8.4);
    this.publish(true);
    this.loop.start();
  }
  dispose() { this.loop.stop(); this.input.release(); this.renderer.dispose(); this.sound.advance(this, true); }
  binding(key) { return this.settings.bindings[key] || CONTROLS[key]?.[0] || ''; }
  setSettings(s) { const resized = this.settings.quality !== s.quality; this.settings = s; this.sound.updateSettings(s); if (resized) this.renderer.size(); }
  stage() { return stageOf(this); }
  objectiveMarker(){return this.outbreak?outbreakMarker(this):marker(this);}
  contactReset(){cancelContact(this);this.contact.kick=0;this.contact.bias=0;this.player.recoil=0;this.player.pump=0;}
  hurtActor(n,amount,owner,detail){return hurtPerson(this,n,amount,owner,detail);}
  hitRide(v,amount,owner,detail){return hitCar(this,v,amount,owner,detail);}
  ammo(type,value){return reserveAmmo(this,type,value);}
  signalNoise(radius,at=this.player,kind='impact'){
    if(!this.outbreak||this.room)return;
    this.outbreak.noise=Math.max(this.outbreak.noise,radius);
    makeNoise(this.outbreak,at,radius,kind);
  }
  damageRide(amount){if(this.car)hitCar(this,this.car,amount);}
  outbreakDrop(n){infectedDrop(this,n);}
  publishBest(){
    if(!this.outbreak)return;
    const o=this.outbreak,b=this.best||readBest();
    this.best={score:Math.max(b.score,o.score),kills:Math.max(b.kills,o.kills),escaped:b.escaped||o.escaped};
    write('outbreak-best',this.best);
  }
  aimWorld() {
    const { width, height, scale } = this.renderer;
    return { x: this.camera.x + (this.input.mouse.x - width / 2) / scale, y: this.camera.y + (this.input.mouse.y - height / 2) / scale };
  }
  focusAt(x, y, duration) { if (this.settings.motion) this.focus = { x, y, time: duration, limit: duration }; }
  bump(level) { this.shake = Math.min(11, this.shake + level); }
  hear(name, x = this.player.x, y = this.player.y, v = 1) {this.sound.play(name,x-this.player.x,y-this.player.y,v,this.room?'room':'street');}
  notify(title, message, tone = 'pink') { this.note = { title, message, tone, time: 4.3 }; this.lastDisplay = -1; }
  say(speech, duration = 6.1) {
    if(speech){
      this.line={...speech,time:duration};
      if(!this.practice&&(this.mode!=='outbreak'||speech.speaker.includes('Emergency'))&&!this.inbox.some(m=>m.line===speech.line))this.inbox=[{...speech,stamp:timecode(this.day),id:`${Math.floor(this.stats.playtime*60)}-${speech.speaker}-${speech.line.slice(0,18)}`} ,...this.inbox].slice(0,30);
    }
    this.lastDisplay=-1;
  }
  report(title) {
    if (this.news.slice(0, 2).some(n => n.title === title)) return;
    this.news = [{ title, time: timecode(this.day) }, ...this.news.slice(0, 15)];
  }
  open(panel) {
    if (this.panel === panel) return;
    if(this.panel==='table'&&panel!=='table')this.table=null;
    this.panel = panel; this.input.reset(); this.input.enabled = !panel; this.hear('click');
    this.screen(panel); this.publish(true);
  }
  setWaypoint(x, y) {
    this.waypoint=x==null?null:{x:pointLimit(x),y:pointLimit(y),label:'Custom waypoint'};
    if (this.waypoint) this.hear('confirm'); this.publish(true);
  }
  save(silent = false) {
    if(this.practice){if(!silent)this.notify('Practice scores only','This bay never modifies campaign saves.');return false;}
    if(this.outbreak?.dead)return false;
    if(this.outbreak&&this.outbreak.score>(this.best?.score||0))this.publishBest();
    const p = this.player, point = this.outside || p;
    const car = this.car || (this.lastOwned&&!this.lastOwned.wreck&&this.cars.includes(this.lastOwned)?this.lastOwned:null) || this.cars.find(v => v.owned && v.keep && !v.wreck && !v.publicLaunch);
    const ok=write(MODES[this.mode].saveKey,{version:1,mode:this.mode,outbreak:this.outbreak?runRecord(this.outbreak):null,seed:this.city.seed,style:this.city.style,start:this.atlasStart,worldKey:this.worldKey,charted:[...this.city.charted].slice(-14000),surveys:[...this.surveys].slice(-5000),x:point.x,y:point.y,a:p.a,hp:p.hp,armor:p.armor,cash:this.cash,
      bankBalance: this.bankBalance, medkits: this.medkits, armory: this.armory, ammoPools:this.ammoPools,inbox:this.inbox,clothes:this.clothes,weapon: this.weapon, look: { color: p.color, skin: p.skin, hair: p.hair, outfit:p.outfit||0 }, chapter: this.chapter, step: this.step,
      day:this.day,weather:this.weather,car:car?{model:GARAGE.indexOf(car.model),color:car.color,inCar:car===this.car,x:car.x,y:car.y,a:car.a,plate:car.plate,boost:car.boost,hp:car.hp,light:car.light,scuffs:car.scuffs,glassHit:car.glassHit,tireWear:car.tireWear}:null,
      rook: this.rook, ending: this.ending, stats: this.stats, rep: this.rep, skills: this.skills, territory: this.territory, imports: this.imports,records:this.records,decoys:this.decoys,boards:this.boards,perks:this.perks,cargo:this.cargo,
      tapes: [...this.tapes], discovered: [...this.discovered], broken: [...this.city.broken].slice(-320), properties: this.properties, news: this.news, waypoint: this.waypoint, station: this.station });
    if (!silent) this.notify(ok ? 'Game saved' : 'Session saved', ok ? 'Checkpoint written to this browser.' : 'Storage is blocked. This save lasts until you close the page.', 'ok');
    this.publish(true); return ok;
  }
  crime(amount, text) {
    if(this.outbreak||this.practice)return;
    const old = Math.ceil(this.heat); this.heat = Math.min(5, this.heat + amount);
    const next = Math.ceil(this.heat); this.sinceSeen = 0;
    this.lastSeen = this.outside || { x: this.player.x, y: this.player.y }; this.alarm = Math.max(this.alarm, 2.4);
    if(this.dispatch){this.dispatch.nextOrder=0;this.dispatch.nextSight=0;if(!old)this.dispatch.velocity={x:0,y:0};}
    if (next > old) { this.policeTimer = Math.min(this.policeTimer, .4); this.report(text); if (old === 0) this.notify('Grid alert', 'Lose their line of sight to start the search timer.', 'warn'); }
    this.rep.Grid -= amount * .4;
  }
  witness(where,text){
    if(this.outbreak||this.practice)return;
    const remembered={x:where.x,y:where.y};
    this.crime(.21,text);if(!this.seen)this.lastSeen=remembered;
  }
  emitStreetNoise(x,y,radius){if(!this.room&&!this.practice)this.streetNoise={x,y,radius,time:this.clock};}
  adjustFaction(team,amount){
    const key=({'Coil Union':'Coil','Prism Crew':'Prism','Civic Grid':'Grid','River Cooperative':'River','Verge Works':'Verge','Civic Union':'Civic',...NEW_FACTIONS})[team];
    if(key)this.rep[key]=clamp((this.rep[key]||0)+amount,-25,25);
  }
  playerHurt(amount,detail) {return hurtPlayer(this,amount,detail);}
  respawn() {
    if(this.practice){this.practice.finish(false);return;}
    if(this.outbreak){this.outbreak.dead=true;this.publishBest();this.open('outbreak-end');return;}
    const p=this.player,at=this.outside||p;
    const hospital=PLACES.filter(q=>q.kind==='CLINIC').sort((a,b)=>dist(a,at)-dist(b,at))[0];
    if(this.job?.started&&this.job.kind==='service'){startJob(this,'');this.report('A service shift closes early.');}
    if (this.car) this.exitCar(true);
    this.cash = Math.max(0, this.cash - 85); this.heat = 0; this.room = null; this.outside = null; this.transition = null; this.interior = null;
    this.hotwire = null; this.bolts.clear(); this.city.k = ''; this.teleport(hospital.x, hospital.y - 16);
    p.hp = 100; p.armor = 12; p.stamina = 100; p.inv = 3; this.focus=null;this.contactReset();
    for (const n of this.people.items) if (n.indoor || n.type === 'officer') n.active = false;
    newStage(this); this.notify('St. Echo Medical', 'You were patched up. Hospital fee: up to $85.', 'warn'); this.report('St. Echo treats another overnight casualty.');
  }
  teleport(x, y) {
    const p = this.player;
    if (this.car) { this.car.x = x; this.car.y = y; this.car.vx = this.car.vy = this.car.speed = 0; savePos(this.car); }
    p.x=pointLimit(x);p.y=pointLimit(y);p.vx=p.vy=p.driveX=p.driveY=p.impactX=p.impactY=0;p.vault=null;p.lift=0;p.swim=false;savePos(p);
    Object.assign(this.camera, { x: p.x, y: p.y, ox: p.x, oy: p.y });
    p.vanim=null;
    this.city.stream(p.x, p.y);
  }
  block(x, y, r, vault = false) {
    if (!this.room) return this.city.block(x, y, r, vault);
    return this.interior.walls.find(b => !b.projectileOnly&&(b.hp===undefined||b.hp>0)&&x + r > b.x && x - r < b.x + b.w && y + r > b.y && y - r < b.y + b.h) || null;
  }
  roomLine(a,b){
    const n=Math.ceil(dist(a,b)/9);
    for(let i=1;i<n;i++)if(this.block(a.x+(b.x-a.x)*i/n,a.y+(b.y-a.y)*i/n,2))return false;
    return true;
  }
  move(body, dx, dy, radius, vault = false) {
    if(!this.room){
      if(body===this.player&&!this.car){
        const blocked=(x,y)=>this.cars.some(v=>{
          if(v.alt>=17||v.speed>=55||v.model.class==='BOAT')return false;
          const rx=x-v.x,ry=y-v.y;if(Math.abs(rx)>50||Math.abs(ry)>50)return false;
          const a=Math.cos(v.a),b=Math.sin(v.a),w=v.model.w*.5+radius*.56,l=v.model.l*.47+radius*.46;
          const next=Math.max(Math.abs(rx*a+ry*b)/l,Math.abs(ry*a-rx*b)/w);
          const ox=body.x-v.x,oy=body.y-v.y,old=Math.max(Math.abs(ox*a+oy*b)/l,Math.abs(oy*a-ox*b)/w);
          return next<1&&(old>=1||next<old);
        });
        if(blocked(body.x+dx,body.y))dx=0;
        if(blocked(body.x+dx,body.y+dy))dy=0;
      }
      return this.city.move(body,dx,dy,radius,vault);
    }
    const b=this.interior.bounds;
    const x = clamp(body.x + dx, b.x + radius, b.right - radius), y = clamp(body.y + dy, b.y + radius, b.bottom - radius);
    const hitX = this.block(x, body.y, radius);
    if (!hitX) body.x = x;
    const hitY = this.block(body.x, y, radius);
    if (!hitY) body.y = y;
    return hitX || hitY;
  }
  setRoom(id) {
    if (this.transition || this.room === id) return;
    this.transition = { id, time: 0, swapped: false }; this.hear('door'); this.bolts.clear(); this.particles.clear();this.fires.clear();this.contactReset();
  }
  swapRoom(id) {
    if (id) {
      const p = place(id); this.outside = { x: p.x, y: p.y }; this.room = id; this.interior = roomGeometry(id); this.discovered.add(id);
      const here = this.player,{spawn,anchor}=this.interior; here.x = spawn.x; here.y = spawn.y; here.a = -Math.PI / 2; here.vx=here.vy=here.driveX=here.driveY=0;savePos(here);
      Object.assign(this.camera, { x: anchor.x, y: anchor.y, ox: anchor.x, oy: anchor.y,zoom:this.interior.scale });
      const m = this.missionState;
      if (id === 'archive' && this.stage()?.stealth) {
        m.actors = this.interior.guards.map((q,i)=>addPerson(this,'officer',q.x,q.y,{tx:i===0?407:282,ty:q.y,keep:true,indoor:true,color:'#898fc1'})).filter(Boolean);
      }
      if(!this.outbreak){
        if(clubStation(this)>=0){this.clubReturn=this.station;this.station=clubStation(this);}
        roomCast(this,addPerson);
      }
    } else {
      if(this.clubReturn!==undefined){this.station=this.clubReturn;this.clubReturn=undefined;}
      const point = this.outside || START; this.room = null; this.interior = null; this.outside = null;
      this.teleport(point.x, point.y - 13);
      for (const n of this.people.items) if (n.indoor) { n.active = false; n.keep = false; }
    }
  }
  enterCar(v) {
    if(!v||v.wreck)return false;
    if(v.speed>86||v.alt>15){this.notify('Ride is moving','Wait for the ride to slow down.','warn');return false;}
    const p=this.player,side=Math.sign((p.x-v.x)*-Math.sin(v.a)+(p.y-v.y)*Math.cos(v.a))||1;
    v.driver=false;v.siren=false;v.mode='parked';v.road=null;
    v.door={kind:'enter',side,time:0,total:.27};
    p.vanim=this.settings.motion&&dist(v,p)>3?{kind:'enter',x:p.x,y:p.y,ex:v.x,ey:v.y,time:0,total:.27}:null;
    this.car=v;p.stance=.27;p.x=v.x;p.y=v.y;p.a=v.a;p.vault=null;p.dodge=0;
    if(v.owned)this.lastOwned=v;
    this.stats.vehicles++; this.contactReset(); this.hear('door');
    if(!v.owned&&!v.reported){v.reported=true;this.crime(.45,'A vehicle has been reported missing after midnight.');}
    return true;
  }
  exitCar(force = false) {
    const v = this.car; if (!v) return;
    if(v.alt>17&&!force){this.notify('Still airborne','Hold the handbrake to land before getting out.','warn');return false;}
    const p = this.player;
    const scales=v.model.class==='BOAT'?[-1,1,-1.8,1.8,-2.7,2.7]:[1,-1,1.8,-1.8,2.7,-2.7];
    let fallback=null,side=1;
    for (const sign of scales) {
      const x = v.x - Math.sin(v.a) * 24 * sign, y = v.y + Math.cos(v.a) * 24 * sign;
      if(!this.city.block(x,y,p.r)){
        if(!fallback){fallback={x,y};side=Math.sign(sign);}if(!this.city.water(x,y)){fallback={x,y};side=Math.sign(sign);break;}
      }
    }
    if(!fallback&&!force){this.notify('Door blocked','Reposition the vehicle to leave it.','warn');return false;}
    if(fallback){p.x=fallback.x;p.y=fallback.y;}
    p.vanim=!force&&fallback&&this.settings.motion?{kind:'exit',x:v.x,y:v.y,ex:p.x,ey:p.y,time:0,total:.23}:null;
    v.door={kind:'exit',side,time:0,total:.23};
    this.car = null; p.stance = .23; p.inv = .32;p.driveX=p.driveY=0;
    v.vx = v.vy = v.speed = 0; v.brake = false; v.signal = 0; this.hear('door', v.x, v.y);
    if(force)this.bump(4);return true;
  }
  nearestCar(){
    let target=null,dd=23;
    for(const v of this.cars){
      if(v.wreck||v.speed>=86||v.alt>15||dist(v,this.player)>72)continue;
      const d=this.rideGap(v,this.player);if(d<dd){dd=d;target=v;}
    }
    return target;
  }
  rideGap(v,p){
    const x=p.x-v.x,y=p.y-v.y,c=Math.cos(v.a),s=Math.sin(v.a);
    return Math.hypot(Math.max(0,Math.abs(x*c+y*s)-v.model.l*.5),Math.max(0,Math.abs(y*c-x*s)-v.model.w*.5));
  }
  nearbyPlace() { return PLACES.find(s => dist(s, this.player) < 32) || null; }
  tapeNear() {
    const t = this.city.at(this.player.x, this.player.y)?.tape;
    return t && dist(t, this.player) < 26 && !this.tapes.has(t.id) ? t : null;
  }
  use() {
    if(this.practice){if(this.practice.near()||!this.practice.active)this.open('practice');return;}
    if(this.transition||this.flight||outbreakUse(this)||missionUse(this)||jobUse(this)||streetUse(this)||surveyUse(this))return;
    if(this.job?.kind==='photo'&&this.prompt()==='Capture landmark in Photo mode'){this.action('photo-compose');return;}
    const p = this.player;
    const bay=place('bay');
    if(!this.room&&!this.car&&dist(bay,p)<33){
      if(this.outbreak)this.notify('Training Bay closed','Access the drills from the title screen.');else this.open('practice-entry');
      return;
    }
    if(this.car){this.exitCar();return;}
    if (this.room) {
      if (dist(p, this.interior.exit) < 34) { this.setRoom(null); return; }
      const spot=this.roomSpot();if(spot){this.useRoomSpot(spot);return;}
      if (dist(p, this.interior.service) < 43) {
        if (['switch', 'coast'].includes(this.room)) this.useRelay(this.outside);
        else if(['relay','shelter'].includes(this.room))this.open('custom');
        else if(this.room==='swapmeet')this.open('exchange');
        else if(place(this.room)?.kind==='METRO'){
          if(this.outbreak)this.notify('Service suspended','The metro is shut down for the night.');else this.open('transit');
        }else if(!this.outbreak&&AIR_PORTS.includes(this.room))this.open('travel-air');
        else if(!this.outbreak&&this.room==='marina')this.open('travel-sea');
        else if(!this.outbreak&&['tide-room','halation'].includes(this.room))this.open('club');
        else if(!this.outbreak&&this.room==='jacklight')this.open('jacklight');
        else if(localVista(this))return;
        else if(!this.outbreak&&this.room==='ember')this.open('field-office');
        else this.open('shop');
      }
      return;
    }
    const stage=this.stage(),ride=this.missionState.ride;
    if (this.outbreak && !this.outbreak.used.includes('shelter') && dist(p,QUARANTINE_START)<10) {
      this.notify('Supply cache nearby','Walk right to the marker on the sidewalk.');return;
    }
    if(stage?.kind==='take'&&ride&&!ride.wreck&&dist(p,ride)<44){this.enterCar(ride);return;}
    const tape = this.tapeNear();
    if (tape) {
      this.tapes.add(tape.id); this.stats.tapes++; this.cash += 75; this.notify('Signal tape found', `Lost Frequencies / ${this.tapes.size} recovered`, 'ok'); this.hear('confirm');
      if (this.job?.kind === 'collect') { this.stats.jobs++; this.job = null; } this.save(true); return;
    }
    const {door:poi,ride:v}=this.streetAccess();
    if(poi){this.setRoom(poi.id);return;}
    if (v) {
      if (v.owned || v.mode === 'mission' || v.jacked || this.outbreak) this.enterCar(v);
      else { this.hotwire = { car: v, t: 0, zone: .23 + this.rand() * .53, mode: 'car' }; this.hotSide = null; this.hear('click'); }
      return;
    }
    const stall=this.vendorNear();if(stall)this.open('vendor');
  }
  streetAccess(){
    const p=this.player,door=this.nearbyPlace(),ride=this.nearestCar();
    const gap=ride?this.rideGap(ride,p):Infinity;
    if(door&&this.arrivalDoor?.id===door.id&&this.clock<this.arrivalDoor.until&&dist(door,p)<26)return {door,ride:null};
    if(ride&&(!door||dist(door,p)>13&&(dist(ride,p)<dist(door,p)-3||ride.owned&&gap<8&&ride.model.l>=48)))return {door:null,ride};
    return {door,ride:door?null:ride};
  }
  roomSpot(){
    return this.interior?.spots.filter(s=>dist(s,this.player)<29).sort((a,b)=>dist(a,this.player)-dist(b,this.player))[0]||null;
  }
  skillTick(){
    const earned=[['long-stride','Long Stride',this.skills.stamina>=8],['steady-hand','Steady Hand',this.skills.aim>=13],['quick-step','Quick Step',this.skills.stealth>=9],['smooth-ride','Smooth Ride',this.skills.drive>=11]];
    for(const [id,name,pass] of earned)if(pass&&!this.perks.includes(id)){
      this.perks.push(id);this.notify('Ability unlocked',name,'ok');this.hear('confirm');this.save(true);
    }
  }
  quote(n){
    const item=MARKET_GOODS[n];if(!item)return null;
    const first=this.room==='dock', hour=Math.floor(this.day), zone=first?0:1;
    const price=Math.round(item.base*(.94+Math.sin(hour*.61+n*1.9+zone*2.45)*.22+(first?(n===2?.17:-.14):(n===2?-.2:.16))));
    return {buy:price,sell:Math.max(5,price-8),held:this.cargo[item.id]||0};
  }
  trade(n,sell){
    if(this.outbreak||!['swapmeet','dock'].includes(this.room))return;
    const item=MARKET_GOODS[n], q=this.quote(n);if(!item||!q)return;
    if(sell&&q.held>0){this.cargo[item.id]=q.held-1;this.cash+=q.sell;}
    else if(!sell&&q.held<12&&this.cash>=q.buy){this.cargo[item.id]=q.held+1;this.cash-=q.buy;}
    else return;
    this.hear('confirm');this.save(true);
  }
  useRoomSpot(spot){
    if(spot.id.startsWith('club-talk:')){clubTalk(this,spot.id.split(':')[1]);return;}
    if(spot.id==='departures'&&!this.outbreak){this.open(AIR_PORTS.includes(this.room)?'travel-air':'travel-sea');return;}
    if(spot.id==='quarters'){this.open('field-office');return;}
    if(spot.id==='jacklight'){this.open('jacklight');return;}
    if(['carrom','darts','dyno'].includes(spot.id)){
      if(this.outbreak){this.notify('Venue closed','Only shelter services are active during Outbreak.');return;}
      this.table=newTable(this,spot.id);this.open('table');return;
    }
    if(spot.id==='bed'){if(this.room==='loft'&&!this.properties.includes('loft')){this.notify('Not your apartment','Use the desk to purchase the loft.');return;}this.buy('rest');return;}
    if(spot.id==='wardrobe'){this.open('custom');return;}
    if(spot.id==='records'){this.open('records');return;}
    if(spot.id==='tea'){this.open('vendor');return;}
    if(spot.id==='aid'){this.buy('kits');return;}
    if(spot.id==='rack'){this.open('shop');return;}
    if(spot.id==='observer'){this.open('map');return;}
    if(spot.id==='bands'){this.open('phone');return;}
    if(spot.id==='shift'){if(!this.outbreak)startJob(this,'bus-shift');return;}
    if(spot.id==='dispatch')this.open('dispatch');
  }
  throwDecoy(){
    if(!this.outbreak||this.room||this.car)return;
    if(!this.decoys){this.notify('No noisemakers','Search another supply locker.','warn');return;}
    const p=this.player, mouse=this.input.mouse.active?this.aimWorld():null;
    const a=mouse?Math.atan2(mouse.y-p.y,mouse.x-p.x):p.a;
    const distance=mouse?clamp(dist(p,mouse),40,180):155;
    let target={x:p.x,y:p.y};
    for(let s=18;s<distance+15;s+=14){const x=p.x+Math.cos(a)*s,y=p.y+Math.sin(a)*s;if(!landAt(this,x,y,4))break;target={x,y};}
    if(dist(p,target)<25){this.notify('No clear throw','Step away from the obstruction.','warn');return;}
    this.decoys--;this.decoyItems.push({...target,fromX:p.x,fromY:p.y,life:8,delay:.37,tick:0});this.hear('click');
  }
  updateDecoys(dt){
    for(let i=this.decoyItems.length-1;i>=0;i--){
      const d=this.decoyItems[i];d.life-=dt;d.tick-=dt;
      if(d.life<=0){this.decoyItems.splice(i,1);continue;}
      if(d.life<8-d.delay&&d.tick<=0){d.tick=.87;this.signalNoise(340,d,'decoy');this.hear('decoy',d.x,d.y,.9);this.light(d.x,d.y,'#e4d69b',21,.27);}
    }
  }
  raiseBarricade(){
    if(!this.outbreak||this.car||this.room)return;
    if(!this.boards){this.notify('No barricades','Check the supply caches for more.','warn');return;}
    const p=this.player, dx=Math.cos(p.a),dy=Math.sin(p.a),x=p.x+dx*39,y=p.y+dy*39, w=Math.abs(dx)>.71?9:50, h=w===9?50:9;
    if(![[x,y],[x-w/2,y-h/2],[x+w/2,y+h/2],[x+w/2,y-h/2],[x-w/2,y+h/2]].every(([a,b])=>landAt(this,a,b,4))){this.notify('No room for a barricade','Try a clear stretch of lane.','warn');return;}
    if(this.people.items.some(n=>n.active&&!n.dead&&Math.hypot(n.x-x,n.y-y)<25)){this.notify('The lane is occupied','Move away from the horde first.','warn');return;}
    this.boards--;this.city.playerProps.push({x:x-w/2,y:y-h/2,w,h,hp:68,type:'prop',kind:'barricade',solid:true,mission:true,id:`player-${++this.uid}`});
    this.city.changed=true;this.hear('wood');this.signalNoise(138,p,'impact');this.notify('Barricade placed','Shamblers route around it. Brutes can break it.','ok');
  }
  vendorNear(){return !this.outbreak&&this.city.at(this.player.x,this.player.y)?.vendors?.find(v=>dist(v,this.player)<25);}
  timing() { return this.hotwire ? (1 - Math.cos(this.hotwire.t * 6.4)) / 2 : 0; }
  timingAction() {
    const h = this.hotwire; if (!h) return;
    if (Math.abs(this.timing() - h.zone) < .155) {
      if (h.mode === 'car') { h.car.jacked = true; this.enterCar(h.car); }
      else { this.cash += 65; this.notify('Signal matched', 'Soft Reset dispenses $65.', 'ok'); this.save(true); }
      this.hotwire = null; this.hear('confirm');
    } else if (h.mode === 'car') {
      h.zone = .2 + this.rand() * .59; this.hotSide = 'Missed. Wait for the highlighted band.'; this.hear('click');
    } else { this.hotwire = null; this.notify('Signal missed', 'Soft Reset keeps the $15 entry fee.', 'warn'); this.hear('click'); }
  }
  useRelay(point, forced = false) {
    if (!forced && this.chapter < 5) { this.notify('Relay locked', 'Inez has not shared the ghost network key yet.'); return; }
    if (!forced && this.blackout?.time > 0) { this.notify('Relay cycling', 'Wait for the district to come back online.'); return; }
    this.blackout={zone:this.city.zone(point.x,point.y),time:32};
    this.heat = Math.max(0, this.heat - .75); this.sinceSeen = 5; this.stats.blackouts++;
    this.report(`Ghost relay takes ${DISTRICTS[this.blackout.zone].name} off the grid.`); this.notify('Dead air', 'The district lights went down. You have 32 seconds.', 'ok'); this.hear('confirm');
  }
  selectWeapon(n) {
    if(this.armory[n]&&this.weapon!==n){this.contactReset();this.weapon=n;this.contact.swap=GEAR[n].style==='melee'?.13:.22;this.hear('equip');}
    this.publish(true);
  }
  reload() {return reloadKit(this);}
  heal() {return handleMedkit(this);}
  fx(x, y, color, count, speed = 48, style = 'spark', direction = null) {
    if (this.settings.quality === 'Low') count = Math.ceil(count / 2);
    const a0=direction?Math.atan2(direction.y,direction.x):0;
    for (let i = 0; i < count; i++) {
      const a=direction?a0+(this.rand()-.5)*2.4:this.rand()*Math.PI*2,s=(.18+this.rand()*.82)*speed;
      const life=style==='smoke'||style==='dust'?.45+this.rand()*.64:style==='casing'?.62:.12+this.rand()*.30;
      this.particles.take({x,y,ox:x,oy:y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,style,color,life,max:life,size:1.1+this.rand()*2.6,a,twist:(this.rand()-.5)*18});
    }
  }
  light(x, y, color, radius, time) {this.lights.take({x,y,color,radius:radius*(this.settings.flashes===false?.58:1),time,max:time});}
  skid(x, y, a) { if (this.skidAt > this.clock) return; this.skidAt = this.clock + .035; this.marks.take({ x, y, a, life: 12 }); }
  breakProp(prop, amount, origin) {
    if (prop.hp <= 0) return;
    prop.hp = Math.max(0,prop.hp-amount);
    if (prop.hp <= 0) {
      if(!prop.mission)this.city.broken.add(prop.id); this.city.changed = true;
      if(materialOf(prop)==='glass'){this.fx(prop.x+prop.w/2,prop.y+prop.h/2,'#ace3e1',17,86,'shard');this.hear('glass',prop.x,prop.y,.84);}
      else {this.fx(prop.x+prop.w/2,prop.y+3,'#dbad8b',11,79,'splinter');this.hear('wood-hit',prop.x,prop.y,.65);}
      if (prop.kind === 'barrel') this.explosion(prop.x + prop.w / 2, prop.y + 3, 59, origin);
    }
  }
  explosion(x, y, strength, origin) {
    this.signalNoise(650,{x,y});
    this.emitStreetNoise(x,y,380);this.alarm=Math.max(this.alarm,2.3);
    const radius = strength + 12, p = this.player, at = { x, y };
    this.fx(x, y, '#ffb578', 34, strength * 2.5); this.fx(x, y, '#c9717b', 19, 66, 'smoke'); this.light(x, y, '#ff915b', radius * 1.55, .53);
    this.hear('explosion', x, y); if (dist(p, at) < 265) this.bump(8);
    if (dist(p, at) < radius) { const dmg = strength * (1 - dist(p, at) / radius)*blastScale(this,at,p); if (this.car) hitCar(this, this.car, dmg); else this.playerHurt(dmg,{source:at,kind:'blast'}); }
    for(const n of this.people.items)if(n.active&&!n.dead&&n.indoor===Boolean(this.room)&&dist(n,at)<radius){
      const a=Math.atan2(n.y-y,n.x-x),amount=(strength*(1-dist(n,at)/radius)+16)*blastScale(this,at,n);
      if(n.type==='target')this.practice?.hit(n,amount);else hurtPerson(this,n,amount,origin,{fx:Math.cos(a),fy:Math.sin(a),material:'cloth'});
    }
    if (!this.room) {
      for (const v of this.cars) if (v !== this.car && dist(v, at) < radius) hitCar(this, v, strength * .65, origin);
      for (const c of this.city.active) for (const q of c.props) if (dist(q, at) < radius) this.breakProp(q, strength, origin);
    }
  }
  launchBolt(x, y, a, damage, range, style, owner) {
    return spawnRound(this,x,y,a,damage,range,style,owner);
  }
  burnField(x,y,origin){
    if(!this.room&&this.city.water(x,y)){this.hear('water',x,y,.73);return;}
    this.fires.take({x,y,origin,life:4.8,emit:0,touch:0});
    this.hear('flare',x,y,1);this.light(x,y,'#fdad70',71,.84);this.fx(x,y,'#fbc28c',14,70);
  }
  updateFires(dt){
    for(const f of this.fires.items){
      if(!f.active)continue;
      f.life-=dt;f.emit-=dt;f.touch-=dt;
      if(f.life<=0){f.active=false;continue;}
      if(f.emit<=0){f.emit=.14;this.fx(f.x+(this.rand()-.5)*29,f.y+(this.rand()-.5)*21,'#ed976e',3,23,'smoke');}
      if(f.touch>0)continue;f.touch=.34;
      if(dist(this.player,f)<31){if(this.car)hitCar(this,this.car,4);else this.playerHurt(5.5);}
      for(const n of this.people.items)if(n.active&&!n.dead&&n.indoor===Boolean(this.room)&&dist(n,f)<32){
        if(n.type==='target')this.practice?.hit(n,8.5);else hurtPerson(this,n,8.5,f.origin);
      }
    }
  }
  fire(options) {return useWeapon(this,options);}
  boltsTick(dt) {tickRounds(this,dt);}
  playerTick(dt) {
    const p=this.player,input=this.input;
    p.cd-=dt;p.hit-=dt;p.stance-=dt;p.inv-=dt;
    p.recoil=(p.recoil||0)-dt;p.flash=(p.flash||0)-dt;p.flinch=(p.flinch||0)-dt;p.pump=(p.pump||0)-dt;
    updateContact(this,dt);
    if(p.vanim){p.vanim.time+=dt;if(p.vanim.time>=p.vanim.total)p.vanim=null;}
    if(this.hotwire){
      this.hotwire.t+=dt;
      if(input.hit('use'))this.timingAction();
      else if(this.hotwire.t>(this.hotwire.mode==='car'?12:8)){this.hotwire=null;this.hotSide=null;}
      return;
    }
    if(input.hit('use'))this.use();
    if(this.panel||this.transition||this.hotwire)return;
    if(input.hit('utility'))this.throwDecoy();
    if(input.hit('barricade'))this.raiseBarricade();
    if(input.hit('heal'))this.heal();
    if(this.car){p.cover=false;p.protected=false;updateDrive(this,dt);p.vx=this.car?.vx||0;p.vy=this.car?.vy||0;return;}
    const previousReload=this.contact.reload;
    if(input.hit('reload'))this.reload();
    const freshAim=this.contact.aim;
    if(!p.vanim||p.vanim.time>p.vanim.total*.53)moveOnFoot(this,dt);
    if(this.practice?.active&&this.practice.id!=='spar'){
      if(freshAim<.6&&this.contact.aim>=.6&&!this.practice.aimLesson){this.practice.aimLesson=true;this.notify('Aim steady','The reticle tightens when you brace and settle.','ok');}
      if(!previousReload&&this.contact.reload&&!this.practice.reloadLesson){this.practice.reloadLesson=true;this.notify('Reload in progress','Use the progress line below your ammunition.');}
    }
    if(input.fire)this.fire({edge:input.fireEdge});
  }
  updateTime(dt) {
    const before = Math.floor(this.day);
    this.day = mod(this.day + dt * .027, 24);
    if (Math.floor(this.day) !== before && this.properties.length) {
      const cash=this.properties.reduce((sum,id)=>sum+(HOLDINGS[id]?.rate||0),0);
      if(cash){this.bankBalance+=cash;this.notify('Property income',`$${cash} credited to Vesper Trust.`,'ok');this.report('The property ledger settles an hourly payment.');}
    }
    this.weatherTimer -= dt;
    const raining=this.weather===1||this.weather===3;
    this.weatherStyle.wet=mix(this.weatherStyle.wet,raining?1:0,dt*(raining?.42:.056));
    if (this.weatherTimer <= 0) { this.weatherTimer = 74 + this.rand() * 58; this.weather = (this.weather + 1 + Math.floor(this.rand() * 3)) % WEATHER.length; this.notify('Harbor forecast', WEATHER[this.weather]); }
    this.lightning = Math.max(0, this.lightning - dt * 2.2);
    if (this.weather === 3 && !this.room) {
      this.thunder -= dt;
      if (this.thunder <= 0) { this.lightning = .53; this.thunder = 5 + this.rand() * 9; this.hear('thunder'); }
    }
    if (this.blackout) { this.blackout.time -= dt; if (this.blackout.time <= 0) { this.blackout = null; this.report('Utility reports overnight street service restored.'); } }
  }
  cycleRadio() {
    this.station = this.station >= STATIONS.length - 1 ? -1 : this.station + 1;
    const s = STATIONS[this.station]; this.notify(s ? `${s.dial} / ${s.name}` : 'Radio off', s?.blurb || 'Only the city now.');
    this.radioTimer = 29; this.sound.jingle?.(this.station);
  }
  radioTick(dt) {
    if (!this.car || this.station < 0) return;
    this.radioTimer = Math.max(0, this.radioTimer - dt);
    if (this.radioTimer > 0 || this.heat > 0 || this.line || this.note) return;
    const s = STATIONS[this.station];
    this.notify(s.name, s.segments[this.radioCue++ % s.segments.length]);
    this.radioTimer = 35; this.sound.jingle?.(this.station);
  }
  cameraTick(dt) {
    const p = this.player, c = this.camera;
    c.ox = c.x; c.oy = c.y;
    let x = this.room ? this.interior.anchor.x : p.x + (this.car ? this.car.vx * .21 : 0), y = this.room ? this.interior.anchor.y : p.y + (this.car ? this.car.vy * .21 : 0);
    if (this.focus) {
      const f = this.focus; f.time -= dt;
      const amount = clamp(Math.min(f.time, f.limit - f.time) * 2.9, 0, .6);
      x = mix(x, f.x, amount); y = mix(y, f.y, amount);
      if (f.time <= 0) this.focus = null;
    }
    if(this.briefing){
      const b=this.briefing;b.time-=dt;
      const t=clamp(1-b.time/b.total,0,1),fade=Math.sin(t*Math.PI);
      x+=b.panX*fade;y+=b.panY*fade;
      if(b.time<=0)this.briefing=null;
    }
    c.x = mix(c.x, x, dt * (this.room ? 10 : 6.7)); c.y = mix(c.y, y, dt * (this.room ? 10 : 6.7));
    const airZoom=this.car?.model.class==='AIR'?.96-clamp(this.car.speed/1910,0,.16)-clamp(this.car.alt/540,0,.22):0;
    const targetZoom=this.room?this.interior.scale:airZoom||(this.car?.model?.96-clamp(this.car.speed/1910,0,.21):this.briefing?1.09:1.17);
    c.zoom=mix(c.zoom,targetZoom,dt*4);
  }
  tick(dt) {
    this.input.poll();
    if(this.flight){travelTick(this,dt);this.input.endTick();return;}
    if (this.panel) {
      if(this.panel==='table'){
        tickTable(this,dt);
        if(this.input.hit('use'))tableTrigger(this);
        this.tableViewAt=(this.tableViewAt||0)-dt;
        if(this.tableViewAt<=0){this.tableViewAt=1/30;this.publish(true,true);}
      }
      if (!this.outbreak?.dead && (this.input.hit('pause') || this.panel === 'map' && this.input.hit('map') || this.panel === 'phone' && this.input.hit('phone'))) this.open(null);
      this.input.endTick(); return;
    }
    const i = this.input;
    if(i.hit('pause')){if(this.briefing){this.briefing=null;return;}if(this.hotwire)this.hotwire=null;else this.open('pause');return;}
    if (i.hit('map')) { this.open(this.practice?'practice':'map'); return; }
    if (i.hit('phone')) { this.open(this.practice?'practice':'phone'); return; }
    if (i.hit('wheel')) { if (!this.car && !this.hotwire) { this.open('wheel'); return; } }
    if (i.hit('debug')) { this.debug = !this.debug; this.publish(true); }
    if (i.hit('save')) this.save();
    if (i.hit('radio')) this.cycleRadio();
    if(i.hit('camera'))this.cycleView();
    if(this.briefing&&(i.fire||i.held('up')||i.held('down')||i.held('left')||i.held('right')||i.held('dash')))this.briefing=null;
    for (let n = 1; n <= 10; n++) if (i.consume(`Digit${n % 10}`) && !this.car && this.armory[n - 1]) this.selectWeapon(n - 1);
    this.clock += dt; this.stats.playtime += dt; this.alarm = Math.max(0, this.alarm - dt); this.shake = Math.max(0, this.shake - dt * 17); this.jump -= dt;
    if (this.note && (this.note.time -= dt) <= 0) this.note = null;
    if (this.line && (this.line.time -= dt) <= 0) this.line = null;
    savePos(this.player); for (const v of this.cars) savePos(v); for (const n of this.people.items) if (n.active) savePos(n);
    if (this.transition) {
      this.transition.time += dt;
      if (this.transition.time >= .32 && !this.transition.swapped) { this.transition.swapped = true; this.swapRoom(this.transition.id); }
      if (this.transition.time >= .64) this.transition = null;
    } else this.playerTick(dt);
    if (!this.room) {
      this.city.stream(this.player.x, this.player.y);
      const placeNear = PLACES.find(p => !this.discovered.has(p.id) && dist(this.player, p) < 150);
      if(placeNear){this.discovered.add(placeNear.id);if(this.chapter>0||this.mode==='atlas')this.notify('Location discovered',placeNear.name);}
      if (this.waypoint && dist(this.waypoint, this.player) < 31) this.waypoint = null;
    }
    this.seedRegionalTraffic();updateActors(this, dt);
    if(this.outbreak){this.updateDecoys(dt);updateOutbreak(this,dt);if(this.city.playerProps.some(p=>p.hp<=0))this.city.playerProps=this.city.playerProps.filter(p=>p.hp>0);}else if(!this.practice)updateWanted(this,dt);
    if(!this.practice&&this.clock>(this.skillsAt||0)){this.skillsAt=this.clock+1;this.skillTick();}
    this.boltsTick(dt);this.updateFires(dt);if(this.practice)this.practice.tick(dt);else if(!this.outbreak){updateMission(this, dt);updateJob(this, dt);updateAmbient(this, dt);}this.updateTime(dt);this.radioTick(dt);
    for(const b of this.particles.items)if(b.active){b.ox=b.x;b.oy=b.y;b.x+=b.vx*dt;b.y+=b.vy*dt;b.a+=(b.twist||0)*dt;
      const friction=Math.exp(-dt*(b.style==='smoke'?1.2:b.style==='drop'?4.8:3));b.vx*=friction;b.vy*=friction;b.life-=dt;if(b.life<=0)b.active=false;}
    for(const s of this.scars.items)if(s.active&&(s.life-=dt)<=0)s.active=false;
    for (const b of this.lights.items) if (b.active && (b.time -= dt) <= 0) b.active = false;
    for (const b of this.marks.items) if (b.active && (b.life -= dt) <= 0) b.active = false;
    this.cameraTick(dt);
    this.autosave -= dt;
    if (this.autosave <= 0) { this.autosave = 23; if(!this.practice)this.save(true); }
    this.publish(); i.endTick();
  }
  seedRegionalTraffic(){
    if(this.room||this.outbreak)return;
    const p=this.player;
    if(dist(p,{x:7324,y:4508})<620&&!this.cars.some(v=>v.publicLaunch||v.model.class==='BOAT'&&dist(v,p)<510)&&this.stage()?.model!=='launch')
      addCar(this,14,7324,4508,0,'parked',{owned:true,keep:true,publicLaunch:true});
    seedAtlasVehicles(this,addCar);
  }
  draw(alpha, fps) {
    if (!this.panel || this.drawnPanel !== this.panel || this.drawnRev !== this.renderRev || this.renderer.dirty) {
      this.renderer.draw(this.panel ? 1 : alpha, fps);
      this.drawnPanel = this.panel; this.drawnRev = this.renderRev;
    }
    if(this.clock-(this.lastAudio||-1)>.08||this.panel!==this.audioPanel){this.lastAudio=this.clock;this.audioPanel=this.panel;this.sound.advance(this,Boolean(this.panel));}
  }
  statsData() {
    return { ...this.stats, skills: { ...this.skills }, rep: { ...this.rep } };
  }
  prompt() {
    const p = this.player, s = this.stage(), m = this.missionState;
    if (this.hotwire) return '';
    if(this.flight)return '';
    if(this.practice)return this.practice.near()||!this.practice.active?this.practice.offer():'';
    const specialPrompt=outbreakPrompt(this);
    if(specialPrompt)return specialPrompt;
    if(this.outbreak&&!this.outbreak.used.includes('shelter')&&dist(p,QUARANTINE_START)<10)return '';
    const current = marker(this), job = jobMarker(this);
    if (current && dist(p, current) < (s.kind === 'pursue' ? 73 : 46)) {
      if (s.kind === 'pursue' && m.ride && (m.progress > .75 || m.ride.hp < 18)) return 'Tag courier';
      if (!this.room&&['use','survey'].includes(s.kind) || s.kind === 'choice' && (!s.room || this.room === s.room)) return s.label;
      if(s.kind==='take'&&m.ride&&dist(m.ride,p)<44)return `Board ${m.ride.model.name}`;
      if (this.room && s.kind === 'room' && this.room === s.room) return s.label;
    }
    if (job && dist(p, job) < 53 && ['taxi','delivery','catalog'].includes(this.job.kind)) return 'Handle contract stop';
    if(job&&dist(p,job)<45&&this.job.kind==='recover')return job.label;
    if(job&&this.job.kind==='service'&&this.car===this.job.ride&&this.job.idx>0&&!this.job.flight&&dist(p,job)<55)return job.label;
    if(job&&this.job.kind==='photo'&&dist(p,job)<104)return 'Capture landmark in Photo mode';
    if (this.car) return this.car.model.class==='BOAT'?'Disembark':'Exit vehicle';
    if (this.room) {
      if (dist(p, this.interior.exit) < 34) return 'Return to the street';
      const spot=this.roomSpot();if(spot)return spot.name;
      if (dist(p, this.interior.service) < 42) return ['switch','coast'].includes(this.room) ? 'Activate ghost relay' : ['relay','shelter'].includes(this.room) ? 'Customize Mara' : place(this.room)?.kind==='METRO'?'Read metro timetable':'Use counter';
      return '';
    }
    const street=streetMarker(this);if(street&&dist(p,street)<34)return street.label;
    const survey=surveyNearby(this);if(survey)return this.surveys.has(survey.id)?'Read surveyed beacon':`Log ${survey.label.toLowerCase()}`;
    const {door:where,ride:v}=this.streetAccess();
    if (this.tapeNear()) return 'Recover lost frequency';
    if(where)return where.id==='bay'&&this.outbreak?'Training Bay closed':`Enter ${where.name}`;
    if (v) return `${v.owned || v.jacked || this.outbreak ? 'Enter' : 'Unlock'} ${v.model.name}`;
    if(this.vendorNear())return 'Browse the roadside stall';
    return '';
  }
  publish(force = false, stateOnly = false) {
    if (!force && this.clock - this.lastDisplay < .09) return;
    if (force&&!stateOnly) this.renderRev++;
    this.lastDisplay = this.clock;
    const p = this.player, objective = this.objectiveMarker(), target = objective || jobMarker(this), mission = this.campaign[this.chapter], s = this.stage(), m = this.missionState, o=this.outbreak;
    const slot = this.armory[this.weapon], dim = this.room ? this.outside : p;
    const special = contractStatus(this) || (s?.kind === 'defend' && m.started ? `HOLD / ${Math.ceil(s.duration - m.clock)}s` : s?.kind === 'race' && m.started ? `GATE ${m.gate + 1}/${s.gates.length} / ${Math.ceil(m.clock)}s` : s?.stealth && this.room === s.room ? `SUSPICION / ${Math.min(100, Math.round(m.suspicion * 100))}%` : this.job?.kind === 'race' && this.job.started ? `CONTRACT / ${Math.ceil(this.job.clock)}s` : s?.kind==='survey'?`READERS / ${m.gate} OF ${s.nodes.length}`:s?.kind==='clear'&&m.barriers?`CLEARED / ${m.barriers.filter(b=>b.hp<=0).length} OF ${m.barriers.length}`:'');
    const region=regionOf(dim.x,dim.y), c=this.contact, h=profile(this);
    const contactLabel=this.car?'':c.heal?'TREATING':c.reload?c.reload.type==='tube'?'LOADING SHELLS':'RELOADING':c.throwing?'WINDUP':c.swing?c.swing.time<c.swing.wind?'WINDUP':'RECOVERY':c.guard>.48?'GUARD':p.protected?'COVER':c.aim>.43?'BRACED':c.swap>0?'READYING':'';
    this.send({ health: Math.ceil(p.hp), armor: Math.ceil(p.armor), stamina: Math.round(p.stamina), cash: this.cash, medkits: this.medkits, heat: Math.ceil(this.heat), seen: this.seen,
      mode:this.mode,region,regionName:ATLAS_LABELS[region],total:this.campaign.length,title:this.practice?this.practice.spec.name:o?'Outbreak':mission?.title||ATLAS_LABELS[region],chapter:this.chapter,objective:this.practice?this.practice.spec.intro:objective?.label||(o?'Ferry secured. See how long you can hold out.':region==='wilds'?'Follow a highway, or log a survey station.':'Explore the city or pick up a regional contract.'),distance:target?Math.round(dist(target,p)/1.65):null,
      district:this.room?place(this.room).name:DISTRICTS[this.city.zone(p.x,p.y)].name,time:timecode(this.day),weather:WEATHER[this.weather],vehicle:this.car?.model.name,
      speed: this.car ? Math.round(this.car.speed * .41) : null, integrity: this.car ? Math.round(100 * this.car.hp / this.car.model.hp) : null, station: this.station,
      weapon: this.weapon, ammo: slot.mag, store: slot.stash, reloading: this.pendingReload > 0, prompt: this.prompt(), line: this.line, note: this.note, special,
      control: keyName(this.binding('use')), room: this.room, location: { x: dim.x, y: dim.y }, waypoint: this.waypoint, unlocked: Object.keys(this.armory).map(Number),
      hotwire: this.hotwire ? { needle: this.timing(), zone: this.hotwire.zone, mode: this.hotwire.mode, help: this.hotSide } : null, debug: this.debug,
      news:this.news,save:readSave(this.mode)!==null,shot:p.hit>0,job:this.job?.name||null,pad:iLabel(this.input),blackout:this.blackout?.zone===this.city.zone(dim.x,dim.y),
      ending: endingLine(this), discovered: [...this.discovered], shop: this.room && place(this.room)?.kind, bank: this.bankBalance, properties: this.properties, rep: this.rep, territory: this.territory,
      keys: Object.fromEntries(Object.keys(CONTROLS).map(key => [key, keyName(this.binding(key))])), look: { color: p.color, hair: p.hair, skin: p.skin,outfit:p.outfit||0 }, tutorial: this.mode==='campaign'&&this.chapter === 0 && this.stats.driven < 95,
      armored:this.car?.model.class==='TANK', outbreak:o?{score:o.score,kills:o.kills,beacons:o.signal.length,time:o.clock,phase:o.phase,noise:Math.round(o.noise/650*100),dead:o.dead,escaped:o.escaped,best:this.best?.score||0}:null,
      alert:this.dispatch?.stage||'PATROL',table:tableView(this),records:this.records,altitude:this.car?.model.class==='AIR'?Math.round(this.car.alt):null,
      decoys:this.decoys,boards:this.boards,view:this.view,photoJob:this.job?.kind==='photo',interior:this.interior?.subtitle||null,
      perks:this.perks,market:['swapmeet','dock'].includes(this.room)?MARKET_GOODS.map((item,i)=>({...item,...this.quote(i)})):[],
      contact:{label:contactLabel,mode:h.mode,cue:h.cue,progress:c.heal?c.heal.elapsed/c.heal.total:c.reload?c.reload.elapsed/c.reload.total:null,spread:weaponSpread(this)},
      practice:this.practice?.snapshot()||null,inbox:this.inbox,clothes:this.clothes,
      faction:this.practice||this.outbreak?null:(()=>{const team=this.territory[this.city.zone(dim.x,dim.y)];return{team,standing:factionDisposition(this,team)};})(),
      atlas:{charted:this.city.charted.size,surveys:this.surveys.size,key:this.worldKey,style:this.city.style},tableRoll:this.tableRoll,
    });
  }
  buy(action, value) {
    const spend = (amount, line) => {
      if (this.cash < amount) { this.notify('Insufficient cash', `Need $${amount}.`, 'warn'); this.publish(true); return false; }
      this.cash -= amount; this.notify('Transaction complete', line, 'ok'); this.hear('confirm'); return true;
    };
    const near = this.outside || this.player;
    if (action === 'gear') {
      const g = GEAR[value]; if (!g) return;
      if (!this.armory[value] && spend(g.price, g.name)){this.armory[value]=itemData(value);if(g.mag)this.ammo(g.ammo,g.mag*4);}
      else if(this.armory[value]&&g.mag&&spend(32,`${g.ammo} ammunition`))this.ammo(g.ammo,g.mag*3);
    }
    if(action==='outfit'&&WARDROBE[value]){
      const outfit=WARDROBE[value];
      if(this.clothes.includes(value))this.player.outfit=value;
      else if(spend(outfit.price,outfit.name)){this.clothes.push(value);this.player.outfit=value;}
    }
    if (action === 'kits' && spend(38, 'Medkit added')) this.medkits++;
    if (action === 'armor' && spend(55, 'Armor replenished')) this.player.armor = 100;
    if (action === 'food' && spend(18, 'Vitality restored')) this.player.hp = Math.min(100, this.player.hp + 34);
    if(action==='cha'&&spend(12,'Hot milk tea. Stamina restored.')){this.player.stamina=100;this.player.hp=Math.min(100,this.player.hp+16);}
    if(action==='fruit'&&spend(16,'Fresh fruit. Vitality restored.'))this.player.hp=Math.min(100,this.player.hp+25);
    if(action==='jetty'){this.setWaypoint(7324,4482);this.open(null);}
    if (action === 'treat' && spend(45, 'Treatment complete')) this.player.hp = 100;
    if (action === 'deposit' && this.cash >= 100) { this.cash -= 100; this.bankBalance += 100; }
    if (action === 'withdraw' && this.bankBalance >= 100) { this.cash += 100; this.bankBalance -= 100; }
    if (action === 'property' && !this.properties.includes('loft') && spend(680, 'Morrow Loft purchased')) { this.properties.push('loft'); this.report('Morrow Loft lists a new owner in Lark Terraces.'); }
    if(action==='holding'){
      const id=value===0?'ghat-counter':'lake-stall',item=HOLDINGS[id];
      if(this.room===(value===0?'ghat':'lake')&&!this.properties.includes(id)&&spend(item.price,`${item.name} purchased`)){this.properties.push(id);this.report(`${item.name} lists a new operator.`);}
    }
    if (action === 'fine' && this.heat > 0 && spend(180, 'Dispatch clears outstanding alerts')) this.heat = 0;
    if (action === 'car' && GARAGE[value] && GARAGE[value].class!=='BOAT' && spend(GARAGE[value].price, `${GARAGE[value].name} parked outside`)) {
      const x=near.x+37,y=near.y-38;
      this.cars.filter(v=>v.purchased&&v!==this.car&&dist(v,{x,y})<50).forEach(v=>{v.keep=false;v.x+=75;});
      this.lastOwned=addCar(this,value,x,y,0,'parked',{owned:true,keep:true,purchased:true});
    }
    if (['repair','paint','upgrade','plate'].includes(action)) {
      const v = this.cars.filter(v => !v.wreck && dist(near, v) < 145).sort((a,b) => dist(a, near) - dist(b, near))[0];
      if (!v) this.notify('No vehicle nearby', 'Park a vehicle near the door before visiting Motorworks.', 'warn');
      else if (action === 'repair' && spend(65, 'Bodywork restored')) {v.hp=v.model.hp;v.fire=0;v.scuffs=[];v.glassHit=false;v.tireWear=0;}
      else if(action==='paint'&&GARAGE_PAINT[value??0]&&spend(35,'New paint applied'))v.color=GARAGE_PAINT[value??0].color;
      else if (action === 'upgrade' && !v.boost && spend(165, 'Performance kit installed')) v.boost = 1;
      else if(action==='plate'&&spend(35,'Custom plate registered'))v.plate=typeof value==='string'?value.toUpperCase().replace(/[^A-Z0-9-]/g,'').slice(0,7)||'GHOST':'GHOST';
    }
    if (action === 'arcade' && spend(15, 'Match the scanner band to win $65')) { this.open(null); this.hotwire = { t: 0, zone: .26 + this.rand() * .45, mode: 'arcade' }; }
    if (action === 'rest') { this.player.hp = 100; this.player.stamina = 100; this.day = mod(this.day + 2, 24); this.notify('Rested', 'Two hours passed in Vesper Bay.', 'ok'); }
    this.save(true); this.publish(true);
  }
  action(type, value) {
    if(type==='fare-air'||type==='fare-sea'){buyTicket(this,type.endsWith('air')?'air':'sea',value);return;}
    if(type==='jacklight'){tablePlay(this);return;}
    if(type==='club-talk'){clubTalk(this,value);return;}
    if(type==='start-ember'&&this.room==='ember'){startJob(this,'fort-relief');return;}
    if(type==='drill'&&this.practice){this.practice.setup(value);return;}
    if(type==='briefing'&&!this.practice){
      const mission=this.campaign[this.chapter];
      if(mission){
        this.open(null);
        const p=this.player,goal=this.objectiveMarker()||p,a=Math.atan2(goal.y-p.y,goal.x-p.x),span=this.room?12:84;
        if(this.settings.motion)this.briefing={title:mission.title,time:4.6,total:4.6,panX:Math.cos(a)*span,panY:Math.sin(a)*span};
        this.say(mission.brief,7.5);
      }
    }
    if(type==='job'&&!this.outbreak&&!this.practice)startJob(this,value);
    if (type === 'choose') selectChoice(this, value);
    if (type === 'weapon') { this.open(null); this.selectWeapon(value); }
    if(type==='look'&&value&&typeof value==='object'){
      const {outfit,...changes}=value;Object.assign(this.player,changes);
      if(this.clothes.includes(outfit))this.player.outfit=outfit;
      this.save(true);
    }
    if (type === 'radio') this.cycleRadio();
    if (type === 'save') this.save();
    if(type==='table-play'&&this.panel==='table')tableTrigger(this);
    if(type==='table-again'&&this.table&&this.panel==='table')this.table=newTable(this,this.table.id);
    if(type==='throw-decoy'&&!this.panel)this.throwDecoy();
    if(type==='barricade'&&!this.panel)this.raiseBarricade();
    if(type.startsWith('table-')&&Number.isFinite(value))adjustTable(this,type,value);
    if(type==='photo-zoom'){this.photoZoom=clamp(value||1,.6,1.65);this.renderer.dirty=true;}
    if(type==='photo-compose'){this.open('photo');this.photoZoom=1;}
    if(type==='photo-frame'){if(recordStreetPhoto(this))this.open(null);}
    if(type==='trade-buy'||type==='trade-sell')this.trade(Number(value),type==='trade-sell');
    if(type==='trade-open'&&['swapmeet','dock'].includes(this.room))this.open('exchange');
    if(type==='dispatch-pin'){const location=place(value);if(location?.kind==='SWAP MEET'||location?.kind==='EXCHANGE'){this.setWaypoint(location.x,location.y);this.open(null);}}
    if(type==='transit'&&!this.outbreak&&place(this.room)?.kind==='METRO'){
      const target=place(value);
      if(target?.kind==='METRO'&&this.cash>=8){
        this.cash-=8;this.day=mod(this.day+.17,24);this.room=null;this.interior=null;this.outside=null;this.discovered.add(target.id);
        this.teleport(target.x,target.y-17);this.open(null);this.notify('Metro arrival',target.name,'ok');this.save(true);
      }
    }
    if (type === 'photo') this.canvas.toBlob(blob => { if (!blob) return; const url = URL.createObjectURL(blob), link = document.createElement('a'); link.href = url; link.download = 'static-harbor.png'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 8000); });
    this.publish(true);
  }
  cycleView(){this.view=(this.view+1)%3;this.notify('Camera view',['Street / default','Street / close','Street / wide'][this.view]);}
  dev(type, value) {
    const p = this.player;
    if(type==='cash')this.cash+=1000;
    if(type==='street'){
      if(debugStreetEvent(this,value)){this.notify('Street event started',this.streetEvent.kind,'ok');this.open(null);}
      else this.notify('Event unavailable','Leave the room or wait for the current event to finish.','warn');
    }
    if (type === 'heal') { p.hp = 100; p.armor = 100; this.medkits += 2; }
    if (type === 'spawn') {
      if (this.room) this.swapRoom(null);
      this.arrivalDoor=null;
      let x = p.x + 43, y = p.y;
      const model=GARAGE[Number(value)]||GARAGE[0],front=model.l*.5+12;
      const options=[[front,0],[-front,0],[0,model.w*.5+19],[0,-model.w*.5-19],[front+20,-32]];
      for(const [dx,dy] of options){x=p.x+dx;y=p.y+dy;if(!this.city.block(x,y,model.w*.5)&&!this.city.water(x,y)&&!this.cars.some(v=>dist(v,{x,y})<v.r+model.w*.51+3))break;}
      const boat=GARAGE[Number(value)]?.class==='BOAT';
      if(boat){[x,y]=FERRY_POINTS[0];this.teleport(x,y-23);}
      addCar(this, Number(value), x, y, 0, 'parked', { owned: true });
    }
    if (type === 'heat'&&!this.outbreak) { this.heat = clamp(Number(value), 0, 5); this.lastSeen = this.outside || { x: p.x, y: p.y }; this.policeTimer = 0; this.sinceSeen = 0; }
    if (type === 'weather') { this.weather = clamp(Number(value), 0, 3); this.weatherTimer = 138; }
    if (type === 'time') this.day = clamp(Number(value), 0, 23.99);
    if(type==='teleport'){
      const where=place(value);if(where){if(this.room)this.swapRoom(null);this.teleport(where.x,where.y-18);this.arrivalDoor={id:where.id,until:this.clock+.85};}
    }
    if(type==='arsenal'){const kit=hydrateKit(null,Object.fromEntries(GEAR.map((_,n)=>[n,itemData(n)])));this.armory=kit.slots;this.ammoPools=kit.reserve;}
    if (type === 'chapter'&&this.campaign.length) { const n = clamp(Number(value), 0, this.campaign.length - 1); this.chapter = n; this.step = 0; newStage(this); this.say(this.campaign[n].brief); }
    this.publish(true); this.hear('click');
  }
}

const iLabel = input => input.pad ? 'GAMEPAD' : 'KEYBOARD';