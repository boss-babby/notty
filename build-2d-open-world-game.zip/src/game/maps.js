import { CELL, DISTRICTS, PLACES } from './data.js';
import { buildChunk, districtAt, roadPath } from './world.js';
import { METRO_LINE, legacyCell, roadConnection } from './geography.js';
import { waterMask } from './monsoon-world.js';
import { jobMarker } from './campaign.js';
import { BEACONS, CACHES, EVAC } from './outbreak.js';
import { streetMarker } from './street-events.js';
import { ATLAS_CHARTS, ATLAS_LABELS } from './atlas-data.js';
import { originalCell, outerWater } from './frontier-geo.js';

const tinted=['#432d40','#4c373d','#30463e','#2e4254','#3b3352','#334b51','#465443','#565048','#38575c','#43495e','#5b4746','#515840','#5b4246'];
export const ATLAS_REGIONS=ATLAS_CHARTS;
let cachedMap=null,cachedSeed=null,cachedStyle=null;
const paths=new Map();

function routeFor(from,to,seed,style){
  const key=[Math.round(from.x/CELL),Math.round(from.y/CELL),Math.round(to.x/CELL),Math.round(to.y/CELL),seed,style].join(':');
  if(!paths.has(key)){
    paths.set(key,roadPath(from,to,seed,style));
    if(paths.size>36)paths.delete(paths.keys().next().value);
  }
  return paths.get(key);
}

function trace(c,from,to,color,width,route=true,seed,style) {
  c.strokeStyle=color;c.lineWidth=width;c.setLineDash([15,18]);
  c.beginPath();c.moveTo(from.x,from.y);
  const d=Math.hypot(to.x-from.x,to.y-from.y);
  if(route&&d>330&&d<14500)for(const p of routeFor(from,to,seed,style))c.lineTo(p.x,p.y);
  c.lineTo(to.x,to.y);c.stroke();c.setLineDash([]);
}

function field(g,seed,visible=null,style='continental',charted=null){
  const paint=(x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(x,y,w,h);};
  const fromX=visible?Math.floor(visible[0]/CELL):-3,toX=visible?Math.floor(visible[2]/CELL):35;
  const fromY=visible?Math.floor(visible[1]/CELL):-3,toY=visible?Math.floor(visible[3]/CELL):21;
  for(let j=fromY;j<=toY;j++)for(let i=fromX;i<=toX;i++){
    const x=i*CELL,y=j*CELL;
    const zone=districtAt(i,j,seed,style),d=DISTRICTS[zone];
    if(!originalCell(i,j)){
      const chunk=buildChunk(i,j,seed,new Set(),style), known=!charted||charted.has(`${i}:${j}`);
      paint(x,y,CELL,CELL,d.ground);
      for(let v=0;v<CELL;v+=80)for(let u=0;u<CELL;u+=80)if(outerWater(x+u+40,y+v+40,seed,style))paint(x+u,y+v,80,80,'#365b6e');
      const [n,e,s,w]=chunk.roads;
      if(n)paint(x,y,CELL,n,'#3b3847');if(s)paint(x,y+CELL-s,CELL,s,'#3b3847');if(w)paint(x,y,w,CELL,'#3b3847');if(e)paint(x+CELL-e,y,e,CELL,'#3b3847');
      const urban=!['dunes','canyon','salt','oasis','islands','juniper','sea'].includes(chunk.type);
      if(urban){
        paint(x+44,y+44,392,392,d.color+'1a');
        for(let v=68;v<440;v+=67){
          paint(x+v,y+50,2,380,'#e7c8a63d');paint(x+50,y+v,380,2,'#e7c8a63d');
        }
        paint(x+208,y+62,64,3,d.color+'88');paint(x+208,y+415,64,3,d.color+'88');
      }
      for(const b of chunk.blocks)paint(b.x,b.y,b.w,b.h,b.kind==='rock'?'#5e4957':urban?'#f3d8ae77':'#d9bd9d65');
      for(const p of chunk.pools)paint(x+p.x,y+p.y,p.w,p.h,'#69a49da2');
      if(chunk.poi){paint(x+chunk.poi.x-33,y+chunk.poi.y-37,66,59,d.color+'a8');paint(x+chunk.poi.x-8,y+chunk.poi.y-2,16,12,'#f4e7c8');}
      if(!known)paint(x,y,CELL,CELL,zone>=23?'#151321b8':'#1513214f');
      continue;
    }
    paint(x,y,CELL,CELL,'#1c1a29');paint(x+39,y+39,402,402,tinted[zone]);
    const old=legacyCell(i,j);
    if(old&&(i===7||i===9)) {
      paint(x+63,y+(i===7?44:0),i===7?354:417,i===7?392:CELL,'#243249');
      if(i===7){paint(x+66,y+210,88,25,'#7c646a');paint(x+65,y+37,350,5,'#928086');}
      else paint(x+62,y+223,170,26,'#857068');
    }else{
      const chunk=buildChunk(i,j,seed);
      if(chunk.type==='park'||chunk.type==='fields'){
        paint(x+80,y+86,309,310,chunk.type==='fields'?'#617a5138':'#7499872c');
        if(chunk.type==='fields')for(let n=88;n<391;n+=37)paint(x+n,y+88,8,304,'#acc38845');
      }
      if(!old) {
        paint(x+58,y+232,368,9,'#b5a6952e');paint(x+227,y+57,8,358,'#b5a69526');
      }
      for(const b of chunk.blocks)paint(b.x,b.y,b.w,b.h,old?'#ad99ab1e':'#c4ae9828');
    }
    for(let k=65;k<CELL;k+=74){paint(x+k,y,22,3,'#92839762');paint(x,y+k,3,22,'#92839762');}
  }
  const l=Math.max(9,fromX)*CELL,t=Math.max(0,fromY)*CELL,w=(Math.min(21,toX)-Math.max(9,fromX)+1)*CELL,h=(Math.min(11,toY)-Math.max(0,fromY)+1)*CELL;
  if(w>0&&h>0){g.save();g.translate(l,t);waterMask(g,[l,t,w,h],visible?48:23,false,true);g.restore();}
  if(toX>=13&&fromX<=17&&fromY<=7){
    g.beginPath();g.moveTo(...METRO_LINE[0]);for(let i=1;i<METRO_LINE.length;i++)g.lineTo(...METRO_LINE[i]);g.strokeStyle='#8fd6c481';g.lineWidth=13;g.stroke();
  }
  for(let j=Math.max(1,fromY);j<=Math.min(11,toY);j++)for(let i=Math.max(1,fromX);i<=Math.min(21,toX);i++){
    if(i<9)continue;
    const x=i*CELL,y=j*CELL;
    if(roadConnection(i,j,i+1,j))paint(x,y-3,CELL,6,'#c4afa849');
    if(roadConnection(i,j,i,j+1))paint(x-3,y,6,CELL,'#c4afa849');
  }
}

function atlasImage(seed,style='continental'){
  if(cachedMap&&cachedSeed===seed&&cachedStyle===style)return cachedMap;
  const c=document.createElement('canvas');c.width=1776;c.height=1134;
  const g=c.getContext('2d');if(!g)return null;
  const [x,y,w,h]=ATLAS_REGIONS.world;
  g.scale(c.width/w,c.height/h);g.translate(-x,-y);field(g,seed,[x,y,x+w,y+h],style);cachedMap=c;cachedSeed=seed;cachedStyle=style;return c;
}

export function primeAtlas(seed,style){
  const warm=()=>atlasImage(seed,style);
  if(typeof globalThis.requestIdleCallback==='function')globalThis.requestIdleCallback(warm,{timeout:1200});
  else setTimeout(warm,120);
}

function dot(g,x,y,r,color,style=false){
  g.fillStyle='#11101c';g.beginPath();g.arc(x,y,r*1.52,0,Math.PI*2);g.fill();
  g.fillStyle=color;g.beginPath();
  if(style){g.moveTo(x,y-r);g.lineTo(x+r,y);g.lineTo(x,y+r);g.lineTo(x-r,y);g.closePath();}
  else g.arc(x,y,r,0,Math.PI*2);
  g.fill();
}
const objColor=g=>g.outbreak?'#d4f0a2':g.mode==='monsoon'?'#f9c081':g.settings.contrast?'#ffd081':'#ff668c';

export function fullMap(canvas,s,game,region='world',zoom=1,control=false,pan=[0,0]){
  const dpr=Math.min(2,globalThis.devicePixelRatio||1),box=canvas.getBoundingClientRect();
  canvas.width=Math.max(1,Math.round(box.width*dpr));canvas.height=Math.max(1,Math.round(box.height*dpr));
  const ctx=canvas.getContext('2d');if(!ctx)return null;
  const far=region==='frontier';
  const [l,t,w,h]=far?[s.location.x-1780+(pan[0]||0),s.location.y-1220+(pan[1]||0),3560,2440]:ATLAS_REGIONS[region]||ATLAS_REGIONS.world;
  const base=Math.min(canvas.width/w,canvas.height/h)*.92,scale=base*zoom;
  const inside=s.location.x>=l&&s.location.x<l+w&&s.location.y>=t&&s.location.y<t+h;
  const cx=zoom>1&&inside?Math.max(l+w*.5/zoom,Math.min(l+w-w*.5/zoom,s.location.x)):l+w/2;
  const cy=zoom>1&&inside?Math.max(t+h*.5/zoom,Math.min(t+h-h*.5/zoom,s.location.y)):t+h/2;
  const left=canvas.width/2-cx*scale,top=canvas.height/2-cy*scale;
  ctx.fillStyle='#151122';ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.setTransform(scale,0,0,scale,left,top);
  ctx.save();ctx.beginPath();ctx.rect(l,t,w,h);ctx.clip();
  const style=game.city.style,seed=game.city.seed,[wx,wy,ww,wh]=ATLAS_REGIONS.world;
  if(far)field(ctx,seed,[l,t,l+w,t+h],style,game.city.charted);
  else{const atlas=atlasImage(seed,style);if(atlas){ctx.imageSmoothingEnabled=false;ctx.drawImage(atlas,wx,wy,ww,wh);}}
  const font=(region==='world'?9:10)*dpr/scale, halo=1.75*dpr/scale;
  ctx.font=`800 ${font}px monospace`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.lineWidth=halo;ctx.strokeStyle='#211927';
  for(const [i,d] of DISTRICTS.entries()){
    if(!d.label)continue;
    if(region==='world'&&!control&&zoom===1)continue;
    const [x,y]=d.label.map(v=>v*CELL); if(x<l||x>l+w||y<t||y>t+h)continue;
    ctx.fillStyle=d.color;ctx.strokeText(d.name.toUpperCase(),x,y);ctx.fillText(d.name.toUpperCase(),x,y);
    if(control){ctx.font=`650 ${font*.72}px monospace`;const fact=s.territory[i]||d.faction;ctx.strokeText(fact.toUpperCase(),x,y+font*1.46);ctx.fillText(fact.toUpperCase(),x,y+font*1.46);ctx.font=`800 ${font}px monospace`;}
  }
  if(region==='world'&&!control&&zoom===1){
    const cities=[['harbor',2430,1340,'#e2aac5'],['monsoon',8040,1640,'#e6c3a0'],['mirage',13470,1330,'#abd7ce'],['basin',13170,7315,'#efabd0']];
    ctx.textAlign='center';ctx.font=`800 ${font*1.47}px monospace`;
    for(const [id,x,y,col] of cities){ctx.fillStyle=col;ctx.strokeText(ATLAS_LABELS[id].toUpperCase(),x,y);ctx.fillText(ATLAS_LABELS[id].toUpperCase(),x,y);}
  }
  const m=game.room?(game.outbreak?null:game.stage()):game.objectiveMarker(),color=objColor(game);
  const aim=game.waypoint||m;
  if(aim)trace(ctx,s.location,aim,game.waypoint?'#b49df493':color+'8e',1.6*dpr/scale,game.car?.model.class!=='BOAT',seed,style);
  const r=3.7*dpr/scale;
  for(const p of PLACES)if(s.discovered.includes(p.id)||['AIRPORT','SEA TERMINAL'].includes(p.kind)){
    dot(ctx,p.x,p.y,r*.58,'#87dbc3');
    if(region!=='world'||zoom>1){ctx.font=`${8.7*dpr/scale}px monospace`;ctx.textAlign='left';ctx.fillStyle='#ded2df';ctx.fillText(p.name,p.x+r*1.6,p.y-r*1.4);}
  }
  if(game.outbreak){
    for(const p of BEACONS)dot(ctx,p.x,p.y,r*.77,game.outbreak.signal.includes(p.id)?'#97bf86':'#e5b57a',true);
    for(const p of CACHES)if(!game.outbreak.used.includes(p.id))dot(ctx,p.x,p.y,r*.58,'#77aa82');
    if(game.outbreak.signal.length===3)dot(ctx,EVAC.x,EVAC.y,r*.84,'#edf7c1',true);
  }
  const job=jobMarker(game);if(job)dot(ctx,job.x,job.y,r,'#85dfc5',true);
  const event=streetMarker(game);if(event)dot(ctx,event.x,event.y,r*.7,'#b3d5a1',true);
  if(far)for(const b of game.city.active){if(b.survey)dot(ctx,b.survey.x,b.survey.y,r*.76,game.surveys.has(b.survey.id)?'#a9b39c':'#fff0b5',true);}
  if(m)dot(ctx,m.x,m.y,r*1.15,color,true);
  if(game.waypoint)dot(ctx,game.waypoint.x,game.waypoint.y,r*1.15,'#bc9bff',true);
  dot(ctx,s.location.x,s.location.y,r,'#fff1e7');ctx.restore();
  return {left:left/dpr,top:top/dpr,scale:scale/dpr,bounds:[l,t,l+w,t+h]};
}

export function miniMap(ctx,g,width,height){
  const p=g.outside||g.player,s=width/690,h=height/s;
  ctx.setTransform(s,0,0,s,width/2-p.x*s,height/2-p.y*s);
  ctx.fillStyle='#1d1928';ctx.fillRect(p.x-365,p.y-h,730,h*2);
  const [wx,wy,ww,wh]=ATLAS_REGIONS.world, inChart=p.x>wx+347&&p.x<wx+ww-347&&p.y>wy+h/2&&p.y<wy+wh-h/2;
  const atlas=inChart&&cachedSeed===g.city.seed&&cachedStyle===g.city.style?cachedMap:null;
  if(atlas){
    const l=p.x-347,t=p.y-h/2,r=p.x+347,bot=p.y+h/2,sx=atlas.width/ww,sy=atlas.height/wh;
    ctx.imageSmoothingEnabled=false;if(r>l&&bot>t)ctx.drawImage(atlas,(l-wx)*sx,(t-wy)*sy,(r-l)*sx,(bot-t)*sy,l,t,r-l,bot-t);
  }else field(ctx,g.city.seed,[p.x-345,p.y-h/2,p.x+345,p.y+h/2],g.city.style,g.city.charted);
  for(const v of PLACES)if(g.discovered.has(v.id)&&Math.abs(v.x-p.x)<350&&Math.abs(v.y-p.y)<h*.56)dot(ctx,v.x,v.y,9,'#81d6ba');
  const m=g.room?(g.outbreak?null:g.stage()):g.objectiveMarker(),target=g.waypoint||m||jobMarker(g);
  if(target){
    const color=g.waypoint?'#ba9afa':objColor(g), dx=target.x-p.x,dy=target.y-p.y, f=Math.max(Math.abs(dx)/299,Math.abs(dy)/(h*.42),1);
    if(!g.room&&Math.hypot(dx,dy)>90)trace(ctx,p,target,color+'72',4,g.car?.model.class!=='BOAT',g.city.seed,g.city.style);
    dot(ctx,p.x+dx/f,p.y+dy/f,14,color,true);
  }
  if(g.heat>0)for(const v of g.cars)if(v.siren&&v!==g.car&&Math.abs(p.x-v.x)<355&&Math.abs(p.y-v.y)<h*.6)dot(ctx,v.x,v.y,10,'#77a7ff');
  if(g.outbreak)for(const v of g.people.items)if(v.active&&!v.dead&&v.type==='infected'&&v.alert>0&&Math.abs(p.x-v.x)<355&&Math.abs(p.y-v.y)<h*.55)dot(ctx,v.x,v.y,6,'#d8aa79');
  const event=streetMarker(g);if(event&&Math.abs(event.x-p.x)<335&&Math.abs(event.y-p.y)<h*.52)dot(ctx,event.x,event.y,11,'#b3d5a1',true);
  ctx.save();ctx.translate(p.x,p.y);ctx.rotate(g.player.a||0);
  ctx.fillStyle='#0e0e19';ctx.beginPath();ctx.arc(0,0,22,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#f9ede7';ctx.beginPath();ctx.moveTo(21,0);ctx.lineTo(-12,12);ctx.lineTo(-5,0);ctx.lineTo(-12,-12);ctx.closePath();ctx.fill();ctx.restore();
}