const EPS=.00001;
const AXES=[0,1];

// Swept shape tests return the first contact in the current update, in [0,1].
export function rectContact(x,y,dx,dy,body,pad=0) {
  let lo=0,hi=1,nx=0,ny=0;
  for(const axis of AXES){
    const origin=axis?y:x, move=axis?dy:dx;
    const min=(axis?body.y:body.x)-pad, max=min+(axis?body.h:body.w)+pad*2;
    if(Math.abs(move)<EPS){if(origin<min||origin>max)return null;continue;}
    const inv=1/move, first=(min-origin)*inv,last=(max-origin)*inv;
    const enter=Math.min(first,last), leave=Math.max(first,last);
    if(enter>lo){lo=enter;nx=axis?0:-Math.sign(move);ny=axis?-Math.sign(move):0;}
    hi=Math.min(hi,leave);if(lo>hi)return null;
  }
  if(hi<0||lo>1)return null;
  if(!nx&&!ny){if(Math.abs(dx)>Math.abs(dy))nx=-Math.sign(dx);else ny=-Math.sign(dy);}
  return {t:lo,nx,ny};
}

export function circleContact(x,y,dx,dy,body,pad=0) {
  const a=dx*dx+dy*dy;if(a<EPS)return null;
  const u=x-body.x,v=y-body.y,b=u*dx+v*dy,c=u*u+v*v-(body.r+pad)**2;
  const discriminant=b*b-a*c;if(discriminant<0)return null;
  const time=(-b-Math.sqrt(discriminant))/a;
  if(c>0&&(time<0||time>1))return null;
  const t=Math.max(0,time),nx=u+dx*t,ny=v+dy*t,len=Math.hypot(nx,ny)||1;
  return {t,nx:nx/len,ny:ny/len};
}

export function hullContact(x,y,dx,dy,body,pad=0) {
  const c=Math.cos(body.a),s=Math.sin(body.a),u=x-body.x,v=y-body.y;
  const sx=u*c+v*s,sy=-u*s+v*c,mx=dx*c+dy*s,my=-dx*s+dy*c;
  const l=body.model.l,w=body.model.w,hit=rectContact(sx,sy,mx,my,{x:-l/2,y:-w/2,w:l,h:w},pad);
  if(!hit)return null;
  const ax=sx+mx*hit.t,ay=sy+my*hit.t;
  return {...hit,nx:hit.nx*c-hit.ny*s,ny:hit.nx*s+hit.ny*c,ax,ay};
}