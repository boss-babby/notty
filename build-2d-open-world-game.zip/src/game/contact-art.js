import { clamp, mix, TAU } from './core.js';
import { GEAR } from './data.js';
import { HANDLING, MATERIALS } from './contact-data.js';

const fill=(c,x,y,w,h,color)=>{c.fillStyle=color;c.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
const line=(c,col,size,x,y,xx,yy)=>{c.strokeStyle=col;c.lineWidth=size;c.beginPath();c.moveTo(x,y);c.lineTo(xx,yy);c.stroke();};
const ellipse=(c,x,y,rx,ry,color)=>{c.fillStyle=color;c.beginPath();c.ellipse(x,y,rx,ry,0,0,TAU);c.fill();};
const path=(c,col,...v)=>{c.fillStyle=col;c.beginPath();c.moveTo(v[0],v[1]);for(let i=2;i<v.length;i+=2)c.lineTo(v[i],v[i+1]);c.closePath();c.fill();};

function tool(c,id,x,y,l){
  if(id==='hands')return;
  if(id==='bat'){fill(c,x,y-1,l,4,'#7f555b');fill(c,x+4,y-1,l-4,2,'#dca57b');fill(c,x,y,5,3,'#514451');return;}
  if(id==='blade'){fill(c,x,y,l,3,'#38313f');path(c,'#b9cfd2',x+4,y,x+l+2,y+1,x+l-2,y+2,x+4,y+2);fill(c,x+2,y,2,4,'#bd8c7a');return;}
  if(id==='grenade'||id==='molotov'){fill(c,x+1,y-1,5,5,id==='grenade'?'#a9be9c':'#cf976d');fill(c,x+5,y+1,2,2,'#edd49b');return;}
  const h=id==='rocket'?5:4;
  path(c,'#222130',x-2,y-2,x+l-1,y-2,x+l+1,y+1,x+l-3,y+h,x+3,y+h,x+1,y+h+2,x-1,y+h+2);
  fill(c,x,y-2,l-1,1,'#b2a4af');fill(c,x+4,y,l-4,h-1,id==='pistol'?'#8e97ab':'#667d84');fill(c,x+l-4,y+1,3,2,'#d1b29a');
  if(id==='smg'||id==='rifle')fill(c,x+7,y+4,3,3,'#474353');
  if(id==='sniper')fill(c,x+6,y-4,7,2,'#cababc');
  if(id==='shotgun')fill(c,x+8,y,6,3,'#c1907a');
}

export function drawBody(c,g,n,x,y,a,main){
  const control=main?g.contact:null, gear=main?GEAR[g.weapon]:null;
  const infected=n.type==='infected', swing=main?control.swing:n.attack;
  const guard=control?.guard||0, aimed=control?.aim||Number(!!n.shotPlan), roll=main&&n.dodge>0;
  const lift=main?n.lift||0:0, turn=n.moveAngle??a, stride=n.stride||0;
  const scale=n.boss||infected&&n.variantZ==='brute'?1.19:1;
  if(n.type==='target'){
    if(n.dead){ellipse(c,x+1,y+3,10,4,'#17192298');fill(c,x-6,y+1,12,4,'#576a6b');return;}
    ellipse(c,x+2,y+5,16,5,'#1419219d');fill(c,x-11,y+6,22,5,'#576169');fill(c,x-2,y-8,4,15,'#9eafb1');
    ellipse(c,x,y-8,10,11,'#272b3d');ellipse(c,x,y-8,9,10,n.hit>0?'#f5e6bb':n.color);ellipse(c,x,y-8,5,6,'#587b74');ellipse(c,x,y-8,2,2,'#dbd6a8');return;
  }
  if(n.dead&&g.settings.motion!==false){
    c.save();c.translate(x,y);c.rotate(n.fallA??a+.8);
    const progress=clamp((3.2-n.dead)*5,0,1);
    ellipse(c,-1,3,12+progress*4,7,'#1a1422b5');fill(c,-11,-2,18,8,n.color+'a5');fill(c,7,-3,7,7,n.skin+'a5');
    line(c,'#2f2a3a',3,-10,-1,-19,-4);line(c,'#2f2a3a',3,-9,4,-18,9);c.restore();return;
  }else if(n.dead){ellipse(c,x,y,14,5,'#292031a5');return;}

  ellipse(c,x+2,y+4,12+lift*.14,7+lift*.05,lift>4?'#1a152068':'#17131ca8');
  if(main&&n.swim){ellipse(c,x,y,16,9,'#a0b4c649');ellipse(c,x,y,12,7,'#3e536899');}
  if(!n.swim){
    c.save();c.translate(x,y-lift);c.rotate(turn);c.scale(scale,scale);
    const gait=Math.sin(stride)*(roll?1.1:main&&n.sprint?5:3.4);
    const lean=main&&n.sprint?3:0;
    for(const s of [-1,1]){
      const foot=-7+gait*s+lean, side=s*(n.cover?3.2:4.7);
      line(c,'#242335',4,-2,side,foot,side+1.5);
      fill(c,foot-3,side,6,4,'#292936');fill(c,foot-1,side,3,1,'#88808f');
    }c.restore();
  }
  c.save();c.translate(x,y-lift);c.rotate(a);c.scale(scale,scale);
  if(roll){c.scale(1.19,.59);c.rotate(Math.sin((n.dashTime||0)*16)*.38);}
  const tuck=n.cover?.77:1, stagger=n.hit>0?Math.sin(n.hit*36)*1.3:0;
  c.translate(stagger,0);
  const outfit=n.outfit||0;
  path(c,'#161824',-8,-4*tuck,-5,-7*tuck,6,-6*tuck,8,-3*tuck,7,4*tuck,4,7*tuck,-6,7*tuck,-8,4*tuck);
  path(c,n.hit>0?'#e2b5b5':n.color,-6,-4*tuck,-3,-6*tuck,5,-5*tuck,6,4*tuck,2,6*tuck,-5,5*tuck);
  fill(c,-5,-3,3,7,'#383346');fill(c,-3,-4*tuck,6,1,'#f5dbc574');
  if(outfit===1||n.type==='officer'){fill(c,-5,-4*tuck,4,8*tuck,'#47717b');fill(c,-2,-3*tuck,2,6*tuck,'#a4c1b0');}
  if(outfit===2){fill(c,-5,-5*tuck,6,2,'#edcf9b');fill(c,-4,3*tuck,6,2,'#edcf9b');}
  if(outfit===3){fill(c,-6,-3*tuck,3,6*tuck,'#786884');fill(c,-3,-3*tuck,2,6*tuck,'#d6b9c9');}
  const armed=gear?gear.style!=='melee':n.type==='enemy'||n.type==='officer';
  let tip=armed?9+aimed*4:4+Math.sin(stride)*2.4;
  if(infected)tip=10+(n.brain?.attack?.hit?4:0);
  if(guard>.36)tip=6.3;
  if(control?.reload||control?.heal)tip=5+Math.sin(g.clock*16)*2;
  if(main&&n.pump>0)tip-=Math.sin(n.pump*8)*1.5;
  const kick=(Math.max(0,n.recoil||0)*13);
  tip-=kick;
  const trace=main&&swing?clamp(swing.time/swing.total,0,1):swing?clamp(swing.time/swing.total,0,1):0;
  const sweep=swing?mix(-1.24,1.14,clamp((trace-.16)*1.82,0,1)):0;
  const h=gear?HANDLING[gear.id]:null;
  line(c,'#242238',4,-2,-6*tuck,tip-1,-6.1*tuck);line(c,n.color,2.8,-2,-6*tuck,tip-1,-6.1*tuck);
  line(c,'#242238',4,-1,6*tuck,tip-1,4.9*tuck);line(c,n.color,2.8,-1,6*tuck,tip-1,4.9*tuck);
  fill(c,tip-2,-7*tuck,3,3,n.skin);fill(c,tip-2,3.6*tuck,3,3,n.skin);
  if(n.state==='film'||n.state==='call'){fill(c,tip+1,-7,4,4,'#303444');fill(c,tip+2,-7,2,3,'#a8d2c8');}
  if(gear&&(!armed||!control.reload)){
    c.save();c.translate(armed?tip-4:swing?Math.cos(sweep)*5:3,armed?2:swing?Math.sin(sweep)*7:5);
    if(swing)c.rotate(sweep);tool(c,gear.id,0,0,h.length);c.restore();
  }else if(armed&&!main)tool(c,'pistol',tip-3,1.4,12);
  if(swing&&swing.time>=swing.wind&&swing.time<swing.wind+.105){
    c.strokeStyle=main?'#f2d6ae95':'#eeb4989a';c.lineWidth=1.25;c.beginPath();c.arc(2,0,gear?.id==='bat'?24:17,-.84,.83);c.stroke();
  }
  if(guard>.44){c.strokeStyle='#b5dbd4a8';c.lineWidth=1.2;c.beginPath();c.arc(3,0,12,-1.08,1.08);c.stroke();}
  ellipse(c,3,-.8,5.4,4.6,n.skin);path(c,'#3a2a3e',-.5,-4.5,4,-5.2,5,-1,2,3,-1,2);
  fill(c,4,-3,2,1,'#f0c5a0');fill(c,7,-1,2,2,infected?'#d4eca5':'#e5bb9e');
  if(n.hair===1)fill(c,-1,-2,3,5,'#332436');
  if(n.hair===2)fill(c,1,-5,4,2,'#a97767');
  if(outfit===2)fill(c,1,-5,6,2,'#c9a274');
  if((n.flash||0)>0&&g.settings.flashes!==false){
    const fx=main?tip-4+(h?.length||10):20;
    path(c,'#ffe0a9',fx,2,fx+9,-1,fx+7,3,fx+13,6,fx+5,6,fx,9);
    fill(c,fx+1,2,6,3,'#fff0c4');
  }
  const cue=n.shotPlan||n.attack||n.brain?.attack;
  if(cue&&!cue.hit&&g.settings.motion!==false){
    const tone=n.shotPlan?'#e6a96e':'#efaa93';
    c.strokeStyle=tone+'c8';c.lineWidth=1;c.beginPath();c.arc(3,0,n.boss?17:14,-.66,.66);c.stroke();
    fill(c,15,-1,3,2,tone);
  }
  c.restore();
}

export function drawImpact(c,s){
  const mat=MATERIALS[s.mat]||MATERIALS.stone;
  const k=Math.min(1,s.life/3),z=(s.seed||.8)*2+1;
  c.globalAlpha=k*.63;
  if(s.mat==='glass'){
    path(c,mat.tint,s.x-z,s.y+3,s.x+z+3,s.y-1,s.x+z,s.y+3);
    fill(c,s.x+z*2,s.y+4,2,1,mat.tint);
  }else{
    ellipse(c,s.x,s.y,z+1.2,z*.72,'#2a202e');
    line(c,mat.dark,1,s.x-s.ny*3,s.y+s.nx*3,s.x+s.ny*4,s.y-s.nx*4);
    if(s.mat==='metal'||s.mat==='stone')fill(c,s.x+s.nx*2,s.y+s.ny*2,z+1,1,mat.tint);
  }
  c.globalAlpha=1;
}

export function drawMote(c,p,x,y){
  const k=p.life/p.max, d=p.size;
  c.globalAlpha=k*(p.style==='smoke'?.38:p.style==='dust'?.34:.89);
  if(p.style==='shard'||p.style==='splinter'||p.style==='casing'){
    c.save();c.translate(x,y);c.rotate(p.a||0);
    if(p.style==='shard')path(c,p.color,0,-d*.57,d*1.24,.6,0,d*.53);
    else{fill(c,0,0,d*1.32,.9,p.color);fill(c,d*.6,0,1,.72,'#fff1cd');}c.restore();
  }else if(p.style==='glint'||p.style==='spark')line(c,p.color,1.15,x,y,x-(p.vx||0)*.037,y-(p.vy||0)*.037);
  else if(p.style==='ink')fill(c,x,y,Math.max(1,d*.6),1,p.color);
  else if(p.style==='drop')fill(c,x,y,1.6,1.6,p.color);
  else ellipse(c,x,y,d*.78+(1-k)*3.9,d*.61+(1-k)*2.3,p.color);
  c.globalAlpha=1;
}