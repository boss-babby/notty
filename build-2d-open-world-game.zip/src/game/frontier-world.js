import { CELL, DISTRICTS, PLACES, SEED } from './data.js';
import { hash, rng } from './core.js';
import { edgeWidths, outerWater, outerZone, surveyAt, terrainNoise } from './frontier-geo.js';

const tiles={airport:'#616365',souk:'#987b62',towers:'#748182',marina:'#7d8279',gardens:'#858467',strip:'#6c596b',courts:'#877365',airstrip:'#686570',camp:'#7e7e64',works:'#987662',dunes:'#9a7a59',canyon:'#8a6557',salt:'#b7a994',oasis:'#828064',islands:'#ac9c79',sea:'#355a6c',juniper:'#637567'};
const kinds={airport:'terminal',airstrip:'terminal',souk:'plaster',towers:'glass',marina:'terrace',gardens:'plaster',strip:'resort',courts:'motel',works:'shed',camp:'hangar',dunes:'plaster',oasis:'plaster',juniper:'cabin'};
const named={AIRPORT:'terminal',MARKET:'plaster',OBSERVATORY:'glass','SEA TERMINAL':'terrace',CLUB:'club',CASINO:'resort',GARAGE:'shed',CLINIC:'clinic','ARMY CAMP':'hangar'};
const landmarks={spire:'spire',jacklight:'crown',marina:'tide',ember:'command','air-mirage':'wing','basin-air':'wing','tide-room':'sound',halation:'halo'};
const SCALE=12;

export function frontierChunk(cx,cy,id,seed=SEED,style='continental',broken=new Set()){
  const zone=outerZone(cx,cy,seed,style), district=DISTRICTS[zone], type=district.type;
  const x=cx*CELL,y=cy*CELL, R=rng(hash(cx,cy,seed+337));
  const roads=edgeWidths(cx,cy,seed,style), poi=PLACES.find(p=>p.cx===cx&&p.cy===cy), survey=surveyAt(cx,cy,seed,style);
  const blocks=[],props=[],trees=[],lights=[],decor=[],pools=[],paths=[],crossings=[],signs=[];
  const h=type==='towers'||type==='strip';
  const urban=!['dunes','canyon','salt','oasis','islands','juniper','sea'].includes(type);
  const clearLand=(lx,ly,w=0,f=0)=>![[lx,ly],[lx+w,ly],[lx,ly+f],[lx+w,ly+f],[lx+w/2,ly+f/2]].some(([a,b])=>outerWater(x+a,y+b,seed,style));
  const empty=(lx,ly,w,f,gap=9)=>!blocks.some(b=>x+lx+w+gap>b.x&&x+lx-gap<b.x+b.w&&y+ly+f+gap>b.y&&y+ly-gap<b.y+b.h);
  const add=(lx,ly,w,f,kind,tag=null)=>{
    if(lx<47||ly<58||lx+w>438||ly+f>436||!clearLand(lx,ly,w,f)||!empty(lx,ly,w,f)||survey&&(Math.abs(x+lx+w/2-survey.x)<w/2+32&&Math.abs(y+ly+f/2-survey.y)<f/2+32)||poi&&!tag&&Math.abs(x+lx+w/2-poi.x)<w/2+28&&Math.abs(y+ly+f/2-poi.y)<f/2+28)return;
    blocks.push({x:x+lx,y:y+ly,w,h:f,kind,feature:tag?landmarks[tag.id]:null,variant:Math.floor(R()*6),height:kind==='glass'?23+R()*34:h?11+R()*16:4+R()*9,poi:tag});
  };
  const lots=(items,kind)=>{for(const [a,b,w,f] of items)add(a+(R()-.5)*7,b+(R()-.5)*8,w*(.88+R()*.27),f*(.87+R()*.28),kind);};
  const pool=(a,b,w,f,shape='box')=>{if(clearLand(a,b,w,f)&&empty(a,b,w,f,5))pools.push({x:a,y:b,w,h:f,shape});};
  const dressing=(a,b,kind)=>{if(clearLand(a,b)&&empty(a,b,5,5))decor.push({x:a,y:b,kind,v:Math.floor(R()*6)});};
  if(poi){
    const a=poi.x-x;add(a-58,89,poi.kind==='AIRPORT'?157:poi.id==='marina'?81:126,poi.kind==='CASINO'?115:poi.id==='spire'?143:79,named[poi.kind]||kinds[type],poi);
    lights.push({x:poi.x,y:poi.y-5,hue:district.color});
  }
  if(type==='airport'||type==='airstrip'){
    const ns=(cx+(type==='airstrip'?1:0))%3===0;
    decor.push({x:ns?279:48,y:ns?65:272,kind:'runway',ns,v:(cx+cy)%4});
    if(ns)lots([[63,200,112,49],[70,311,106,67]],'hangar');
    else lots([[60,111,99,42],[315,107,103,42],[84,361,124,57]],'hangar');
    lights.push({x:x+270,y:y+113,hue:'#a6bede'},{x:x+399,y:y+404,hue:'#edab89'});
    if(poi)decor.push({x:355,y:205,kind:'plane',v:0});
  }else if(type==='souk'){
    const bend=200+Math.round(R()*66);
    paths.push([59,220,bend,210,276,239,423,237],[bend,57,bend-21,130,bend,214,bend-6,421]);
    for(let i=0;i<8;i++){
      const a=i%4, b=i>3?283:91;
      add(61+a*96+R()*16,b+R()*32,44+R()*29,46+R()*52,'plaster');
      if(i%3!==0)dressing(61+a*96,b+102,i%2?'awning':'market');
    }
    pool(142,230,64,38,'fountain');
  }else if(type==='towers'){
    const option=Math.floor(R()*3);
    if(option===0)lots([[82,85,88,132],[298,100,97,99],[190,279,85,111]],'glass');
    if(option===1)lots([[70,116,154,118],[307,98,84,155],[238,306,117,93]],'glass');
    if(option===2)lots([[134,95,102,97],[283,205,100,130],[73,281,92,95]],'glass');
    pool(179,179,94,97,'fountain');pool(66,339,102,22);dressing(259,166,'sculpture');
    paths.push([48,240,184,240,246,227,425,212]);
  }else if(type==='marina'){
    lots([[64,109,112,80],[296,95,75,79],[103,283,97,69],[303,293,89,68]],'terrace');
    for(let i=0;i<9;i++)dressing(63+i*42,214,i%3===0?'palm':'bench');
    decor.push({x:310,y:223,kind:'pier',v:cx%3});pool(78,206,115,34);
  }else if(type==='strip'){
    const left=R()>.5;
    lots(left?[[69,120,130,95],[275,103,120,146],[247,330,147,74]]:[[244,120,156,112],[89,263,100,145],[303,297,90,103]],'resort');
    pool(left?75:288,249,108,44,'oval');
    for(let i=0;i<6;i++)dressing(57+i*66,62,i%2?'marquee':'palm');
    paths.push([53,219,196,226,241,239,422,231],[197,56,210,156,241,239,225,421]);
    for(const [a,b] of [[224,78],[83,256],[404,221]])if(clearLand(a,b))lights.push({x:x+a,y:y+b,hue:['#ed78a6','#91c8e6','#d49ce4'][(a+b)%3]});
  }else if(type==='camp'||type==='works'){
    lots([[87,93,104,50],[258,100,120,60],[78,275,94,89],[290,286,98,90]],type==='camp'?'hangar':'shed');
    decor.push({x:198,y:208,kind:type==='camp'?'helipad':'freight',v:0});
    for(let i=0;i<5;i++)dressing(67+i*77,243,i%2?'containers':'fence');
  }else if(type==='gardens'||type==='courts'){
    const data=type==='gardens'?[[83,85,89,69],[258,145,126,73],[117,291,83,68],[284,320,102,66]]:[[62,102,135,57],[262,85,139,48],[62,309,119,58],[267,320,131,49]];
    lots(data,kinds[type]);pool(type==='gardens'?190:225,206,type==='gardens'?76:129,47,type==='gardens'?'fountain':'oval');
    paths.push([48,222,177,227,238,241,431,241]);
  }else if(type!=='sea'){
    if(type==='canyon'){
      const side=R()>.46?64:278;
      for(let i=0;i<5;i++)add(side+R()*58,78+i*62,27+R()*50,25+R()*39,'rock');
      if(R()>.43)for(let i=0;i<3;i++)add(side<100?293:74,120+i*116,37+R()*33,34+R()*37,'rock');
    }else if(type==='oasis'||type==='juniper'||type==='islands'){
      if(R()<.72)lots([[89,96,62,35],[307,278,61,47],[132,341,48,43]],kinds[type]||'cabin');
      if(type==='oasis')pool(176,137,105,68,'oval');
    }else if(type==='dunes'&&R()<.24)lots([[77,96,49,40]],'plaster');
    if(survey)decor.push({x:236,y:213,kind:'beacon',v:0});
  }
  if(urban){
    // Dense, differently shaped infill gives each authored city a recognisable street grain.
    const rows=type==='towers'||type==='strip'?5:4, cols=type==='souk'?4:5;
    for(let gy=0;gy<rows;gy++)for(let gx=0;gx<cols;gx++){
      if(R()<((type==='camp'||type==='works') ? .42 : .12))continue;
      const w=28+R()*(type==='towers'?39:30),f=25+R()*(type==='souk'?34:29);
      const lx=56+gx*(type==='souk'?99:77)+(R()-.5)*13,ly=66+gy*(type==='towers'?69:78)+(R()-.5)*13;
      add(lx,ly,w,f,type==='souk'?'plaster':type==='strip'?'motel':kinds[type]||'plaster');
    }
    for(let i=0;i<17;i++){
      const corner=i%4, along=74+(i*47)%330;
      const lx=corner===0?95:corner===1?along:corner===2?382:along;
      const ly=corner===0?along:corner===1?84:corner===2?along:399;
      dressing(lx,ly,['market','streetlight','bench','cafe','palm','banner','scooter','planter'][i%8]);
    }
    for(let i=0;i<4;i++){
      const lx=63+R()*340,ly=73+R()*330;
      const words=type==='souk'?['SOUK','SPICE','TEA','OPEN','LANTERN','CLOTH']:type==='strip'?['JACK','LUCK','NEON','24H','SHOW','NITE']:type==='airport'||type==='airstrip'?['AIR','GATE','FLIGHT','DEPART','LINK']:type==='marina'?['PIER','FERRY','TIDE','SEA','DOCK']:type==='camp'||type==='works'?['EMBER','YARD','GATE','SUPPLY','DEPOT']:['MARKET','PLAZA','NIGHT','OPEN','CITY','LINE'];
      if(clearLand(lx,ly)&&empty(lx,ly,6,6,6))signs.push({x:lx,y:ly,w:25+R()*33,h:9+R()*5,text:words[Math.floor(R()*words.length)],color:['#f7c28c','#8fd9ca','#e4a0cf','#b8d2a8'][Math.floor(R()*4)],phase:R()*6,neon:type==='strip'||type==='towers'||type==='souk'});
    }
    const [a,r,b,l]=roads;
    if(a>15&&l>15)crossings.push({x:l,y:a,a:'v'});
    if(r>15&&a>15)crossings.push({x:CELL-r,y:a,a:'v'});
    if(l>15&&a>15)crossings.push({x:l,y:CELL-b,a:'h'});
    if(r>15&&b>15)crossings.push({x:CELL-r,y:CELL-b,a:'h'});
  }
  const n={gardens:34,souk:9,towers:18,marina:25,strip:17,courts:14,camp:8,airport:5,airstrip:4,works:7,dunes:9,canyon:6,salt:3,sea:0,islands:24,oasis:31,juniper:31}[type]??7;
  for(let i=0;i<n+(urban?9:0);i++){
    const a=55+R()*363,b=54+R()*363;
    if(empty(a,b,6,8,12)&&clearLand(a,b)&&!pools.some(p=>a>p.x-12&&a<p.x+p.w+12&&b>p.y-12&&b<p.y+p.h+12))trees.push({x:a,y:b,r:5+R()*(type==='juniper'?16:8),v:Math.floor(R()*5)});
  }
  if(!['sea','dunes','salt','canyon','juniper'].includes(type))for(const [a,b] of [[43,45],[433,46],[44,412],[433,415],[225,48],[49,233]])if(clearLand(a,b))lights.push({x:x+a,y:y+b,hue:type==='strip'?'#f48cba':type==='marina'||type==='towers'?'#abe2df':'#ffd79b'});
  for(let i=0;i<(h?4:2);i++){
    const a=81+R()*310,b=68+R()*45,key=`${id}:f${i}`;
    if((!poi||Math.hypot(x+a-poi.x,y+b-poi.y)>43)&&clearLand(a,b)&&empty(a,b,18,9,9)&&!broken.has(key))props.push({x:x+a,y:y+b,w:13,h:8,id:key,type:'prop',kind:i===0?'sign':'crate',hp:24});
  }
  return {id,cx,cy,x,y,zone,type,frontier:true,roads,poi,blocks,props,trees,lights,decor,pools,paths,survey,crossings,signs};
}

const f=(g,x,y,w,h,color)=>{g.fillStyle=color;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
function line(g,col,width,points){g.strokeStyle=col;g.lineWidth=width;g.beginPath();g.moveTo(points[0],points[1]);for(let i=2;i<points.length;i+=2)g.lineTo(points[i],points[i+1]);g.stroke();}
function ellipse(g,x,y,rx,ry,col){g.fillStyle=col;g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);g.fill();}
function poly(g,col,v){g.fillStyle=col;g.beginPath();g.moveTo(v[0],v[1]);for(let i=2;i<v.length;i+=2)g.lineTo(v[i],v[i+1]);g.closePath();g.fill();}
const banner=(g,text,x,y,color,size=9)=>{g.fillStyle=color;g.font=`700 ${size}px monospace`;g.textAlign='center';g.fillText(text,x,y);};

function bayFill(g,b,seed,style){
  const {x,y,cx,cy}=b,size=6;
  // Get a watertight, seed-stable shoreline rather than a rectangle per block.
  for(let v=0;v<CELL;v+=size){let start=-1;
    for(let u=0;u<=CELL;u+=size){
      const wet=u<CELL&&outerWater(x+u+3,y+v+3,seed,style);
      if(wet&&start<0)start=u;
      if(!wet&&start>=0){f(g,start,v,u-start,size,'#355c6f');if(v%18===0)f(g,start+2,v+1,Math.max(0,u-start-4),1,'#84beb133');start=-1;}
    }
  }
  if((cx<27&&cx>-3&&cy>=-1&&cy<21)&&b.type!=='marina')return;
  for(let i=0;i<36;i++){
    const a=(i*79+cx*17+2400)%CELL,v=(i*91+cy*33+2400)%CELL;
    if(a>0&&v>0&&outerWater(x+a,y+v,seed,style))f(g,a,v,4+i%12,1,i%2?'#8ccec357':'#a8d2be35');
  }
}

const channels=val=>[parseInt(val.slice(1,3),16),parseInt(val.slice(3,5),16),parseInt(val.slice(5,7),16)];
export function terrainTint(x,y,seed,style){
  const sea=outerWater(x,y,seed,style);
  if(sea)return '#355c6f';
  const cx=x/CELL-.5,cy=y/CELL-.5,a=Math.floor(cx),b=Math.floor(cy),u=cx-a,v=cy-b;
  const w=[(1-u)*(1-v),u*(1-v),(1-u)*v,u*v], p=[[a,b],[a+1,b],[a,b+1],[a+1,b+1]];
  const c=[0,0,0];
  for(let i=0;i<4;i++){
    const d=DISTRICTS[outerZone(p[i][0],p[i][1],seed,style)],hex=channels(tiles[d.type]||d.ground);
    for(let v=0;v<3;v++)c[v]+=hex[v]*w[i];
  }
  const n=(terrainNoise(x/630,y/390,seed+319)-.5)*30;
  return `rgb(${Math.round(c[0]+n)},${Math.round(c[1]+n)},${Math.round(c[2]+n*.6)})`;
}

export function paintFrontier(g,b,seed,style){
  const R=rng(hash(b.cx,b.cy,seed+397)), {x,y,type}=b, d=DISTRICTS[b.zone], ground=tiles[type]||d.ground;
  f(g,0,0,CELL,CELL,ground);
  const terrain=['dunes','canyon','oasis','islands','juniper','salt'].includes(type);
  if(terrain){
    for(let v=0;v<CELL;v+=SCALE)for(let a=0;a<CELL;a+=SCALE)f(g,a,v,SCALE,SCALE,terrainTint(x+a+6,y+v+6,seed,style));
    for(let j=0;j<25;j++){
      const a=R()*CELL,b0=R()*CELL,points=[a,b0,a+21,b0-4,a+49,b0+Math.sin(a)*7,a+81,b0+2,a+113,b0+8];
      line(g,type==='salt'?'#e2cfaa53':'#d2aa7e58',1.2,points);
    }
  }else{
    f(g,42,43,395,394,type==='strip'?'#7e6877':type==='towers'?'#86918c':type==='camp'?'#94917b':'#a0876d');
    for(let n=52;n<432;n+=22){f(g,n,44,1,394,'#c8ac8d20');f(g,45,n,390,1,'#3c394930');}
    if(type==='strip'||type==='towers')for(let n=0;n<11;n++)f(g,65+n*29,266,2,32,'#e8c7a84b');
  }
  for(let i=0;i<670;i++){
    const a=R()*CELL,v=R()*CELL;f(g,a,v,R()*4+1,1,R()<.57?'#edd4af39':'#342f3d40');
  }
  if(b.cx>=29&&b.cx<39&&b.cy>=2&&b.cy<=8||(!['airport','airstrip','souk','towers','strip','camp','courts','works','gardens'].includes(type)&&Math.abs(b.cx)>2&&(Math.abs(b.cy)>19||b.cx<-1||b.cx>32))||type==='sea'||type==='islands')bayFill(g,b,seed,style);
  for(const path of b.paths){line(g,'#b59d839c',18,path);line(g,'#67616a',11,path);line(g,'#d0a78662',1,path);}
  for(const p of b.pools){
    if(p.shape!=='box'){
      ellipse(g,p.x+p.w/2,p.y+p.h/2,p.w/2+4,p.h/2+3,'#c8b79c');ellipse(g,p.x+p.w/2,p.y+p.h/2,p.w/2,p.h/2,'#579790');
      ellipse(g,p.x+p.w/2,p.y+p.h/2,p.w/4,p.h/4,'#92c7b2');
      if(p.shape==='fountain'){f(g,p.x+p.w/2-5,p.y+p.h/2-8,10,12,'#d1c6a5');f(g,p.x+p.w/2-1,p.y+p.h/2-11,3,7,'#f5d9a7');}
    }else{f(g,p.x-3,p.y-3,p.w+6,p.h+6,'#c1b49e');f(g,p.x,p.y,p.w,p.h,'#599086');f(g,p.x+4,p.y+4,p.w-7,2,'#abd5b3');}
    for(let i=0;i<10;i++)f(g,p.x+p.w*.19+R()*p.w*.64,p.y+p.h*.2+R()*p.h*.63,9,1,'#c0ded05f');
  }
  const road='#5b555f', [a,r,c,l]=b.roads;
  const pave=(x0,y0,w,h)=>{f(g,x0-2,y0-2,w+4,h+4,'#bb9879');f(g,x0,y0,w,h,road);};
  if(a)pave(0,0,CELL,a);if(c)pave(0,CELL-c,CELL,c);if(l)pave(0,0,l,CELL);if(r)pave(CELL-r,0,r,CELL);
  const bridge=(bx,by,bw,bh,horizontal)=>{
    if(!outerWater(x+bx+bw/2,y+by+bh/2,seed,style))return;
    f(g,bx,by,bw,bh,'#3f4656');f(g,bx,by,bw,2,'#d3ab83');f(g,bx,by+bh-2,bw,2,'#a37476');
    for(let i=12;i<(horizontal?bw:bh);i+=27){
      if(horizontal){f(g,bx+i,by+3,2,bh-6,'#8d7a7c');f(g,bx+i-2,by+bh,7,4,'#3c394a');}
      else{f(g,bx+3,by+i,bw-6,2,'#8d7a7c');f(g,bx+bw,by+i-2,4,7,'#3c394a');}
    }
  };
  if(a)bridge(0,0,CELL,a,true);if(c)bridge(0,CELL-c,CELL,c,true);if(l)bridge(0,0,l,CELL,false);if(r)bridge(CELL-r,0,r,CELL,false);
  for(let i=44;i<451;i+=28){
    if(a>20)f(g,i,3,12,1,'#cfa579c2');if(c>20)f(g,i,475,12,1,'#cfa579c2');
    if(l>20)f(g,3,i,1,12,'#cfa579c2');if(r>20)f(g,475,i,1,12,'#cfa579c2');
  }
  if(type==='strip'||type==='towers')for(let i=0;i<4;i++){if(a>20)f(g,39,5+i*5,18,2,'#cebba886');if(l>20)f(g,5+i*5,39,2,18,'#cebba886');}
  for(const obj of b.decor)scenery(g,obj,b,R);
  for(const k of b.blocks)building(g,k,b,R);
  for(const t of b.trees)tree(g,t,type);
  for(const o of b.lights){const a=o.x-x,v=o.y-y;f(g,a-2,v-1,7,3,'#403a48');f(g,a,v-8,2,9,'#aca08c');f(g,a-1,v-8,4,3,o.hue);}
  if(b.survey){const a=b.survey.x-x,v=b.survey.y-y;ellipse(g,a+3,v+3,21,12,'#6e5852');ellipse(g,a,v,17,9,'#bc9f79');f(g,a-6,v-18,12,21,'#4c5a63');f(g,a-3,v-17,7,5,'#b1e3c4');}
}

function building(g,k,b,R){
  const x=k.x-b.x,y=k.y-b.y,{w,h,kind,variant:v}=k, d=DISTRICTS[b.zone],z=k.height;
  if(kind==='rock'){
    const v0=[x,y+h*.29,x+w*.25,y,x+w*.81,y+6,x+w,y+h*.46,x+w*.84,y+h,x+8,y+h*.92];
    poly(g,'#43394866',v0.map((n,i)=>n+(i%2?8:9)));poly(g,'#674852',v0);
    poly(g,'#a37965',[x+3,y+h*.27,x+w*.29,y+2,x+w*.77,y+8,x+w*.95,y+h*.5,x+w*.36,y+h*.52]);
    for(let i=0;i<6;i++)line(g,'#c595795d',1,[x+w*.17,y+7+i*h/9,x+w*.7,y+11+i*h/9]);return;
  }
  f(g,x+7,y+8,w+z*.32,h+z*.43,'#322b4359');
  f(g,x+3,y+2,w,h+7,'#453747');f(g,x,y,w,h,'#b29987');
  const glass=kind==='glass', metal=kind==='hangar'||kind==='shed'||kind==='terminal';
  f(g,x+3,y+3,w-6,h-7,glass?'#456776':kind==='resort'||kind==='club'?'#725569':metal?'#68646c':d.roof);
  f(g,x,y,w,2,glass?'#adc6bb':'#e4c29d');f(g,x+w-3,y+3,3,h-6,'#544458');
  if(glass){
    f(g,x+9,y+9,w-18,h-23,'#5e8491');
    for(let i=13;i<w-8;i+=8){f(g,x+i,y+9,2,h-23,i%3?'#9ebfbd':'#72939b');f(g,x+i+1,y+10,1,h-27,'#d5dec36b');}
    for(let j=12;j<h-12;j+=16)f(g,x+10,y+j,w-20,1,'#bdcfb48a');
    f(g,x+w*.32,y+h*.24,w*.34,h*.46,'#55717d');f(g,x+w*.35,y+h*.27,w*.28,4,'#92babc');
    if(k.feature==='spire'){ellipse(g,x+w*.5,y+h*.36,w*.26,h*.28,'#75a3a6');f(g,x+w*.48,y-6,4,h*.53,'#cce2c3');f(g,x+w*.51,y-9,3,4,'#fff2c7');}
    if(v%3===0){ellipse(g,x+w*.5,y+2,w*.24,h*.14,'#d9cda6');f(g,x+w*.46,y-6,3,9,'#b7d9c7');f(g,x+w*.49,y-9,1,3,'#ffe4a2');}
    if(w>60){f(g,x+w*.15,y+h*.08,w*.28,5,'#4c6f7d');f(g,x+w*.58,y+h*.08,w*.24,5,'#6b8f91');}
    for(let i=8;i<w-8;i+=11){f(g,x+i,y+h-13,3,6,'#d7bca089');}
  }else if(metal){
    for(let i=6;i<w-5;i+=5){f(g,x+i,y+7,1,h-17,'#4848548c');f(g,x+i+1,y+7,1,h-17,'#bdb69f66');}
    f(g,x+9,y+h*.56,w-18,3,kind==='terminal'?'#a4d1cc':'#bfa77d');
  }else if(kind==='resort'||kind==='club'){
    const n=['#d879a4','#eea37c','#7ecbc8','#a38ed4','#d48f9a','#a0a9d5'][v];
    f(g,x+8,y+8,w-16,h-17,'#604860');f(g,x+13,y+11,w-26,h-24,'#6d526a');
    f(g,x+7,y+8,w-13,2,n);f(g,x+8,y+h-13,w-16,3,n);
    for(let i=13;i<w-11;i+=8)f(g,x+i,y+h-10,3,3,i%3?'#eec1a2':n);
    for(let i=13;i<h-15;i+=10){f(g,x+7,y+i,4,2,n);f(g,x+w-11,y+i,4,2,n);}
    if(k.feature==='crown'||k.feature==='halo'){ellipse(g,x+w*.5,y+h*.39,w*.27,h*.24,n);ellipse(g,x+w*.5,y+h*.39,w*.21,h*.17,'#563c59');ellipse(g,x+w*.5,y+h*.39,w*.11,h*.08,'#ad8696');}
    if(h>70){f(g,x+w*.72,y-30,16,42,'#31243f');f(g,x+w*.74,y-27,12,35,n);banner(g,k.feature==='crown'?'J':'H',x+w*.8,y-6,'#ffe4b2',14);}
    for(let i=12;i<w-8;i+=13){f(g,x+i,y+h-6,7,4,i%2?'#f3c98c':n);}
  }else{
    for(let i=0;i<4;i++)f(g,x+7+R()*Math.max(3,w-29),y+9+R()*Math.max(3,h-25),11,8,'#b89b7c');
    f(g,x+7,y+7,w-14,2,'#f3d0a477');
    if(kind==='plaster'||kind==='terrace'){
      f(g,x+w*.32,y+h*.36,w*.35,h*.34,'#8b735f');f(g,x+w*.36,y+h*.40,w*.27,h*.26,'#6b655d');
      if(v%2===0){ellipse(g,x+w*.5,y+h*.5,w*.09,h*.095,'#799388');f(g,x+w*.47,y+h*.43,4,4,'#c7c4a0');}
      for(let i=10;i<w-8;i+=14){
        f(g,x+i,y+h-11,9,9,'#3e3445');ellipse(g,x+i+4.5,y+h-4,4.5,6,'#5b4c54');f(g,x+i+1,y+h-7,7,2,'#d4ab83');
      }
      if(k.feature==='tide'){
        ellipse(g,x+w*.5,y+4,w*.29,h*.16,'#bfb59b');ellipse(g,x+w*.5,y-2,w*.16,h*.09,'#9ac6bd');
        f(g,x+8,y-17,4,20,'#d9c5a4');f(g,x+7,y-19,6,3,'#a4d2c7');f(g,x+w-12,y-14,4,17,'#d9c5a4');f(g,x+w-13,y-16,6,3,'#a4d2c7');
      }
      if(w>68){f(g,x+8,y+8,w-16,3,'#c5a47f');for(let i=15;i<w-12;i+=9)f(g,x+i,y+12,4,4,'#9b6f75');}
    }
  }
  for(let i=7;i<w-4;i+=11)f(g,x+i,y+h+2,5,3,i%3?'#f3bc91':'#9ac8c1');
  if(k.poi){
    const at=k.poi.x-b.x;
    f(g,at-7,y-10,14,10,'#473d4a');f(g,at-7,y-9,14,2,d.color);f(g,at-3,y-7,6,4,'#ffddb7');
    f(g,x+7,y+h*.61,w-14,15,'#352d43');banner(g,k.poi.sign,x+w*.5,y+h*.61+10,d.color,w>108?8:7);
  }
}

function scenery(g,o,b,R){
  const {x,y,kind}=o;
  if(kind==='runway'){
    const w=o.ns?61:386,h=o.ns?356:61;
    f(g,x-3,y-3,w+6,h+6,'#b0a591');f(g,x,y,w,h,'#514d5a');
    for(let k=18;k<(o.ns?h:w)-15;k+=25){if(o.ns)f(g,x+29,y+k,2,12,'#d8c9b0');else f(g,x+k,y+29,12,2,'#d8c9b0');}
    for(let k=7;k<55;k+=7){if(o.ns){f(g,x+k,y+10,2,12,'#e1d2b9');f(g,x+k,y+h-23,2,12,'#e1d2b9');}else{f(g,x+9,y+k,12,2,'#e1d2b9');f(g,x+w-23,y+k,12,2,'#e1d2b9');}}
    banner(g,'07',x+(o.ns?31:34),y+(o.ns?36:34),'#c7bca7',10);return;
  }
  if(kind==='helipad'){f(g,x-7,y-7,93,69,'#888472');f(g,x,y,80,58,'#5b5f60');ellipse(g,x+39,y+29,26,21,'#72776a');banner(g,'H',x+39,y+39,'#e3d4a1',23);return;}
  if(kind==='plane'){
    const body=[x-5,y+33,x-4,y+9,x-40,y+24,x-45,y+17,x-7,y-9,x-7,y-29,x,y-43,x+6,y-33,x+7,y-9,x+43,y+17,x+40,y+25,x+5,y+9,x+5,y+34];
    poly(g,'#44405784',body.map((v,i)=>v+(i%2?7:8)));poly(g,'#d9c5ab',body);
    f(g,x-4,y-28,8,9,'#6e8295');f(g,x-2,y-24,4,5,'#9bacaa');f(g,x-2,y-9,3,38,'#bba0a2');f(g,x-10,y+29,20,5,'#a58ba0');return;
  }
  if(kind==='awning'||kind==='market'){
    const colors=['#c47762','#709b84','#ce9c69','#aa7295','#7192a0','#cf9b8a'];
    f(g,x+2,y+4,29,12,'#4c3f4d');f(g,x,y,28,11,colors[o.v]);
    for(let k=3;k<26;k+=6)f(g,x+k,y,2,11,'#f1ceaa88');
    return;
  }
  if(kind==='streetlight'){
    f(g,x,y-22,3,24,'#464253');f(g,x-3,y-24,9,3,'#d4b68d');f(g,x-1,y-21,5,2,'#ffe4a9');
    return;
  }
  if(kind==='banner'){
    f(g,x,y-27,3,29,'#51435a');poly(g,'#bc7797',[x,y-27,x+28,y-25,x+26,y-9,x+1,y-11]);
    for(let k=5;k<22;k+=7)f(g,x+k,y-24,3,2,'#f2cfaf');return;
  }
  if(kind==='cafe'){
    f(g,x,y,27,6,'#6c5560');f(g,x+2,y-11,23,10,'#a87c75');f(g,x+4,y-9,19,5,'#e7bd98');
    f(g,x+7,y-7,4,3,'#7a5e6b');f(g,x+16,y-7,4,3,'#7a5e6b');return;
  }
  if(kind==='scooter'){
    f(g,x+2,y+3,6,3,'#1e1a28');f(g,x+13,y+3,6,3,'#1e1a28');ellipse(g,x+5,y+3,3,3,'#11101c');ellipse(g,x+16,y+3,3,3,'#11101c');
    poly(g,'#c78b9a',[x,y-2,x+17,y-3,x+21,y+1,x+5,y+3]);f(g,x+15,y-6,3,5,'#c8b39d');return;
  }
  if(kind==='planter'){
    f(g,x,y-7,14,9,'#634c58');f(g,x+2,y-9,10,4,'#7b9b78');f(g,x+4,y-12,3,5,'#5e8e6c');f(g,x+9,y-13,3,5,'#7ca27a');return;
  }
  if(kind==='marquee'||kind==='sculpture'){f(g,x,y,20,13,'#4e3d56');f(g,x+2,y+2,16,5,kind==='marquee'?'#df8ab1':'#a5c8c6');f(g,x+7,y+13,4,5,'#4e4354');return;}
  if(kind==='containers'||kind==='freight'||kind==='fence'){f(g,x,y,35,14,'#6e514f');for(let i=2;i<34;i+=5)f(g,x+i,y+2,1,10,'#b69e81');return;}
  if(kind==='pier'){
    for(let k=0;k<4;k++){f(g,x+k*32,y-5,27,21,'#9d8f7e');f(g,x+k*32,y-5,27,2,'#d4bfa0');}
    return;
  }
  if(kind==='palm'){tree(g,{x,y,r:16,v:1},'marina');return;}
  if(kind==='bench'){f(g,x,y,16,4,'#6c594f');f(g,x+2,y+1,12,1,'#cfad86');}
}

function tree(g,t,type){
  const {x,y,r,v}=t;
  if(['dunes','canyon','salt'].includes(type)){
    if(type==='salt'){f(g,x,y,r,1,'#efe0bc8c');return;}
    f(g,x+2,y+3,r,4,'#6d574e');f(g,x,y-3,3,r,'#7d825f');f(g,x-4,y,9,2,'#a3a071');f(g,x-1,y-5,2,5,'#b9a47c');return;
  }
  ellipse(g,x+4,y+5,r,r*.57,'#443c4f59');f(g,x-1,y-1,3,r+2,'#796552');
  if(['marina','gardens','strip','islands','oasis','souk'].includes(type)){
    for(let i=0;i<6;i++){
      const a=i*Math.PI/3+.17*v, u=x+Math.cos(a)*r*1.2,w=y+Math.sin(a)*r*.9;
      line(g,i%2?'#628977':'#527563',3,[x,y-3,(x+u)/2,(y+w)/2-2,u,w]);
    }
  }else{ellipse(g,x,y-3,r,r*.65,'#4f6b60');ellipse(g,x-3,y-6,r*.61,r*.40,'#71907a');}
}