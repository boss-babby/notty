import { CELL, COLS, ROWS, PLACES, DISTRICTS, SEED } from './data.js';
import { hash, mod, rng, SpatialHash } from './core.js';
import { arterial, bridgeDeck, cellKey, closestJunction, expansionWater, legacyCell, roadConnection, wetland, zoneFor } from './geography.js';
import { eastChunk, paintEast, waterMask } from './monsoon-world.js';
import { originalCell, outerRoadAt } from './frontier-geo.js';
import { frontierChunk, paintFrontier } from './frontier-world.js';

export const districtAt = zoneFor;
export const districtOf=(x,y,seed=SEED,style='continental')=>districtAt(Math.floor(x/CELL),Math.floor(y/CELL),seed,style);
const streetEdge = d => Math.min(d, CELL - d);
const roadDist = a => streetEdge(mod(a, CELL));
const keyFor = cellKey;

export function isWater(x,y,seed=SEED,style='continental') {
  const u = mod(x, CELL), v = mod(y, CELL), cx = Math.floor(x / CELL), cy = Math.floor(y / CELL);
  if(wetland(x,y,seed,style))return expansionWater(x,y,seed,style);
  if (!legacyCell(cx,cy)) return false;
  if (cx === 7) return u > 71 && u < 416 && streetEdge(v) > 44 && !(u < 153 && v > 209 && v < 235);
  if (cx === 9) return u > 61 && !(u < 230 && (v < 15 || v > 466 || (v > 224 && v < 251)));
  return false;
}

export function isRoad(x,y,seed=SEED,style='continental') {
  const raw=wetland(x,y,seed,style),cx=Math.floor(x/CELL),cy=Math.floor(y/CELL);
  if(raw)return bridgeDeck(x,y,raw,seed,style);
  if(!originalCell(cx,cy))return outerRoadAt(x,y,seed,style);
  if(legacyCell(cx,cy))return !isWater(x,y,seed,style)&&(roadDist(x)<=42||roadDist(y)<=42);
  return arterial(x,y) || x>12*CELL&&y<9*CELL&&(Math.abs(mod(x,CELL)-231)<12||Math.abs(mod(y,CELL)-240)<12);
}

export function buildChunk(cx,cy,seed,broken=new Set(),style='continental') {
  if(!originalCell(cx,cy))return withPanels(frontierChunk(cx,cy,keyFor(cx,cy),seed,style,broken),broken);
  if(!legacyCell(cx,cy))return withPanels(eastChunk(cx,cy,seed,broken),broken);
  const id = keyFor(cx, cy), x = cx * CELL, y = cy * CELL, zone = districtAt(cx, cy);
  const rand = rng(hash(cx, cy, seed));
  const poi = PLACES.find(p => p.cx === cx && p.cy === cy);
  const blocks = [], props = [], trees = [], lights = [];
  const type = cx === 7 ? 'canal' : cx === 9 ? 'pier' : zone === 1 ? 'yard' : !poi && (rand() < .19 || (zone === 2 && rand() < .32)) ? 'park' : 'blocks';
  for (const [lx, ly] of [[49,50],[431,50],[49,430],[431,430],[49,240],[240,49]]) {
    if (!isWater(x + lx, y + ly)) lights.push({ x: x + lx, y: y + ly, hue: zone === 3 ? '#89d4ff' : '#ffc174' });
  }
  if (type === 'blocks' || type === 'yard') {
    const lots = [[75,83],[259,86],[77,262],[259,260]];
    for (let n = 0; n < lots.length; n++) {
      if (n && rand() < .23 || !n && !poi && rand() < .065) continue;
      const [lx, ly] = lots[n];
      const w = 110 + Math.floor(rand() * 44), h = 106 + Math.floor(rand() * 50);
      blocks.push({ x: x + lx, y: y + ly, w, h, variant: Math.floor(rand() * 4), height: 5 + Math.floor(rand() * (zone === 0 ? 19 : 10)), poi: n === 0 ? poi : null });
    }
  }
  if (type !== 'canal' && type !== 'pier') {
    for (let i = 0; i < (type === 'park' ? 24 : 8); i++) {
      const lx = 57 + rand() * 367, ly = 74 + rand() * 347;
      if (blocks.some(b => x + lx > b.x - 16 && x + lx < b.x + b.w + 20 && y + ly > b.y - 20 && y + ly < b.y + b.h + 25)) continue;
      if (Math.abs(lx - 239) < 17 || Math.abs(ly - 239) < 16 || (ly < 105 && lx < 165)) continue;
      trees.push({ x: x + lx, y: y + ly, r: 7 + rand() * 8, variant: Math.floor(rand() * 4) });
    }
    for (let i = 0; i < 5; i++) {
      const px = x + (i % 2 ? 242 : 224) + rand() * 7, py = y + 114 + i * 66 + rand() * 10;
      const kind = ['crate', 'barrel', 'fence', 'crate', 'sign'][i];
      const id2 = `${id}:${i}`;
      if (!broken.has(id2)) props.push({ x: px, y: py, w: kind === 'fence' ? 25 : 12, h: 10, hp: kind === 'fence' ? 22 : 30, type: 'prop', kind, id: id2 });
    }
  }
  const tape = rand() < .42 && type !== 'canal' && type !== 'pier' ? { x: x + 236, y: y + 231, id: `tape-${id}` } : null;
  return withPanels({ id, cx, cy, x, y, zone, type, blocks, props, trees, lights, tape, poi },broken);
}

function withPanels(b,broken){
  b.panels=[];
  for(const [i,q] of b.blocks.entries()){
    if(q.w<55||q.kind==='rock')continue;
    const id=`pane-${b.id}-${i}`, gone=broken.has(id), w=Math.min(43,q.w*.45);
    const glass={x:q.x+q.w*.3,y:q.y+q.h+2,w,h:5,id,kind:'window',material:'glass',type:'prop',hp:gone?0:17,projectileOnly:true};
    b.panels.push(glass);if(!gone)b.props.push(glass);
  }
  return b;
}

export class City {
  constructor(seed,style='continental') {
    this.seed=seed;this.style=style;this.active=[];this.cache=new Map();this.tiles=new Map();this.charted=new Set();
    this.broken = new Set(); this.temporary=[]; this.playerProps=[]; this.hash = new SpatialHash(96); this.near = []; this.k = ''; this.changed = false;
  }
  get(cx, cy) {
    const key = keyFor(cx, cy);
    if(!this.cache.has(key))this.cache.set(key,buildChunk(cx,cy,this.seed,this.broken,this.style));
    return this.cache.get(key);
  }
  water(x,y){return isWater(x,y,this.seed,this.style);}
  road(x,y){return isRoad(x,y,this.seed,this.style);}
  grip(x,y){
    if(this.road(x,y))return 1;
    const t=DISTRICTS[this.zone(x,y)]?.type;
    return t==='dunes'?.56:t==='salt'?.91:t==='canyon'||t==='oasis'||t==='juniper'?.66:.74;
  }
  zone(x,y){return districtOf(x,y,this.seed,this.style);}
  at(x, y) { return this.get(Math.floor(x / CELL), Math.floor(y / CELL)); }
  stream(x, y) {
    const cx=Math.floor(x/CELL),cy=Math.floor(y/CELL);
    this.charted.add(`${cx}:${cy}`);
    const k = `${cx}:${cy}`;
    if (k === this.k && !this.changed) return;
    this.k = k; this.changed = false; this.hash.clear(); this.active.length = 0;
    for (let j = cy - 2; j <= cy + 2; j++) for (let i = cx - 2; i <= cx + 2; i++) {
      const b = this.get(i, j);
      if (!b) continue;
      this.active.push(b);
      for (const o of b.blocks) this.hash.add(o, o.x, o.y, o.w, o.h);
      for (const o of b.props) if (o.hp > 0) this.hash.add(o, o.x, o.y, o.w, o.h);
    }
    for(const o of this.temporary)if(o.hp>0)this.hash.add(o,o.x,o.y,o.w,o.h);
    for(const o of this.playerProps)if(o.hp>0&&Math.abs(o.x-x)<1280&&Math.abs(o.y-y)<1280)this.hash.add(o,o.x,o.y,o.w,o.h);
    const ids = new Set(this.active.map(b => b.id));
    for (const key of this.cache.keys()) if (!ids.has(key)) this.cache.delete(key);
    for (const key of this.tiles.keys()) if (!ids.has(key)) this.tiles.delete(key);
  }
  tile(b) {
    if (!this.tiles.has(b.id)) {
      const surface = document.createElement('canvas');
      surface.width = CELL; surface.height = CELL;
      const ctx=surface.getContext('2d');
      if(b.frontier)paintFrontier(ctx,b,this.seed,this.style);
      else if(b.east)paintEast(ctx,b,this.seed);
      else { paintChunk(ctx,b,this.seed); if(b.cx===9)waterMask(ctx,[b.x,b.y,CELL,CELL],5,true); }
      this.tiles.set(b.id, surface);
    }
    return this.tiles.get(b.id);
  }
  block(x, y, r, vault = false) {
    const found = this.hash.query(x - r, y - r, r * 2, r * 2, this.near);
    for (const b of found) {
      if (b.type === 'prop' && (b.projectileOnly || vault && !b.solid || b.hp <= 0)) continue;
      if (x + r > b.x && x - r < b.x + b.w && y + r > b.y && y - r < b.y + b.h) return b;
    }
    return null;
  }
  line(x, y, xx, yy) {
    const n = Math.ceil(Math.hypot(xx - x, yy - y) / 22);
    for (let i = 1; i < n; i++) {
      if (this.block(x + (xx - x) * i / n, y + (yy - y) * i / n, 3, true)) return false;
    }
    return true;
  }
  move(body, dx, dy, radius, vault = false) {
    let hit = null;
    const x=body.x+dx,y=body.y+dy;
    const hX = this.block(x, body.y, radius, vault);
    if (!hX) body.x = x; else hit = hX;
    const hY = this.block(body.x, y, radius, vault);
    if (!hY) body.y = y; else hit = hY;
    return hit;
  }
}

// A* on the intersection graph. Turns use lane offsets chosen by the actor.
export function roadPath(from,to,seed=SEED,style='continental') {
  const start=closestJunction(from,seed,style), goal=closestJunction(to,seed,style);
  const ids = p => keyFor(p.x, p.y), goalId = ids(goal);
  const h = p => Math.abs(goal.x - p.x) + Math.abs(goal.y - p.y);
  const open = [{ ...start, g: 0, f: h(start), prev: null }], best = new Map([[ids(start), 0]]);
  let tries=0;
  while(open.length&&tries++<3300){
    let low = 0;
    for (let i = 1; i < open.length; i++) if (open[i].f < open[low].f) low = i;
    const [p] = open.splice(low, 1);
    if (ids(p) === goalId) {
      const path = [];
      for (let v = p; v; v = v.prev) path.push({ x: v.x * CELL, y: v.y * CELL });
      return path.reverse();
    }
    for (const [dx, dy] of [[1,0],[0,1],[-1,0],[0,-1]]) {
      const x = p.x + dx, y = p.y + dy;
      if(!roadConnection(p.x,p.y,x,y,seed,style))continue;
      const g = p.g + 1 + (hash(x, y, seed) % 11) * .013;
      if (g >= (best.get(keyFor(x, y)) ?? Infinity)) continue;
      best.set(keyFor(x, y), g);
      open.push({ x, y, g, f: g + h({ x, y }), prev: p });
    }
  }
  return [];
}

export function signalAt(x, y, clock, horizontal) {
  const ph = mod(clock + (Math.round(x / CELL) * 3 + Math.round(y / CELL) * 4), 14);
  return horizontal ? ph < 6.8 : ph >= 7.3 && ph < 13.5;
}

export { roomGeometry } from './interiors.js';

function paintChunk(g, b, seed) {
  const R = rng(hash(b.cx, b.cy, seed + 912)), d = DISTRICTS[b.zone];
  const f = (x, y, w, h, color) => { g.fillStyle = color; g.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); };
  f(0, 0, CELL, CELL, '#2a2531');
  f(42, 42, 396, 396, '#6d5768'); f(44, 44, 391, 391, '#504452'); f(57, 57, 366, 366, d.ground);
  for (let n = 60; n < 431; n += 13) {
    f(n, 44, 1, 13, '#29233366'); f(n, 423, 1, 13, '#29233366'); f(44, n, 13, 1, '#29233366'); f(423, n, 13, 1, '#29233366');
  }
  for (let i = 0; i < 990; i++) {
    const x = R() * CELL, y = R() * CELL;
    f(x, y, 1 + R() * 3, 1, R() < .62 ? '#8f799627' : '#100f2059');
  }
  for (let i = 56; i < 427; i += 28) {
    f(i, 0, 13, 2, '#b18a765c'); f(i, 478, 13, 2, '#b18a765c'); f(0, i, 2, 13, '#b18a765c'); f(478, i, 2, 13, '#b18a765c');
  }
  for (const v of [29, 450]) for (let z = 4; z < 42; z += 8) {
    for (const off of [0, 436]) { f(v, z + off, 10, 4, '#bba2ac66'); f(z + off, v, 4, 10, '#bba2ac66'); }
  }
  for (const [x, y, rx, ry] of [[22,20,55,0],[458,20,-55,0],[22,458,0,-55],[458,458,0,-55]]) {
    const r = R();
    f(x + rx, y + ry, 13, 1, '#8c748055'); f(x + rx + 3, y + ry - 3, 5, 1, '#8c748066');
    if (r < .7) f(x + rx + 5, y + ry - 4, 1, 9, '#9e86935c');
  }

  if (b.type === 'canal' || b.type === 'pier') {
    const left = b.type === 'canal' ? 72 : 62, right = b.type === 'canal' ? 416 : CELL;
    const y = b.type === 'canal' ? 44 : 0, h = b.type === 'canal' ? 392 : CELL;
    f(left - 6, y, right - left + 12, h, '#784f5d');
    f(left, y, right - left, h, '#20293e'); f(left + 6, y, right - left - 8, h, '#20283d');
    for (let n = 0; n < 250; n++) {
      const x = left + R() * (right - left - 17), yy = y + R() * h;
      f(x, yy, 2 + R() * 14, 1, R() < .5 ? '#495a7d96' : '#7088a23e');
    }
    f(left - 5, 0, 6, CELL, '#4a425a'); f(left, y, 2, h, '#8490a693');
    if (b.type === 'canal') {
      f(left + 2, 208, 78, 28, '#524653'); f(left + 2, 208, 83, 2, '#978085'); f(412, y, 5, h, '#686985');
      for (let i = 0; i < 7; i++) f(left + 13 + i * 8, 211, 1, 23, '#29243796');
      for (const yy of [38, 441]) { f(left, yy, right - left, 5, '#887083'); f(left, yy + 2, right - left, 2, '#2b223a'); }
    } else {
      for (const yy of [-12, 223, 467]) {
        f(55, yy, 174, 28, '#62505b'); f(61, yy + 1, 166, 2, '#a29192');
        for (let j = 67; j < 224; j += 8) f(j, yy + 3, 1, 23, '#352c40');
        f(193, yy + 7, 23, 14, '#aa7968');
      }
    }
  } else if (b.type === 'park') {
    f(63, 66, 354, 349, '#303e43'); f(66, 68, 349, 344, '#324047');
    f(232, 65, 17, 351, '#5e505d'); f(65, 233, 351, 16, '#5e515c');
    f(276, 284, 75, 59, '#5f626d'); f(280, 288, 67, 51, '#344d61');
    for (let i = 0; i < 210; i++) f(68 + R() * 342, 68 + R() * 339, 1 + R() * 5, 1, R() < .5 ? '#66827654' : '#1f313d79');
    f(211, 213, 58, 55, '#645764'); f(215, 216, 50, 48, '#404d62'); f(229, 230, 22, 19, '#708999');
    f(237, 235, 7, 4, '#bbc7c6');
  } else {
    f(220, 58, 31, 365, '#252431'); f(57, 220, 365, 29, '#2b2634');
    f(220, 57, 2, 366, '#746071'); f(249, 57, 2, 366, '#4f4453'); f(57, 248, 365, 2, '#655367');
    for (let i = 0; i < 6; i++) {
      f(59 + i * 19, 226, 15, 1, '#99869666'); f(266 + i * 20, 227, 2, 15, '#9b839970');
      f(229, 72 + i * 57, 11, 5, '#4a4354'); f(229, 73 + i * 57, 11, 1, '#686074');
    }
    if (b.type === 'yard') {
      for (let i = 0; i < 2; i++) {
        f(62, 374 + i * 13, 358, 2, '#a1807358'); f(62, 377 + i * 13, 358, 1, '#17202b');
      }
      for (let i = 0; i < 25; i++) f(63 + i * 14, 370, 2, 25, '#544153');
    }
  }

  for (const k of b.blocks) {
    const x = k.x - b.x, y = k.y - b.y, { w, h } = k; const z = k.height;
    f(x + 7, y + 9, w + z + 4, h + z + 8, '#13132188');
    f(x + 2, y + 4, w + 6, h + 13, '#201b2c');
    f(x + w - 4, y + 3, 8, h + 6, '#322a3e');
    f(x - 1, y - z / 2, w + 2, h + z / 2, '#766477');
    f(x + 3, y - z / 2 + 4, w - 6, h + z / 2 - 10, d.roof);
    f(x + 7, y - z / 2 + 8, w - 14, h + z / 2 - 18, k.variant % 2 ? '#372c42' : '#493b50');
    f(x + 8, y - z / 2 + 9, w - 16, 2, '#7867816a');
    f(x - 1, y - z / 2, w + 2, 2, '#ad879597');
    f(x + 1, y + h - 4, w, 4, '#232033');
    for (let i = 0; i < 13; i++) {
      const px = x + 10 + R() * (w - 23), py = y + 7 + R() * (h - 19);
      f(px, py, 1 + R() * 9, 1, R() < .44 ? '#80677969' : '#241f348b');
    }
    for (let i = 0; i < 3; i++) {
      const xx = x + 15 + i * 19 + R() * 8, yy = y + 13 + R() * (h / 2);
      f(xx + 3, yy + 3, 15, 13, '#262036'); f(xx, yy, 15, 11, '#646077'); f(xx + 2, yy + 2, 11, 7, '#363348');
      f(xx + 3, yy + 3, 9, 1, '#9f8a9a66'); f(xx + 3, yy + 5, 9, 1, '#9f8a9a66');
    }
    for (let i = 11; i < w - 8; i += 10 + k.variant) {
      if (R() < .76) { f(x + i, y + h + 2, 6, 4, '#110f1b'); f(x + i + 1, y + h + 2, 4, 2, R() < .65 ? '#dda37f' : d.color); }
    }
    if (k.poi) {
      const door = k.poi.x - b.x;
      f(door - 15, y - z / 2 - 3, 30, 6, d.color); f(door - 10, y - z / 2 - 2, 20, 2, '#fff0dc');
      f(door - 12, y - 6, 24, 9, '#191725'); f(door - 7, y - 8, 14, 5, d.color);
      f(x + 17, y + h / 2 - 18, w - 34, 23, '#251e32'); f(x + 17, y + h / 2 - 18, w - 34, 1, d.color);
      g.fillStyle = d.color; g.textAlign = 'center'; g.font = '700 9px monospace'; g.fillText(k.poi.sign, x + w / 2, y + h / 2 - 4);
    } else if (k.variant === 3) {
      f(x + 21, y + h / 2, 39, 13, '#25213a'); f(x + 24, y + h / 2 + 3, 33, 2, d.color);
      f(x + 27, y + h / 2 + 7, 22, 1, '#a8909d');
    }
  }

  for (const t of b.trees) {
    const x = t.x - b.x, y = t.y - b.y, radius = t.r;
    f(x + 1, y + 4, radius * 1.1, radius * .8, '#1a1c2bad');
    f(x - 2, y + 2, 4, 8, '#695058');
    f(x - radius * .8, y - radius * .43, radius * 1.6, radius * .9, '#253547');
    f(x - radius * .6, y - radius * .71, radius * 1.2, radius * 1.2, '#293d46');
    const shades = ['#445953', '#34585a', '#546259', '#425162'];
    f(x - radius * .46, y - radius * .58, radius * .9, radius * .47, shades[t.variant]);
    f(x - radius * .52, y - 1, radius * .84, 3, '#566c666a');
  }
}