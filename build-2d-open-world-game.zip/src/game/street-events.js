import { CELL, DISTRICTS, modelIndex } from './data.js';
import { clamp, dist } from './core.js';
import { NEW_FACTIONS } from './atlas-data.js';
import { regionOf } from './geography.js';
import { freeNear } from './navigation.js';
import { setRoad } from './traffic.js';

export const EVENT_OPTIONS=[['auto','Random street event'],['robbery','Market robbery'],['chase','Traffic pursuit'],['race','Street race'],['ambulance','Medical response'],['fire','Fire response'],['protest','Street vigil'],['turf','Territory dispute'],['lost','Lost dispatch pouch']];
const CYCLE=['robbery','ambulance','race','fire','chase','protest','turf','lost'];
const LOCAL=[['River Cooperative','Verge Works'],['Civic Union','Verge Works']];
const BAY=[['Coil Union','Prism Crew'],['Prism Crew','Civic Grid']];
const repKey={'River Cooperative':'River','Verge Works':'Verge','Civic Union':'Civic','Coil Union':'Coil','Prism Crew':'Prism','Civic Grid':'Grid',...NEW_FACTIONS};
export const factionDisposition=(g,faction)=>{const score=g.rep[repKey[faction]]||0;return score>=2?'Allied':score<=-2?'Hostile':'Neutral';};

function clearRoad(g){
  const p=g.player, jx=Math.round(p.x/CELL)*CELL,jy=Math.round(p.y/CELL)*CELL;
  for(const [a,b,dx,dy] of [[190,21,1,0],[-197,-18,-1,0],[18,202,0,1],[-18,-213,0,-1],[233,-18,-1,0],[-238,18,1,0],[18,-170,0,1],[-18,178,0,-1]]){
    const x=jx+a,y=jy+b;
    if(Math.hypot(x-p.x,y-p.y)<122||!g.city.road(x,y)||g.city.water(x,y)||g.city.block(x,y,14))continue;
    if(g.cars.some(v=>Math.hypot(v.x-x,v.y-y)<69))continue;
    return {x,y,dx,dy,a:Math.atan2(dy,dx)};
  }
  return null;
}

function placeVehicle(g,addCar,id,road,speed,offset=0,options={}){
  const x=road.x-road.dx*offset,y=road.y-road.dy*offset;
  const model=modelIndex(id);
  const v=addCar(g,model,x,y,road.a,'runner',{runnerSpeed:speed,cruise:speed,serviceLights:false,...options});
  setRoad(v,road.dx,road.dy);return v;
}

export function startStreetEvent(g,addCar,addPerson,requested='auto'){
  if(g.room||g.outbreak||g.practice||g.streetEvent)return false;
  const road=clearRoad(g);if(!road)return false;
  const i=g.streetIndex??Math.floor(g.rand()*CYCLE.length), kind=requested==='auto'?CYCLE[i%CYCLE.length]:requested;
  if(!CYCLE.includes(kind))return false;
  const side={x:road.x-road.dy*49,y:road.y+road.dx*49};
  const onFoot=freeNear(g,side,9,47)||{x:road.x,y:road.y};
  const e={kind,x:onFoot.x,y:onFoot.y,time:0,duration:34,people:[],rides:[],reportAt:0,stage:'arriving',zone:g.city.zone(onFoot.x,onFoot.y)};
  const mark=()=>{g.streetEvent=e;g.streetIndex=i+1;return true;};
  const who=(type,x,y,options={})=>{
    const pos=freeNear(g,{x,y},8,37);if(!pos)return null;
    const n=addPerson(g,type,pos.x,pos.y,{keep:true,tx:pos.x,ty:pos.y,...options});if(n)e.people.push(n);return n;
  };
  if(kind==='chase'||kind==='race'){
    const lead=placeVehicle(g,addCar,kind==='chase'?'havoc':'vanta',road,kind==='chase'?163:179,0,{turnLog:new Map(),keep:true});
    const tail=placeVehicle(g,addCar,kind==='chase'?'patrol':'havoc',road,kind==='chase'?172:178,65,{followVehicle:lead,keep:true,siren:kind==='chase',color:kind==='chase'?'#7c94bd':'#dfa17d'});
    e.rides.push(lead,tail);e.duration=23;e.stage='running';
    g.report(kind==='chase'?'A Grid cruiser follows a speeding car through town.':'Two street racers leave the junction nose to tail.');return mark();
  }
  if(kind==='robbery'){
    e.duration=45;e.stage='runner';
    const courier=who('ped',onFoot.x+12,onFoot.y,{routine:'parcel',state:'flee',timer:18,color:'#cfaabc',identity:'PARCEL',fearAt:{x:g.player.x,y:g.player.y},hp:42});
    if(!courier)return false;
    e.courier=courier;
    who('ped',onFoot.x-19,onFoot.y+12,{routine:'victim',color:'#efb38e',state:'call',timer:2,fearAt:{x:onFoot.x,y:onFoot.y}});
    g.notify('Stall robbery','Follow the mint marker to recover the dropped parcel.','warn');g.report('A vendor reports a snatched parcel.');return mark();
  }
  if(kind==='ambulance'||kind==='fire'){
    const medical=kind==='ambulance', model=medical?'rescue':'hearth', back=155;
    const spawn={x:road.x-road.dx*back,y:road.y-road.dy*back};
    const at=freeNear(g,spawn,16,58)||road;
    const v=addCar(g,modelIndex(model),at.x,at.y,road.a,'response',{serviceLights:true,siren:true,owned:false,keep:true,caseId:kind});
    e.rides.push(v);e.stop={x:road.x,y:road.y};e.duration=31;e.stage='approach';
    if(medical)e.patient=who('ped',onFoot.x,onFoot.y,{routine:'victim',identity:'PATIENT',color:'#e1b3b2'});
    g.report(medical?'An Echo medical crew heads to a roadside call.':'Hearth Response was dispatched to a smoking street kiosk.');return mark();
  }
  if(kind==='protest'){
    for(let i=0;i<6;i++)who('ped',onFoot.x+(i%3-1)*15,onFoot.y+(i<3?0:17),{routine:'vigil',identity:i===0?'VIGIL':null,color:['#deb88a','#b9a9d3','#9bc4c4'][i%3]});
    e.stage='gathered';e.duration=39;g.report('A candlelight vigil gathers at the curb.');return mark();
  }
  if(kind==='turf'){
    const region=regionOf(road.x,road.y),pool=region==='mirage'?[['Copper Lantern','Meridian Guild'],['Crescent Pilots','Copper Lantern']]:region==='basin'?[['Velvet Circuit','Sunbelt Riders'],['Sunbelt Riders','Copper Lantern']]:region==='monsoon'?LOCAL:BAY;
    const teams=pool[e.zone%pool.length];e.teams=teams;e.stage='contested';e.duration=35;
    for(let j=0;j<2;j++)for(let k=0;k<2;k++){
      const n=who('rival',onFoot.x+(j?1:-1)*(47+k*15),onFoot.y+12+k*8,{color:j?'#d897ae':'#86b9b2',hp:54,identity:k?null:teams[j],sideGroup:j,team:teams[j]});
      if(n){n.partnerPoint={x:onFoot.x,y:onFoot.y};n.cd=.4+(n.id%4)*.17;}
    }
    if(e.people.length<2){for(const n of e.people)n.active=false;return false;}
    g.report(`A local dispute challenges control near ${DISTRICTS[e.zone].name}.`);return mark();
  }
  e.stage='dropped';e.duration=54;g.report('A courier reports a missing dispatch pouch.');return mark();
}

export function streetMarker(g){
  const e=g.streetEvent;
  if(!e||g.room)return null;
  if(e.kind==='robbery'&&e.courier?.active&&!e.courier.dead)return {x:e.courier.x,y:e.courier.y,label:'Recover the parcel'};
  if(e.kind==='robbery'||e.kind==='lost')return {x:e.x,y:e.y,label:e.kind==='lost'?'Return the dispatch pouch':'Recover the parcel'};
  return null;
}

export function streetUse(g){
  const e=g.streetEvent, point=streetMarker(g);
  if(!e||!point||g.car||dist(g.player,point)>34)return false;
  const pay=e.kind==='robbery'?95:65;
  g.cash+=pay;g.stats.jobs++;g.notify('Parcel returned',`The vendor left you $${pay}.`,'ok');g.report('A local delivery was returned with its seal intact.');
  endStreetEvent(g);g.hear('confirm');g.save(true);return true;
}

function endStreetEvent(g){
  const e=g.streetEvent;if(!e)return;
  for(const n of e.people){n.keep=false;if(n.type==='rival'||n.routine==='parcel'||n.routine==='victim')n.active=false;else{n.routine='';n.identity=null;}}
  for(const v of e.rides){v.keep=false;v.serviceLights=false;v.siren=false;if(v.mode==='response'){v.mode='traffic';v.road=null;}}
  g.streetEvent=null;
}

export function tickStreetEvents(g,dt,addPerson,hurtPerson){
  const e=g.streetEvent;if(!e||g.room)return;
  e.time+=dt;
  if(e.kind==='robbery'&&e.courier?.dead){e.x=e.courier.x;e.y=e.courier.y;e.stage='dropped';}
  if((e.kind==='fire'||e.kind==='ambulance')&&e.rides[0]?.mode==='response'){
    const v=e.rides[0], stop=e.stop, d=dist(v,stop);
    if(e.stage==='approach'){
      if(d<24||e.time>8){
        e.stage='working';e.workAt=e.time;v.vx=v.vy=v.speed=0;v.brake=true;
        const n=addPerson(g,'ped',v.x-Math.sin(v.a)*18,v.y+Math.cos(v.a)*18,{tx:e.x,ty:e.y,keep:true,routine:'response',identity:e.kind==='fire'?'FIRE CREW':'MEDIC',color:e.kind==='fire'?'#e2b17d':'#b4d4ca'});
        if(n)e.people.push(n);
      }else{
        const a=Math.atan2(stop.y-v.y,stop.x-v.x),speed=Math.min(118,d*2.55);
        const dx=Math.cos(a)*speed,dy=Math.sin(a)*speed;
        const x=v.x+dx*dt,y=v.y+dy*dt,close=g.cars.some(o=>o!==v&&o.alt<18&&Math.hypot(o.x-x,o.y-y)<o.r+v.r+3&&Math.hypot(o.x-x,o.y-y)<dist(o,v));
        v.a=a;v.vx=close?0:dx;v.vy=close?0:dy;v.speed=close?0:speed;g.city.move(v,v.vx*dt,v.vy*dt,v.r);
      }
    }else if(e.stage==='working'&&e.time-e.workAt>6.2){
      e.stage='cleared';e.duration=Math.min(e.duration,e.time+4);
      if(e.patient)e.patient.active=false;
      for(const n of e.people)if(n.routine==='response'){n.tx=v.x;n.ty=v.y;}
      g.report(e.kind==='fire'?'The crew makes the kiosk safe and the lane reopens.':'An Echo crew takes the patient to the clinic.');
    }
    if(e.kind==='fire'&&e.stage!=='cleared'&&e.time>e.reportAt){
      e.reportAt=e.time+.17;g.fx(e.x,e.y,'#ac9898',3,19,'smoke');g.light(e.x,e.y,'#e0a375',23,.17);
    }
  }
  if(e.kind==='turf'&&e.teams){
    const counts=[0,0];
    for(const n of e.people){
      if(!n.active||n.dead)continue;counts[n.sideGroup]++;
      const target=e.people.find(other=>other.active&&!other.dead&&other.sideGroup!==n.sideGroup);if(!target)continue;
      n.cd-=dt;const d=dist(n,target);n.a=Math.atan2(target.y-n.y,target.x-n.x);
      if(d>23)g.city.move(n,Math.cos(n.a)*51*dt,Math.sin(n.a)*51*dt,n.r);
      else if(n.cd<=0){n.cd=.75;hurtPerson(g,target,9,'world');g.hear('body',n.x,n.y,.4);}
    }
    if(e.time>3.5&&(!counts[0]||!counts[1]||e.time>=e.duration)){
      const winner=e.teams[counts[0]>=counts[1]?0:1];g.territory[e.zone]=winner;
      g.report(`${winner} now controls the disputed corner in ${DISTRICTS[e.zone].name}.`);endStreetEvent(g);g.save(true);return;
    }
  }
  if(e.time>=e.duration||e.time>12&&dist(e,g.player)>910)endStreetEvent(g);
}