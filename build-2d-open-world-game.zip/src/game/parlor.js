import { clamp } from './core.js';

export const TABLES={
  carrom:{name:'Carrom Table',room:'cha',subtitle:'NODI CHA / CORNER TABLE',shots:6,target:5,prize:85,description:'Aim from the sitting edge. Turn slightly left or right, set your power, then shoot for a corner pocket.'},
  darts:{name:'Neon Darts',room:'arcade',subtitle:'SOFT RESET / THROW LINE',shots:5,target:115,prize:100,description:'Land five throws. Throwing is timed: press when the crosshair reaches the center.'},
  dyno:{name:'Workshop Dyno',room:'garage',subtitle:'WORKSHOP / TUNING BAY',shots:5,target:4,prize:75,description:'Shift in the highlighted RPM band. Hit four clean shifts to certify your tune.'},
};
const board={size:240,holes:[[18,18],[222,18],[18,222],[222,222]]};

function coin(x,y,r,kind){return {x,y,r,kind,vx:0,vy:0,down:false};}
export function newTable(g,id){
  const spec=TABLES[id];if(!spec)return null;
  const pieces=[];
  if(id==='carrom'){
    for(let n=0;n<6;n++){
      const a=.42+n*Math.PI/3;pieces.push(coin(120+Math.cos(a)*17,105+Math.sin(a)*17,5.8,n%2?'cream':'ink'));
    }
    pieces.push(coin(120,105,6,'queen'),coin(120,194,8,'striker'));
  }
  return {id,clock:0,round:0,score:0,last:'',ended:false,busy:false,offset:0,angle:0,power:72,marker:.12,goal:.73,marks:[],pieces};
}

export function tableView(g){
  const t=g.table;if(!t)return null;
  return {...t, best:g.records?.[t.id]?.best||0};
}

export function adjustTable(g,field,n){
  const t=g.table;if(!t||t.id!=='carrom'||t.busy||t.ended)return;
  const piece=t.pieces.at(-1);
  if(field==='table-angle')t.angle=clamp(n,-66,66);
  if(field==='table-power')t.power=clamp(n,25,100);
  if(field==='table-offset'){t.offset=clamp(n,-45,45);piece.x=120+t.offset;}
}

function finish(g,t){
  const s=TABLES[t.id];t.ended=true;t.busy=false;
  const rec=g.records[t.id]||{plays:0,wins:0,best:0};
  const old=rec.best,win=t.score>=s.target;
  g.records[t.id]={plays:rec.plays+1,wins:rec.wins+Number(win),best:Math.max(rec.best,t.score)};
  if(win){g.cash+=s.prize+(t.score>old?35:0);g.stats.jobs++;g.hear('confirm');g.report(`${s.name} posts a successful new score at the counter.`);}
  else g.hear('click');
  t.last=win?`Target reached. +$${s.prize+(t.score>old?35:0)}.`:'Round complete. Your score is on the local board.';
  g.save(true);
}

export function playTable(g){
  const t=g.table;if(!t||t.ended||t.busy)return;
  if(t.id==='carrom'){
    const s=t.pieces.at(-1),a=t.angle*Math.PI/180,k=2.7*t.power+68;
    s.vx=Math.sin(a)*k;s.vy=-Math.cos(a)*k;t.busy=true;t.settle=0;t.round++;t.last='Watch the pockets.';g.hear('wood');
  }else if(t.id==='darts'){
    const x=Math.sin(t.clock*3.23)*.92,y=Math.sin(t.clock*2.32+.7)*.9,r=Math.hypot(x,y);
    const hit=r<.14?50:r<.31?36:r<.5?26:r<.71?17:r<.92?9:0;
    t.score+=hit;t.round++;t.last=hit?`${hit} points on that throw.`:'Outside the board.';t.marks.push({x,y,kind:hit});t.wait=.36;g.hear('wood');
  }else{
    const hit=Math.abs(t.marker-t.goal)<.13;
    t.score+=Number(hit);t.round++;t.last=hit?'Clean shift.':'Missed the power band.';t.marks.push({kind:hit?1:0});t.wait=.39;g.hear(hit?'confirm':'click');
    t.goal=.61+(t.round%3)*.077;
  }
  if(t.id!=='carrom'&&t.round>=TABLES[t.id].shots)finish(g,t);
}

function stepCarrom(g,t,dt){
  let max=0;
  const pieces=t.pieces;
  for(const s of pieces)if(!s.down){
    s.x+=s.vx*dt;s.y+=s.vy*dt;
    const slow=Math.exp(-1.12*dt);s.vx*=slow;s.vy*=slow;
    if(s.x<s.r+7||s.x>board.size-s.r-7){s.x=clamp(s.x,s.r+7,board.size-s.r-7);s.vx*=-.78;}
    if(s.y<s.r+7||s.y>board.size-s.r-7){s.y=clamp(s.y,s.r+7,board.size-s.r-7);s.vy*=-.78;}
    if(board.holes.some(([x,y])=>(s.x-x)**2+(s.y-y)**2<117)){
      s.down=true;s.vx=s.vy=0;
      if(s.kind==='striker'){t.score=Math.max(0,t.score-1);t.last='Striker pocketed. One point deducted.';}
      else{const p=s.kind==='queen'?3:1;t.score+=p;t.last=s.kind==='queen'?'Queen pocketed: +3.':'Coin pocketed: +1.';g.hear('confirm');}
    }
    max=Math.max(max,Math.hypot(s.vx,s.vy));
  }
  for(let i=0;i<pieces.length;i++)for(let j=i+1;j<pieces.length;j++){
    const a=pieces[i],b=pieces[j];if(a.down||b.down)continue;
    const x=b.x-a.x,y=b.y-a.y, min=a.r+b.r, dist=Math.hypot(x,y);if(dist>=min||dist<.001)continue;
    const ux=x/dist,uy=y/dist,push=(min-dist)*.51;
    a.x-=ux*push;a.y-=uy*push;b.x+=ux*push;b.y+=uy*push;
    const hit=(a.vx-b.vx)*ux+(a.vy-b.vy)*uy;
    if(hit>0){a.vx-=ux*hit*.94;a.vy-=uy*hit*.94;b.vx+=ux*hit*.94;b.vy+=uy*hit*.94;}
  }
  t.settle+=dt;
  if(t.settle>4||max<11){
    if(t.round===TABLES.carrom.shots||pieces.slice(0,-1).every(s=>s.down)){finish(g,t);return;}
    const s=pieces.at(-1);s.x=120+t.offset;s.y=194;s.down=false;
    for(const v of pieces)v.vx=v.vy=0;
    t.busy=false;
  }
}

export function tickTable(g,dt){
  const t=g.table;if(!t||t.ended)return;
  t.clock+=dt;t.wait=Math.max(0,(t.wait||0)-dt);
  if(t.id==='carrom'&&t.busy){stepCarrom(g,t,dt/2);if(t.busy)stepCarrom(g,t,dt/2);}
  if(t.id==='dyno')t.marker=(1-Math.cos(t.clock*4.6))*.5;
}

export function tableTrigger(g){if(g.table&&!(g.table.wait>0))playTable(g);}