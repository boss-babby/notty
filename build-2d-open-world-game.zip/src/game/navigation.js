import { clamp, dist } from './core.js';
import { roadPath } from './world.js';

export const landAt=(g,x,y,r=8,vault=false)=>Number.isFinite(x)&&Number.isFinite(y)&&!g.city.water(x,y)&&!g.city.block(x,y,r,vault);

export function clearSegment(g, a, b, r = 7, vault = false) {
  const n = Math.ceil(dist(a,b)/Math.max(8,r*.8));
  for(let i=1;i<=n;i++)if(!landAt(g,a.x+(b.x-a.x)*i/n,a.y+(b.y-a.y)*i/n,r,vault))return false;
  return true;
}

export function freeNear(g, p, r, span = 74) {
  if(landAt(g,p.x,p.y,r))return {x:p.x,y:p.y};
  for(let s=14;s<=span;s+=13)for(let k=0;k<8;k++){
    const a=k*Math.PI/4,x=p.x+Math.cos(a)*s,y=p.y+Math.sin(a)*s;
    if(landAt(g,x,y,r))return {x,y};
  }
  return null;
}

class Frontier {
  constructor(){this.nodes=[];}
  push(n,f){const a=this.nodes;let i=a.length;a.push([n,f]);while(i){const t=(i-1)>>1;if(a[t][1]<=f)break;a[i]=a[t];i=t;}a[i]=[n,f];}
  pop(){const a=this.nodes,first=a[0],end=a.pop();if(a.length){let i=0;while(i*2+1<a.length){let c=i*2+1;if(c+1<a.length&&a[c+1][1]<a[c][1])c++;if(a[c][1]>=end[1])break;a[i]=a[c];i=c;}a[i]=end;}return first[0];}
  get size(){return this.nodes.length;}
}

// A bounded clearance grid handles corners, alleys and parked obstacles without building a city-size navmesh.
export function localPath(g, from, target, r = 8, maxNodes = 960, vault = false) {
  if(clearSegment(g,from,target,r,vault))return [{x:target.x,y:target.y}];
  const step = r > 13 ? 22 : 16, range = 106;
  const length=dist(from,target), t=Math.min(1,490/Math.max(1,length));
  const goal = {x:from.x+(target.x-from.x)*t,y:from.y+(target.y-from.y)*t};
  const lx=Math.floor((Math.min(from.x,goal.x)-range)/step)*step,ly=Math.floor((Math.min(from.y,goal.y)-range)/step)*step;
  const w=Math.ceil((Math.max(from.x,goal.x)+range-lx)/step)+1,h=Math.ceil((Math.max(from.y,goal.y)+range-ly)/step)+1;
  if(w<2||h<2)return [];
  const pass=new Int8Array(w*h), cost=new Float32Array(w*h).fill(Infinity), parents=new Int32Array(w*h).fill(-1);
  const pos=i=>({x:lx+(i%w)*step,y:ly+Math.floor(i/w)*step});
  function walk(i){if(pass[i])return pass[i]>0;const p=pos(i);const v=landAt(g,p.x,p.y,r+1,vault);pass[i]=v?1:-1;return v;}
  function nearest(p, visible){
    const x=clamp(Math.round((p.x-lx)/step),0,w-1),y=clamp(Math.round((p.y-ly)/step),0,h-1);
    let id=-1,d=Infinity;
    for(let j=Math.max(0,y-3);j<=Math.min(h-1,y+3);j++)for(let k=Math.max(0,x-3);k<=Math.min(w-1,x+3);k++){
      const i=k+j*w,q=pos(i),d2=(p.x-q.x)**2+(p.y-q.y)**2;
      if(d2<d&&walk(i)&&(!visible||clearSegment(g,p,q,r,vault))){id=i;d=d2;}
    }
    return id;
  }
  const start=nearest(from,true), end=nearest(goal,false);if(start<0||end<0)return [];
  const ex=end%w,ey=Math.floor(end/w), heuristic=i=>Math.hypot(i%w-ex,Math.floor(i/w)-ey);
  const frontier=new Frontier();frontier.push(start,heuristic(start));cost[start]=0;
  const closed=new Uint8Array(w*h);let best=start,bestH=Infinity;
  const neighbors=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
  let expanded=0;
  while(frontier.size&&expanded<maxNodes){
    const i=frontier.pop();if(closed[i])continue;closed[i]=1;expanded++;
    const v=heuristic(i);if(v<bestH){bestH=v;best=i;}if(i===end)break;
    const x=i%w,y=Math.floor(i/w);
    for(const [dx,dy] of neighbors){
      const a=x+dx,b=y+dy;if(a<0||a>=w||b<0||b>=h)continue;
      const next=a+b*w, value=cost[i]+(dx&&dy?1.4142:1);
      if(closed[next]||value>=cost[next]||!walk(next)||dx&&dy&&(!walk(a+y*w)||!walk(x+b*w)))continue;
      parents[next]=i;cost[next]=value;frontier.push(next,value+heuristic(next)*1.12);
    }
  }
  const raw=[];for(let i=best;i>=0;i=parents[i])raw.push(pos(i));raw.reverse();
  if(best===end&&clearSegment(g,raw.at(-1),goal,r,vault))raw.push(goal);
  const path=[];let here=from,index=0;
  while(index<raw.length){
    let skip=Math.min(index+12,raw.length-1);
    while(skip>index&&!clearSegment(g,here,raw[skip],r,vault))skip--;
    here=raw[skip];if(dist(path.at(-1)||from,here)>4)path.push(here);index=skip+1;
  }
  return path;
}

export function streetRoute(g, from, target, r, lane) {
  const center=roadPath(from,target,g.city.seed,g.city.style);
  const route=[];
  for(let i=0;i<center.length;i++){
    const p=center[i],next=center[i+1]||p,prev=center[i-1]||p;
    const a=Math.atan2(next.y-prev.y,next.x-prev.x);
    const off={x:p.x-Math.sin(a)*lane,y:p.y+Math.cos(a)*lane};
    if(landAt(g,off.x,off.y,r))route.push(off);else if(landAt(g,p.x,p.y,r))route.push(p);
  }
  if(route.length>1&&dist(from,route[1])+38<dist(route[0],route[1]))route.shift();
  if(!route.length||dist(route.at(-1),target)>26)route.push(target);
  return route;
}