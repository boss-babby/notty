import { CELL } from './data.js';
import { mod, TAU } from './core.js';

const box=(c,x,y,w,h,col)=>{c.fillStyle=col;c.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
const glow=(c,x,y,r,col,alpha=.4)=>{
  c.globalAlpha=alpha;const gr=c.createRadialGradient(x,y,0,x,y,r);
  gr.addColorStop(0,col);gr.addColorStop(1,'transparent');c.fillStyle=gr;c.fillRect(x-r,y-r,r*2,r*2);c.globalAlpha=1;
};

// Small animated layer painted over cached frontier tiles: signs, lamps, water and crossings.
export function drawAtlasDetail(c,g,b){
  const t=g.clock,{x,y,type}=b, urban=!['dunes','canyon','salt','oasis','islands','juniper','sea'].includes(type);
  for(const q of b.crossings||[]){
    for(let i=-1;i<=1;i++){
      if(q.a==='h')box(c,x+q.x-7,y+q.y+i*6-1,14,2,'#e2c58b87');
      else box(c,x+q.x+i*6-1,y+q.y-7,2,14,'#e2c58b87');
    }
  }
  for(const s of b.signs||[]){
    const sx=x+s.x,sy=y+s.y,pulse=.56+.44*Math.sin(t*2.1+s.phase);
    box(c,sx-2,sy-2,s.w+4,s.h+4,'#1c1728cc');
    box(c,sx,sy,s.w,s.h,s.bg||'#3d2b43');
    box(c,sx+1,sy+1,s.w-2,1,s.color);
    c.font=`700 ${s.size||8}px monospace`;c.textAlign='center';c.fillStyle=s.color;c.globalAlpha=.63+.37*pulse;
    c.fillText(s.text,sx+s.w/2,sy+s.h*.72);c.globalAlpha=1;
    if(s.neon)glow(c,sx+s.w/2,sy+s.h/2,s.w*.9,s.color,.1+.13*pulse);
  }
  for(const d of b.decor||[]){
    const px=x+d.x,py=y+d.y;
    if(d.kind==='marquee'){
      const blink=Math.sin(t*4+d.v)>.3;
      box(c,px+2,py+2,16,5,blink?'#ffd8a9':'#80566d');
      if(blink)glow(c,px+10,py+4,19,'#ff9dbd',.21);
    }else if(d.kind==='fountain'){
      for(let i=0;i<7;i++){
        const a=i/7*TAU+t*.55, rr=8+Math.sin(t*2+i)*2.3;
        box(c,px+18+Math.cos(a)*rr,py+9+Math.sin(a)*rr*.37,1.4,1.4,'#c6f5e6b0');
      }
    }else if(d.kind==='awning'){
      const sway=Math.sin(t*2.6+d.v)*1.6;
      box(c,px+2,py+10+sway,25,2,'#f0c79a55');
    }else if(d.kind==='palm'){
      const s=Math.sin(t*1.5+d.v)*2;
      c.strokeStyle='#7ba08a7c';c.lineWidth=1;c.beginPath();c.moveTo(px+4,py-1);c.lineTo(px+10+s,py-13);c.moveTo(px+4,py-1);c.lineTo(px-2+s,py-10);c.stroke();
    }else if(d.kind==='beacon'){
      const on=Math.sin(t*5)>.15;
      box(c,px-2,py-21,5,4,on?'#d8f2a5':'#5d695c');if(on)glow(c,px,py-19,29,'#d8f2a5',.25);
    }else if(d.kind==='plane'){
      box(c,px+2,py-34,2,2,Math.sin(t*6)>.4?'#ffe2aa':'#744d5f');
    }
  }
  if(b.type==='marina'||b.type==='sea'||b.type==='islands'){
    for(let i=0;i<8;i++){
      const xx=x+mod(i*61+t*13,CELL),yy=y+mod(i*83+t*6,CELL);
      if(b.type==='marina'&&yy>y+250)continue;
      box(c,xx,yy,5+i%4*7,1,i%2?'#a9e7d855':'#f3d6a342');
    }
  }
  if(urban&&b.roads.reduce((a,n)=>a+n,0)>80){
    for(const [dx,dy] of [[b.roads[3],24],[CELL-b.roads[1],24],[24,b.roads[0]],[24,CELL-b.roads[2]]]){
      const xx=x+dx,yy=y+dy,green=Math.sin(g.clock/7+b.cx)>.5;
      box(c,xx-3,yy-6,6,7,'#292338');box(c,xx-2,yy-5,4,5,green?'#89dca8':'#d8738f');
    }
  }
}
