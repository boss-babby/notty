# Static Harbor: Open Atlas

## Design

Open Atlas adds two fictional cities to the same streamed world as Vesper Bay and Monsoon City. Mirage Coast takes inspiration from Dubai's skyline, waterfront promenades, courtyards, and long airport approaches. Neon Basin takes inspiration from Las Vegas's resort strip, service roads, even-night lighting, and desert surroundings. Neither city reproduces a real logo, facility, or street network.

- **Mirage Coast:** Turquoise water, sand-colored courtyards, hillside market lanes, terraced towers, and a crescent marina. Windglass International and the marina ticket desk provide regional travel. The Tide Room serves as the district's listening lounge.
- **Neon Basin:** High-contrast marquee lighting, landscaped resort setbacks, service alleys, dry washes, and aviation yards. Jacklight runs a free game-score challenge, Halation runs regional radio, and fictional Fort Ember has a public field office and a relief task.
- **Frontier:** Signed chunk coordinates grow in all directions beyond the old map. Continuous noise determines terrain, sparse interlinked highways keep destinations reachable, and generated survey stations bring something to do between the cities. A world key determines layout and scenery; a style changes regional terrain balance. The original campaigns keep their exact coordinates and use the same expanded world.
- **Detail pass:** Authored cities use denser local infill and district-specific objects: market awnings and spice crates in the souk, glass canopies and rooftop crowns in the tower district, café tables and ferry signs on the marina, motels and illuminated marquees on the strip, service fencing and aircraft at airfields. Animated signage, fountains, palms, waterlines, crossings and traffic lights are drawn over cached tiles. Minor roads do not cross water; trunk routes that do are drawn as bridged causeways.

Nightlife depicts adults working or socializing. It includes optional, non-explicit dialogue with adult entertainers and independent escorts, not a solicitation, purchase, or sex mechanic. Factions, military characters, and infrastructure are invented for the game.

```text
World key + style -> continuous terrain + shared road edges
          -> district-specific lots + landmarks + survey stations
          -> streamed collision / pixel tiles / local atlas
          -> exploration log, fares, faction contracts, and venue interactions
```