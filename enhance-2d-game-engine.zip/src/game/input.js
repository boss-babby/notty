// ===== input.js — keyboard, mouse, gamepad, touch; rebindable actions =====
export const ACTIONS = [
  ['up', 'Move Up'], ['down', 'Move Down'], ['left', 'Move Left'], ['right', 'Move Right'], ['sprint', 'Sprint'], ['roll', 'Dodge Roll'],
  ['jump', 'Vault / Handbrake'], ['interact', 'Interact / Enter Vehicle'], ['reload', 'Reload'], ['cover', 'Take Cover'], ['wheel', 'Weapon Wheel'],
  ['fire', 'Fire'], ['aim', 'Aim / Scope'], ['radio', 'Next Radio Station'], ['horn', 'Horn'], ['siren', 'Siren'], ['phone', 'Phone'],
  ['map', 'Map'], ['focus', 'Tidal Focus'], ['pause', 'Pause'],
];
const DEFAULTS = {
  up: ['KeyW', 'ArrowUp'], down: ['KeyS', 'ArrowDown'], left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'],
  sprint: ['ShiftLeft', 'ShiftRight'], roll: ['KeyV', 'ControlLeft'], jump: ['Space'], interact: ['KeyE'], reload: ['KeyR'], cover: ['KeyC'],
  wheel: ['KeyQ'], fire: ['Mouse0'], aim: ['Mouse2'], radio: ['KeyX'], horn: ['KeyH'], siren: ['KeyG'], phone: ['Tab'], map: ['KeyM'], focus: ['KeyF'], pause: ['Escape', 'KeyP'],
};
const BLOCK = new Set(['Tab', 'Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'F1', 'F2', 'F3', 'F4', 'Backquote', 'ControlLeft']);

export class Input {
  constructor(el) {
    this.el = el; this.keys = new Set(); this.pr = new Set(); this.rel = new Set();
    this.mx = 0; this.my = 0; this.wheel = 0; this.virt = {}; this.virtPr = {};
    this.pad = { on: false, mx: 0, my: 0, ax: 0, ay: 0, down: {}, pr: {}, prev: {}, aimActive: false, lock: false };
    this.touch = false; this.rebinding = null; this.onRebind = null; this.enabled = true; this.unsub = [];
    this.bind = JSON.parse(JSON.stringify(DEFAULTS));
    try { const s = JSON.parse(localStorage.getItem('nt_bind') || 'null'); if (s) Object.assign(this.bind, s); } catch (e) { /* ignore */ }
    const on = (t, ev, fn, o) => { t.addEventListener(ev, fn, o); this.unsub.push(() => t.removeEventListener(ev, fn, o)); };
    on(window, 'keydown', (e) => {
      if (this.rebinding) { e.preventDefault(); this.setBind(this.rebinding, e.code); return; }
      if (e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
      if (BLOCK.has(e.code) && this.enabled) e.preventDefault();
      if (!e.repeat) this.pr.add(e.code);
      this.keys.add(e.code);
    });
    on(window, 'keyup', (e) => { this.keys.delete(e.code); this.rel.add(e.code); });
    on(window, 'blur', () => { this.keys.clear(); });
    on(el, 'mousemove', (e) => { this.mx = e.clientX; this.my = e.clientY; this.moveT = performance.now(); });
    on(el, 'mousedown', (e) => {
      this.mx = e.clientX; this.my = e.clientY;
      if (this.rebinding) { e.preventDefault(); this.setBind(this.rebinding, 'Mouse' + e.button); return; }
      this.keys.add('Mouse' + e.button); this.pr.add('Mouse' + e.button);
    });
    on(window, 'mouseup', (e) => { this.keys.delete('Mouse' + e.button); this.rel.add('Mouse' + e.button); });
    on(el, 'contextmenu', (e) => e.preventDefault());
    on(el, 'wheel', (e) => { this.wheel += Math.sign(e.deltaY); }, { passive: true });
    on(window, 'touchstart', () => { if (!this.touch) { this.touch = true; this.buildTouch(); if (this.onTouchMode) this.onTouchMode(); } }, { passive: true });
  }
  destroy() { this.unsub.forEach((f) => f()); if (this.touchEl) this.touchEl.remove(); }
  setBind(a, code) {
    this.bind[a] = [code]; this.rebinding = null;
    try { localStorage.setItem('nt_bind', JSON.stringify(this.bind)); } catch (e) { /* ignore */ }
    if (this.onRebind) this.onRebind();
  }
  resetBinds() { this.bind = JSON.parse(JSON.stringify(DEFAULTS)); try { localStorage.removeItem('nt_bind'); } catch (e) { /* ignore */ } }
  down(a) { const b = this.bind[a]; if (b) for (let i = 0; i < b.length; i++) if (this.keys.has(b[i])) return true; return !!this.virt[a] || !!this.pad.down[a] || (a === 'fire' && !!this.virt.fireBtn); }
  pressed(a) { const b = this.bind[a]; if (b) for (let i = 0; i < b.length; i++) if (this.pr.has(b[i])) return true; return !!this.virtPr[a] || !!this.pad.pr[a] || (a === 'fire' && !!this.virtPr.fireBtn); }
  released(a) { const b = this.bind[a]; if (b) for (let i = 0; i < b.length; i++) if (this.rel.has(b[i])) return true; return false; }
  /** movement vector, normalised if > 1 */
  move() {
    let x = (this.down('right') ? 1 : 0) - (this.down('left') ? 1 : 0), y = (this.down('down') ? 1 : 0) - (this.down('up') ? 1 : 0);
    x += this.pad.mx + (this.virt.mx || 0); y += this.pad.my + (this.virt.my || 0);
    const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; }
    return { x, y };
  }
  endStep() { this.pr.clear(); this.rel.clear(); this.wheel = 0; this.virtPr = {}; this.pad.pr = {}; }
  /** gamepad polling — call once per frame */
  poll() {
    let gp = null;
    try { const l = navigator.getGamepads ? navigator.getGamepads() : []; for (const p of l) if (p && p.connected) { gp = p; break; } } catch (e) { /* ignore */ }
    const P = this.pad;
    if (!gp) { P.on = false; P.mx = P.my = 0; P.down = {}; if (!this.touch) P.aimActive = false; return; }
    P.on = true;
    const dz = (v) => (Math.abs(v) < 0.18 ? 0 : v);
    P.mx = dz(gp.axes[0] || 0); P.my = dz(gp.axes[1] || 0); P.ax = dz(gp.axes[2] || 0); P.ay = dz(gp.axes[3] || 0);
    P.aimActive = Math.hypot(P.ax, P.ay) > 0.3;
    const b = (i) => !!(gp.buttons[i] && gp.buttons[i].pressed);
    const map = { interact: 0, roll: 1, reload: 2, focus: 3, fire: 7, aim: 6, sprint: 10, map: 8, pause: 9, cover: 11, phone: 12, radio: 13, horn: 14, wheel: 15 };
    const cur = {};
    for (const k in map) cur[k] = b(map[k]);
    cur.prevW = b(4); cur.nextW = b(5);
    for (const k in cur) { if (cur[k] && !P.prev[k]) P.pr[k] = true; }
    P.down = cur; P.prev = cur;
    P.lock = b(6);
  }
  buildTouch() {
    if (this.touchEl) return;
    const d = document.createElement('div'); d.id = 'touch'; this.touchEl = d;
    // ctx: foot = only on foot, car = only in a vehicle, '' = always
    const BTN = [['interact', 'E', 'tb-e', ''], ['fireBtn', 'FIRE', 'tb-fire', 'foot'], ['jump', '⤒', 'tb-jump', 'foot'], ['roll', '↻', 'tb-roll', 'foot'], ['reload', 'R', 'tb-rel', 'foot'], ['nextW', '⇄', 'tb-wpn', 'foot'],
      ['sprint', '»', 'tb-spr', 'foot'], ['focus', 'F', 'tb-foc', ''], ['jump', 'BRAKE', 'tb-hb', 'car'], ['horn', '📣', 'tb-horn', 'car'], ['radio', '♪', 'tb-rad', 'car'], ['siren', '🚨', 'tb-sir', 'car'], ['cover', '▣', 'tb-cov', 'foot']];
    d.innerHTML = '<div class="tzone" id="tjL"><div class="tbase"><i></i></div></div><div class="tstick" id="tjR"><i></i><span>AIM</span></div>' +
      BTN.map(([a, t, c, ctx]) => `<button class="tb ${c} ${ctx}" data-a="${a}" aria-label="${a}"><span>${t}</span></button>`).join('');
    document.body.appendChild(d);
    const buzz = (ms) => { try { if (this.haptics !== false && navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* ignore */ } };
    // ---- buttons (pointer events: robust multi-touch) ----
    d.querySelectorAll('.tb').forEach((b) => {
      const a = b.dataset.a; let pid = null;
      b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); pid = e.pointerId; try { b.setPointerCapture(pid); } catch (er) { /* ignore */ } b.classList.add('on'); buzz(8);
        if (a === 'nextW') { this.pad.pr.nextW = true; return; } this.virt[a] = true; this.virtPr[a] = true; });
      const up = (e) => { if (e.pointerId !== pid) return; pid = null; b.classList.remove('on'); if (a !== 'nextW') this.virt[a] = false; };
      b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('lostpointercapture', up);
      b.addEventListener('contextmenu', (e) => e.preventDefault());
    });
    // ---- floating move stick: touch anywhere in the left zone ----
    const zone = d.querySelector('#tjL'), base = zone.firstChild, knob = base.firstChild; let mp = null, ox = 0, oy = 0;
    const R = () => 54 * (parseFloat(getComputedStyle(document.body).getPropertyValue('--ts')) || 1);
    zone.addEventListener('pointerdown', (e) => { if (mp !== null) return; e.preventDefault(); mp = e.pointerId; try { zone.setPointerCapture(mp); } catch (er) { /* ignore */ }
      const r = zone.getBoundingClientRect(); ox = e.clientX; oy = e.clientY; base.style.left = ox - r.left + 'px'; base.style.top = oy - r.top + 'px'; base.classList.add('on'); knob.style.transform = ''; });
    zone.addEventListener('pointermove', (e) => { if (e.pointerId !== mp) return; e.preventDefault(); const rad = R(); let dx = (e.clientX - ox) / rad, dy = (e.clientY - oy) / rad; const l = Math.hypot(dx, dy);
      if (l > 1) { // the base follows the finger so the thumb never runs out of room
        ox += (e.clientX - ox) - (dx / l) * rad; oy += (e.clientY - oy) - (dy / l) * rad; dx /= l; dy /= l; const r = zone.getBoundingClientRect(); base.style.left = ox - r.left + 'px'; base.style.top = oy - r.top + 'px'; }
      knob.style.transform = `translate(${dx * rad * 0.7}px,${dy * rad * 0.7}px)`; const dz = Math.hypot(dx, dy) < 0.14; this.virt.mx = dz ? 0 : dx; this.virt.my = dz ? 0 : dy; });
    const mend = (e) => { if (e.pointerId !== mp) return; mp = null; base.classList.remove('on'); knob.style.transform = ''; this.virt.mx = 0; this.virt.my = 0; };
    zone.addEventListener('pointerup', mend); zone.addEventListener('pointercancel', mend); zone.addEventListener('lostpointercapture', mend);
    // ---- aim stick (fixed): aim, and fire when pushed to the rim ----
    const st = d.querySelector('#tjR'), sk = st.firstChild; let ap = null;
    const aimMove = (e) => { const r = st.getBoundingClientRect(), rad = r.width / 2; let dx = (e.clientX - (r.left + rad)) / rad, dy = (e.clientY - (r.top + rad)) / rad; const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; }
      sk.style.transform = `translate(${dx * rad * 0.55}px,${dy * rad * 0.55}px)`; this.pad.ax = dx; this.pad.ay = dy; this.pad.aimActive = Math.hypot(dx, dy) > 0.3; const f = Math.hypot(dx, dy) > 0.8; if (f && !this.virt.fire) this.virtPr.fire = true; this.virt.fire = f; };
    st.addEventListener('pointerdown', (e) => { if (ap !== null) return; e.preventDefault(); ap = e.pointerId; try { st.setPointerCapture(ap); } catch (er) { /* ignore */ } st.classList.add('on'); aimMove(e); });
    st.addEventListener('pointermove', (e) => { if (e.pointerId === ap) { e.preventDefault(); aimMove(e); } });
    const aend = (e) => { if (e.pointerId !== ap) return; ap = null; st.classList.remove('on'); sk.style.transform = ''; this.pad.ax = 0; this.pad.ay = 0; this.pad.aimActive = false; this.virt.fire = false; };
    st.addEventListener('pointerup', aend); st.addEventListener('pointercancel', aend); st.addEventListener('lostpointercapture', aend);
    d.addEventListener('touchstart', (e) => { if (e.target === d || e.target.closest('.tb,.tzone,.tstick')) e.preventDefault(); }, { passive: false });
    d.addEventListener('contextmenu', (e) => e.preventDefault());
  }
}
