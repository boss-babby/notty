# VLC Redesign (Rust + Slint on libvlc)

A re-skin of VLC that follows the community Figma redesign ("VLC Redesign (Community)"), written in Rust.

* **Engine = VLC.** All demuxing, decoding, audio output, subtitles, equalizer and network protocols are done by
  the real **libvlc 3.0.24** (`libvlc.dll`, `libvlccore.dll`, `plugins/`), loaded at runtime (`src/vlc.rs`).
  Media support and decode performance are therefore VLC's own.
* **UI = new.** A retained-mode UI written in [Slint](https://slint.dev) (`ui/app.slint`), rendered with
  OpenGL (femtovg) with an automatic software fallback. Native Rust, no web view, no Qt.
* **Video path.** libvlc decodes (hardware decode enabled via `--avcodec-hw=any`, copy-back) and scales on its
  own thread into an RGBA buffer using `libvlc_video_set_callbacks/format_callbacks`; the frame is handed to the UI
  by pointer swap (zero-copy on the VLC side) and uploaded as a texture at 60 Hz.

## Implemented
Library grid with breadcrumbs / sort / search / tile size, Home / Videos / Music / Network / Playlists / Recent / Add item,
player view with queue panel, custom control bar (seek, volume, audio tracks + equalizer, subtitles, settings,
fullscreen), the redesigned right-click menu (all sub-menus), settings dialog with 12 pages (theme, accent colours, ...),
resume playback, saved playlists, snapshots, recording (sout), keyboard shortcuts
(Space, S, P, N, R, M, F/F11, arrows, Ctrl+\ hide UI, Ctrl+Q), command-line / "Open with" file argument.

## Run (Windows x64)
Unzip the release bundle and start `vlc-redesign.exe` (keep `libvlc.dll`, `libvlccore.dll`, `plugins/` beside it).
If VLC 3.x is installed, the app also finds it in `C:\Program Files\VideoLAN\VLC`.

## Build (Linux/macOS/Windows host -> Windows x64)
```
./scripts/fetch-toolchain.sh        # rustup + llvm-mingw (no root needed)
./scripts/build-windows.sh          # -> dist/VLC-Redesign-win64/
```
UI snapshot tool (headless, renders the real UI to PNG): `cd tools/shot && cargo run --release -- out/`.

## Known limitations (honest list)
* Window uses the OS title bar (custom frameless title bar from the Figma is not done).
* Video is drawn through a software-copy path (like VLC's "vmem"); VLC's native Direct3D11 vout is not used, so
  extreme 8K/HDR content will use more CPU/GPU than stock VLC. `Performance > Max frame width` bounds the copy cost.
* HDR tone mapping, video filters, DVD/Bluray menus and the Lua extension UIs are not exposed in the new UI.
* Light theme / accent colours implemented; "System" theme follows Dark. Only English strings.
* The Windows build was cross-compiled on Linux; it could not be executed in the build sandbox. The UI was verified by
  headless rendering of the same `.slint` file (docs/*.png); libvlc interop follows the libvlc 3.0 headers.
