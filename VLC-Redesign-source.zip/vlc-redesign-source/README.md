# VLC Redesign (Rust + Slint on libvlc)

A re-skin of VLC that follows the community Figma redesign ("VLC Redesign (Community)"), written in Rust.

* **Engine = VLC.** All demuxing, decoding, audio output, subtitles, equalizer and network protocols are done by
  the real **libvlc 3.0.24** (`libvlc.dll`, `libvlccore.dll`, `plugins/`), loaded at runtime (`src/vlc.rs`).
  Media support and decode performance are therefore VLC's own.
* **UI = new.** A retained-mode UI written in [Slint](https://slint.dev) (`ui/app.slint`), rendered with
  OpenGL (femtovg) with an automatic software fallback. Native Rust, no web view, no Qt.
* **Video path.** libvlc decodes (hardware decode enabled via `--avcodec-hw=any`, copy-back) and scales on its
  own thread into an RGBA buffer using `libvlc_video_set_callbacks/format_callbacks`; the frame is handed to the UI
  by pointer swap (zero-copy on the VLC side) and uploaded as a texture at 60 Hz.

## Documentation
* `docs/PROGRESS.md` — what is done and what remains.
* `docs/PERFORMANCE.md` — video / audio path, root causes of the old stutter, verification and diagnostics.

## Implemented
See `docs/PROGRESS.md`. Highlights: frameless Figma title bar, tune panel (playback / video / audio / subtitles), 10-band
equalizer, animated transitions, zero-copy vsync-paced video path, tuned Windows audio path.

## Run (Windows x64)
Unzip the release bundle and start `vlc-redesign.exe` (keep `libvlc.dll`, `libvlccore.dll`, `plugins/` beside it).
If VLC 3.x is installed, the app also finds it in `C:\Program Files\VideoLAN\VLC`.

## Build (Linux/macOS/Windows host -> Windows x64)
```
./scripts/build-windows.sh          # -> dist/VLC-Redesign-win64/ and dist/VLC-Redesign-win64.zip
```
Toolchain: Debian/Ubuntu `mingw-w64` (posix thread model) + `rustup target add x86_64-pc-windows-gnu`, or
`./scripts/fetch-toolchain.sh` (rustup + llvm-mingw, no root).
Linux dev build (needs `libvlc5`, `vlc-plugin-base`): `cargo run --release -- file.mp4`.
UI snapshot tool (headless): `cd tools/shot && cargo run --release -- ../../docs`.
Debug: `VLC_REDESIGN_STATS=1`, `VLC_REDESIGN_ARGS="--aout=dummy"`.

## Known limitations
See the "Not done yet" table in `docs/PROGRESS.md` and the "What is different" list in `docs/PERFORMANCE.md`.
