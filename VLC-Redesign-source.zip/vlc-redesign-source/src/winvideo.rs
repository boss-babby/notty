//! Native video surface (Windows).
//!
//! VLC's own Direct3D11 video output renders into a *child window* of the Slint window. Decoding (D3D11VA),
//! colour conversion, scaling, subtitle blending and presentation all stay on the GPU inside libvlc - the UI
//! never touches a frame, so CPU use is the same as stock VLC.
//!
//! The Slint UI is drawn with OpenGL in the parent window. Everything that must appear *above* the video
//! (popup menus, toast, dialogs, the fullscreen control bar ...) is punched out of the child window's region
//! (`SetWindowRgn`), so the GL surface of the parent shows through exactly there. No overlay window, no
//! transparency tricks, no per-frame work.

#[derive(Clone, Copy, Default, PartialEq, Debug)]
pub struct Rect { pub x: i32, pub y: i32, pub w: i32, pub h: i32 }

#[derive(Clone, Copy, Default, Debug)]
pub struct MouseSnap { pub x: i32, pub y: i32, pub over_video: bool, pub left: bool, pub right: bool, pub middle: bool }

#[cfg(windows)]
mod imp {
    use super::{MouseSnap, Rect};
    use std::ffi::c_void;
    use std::ptr::{null, null_mut};
    use windows_sys::Win32::Foundation::{HWND, LPARAM, LRESULT, POINT, RECT, WPARAM};
    use windows_sys::Win32::Graphics::Gdi::{
        CombineRgn, CreateRectRgn, CreateRoundRectRgn, DeleteObject, FillRect, GetStockObject, ScreenToClient, SetWindowRgn, BLACK_BRUSH, HBRUSH, RGN_DIFF,
    };
    use windows_sys::Win32::System::LibraryLoader::GetModuleHandleW;
    use windows_sys::Win32::UI::Input::KeyboardAndMouse::{GetAsyncKeyState, VK_LBUTTON, VK_MBUTTON, VK_RBUTTON};
    use windows_sys::Win32::UI::WindowsAndMessaging::{
        CreateWindowExW, DefWindowProcW, DestroyWindow, GetAncestor, GetClientRect, GetCursorPos, IsChild, RegisterClassW, SetWindowPos,
        ShowWindow, WindowFromPoint, CS_DBLCLKS, GA_ROOT, HWND_TOP, SWP_NOACTIVATE, SWP_NOOWNERZORDER, SWP_SHOWWINDOW,
        SW_HIDE, WM_ERASEBKGND, WNDCLASSW, WS_CHILD, WS_CLIPCHILDREN, WS_CLIPSIBLINGS, WS_EX_NOPARENTNOTIFY,
    };

    fn wide(s: &str) -> Vec<u16> { s.encode_utf16().chain(std::iter::once(0)).collect() }

    unsafe extern "system" fn proc_(h: HWND, m: u32, w: WPARAM, l: LPARAM) -> LRESULT {
        if m == WM_ERASEBKGND {
            let mut r: RECT = std::mem::zeroed();
            GetClientRect(h, &mut r);
            FillRect(w as _, &r, GetStockObject(BLACK_BRUSH) as HBRUSH);
            return 1;
        }
        DefWindowProcW(h, m, w, l)
    }

    pub struct VideoHost {
        hwnd: HWND,
        parent: HWND,
        shown: bool,
        last_rect: Rect,
        last_key: u64,
    }

    impl VideoHost {
        pub fn create(parent: isize) -> Option<VideoHost> {
            unsafe {
                let parent = parent as HWND;
                let hinst = GetModuleHandleW(null());
                let class = wide("VlcRedesignVideoHost");
                let wc = WNDCLASSW {
                    style: CS_DBLCLKS,
                    lpfnWndProc: Some(proc_),
                    cbClsExtra: 0,
                    cbWndExtra: 0,
                    hInstance: hinst,
                    hIcon: null_mut(),
                    hCursor: null_mut(),
                    hbrBackground: GetStockObject(BLACK_BRUSH) as HBRUSH,
                    lpszMenuName: null(),
                    lpszClassName: class.as_ptr(),
                };
                RegisterClassW(&wc); // fails harmlessly when already registered
                let hwnd = CreateWindowExW(
                    WS_EX_NOPARENTNOTIFY, class.as_ptr(), null(), WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
                    0, 0, 16, 16, parent, null_mut(), hinst, null::<c_void>(),
                );
                if hwnd.is_null() { return None; }
                Some(VideoHost { hwnd, parent, shown: false, last_rect: Rect::default(), last_key: 0 })
            }
        }

        pub fn handle(&self) -> *mut c_void { self.hwnd }

        /// `rect` and `cuts` are in physical pixels, relative to the parent's client area.
        /// `round` > 0 rounds the corners of the video surface (radius in physical px).
        pub fn update(&mut self, visible: bool, rect: Rect, cuts: &[Rect], round: i32) {
            unsafe {
                if !visible || rect.w < 8 || rect.h < 8 {
                    if self.shown { ShowWindow(self.hwnd, SW_HIDE); self.shown = false; }
                    return;
                }
                // fully covered by one cut-out (e.g. the settings dialog) -> hide instead of an empty region
                for c in cuts {
                    if c.x <= rect.x && c.y <= rect.y && c.x + c.w >= rect.x + rect.w && c.y + c.h >= rect.y + rect.h {
                        if self.shown { ShowWindow(self.hwnd, SW_HIDE); self.shown = false; }
                        return;
                    }
                }
                let mut key: u64 = round as u64;
                for c in cuts {
                    for v in [c.x, c.y, c.w, c.h] { key = key.wrapping_mul(1_000_003).wrapping_add(v as u64 ^ 0x9e37); }
                }
                key = key.wrapping_mul(31).wrapping_add(rect.w as u64 * 7919 + rect.h as u64);
                let geom_changed = rect != self.last_rect || !self.shown;
                if geom_changed {
                    SetWindowPos(self.hwnd, HWND_TOP, rect.x, rect.y, rect.w, rect.h, SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_SHOWWINDOW);
                    self.last_rect = rect;
                    self.shown = true;
                }
                if geom_changed || key != self.last_key {
                    self.last_key = key;
                    let base = if round > 0 { CreateRoundRectRgn(0, 0, rect.w + 1, rect.h + 1, round * 2, round * 2) } else { CreateRectRgn(0, 0, rect.w, rect.h) };
                    for c in cuts {
                        if c.w <= 0 || c.h <= 0 { continue; }
                        let r = CreateRectRgn(c.x - rect.x, c.y - rect.y, c.x - rect.x + c.w, c.y - rect.y + c.h);
                        CombineRgn(base, base, r, RGN_DIFF);
                        DeleteObject(r as _);
                    }
                    // the system owns the region after this call
                    SetWindowRgn(self.hwnd, base, 1);
                }
            }
        }

        /// Polled mouse state (VLC's own child window swallows mouse messages, so clicks on the video are
        /// detected here instead).
        pub fn mouse(&self) -> MouseSnap {
            unsafe {
                let mut pt = POINT { x: 0, y: 0 };
                if GetCursorPos(&mut pt) == 0 { return MouseSnap::default(); }
                let under = WindowFromPoint(pt);
                let over = self.shown
                    && !under.is_null()
                    && (under == self.hwnd || IsChild(self.hwnd, under) != 0)
                    && GetAncestor(under, GA_ROOT) == GetAncestor(self.parent, GA_ROOT);
                let mut c = pt;
                ScreenToClient(self.parent, &mut c);
                let down = |vk: u16| (GetAsyncKeyState(vk as i32) as u16 & 0x8000) != 0;
                MouseSnap { x: c.x, y: c.y, over_video: over, left: down(VK_LBUTTON), right: down(VK_RBUTTON), middle: down(VK_MBUTTON) }
            }
        }
    }

    impl Drop for VideoHost {
        fn drop(&mut self) { unsafe { DestroyWindow(self.hwnd); } }
    }
}

#[cfg(not(windows))]
mod imp {
    use super::{MouseSnap, Rect};
    pub struct VideoHost;
    impl VideoHost {
        pub fn create(_parent: isize) -> Option<VideoHost> { None }
        pub fn handle(&self) -> *mut std::ffi::c_void { std::ptr::null_mut() }
        pub fn update(&mut self, _v: bool, _r: Rect, _c: &[Rect], _round: i32) {}
        pub fn mouse(&self) -> MouseSnap { MouseSnap::default() }
    }
}

pub use imp::VideoHost;
