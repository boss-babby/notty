#![cfg_attr(all(windows, not(debug_assertions)), windows_subsystem = "windows")]
//! VLC Redesign - Rust / Slint (retained-mode) front-end on top of libvlc.

mod dialogs;
mod platform;
mod store;
mod tune;
mod vlc;

slint::include_modules!();

use slint::winit_030::{winit, WinitWindowAccessor};
use slint::{ComponentHandle, Image, ModelRc, Timer, TimerMode, VecModel};
use std::sync::Arc;
use std::cell::RefCell;
use std::path::{Path, PathBuf};
use std::rc::Rc;
use std::sync::atomic::Ordering;
use std::time::{Duration, Instant};
use store::{home_dir, Store, DEFS};
use vlc::{Player, State, Vlc};

const VIDEO_EXT: &[&str] = &["mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "m4v", "mpg", "mpeg", "ts", "m2ts", "3gp", "ogv", "vob", "mts"];
const AUDIO_EXT: &[&str] = &["mp3", "flac", "wav", "ogg", "opus", "m4a", "aac", "wma", "aiff", "ape", "mka"];

struct Entry { title: String, path: String, kind: i32, meta: String }

struct App {
    store: Store,
    // NOTE: field order matters for drop: player must drop before the libvlc instance.
    player: Option<Player>,
    vlc: Option<Vlc>,
    err: String,
    queue: Vec<String>,
    cur: Option<usize>,
    nav: String,
    dir: Option<PathBuf>,
    listing: Vec<Entry>,
    crumb_paths: Vec<Option<PathBuf>>,
    query: String,
    sort_desc: bool,
    speed: f32,
    muted: bool,
    recording: Option<String>,
    last_activity: Instant,
    fullscreen: bool,
    settings_query: String,
    row_defs: Vec<&'static str>,
    toast_until: Option<Instant>,
    now_title: String,
    audio_only: bool,
    ended_handled: bool,
    grace_until: Instant,
    tune: tune::TuneState,
    exec_playing: bool,
}

// ------------------------------------------------------------------ helpers

fn ext_of(p: &Path) -> String { p.extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default() }
/// 0 = video, 1 = audio
fn media_kind(p: &Path) -> Option<i32> {
    let e = ext_of(p);
    if VIDEO_EXT.contains(&e.as_str()) { Some(0) } else if AUDIO_EXT.contains(&e.as_str()) { Some(1) } else { None }
}
fn file_title(p: &str) -> String {
    Path::new(p).file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| p.to_string())
}
fn hms(ms: i64) -> String {
    let s = (ms.max(0) / 1000) as u64;
    format!("{:02}:{:02}:{:02}", s / 3600, (s / 60) % 60, s % 60)
}
fn lead_num(s: &str) -> i64 { s.split_whitespace().next().and_then(|n| n.parse().ok()).unwrap_or(0) }
fn tint(seed: &str) -> slint::Color {
    const P: [(u8, u8, u8); 8] = [(96, 44, 28), (28, 66, 110), (66, 34, 104), (24, 92, 66), (112, 84, 26), (104, 30, 66), (30, 88, 100), (84, 54, 40)];
    let h = seed.bytes().fold(7usize, |a, b| a.wrapping_mul(31).wrapping_add(b as usize));
    let c = P[h % P.len()];
    slint::Color::from_rgb_u8(c.0, c.1, c.2)
}
fn size_text(n: u64) -> String {
    if n >= 1 << 30 { format!("{:.1} GB", n as f64 / (1u64 << 30) as f64) } else { format!("{:.0} MB", n as f64 / (1u64 << 20) as f64) }
}
fn model<T: Clone + 'static>(v: Vec<T>) -> ModelRc<T> { ModelRc::new(VecModel::from(v)) }
fn me(label: &str, shortcut: &str, icon: &str, id: &str, sub: bool, checked: bool) -> MenuEntry {
    MenuEntry { label: label.into(), shortcut: shortcut.into(), icon: icon.into(), id: id.into(), sub, checked }
}
fn root_for(nav: &str) -> PathBuf { home_dir().join(if nav == "music" { "Music" } else { "Videos" }) }

// ------------------------------------------------------------------ library

fn list_dir(dir: &Path, nav: &str, st: &Store) -> Vec<Entry> {
    let mut out = vec![];
    let Ok(rd) = std::fs::read_dir(dir) else { return out };
    for e in rd.flatten() {
        let name = e.file_name().to_string_lossy().into_owned();
        if !st.on("show_hidden") && name.starts_with('.') { continue; }
        let path = e.path();
        let Ok(md) = e.metadata() else { continue };
        if md.is_dir() {
            out.push(Entry { title: name, path: path.to_string_lossy().into_owned(), kind: 2, meta: String::new() });
        } else {
            let want = if nav == "music" { 1 } else { 0 };
            let k = media_kind(&path);
            if k == Some(want) || (st.on("show_all_files") && k.is_some()) {
                out.push(Entry { title: name, path: path.to_string_lossy().into_owned(), kind: k.unwrap_or(0), meta: size_text(md.len()) });
            }
        }
    }
    out
}

fn refresh_library(app: &mut App, ui: &MainWindow) {
    let mut entries: Vec<Entry> = vec![];
    let mut crumbs: Vec<(String, Option<PathBuf>)> = vec![];
    match app.nav.as_str() {
        "videos" | "music" => {
            let root = root_for(&app.nav);
            let label = if app.nav == "music" { "Music" } else { "Videos" };
            let dir = app.dir.clone().unwrap_or_else(|| root.clone());
            entries = list_dir(&dir, &app.nav, &app.store);
            if let Ok(rel) = dir.strip_prefix(&root) {
                crumbs.push((label.into(), Some(root.clone())));
                let mut acc = root.clone();
                for c in rel.components() {
                    acc.push(c);
                    crumbs.push((c.as_os_str().to_string_lossy().into_owned(), Some(acc.clone())));
                }
            } else {
                let anc: Vec<&Path> = dir.ancestors().collect();
                for a in anc.iter().take(3).rev() {
                    let n = a.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| a.to_string_lossy().into_owned());
                    crumbs.push((n, Some(a.to_path_buf())));
                }
            }
            app.dir = Some(dir);
        }
        "home" => {
            crumbs.push(("Home".into(), None));
            for (n, p) in [("Videos", root_for("videos")), ("Music", root_for("music"))] {
                entries.push(Entry { title: n.into(), path: p.to_string_lossy().into_owned(), kind: 2, meta: String::new() });
            }
            for f in &app.store.folders {
                entries.push(Entry { title: file_title(f), path: f.clone(), kind: 2, meta: String::new() });
            }
            for r in &app.store.recent {
                if let Some(k) = media_kind(Path::new(r)) { entries.push(Entry { title: file_title(r), path: r.clone(), kind: k, meta: String::new() }); }
            }
        }
        "recent" => {
            crumbs.push(("Recent".into(), None));
            for r in &app.store.recent {
                let k = media_kind(Path::new(r)).unwrap_or(0);
                entries.push(Entry { title: file_title(r), path: r.clone(), kind: k, meta: String::new() });
            }
        }
        "playlists" => {
            crumbs.push(("Playlists".into(), None));
            entries.push(Entry { title: "Create playlist".into(), path: String::new(), kind: 4, meta: String::new() });
            for (i, p) in app.store.playlists.iter().enumerate() {
                entries.push(Entry { title: p.name.clone(), path: i.to_string(), kind: 3, meta: format!("{} items", p.items.len()) });
            }
        }
        _ => crumbs.push(("Network".into(), None)),
    }
    let q = app.query.to_lowercase();
    if !q.is_empty() { entries.retain(|e| e.title.to_lowercase().contains(&q)); }
    if app.nav == "videos" || app.nav == "music" {
        entries.sort_by(|a, b| (b.kind == 2).cmp(&(a.kind == 2)).then(a.title.to_lowercase().cmp(&b.title.to_lowercase())));
        if app.sort_desc { entries.reverse(); }
    }
    let items: Vec<MediaItem> = entries.iter().map(|e| MediaItem {
        title: e.title.clone().into(),
        path: e.path.clone().into(),
        kind: e.kind,
        meta: e.meta.clone().into(),
        tint: tint(&e.title),
        resume: if e.kind <= 1 { app.store.resume.get(&e.path).map(|&ms| (ms as f32 / 3_600_000.0).clamp(0.05, 0.95)).unwrap_or(0.0) } else { 0.0 },
    }).collect();
    let n = items.iter().filter(|i| i.kind != 4).count();
    ui.set_count_text(format!("{} items", n).into());
    ui.set_items(model(items));
    ui.set_crumbs(model(crumbs.iter().map(|(l, _)| Crumb { label: l.clone().into() }).collect()));
    app.crumb_paths = crumbs.into_iter().map(|(_, p)| p).collect();
    app.listing = entries;
    ui.set_nav(app.nav.clone().into());
}

// ------------------------------------------------------------------ frame pump (libvlc -> UI)

static PUMPED: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

thread_local! {
    static CTX: RefCell<Option<(Rc<RefCell<App>>, slint::Weak<MainWindow>)>> = const { RefCell::new(None) };
}

/// Runs on the UI thread, woken by libvlc's display callback (once per consumed frame). The new frame is moved
/// into a Slint image; Slint then presents it on the next vsync.
fn pump_frame() {
    PUMPED.fetch_add(1, Ordering::Relaxed);
    CTX.with(|c| {
        let c = c.borrow();
        let Some((app, weak)) = c.as_ref() else { return };
        let Some(ui) = weak.upgrade() else { return };
        let Ok(a) = app.try_borrow() else { return };
        if let Some(p) = a.player.as_ref() {
            if let Some(buf) = p.take_frame() {
                ui.set_frame(Image::from_rgba8(buf));
                if !ui.get_has_frame() { ui.set_has_frame(true); }
            }
        }
    });
}

// ------------------------------------------------------------------ playback

fn toast(app: &mut App, ui: &MainWindow, msg: &str) {
    ui.set_toast(msg.into());
    app.toast_until = Some(Instant::now() + Duration::from_millis(2800));
}

fn set_queue_models(app: &App, ui: &MainWindow) {
    let q: Vec<MediaItem> = app.queue.iter().map(|p| MediaItem {
        title: file_title(p).into(), path: p.clone().into(), kind: 0, meta: "".into(), tint: slint::Color::from_rgb_u8(0, 0, 0), resume: 0.0,
    }).collect();
    ui.set_queue(model(q));
    ui.set_current_index(app.cur.map(|c| c as i32).unwrap_or(-1));
}

fn save_resume(app: &mut App) {
    if !app.store.on("resume") { return; }
    let (Some(p), Some(c)) = (app.player.as_ref(), app.cur) else { return };
    let Some(path) = app.queue.get(c).cloned() else { return };
    let (t, len) = (p.time_ms(), p.length_ms());
    if t > 5000 && len > 0 && t < len - 10_000 { app.store.resume.insert(path, t as u32); } else { app.store.resume.remove(&path); }
}

fn start_with(app: &mut App, ui: &MainWindow, idx: usize, extra: Vec<String>) {
    let Some(path) = app.queue.get(idx).cloned() else { return };
    if app.player.is_none() {
        app.err = if app.err.is_empty() { "libvlc is not available".into() } else { app.err.clone() };
        ui.set_error_text(app.err.clone().into());
        ui.set_has_media(true);
        ui.set_player_page(true);
        app.cur = Some(idx);
        app.now_title = file_title(&path);
        ui.set_now_title(app.now_title.clone().into());
        set_queue_models(app, ui);
        return;
    }
    if app.cur.is_some() && extra.is_empty() { save_resume(app); }
    app.cur = Some(idx);
    let mut opts = extra;
    if opts.is_empty() && app.store.on("resume") {
        if let Some(ms) = app.store.resume.get(&path) { opts.push(format!(":start-time={}", ms / 1000)); }
    }
    opts.extend(tune::media_options(app));
    let vol = (app.store.volume * 100.0) as i32;
    let (speed, muted) = (app.speed, app.muted);
    let ok = {
        let p = app.player.as_mut().unwrap();
        let ok = p.play(&path, &opts);
        p.set_rate(speed);
        p.set_volume(vol);
        p.set_mute(muted);
        ok
    };
    tune::apply_all(app);
    app.ended_handled = false;
    app.grace_until = Instant::now() + Duration::from_millis(1200);
    app.now_title = file_title(&path);
    app.audio_only = !path.contains("://") && media_kind(Path::new(&path)) == Some(1);
    if app.store.on("save_recent") && !path.contains("://") { app.store.push_recent(&path); }
    app.err = if ok { String::new() } else { "VLC could not open this item.".into() };
    ui.set_error_text(app.err.clone().into());
    ui.set_has_frame(false);
    ui.set_has_media(true);
    ui.set_audio_only(app.audio_only);
    ui.set_now_title(app.now_title.clone().into());
    ui.set_player_page(true);
    set_queue_models(app, ui);
    tune::refresh_tab(app, ui);
}
fn start(app: &mut App, ui: &MainWindow, idx: usize) { start_with(app, ui, idx, vec![]); }

fn open_paths(app: &mut App, ui: &MainWindow, paths: Vec<String>) {
    if paths.is_empty() { return; }
    app.queue = paths;
    start(app, ui, 0);
}

fn step_next(app: &mut App, ui: &MainWindow, dir: i32) {
    let n = app.queue.len() as i32;
    let Some(c) = app.cur else { return };
    if n == 0 { return; }
    let t = c as i32 + dir;
    if t >= 0 && t < n { start(app, ui, t as usize); }
    else if app.store.get("repeat") == "All" { start(app, ui, (t.rem_euclid(n)) as usize); }
}

fn do_stop(app: &mut App, ui: &MainWindow) {
    save_resume(app);
    if let Some(p) = app.player.as_ref() { p.stop(); }
    ui.set_playing(false);
    ui.set_position(0.0);
    ui.set_cur_time("00:00:00".into());
    ui.set_has_frame(false);
    app.ended_handled = true;
}

fn tick(app: &mut App, ui: &MainWindow, n: u32) {
    // safety net: frames are normally pushed by libvlc through `pump_frame`; this only catches a missed wake-up
    if let Some(p) = app.player.as_ref() {
        if let Some(buf) = p.take_frame() { ui.set_frame(Image::from_rgba8(buf)); ui.set_has_frame(true); }
    }
    if n % 4 != 0 { return; }
    if n % 40 == 0 && std::env::var_os("VLC_REDESIGN_STATS").is_some() {
        if let Some(p) = app.player.as_ref() {
            eprintln!("[stats] state={:?} t={}ms len={}ms decoded={} presented={}", p.state(), p.time_ms(), p.length_ms(), p.frames_decoded(), PUMPED.load(Ordering::Relaxed));
        }
    }
    let mx = ui.window().is_maximized();
    if mx != ui.get_win_max() { ui.set_win_max(mx); }
    let now = Instant::now();
    if let Some(t) = app.toast_until { if now > t { ui.set_toast("".into()); app.toast_until = None; } }
    if app.fullscreen { ui.set_controls_visible(now.duration_since(app.last_activity) < Duration::from_secs(3)); }
    let Some(p) = app.player.as_ref() else { return };
    let st = p.state();
    ui.set_playing(st == State::Playing || st == State::Opening || st == State::Buffering);
    let busy = st == State::Playing;
    if busy != app.exec_playing { app.exec_playing = busy; platform::set_playing(busy && !app.audio_only); }
    if st == State::Playing || st == State::Paused {
        let (t, len) = (p.time_ms(), p.length_ms());
        ui.set_cur_time(hms(t).into());
        ui.set_total_time(hms(len).into());
        let pos = p.position();
        if pos >= 0.0 { ui.set_position(pos); }
    }
    if st == State::Error && app.err.is_empty() {
        app.err = "VLC could not play this item.".into();
        ui.set_error_text(app.err.clone().into());
    }
    if st == State::Ended && !app.ended_handled && now > app.grace_until {
        app.ended_handled = true;
        let rep = app.store.get("repeat");
        let Some(c) = app.cur else { return };
        app.store.resume.remove(&app.queue[c]);
        if rep == "One" { start(app, ui, c); }
        else if app.store.on("autoplay_next") && (c + 1 < app.queue.len() || rep == "All") { step_next(app, ui, 1); }
        else { do_stop(app, ui); }
    }
}

fn toggle_fullscreen(app: &mut App, ui: &MainWindow) {
    app.fullscreen = !app.fullscreen;
    ui.window().set_fullscreen(app.fullscreen);
    ui.set_fullscreen_mode(app.fullscreen);
    ui.set_controls_visible(true);
    app.last_activity = Instant::now();
}

fn toggle_record(app: &mut App, ui: &MainWindow) {
    let (Some(c), Some(_)) = (app.cur, app.player.as_ref()) else { return toast(app, ui, "Nothing to record") };
    let path = app.queue[c].clone();
    let t = app.player.as_ref().unwrap().time_ms().max(0) / 1000;
    if let Some(out) = app.recording.take() {
        start_with(app, ui, c, vec![format!(":start-time={}", t)]);
        ui.set_recording(false);
        toast(app, ui, &format!("Recording saved: {}", out));
    } else {
        let dir = home_dir().join("Videos").join("VLC Recordings");
        let _ = std::fs::create_dir_all(&dir);
        let stamp = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0);
        let stem = Path::new(&path).file_stem().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| "stream".into());
        let out = dir.join(format!("{}-{}.ts", stem, stamp)).to_string_lossy().replace('\\', "/");
        let sout = format!(":sout=#duplicate{{dst=display,dst=std{{access=file,mux=ts,dst=\"{}\"}}}}", out);
        start_with(app, ui, c, vec![sout, ":sout-keep".into(), format!(":start-time={}", t)]);
        ui.set_recording(true);
        app.recording = Some(out);
        toast(app, ui, "Recording started (press R again to stop)");
    }
}

fn apply_setting(app: &mut App, ui: &MainWindow, key: &str) {
    match key {
        "fit" => ui.set_fit_mode(match app.store.get("fit").as_str() { "Fill" => 1, "Stretch" => 2, _ => 0 }),
        "tile_size" => ui.set_compact(app.store.get("tile_size") == "Compact"),
        "nav_expanded" => ui.set_nav_expanded(app.store.on("nav_expanded")),
        "frame_w" => vlc::MAX_FRAME_W.store(lead_num(&app.store.get("frame_w")) as u32, Ordering::Relaxed),
        "show_hidden" | "show_all_files" => refresh_library(app, ui),
        _ => {}
    }
}

fn cycle_setting(app: &mut App, ui: &MainWindow, key: &str) {
    let Some(d) = store::def(key) else { return };
    if d.kind == 0 {
        let nv = if app.store.on(key) { "off" } else { "on" };
        app.store.settings.insert(key.into(), nv.into());
    } else if d.kind == 1 {
        let cur = app.store.get(key);
        let i = d.options.iter().position(|o| *o == cur).unwrap_or(0);
        app.store.settings.insert(key.into(), d.options[(i + 1) % d.options.len()].into());
    }
    app.store.save();
    apply_setting(app, ui, key);
    if d.label.contains("needs restart") { toast(app, ui, "Applies the next time VLC Redesign starts"); }
}

fn build_rows(app: &mut App, ui: &MainWindow) {
    let page = ui.get_settings_page().to_string();
    let q = app.settings_query.to_lowercase();
    app.row_defs.clear();
    let mut rows = vec![];
    for d in DEFS.iter() {
        let show = if q.is_empty() { d.page == page } else { d.kind != 2 && d.label.to_lowercase().contains(&q) };
        if !show { continue; }
        app.row_defs.push(d.key);
        rows.push(Row { label: d.label.into(), kind: d.kind, on: d.kind == 0 && app.store.on(d.key), value: if d.kind == 1 { app.store.get(d.key).into() } else { "".into() } });
    }
    ui.set_rows(model(rows));
}

// ------------------------------------------------------------------ menus

fn build_menu(app: &mut App, ui: &MainWindow, kind: &str) -> Vec<MenuEntry> {
    let back = me("Back", "", "back", "menu:main", true, false);
    match kind {
        "playback" => {
            let mut v = vec![back, me("Speed", "", "", "", false, false)];
            for (l, s) in [("0.5x", 0.5f32), ("0.75x", 0.75), ("Normal", 1.0), ("1.25x", 1.25), ("1.5x", 1.5), ("2x", 2.0)] {
                v.push(me(l, "", "", &format!("speed:{}", s), false, (app.speed - s).abs() < 0.01));
            }
            v.push(me("Jump forward", "Right", "next", "seek:1", false, false));
            v.push(me("Jump backward", "Left", "prev", "seek:-1", false, false));
            v.push(me(&format!("Repeat: {}", app.store.get("repeat")), "", "playback", "cycle:repeat", false, false));
            v
        }
        "video" => {
            let f = ui.get_fit_mode();
            vec![back,
                me("Fit to window", "", "", "fit:0", false, f == 0), me("Fill window", "", "", "fit:1", false, f == 1), me("Stretch", "", "", "fit:2", false, f == 2),
                me("Fullscreen", "F", "fullscreen", "fullscreen", false, false), me("Take snapshot", "", "camera", "snapshot", false, false)]
        }
        "audio" => {
            let mut v = vec![back, me("Mute", "M", "volume-mute", "mute", false, app.muted)];
            if let Some(p) = app.player.as_ref() {
                let (tr, cur) = p.audio_tracks();
                v.push(me("Audio track", "", "", "", false, false));
                for (id, name) in tr.into_iter().take(6) { v.push(me(&name, "", "", &format!("atrack:{}", id), false, id == cur)); }
            }
            v.push(me(if app.tune.eq_on { "Equalizer: On" } else { "Equalizer: Off" }, "", "wave", "eqtoggle", false, false));
            v
        }
        "subtitle" => {
            let mut v = vec![back, me("Add subtitle file...", "", "subtitle", "subs:add", false, false)];
            if let Some(p) = app.player.as_ref() {
                let (tr, cur) = p.sub_tracks();
                v.push(me("Subtitle track", "", "", "", false, false));
                for (id, name) in tr.into_iter().take(7) { v.push(me(&name, "", "", &format!("strack:{}", id), false, id == cur)); }
            }
            v
        }
        "playlist" => {
            let mut v = vec![back, me("Save queue as playlist", "", "add", "pl:create", false, false), me("Clear queue", "", "close", "pl:clear", false, false)];
            for (i, p) in app.store.playlists.iter().enumerate().take(7) { v.push(me(&p.name, "", "playlist", &format!("pl:load:{}", i), false, false)); }
            v
        }
        "open" => vec![back,
            me("Open file(s)...", "", "videos", "open:files", false, false),
            me("Open folder...", "", "folder", "open:folder", false, false),
            me("Open network stream...", "", "network", "open:net", false, false)],
        _ => {
            let playing = ui.get_playing();
            vec![
                me(if playing { "Pause" } else { "Play" }, "Space", if playing { "pause" } else { "play" }, "play", false, false),
                me("Stop", "S", "stop", "stop", false, false),
                me("Previous Item", "P", "prev", "prev", false, false),
                me("Next Item", "N", "next", "next", false, false),
                me(if app.recording.is_some() { "Stop recording" } else { "Record" }, "R", "record", "record", false, false),
                me("Hide UI", "Ctrl + \\", "hideui", "hideui", false, false),
                me("Playback", "", "playback", "menu:playback", true, false),
                me("Video", "", "clap", "menu:video", true, false),
                me("Audio", "", "wave", "menu:audio", true, false),
                me("Subtitle", "", "subtitle", "menu:subtitle", true, false),
                me("Tune playback", "T", "sliders", "tune", false, false),
                me("More Settings", "", "settings", "settings", true, false),
                me("Playlist", "", "playlist", "menu:playlist", true, false),
                me("Open Media", "", "openmedia", "menu:open", true, false),
                me("Quit VLC", "Ctrl + Q", "quit", "quit", false, false),
            ]
        }
    }
}

fn pick_media_files() -> Vec<String> {
    let mut exts: Vec<&str> = VIDEO_EXT.to_vec();
    exts.extend_from_slice(AUDIO_EXT);
    dialogs::pick_files("Open media", "Media files", &exts)
}

fn on_menu(app: &mut App, ui: &MainWindow, id: &str) {
    if let Some(k) = id.strip_prefix("menu:") {
        let m = build_menu(app, ui, k);
        ui.set_menu_items(model(m));
        return;
    }
    if let Some(v) = id.strip_prefix("speed:") {
        app.speed = v.parse().unwrap_or(1.0);
        if let Some(p) = app.player.as_ref() { p.set_rate(app.speed); }
        return toast(app, ui, &format!("Speed {}x", app.speed));
    }
    if let Some(v) = id.strip_prefix("fit:") {
        let n: i32 = v.parse().unwrap_or(0);
        ui.set_fit_mode(n);
        app.store.settings.insert("fit".into(), ["Fit", "Fill", "Stretch"][n as usize % 3].into());
        app.store.save();
        return;
    }
    if let Some(v) = id.strip_prefix("atrack:") { if let Some(p) = app.player.as_ref() { p.set_audio_track(v.parse().unwrap_or(0)); } return; }
    if let Some(v) = id.strip_prefix("strack:") { if let Some(p) = app.player.as_ref() { p.set_sub_track(v.parse().unwrap_or(-1)); } return; }
    if let Some(v) = id.strip_prefix("cycle:") { return cycle_setting(app, ui, v); }
    if let Some(v) = id.strip_prefix("seek:") { return seek_step(app, v.parse().unwrap_or(1)); }
    if let Some(v) = id.strip_prefix("pl:load:") {
        if let Some(pl) = v.parse::<usize>().ok().and_then(|i| app.store.playlists.get(i)).cloned() { open_paths(app, ui, pl.items); }
        return;
    }
    match id {
        "play" => { if let Some(p) = app.player.as_ref() { p.toggle_pause() } }
        "stop" => do_stop(app, ui),
        "prev" => step_next(app, ui, -1),
        "next" => step_next(app, ui, 1),
        "record" => toggle_record(app, ui),
        "hideui" => ui.set_ui_hidden(!ui.get_ui_hidden()),
        "settings" => { ui.set_settings_open(true); build_rows(app, ui); }
        "eqtoggle" => tune::eq_toggle(app, ui),
        "tune" => { ui.set_tune_open(true); tune::refresh_tab(app, ui); }
        "fullscreen" => toggle_fullscreen(app, ui),
        "mute" => toggle_mute(app, ui),
        "quit" => { shutdown(app); let _ = slint::quit_event_loop(); }
        "snapshot" => {
            let dir = home_dir().join("Pictures").join("VLC Snapshots");
            let _ = std::fs::create_dir_all(&dir);
            let f = dir.join(format!("snap-{}.png", std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)));
            let ok = app.player.as_ref().map(|p| p.snapshot(&f.to_string_lossy())).unwrap_or(false);
            toast(app, ui, if ok { "Snapshot saved to Pictures\\VLC Snapshots" } else { "Snapshot failed" });
        }
        "subs:add" => {
            if let Some(f) = dialogs::pick_file("Subtitles", &["srt", "ass", "ssa", "sub", "vtt", "idx"]) {
                let ok = app.player.as_ref().map(|p| p.add_subtitle(&f.to_string_lossy())).unwrap_or(false);
                toast(app, ui, if ok { "Subtitle loaded" } else { "Could not load subtitle" });
            }
        }
        "pl:create" => create_playlist(app, ui),
        "pl:clear" => { app.queue.clear(); app.cur = None; do_stop(app, ui); ui.set_has_media(false); ui.set_player_page(false); set_queue_models(app, ui); }
        "open:files" => { let f = pick_media_files(); open_paths(app, ui, f); }
        "open:folder" => {
            if let Some(d) = dialogs::pick_folder("Add folder to library") {
                let s = d.to_string_lossy().into_owned();
                if !app.store.folders.contains(&s) { app.store.folders.push(s); app.store.save(); }
                app.nav = "videos".into();
                app.dir = Some(d);
                ui.set_player_page(false);
                refresh_library(app, ui);
            }
        }
        "open:net" => { app.nav = "network".into(); ui.set_player_page(false); refresh_library(app, ui); }
        _ => {}
    }
}

fn create_playlist(app: &mut App, ui: &MainWindow) {
    if app.queue.is_empty() { return toast(app, ui, "Queue is empty - open something first"); }
    let name = format!("Playlist {}", app.store.playlists.len() + 1);
    app.store.playlists.push(store::Playlist { name: name.clone(), items: app.queue.clone() });
    app.store.save();
    toast(app, ui, &format!("Saved \"{}\"", name));
    if app.nav == "playlists" { refresh_library(app, ui); }
}

fn toggle_mute(app: &mut App, ui: &MainWindow) {
    app.muted = !app.muted;
    if let Some(p) = app.player.as_ref() { p.set_mute(app.muted); }
    ui.set_muted(app.muted);
}

fn seek_step(app: &mut App, dir: i64) {
    let step = lead_num(&app.store.get("seek_step")).max(1) * 1000;
    if let Some(p) = app.player.as_ref() { p.seek_by_ms(dir * step); }
}

fn set_volume(app: &mut App, ui: &MainWindow, v: f32) {
    let v = v.clamp(0.0, 1.0);
    app.store.volume = v;
    ui.set_volume(v);
    if v > 0.0 && app.muted { app.muted = false; ui.set_muted(false); if let Some(p) = app.player.as_ref() { p.set_mute(false); } }
    if let Some(p) = app.player.as_ref() { p.set_volume((v * 100.0) as i32); }
}

fn shutdown(app: &mut App) {
    save_resume(app);
    app.store.save();
    if let Some(p) = app.player.as_ref() { p.stop(); }
}

fn libvlc_args(st: &Store) -> Vec<String> {
    let mut a: Vec<String> = vec!["--quiet".into(), "--no-stats".into(), "--no-snapshot-preview".into(), "--no-video-title-show".into()];
    a.push(if st.on("hw_decode") { "--avcodec-hw=any".into() } else { "--avcodec-hw=none".into() });
    if !st.on("sub_autodetect") { a.push("--no-sub-autodetect-file".into()); }
    if st.on("deinterlace") { a.push("--deinterlace=1".into()); }
    if st.on("normalize") { a.push("--audio-filter=normvol".into()); }
    if !st.on("lua") { a.push("--no-lua".into()); }
    if !st.on("drop_late") { a.push("--no-drop-late-frames".into()); a.push("--no-skip-frames".into()); }
    a.push(format!("--network-caching={}", lead_num(&st.get("net_cache"))));
    a.push(format!("--file-caching={}", lead_num(&st.get("file_cache"))));
    // audio path: explicit output module (WASAPI by default on Windows) and the high-quality SoX resampler
    match st.get("aout").as_str() {
        "WASAPI" => a.push("--aout=mmdevice".into()),
        "DirectSound" => a.push("--aout=directsound".into()),
        "WaveOut" => a.push("--aout=waveout".into()),
        _ => {}
    }
    a.push("--audio-resampler=soxr".into());
    a.push("--no-osd".into());
    if st.on("replay_gain") { a.push("--audio-replay-gain-mode=track".into()); }
    if let Ok(extra) = std::env::var("VLC_REDESIGN_ARGS") { a.extend(extra.split_whitespace().map(String::from)); }
    a
}

// ------------------------------------------------------------------ wiring

macro_rules! hook {
    ($ui:expr, $app:expr, $setter:ident, |$a:ident, $u:ident $(, $arg:ident)*| $body:block) => {{
        let app = $app.clone();
        let weak = $ui.as_weak();
        $ui.$setter(move |$($arg),*| {
            if let Some($u) = weak.upgrade() {
                // try_borrow: a native dialog may pump events while a handler is still running
                let Ok(mut $a) = app.try_borrow_mut() else { return };
                let $a = &mut *$a;
                let $u = &$u;
                $body
            }
        });
    }};
}

fn main() {
    platform::init();
    let store = Store::load();
    let args = libvlc_args(&store);
    let (vlc, err) = match Vlc::load(&args) { Ok(v) => (Some(v), String::new()), Err(e) => (None, e) };
    let player = vlc.as_ref().map(|v| v.new_player());

    let ui = MainWindow::new().expect("create window");
    vlc::MAX_FRAME_W.store(lead_num(&store.get("frame_w")).max(320) as u32, Ordering::Relaxed);

    let app = Rc::new(RefCell::new(App {
        store, player, vlc, err: err.clone(), queue: vec![], cur: None, nav: "videos".into(), dir: None, listing: vec![], crumb_paths: vec![],
        query: String::new(), sort_desc: false, speed: 1.0, muted: false, recording: None, last_activity: Instant::now(), fullscreen: false,
        settings_query: String::new(), row_defs: vec![], toast_until: None, now_title: String::new(), audio_only: false, ended_handled: true,
        grace_until: Instant::now(), tune: tune::TuneState::new(), exec_playing: false,
    }));

    {
        let mut a = app.borrow_mut();
        let a = &mut *a;
        ui.set_theme_index(a.store.theme_index);
        ui.set_accent_index(a.store.accent_index);
        ui.set_volume(a.store.volume);
        for k in ["fit", "tile_size", "nav_expanded"] { apply_setting(a, &ui, k); }
        if let Some(v) = a.vlc.as_ref() { eprintln!("libvlc {} loaded", v.version); }
        if !err.is_empty() { ui.set_error_text(err.into()); }
        refresh_library(a, &ui);
        if let Some(p) = a.player.as_ref() { p.set_volume((a.store.volume * 100.0) as i32); }
        tune::init(a, &ui);
        if let Some(p) = a.player.as_ref() { p.set_frame_notify(Arc::new(|| { let _ = slint::invoke_from_event_loop(pump_frame); })); }
    }
    CTX.with(|c| *c.borrow_mut() = Some((app.clone(), ui.as_weak())));

    // frameless window: drag / resize / minimize / maximize go through winit
    {
        let w = ui.as_weak();
        ui.on_window_drag(move || { if let Some(u) = w.upgrade() { u.window().with_winit_window(|win| { let _ = win.drag_window(); }); } });
        let w = ui.as_weak();
        ui.on_window_resize(move |d| {
            use winit::window::ResizeDirection as R;
            let dir = match d { 0 => R::North, 1 => R::South, 2 => R::East, 3 => R::West, 4 => R::NorthEast, 5 => R::NorthWest, 6 => R::SouthEast, _ => R::SouthWest };
            if let Some(u) = w.upgrade() { u.window().with_winit_window(|win| { let _ = win.drag_resize_window(dir); }); }
        });
        let w = ui.as_weak();
        ui.on_window_minimize(move || { if let Some(u) = w.upgrade() { u.window().set_minimized(true); } });
        let w = ui.as_weak();
        ui.on_window_toggle_maximize(move || {
            if let Some(u) = w.upgrade() { let m = !u.window().is_maximized(); u.window().set_maximized(m); u.set_win_max(m); }
        });
    }

    hook!(ui, app, on_nav_selected, |a, u, id| {
        a.nav = id.to_string();
        a.dir = None;
        a.query.clear();
        u.set_player_page(false);
        refresh_library(a, u);
    });
    hook!(ui, app, on_item_clicked, |a, u, i| {
        let Some(e) = a.listing.get(i as usize) else { return };
        let (kind, path, title) = (e.kind, e.path.clone(), e.title.clone());
        match kind {
            2 => {
                let p = PathBuf::from(&path);
                if p.starts_with(root_for("music")) { a.nav = "music".into(); } else { a.nav = "videos".into(); }
                a.dir = Some(p);
                a.query.clear();
                refresh_library(a, u);
            }
            0 | 1 => {
                let q: Vec<String> = a.listing.iter().filter(|e| e.kind <= 1).map(|e| e.path.clone()).collect();
                let start_i = q.iter().position(|p| *p == path).unwrap_or(0);
                a.queue = q;
                start(a, u, start_i);
            }
            3 => { let _ = title; if let Some(pl) = path.parse::<usize>().ok().and_then(|i| a.store.playlists.get(i)).cloned() { open_paths(a, u, pl.items); } }
            4 => create_playlist(a, u),
            _ => {}
        }
    });
    hook!(ui, app, on_crumb_clicked, |a, u, i| {
        if let Some(Some(p)) = a.crumb_paths.get(i as usize).cloned() { a.dir = Some(p); refresh_library(a, u); }
    });
    hook!(ui, app, on_go_up, |a, u| {
        if a.nav == "videos" || a.nav == "music" {
            if let Some(d) = a.dir.clone() {
                let root = root_for(&a.nav);
                if d != root { if let Some(par) = d.parent() { a.dir = Some(par.to_path_buf()); refresh_library(a, u); return; } }
            }
        }
        a.nav = "home".into();
        refresh_library(a, u);
    });
    hook!(ui, app, on_search, |a, u, q| { a.query = q.to_string(); refresh_library(a, u); });
    hook!(ui, app, on_toggle_sort, |a, u| { a.sort_desc = !a.sort_desc; refresh_library(a, u); });
    hook!(ui, app, on_toggle_compact, |a, u| {
        let nv = if u.get_compact() { "Large" } else { "Compact" };
        a.store.settings.insert("tile_size".into(), nv.into());
        a.store.save();
        apply_setting(a, u, "tile_size");
    });
    hook!(ui, app, on_toggle_play, |a, u| {
        if a.player.is_some() && a.cur.is_some() {
            let ended = a.player.as_ref().map(|p| matches!(p.state(), State::Ended | State::Stopped | State::Idle)).unwrap_or(false);
            if ended { let c = a.cur.unwrap(); start(a, u, c); } else { a.player.as_ref().unwrap().toggle_pause(); }
        } else if !a.queue.is_empty() { start(a, u, 0); }
    });
    hook!(ui, app, on_stop, |a, u| { do_stop(a, u); });
    hook!(ui, app, on_prev, |a, u| {
        // restart the current item when more than 3 s in (classic player behaviour)
        if a.player.as_ref().map(|p| p.time_ms() > 3000).unwrap_or(false) { if let Some(p) = a.player.as_ref() { p.set_position(0.0); } }
        else { step_next(a, u, -1); }
    });
    hook!(ui, app, on_next, |a, u| { step_next(a, u, 1); });
    hook!(ui, app, on_seek, |a, _u, v| { if let Some(p) = a.player.as_ref() { p.set_position(v); } });
    hook!(ui, app, on_seek_by, |a, _u, d| { seek_step(a, d as i64); });
    hook!(ui, app, on_set_volume, |a, u, v| { set_volume(a, u, v); });
    hook!(ui, app, on_volume_by, |a, u, d| {
        let step = lead_num(&a.store.get("volume_step")).max(1) as f32 / 100.0;
        let v = a.store.volume + d as f32 * step;
        set_volume(a, u, v);
    });
    hook!(ui, app, on_toggle_mute, |a, u| { toggle_mute(a, u); });
    hook!(ui, app, on_request_menu, |a, u, kind| {
        if kind == "record" { toggle_record(a, u); return; }
        let m = build_menu(a, u, &kind);
        u.set_menu_items(model(m));
    });
    hook!(ui, app, on_menu_activated, |a, u, id| { on_menu(a, u, &id); });
    hook!(ui, app, on_queue_clicked, |a, u, i| { start(a, u, i as usize); });
    hook!(ui, app, on_toggle_fullscreen, |a, u| { toggle_fullscreen(a, u); });
    hook!(ui, app, on_activity, |a, _u| { a.last_activity = Instant::now(); });
    hook!(ui, app, on_open_url, |a, u, url| {
        let s = url.trim().to_string();
        if !s.is_empty() { let s = if s.contains("://") { s } else { format!("http://{}", s) }; open_paths(a, u, vec![s]); }
    });
    hook!(ui, app, on_settings_row_toggled, |a, u, i| {
        if let Some(k) = a.row_defs.get(i as usize).copied() { cycle_setting(a, u, k); build_rows(a, u); }
    });
    hook!(ui, app, on_settings_search, |a, u, q| { a.settings_query = q.to_string(); build_rows(a, u); });
    hook!(ui, app, on_settings_page_changed, |a, u| { build_rows(a, u); });
    hook!(ui, app, on_appearance_changed, |a, u| {
        a.store.theme_index = u.get_theme_index();
        a.store.accent_index = u.get_accent_index();
        a.store.save();
    });
    hook!(ui, app, on_tune_tab_changed, |a, u| { tune::refresh_tab(a, u); });
    hook!(ui, app, on_param_changed, |a, u, i, v| { tune::param_changed(a, u, i, v); });
    hook!(ui, app, on_param_action, |a, u, i| { tune::param_action(a, u, i); });
    hook!(ui, app, on_eq_toggle, |a, u| { tune::eq_toggle(a, u); });
    hook!(ui, app, on_eq_preset_next, |a, u| { tune::eq_preset_next(a, u); });
    hook!(ui, app, on_eq_band_changed, |a, u, i, v| { tune::eq_band_changed(a, u, i, v); });
    hook!(ui, app, on_eq_reset, |a, u| { tune::eq_reset(a, u); });
    hook!(ui, app, on_create_playlist, |a, u| { create_playlist(a, u); });
    hook!(ui, app, on_quit_app, |a, _u| { shutdown(a); let _ = slint::quit_event_loop(); });

    // open file passed on the command line (file association / "Open with")
    if let Some(arg) = std::env::args().nth(1) {
        let mut a = app.borrow_mut();
        open_paths(&mut a, &ui, vec![arg]);
    }

    // 60 Hz pump: frames from libvlc -> Slint image, plus clock / state sync every ~100 ms
    let timer = Timer::default();
    {
        let app = app.clone();
        let weak = ui.as_weak();
        let mut n: u32 = 0;
        timer.start(TimerMode::Repeated, Duration::from_millis(25), move || {
            n = n.wrapping_add(1);
            if let (Some(ui), Ok(mut a)) = (weak.upgrade(), app.try_borrow_mut()) { tick(&mut a, &ui, n); }
        });
    }

    ui.run().expect("run");

    {
        let mut a = app.borrow_mut();
        shutdown(&mut a);
        a.player = None;
        a.vlc = None;
    }
    drop(timer);
    platform::set_playing(false);
    platform::shutdown();
}
