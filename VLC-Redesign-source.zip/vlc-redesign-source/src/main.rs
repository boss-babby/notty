#![cfg_attr(all(windows, not(debug_assertions)), windows_subsystem = "windows")]
//! VLC Redesign - Rust / Slint (retained-mode) front-end on top of libvlc.

mod dialogs;
mod platform;
mod store;
mod subs;
mod tune;
mod vlc;
mod winvideo;

slint::include_modules!();

use slint::winit_030::{winit, WinitWindowAccessor};
use slint::{ComponentHandle, Model, ModelRc, Timer, TimerMode, VecModel};
use std::cell::RefCell;
use std::path::{Path, PathBuf};
use std::rc::Rc;
use std::time::{Duration, Instant};
use store::{home_dir, Store, DEFS};
use vlc::{Player, State, Vlc};

const VIDEO_EXT: &[&str] = &["mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "m4v", "mpg", "mpeg", "ts", "m2ts", "3gp", "ogv", "vob", "mts"];
const AUDIO_EXT: &[&str] = &["mp3", "flac", "wav", "ogg", "opus", "m4a", "aac", "wma", "aiff", "ape", "mka"];

struct Entry { title: String, path: String, kind: i32, meta: String }

struct App {
    store: Store,
    // NOTE: field order matters for drop: player must drop before the libvlc instance.
    player: Option<Player>,
    vlc: Option<Vlc>,
    err: String,
    queue: Vec<String>,
    cur: Option<usize>,
    nav: String,
    dir: Option<PathBuf>,
    listing: Vec<Entry>,
    crumb_paths: Vec<Option<PathBuf>>,
    query: String,
    sort_desc: bool,
    speed: f32,
    muted: bool,
    recording: Option<String>,
    last_activity: Instant,
    fullscreen: bool,
    settings_query: String,
    row_defs: Vec<&'static str>,
    toast_until: Option<Instant>,
    now_title: String,
    audio_only: bool,
    ended_handled: bool,
    grace_until: Instant,
    tune: tune::TuneState,
    exec_playing: bool,
    host: Option<winvideo::VideoHost>,
    host_tries: u32,
    sub_orig: Vec<subs::Cue>,
    sub_cues: Vec<subs::Cue>,
    sub_path: Option<String>,
    sub_marks_on: bool,
    marks_key: (i64, i64, usize, bool),
    engine_dirty: Option<Instant>,
    item_dirty: Option<Instant>,
    retime_dirty: Option<Instant>,
    pending_tracks: Option<(Instant, i32, i32, bool)>,
    mouse: MouseState,
    ab: (Option<i64>, Option<i64>),
    stage_ratio: String,
    temp_sub_n: u32,
    pending_open: Option<Vec<String>>,
    manual_sub: Option<String>,
}

#[derive(Default)]
struct MouseState { prev_left: bool, prev_right: bool, last_click: Option<Instant>, pending_single: Option<Instant>, last_pos: (i32, i32) }

// ------------------------------------------------------------------ helpers

fn ext_of(p: &Path) -> String { p.extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default() }
/// 0 = video, 1 = audio
fn media_kind(p: &Path) -> Option<i32> {
    let e = ext_of(p);
    if VIDEO_EXT.contains(&e.as_str()) { Some(0) } else if AUDIO_EXT.contains(&e.as_str()) { Some(1) } else { None }
}
fn file_title(p: &str) -> String {
    Path::new(p).file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| p.to_string())
}
fn hms(ms: i64) -> String {
    let s = (ms.max(0) / 1000) as u64;
    format!("{:02}:{:02}:{:02}", s / 3600, (s / 60) % 60, s % 60)
}
fn lead_num(s: &str) -> i64 { s.split_whitespace().next().and_then(|n| n.parse().ok()).unwrap_or(0) }
fn tint(seed: &str) -> slint::Color {
    const P: [(u8, u8, u8); 8] = [(96, 44, 28), (28, 66, 110), (66, 34, 104), (24, 92, 66), (112, 84, 26), (104, 30, 66), (30, 88, 100), (84, 54, 40)];
    let h = seed.bytes().fold(7usize, |a, b| a.wrapping_mul(31).wrapping_add(b as usize));
    let c = P[h % P.len()];
    slint::Color::from_rgb_u8(c.0, c.1, c.2)
}
fn size_text(n: u64) -> String {
    if n >= 1 << 30 { format!("{:.1} GB", n as f64 / (1u64 << 30) as f64) } else { format!("{:.0} MB", n as f64 / (1u64 << 20) as f64) }
}
fn model<T: Clone + 'static>(v: Vec<T>) -> ModelRc<T> { ModelRc::new(VecModel::from(v)) }
fn me(label: &str, shortcut: &str, icon: &str, id: &str, sub: bool, checked: bool) -> MenuEntry {
    MenuEntry { label: label.into(), shortcut: shortcut.into(), icon: icon.into(), id: id.into(), sub, checked }
}
fn root_for(nav: &str) -> PathBuf { home_dir().join(if nav == "music" { "Music" } else { "Videos" }) }

// ------------------------------------------------------------------ library

fn list_dir(dir: &Path, nav: &str, st: &Store) -> Vec<Entry> {
    let mut out = vec![];
    let Ok(rd) = std::fs::read_dir(dir) else { return out };
    for e in rd.flatten() {
        let name = e.file_name().to_string_lossy().into_owned();
        if !st.on("show_hidden") && name.starts_with('.') { continue; }
        let path = e.path();
        let Ok(md) = e.metadata() else { continue };
        if md.is_dir() {
            out.push(Entry { title: name, path: path.to_string_lossy().into_owned(), kind: 2, meta: String::new() });
        } else {
            let want = if nav == "music" { 1 } else { 0 };
            let k = media_kind(&path);
            if k == Some(want) || (st.on("show_all_files") && k.is_some()) {
                out.push(Entry { title: name, path: path.to_string_lossy().into_owned(), kind: k.unwrap_or(0), meta: size_text(md.len()) });
            }
        }
    }
    out
}

fn refresh_library(app: &mut App, ui: &MainWindow) {
    let mut entries: Vec<Entry> = vec![];
    let mut crumbs: Vec<(String, Option<PathBuf>)> = vec![];
    match app.nav.as_str() {
        "videos" | "music" => {
            let root = root_for(&app.nav);
            let label = if app.nav == "music" { "Music" } else { "Videos" };
            let dir = app.dir.clone().unwrap_or_else(|| root.clone());
            entries = list_dir(&dir, &app.nav, &app.store);
            if let Ok(rel) = dir.strip_prefix(&root) {
                crumbs.push((label.into(), Some(root.clone())));
                let mut acc = root.clone();
                for c in rel.components() {
                    acc.push(c);
                    crumbs.push((c.as_os_str().to_string_lossy().into_owned(), Some(acc.clone())));
                }
            } else {
                let anc: Vec<&Path> = dir.ancestors().collect();
                for a in anc.iter().take(3).rev() {
                    let n = a.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| a.to_string_lossy().into_owned());
                    crumbs.push((n, Some(a.to_path_buf())));
                }
            }
            app.dir = Some(dir);
        }
        "home" => {
            crumbs.push(("Home".into(), None));
            for (n, p) in [("Videos", root_for("videos")), ("Music", root_for("music"))] {
                entries.push(Entry { title: n.into(), path: p.to_string_lossy().into_owned(), kind: 2, meta: String::new() });
            }
            for f in &app.store.folders {
                entries.push(Entry { title: file_title(f), path: f.clone(), kind: 2, meta: String::new() });
            }
            for r in &app.store.recent {
                if let Some(k) = media_kind(Path::new(r)) { entries.push(Entry { title: file_title(r), path: r.clone(), kind: k, meta: String::new() }); }
            }
        }
        "recent" => {
            crumbs.push(("Recent".into(), None));
            for r in &app.store.recent {
                let k = media_kind(Path::new(r)).unwrap_or(0);
                entries.push(Entry { title: file_title(r), path: r.clone(), kind: k, meta: String::new() });
            }
        }
        "playlists" => {
            crumbs.push(("Playlists".into(), None));
            entries.push(Entry { title: "Create playlist".into(), path: String::new(), kind: 4, meta: String::new() });
            for (i, p) in app.store.playlists.iter().enumerate() {
                entries.push(Entry { title: p.name.clone(), path: i.to_string(), kind: 3, meta: format!("{} items", p.items.len()) });
            }
        }
        _ => crumbs.push(("Network".into(), None)),
    }
    let q = app.query.to_lowercase();
    if !q.is_empty() { entries.retain(|e| e.title.to_lowercase().contains(&q)); }
    if app.nav == "videos" || app.nav == "music" {
        entries.sort_by(|a, b| (b.kind == 2).cmp(&(a.kind == 2)).then(a.title.to_lowercase().cmp(&b.title.to_lowercase())));
        if app.sort_desc { entries.reverse(); }
    }
    let items: Vec<MediaItem> = entries.iter().map(|e| MediaItem {
        title: e.title.clone().into(),
        path: e.path.clone().into(),
        kind: e.kind,
        meta: e.meta.clone().into(),
        tint: tint(&e.title),
        resume: if e.kind <= 1 { app.store.resume.get(&e.path).map(|&ms| (ms as f32 / 3_600_000.0).clamp(0.05, 0.95)).unwrap_or(0.0) } else { 0.0 },
    }).collect();
    let n = items.iter().filter(|i| i.kind != 4).count();
    ui.set_count_text(format!("{} items", n).into());
    ui.set_items(model(items));
    ui.set_crumbs(model(crumbs.iter().map(|(l, _)| Crumb { label: l.clone().into() }).collect()));
    app.crumb_paths = crumbs.into_iter().map(|(_, p)| p).collect();
    app.listing = entries;
    ui.set_nav(app.nav.clone().into());
}

// ------------------------------------------------------------------ playback

fn toast(app: &mut App, ui: &MainWindow, msg: &str) {
    ui.set_toast(msg.into());
    app.toast_until = Some(Instant::now() + Duration::from_millis(2800));
}

fn set_queue_models(app: &App, ui: &MainWindow) {
    let q: Vec<MediaItem> = app.queue.iter().map(|p| MediaItem {
        title: file_title(p).into(), path: p.clone().into(), kind: 0, meta: "".into(), tint: slint::Color::from_rgb_u8(0, 0, 0), resume: 0.0,
    }).collect();
    ui.set_queue(model(q));
    ui.set_current_index(app.cur.map(|c| c as i32).unwrap_or(-1));
}

fn save_resume(app: &mut App) {
    if !app.store.on("resume") { return; }
    let (Some(p), Some(c)) = (app.player.as_ref(), app.cur) else { return };
    let Some(path) = app.queue.get(c).cloned() else { return };
    let (t, len) = (p.time_ms(), p.length_ms());
    if t > 5000 && len > 0 && t < len - 10_000 { app.store.resume.insert(path, t as u32); } else { app.store.resume.remove(&path); }
}

fn start_with(app: &mut App, ui: &MainWindow, idx: usize, extra: Vec<String>) {
    let Some(path) = app.queue.get(idx).cloned() else { return };
    if app.player.is_none() {
        app.err = if app.err.is_empty() { "libvlc is not available".into() } else { app.err.clone() };
        ui.set_error_text(app.err.clone().into());
        ui.set_has_media(true);
        ui.set_player_page(true);
        app.cur = Some(idx);
        app.now_title = file_title(&path);
        ui.set_now_title(app.now_title.clone().into());
        set_queue_models(app, ui);
        return;
    }
    if app.cur.is_some() && extra.is_empty() { save_resume(app); }
    app.cur = Some(idx);
    let fresh = extra.is_empty();
    if fresh { app.manual_sub = None; }
    let mut opts = extra;
    if let Some(ms) = app.manual_sub.clone() { opts.push(format!(":sub-file={}", ms)); }
    if fresh && app.store.on("resume") {
        if let Some(ms) = app.store.resume.get(&path) { opts.push(format!(":start-time={}", ms / 1000)); }
    }
    opts.extend(tune::media_options(app));
    let vol = (app.store.volume * 100.0) as i32;
    let (speed, muted) = (app.speed, app.muted);
    let ok = {
        let p = app.player.as_mut().unwrap();
        let ok = p.play(&path, &opts);
        p.set_rate(speed);
        p.set_volume(vol);
        p.set_mute(muted);
        ok
    };
    tune::apply_all(app);
    apply_video_opts(app);
    app.sub_orig.clear();
    app.sub_cues.clear();
    app.sub_path = None;
    app.sub_marks_on = true;
    app.ab = (None, None);
    app.marks_key = (-1, 0, 0, false);
    if let Some(ms) = app.manual_sub.clone() {
        load_sub_cues(app, Path::new(&ms));
    } else if !path.contains("://") && app.store.on("sub_autodetect") {
        if let Some(sc) = subs::find_sidecars(&path).into_iter().next() { load_sub_cues(app, &sc); }
    }
    if !app.sub_orig.is_empty() && retime_needed(app) { app.retime_dirty = Some(Instant::now() + Duration::from_millis(1100)); }
    app.ended_handled = false;
    app.grace_until = Instant::now() + Duration::from_millis(1200);
    app.now_title = file_title(&path);
    app.audio_only = !path.contains("://") && media_kind(Path::new(&path)) == Some(1);
    if app.store.on("save_recent") && !path.contains("://") { app.store.push_recent(&path); }
    app.err = if ok { String::new() } else { "VLC could not open this item.".into() };
    ui.set_error_text(app.err.clone().into());
    ui.set_has_media(true);
    ui.set_audio_only(app.audio_only);
    ui.set_now_title(app.now_title.clone().into());
    ui.set_player_page(true);
    set_queue_models(app, ui);
    tune::refresh_tab(app, ui);
}
fn start(app: &mut App, ui: &MainWindow, idx: usize) { start_with(app, ui, idx, vec![]); }

fn open_paths(app: &mut App, ui: &MainWindow, paths: Vec<String>) {
    if paths.is_empty() { return; }
    app.queue = paths;
    start(app, ui, 0);
}

fn step_next(app: &mut App, ui: &MainWindow, dir: i32) {
    let n = app.queue.len() as i32;
    let Some(c) = app.cur else { return };
    if n == 0 { return; }
    let t = c as i32 + dir;
    if t >= 0 && t < n { start(app, ui, t as usize); }
    else if app.store.get("repeat") == "All" { start(app, ui, (t.rem_euclid(n)) as usize); }
}

fn do_stop(app: &mut App, ui: &MainWindow) {
    save_resume(app);
    app.sub_cues.clear();
    app.sub_orig.clear();
    if let Some(p) = app.player.as_ref() { p.stop(); }
    ui.set_playing(false);
    ui.set_position(0.0);
    ui.set_cur_time("00:00:00".into());
    app.ended_handled = true;
}

fn tick(app: &mut App, ui: &MainWindow, n: u32) {
    video_sync(app, ui);
    let now0 = Instant::now();
    if let Some(t) = app.mouse.pending_single { if now0 >= t { app.mouse.pending_single = None; if app.store.on("click_pause") { do_toggle_play(app, ui); } } }
    if let Some(t) = app.engine_dirty { if now0 >= t { app.engine_dirty = None; restart_engine(app, ui); } }
    if let Some(t) = app.item_dirty { if now0 >= t { app.item_dirty = None; reload_item(app, ui); } }
    if let Some(t) = app.retime_dirty { if now0 >= t && app.player.as_ref().map(|p| p.state() == State::Playing || p.state() == State::Paused).unwrap_or(false) { app.retime_dirty = None; apply_retimed(app, ui); } }
    if let Some((t, a, sidx, paused)) = app.pending_tracks {
        if now0 >= t && app.player.as_ref().map(|p| p.state() == State::Playing).unwrap_or(false) {
            app.pending_tracks = None;
            if let Some(p) = app.player.as_ref() {
                if a >= 0 { p.set_audio_track(a); }
                p.set_sub_track(sidx);
                if paused { p.toggle_pause(); }
            }
        }
    }
    // A-B loop
    if let (Some(a), Some(b), Some(p)) = (app.ab.0, app.ab.1, app.player.as_ref()) {
        if b > a && p.time_ms() >= b { p.seek_by_ms(a - p.time_ms()); }
    }
    if n % 4 != 0 { return; }
    update_marks(app, ui, n);
    if n % 40 == 0 && std::env::var_os("VLC_REDESIGN_STATS").is_some() {
        if let Some(p) = app.player.as_ref() {
            eprintln!("[stats] state={:?} t={}ms len={}ms native_vout={} vol={}", p.state(), p.time_ms(), p.length_ms(), p.has_video(), p.volume());
        }
    }
    let mx = ui.window().is_maximized();
    if mx != ui.get_win_max() { ui.set_win_max(mx); }
    let now = Instant::now();
    if let Some(t) = app.toast_until { if now > t { ui.set_toast("".into()); app.toast_until = None; } }
    if app.fullscreen { ui.set_controls_visible(now.duration_since(app.last_activity) < Duration::from_secs(3)); }
    let Some(p) = app.player.as_ref() else { return };
    let st = p.state();
    ui.set_playing(st == State::Playing || st == State::Opening || st == State::Buffering);
    let busy = st == State::Playing;
    if busy != app.exec_playing { app.exec_playing = busy; platform::set_playing(busy && !app.audio_only); }
    if st == State::Playing || st == State::Paused {
        let (t, len) = (p.time_ms(), p.length_ms());
        ui.set_cur_time(hms(t).into());
        ui.set_total_time(if app.store.on("show_remaining") { format!("-{}", hms(len - t)) } else { hms(len) }.into());
        let pos = p.position();
        if pos >= 0.0 { ui.set_position(pos); }
    }
    if st == State::Error && app.err.is_empty() {
        app.err = "VLC could not play this item.".into();
        ui.set_error_text(app.err.clone().into());
    }
    if st == State::Ended && !app.ended_handled && now > app.grace_until {
        app.ended_handled = true;
        let rep = app.store.get("repeat");
        let Some(c) = app.cur else { return };
        app.store.resume.remove(&app.queue[c]);
        if rep == "One" { start(app, ui, c); }
        else if app.store.on("autoplay_next") && (c + 1 < app.queue.len() || rep == "All") { step_next(app, ui, 1); }
        else { do_stop(app, ui); }
    }
}

fn toggle_fullscreen(app: &mut App, ui: &MainWindow) {
    app.fullscreen = !app.fullscreen;
    ui.window().set_fullscreen(app.fullscreen);
    ui.set_fullscreen_mode(app.fullscreen);
    ui.set_controls_visible(true);
    app.last_activity = Instant::now();
}

fn toggle_record(app: &mut App, ui: &MainWindow) {
    let (Some(c), Some(_)) = (app.cur, app.player.as_ref()) else { return toast(app, ui, "Nothing to record") };
    let path = app.queue[c].clone();
    let t = app.player.as_ref().unwrap().time_ms().max(0) / 1000;
    if let Some(out) = app.recording.take() {
        start_with(app, ui, c, vec![format!(":start-time={}", t)]);
        ui.set_recording(false);
        toast(app, ui, &format!("Recording saved: {}", out));
    } else {
        let dir = home_dir().join("Videos").join("VLC Recordings");
        let _ = std::fs::create_dir_all(&dir);
        let stamp = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0);
        let stem = Path::new(&path).file_stem().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| "stream".into());
        let out = dir.join(format!("{}-{}.ts", stem, stamp)).to_string_lossy().replace('\\', "/");
        let sout = format!(":sout=#duplicate{{dst=display,dst=std{{access=file,mux=ts,dst=\"{}\"}}}}", out);
        start_with(app, ui, c, vec![sout, ":sout-keep".into(), format!(":start-time={}", t)]);
        ui.set_recording(true);
        app.recording = Some(out);
        toast(app, ui, "Recording started (press R again to stop)");
    }
}

fn apply_setting(app: &mut App, ui: &MainWindow, key: &str) {
    match key {
        "fit" => { ui.set_fit_mode(match app.store.get("fit").as_str() { "Fill" => 1, "Stretch" => 2, _ => 0 }); apply_video_opts(app); }
        "tile_size" => ui.set_compact(app.store.get("tile_size") == "Compact"),
        "nav_expanded" => ui.set_nav_expanded(app.store.on("nav_expanded")),
        "show_hidden" | "show_all_files" => refresh_library(app, ui),
        "two_tone" => ui.global::<Theme>().set_two_tone(app.store.on("two_tone")),
        "show_marks" => ui.set_show_marks(app.store.on("show_marks")),
        "btn_prevnext" => ui.set_show_prev_next(app.store.on("btn_prevnext")),
        "btn_audio" => ui.set_show_audio_btn(app.store.on("btn_audio")),
        "btn_sub" => ui.set_show_sub_btn(app.store.on("btn_sub")),
        "btn_tune" => ui.set_show_tune_btn(app.store.on("btn_tune")),
        "btn_settings" => ui.set_show_settings_btn(app.store.on("btn_settings")),
        "btn_fs" => ui.set_show_fs_btn(app.store.on("btn_fs")),
        "btn_queue" => ui.set_show_queue_btn(app.store.on("btn_queue")),
        "stereo_mode" => { apply_video_opts(app); if app.store.get("stereo_mode") == "Stereo" { if let Some(p) = app.player.as_ref() { p.set_channel(1); } } }
        "aspect" | "crop" | "zoom" | "deint" => apply_video_opts(app),
        "boost_db" => tune::eq_apply(app),
        k if k.starts_with("sub_") => update_sub_style(app, ui),
        _ => {}
    }
}

fn cycle_setting(app: &mut App, ui: &MainWindow, key: &str) {
    let Some(d) = store::def(key) else { return };
    let nv: String = if d.kind == 0 {
        (if app.store.on(key) { "off" } else { "on" }).to_string()
    } else if d.kind == 1 {
        let cur = app.store.get(key);
        let i = d.options.iter().position(|o| *o == cur).unwrap_or(0);
        d.options[(i + 1) % d.options.len()].to_string()
    } else { return };
    set_setting(app, ui, key, &nv);
}

fn set_setting(app: &mut App, ui: &MainWindow, key: &str, val: &str) {
    let Some(d) = store::def(key) else { return };
    app.store.settings.insert(key.into(), val.into());
    app.store.save();
    apply_setting(app, ui, key);
    if d.label.contains("reloads engine") {
        app.engine_dirty = Some(Instant::now() + Duration::from_millis(1100));
        toast(app, ui, "Applying - reloading the VLC engine...");
    } else if d.label.contains("reloads item") {
        app.item_dirty = Some(Instant::now() + Duration::from_millis(700));
    } else if d.label.contains("re-times") {
        app.retime_dirty = Some(Instant::now() + Duration::from_millis(500));
    }
}

fn build_rows(app: &mut App, ui: &MainWindow) {
    let page = ui.get_settings_page().to_string();
    let q = app.settings_query.to_lowercase();
    app.row_defs.clear();
    let mut rows = vec![];
    for d in DEFS.iter() {
        let show = if q.is_empty() { d.page == page } else { d.kind != 2 && d.label.to_lowercase().contains(&q) };
        if !show { continue; }
        app.row_defs.push(d.key);
        let val = if d.kind == 1 { app.store.get(d.key) } else { String::new() };
        let sw = if d.key.ends_with("color") { Some(pal(&val)) } else { None };
        rows.push(Row {
            label: d.label.into(), kind: d.kind, on: d.kind == 0 && app.store.on(d.key), value: val.into(),
            swatch: sw.map(rgb).unwrap_or_default(), has_swatch: sw.is_some(),
        });
    }
    ui.set_rows(model(rows));
}

// ------------------------------------------------------------------ menus

fn build_menu(app: &mut App, ui: &MainWindow, kind: &str) -> Vec<MenuEntry> {
    let back = me("Back", "", "back", "menu:main", true, false);
    match kind {
        "playback" => {
            let mut v = vec![back, me("Speed", "", "", "", false, false)];
            for (l, s) in [("0.5x", 0.5f32), ("0.75x", 0.75), ("Normal", 1.0), ("1.25x", 1.25), ("1.5x", 1.5), ("2x", 2.0)] {
                v.push(me(l, "", "", &format!("speed:{}", s), false, (app.speed - s).abs() < 0.01));
            }
            v.push(me("Jump forward", "Right", "next", "seek:1", false, false));
            v.push(me("Jump backward", "Left", "prev", "seek:-1", false, false));
            v.push(me(&format!("Repeat: {}", app.store.get("repeat")), "", "playback", "cycle:repeat", false, false));
            v.push(me("Frame by frame", "E", "next", "nextframe", false, false));
            let ab = match app.ab { (None, _) => "A-B loop: set point A", (Some(_), None) => "A-B loop: set point B", _ => "A-B loop: clear" };
            v.push(me(ab, "", "reset", "abloop", false, false));
            v.push(me("Previous chapter", "", "prev", "chap:-1", false, false));
            v.push(me("Next chapter", "", "next", "chap:1", false, false));
            v
        }
        "video" => vec![back,
            me("Aspect ratio", "A", "", "menu:aspect", true, false), me("Crop", "C", "", "menu:crop", true, false),
            me("Zoom", "Z", "", "menu:zoom", true, false), me("Deinterlacing", "", "", "menu:deint", true, false),
            me("Scaling", "", "", "menu:fit", true, false),
            me("Fullscreen", "F", "fullscreen", "fullscreen", false, false), me("Take snapshot", "", "camera", "snapshot", false, false)],
        k if store::def(k).is_some() && store::def(k).map(|d| d.kind == 1).unwrap_or(false) => {
            let d = store::def(k).unwrap();
            let cur = app.store.get(k);
            let back_to = if k == "stereo_mode" || k == "boost_db" { "menu:audio" } else { "menu:video" };
            let mut v = vec![me("Back", "", "back", back_to, true, false)];
            for o in d.options { v.push(me(o, "", "", &format!("set:{}:{}", k, o), false, *o == cur)); }
            v
        }
        "audio" => {
            let mut v = vec![back, me("Mute", "M", "volume-mute", "mute", false, app.muted)];
            if let Some(p) = app.player.as_ref() {
                let (tr, cur) = p.audio_tracks();
                v.push(me("Audio track", "", "", "", false, false));
                for (id, name) in tr.into_iter().take(6) { v.push(me(&name, "", "", &format!("atrack:{}", id), false, id == cur)); }
            }
            v.push(me("Stereo mode", "", "", "menu:stereo_mode", true, false));
            v.push(me("Sound boost", "", "volume", "menu:boost_db", true, false));
            v.push(me("Audio delay -50 ms", "J", "", "adelay:-50", false, false));
            v.push(me("Audio delay +50 ms", "K", "", "adelay:50", false, false));
            v.push(me(if app.tune.eq_on { "Equalizer: On" } else { "Equalizer: Off" }, "", "wave", "eqtoggle", false, false));
            v
        }
        "subtitle" => {
            let mut v = vec![back, me("Add subtitle file...", "", "subtitle", "subs:add", false, false),
                me("Subtitle delay -50 ms", "G", "", "sdelay:-50", false, false), me("Subtitle delay +50 ms", "H", "", "sdelay:50", false, false),
                me("Subtitle appearance...", "", "sliders", "tune:3", false, false)];
            if let Some(p) = app.player.as_ref() {
                let (tr, cur) = p.sub_tracks();
                v.push(me("Subtitle track", "", "", "", false, false));
                for (id, name) in tr.into_iter().take(7) { v.push(me(&name, "", "", &format!("strack:{}", id), false, id == cur)); }
            }
            v
        }
        "playlist" => {
            let mut v = vec![back, me("Save queue as playlist", "", "add", "pl:create", false, false), me("Clear queue", "", "close", "pl:clear", false, false)];
            for (i, p) in app.store.playlists.iter().enumerate().take(7) { v.push(me(&p.name, "", "playlist", &format!("pl:load:{}", i), false, false)); }
            v
        }
        "open" => vec![back,
            me("Open file(s)...", "", "videos", "open:files", false, false),
            me("Open folder...", "", "folder", "open:folder", false, false),
            me("Open network stream...", "", "network", "open:net", false, false)],
        _ => {
            let playing = ui.get_playing();
            vec![
                me(if playing { "Pause" } else { "Play" }, "Space", if playing { "pause" } else { "play" }, "play", false, false),
                me("Stop", "S", "stop", "stop", false, false),
                me("Previous Item", "P", "prev", "prev", false, false),
                me("Next Item", "N", "next", "next", false, false),
                me(if app.recording.is_some() { "Stop recording" } else { "Record" }, "R", "record", "record", false, false),
                me("Hide UI", "Ctrl + \\", "hideui", "hideui", false, false),
                me("Playback", "", "playback", "menu:playback", true, false),
                me("Video", "", "clap", "menu:video", true, false),
                me("Audio", "", "wave", "menu:audio", true, false),
                me("Subtitle", "", "subtitle", "menu:subtitle", true, false),
                me("Tune playback", "T", "sliders", "tune", false, false),
                me("More Settings", "", "settings", "settings", true, false),
                me("Playlist", "", "playlist", "menu:playlist", true, false),
                me("Open Media", "", "openmedia", "menu:open", true, false),
                me("Quit VLC", "Ctrl + Q", "quit", "quit", false, false),
            ]
        }
    }
}

fn pick_media_files() -> Vec<String> {
    let mut exts: Vec<&str> = VIDEO_EXT.to_vec();
    exts.extend_from_slice(AUDIO_EXT);
    dialogs::pick_files("Open media", "Media files", &exts)
}

fn on_menu(app: &mut App, ui: &MainWindow, id: &str) {
    if let Some(k) = id.strip_prefix("menu:") {
        let m = build_menu(app, ui, k);
        ui.set_menu_items(model(m));
        return;
    }
    if let Some(v) = id.strip_prefix("speed:") {
        app.speed = v.parse().unwrap_or(1.0);
        if let Some(p) = app.player.as_ref() { p.set_rate(app.speed); }
        return toast(app, ui, &format!("Speed {}x", app.speed));
    }
    if let Some(v) = id.strip_prefix("fit:") {
        let n: i32 = v.parse().unwrap_or(0);
        set_setting(app, ui, "fit", ["Fit", "Fill", "Stretch"][n as usize % 3]);
        return;
    }
    if let Some(v) = id.strip_prefix("set:") {
        if let Some((k, val)) = v.split_once(':') { set_setting(app, ui, k, val); toast(app, ui, &format!("{}: {}", store::def(k).map(|d| d.label.split(" (").next().unwrap_or("")).unwrap_or(""), val)); }
        return;
    }
    if let Some(v) = id.strip_prefix("chap:") { if let Some(p) = app.player.as_ref() { let (c, n) = p.chapter(); let t = c + v.parse::<i32>().unwrap_or(1); if n > 0 && t >= 0 && t < n { p.set_chapter(t); } } return; }
    if let Some(v) = id.strip_prefix("sdelay:") { tune::nudge(app, ui, "sdelay", v.parse::<f32>().unwrap_or(0.0) / 1000.0); return; }
    if let Some(v) = id.strip_prefix("adelay:") { tune::nudge(app, ui, "adelay", v.parse::<f32>().unwrap_or(0.0) / 1000.0); return; }
    if let Some(v) = id.strip_prefix("tune:") { ui.set_tune_tab(v.parse().unwrap_or(0)); ui.set_tune_open(true); tune::refresh_tab(app, ui); return; }
    if let Some(v) = id.strip_prefix("atrack:") { if let Some(p) = app.player.as_ref() { p.set_audio_track(v.parse().unwrap_or(0)); } return; }
    if let Some(v) = id.strip_prefix("strack:") {
        let sid: i32 = v.parse().unwrap_or(-1);
        if let Some(p) = app.player.as_ref() { p.set_sub_track(sid); }
        app.sub_marks_on = sid != -1;
        return;
    }
    if let Some(v) = id.strip_prefix("cycle:") { return cycle_setting(app, ui, v); }
    if let Some(v) = id.strip_prefix("seek:") { return seek_step(app, v.parse().unwrap_or(1)); }
    if let Some(v) = id.strip_prefix("pl:load:") {
        if let Some(pl) = v.parse::<usize>().ok().and_then(|i| app.store.playlists.get(i)).cloned() { open_paths(app, ui, pl.items); }
        return;
    }
    match id {
        "play" => { do_toggle_play(app, ui); }
        "stop" => do_stop(app, ui),
        "prev" => step_next(app, ui, -1),
        "next" => step_next(app, ui, 1),
        "record" => toggle_record(app, ui),
        "hideui" => ui.set_ui_hidden(!ui.get_ui_hidden()),
        "settings" => { ui.set_settings_open(true); build_rows(app, ui); }
        "eqtoggle" => tune::eq_toggle(app, ui),
        "tune" => { ui.set_tune_open(true); tune::refresh_tab(app, ui); }
        "fullscreen" => toggle_fullscreen(app, ui),
        "mute" => toggle_mute(app, ui),
        "quit" => { shutdown(app); let _ = slint::quit_event_loop(); }
        "snapshot" => {
            let dir = home_dir().join("Pictures").join("VLC Snapshots");
            let _ = std::fs::create_dir_all(&dir);
            let f = dir.join(format!("snap-{}.png", std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)));
            let ok = app.player.as_ref().map(|p| p.snapshot(&f.to_string_lossy())).unwrap_or(false);
            toast(app, ui, if ok { "Snapshot saved to Pictures\\VLC Snapshots" } else { "Snapshot failed" });
        }
        "subs:add" => {
            if let Some(f) = dialogs::pick_file("Subtitles", &["srt", "ass", "ssa", "sub", "vtt", "idx"]) {
                let ok = app.player.as_ref().map(|p| p.add_subtitle(&f.to_string_lossy())).unwrap_or(false);
                let n = load_sub_cues(app, &f);
                app.manual_sub = Some(f.to_string_lossy().into_owned());
                if n > 0 && retime_needed(app) { app.retime_dirty = Some(Instant::now() + Duration::from_millis(400)); }
                app.marks_key = (-1, 0, 0, false);
                toast(app, ui, &if !ok { "Could not load subtitle".to_string() } else if n > 0 { format!("Subtitle loaded - {} cues on the seek bar", n) } else { "Subtitle loaded".to_string() });
            }
        }
        "nextframe" => { if let Some(p) = app.player.as_ref() { p.next_frame(); } }
        "abloop" => {
            let t = app.player.as_ref().map(|p| p.time_ms()).unwrap_or(0);
            app.ab = match app.ab { (None, _) => (Some(t), None), (Some(a), None) => (Some(a), Some(t.max(a + 500))), _ => (None, None) };
            let m = match app.ab { (Some(_), None) => "Loop start set - choose the end point", (Some(_), Some(_)) => "Looping A-B", _ => "A-B loop cleared" };
            toast(app, ui, m);
        }
        "pl:create" => create_playlist(app, ui),
        "pl:clear" => { app.queue.clear(); app.cur = None; do_stop(app, ui); ui.set_has_media(false); ui.set_player_page(false); set_queue_models(app, ui); }
        "open:files" => { let f = pick_media_files(); open_paths(app, ui, f); }
        "open:folder" => {
            if let Some(d) = dialogs::pick_folder("Add folder to library") {
                let s = d.to_string_lossy().into_owned();
                if !app.store.folders.contains(&s) { app.store.folders.push(s); app.store.save(); }
                app.nav = "videos".into();
                app.dir = Some(d);
                ui.set_player_page(false);
                refresh_library(app, ui);
            }
        }
        "open:net" => { app.nav = "network".into(); ui.set_player_page(false); refresh_library(app, ui); }
        _ => {}
    }
}

fn create_playlist(app: &mut App, ui: &MainWindow) {
    if app.queue.is_empty() { return toast(app, ui, "Queue is empty - open something first"); }
    let name = format!("Playlist {}", app.store.playlists.len() + 1);
    app.store.playlists.push(store::Playlist { name: name.clone(), items: app.queue.clone() });
    app.store.save();
    toast(app, ui, &format!("Saved \"{}\"", name));
    if app.nav == "playlists" { refresh_library(app, ui); }
}

fn toggle_mute(app: &mut App, ui: &MainWindow) {
    app.muted = !app.muted;
    if let Some(p) = app.player.as_ref() { p.set_mute(app.muted); }
    ui.set_muted(app.muted);
}

fn seek_step(app: &mut App, dir: i64) {
    let step = lead_num(&app.store.get("seek_step")).max(1) * 1000;
    if let Some(p) = app.player.as_ref() { p.seek_by_ms(dir * step); }
}

fn set_volume(app: &mut App, ui: &MainWindow, v: f32) {
    let v = v.clamp(0.0, 2.0);
    app.store.volume = v;
    ui.set_volume(v);
    if v > 0.0 && app.muted { app.muted = false; ui.set_muted(false); if let Some(p) = app.player.as_ref() { p.set_mute(false); } }
    if let Some(p) = app.player.as_ref() { p.set_volume((v * 100.0) as i32); }
}

fn shutdown(app: &mut App) {
    save_resume(app);
    app.store.save();
    if let Some(p) = app.player.as_ref() { p.stop(); }
}

fn safe_args() -> Vec<String> { vec!["--quiet".into(), "--no-video-title-show".into(), "--no-osd".into()] }

fn libvlc_args(st: &Store) -> Vec<String> {
    let mut a: Vec<String> = vec!["--quiet".into(), "--no-stats".into(), "--no-snapshot-preview".into(), "--no-video-title-show".into(), "--no-osd".into()];
    // ---- video: VLC's own GPU output (Direct3D11 + D3D11VA zero-copy decode by default)
    a.push(match st.get("hw_decode").as_str() { "D3D11VA" => "--avcodec-hw=d3d11va", "DXVA2" => "--avcodec-hw=dxva2", "Off" => "--avcodec-hw=none", _ => "--avcodec-hw=any" }.into());
    match st.get("vout").as_str() { "Direct3D11" => a.push("--vout=direct3d11".into()), "Direct3D9" => a.push("--vout=direct3d9".into()), "OpenGL" => a.push("--vout=gl".into()), _ => {} }
    if st.on("skip_loop") { a.push("--avcodec-skiploopfilter=4".into()); }
    if !st.on("sub_autodetect") { a.push("--no-sub-autodetect-file".into()); }
    if !st.on("lua") { a.push("--no-lua".into()); }
    if !st.on("drop_late") { a.push("--no-drop-late-frames".into()); a.push("--no-skip-frames".into()); }
    a.push(format!("--network-caching={}", lead_num(&st.get("net_cache"))));
    a.push(format!("--file-caching={}", lead_num(&st.get("file_cache"))));
    // ---- audio
    match st.get("aout").as_str() {
        "WASAPI" => a.push("--aout=mmdevice".into()),
        "DirectSound" => a.push("--aout=directsound".into()),
        "WaveOut" => a.push("--aout=waveout".into()),
        _ => {}
    }
    a.push("--audio-resampler=soxr".into());
    if st.on("replay_gain") { a.push("--audio-replay-gain-mode=track".into()); }
    // ---- subtitles (rendered by libvlc's freetype text renderer)
    let enc = st.get("sub_encoding");
    if enc != "Auto" { a.push(format!("--subsdec-encoding={}", enc)); }
    let lang = st.get("sub_lang");
    if lang != "Auto" { a.push(format!("--sub-language={}", lang)); }
    a.push(if st.on("sub_formatted") { "--subsdec-formatted".into() } else { "--no-subsdec-formatted".into() });
    a.push(format!("--freetype-font={}", st.get("sub_font")));
    a.push(format!("--freetype-rel-fontsize={}", rel_size(&st.get("sub_size"))));
    a.push(if st.on("sub_bold") { "--freetype-bold".into() } else { "--no-freetype-bold".into() });
    a.push(format!("--freetype-color={}", rgb_int(pal(&st.get("sub_color")))));
    a.push(format!("--freetype-opacity={}", (255.0 * lead_num(&st.get("sub_opacity")) as f32 / 100.0).round() as i32));
    a.push(format!("--freetype-outline-color={}", rgb_int(pal(&st.get("sub_outline_color")))));
    a.push("--freetype-outline-opacity=255".into());
    a.push(format!("--freetype-outline-thickness={}", outline_px(&st.get("sub_outline_width"))));
    let (bgo, sho) = (match st.get("sub_bg").as_str() { "Semi-transparent" => 140, "Solid" => 255, _ => 0 }, match st.get("sub_shadow").as_str() { "Soft" => 110, "Hard" => 255, _ => 0 });
    a.push(format!("--freetype-background-opacity={}", bgo));
    a.push("--freetype-background-color=0".into());
    a.push(format!("--freetype-shadow-opacity={}", sho));
    a.push("--freetype-shadow-color=0".into());
    a.push(format!("--sub-margin={}", lead_num(&st.get("sub_margin"))));
    if let Ok(extra) = std::env::var("VLC_REDESIGN_ARGS") { a.extend(extra.split_whitespace().map(String::from)); }
    a
}

fn load_vlc(st: &Store) -> (Option<Vlc>, String) {
    match Vlc::load(&libvlc_args(st)) {
        Ok(v) => (Some(v), String::new()),
        // an option the bundled libvlc does not know makes libvlc_new fail -> retry with a minimal set
        Err(e1) => match Vlc::load(&safe_args()) { Ok(v) => (Some(v), String::new()), Err(e2) => (None, format!("{e1} / {e2}")) },
    }
}

// ------------------------------------------------------------------ colours / subtitle style
fn pal(name: &str) -> (u8, u8, u8) {
    match name {
        "White" => (255, 255, 255), "Light gray" => (184, 184, 184), "Yellow" => (255, 230, 0), "Cyan" => (0, 229, 255),
        "Green" => (124, 252, 0), "Orange" => (255, 152, 0), "Pink" => (255, 105, 180), "Red" => (255, 59, 48), "Black" => (0, 0, 0),
        "Dark gray" => (32, 32, 32), "Blue" => (30, 100, 255), _ => (255, 255, 255),
    }
}
fn rgb(c: (u8, u8, u8)) -> slint::Color { slint::Color::from_rgb_u8(c.0, c.1, c.2) }
fn rgb_int(c: (u8, u8, u8)) -> u32 { ((c.0 as u32) << 16) | ((c.1 as u32) << 8) | c.2 as u32 }
fn rel_size(name: &str) -> i32 { match name { "Small" => 18, "Smaller" => 20, "Large" => 12, "Larger" => 9, "Huge" => 6, _ => 16 } }
/// libvlc freetype outline thickness choices: None 0, Thin 2, Normal 4, Thick 6
fn outline_px(name: &str) -> i32 { match name { "None" => 0, "Thin" => 2, "Thick" => 6, _ => 4 } }

fn update_sub_style(app: &App, ui: &MainWindow) {
    let op = lead_num(&app.store.get("sub_opacity")).clamp(10, 100) as f32 / 100.0;
    let st = SubStyle {
        font: app.store.get("sub_font").into(),
        color: rgb(pal(&app.store.get("sub_color"))).with_alpha(op),
        outline: rgb(pal(&app.store.get("sub_outline_color"))),
        outline_w: match outline_px(&app.store.get("sub_outline_width")) { 0 => 0.0, 2 => 1.0, 6 => 3.5, _ => 2.0 },
        size: 92.0 / rel_size(&app.store.get("sub_size")) as f32 * 2.4,
        bold: app.store.on("sub_bold"),
        sample: "The quick brown fox jumps over the lazy dog".into(),
    };
    ui.set_sub_style(st);
}

// ------------------------------------------------------------------ subtitles on the seek bar
fn load_sub_cues(app: &mut App, path: &Path) -> usize {
    match subs::parse_file(path) {
        Some(c) => {
            let n = c.len();
            app.sub_orig = c.clone();
            app.sub_cues = c;
            app.sub_path = Some(path.to_string_lossy().into_owned());
            app.sub_marks_on = true;
            n
        }
        None => 0,
    }
}
fn sub_speed(app: &App) -> f64 { app.store.get("sub_speed").trim_end_matches('x').parse().unwrap_or(1.0) }
fn sub_dur(app: &App) -> f64 { app.store.get("sub_dur").parse().unwrap_or(0.0) }
fn retime_needed(app: &App) -> bool { (sub_speed(app) - 1.0).abs() > 1e-6 || sub_dur(app) > 1e-6 }

/// Re-times the loaded external subtitle (speed + duration factor) and hands the result back to VLC.
fn apply_retimed(app: &mut App, ui: &MainWindow) {
    if app.sub_orig.is_empty() { return toast(app, ui, "Re-timing needs an external subtitle file (srt / ass / vtt / sub)"); }
    let (sp, du) = (sub_speed(app), sub_dur(app));
    if retime_needed(app) {
        app.temp_sub_n += 1;
        let f = std::env::temp_dir().join("vlc-redesign-subs").join(format!("retimed-{}.srt", app.temp_sub_n));
        if subs::write_retimed(&app.sub_orig, sp, du, &f) {
            if let Some(c) = subs::parse_file(&f) { app.sub_cues = c; }
            if let Some(p) = app.player.as_ref() { p.add_subtitle(&f.to_string_lossy()); }
        }
    } else {
        app.sub_cues = app.sub_orig.clone();
        if let (Some(path), Some(p)) = (app.sub_path.clone(), app.player.as_ref()) { p.add_subtitle(&path); }
    }
    app.sub_marks_on = true;
    app.marks_key = (-1, 0, 0, false);
}

fn update_marks(app: &mut App, ui: &MainWindow, n: u32) {
    let (len, t) = app.player.as_ref().map(|p| (p.length_ms(), p.time_ms())).unwrap_or((0, 0));
    let delay = (tune::sub_delay_s(app) * 1000.0) as i64;
    let on = app.sub_marks_on && !app.sub_cues.is_empty();
    let key = (len, delay, app.sub_cues.len(), on);
    if key != app.marks_key {
        app.marks_key = key;
        let segs = if on { subs::seekbar_marks(&app.sub_cues, delay, len, 320) } else { vec![] };
        ui.set_sub_marks(model(segs.into_iter().map(|(a, b)| Seg { x: a, w: b - a, on: false }).collect()));
    }
    let panel = (ui.get_tune_open() && ui.get_tune_tab() == 3) || (ui.get_settings_open() && ui.get_settings_page().as_str() == "Subtitles");
    if panel && n % 8 == 0 {
        let w = if on { subs::window_segments(&app.sub_cues, t, delay, 30_000) } else { vec![] };
        ui.set_sub_win(model(w.into_iter().map(|(a, b, act)| Seg { x: a, w: b - a, on: act }).collect()));
        ui.set_sub_cue_text((if on { subs::active_text(&app.sub_cues, t, delay) } else { String::new() }).into());
        ui.set_sub_delay_text(format!("{:+.2} s", delay as f64 / 1000.0).into());
    }
}

// ------------------------------------------------------------------ native video window
fn parent_hwnd(ui: &MainWindow) -> Option<isize> {
    use winit::raw_window_handle::{HasWindowHandle, RawWindowHandle};
    ui.window().with_winit_window(|w| {
        w.window_handle().ok().and_then(|h| match h.as_raw() { RawWindowHandle::Win32(x) => Some(x.hwnd.get()), _ => None })
    }).flatten()
}

fn try_create_host(app: &mut App, ui: &MainWindow) {
    if app.host.is_some() { return; }
    if let Some(hwnd) = parent_hwnd(ui) {
        if let Some(h) = winvideo::VideoHost::create(hwnd) {
            if let Some(p) = app.player.as_ref() { p.set_hwnd(h.handle()); }
            app.host = Some(h);
            if let Some(v) = app.pending_open.take() { open_paths(app, ui, v); }
        }
    }
}

fn apply_video_opts(app: &App) {
    let Some(p) = app.player.as_ref() else { return };
    let aspect = app.store.get("aspect");
    let crop = app.store.get("crop");
    let ratio = app.stage_ratio.clone();
    let asp = if aspect == "Default" { "" } else { aspect.as_str() };
    let crp = if crop == "None" { "" } else { crop.as_str() };
    match app.store.get("fit").as_str() {
        "Fill" => { p.set_aspect(asp); p.set_crop(if ratio.is_empty() { crp } else { &ratio }); }
        "Stretch" => { p.set_aspect(if ratio.is_empty() { asp } else { &ratio }); p.set_crop(crp); }
        _ => { p.set_aspect(asp); p.set_crop(crp); }
    }
    let z = app.store.get("zoom");
    p.set_scale(if z == "Fit" { 0.0 } else { lead_num(&z) as f32 / 100.0 });
    p.set_deinterlace(match app.store.get("deint").as_str() {
        "Yadif" => "yadif", "Yadif (2x)" => "yadif2x", "Blend" => "blend", "Bob" => "bob", "Linear" => "linear", "X" => "x", "Mean" => "mean", "Discard" => "discard", _ => "",
    });
    // only force a stereo mode when the user picked one (the default must not touch multichannel downmix)
    match app.store.get("stereo_mode").as_str() { "Reverse stereo" => p.set_channel(2), "Left only" => p.set_channel(3), "Right only" => p.set_channel(4), "Dolby surround" => p.set_channel(5), _ => {} }
}

fn video_sync(app: &mut App, ui: &MainWindow) {
    if app.host.is_none() && app.host_tries < 400 { app.host_tries += 1; try_create_host(app, ui); }
    let sc = ui.window().scale_factor();
    let has_vo = app.player.as_ref().map(|p| p.has_video()).unwrap_or(false);
    let visible = ui.get_player_page() && has_vo && ui.get_has_media();
    if visible && !ui.get_has_frame() { apply_video_opts(app); }
    if ui.get_has_frame() != visible { ui.set_has_frame(visible); }
    let to = |v: f32| (v * sc).round() as i32;
    let vr = ui.get_video_rect();
    let rect = winvideo::Rect { x: to(vr.x), y: to(vr.y), w: to(vr.w), h: to(vr.h) };
    let bare = app.fullscreen || ui.get_ui_hidden();
    if let Some(h) = app.host.as_mut() {
        let cuts: Vec<winvideo::Rect> = ui.get_cuts().iter().map(|c| winvideo::Rect { x: to(c.x), y: to(c.y), w: to(c.w), h: to(c.h) }).collect();
        h.update(visible, rect, &cuts, if bare { 0 } else { to(6.0) });
    }
    // keep "Fill" / "Stretch" matched to the stage shape
    let ratio = format!("{}:{}", rect.w.max(1), rect.h.max(1));
    if ratio != app.stage_ratio && rect.w > 16 {
        app.stage_ratio = ratio;
        if app.store.get("fit") != "Fit" { apply_video_opts(app); }
    }
    // mouse on the video (VLC's child window swallows window messages, so the cursor is polled)
    let Some(m) = app.host.as_ref().map(|h| h.mouse()) else { return };
    let now = Instant::now();
    if (m.x, m.y) != app.mouse.last_pos {
        app.mouse.last_pos = (m.x, m.y);
        let sz = ui.window().size();
        if m.x >= 0 && m.y >= 0 && m.x < sz.width as i32 && m.y < sz.height as i32 { app.last_activity = now; }
    }
    if m.over_video && m.left && !app.mouse.prev_left {
        if ui.get_menu_open() { ui.invoke_close_menu(); }
        else if app.mouse.last_click.map(|t| now.duration_since(t) < Duration::from_millis(350)).unwrap_or(false) {
            app.mouse.last_click = None;
            app.mouse.pending_single = None;
            if app.store.on("dblclick_fs") { toggle_fullscreen(app, ui); }
        } else {
            app.mouse.last_click = Some(now);
            app.mouse.pending_single = Some(now + Duration::from_millis(300));
        }
    }
    if m.over_video && m.right && !app.mouse.prev_right {
        // build the items here: the `request-menu` callback cannot re-borrow the app while the tick holds it
        let items = build_menu(app, ui, "main");
        ui.set_menu_items(model(items));
        ui.invoke_open_context_menu(m.x as f32 / sc, m.y as f32 / sc);
    }
    // keep the fullscreen control bar while the cursor rests on it
    if app.fullscreen && ui.get_controls_visible() && (m.y as f32) > (ui.window().size().height as f32 - 70.0 * sc) && m.y >= 0 { app.last_activity = now; }
    app.mouse.prev_left = m.left;
    app.mouse.prev_right = m.right;
}

fn do_toggle_play(a: &mut App, u: &MainWindow) {
    if a.player.is_some() && a.cur.is_some() {
        let ended = a.player.as_ref().map(|p| matches!(p.state(), State::Ended | State::Stopped | State::Idle)).unwrap_or(false);
        if ended { let c = a.cur.unwrap(); start(a, u, c); } else { a.player.as_ref().unwrap().toggle_pause(); }
    } else if !a.queue.is_empty() { start(a, u, 0); }
}

// ------------------------------------------------------------------ engine / item reload
fn reload_item(app: &mut App, ui: &MainWindow) {
    let Some(c) = app.cur else { return };
    let Some(p) = app.player.as_ref() else { return };
    if !matches!(p.state(), State::Playing | State::Paused) { return; }
    let t = p.time_ms().max(0) as f64 / 1000.0;
    let paused = p.state() == State::Paused;
    let (a, s) = (p.audio_tracks().1, p.sub_tracks().1);
    start_with(app, ui, c, vec![format!(":start-time={:.2}", t)]);
    app.pending_tracks = Some((Instant::now() + Duration::from_millis(1000), a, s, paused));
}

/// Re-creates the libvlc instance with the current settings (subtitle style, decoder, outputs ...) and resumes at the same position.
fn restart_engine(app: &mut App, ui: &MainWindow) {
    let (cur, t, paused, a, s) = match app.player.as_ref() {
        Some(p) if app.cur.is_some() && matches!(p.state(), State::Playing | State::Paused | State::Buffering) => {
            (app.cur, p.time_ms().max(0) as f64 / 1000.0, p.state() == State::Paused, p.audio_tracks().1, p.sub_tracks().1)
        }
        _ => (None, 0.0, false, -1, -1),
    };
    app.player = None;
    app.vlc = None;
    let (vlc, err) = load_vlc(&app.store);
    app.err = err;
    app.vlc = vlc;
    app.player = app.vlc.as_ref().map(|v| v.new_player());
    if let (Some(p), Some(h)) = (app.player.as_ref(), app.host.as_ref()) { p.set_hwnd(h.handle()); }
    if let Some(p) = app.player.as_ref() { p.set_volume((app.store.volume * 100.0).round() as i32); p.set_mute(app.muted); }
    tune::eq_apply(app);
    if let Some(c) = cur {
        start_with(app, ui, c, vec![format!(":start-time={:.2}", t)]);
        app.pending_tracks = Some((Instant::now() + Duration::from_millis(1200), a, s, paused));
    }
    toast(app, ui, "Engine reloaded");
}

// ------------------------------------------------------------------ extra keyboard shortcuts
fn cycle_sub(app: &mut App, ui: &MainWindow) {
    let (tr, cur) = match app.player.as_ref() { Some(p) => p.sub_tracks(), None => return };
    if tr.is_empty() { return; }
    let pos = tr.iter().position(|(id, _)| *id == cur).unwrap_or(0);
    let (id, name) = tr[(pos + 1) % tr.len()].clone();
    if let Some(p) = app.player.as_ref() { p.set_sub_track(id); }
    app.sub_marks_on = id != -1;
    toast(app, ui, &format!("Subtitle: {}", name));
}
fn cycle_audio(app: &mut App, ui: &MainWindow) {
    let (tr, cur) = match app.player.as_ref() { Some(p) => p.audio_tracks(), None => return };
    if tr.is_empty() { return; }
    let pos = tr.iter().position(|(id, _)| *id == cur).unwrap_or(0);
    let (id, name) = tr[(pos + 1) % tr.len()].clone();
    if let Some(p) = app.player.as_ref() { p.set_audio_track(id); }
    toast(app, ui, &format!("Audio: {}", name));
}
fn speed_step(app: &mut App, ui: &MainWindow, dir: i32) {
    const T: [f32; 9] = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0];
    let i = T.iter().enumerate().min_by(|a, b| (a.1 - app.speed).abs().partial_cmp(&(b.1 - app.speed).abs()).unwrap()).map(|x| x.0).unwrap_or(3) as i32;
    app.speed = T[(i + dir).clamp(0, 8) as usize];
    if let Some(p) = app.player.as_ref() { p.set_rate(app.speed); }
    toast(app, ui, &format!("Speed {}x", app.speed));
    tune::refresh_tab(app, ui);
}
fn handle_key(app: &mut App, ui: &MainWindow, k: &str) {
    let seek = |app: &App, ms: i64| { if let Some(p) = app.player.as_ref() { p.seek_by_ms(ms); } };
    match k {
        "jump-long-back" => seek(app, -60_000),
        "jump-long-fwd" => seek(app, 60_000),
        "jump-short-back" => seek(app, -3_000),
        "jump-short-fwd" => seek(app, 3_000),
        "e" => { if let Some(p) = app.player.as_ref() { p.next_frame(); } }
        "[" | "-" => speed_step(app, ui, -1),
        "]" | "+" => speed_step(app, ui, 1),
        "=" => { app.speed = 1.0; if let Some(p) = app.player.as_ref() { p.set_rate(1.0); } toast(app, ui, "Speed 1x"); tune::refresh_tab(app, ui); }
        "g" => tune::nudge(app, ui, "sdelay", -0.05),
        "h" => tune::nudge(app, ui, "sdelay", 0.05),
        "j" => tune::nudge(app, ui, "adelay", -0.05),
        "k" => tune::nudge(app, ui, "adelay", 0.05),
        "v" => cycle_sub(app, ui),
        "b" => cycle_audio(app, ui),
        "a" | "z" | "c" => {
            let key = match k { "a" => "aspect", "z" => "zoom", _ => "crop" };
            cycle_setting(app, ui, key);
            toast(app, ui, &format!("{}: {}", key, app.store.get(key)));
        }
        _ => {}
    }
}

// ------------------------------------------------------------------ wiring

macro_rules! hook {
    ($ui:expr, $app:expr, $setter:ident, |$a:ident, $u:ident $(, $arg:ident)*| $body:block) => {{
        let app = $app.clone();
        let weak = $ui.as_weak();
        $ui.$setter(move |$($arg),*| {
            if let Some($u) = weak.upgrade() {
                // try_borrow: a native dialog may pump events while a handler is still running
                let Ok(mut $a) = app.try_borrow_mut() else { return };
                let $a = &mut *$a;
                let $u = &$u;
                $body
            }
        });
    }};
}

fn main() {
    platform::init();
    let store = Store::load();
    let (vlc, err) = load_vlc(&store);
    let player = vlc.as_ref().map(|v| v.new_player());

    let ui = MainWindow::new().expect("create window");

    let app = Rc::new(RefCell::new(App {
        store, player, vlc, err: err.clone(), queue: vec![], cur: None, nav: "videos".into(), dir: None, listing: vec![], crumb_paths: vec![],
        query: String::new(), sort_desc: false, speed: 1.0, muted: false, recording: None, last_activity: Instant::now(), fullscreen: false,
        settings_query: String::new(), row_defs: vec![], toast_until: None, now_title: String::new(), audio_only: false, ended_handled: true,
        grace_until: Instant::now(), tune: tune::TuneState::new(), exec_playing: false,
        host: None, host_tries: 0, sub_orig: vec![], sub_cues: vec![], sub_path: None, sub_marks_on: true, marks_key: (-1, 0, 0, false),
        engine_dirty: None, item_dirty: None, retime_dirty: None, pending_tracks: None, mouse: MouseState::default(), ab: (None, None),
        stage_ratio: String::new(), temp_sub_n: 0, pending_open: None, manual_sub: None,
    }));

    {
        let mut a = app.borrow_mut();
        let a = &mut *a;
        ui.set_theme_index(a.store.theme_index);
        ui.set_accent_index(a.store.accent_index);
        ui.set_volume(a.store.volume);
        a.store.volume = a.store.volume.clamp(0.0, 2.0);
        for k in ["fit", "tile_size", "nav_expanded", "two_tone", "show_marks", "btn_prevnext", "btn_audio", "btn_sub", "btn_tune", "btn_settings", "btn_fs", "btn_queue"] { apply_setting(a, &ui, k); }
        update_sub_style(a, &ui);
        apply_video_opts(a);
        if let Some(v) = a.vlc.as_ref() { eprintln!("libvlc {} loaded", v.version); }
        if !err.is_empty() { ui.set_error_text(err.into()); }
        refresh_library(a, &ui);
        if let Some(p) = a.player.as_ref() { p.set_volume((a.store.volume * 100.0) as i32); }
        tune::init(a, &ui);
    }
    // the native video window must exist before the first item starts
    ui.show().expect("show window");
    try_create_host(&mut app.borrow_mut(), &ui);

    // frameless window: drag / resize / minimize / maximize go through winit
    {
        let w = ui.as_weak();
        ui.on_window_drag(move || { if let Some(u) = w.upgrade() { u.window().with_winit_window(|win| { let _ = win.drag_window(); }); } });
        let w = ui.as_weak();
        ui.on_window_resize(move |d| {
            use winit::window::ResizeDirection as R;
            let dir = match d { 0 => R::North, 1 => R::South, 2 => R::East, 3 => R::West, 4 => R::NorthEast, 5 => R::NorthWest, 6 => R::SouthEast, _ => R::SouthWest };
            if let Some(u) = w.upgrade() { u.window().with_winit_window(|win| { let _ = win.drag_resize_window(dir); }); }
        });
        let w = ui.as_weak();
        ui.on_window_minimize(move || { if let Some(u) = w.upgrade() { u.window().set_minimized(true); } });
        let w = ui.as_weak();
        ui.on_window_toggle_maximize(move || {
            if let Some(u) = w.upgrade() { let m = !u.window().is_maximized(); u.window().set_maximized(m); u.set_win_max(m); }
        });
    }

    hook!(ui, app, on_nav_selected, |a, u, id| {
        a.nav = id.to_string();
        a.dir = None;
        a.query.clear();
        u.set_player_page(false);
        refresh_library(a, u);
    });
    hook!(ui, app, on_item_clicked, |a, u, i| {
        let Some(e) = a.listing.get(i as usize) else { return };
        let (kind, path, title) = (e.kind, e.path.clone(), e.title.clone());
        match kind {
            2 => {
                let p = PathBuf::from(&path);
                if p.starts_with(root_for("music")) { a.nav = "music".into(); } else { a.nav = "videos".into(); }
                a.dir = Some(p);
                a.query.clear();
                refresh_library(a, u);
            }
            0 | 1 => {
                let q: Vec<String> = a.listing.iter().filter(|e| e.kind <= 1).map(|e| e.path.clone()).collect();
                let start_i = q.iter().position(|p| *p == path).unwrap_or(0);
                a.queue = q;
                start(a, u, start_i);
            }
            3 => { let _ = title; if let Some(pl) = path.parse::<usize>().ok().and_then(|i| a.store.playlists.get(i)).cloned() { open_paths(a, u, pl.items); } }
            4 => create_playlist(a, u),
            _ => {}
        }
    });
    hook!(ui, app, on_crumb_clicked, |a, u, i| {
        if let Some(Some(p)) = a.crumb_paths.get(i as usize).cloned() { a.dir = Some(p); refresh_library(a, u); }
    });
    hook!(ui, app, on_go_up, |a, u| {
        if a.nav == "videos" || a.nav == "music" {
            if let Some(d) = a.dir.clone() {
                let root = root_for(&a.nav);
                if d != root { if let Some(par) = d.parent() { a.dir = Some(par.to_path_buf()); refresh_library(a, u); return; } }
            }
        }
        a.nav = "home".into();
        refresh_library(a, u);
    });
    hook!(ui, app, on_search, |a, u, q| { a.query = q.to_string(); refresh_library(a, u); });
    hook!(ui, app, on_toggle_sort, |a, u| { a.sort_desc = !a.sort_desc; refresh_library(a, u); });
    hook!(ui, app, on_toggle_compact, |a, u| {
        let nv = if u.get_compact() { "Large" } else { "Compact" };
        a.store.settings.insert("tile_size".into(), nv.into());
        a.store.save();
        apply_setting(a, u, "tile_size");
    });
    hook!(ui, app, on_toggle_play, |a, u| { do_toggle_play(a, u); });
    hook!(ui, app, on_key, |a, u, k| { handle_key(a, u, &k); });
    {
        let app = app.clone();
        ui.on_hover_info(move |v| {
            let Ok(a) = app.try_borrow() else { return "".into() };
            let Some(p) = a.player.as_ref() else { return "".into() };
            let t = (v as f64 * p.length_ms().max(0) as f64) as i64;
            let delay = (tune::sub_delay_s(&a) * 1000.0) as i64;
            let cue = if a.sub_marks_on { subs::active_text(&a.sub_cues, t, delay) } else { String::new() };
            if cue.is_empty() { hms(t).into() } else { format!("{}   {}", hms(t), cue.chars().take(70).collect::<String>()).into() }
        });
    }
    hook!(ui, app, on_stop, |a, u| { do_stop(a, u); });
    hook!(ui, app, on_prev, |a, u| {
        // restart the current item when more than 3 s in (classic player behaviour)
        if a.player.as_ref().map(|p| p.time_ms() > 3000).unwrap_or(false) { if let Some(p) = a.player.as_ref() { p.set_position(0.0); } }
        else { step_next(a, u, -1); }
    });
    hook!(ui, app, on_next, |a, u| { step_next(a, u, 1); });
    hook!(ui, app, on_seek, |a, _u, v| { if let Some(p) = a.player.as_ref() { p.set_position(v); } });
    hook!(ui, app, on_seek_by, |a, _u, d| { seek_step(a, d as i64); });
    hook!(ui, app, on_set_volume, |a, u, v| { set_volume(a, u, v); });
    hook!(ui, app, on_volume_by, |a, u, d| {
        let step = lead_num(&a.store.get("volume_step")).max(1) as f32 / 100.0;
        let v = a.store.volume + d as f32 * step;
        set_volume(a, u, v);
    });
    hook!(ui, app, on_toggle_mute, |a, u| { toggle_mute(a, u); });
    hook!(ui, app, on_request_menu, |a, u, kind| {
        if kind == "record" { toggle_record(a, u); return; }
        let m = build_menu(a, u, &kind);
        u.set_menu_items(model(m));
    });
    hook!(ui, app, on_menu_activated, |a, u, id| { on_menu(a, u, &id); });
    hook!(ui, app, on_queue_clicked, |a, u, i| { start(a, u, i as usize); });
    hook!(ui, app, on_toggle_fullscreen, |a, u| { toggle_fullscreen(a, u); });
    hook!(ui, app, on_activity, |a, _u| { a.last_activity = Instant::now(); });
    hook!(ui, app, on_open_url, |a, u, url| {
        let s = url.trim().to_string();
        if !s.is_empty() { let s = if s.contains("://") { s } else { format!("http://{}", s) }; open_paths(a, u, vec![s]); }
    });
    hook!(ui, app, on_settings_row_toggled, |a, u, i| {
        if let Some(k) = a.row_defs.get(i as usize).copied() { cycle_setting(a, u, k); build_rows(a, u); }
    });
    hook!(ui, app, on_settings_search, |a, u, q| { a.settings_query = q.to_string(); build_rows(a, u); });
    hook!(ui, app, on_settings_page_changed, |a, u| { build_rows(a, u); });
    hook!(ui, app, on_appearance_changed, |a, u| {
        a.store.theme_index = u.get_theme_index();
        a.store.accent_index = u.get_accent_index();
        a.store.save();
    });
    hook!(ui, app, on_tune_tab_changed, |a, u| { tune::refresh_tab(a, u); });
    hook!(ui, app, on_param_changed, |a, u, i, v| { tune::param_changed(a, u, i, v); });
    hook!(ui, app, on_param_action, |a, u, i| { tune::param_action(a, u, i); });
    hook!(ui, app, on_eq_toggle, |a, u| { tune::eq_toggle(a, u); });
    hook!(ui, app, on_eq_preset_next, |a, u| { tune::eq_preset_next(a, u); });
    hook!(ui, app, on_eq_band_changed, |a, u, i, v| { tune::eq_band_changed(a, u, i, v); });
    hook!(ui, app, on_eq_reset, |a, u| { tune::eq_reset(a, u); });
    hook!(ui, app, on_create_playlist, |a, u| { create_playlist(a, u); });
    hook!(ui, app, on_quit_app, |a, _u| { shutdown(a); let _ = slint::quit_event_loop(); });

    // open file passed on the command line (file association / "Open with")
    if let Some(arg) = std::env::args().nth(1) {
        let mut a = app.borrow_mut();
        if a.host.is_some() || !cfg!(windows) { open_paths(&mut a, &ui, vec![arg]); } else { a.pending_open = Some(vec![arg]); }
    }

    // 60 Hz pump: frames from libvlc -> Slint image, plus clock / state sync every ~100 ms
    let timer = Timer::default();
    {
        let app = app.clone();
        let weak = ui.as_weak();
        let mut n: u32 = 0;
        timer.start(TimerMode::Repeated, Duration::from_millis(25), move || {
            n = n.wrapping_add(1);
            if let (Some(ui), Ok(mut a)) = (weak.upgrade(), app.try_borrow_mut()) { tick(&mut a, &ui, n); }
        });
    }

    ui.run().expect("run");

    {
        let mut a = app.borrow_mut();
        shutdown(&mut a);
        a.player = None;
        a.vlc = None;
        a.host = None;
    }
    drop(timer);
    platform::set_playing(false);
    platform::shutdown();
}
