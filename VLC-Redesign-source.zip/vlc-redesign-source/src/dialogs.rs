//! Native file dialogs. Windows uses the system dialogs (rfd); the Linux dev build shells out to zenity.

use std::path::PathBuf;

#[cfg(windows)]
pub fn pick_files(title: &str, name: &str, exts: &[&str]) -> Vec<String> {
    rfd::FileDialog::new().set_title(title).add_filter(name, exts).add_filter("All files", &["*"]).pick_files()
        .map(|v| v.into_iter().map(|p| p.to_string_lossy().into_owned()).collect()).unwrap_or_default()
}
#[cfg(windows)]
pub fn pick_file(name: &str, exts: &[&str]) -> Option<PathBuf> { rfd::FileDialog::new().add_filter(name, exts).pick_file() }
#[cfg(windows)]
pub fn pick_folder(title: &str) -> Option<PathBuf> { rfd::FileDialog::new().set_title(title).pick_folder() }

#[cfg(not(windows))]
fn zenity(args: &[&str]) -> Vec<String> {
    std::process::Command::new("zenity").args(args).output().ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().split('|').filter(|s| !s.is_empty()).map(String::from).collect())
        .unwrap_or_default()
}
#[cfg(not(windows))]
pub fn pick_files(title: &str, _name: &str, _exts: &[&str]) -> Vec<String> { zenity(&["--file-selection", "--multiple", "--title", title]) }
#[cfg(not(windows))]
pub fn pick_file(_name: &str, _exts: &[&str]) -> Option<PathBuf> { zenity(&["--file-selection"]).into_iter().next().map(PathBuf::from) }
#[cfg(not(windows))]
pub fn pick_folder(title: &str) -> Option<PathBuf> { zenity(&["--file-selection", "--directory", "--title", title]).into_iter().next().map(PathBuf::from) }
