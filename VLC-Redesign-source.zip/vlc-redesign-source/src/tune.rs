//! Playback tuning panel (Playback / Video / Audio / Subtitles tabs) and the 10-band equalizer.
//!
//! Everything here drives *libvlc's own* filters: video adjust (brightness/contrast/...), audio / subtitle delay,
//! playback rate, the 10-band equalizer (live) and the VLC `compressor` audio filter (applied per item).

use crate::vlc::EqParams;
use crate::{build_rows, on_menu, toast, App, EqBand, MainWindow, Param};
use slint::{Model, ModelRc, VecModel};
use std::collections::BTreeMap;
use std::rc::Rc;

const EQ_LABELS: [&str; 11] = ["Preamp", "60 Hz", "170 Hz", "310 Hz", "600 Hz", "1 KHz", "3 KHz", "6 KHz", "12 KHz", "14 KHz", "16 KHz"];
const KEYS: [&str; 15] = ["bright", "contrast", "sat", "hue", "gamma", "adelay", "sdelay", "c0", "c1", "c2", "c3", "c4", "c5", "c6", "speed"];

pub struct TuneState {
    pub vals: BTreeMap<&'static str, f32>,
    pub comp_on: bool,
    pub eq_on: bool,
    pub eq_preamp: f32,
    pub eq_bands: [f32; 10],
    /// -1 = custom curve
    pub eq_preset: i32,
    pub eq_names: Vec<String>,
    pub model: Rc<VecModel<Param>>,
    pub eq_model: Rc<VecModel<EqBand>>,
}

impl TuneState {
    pub fn new() -> Self {
        TuneState {
            vals: BTreeMap::new(),
            comp_on: false,
            eq_on: false,
            eq_preamp: 0.0,
            eq_bands: [0.0; 10],
            eq_preset: -1,
            eq_names: vec![],
            model: Rc::new(VecModel::default()),
            eq_model: Rc::new(VecModel::default()),
        }
    }
}

/// (min, max, default)
fn range(id: &str) -> Option<(f32, f32, f32)> {
    Some(match id {
        "speed" => (0.25, 4.0, 1.0),
        "bright" => (0.0, 2.0, 1.0),
        "contrast" => (0.0, 2.0, 1.0),
        "sat" => (0.0, 3.0, 1.0),
        "hue" => (-180.0, 180.0, 0.0),
        "gamma" => (0.1, 3.0, 1.0),
        "adelay" | "sdelay" => (-10.0, 10.0, 0.0),
        "c0" => (0.0, 1.0, 0.2),
        "c1" => (1.5, 400.0, 25.0),
        "c2" => (2.0, 800.0, 100.0),
        "c3" => (-30.0, 0.0, -11.0),
        "c4" => (1.0, 20.0, 8.0),
        "c5" => (1.0, 10.0, 2.5),
        "c6" => (0.0, 24.0, 7.0),
        _ => return None,
    })
}

fn fmt(id: &str, v: f32) -> String {
    match id {
        "speed" => format!("{:.2}x", v),
        "hue" => format!("{:.0}°", v),
        "adelay" | "sdelay" => format!("{:+.3} s", v),
        "c0" => format!("{:.2}", v),
        "c1" | "c2" => format!("{:.1} ms", v),
        "c3" | "c5" | "c6" => format!("{:.1} dB", v),
        "c4" => format!("{:.1} : 1", v),
        _ => format!("{:.2}", v),
    }
}

fn val(app: &App, id: &str) -> f32 {
    if id == "speed" { return app.speed; }
    let d = range(id).map(|r| r.2).unwrap_or(0.0);
    app.tune.vals.iter().find(|(k, _)| **k == id).map(|(_, v)| *v).unwrap_or(d)
}

fn set_val(app: &mut App, id: &str, v: f32) {
    if id == "speed" { app.speed = v; }
    if let Some(key) = KEYS.iter().find(|k| **k == id) { app.tune.vals.insert(key, v); }
}

fn hdr(label: &str) -> Param { Param { id: "".into(), label: label.into(), text: "".into(), norm: 0.0, kind: 1 } }
fn note(label: &str) -> Param { Param { id: "".into(), label: label.into(), text: "".into(), norm: 0.0, kind: 4 } }
fn act(id: &str, label: &str, text: &str) -> Param { Param { id: id.into(), label: label.into(), text: text.into(), norm: 0.0, kind: 2 } }
fn tg(id: &str, label: &str, on: bool) -> Param { Param { id: id.into(), label: label.into(), text: if on { "on" } else { "off" }.into(), norm: 0.0, kind: 3 } }
fn sl(app: &App, id: &str, label: &str) -> Param {
    let (mn, mx, _) = range(id).unwrap_or((0.0, 1.0, 0.0));
    let v = val(app, id);
    Param { id: id.into(), label: label.into(), text: fmt(id, v).into(), norm: ((v - mn) / (mx - mn)).clamp(0.0, 1.0), kind: 0 }
}

fn rows(app: &App, ui: &MainWindow, tab: i32) -> Vec<Param> {
    match tab {
        0 => vec![
            hdr("Speed"),
            sl(app, "speed", "Playback speed"),
            act("speed_reset", "Reset speed", "1.00x"),
            hdr("Behaviour"),
            act("seek_step", "Jump size (arrow keys)", &app.store.get("seek_step")),
            act("repeat", "Repeat", &app.store.get("repeat")),
            tg("autoplay_next", "Play next item automatically", app.store.on("autoplay_next")),
        ],
        1 => vec![
            hdr("Adjustments"),
            sl(app, "bright", "Brightness"),
            sl(app, "contrast", "Contrast"),
            sl(app, "sat", "Saturation"),
            sl(app, "hue", "Hue"),
            sl(app, "gamma", "Gamma"),
            act("vreset", "Reset adjustments", ""),
            hdr("Display"),
            act("fit", "Video scaling", ["Fit", "Fill", "Stretch"][(ui.get_fit_mode().clamp(0, 2)) as usize]),
            act("snap", "Take snapshot", ""),
        ],
        2 => vec![
            hdr("Synchronization"),
            sl(app, "adelay", "Audio track delay"),
            hdr("Effects"),
            tg("eq", "Equalizer", app.tune.eq_on),
            act("eq_open", "Open 10-band equalizer", ""),
            hdr("Compressor"),
            tg("comp", "Dynamic range compressor", app.tune.comp_on),
            note("Compressor settings are handed to VLC's compressor filter and apply from the next item that starts."),
            sl(app, "c0", "RMS / Peak"),
            sl(app, "c1", "Attack"),
            sl(app, "c2", "Release"),
            sl(app, "c3", "Threshold"),
            sl(app, "c4", "Ratio"),
            sl(app, "c5", "Knee radius"),
            sl(app, "c6", "Makeup gain"),
        ],
        _ => {
            let cur = app.player.as_ref().map(|p| {
                let (tr, c) = p.sub_tracks();
                tr.into_iter().find(|(id, _)| *id == c).map(|(_, n)| n).unwrap_or_else(|| "None".into())
            }).unwrap_or_else(|| "None".into());
            vec![
                hdr("Defaults"),
                act("strack", "Subtitle track (click to cycle)", &cur),
                act("sub_add", "Add subtitle file...", ""),
                hdr("Synchronization"),
                sl(app, "sdelay", "Subtitle track delay"),
                note("Positive values show subtitles later, negative values earlier."),
            ]
        }
    }
}

pub fn init(app: &mut App, ui: &MainWindow) {
    ui.set_tune_params(ModelRc::from(app.tune.model.clone()));
    ui.set_eq_bands(ModelRc::from(app.tune.eq_model.clone()));
    if let Some(v) = app.vlc.as_ref() { app.tune.eq_names = v.eq_presets(); }
    // restore equalizer
    app.tune.eq_on = app.store.on("eq_on");
    app.tune.eq_preset = app.store.settings.get("eq_preset").and_then(|s| s.parse().ok()).unwrap_or(-1);
    if let Some(vals) = app.store.settings.get("eq_vals") {
        let v: Vec<f32> = vals.split(',').filter_map(|x| x.parse().ok()).collect();
        if v.len() == 11 { app.tune.eq_preamp = v[0]; app.tune.eq_bands.copy_from_slice(&v[1..]); }
    }
    app.tune.comp_on = app.store.on("comp_on");
    eq_apply(app);
    eq_refresh(app, ui);
    refresh_tab(app, ui);
}

pub fn refresh_tab(app: &mut App, ui: &MainWindow) {
    let r = rows(app, ui, ui.get_tune_tab());
    app.tune.model.set_vec(r);
}

pub fn param_changed(app: &mut App, _ui: &MainWindow, i: i32, norm: f32) {
    let Some(row) = app.tune.model.row_data(i as usize) else { return };
    let id = row.id.to_string();
    let Some((mn, mx, _)) = range(&id) else { return };
    let mut v = mn + norm.clamp(0.0, 1.0) * (mx - mn);
    v = match id.as_str() {
        "speed" => (v / 0.05).round() * 0.05,
        "hue" => v.round(),
        "adelay" | "sdelay" => (v * 20.0).round() / 20.0,
        "c1" | "c2" => v.round(),
        _ => (v * 100.0).round() / 100.0,
    }.clamp(mn, mx);
    set_val(app, &id, v);
    apply(app, &id);
    app.tune.model.set_row_data(i as usize, Param { text: fmt(&id, v).into(), norm: ((v - mn) / (mx - mn)).clamp(0.0, 1.0), ..row });
}

pub fn param_action(app: &mut App, ui: &MainWindow, i: i32) {
    let Some(row) = app.tune.model.row_data(i as usize) else { return };
    match row.id.as_str() {
        "speed_reset" => { set_val(app, "speed", 1.0); apply(app, "speed"); }
        "seek_step" | "repeat" | "autoplay_next" => crate::cycle_setting(app, ui, &row.id),
        "vreset" => {
            for k in ["bright", "contrast", "sat", "hue", "gamma"] { set_val(app, k, range(k).unwrap().2); }
            if let Some(p) = app.player.as_ref() { p.adjust_off(); }
        }
        "fit" => { let n = (ui.get_fit_mode() + 1) % 3; on_menu(app, ui, &format!("fit:{}", n)); }
        "snap" => on_menu(app, ui, "snapshot"),
        "eq" => { eq_toggle(app, ui); }
        "eq_open" => { ui.set_settings_page("Audio".into()); ui.set_settings_open(true); build_rows(app, ui); }
        "comp" => {
            app.tune.comp_on = !app.tune.comp_on;
            app.store.settings.insert("comp_on".into(), if app.tune.comp_on { "on" } else { "off" }.into());
            app.store.save();
            toast(app, ui, "Compressor applies from the next item");
        }
        "strack" => {
            if let Some(p) = app.player.as_ref() {
                let (tr, cur) = p.sub_tracks();
                if !tr.is_empty() {
                    let pos = tr.iter().position(|(id, _)| *id == cur).unwrap_or(0);
                    p.set_sub_track(tr[(pos + 1) % tr.len()].0);
                }
            }
        }
        "sub_add" => on_menu(app, ui, "subs:add"),
        _ => {}
    }
    refresh_tab(app, ui);
}

/// Push one tuned value into libvlc.
pub fn apply(app: &mut App, id: &str) {
    let v = val(app, id);
    let Some(p) = app.player.as_ref() else { return };
    match id {
        "speed" => p.set_rate(v),
        "contrast" => p.set_adjust(1, v),
        "bright" => p.set_adjust(2, v),
        "hue" => p.set_adjust(3, v),
        "sat" => p.set_adjust(4, v),
        "gamma" => p.set_adjust(5, v),
        "adelay" => p.set_audio_delay_ms((v * 1000.0) as i64),
        "sdelay" => p.set_sub_delay_ms((v * 1000.0) as i64),
        _ => {}
    }
}

/// Re-apply every non-default tuned value (called when a new item starts).
pub fn apply_all(app: &mut App) {
    for id in ["bright", "contrast", "sat", "hue", "gamma", "adelay", "sdelay"] {
        let (v, d) = (val(app, id), range(id).unwrap().2);
        if (v - d).abs() > 1e-4 { apply(app, id); }
    }
}

/// Media options for the VLC compressor filter (per item).
pub fn media_options(app: &App) -> Vec<String> {
    if !app.tune.comp_on { return vec![]; }
    let g = |id: &str| val(app, id);
    vec![
        ":audio-filter=compressor".into(),
        format!(":compressor-rms-peak={:.2}", g("c0")),
        format!(":compressor-attack={:.1}", g("c1")),
        format!(":compressor-release={:.1}", g("c2")),
        format!(":compressor-threshold={:.1}", g("c3")),
        format!(":compressor-ratio={:.1}", g("c4")),
        format!(":compressor-knee={:.1}", g("c5")),
        format!(":compressor-makeup-gain={:.1}", g("c6")),
    ]
}

// ------------------------------------------------------------------ equalizer

pub fn eq_apply(app: &mut App) {
    let params = if app.tune.eq_on { Some(EqParams { preamp: app.tune.eq_preamp, bands: app.tune.eq_bands }) } else { None };
    if let Some(p) = app.player.as_mut() { p.set_eq(params); }
}

fn eq_save(app: &mut App) {
    let mut v = vec![app.tune.eq_preamp];
    v.extend_from_slice(&app.tune.eq_bands);
    app.store.settings.insert("eq_vals".into(), v.iter().map(|x| format!("{:.1}", x)).collect::<Vec<_>>().join(","));
    app.store.settings.insert("eq_on".into(), if app.tune.eq_on { "on" } else { "off" }.into());
    app.store.settings.insert("eq_preset".into(), app.tune.eq_preset.to_string());
    app.store.save();
}

pub fn eq_refresh(app: &mut App, ui: &MainWindow) {
    let t = &app.tune;
    let mut bands = vec![];
    for i in 0..11 {
        let db = if i == 0 { t.eq_preamp } else { t.eq_bands[i - 1] };
        bands.push(EqBand { label: EQ_LABELS[i].into(), text: format!("{:.1} dB", db).into(), norm: ((db + 20.0) / 40.0).clamp(0.0, 1.0) });
    }
    t.eq_model.set_vec(bands);
    ui.set_eq_on(t.eq_on);
    let name = if t.eq_preset >= 0 { t.eq_names.get(t.eq_preset as usize).cloned().unwrap_or_default() } else if t.eq_on { "Custom".into() } else { "None".into() };
    ui.set_eq_preset_name(name.into());
}

pub fn eq_toggle(app: &mut App, ui: &MainWindow) {
    app.tune.eq_on = !app.tune.eq_on;
    eq_apply(app);
    eq_save(app);
    eq_refresh(app, ui);
}

pub fn eq_preset_next(app: &mut App, ui: &MainWindow) {
    let n = app.tune.eq_names.len() as i32;
    if n == 0 { return; }
    let next = (app.tune.eq_preset + 1).rem_euclid(n);
    if let Some(pr) = app.player.as_ref().and_then(|p| p.eq_preset_params(next as u32)) {
        app.tune.eq_preset = next;
        app.tune.eq_preamp = pr.preamp;
        app.tune.eq_bands = pr.bands;
        app.tune.eq_on = true;
        eq_apply(app);
        eq_save(app);
        eq_refresh(app, ui);
    }
}

pub fn eq_band_changed(app: &mut App, ui: &MainWindow, i: i32, norm: f32) {
    let db = ((norm * 40.0 - 20.0) * 2.0).round() / 2.0;
    if i == 0 { app.tune.eq_preamp = db; } else if (1..=10).contains(&i) { app.tune.eq_bands[i as usize - 1] = db; } else { return; }
    let was_on = app.tune.eq_on;
    app.tune.eq_preset = -1;
    app.tune.eq_on = true;
    eq_apply(app);
    eq_save(app);
    app.tune.eq_model.set_row_data(i as usize, EqBand { label: EQ_LABELS[i as usize].into(), text: format!("{:.1} dB", db).into(), norm: ((db + 20.0) / 40.0).clamp(0.0, 1.0) });
    if !was_on { ui.set_eq_on(true); }
    ui.set_eq_preset_name("Custom".into());
}

pub fn eq_reset(app: &mut App, ui: &MainWindow) {
    app.tune.eq_preamp = 0.0;
    app.tune.eq_bands = [0.0; 10];
    app.tune.eq_preset = -1;
    eq_apply(app);
    eq_save(app);
    eq_refresh(app, ui);
}
