//! Minimal, dynamically-loaded libvlc (3.x) binding.
//!
//! The decoding / demuxing / audio / subtitle pipeline is **VLC's own engine**; this module only
//! drives it. libvlc.dll + libvlccore.dll + plugins/ are loaded at runtime from the app directory.

use libloading::Library;
use std::cell::UnsafeCell;
use std::ffi::{c_char, c_int, c_uint, c_void, CStr, CString};
use std::path::{Path, PathBuf};
use std::ptr;
use slint::{Rgba8Pixel, SharedPixelBuffer};
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering};
use std::sync::{Arc, Mutex, OnceLock};

/// Maximum width of frames handed to the UI (VLC scales on its own thread before delivery).
pub static MAX_FRAME_W: AtomicU32 = AtomicU32::new(1920);

#[repr(C)]
pub struct TrackDesc {
    pub id: c_int,
    pub name: *const c_char,
    pub next: *mut TrackDesc,
}

type P = *mut c_void;
type LockCb = unsafe extern "C" fn(P, *mut *mut c_void) -> P;
type UnlockCb = unsafe extern "C" fn(P, P, *const *mut c_void);
type DisplayCb = unsafe extern "C" fn(P, P);
type FormatCb = unsafe extern "C" fn(*mut P, *mut c_char, *mut c_uint, *mut c_uint, *mut c_uint, *mut c_uint) -> c_uint;
type CleanupCb = unsafe extern "C" fn(P);

macro_rules! api {
    ($($name:ident : $ty:ty = $sym:literal),* $(,)?) => {
        #[allow(dead_code)]
        pub struct Api { $(pub $name: $ty,)* _lib: Library }
        impl Api {
            unsafe fn bind(lib: Library) -> Result<Api, String> {
                $( let $name: $ty = *lib.get::<$ty>(concat!($sym, "\0").as_bytes())
                        .map_err(|e| format!("{}: {}", $sym, e))?; )*
                Ok(Api { $($name,)* _lib: lib })
            }
        }
    };
}

api! {
    new: unsafe extern "C" fn(c_int, *const *const c_char) -> P = "libvlc_new",
    release: unsafe extern "C" fn(P) = "libvlc_release",
    media_new_path: unsafe extern "C" fn(P, *const c_char) -> P = "libvlc_media_new_path",
    media_new_location: unsafe extern "C" fn(P, *const c_char) -> P = "libvlc_media_new_location",
    media_add_option: unsafe extern "C" fn(P, *const c_char) = "libvlc_media_add_option",
    media_release: unsafe extern "C" fn(P) = "libvlc_media_release",
    mp_new: unsafe extern "C" fn(P) -> P = "libvlc_media_player_new",
    mp_release: unsafe extern "C" fn(P) = "libvlc_media_player_release",
    mp_set_media: unsafe extern "C" fn(P, P) = "libvlc_media_player_set_media",
    mp_play: unsafe extern "C" fn(P) -> c_int = "libvlc_media_player_play",
    mp_set_pause: unsafe extern "C" fn(P, c_int) = "libvlc_media_player_set_pause",
    mp_stop: unsafe extern "C" fn(P) = "libvlc_media_player_stop",
    mp_get_state: unsafe extern "C" fn(P) -> c_int = "libvlc_media_player_get_state",
    mp_get_time: unsafe extern "C" fn(P) -> i64 = "libvlc_media_player_get_time",
    mp_set_time: unsafe extern "C" fn(P, i64) = "libvlc_media_player_set_time",
    mp_get_length: unsafe extern "C" fn(P) -> i64 = "libvlc_media_player_get_length",
    mp_get_position: unsafe extern "C" fn(P) -> f32 = "libvlc_media_player_get_position",
    mp_set_position: unsafe extern "C" fn(P, f32) = "libvlc_media_player_set_position",
    mp_set_rate: unsafe extern "C" fn(P, f32) -> c_int = "libvlc_media_player_set_rate",
    mp_has_vout: unsafe extern "C" fn(P) -> c_uint = "libvlc_media_player_has_vout",
    mp_set_equalizer: unsafe extern "C" fn(P, P) -> c_int = "libvlc_media_player_set_equalizer",
    video_set_callbacks: unsafe extern "C" fn(P, LockCb, UnlockCb, DisplayCb, P) = "libvlc_video_set_callbacks",
    video_set_format_callbacks: unsafe extern "C" fn(P, FormatCb, CleanupCb) = "libvlc_video_set_format_callbacks",
    video_take_snapshot: unsafe extern "C" fn(P, c_uint, *const c_char, c_uint, c_uint) -> c_int = "libvlc_video_take_snapshot",
    video_set_subtitle_file: unsafe extern "C" fn(P, *const c_char) -> c_int = "libvlc_video_set_subtitle_file",
    video_get_spu: unsafe extern "C" fn(P) -> c_int = "libvlc_video_get_spu",
    video_set_spu: unsafe extern "C" fn(P, c_int) -> c_int = "libvlc_video_set_spu",
    video_get_spu_description: unsafe extern "C" fn(P) -> *mut TrackDesc = "libvlc_video_get_spu_description",
    audio_get_track: unsafe extern "C" fn(P) -> c_int = "libvlc_audio_get_track",
    audio_set_track: unsafe extern "C" fn(P, c_int) -> c_int = "libvlc_audio_set_track",
    audio_get_track_description: unsafe extern "C" fn(P) -> *mut TrackDesc = "libvlc_audio_get_track_description",
    audio_get_volume: unsafe extern "C" fn(P) -> c_int = "libvlc_audio_get_volume",
    audio_set_volume: unsafe extern "C" fn(P, c_int) -> c_int = "libvlc_audio_set_volume",
    audio_set_mute: unsafe extern "C" fn(P, c_int) = "libvlc_audio_set_mute",
    track_desc_release: unsafe extern "C" fn(*mut TrackDesc) = "libvlc_track_description_list_release",
    eq_new_from_preset: unsafe extern "C" fn(c_uint) -> P = "libvlc_audio_equalizer_new_from_preset",
    eq_release: unsafe extern "C" fn(P) = "libvlc_audio_equalizer_release",
    eq_preset_count: unsafe extern "C" fn() -> c_uint = "libvlc_audio_equalizer_get_preset_count",
    eq_preset_name: unsafe extern "C" fn(c_uint) -> *const c_char = "libvlc_audio_equalizer_get_preset_name",
    audio_set_delay: unsafe extern "C" fn(P, i64) -> c_int = "libvlc_audio_set_delay",
    spu_set_delay: unsafe extern "C" fn(P, i64) -> c_int = "libvlc_video_set_spu_delay",
    adjust_int: unsafe extern "C" fn(P, c_uint, c_int) = "libvlc_video_set_adjust_int",
    adjust_float: unsafe extern "C" fn(P, c_uint, f32) = "libvlc_video_set_adjust_float",
    eq_new: unsafe extern "C" fn() -> P = "libvlc_audio_equalizer_new",
    eq_set_preamp: unsafe extern "C" fn(P, f32) -> c_int = "libvlc_audio_equalizer_set_preamp",
    eq_get_preamp: unsafe extern "C" fn(P) -> f32 = "libvlc_audio_equalizer_get_preamp",
    eq_set_amp: unsafe extern "C" fn(P, f32, c_uint) -> c_int = "libvlc_audio_equalizer_set_amp_at_index",
    eq_get_amp: unsafe extern "C" fn(P, c_uint) -> f32 = "libvlc_audio_equalizer_get_amp_at_index",
    get_version: unsafe extern "C" fn() -> *const c_char = "libvlc_get_version",
}

fn lib_names() -> &'static [&'static str] {
    if cfg!(windows) { &["libvlc.dll"] } else if cfg!(target_os = "macos") { &["libvlc.dylib"] } else { &["libvlc.so.5", "libvlc.so"] }
}

/// Directories searched for libvlc (+ its `plugins/` folder).
pub fn candidate_dirs() -> Vec<PathBuf> {
    let mut v = Vec::new();
    if let Ok(exe) = std::env::current_exe() {
        if let Some(d) = exe.parent() { v.push(d.to_path_buf()); v.push(d.join("vlc")); }
    }
    if let Ok(d) = std::env::var("VLC_DIR") { v.push(PathBuf::from(d)); }
    for pf in ["ProgramFiles", "ProgramFiles(x86)"] {
        if let Ok(p) = std::env::var(pf) { v.push(Path::new(&p).join("VideoLAN").join("VLC")); }
    }
    v
}

unsafe fn open_lib(path: &Path) -> Result<Library, libloading::Error> {
    #[cfg(windows)]
    {
        use libloading::os::windows::{Library as WinLib, LOAD_WITH_ALTERED_SEARCH_PATH};
        WinLib::load_with_flags(path, LOAD_WITH_ALTERED_SEARCH_PATH).map(Library::from)
    }
    #[cfg(not(windows))]
    { Library::new(path) }
}

pub struct Vlc {
    pub api: Arc<Api>,
    inst: P,
    pub version: String,
}

impl Vlc {
    pub fn load(args: &[String]) -> Result<Vlc, String> {
        let mut last_err = String::from("libvlc not found");
        for dir in candidate_dirs() {
            for name in lib_names() {
                let p = dir.join(name);
                if !p.exists() { continue; }
                let plugins = dir.join("plugins");
                if plugins.exists() { std::env::set_var("VLC_PLUGIN_PATH", &plugins); }
                unsafe {
                    match open_lib(&p).map_err(|e| e.to_string()).and_then(|l| Api::bind(l)) {
                        Ok(api) => return Self::init(api, args),
                        Err(e) => last_err = format!("{}: {}", p.display(), e),
                    }
                }
            }
        }
        // system-wide fallback (Linux/macOS dev machines)
        unsafe {
            for name in lib_names() {
                if let Ok(l) = Library::new(name) {
                    if let Ok(api) = Api::bind(l) { return Self::init(api, args); }
                }
            }
        }
        Err(format!("{last_err}. Put libvlc.dll, libvlccore.dll and the plugins folder next to the executable."))
    }

    fn init(api: Api, args: &[String]) -> Result<Vlc, String> {
        let cargs: Vec<CString> = args.iter().filter_map(|a| CString::new(a.as_str()).ok()).collect();
        let ptrs: Vec<*const c_char> = cargs.iter().map(|c| c.as_ptr()).collect();
        let inst = unsafe { (api.new)(ptrs.len() as c_int, ptrs.as_ptr()) };
        if inst.is_null() { return Err("libvlc_new failed (plugins folder missing?)".into()); }
        let version = unsafe { CStr::from_ptr((api.get_version)()).to_string_lossy().into_owned() };
        Ok(Vlc { api: Arc::new(api), inst, version })
    }

    pub fn eq_presets(&self) -> Vec<String> {
        unsafe {
            let n = (self.api.eq_preset_count)();
            (0..n).map(|i| CStr::from_ptr((self.api.eq_preset_name)(i)).to_string_lossy().into_owned()).collect()
        }
    }

    pub fn new_player(&self) -> Player {
        let mp = unsafe { (self.api.mp_new)(self.inst) };
        let sink = Arc::new(Sink::default());
        unsafe {
            // keep one strong ref alive for the lifetime of the player (released in Drop)
            let raw = Arc::into_raw(sink.clone()) as P;
            (self.api.video_set_callbacks)(mp, cb_lock, cb_unlock, cb_display, raw);
            (self.api.video_set_format_callbacks)(mp, cb_setup, cb_cleanup);
            Player { api: self.api.clone(), inst: self.inst, mp, sink, raw, eq: ptr::null_mut() }
        }
    }
}

impl Drop for Vlc {
    fn drop(&mut self) { unsafe { (self.api.release)(self.inst) } }
}

// ---------------------------------------------------------------- video sink (frame hand-off)
//
// Pipeline (no polling, no extra copies):
//   libvlc vout thread --lock()--> decodes straight into a fresh SharedPixelBuffer (RGBA)
//                      --display()--> buffer is *moved* into `front`, UI thread is woken once
//   UI thread (vsync-throttled by Slint) --take_frame()--> Image::from_rgba8(buffer) -> GPU texture
// The wake-up is coalesced: while the UI has not consumed the previous frame no further wake-ups are
// queued, and a newer frame simply replaces the older one (late frames are dropped, never queued).

type Pix = SharedPixelBuffer<Rgba8Pixel>;

#[derive(Default)]
pub struct Sink {
    front: Mutex<Option<Pix>>,
    decode: UnsafeCell<Option<Pix>>,
    pending: AtomicBool,
    pub has_video: AtomicBool,
    pub generation: AtomicU32,
    pub frames: AtomicU64,
    pub notify: OnceLock<Arc<dyn Fn() + Send + Sync>>,
}
unsafe impl Sync for Sink {}
unsafe impl Send for Sink {}

unsafe extern "C" fn cb_setup(opaque: *mut P, chroma: *mut c_char, w: *mut c_uint, h: *mut c_uint, pitches: *mut c_uint, lines: *mut c_uint) -> c_uint {
    let sink = &*(*opaque as *const Sink);
    let (mut ww, mut hh) = (*w, *h);
    let max_w = MAX_FRAME_W.load(Ordering::Relaxed).max(320);
    if ww > max_w {
        hh = (hh as u64 * max_w as u64 / ww as u64) as u32;
        ww = max_w;
    }
    ww &= !1;
    hh &= !1;
    if ww == 0 || hh == 0 { return 0; }
    ptr::copy_nonoverlapping(b"RGBA".as_ptr(), chroma as *mut u8, 4);
    *w = ww;
    *h = hh;
    *pitches = ww * 4;
    *lines = hh;
    *sink.decode.get() = Some(Pix::new(ww, hh));
    *sink.front.lock().unwrap_or_else(|e| e.into_inner()) = None;
    sink.generation.fetch_add(1, Ordering::Relaxed);
    sink.has_video.store(true, Ordering::Relaxed);
    1
}
unsafe extern "C" fn cb_cleanup(_: P) {}
unsafe extern "C" fn cb_lock(opaque: P, planes: *mut *mut c_void) -> P {
    let sink = &*(opaque as *const Sink);
    match (*sink.decode.get()).as_mut() {
        Some(b) => { *planes = b.make_mut_bytes().as_mut_ptr() as *mut c_void; }
        None => { *planes = ptr::null_mut(); }
    }
    ptr::null_mut()
}
unsafe extern "C" fn cb_unlock(_: P, _: P, _: *const *mut c_void) {}
unsafe extern "C" fn cb_display(opaque: P, _: P) {
    let sink = &*(opaque as *const Sink);
    let slot = &mut *sink.decode.get();
    let Some(done) = slot.take() else { return };
    // the next frame is decoded into a brand-new buffer; the finished one is moved (not copied) to the UI
    *slot = Some(Pix::new(done.width(), done.height()));
    *sink.front.lock().unwrap_or_else(|e| e.into_inner()) = Some(done);
    sink.frames.fetch_add(1, Ordering::Relaxed);
    if !sink.pending.swap(true, Ordering::AcqRel) {
        if let Some(n) = sink.notify.get() { n(); }
    }
}

// ---------------------------------------------------------------- player

pub struct Player {
    api: Arc<Api>,
    inst: P,
    mp: P,
    sink: Arc<Sink>,
    raw: P,
    eq: P,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum State { Idle, Opening, Buffering, Playing, Paused, Stopped, Ended, Error }

/// Equalizer description handed to libvlc (10 bands + preamp, dB).
#[derive(Clone, Copy)]
pub struct EqParams { pub preamp: f32, pub bands: [f32; 10] }

impl Player {
    fn media(&self, target: &str, options: &[String]) -> P {
        let c = CString::new(target).unwrap_or_default();
        unsafe {
            let m = if target.contains("://") { (self.api.media_new_location)(self.inst, c.as_ptr()) } else { (self.api.media_new_path)(self.inst, c.as_ptr()) };
            for o in options {
                if let Ok(oc) = CString::new(o.as_str()) { (self.api.media_add_option)(m, oc.as_ptr()); }
            }
            m
        }
    }

    pub fn play(&mut self, target: &str, options: &[String]) -> bool {
        self.sink.has_video.store(false, Ordering::Relaxed);
        unsafe {
            let m = self.media(target, options);
            if m.is_null() { return false; }
            (self.api.mp_set_media)(self.mp, m);
            (self.api.media_release)(m);
            (self.api.mp_play)(self.mp) == 0
        }
    }
    pub fn toggle_pause(&self) {
        unsafe {
            match self.state() {
                State::Playing => (self.api.mp_set_pause)(self.mp, 1),
                State::Paused => (self.api.mp_set_pause)(self.mp, 0),
                _ => { (self.api.mp_play)(self.mp); }
            }
        }
    }
    pub fn stop(&self) { unsafe { (self.api.mp_stop)(self.mp) }; self.sink.has_video.store(false, Ordering::Relaxed); }
    pub fn state(&self) -> State {
        match unsafe { (self.api.mp_get_state)(self.mp) } {
            1 => State::Opening, 2 => State::Buffering, 3 => State::Playing, 4 => State::Paused,
            5 => State::Stopped, 6 => State::Ended, 7 => State::Error, _ => State::Idle,
        }
    }
    pub fn time_ms(&self) -> i64 { unsafe { (self.api.mp_get_time)(self.mp) } }
    pub fn length_ms(&self) -> i64 { unsafe { (self.api.mp_get_length)(self.mp) } }
    pub fn position(&self) -> f32 { unsafe { (self.api.mp_get_position)(self.mp) } }
    pub fn set_position(&self, p: f32) { unsafe { (self.api.mp_set_position)(self.mp, p.clamp(0.0, 1.0)) } }
    pub fn seek_by_ms(&self, delta: i64) {
        let t = (self.time_ms() + delta).max(0);
        let len = self.length_ms();
        unsafe { (self.api.mp_set_time)(self.mp, if len > 0 { t.min(len - 500) } else { t }) }
    }
    pub fn set_rate(&self, r: f32) { unsafe { (self.api.mp_set_rate)(self.mp, r); } }
    pub fn set_volume(&self, pct: i32) { unsafe { (self.api.audio_set_volume)(self.mp, pct.clamp(0, 200)); } }
    pub fn set_mute(&self, m: bool) { unsafe { (self.api.audio_set_mute)(self.mp, m as c_int) } }
    pub fn has_video(&self) -> bool { self.sink.has_video.load(Ordering::Relaxed) && unsafe { (self.api.mp_has_vout)(self.mp) } > 0 }

    /// Register the wake-up used by the vout thread when a new frame is ready (called at most once per consumed frame).
    pub fn set_frame_notify(&self, f: Arc<dyn Fn() + Send + Sync>) { let _ = self.sink.notify.set(f); }
    /// Take the newest decoded frame (moved out, no copy). Re-arms the wake-up.
    pub fn take_frame(&self) -> Option<Pix> {
        self.sink.pending.store(false, Ordering::Release);
        self.sink.front.lock().unwrap_or_else(|e| e.into_inner()).take()
    }
    pub fn frames_decoded(&self) -> u64 { self.sink.frames.load(Ordering::Relaxed) }
    pub fn set_audio_delay_ms(&self, ms: i64) { unsafe { (self.api.audio_set_delay)(self.mp, ms * 1000); } }
    pub fn set_sub_delay_ms(&self, ms: i64) { unsafe { (self.api.spu_set_delay)(self.mp, ms * 1000); } }
    /// libvlc video adjust: 1 contrast, 2 brightness, 3 hue, 4 saturation, 5 gamma (0 = enable).
    pub fn set_adjust(&self, opt: u32, v: f32) {
        unsafe {
            (self.api.adjust_int)(self.mp, 0, 1);
            if opt == 3 { (self.api.adjust_int)(self.mp, 3, v as c_int) } else { (self.api.adjust_float)(self.mp, opt, v) }
        }
    }
    pub fn adjust_off(&self) { unsafe { (self.api.adjust_int)(self.mp, 0, 0) } }
    pub fn eq_preset_params(&self, preset: u32) -> Option<EqParams> {
        unsafe {
            let eq = (self.api.eq_new_from_preset)(preset);
            if eq.is_null() { return None; }
            let mut p = EqParams { preamp: (self.api.eq_get_preamp)(eq), bands: [0.0; 10] };
            for i in 0..10 { p.bands[i] = (self.api.eq_get_amp)(eq, i as c_uint); }
            (self.api.eq_release)(eq);
            Some(p)
        }
    }
    /// `None` disables the equalizer, `Some(params)` applies a 10-band curve (live, no restart).
    pub fn set_eq(&mut self, params: Option<EqParams>) {
        unsafe {
            match params {
                None => { (self.api.mp_set_equalizer)(self.mp, ptr::null_mut()); }
                Some(pr) => {
                    let eq = (self.api.eq_new)();
                    if eq.is_null() { return; }
                    (self.api.eq_set_preamp)(eq, pr.preamp.clamp(-20.0, 20.0));
                    for (i, b) in pr.bands.iter().enumerate() { (self.api.eq_set_amp)(eq, b.clamp(-20.0, 20.0), i as c_uint); }
                    (self.api.mp_set_equalizer)(self.mp, eq);
                    if !self.eq.is_null() { (self.api.eq_release)(self.eq); }
                    self.eq = eq;
                }
            }
        }
    }

    unsafe fn list(&self, head: *mut TrackDesc) -> Vec<(i32, String)> {
        let mut out = Vec::new();
        let mut p = head;
        while !p.is_null() {
            let name = if (*p).name.is_null() { String::new() } else { CStr::from_ptr((*p).name).to_string_lossy().into_owned() };
            out.push(((*p).id, name));
            p = (*p).next;
        }
        if !head.is_null() { (self.api.track_desc_release)(head); }
        out
    }
    pub fn audio_tracks(&self) -> (Vec<(i32, String)>, i32) {
        unsafe { (self.list((self.api.audio_get_track_description)(self.mp)), (self.api.audio_get_track)(self.mp)) }
    }
    pub fn sub_tracks(&self) -> (Vec<(i32, String)>, i32) {
        unsafe { (self.list((self.api.video_get_spu_description)(self.mp)), (self.api.video_get_spu)(self.mp)) }
    }
    pub fn set_audio_track(&self, id: i32) { unsafe { (self.api.audio_set_track)(self.mp, id); } }
    pub fn set_sub_track(&self, id: i32) { unsafe { (self.api.video_set_spu)(self.mp, id); } }
    pub fn add_subtitle(&self, path: &str) -> bool {
        let c = CString::new(path).unwrap_or_default();
        unsafe { (self.api.video_set_subtitle_file)(self.mp, c.as_ptr()) != 0 }
    }
    pub fn snapshot(&self, path: &str) -> bool {
        let c = CString::new(path).unwrap_or_default();
        unsafe { (self.api.video_take_snapshot)(self.mp, 0, c.as_ptr(), 0, 0) == 0 }
    }
}

impl Drop for Player {
    fn drop(&mut self) {
        unsafe {
            (self.api.mp_stop)(self.mp);
            (self.api.mp_release)(self.mp);
            if !self.eq.is_null() { (self.api.eq_release)(self.eq); }
            drop(Arc::from_raw(self.raw as *const Sink));
        }
    }
}
