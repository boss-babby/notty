//! OS-level tuning that matters for smooth A/V playback.
//!
//! * Windows' default timer granularity is ~15.6 ms. Without `timeBeginPeriod(1)` every sleep / wait in the
//!   process (libvlc's clock threads, the UI frame timer, WASAPI wake-ups) is rounded to 15.6 ms steps, which shows
//!   up as judder and as audio buffer under-runs (crackles) under load.
//! * The process is moved to ABOVE_NORMAL priority and the UI thread registers with MMCSS ("Playback") so the
//!   scheduler keeps decode/audio threads from being starved by background work.
//! * Power throttling (EcoQoS) is disabled so the player is not pushed to efficiency cores on hybrid CPUs.

#[cfg(windows)]
mod imp {
    use std::ffi::c_void;
    #[link(name = "winmm")]
    extern "system" {
        fn timeBeginPeriod(ms: u32) -> u32;
        fn timeEndPeriod(ms: u32) -> u32;
    }
    #[link(name = "kernel32")]
    extern "system" {
        fn GetCurrentProcess() -> *mut c_void;
        fn SetPriorityClass(h: *mut c_void, class: u32) -> i32;
        fn SetProcessInformation(h: *mut c_void, class: i32, info: *const c_void, size: u32) -> i32;
        fn SetThreadExecutionState(flags: u32) -> u32;
    }
    #[link(name = "avrt")]
    extern "system" {
        fn AvSetMmThreadCharacteristicsW(task: *const u16, index: *mut u32) -> *mut c_void;
    }
    #[repr(C)]
    struct PowerThrottling { version: u32, control_mask: u32, state_mask: u32 }

    pub fn init() {
        unsafe {
            timeBeginPeriod(1);
            let me = GetCurrentProcess();
            SetPriorityClass(me, 0x0000_8000); // ABOVE_NORMAL_PRIORITY_CLASS
            // PROCESS_POWER_THROTTLING_EXECUTION_SPEED = 1, ProcessPowerThrottling = 4: opt out of EcoQoS
            let pt = PowerThrottling { version: 1, control_mask: 1, state_mask: 0 };
            SetProcessInformation(me, 4, &pt as *const _ as *const c_void, std::mem::size_of::<PowerThrottling>() as u32);
            let task: Vec<u16> = "Playback\0".encode_utf16().collect();
            let mut idx = 0u32;
            AvSetMmThreadCharacteristicsW(task.as_ptr(), &mut idx);
        }
    }
    pub fn set_playing(playing: bool) {
        // ES_CONTINUOUS | ES_DISPLAY_REQUIRED | ES_SYSTEM_REQUIRED while playing: no screensaver / sleep during video
        unsafe { SetThreadExecutionState(if playing { 0x8000_0001 | 0x0000_0002 } else { 0x8000_0000 }); }
    }
    pub fn shutdown() { unsafe { timeEndPeriod(1); } }
}

#[cfg(not(windows))]
mod imp {
    pub fn init() {}
    pub fn set_playing(_: bool) {}
    pub fn shutdown() {}
}

pub use imp::*;
