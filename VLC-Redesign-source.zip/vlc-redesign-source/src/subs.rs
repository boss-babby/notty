//! Subtitle files: parsing (SRT / WebVTT / ASS / SSA / MicroDVD), the cue timeline that is drawn on the seek bar,
//! and re-timed SRT export (speed + duration factor) that is handed back to VLC for rendering.
//!
//! VLC (libvlc's freetype renderer) always draws the subtitles on the video - this module only reads the same
//! file so the UI can show *where* the cues are and keep that picture in sync with the subtitle delay.

use std::path::{Path, PathBuf};

#[derive(Clone, Debug)]
pub struct Cue { pub start: i64, pub end: i64, pub text: String }

pub const EXTS: &[&str] = &["srt", "vtt", "ass", "ssa", "sub", "txt"];

fn decode(bytes: &[u8]) -> String {
    if bytes.starts_with(&[0xFF, 0xFE]) || bytes.starts_with(&[0xFE, 0xFF]) {
        let le = bytes[0] == 0xFF;
        let u: Vec<u16> = bytes[2..].chunks_exact(2).map(|c| if le { u16::from_le_bytes([c[0], c[1]]) } else { u16::from_be_bytes([c[0], c[1]]) }).collect();
        return String::from_utf16_lossy(&u);
    }
    let b = bytes.strip_prefix(&[0xEF, 0xBB, 0xBF][..]).unwrap_or(bytes);
    match std::str::from_utf8(b) {
        Ok(s) => s.to_string(),
        // legacy single-byte files (Windows-1252 / Latin-1): map bytes directly
        Err(_) => b.iter().map(|&c| c as char).collect(),
    }
}

/// "00:01:02,345" | "01:02.345" | "1:02:03.45" (ASS centiseconds) -> ms
fn parse_time(s: &str) -> Option<i64> {
    let s = s.trim().replace(',', ".");
    let parts: Vec<&str> = s.split(':').collect();
    let (h, m, sec) = match parts.len() {
        3 => (parts[0].parse::<i64>().ok()?, parts[1].parse::<i64>().ok()?, parts[2]),
        2 => (0, parts[0].parse::<i64>().ok()?, parts[1]),
        _ => return None,
    };
    let (whole, frac) = sec.split_once('.').unwrap_or((sec, "0"));
    let sw: i64 = whole.trim().parse().ok()?;
    let mut f = frac.trim().chars().take(3).collect::<String>();
    let digits = f.len();
    while f.len() < 3 { f.push('0'); }
    let fr: i64 = f.parse().ok()?;
    let _ = digits;
    Some(((h * 60 + m) * 60 + sw) * 1000 + fr)
}

fn parse_srt_like(text: &str) -> Vec<Cue> {
    let mut out = vec![];
    let norm = text.replace("\r\n", "\n").replace('\r', "\n");
    for block in norm.split("\n\n") {
        let lines: Vec<&str> = block.lines().collect();
        let Some(ti) = lines.iter().position(|l| l.contains("-->")) else { continue };
        let (a, b) = lines[ti].split_once("-->").unwrap();
        let b = b.trim().split_whitespace().next().unwrap_or("");
        let (Some(start), Some(end)) = (parse_time(a), parse_time(b)) else { continue };
        let body = lines[ti + 1..].join("\n");
        if !body.trim().is_empty() { out.push(Cue { start, end, text: body }); }
    }
    out
}

fn strip_ass(t: &str) -> String {
    let mut out = String::new();
    let mut depth = 0;
    let mut it = t.chars().peekable();
    while let Some(c) = it.next() {
        match c {
            '{' => depth += 1,
            '}' => { if depth > 0 { depth -= 1 } }
            '\\' if depth == 0 => match it.peek() {
                Some('N') | Some('n') => { it.next(); out.push('\n'); }
                Some('h') => { it.next(); out.push(' '); }
                _ => out.push(c),
            },
            _ if depth == 0 => out.push(c),
            _ => {}
        }
    }
    out
}

fn parse_ass(text: &str) -> Vec<Cue> {
    let mut out = vec![];
    let (mut si, mut ei, mut ti, mut n) = (1usize, 2usize, 9usize, 10usize);
    let mut in_events = false;
    for line in text.lines() {
        let l = line.trim();
        if l.starts_with('[') { in_events = l.eq_ignore_ascii_case("[events]"); continue; }
        if !in_events { continue; }
        if let Some(f) = l.strip_prefix("Format:") {
            let cols: Vec<String> = f.split(',').map(|c| c.trim().to_lowercase()).collect();
            n = cols.len();
            si = cols.iter().position(|c| c == "start").unwrap_or(1);
            ei = cols.iter().position(|c| c == "end").unwrap_or(2);
            ti = cols.iter().position(|c| c == "text").unwrap_or(n.saturating_sub(1));
        } else if let Some(d) = l.strip_prefix("Dialogue:") {
            let f: Vec<&str> = d.trim_start().splitn(n.max(ti + 1), ',').collect();
            if f.len() <= ti.max(si).max(ei) { continue; }
            if let (Some(s), Some(e)) = (parse_time(f[si]), parse_time(f[ei])) {
                let t = strip_ass(f[ti]);
                if !t.trim().is_empty() { out.push(Cue { start: s, end: e, text: t }); }
            }
        }
    }
    out.sort_by_key(|c| c.start);
    out
}

fn parse_microdvd(text: &str, fps: f64) -> Vec<Cue> {
    let mut out = vec![];
    for l in text.lines() {
        let l = l.trim();
        let Some(r) = l.strip_prefix('{') else { continue };
        let Some((a, r)) = r.split_once('}') else { continue };
        let Some(r) = r.strip_prefix('{') else { continue };
        let Some((b, body)) = r.split_once('}') else { continue };
        let (Ok(a), Ok(b)) = (a.parse::<f64>(), b.parse::<f64>()) else { continue };
        out.push(Cue { start: (a / fps * 1000.0) as i64, end: (b / fps * 1000.0) as i64, text: body.replace('|', "\n") });
    }
    out
}

pub fn parse_file(path: &Path) -> Option<Vec<Cue>> {
    let bytes = std::fs::read(path).ok()?;
    let text = decode(&bytes);
    let ext = path.extension()?.to_string_lossy().to_lowercase();
    let mut cues = match ext.as_str() {
        "ass" | "ssa" => parse_ass(&text),
        "sub" => {
            let c = parse_microdvd(&text, 23.976);
            if c.is_empty() { parse_srt_like(&text) } else { c }
        }
        _ => parse_srt_like(&text),
    };
    if cues.is_empty() && text.contains("[Events]") { cues = parse_ass(&text); }
    if cues.is_empty() { return None; }
    cues.sort_by_key(|c| c.start);
    Some(cues)
}

/// Subtitle files next to the media file (same base name, optional language suffix: `movie.en.srt`).
pub fn find_sidecars(media: &str) -> Vec<PathBuf> {
    let p = Path::new(media);
    let (Some(dir), Some(stem)) = (p.parent(), p.file_stem().map(|s| s.to_string_lossy().to_lowercase())) else { return vec![] };
    let mut v = vec![];
    if let Ok(rd) = std::fs::read_dir(dir) {
        for e in rd.flatten() {
            let f = e.path();
            let ext = f.extension().map(|x| x.to_string_lossy().to_lowercase()).unwrap_or_default();
            if !EXTS.contains(&ext.as_str()) || ext == "txt" { continue; }
            let name = f.file_stem().map(|s| s.to_string_lossy().to_lowercase()).unwrap_or_default();
            if name == stem || name.starts_with(&format!("{}.", stem)) { v.push(f); }
        }
    }
    v.sort();
    v
}

fn fmt_srt(ms: i64) -> String {
    let ms = ms.max(0);
    format!("{:02}:{:02}:{:02},{:03}", ms / 3_600_000, (ms / 60_000) % 60, (ms / 1000) % 60, ms % 1000)
}

/// Writes a re-timed SRT (speed multiplier + duration factor). `dur_factor` 0.0 keeps the original duration,
/// 0.5 makes every cue 50 % longer (never overlapping the next cue's start).
pub fn write_retimed(cues: &[Cue], speed: f64, dur_factor: f64, out: &Path) -> bool {
    let mut s = String::new();
    for (i, c) in cues.iter().enumerate() {
        let st = (c.start as f64 * speed) as i64;
        let mut en = (c.end as f64 * speed) as i64;
        let dur = (en - st).max(0);
        en = st + (dur as f64 * (1.0 + dur_factor)) as i64;
        if dur_factor > 0.0 {
            if let Some(n) = cues.get(i + 1) { en = en.min(((n.start as f64 * speed) as i64 - 20).max(st + 200)); }
        }
        s.push_str(&format!("{}\n{} --> {}\n{}\n\n", i + 1, fmt_srt(st), fmt_srt(en.max(st + 100)), c.text.trim()));
    }
    if let Some(d) = out.parent() { let _ = std::fs::create_dir_all(d); }
    std::fs::write(out, s).is_ok()
}

/// Cue density along the whole media for the seek bar: merged `(x0, x1)` segments in 0..1, shifted by the
/// current subtitle delay (so changing the delay visibly slides the marks).
pub fn seekbar_marks(cues: &[Cue], delay_ms: i64, len_ms: i64, max_segments: usize) -> Vec<(f32, f32)> {
    if len_ms <= 0 { return vec![]; }
    let len = len_ms as f64;
    let mut segs: Vec<(f32, f32)> = vec![];
    for c in cues {
        let a = ((c.start + delay_ms) as f64 / len).clamp(0.0, 1.0) as f32;
        let b = ((c.end + delay_ms) as f64 / len).clamp(0.0, 1.0) as f32;
        if b <= 0.0 || a >= 1.0 { continue; }
        match segs.last_mut() {
            Some(l) if a - l.1 < 0.0015 => { if b > l.1 { l.1 = b; } }
            _ => segs.push((a, b.max(a + 0.0008))),
        }
    }
    // thin out when there are too many for the UI
    while segs.len() > max_segments {
        let mut merged = Vec::with_capacity(segs.len() / 2 + 1);
        for ch in segs.chunks(2) { merged.push((ch[0].0, ch[ch.len() - 1].1)); }
        segs = merged;
    }
    segs
}

/// Cues around "now" (window of +- `half_ms`) for the mini timeline in the tune panel: `(x0, x1, active)`, 0..1.
pub fn window_segments(cues: &[Cue], now_ms: i64, delay_ms: i64, half_ms: i64) -> Vec<(f32, f32, bool)> {
    let lo = now_ms - half_ms;
    let hi = now_ms + half_ms;
    let span = (half_ms * 2) as f64;
    let mut v = vec![];
    for c in cues {
        let (s, e) = (c.start + delay_ms, c.end + delay_ms);
        if e < lo || s > hi { continue; }
        let a = ((s - lo) as f64 / span).clamp(0.0, 1.0) as f32;
        let b = ((e - lo) as f64 / span).clamp(0.0, 1.0) as f32;
        v.push((a, b.max(a + 0.004), s <= now_ms && now_ms <= e));
    }
    v
}

pub fn active_text(cues: &[Cue], now_ms: i64, delay_ms: i64) -> String {
    cues.iter().find(|c| c.start + delay_ms <= now_ms && now_ms <= c.end + delay_ms).map(|c| {
        c.text.replace("<i>", "").replace("</i>", "").replace("<b>", "").replace("</b>", "").replace('\n', " ")
    }).unwrap_or_default()
}
