//! Persistent state (settings, recents, playlists, library folders) + settings definitions.

use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::path::PathBuf;

#[derive(Serialize, Deserialize, Clone, Default)]
pub struct Playlist { pub name: String, pub items: Vec<String> }

#[derive(Serialize, Deserialize, Clone)]
pub struct Store {
    pub settings: BTreeMap<String, String>,
    pub recent: Vec<String>,
    pub playlists: Vec<Playlist>,
    pub folders: Vec<String>,
    /// path -> last position (0..1000)
    pub resume: BTreeMap<String, u32>,
    pub volume: f32,
    pub theme_index: i32,
    pub accent_index: i32,
}

impl Default for Store {
    fn default() -> Self {
        Store { settings: BTreeMap::new(), recent: vec![], playlists: vec![], folders: vec![], resume: BTreeMap::new(), volume: 0.8, theme_index: 0, accent_index: 0 }
    }
}

pub fn data_dir() -> PathBuf {
    let base = std::env::var("APPDATA").or_else(|_| std::env::var("XDG_CONFIG_HOME")).map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from(std::env::var("HOME").unwrap_or_else(|_| ".".into())).join(".config"));
    base.join("VLC Redesign")
}
pub fn home_dir() -> PathBuf {
    PathBuf::from(std::env::var("USERPROFILE").or_else(|_| std::env::var("HOME")).unwrap_or_else(|_| ".".into()))
}

impl Store {
    pub fn load() -> Store {
        std::fs::read_to_string(data_dir().join("state.json")).ok().and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default()
    }
    pub fn save(&self) {
        let d = data_dir();
        let _ = std::fs::create_dir_all(&d);
        if let Ok(s) = serde_json::to_string_pretty(self) { let _ = std::fs::write(d.join("state.json"), s); }
    }
    pub fn get(&self, key: &str) -> String {
        self.settings.get(key).cloned().unwrap_or_else(|| def(key).map(|d| d.default.to_string()).unwrap_or_default())
    }
    pub fn on(&self, key: &str) -> bool { self.get(key) == "on" }
    pub fn push_recent(&mut self, p: &str) {
        self.recent.retain(|x| x != p);
        self.recent.insert(0, p.to_string());
        self.recent.truncate(60);
    }
}

/// kind: 0 toggle, 1 select (click cycles), 2 section header.
pub struct Def {
    pub page: &'static str,
    pub key: &'static str,
    pub label: &'static str,
    pub kind: i32,
    pub options: &'static [&'static str],
    pub default: &'static str,
}

const fn t(page: &'static str, key: &'static str, label: &'static str, default: &'static str) -> Def { Def { page, key, label, kind: 0, options: &[], default } }
const fn s(page: &'static str, key: &'static str, label: &'static str, options: &'static [&'static str]) -> Def { Def { page, key, label, kind: 1, options, default: options[0] } }
const fn h(page: &'static str, label: &'static str) -> Def { Def { page, key: "", label, kind: 2, options: &[], default: "" } }

pub static DEFS: &[Def] = &[
    h("General", "Startup"),
    t("General", "confirm_dialogs", "Show confirmation and error dialogs", "off"),
    t("General", "auto_update", "Check for updates automatically", "off"),
    h("General", "Diagnostics"),
    t("General", "dev_mode", "Developer mode", "off"),
    t("General", "save_log", "Save a log", "on"),
    s("General", "log_details", "Log details", &["Errors only", "Warnings", "Debug"]),

    h("Interface", "Window"),
    t("Interface", "show_title", "Show media title on video", "on"),
    t("Interface", "nav_expanded", "Expanded navigation sidebar", "on"),
    s("Interface", "tile_size", "Library tile size", &["Large", "Compact"]),

    h("Privacy", "History"),
    t("Privacy", "save_recent", "Save recently played items", "on"),
    t("Privacy", "resume", "Resume playback where I left off", "on"),

    h("Controls", "Keyboard & mouse"),
    s("Controls", "seek_step", "Seek step (arrow keys)", &["10 seconds", "5 seconds", "30 seconds", "60 seconds"]),
    s("Controls", "volume_step", "Volume step (arrow keys)", &["5 %", "2 %", "10 %"]),

    h("Playback", "Behaviour"),
    t("Playback", "autoplay_next", "Play next item automatically", "on"),
    s("Playback", "repeat", "Repeat", &["Off", "All", "One"]),
    t("Playback", "autoplay_open", "Start playing when an item is opened", "on"),

    h("Video", "Output"),
    t("Video", "hw_decode", "Hardware decoding (needs restart)", "on"),
    s("Video", "fit", "Video scaling", &["Fit", "Fill", "Stretch"]),
    t("Video", "deinterlace", "Deinterlace (needs restart)", "off"),

    h("Audio", "Output"),
    t("Audio", "normalize", "Normalize volume (needs restart)", "off"),
    s("Audio", "eq", "Equalizer preset", &["Off", "Flat", "Classical", "Club", "Dance", "Full bass", "Full bass and treble", "Full treble", "Headphones", "Large Hall", "Live", "Party", "Pop", "Reggae", "Rock", "Ska", "Soft", "Soft rock", "Techno"]),

    h("Subtitles", "Loading"),
    t("Subtitles", "sub_autodetect", "Detect subtitle files automatically (needs restart)", "on"),

    h("Library", "Scanning"),
    t("Library", "show_hidden", "Show hidden files", "off"),
    t("Library", "show_all_files", "Show non-media files", "off"),

    h("Network", "Streaming"),
    s("Network", "net_cache", "Network caching (needs restart)", &["1000 ms", "300 ms", "3000 ms", "6000 ms"]),

    h("Performance", "Rendering"),
    s("Performance", "frame_w", "Max frame width", &["1920 px", "1280 px", "2560 px", "3840 px"]),
    s("Performance", "file_cache", "File caching (needs restart)", &["300 ms", "1000 ms", "3000 ms"]),
    t("Performance", "drop_late", "Drop late frames (needs restart)", "on"),

    h("Recording", "Output"),
    t("Recording", "rec_note", "Recordings are saved in Videos\\VLC Recordings", "on"),

    h("Extensions", "Lua"),
    t("Extensions", "lua", "Enable Lua playlist parsers (needs restart)", "on"),
];

pub fn def(key: &str) -> Option<&'static Def> { DEFS.iter().find(|d| d.key == key) }
