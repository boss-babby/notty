//! Persistent state (settings, recents, playlists, library folders) + settings definitions.

use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::path::PathBuf;

#[derive(Serialize, Deserialize, Clone, Default)]
pub struct Playlist { pub name: String, pub items: Vec<String> }

#[derive(Serialize, Deserialize, Clone)]
pub struct Store {
    pub settings: BTreeMap<String, String>,
    pub recent: Vec<String>,
    pub playlists: Vec<Playlist>,
    pub folders: Vec<String>,
    /// path -> last position (0..1000)
    pub resume: BTreeMap<String, u32>,
    pub volume: f32,
    pub theme_index: i32,
    pub accent_index: i32,
}

impl Default for Store {
    fn default() -> Self {
        Store { settings: BTreeMap::new(), recent: vec![], playlists: vec![], folders: vec![], resume: BTreeMap::new(), volume: 0.8, theme_index: 0, accent_index: 0 }
    }
}

pub fn data_dir() -> PathBuf {
    let base = std::env::var("APPDATA").or_else(|_| std::env::var("XDG_CONFIG_HOME")).map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from(std::env::var("HOME").unwrap_or_else(|_| ".".into())).join(".config"));
    base.join("VLC Redesign")
}
pub fn home_dir() -> PathBuf {
    PathBuf::from(std::env::var("USERPROFILE").or_else(|_| std::env::var("HOME")).unwrap_or_else(|_| ".".into()))
}

impl Store {
    pub fn load() -> Store {
        std::fs::read_to_string(data_dir().join("state.json")).ok().and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default()
    }
    pub fn save(&self) {
        let d = data_dir();
        let _ = std::fs::create_dir_all(&d);
        if let Ok(s) = serde_json::to_string_pretty(self) { let _ = std::fs::write(d.join("state.json"), s); }
    }
    pub fn get(&self, key: &str) -> String {
        self.settings.get(key).cloned().unwrap_or_else(|| def(key).map(|d| d.default.to_string()).unwrap_or_default())
    }
    pub fn on(&self, key: &str) -> bool { self.get(key) == "on" }
    pub fn push_recent(&mut self, p: &str) {
        self.recent.retain(|x| x != p);
        self.recent.insert(0, p.to_string());
        self.recent.truncate(60);
    }
}

/// kind: 0 toggle, 1 select (click cycles), 2 section header.
pub struct Def {
    pub page: &'static str,
    pub key: &'static str,
    pub label: &'static str,
    pub kind: i32,
    pub options: &'static [&'static str],
    pub default: &'static str,
}

const fn t(page: &'static str, key: &'static str, label: &'static str, default: &'static str) -> Def { Def { page, key, label, kind: 0, options: &[], default } }
const fn s(page: &'static str, key: &'static str, label: &'static str, options: &'static [&'static str]) -> Def { Def { page, key, label, kind: 1, options, default: options[0] } }
const fn n(page: &'static str, key: &'static str, label: &'static str) -> Def { Def { page, key, label, kind: 3, options: &[], default: "" } }
const fn h(page: &'static str, label: &'static str) -> Def { Def { page, key: "", label, kind: 2, options: &[], default: "" } }

pub static DEFS: &[Def] = &[
    h("General", "Startup"),
    t("General", "confirm_dialogs", "Show confirmation and error dialogs", "off"),
    t("General", "auto_update", "Check for updates automatically", "off"),
    h("General", "Diagnostics"),
    t("General", "dev_mode", "Developer mode", "off"),
    t("General", "save_log", "Save a log", "on"),
    s("General", "log_details", "Log details", &["Errors only", "Warnings", "Debug"]),

    h("Interface", "Window"),
    t("Interface", "show_title", "Show media title on video", "on"),
    t("Interface", "nav_expanded", "Expanded navigation sidebar", "on"),
    s("Interface", "tile_size", "Library tile size", &["Large", "Compact"]),
    h("Interface", "Appearance"),
    t("Interface", "two_tone", "Two-tone sliders and seek bar", "on"),
    t("Interface", "show_marks", "Show subtitle cues on the seek bar", "on"),
    t("Interface", "show_remaining", "Show remaining time instead of total", "off"),
    h("Interface", "Toolbar buttons"),
    t("Interface", "btn_prevnext", "Previous / next buttons", "on"),
    t("Interface", "btn_audio", "Audio menu button", "on"),
    t("Interface", "btn_sub", "Subtitle menu button", "on"),
    t("Interface", "btn_tune", "Tune playback button", "on"),
    t("Interface", "btn_settings", "Settings button", "on"),
    t("Interface", "btn_fs", "Fullscreen button", "on"),
    t("Interface", "btn_queue", "Queue button", "on"),

    h("Privacy", "History"),
    t("Privacy", "save_recent", "Save recently played items", "on"),
    t("Privacy", "resume", "Resume playback where I left off", "on"),

    h("Controls", "Keyboard & mouse"),
    s("Controls", "seek_step", "Seek step (arrow keys)", &["10 seconds", "5 seconds", "30 seconds", "60 seconds"]),
    s("Controls", "volume_step", "Volume step (arrow keys / wheel)", &["5 %", "2 %", "10 %"]),
    t("Controls", "click_pause", "Click on the video pauses / plays", "on"),
    t("Controls", "dblclick_fs", "Double-click on the video toggles fullscreen", "on"),
    h("Controls", "Shortcuts"),
    n("Controls", "key_note1", "Space play/pause  F fullscreen  M mute  S stop  N / P next / previous"),
    n("Controls", "key_note2", "Left/Right seek  Shift/Ctrl+arrows short/long jump  Up/Down volume"),
    n("Controls", "key_note3", "[ ] speed  = normal  E next frame  G/H subtitle delay  J/K audio delay"),
    n("Controls", "key_note4", "V subtitle track  B audio track  A aspect ratio  Z zoom  C crop  T tune panel"),

    h("Playback", "Behaviour"),
    t("Playback", "autoplay_next", "Play next item automatically", "on"),
    s("Playback", "repeat", "Repeat", &["Off", "All", "One"]),
    t("Playback", "autoplay_open", "Start playing when an item is opened", "on"),

    h("Video", "Output"),
    s("Video", "hw_decode", "Hardware decoding (reloads engine)", &["Automatic", "D3D11VA", "DXVA2", "Off"]),
    s("Video", "vout", "Video output (reloads engine)", &["Automatic", "Direct3D11", "Direct3D9", "OpenGL"]),
    s("Video", "fit", "Video scaling", &["Fit", "Fill", "Stretch"]),
    s("Video", "aspect", "Aspect ratio", &["Default", "16:9", "4:3", "21:9", "16:10", "1:1", "2.35:1"]),
    s("Video", "crop", "Crop", &["None", "16:9", "4:3", "1:1", "16:10", "21:9", "5:4"]),
    s("Video", "zoom", "Zoom", &["Fit", "25 %", "50 %", "75 %", "100 %", "150 %", "200 %"]),
    s("Video", "deint", "Deinterlacing", &["Off", "Yadif", "Yadif (2x)", "Blend", "Bob", "Linear", "X", "Mean", "Discard"]),

    h("Audio", "Output"),
    s("Audio", "boost_db", "Sound boost (live, above 200 % volume)", &["Off", "+3 dB", "+6 dB", "+9 dB", "+12 dB", "+15 dB", "+20 dB"]),
    s("Audio", "stereo_mode", "Stereo mode", &["Stereo", "Reverse stereo", "Left only", "Right only", "Dolby surround"]),
    t("Audio", "normalize", "Normalize volume (reloads item)", "off"),
    s("Audio", "aout", "Audio output (reloads engine)", &["Auto", "WASAPI", "DirectSound", "WaveOut"]),
    t("Audio", "replay_gain", "Apply ReplayGain (reloads engine)", "off"),
    h("Audio", "Effects"),
    t("Audio", "two_pass", "Two-pass equalizer (reloads item)", "off"),
    t("Audio", "spatial", "Spatial audio (reloads item)", "off"),
    s("Audio", "spatial_mode", "Spatial audio mode", &["Headphone virtualization", "Dolby surround downmix", "Room reverb"]),
    t("Audio", "widen", "Stereo widening (reloads item)", "off"),

    h("Subtitles", "Loading"),
    t("Subtitles", "sub_autodetect", "Detect subtitle files automatically (reloads engine)", "on"),
    s("Subtitles", "sub_lang", "Preferred subtitle language (reloads engine)", &["Auto", "English", "French", "German", "Spanish", "Italian", "Portuguese", "Russian", "Arabic", "Japanese", "Korean", "Chinese", "Hindi", "Turkish"]),
    s("Subtitles", "sub_encoding", "Text encoding (reloads engine)", &["Auto", "UTF-8", "Windows-1252", "ISO-8859-1", "Windows-1251", "Windows-1256", "GB18030", "Big5", "Shift_JIS", "EUC-KR"]),
    t("Subtitles", "sub_formatted", "Embedded sub format - keep styling (reloads engine)", "on"),
    h("Subtitles", "Synchronization"),
    s("Subtitles", "sub_speed", "Subtitle speed (re-times the file)", &["1.000x", "0.960x", "0.980x", "1.020x", "1.042x", "1.100x", "1.250x", "0.900x", "0.800x", "1.500x", "2.000x", "0.500x"]),
    s("Subtitles", "sub_dur", "Subtitle duration factor (re-times the file)", &["0.00", "0.25", "0.50", "1.00", "2.00"]),
    h("Subtitles", "Appearance"),
    s("Subtitles", "sub_font", "Subtitle font (reloads engine)", &["Segoe UI", "Arial", "Verdana", "Tahoma", "Calibri", "Trebuchet MS", "Georgia", "Times New Roman", "Consolas", "Comic Sans MS", "Impact"]),
    s("Subtitles", "sub_size", "Text size (reloads engine)", &["Normal", "Small", "Smaller", "Large", "Larger", "Huge"]),
    t("Subtitles", "sub_bold", "Bold text (reloads engine)", "off"),
    s("Subtitles", "sub_color", "Text color (reloads engine)", &["White", "Light gray", "Yellow", "Cyan", "Green", "Orange", "Pink", "Red", "Black"]),
    s("Subtitles", "sub_opacity", "Text opacity (reloads engine)", &["100 %", "85 %", "70 %", "50 %"]),
    s("Subtitles", "sub_outline_color", "Outline color (reloads engine)", &["Black", "Dark gray", "White", "Blue", "Red", "Yellow"]),
    s("Subtitles", "sub_outline_width", "Outline width (reloads engine)", &["Normal", "None", "Thin", "Thick"]),
    s("Subtitles", "sub_bg", "Background box (reloads engine)", &["None", "Semi-transparent", "Solid"]),
    s("Subtitles", "sub_shadow", "Shadow (reloads engine)", &["Off", "Soft", "Hard"]),
    s("Subtitles", "sub_margin", "Bottom margin (reloads engine)", &["0 px", "10 px", "20 px", "40 px", "60 px", "100 px"]),

    h("Library", "Scanning"),
    t("Library", "show_hidden", "Show hidden files", "off"),
    t("Library", "show_all_files", "Show non-media files", "off"),

    h("Network", "Streaming"),
    s("Network", "net_cache", "Network caching (reloads engine)", &["1000 ms", "300 ms", "3000 ms", "6000 ms"]),

    h("Performance", "Rendering"),
    n("Performance", "perf_note", "Video is decoded and drawn by VLC on the GPU - no frames pass through the UI"),
    s("Performance", "file_cache", "File caching (reloads engine)", &["300 ms", "1000 ms", "3000 ms"]),
    t("Performance", "drop_late", "Drop late frames (reloads engine)", "on"),
    t("Performance", "skip_loop", "Skip H.264 loop filter on slow CPUs (reloads engine)", "off"),

    h("Recording", "Output"),
    n("Recording", "rec_note", "Recordings are saved in Videos\\VLC Recordings"),

    h("Extensions", "Lua"),
    t("Extensions", "lua", "Enable Lua playlist parsers (reloads engine)", "on"),
];

pub fn def(key: &str) -> Option<&'static Def> { DEFS.iter().find(|d| d.key == key) }
