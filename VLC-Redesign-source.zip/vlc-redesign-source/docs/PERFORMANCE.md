# Video & audio performance notes

The previous build had choppy video and, at times, poor sound. This session replaced the frame path and tuned the
operating-system side. Everything below is in `src/vlc.rs`, `src/platform.rs` and `src/main.rs`.

## Root causes found

| Symptom | Cause | Fix |
|---|---|---|
| Video judder / uneven frame pacing | The UI pulled frames from a **16 ms repeating timer**. On Windows the default timer granularity is **15.6 ms**, so ticks landed at 15.6 / 31.2 ms and frames were shown at the wrong time. | Frames are now **pushed**: libvlc's display callback wakes the UI thread once per frame; Slint presents on vsync. The timer is only a 25 ms safety net and state sync. |
| High CPU, dropped frames at 1080p+ | Every frame was memcpy'd twice (libvlc buffer -> swap buffer -> new `SharedPixelBuffer`) and a new 8 MB zeroed buffer was allocated on the UI thread. | libvlc now decodes **directly into a `SharedPixelBuffer`**; the finished buffer is *moved* to the UI (zero copies). Allocation happens on the decoder thread. Newer frames replace unconsumed ones (late frames are dropped, never queued). |
| Audio crackle / stutter under load | `timeBeginPeriod` was never called (15.6 ms sleeps in libvlc's clock/audio threads), normal process priority, UI thread and decode competing, EcoQoS power throttling possible on hybrid CPUs. | `platform::init()`: `timeBeginPeriod(1)`, `ABOVE_NORMAL` priority class, MMCSS "Playback" registration, EcoQoS opt-out, display/system sleep blocked while video plays. |
| Resampling artefacts | libvlc picked its default resampler. | `--audio-resampler=soxr` (SoX, high quality) explicitly; WASAPI (`mmdevice`) selectable, plus DirectSound / WaveOut fallbacks in *Settings > Audio > Audio output*. |

## What is the same as VLC

* Demuxing, decoding (incl. D3D11VA / DXVA2 hardware decode via `--avcodec-hw=any`, copy-back), colour conversion,
  deinterlacing, audio output, A/V sync clock, subtitle rendering: all libvlc.
* Audio and video use libvlc's master clock, so lip-sync is VLC's.

## What is different (honest list)

* Video reaches the screen through libvlc's `vmem` output (CPU RGBA frame) instead of VLC's native Direct3D11 vout.
  1080p60 is fine on any recent CPU; 4K60 HEVC / HDR will use more CPU than stock VLC. *Settings > Performance >
  Max frame width* bounds the cost (frames are scaled by libvlc before delivery).
* No HDR tone-mapping, no anamorphic SAR correction in the vmem path.

## How it was verified

* Linux (Xvfb, real **libvlc 3.0.24**, `--aout=dummy`): 1080p30 H.264 + AAC test clip played for 20 s; the UI presented
  every frame libvlc delivered after start-up (`VLC_REDESIGN_STATS=1` prints decoded vs. presented counters).
* The Windows executable is cross-compiled; its imports are system DLLs only. Please report A/V behaviour on your
  hardware through the feedback form on the download page.

## Diagnostics

* `VLC_REDESIGN_STATS=1` -> once per second prints `state / time / decoded / presented`.
* `VLC_REDESIGN_ARGS="--aout=dummy -vv"` -> extra libvlc arguments (space separated).

## Test notes
* Running the Windows exe under Wine 8 was attempted and is not possible there (Wine 8 lacks `bcryptprimitives.dll`,
  which current Rust std needs; real Windows 10/11 has it). The Windows build therefore has **not been executed** in the
  build environment; the same Rust code and the same libvlc binding were exercised on Linux against libvlc 3.0.24.
* While paused, libvlc's vout keeps re-delivering the current picture (~15 Hz) so overlays can refresh; this is VLC
  behaviour and costs little.
