# Video & audio path - why the first build burned CPU, and what changed

## Why the old build used so much CPU
The previous build played video through libvlc's **`vmem` callbacks**:

1. libvlc decoded (optionally on the GPU) and then had to **copy every frame back to system RAM**,
2. converted it to RGBA with **swscale on the CPU** (a 1080p60 stream = ~500 MB/s of memory traffic),
3. handed the buffer to the UI, which **uploaded it again as an OpenGL texture** for Slint to draw.

So the video was *not connected to the GPU at all*: hardware decode was copy-back, colour conversion/scaling was on the
CPU, and presentation went through a second texture upload. That is the high CPU use, and also why 4K / HEVC / HDR was bad.

## What it does now (same path as stock VLC)
* libvlc is given a **native child window** (`libvlc_media_player_set_hwnd`, `src/winvideo.rs`). VLC's own
  **Direct3D11 video output** renders into it: `--avcodec-hw=any` -> **D3D11VA decode, zero-copy**, GPU colour
  conversion / scaling / deinterlacing, subtitles blended by libvlc, presentation by the GPU swap chain.
  The UI never touches a frame, so CPU use equals VLC's (Settings > Video lets you force D3D11VA / DXVA2 / D3D9 / OpenGL).
* The Slint UI stays GPU-rendered (OpenGL). Things that must be drawn *above* the video (popup menus, toast, seek tooltip,
  dialogs, the fullscreen control bar, the tune panel in fullscreen) are **cut out of the video window's region**
  (`SetWindowRgn`), so the UI shows through exactly there. No overlay window, no transparency tricks, no per-frame work.
  In windowed mode the layout is docked like the Figma (video stage, queue and tune panel never overlap).
* VLC's child window swallows mouse messages, so clicks on the video are detected by cheap cursor polling
  (25 ms): click = play/pause, double-click = fullscreen, right-click = context menu.
* Windows tuning is unchanged: 1 ms timer resolution, MMCSS "Playback", above-normal priority, EcoQoS opt-out,
  display/system sleep blocked while video plays. Audio: SoX resampler, selectable WASAPI / DirectSound / WaveOut.

## Sound boost (like VLC)
* The volume slider goes **0 - 200 %** (libvlc software amplification, same as VLC's > 100 % range); the part above 100 %
  is drawn in orange. Mouse wheel on the slider / Up-Down keys change it by the configured step.
* *Settings > Audio > Sound boost* adds **+3 ... +20 dB** on top, live, through the equalizer pre-amp (works with the EQ off).
* Normalizer, compressor, spatial audio (headphone virtualisation / Dolby downmix / room reverb), stereo widening and
  two-pass EQ are libvlc filters chained per item (the item reloads at the same position when toggled).

## Diagnostics
* `VLC_REDESIGN_STATS=1` prints state / time / whether the native vout exists / volume once per second.
* `VLC_REDESIGN_ARGS="-vv"` passes extra libvlc arguments (verbose log shows `direct3d11` + `d3d11va` when GPU path is active).

## Honest limits
* The Windows executable is cross-compiled from Linux; it has **not been run on a Windows machine** in the build
  environment (no Windows / Wine). All libvlc symbols used were checked against `libvlc.dll` 3.0.21 and the UI was
  rendered headlessly. If something misbehaves on your GPU, switch *Settings > Video > Video output* and report it.
* libvlc 3.0 cannot expose cues of *embedded* subtitle tracks, so the seek-bar cue marks are drawn for external
  subtitle files (auto-detected next to the video, or added by you). Embedded tracks render normally in the video.
