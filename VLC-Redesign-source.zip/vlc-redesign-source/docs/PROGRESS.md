# VLC Redesign — progress & roadmap

Rust + [Slint](https://slint.dev) UI on top of **libvlc 3.0.24**, following the *VLC Redesign (Community)* Figma.
Design reference images live in `docs/design/`. Rendered screens of the current UI are in `docs/*.png`
(`cd tools/shot && cargo run --release -- ../../docs`).

## Done

### Session 1 (starter)
* Library grid (Home / Videos / Music / Network / Playlists / Recent / Add item), breadcrumbs, sort, tile size, search.
* Player page with queue panel, custom control bar (seek, volume, audio / subtitle menus, settings, fullscreen).
* Redesigned right-click menu with all sub-menus; settings dialog with 12 pages; dark/light theme and 9 accent colours.
* Resume playback, saved playlists, snapshots, recording, keyboard shortcuts, "Open with" file argument.

### Session 2 (this session)
**Engine / performance** (details in `PERFORMANCE.md`)
* Event-driven, zero-copy frame path (libvlc -> `SharedPixelBuffer` -> GPU), vsync-paced presentation.
* Windows tuning: 1 ms timer resolution, process priority, MMCSS, EcoQoS opt-out, sleep inhibition while playing.
* Audio: SoX resampler, selectable output module (WASAPI / DirectSound / WaveOut), optional ReplayGain.
* New libvlc bindings: audio delay, subtitle delay, video adjust, 10-band equalizer.

**UI from the Figma**
* **Frameless window** with the Figma title bar: cone, menu, sidebar toggle, folder + current location, centred title,
  minimise / maximise-restore / fullscreen / close. Drag by title bar, double-click to maximise, 8-way edge resize.
* **Tune panel** (side panel, tabs *Playback / Video / Audio / Subtitles*, opens from the sliders button or `T`):
  * Playback: speed slider, reset, jump size, repeat, autoplay.
  * Video: brightness, contrast, saturation, hue, gamma, reset, scaling, snapshot.
  * Audio: audio delay, equalizer switch, compressor (RMS/peak, attack, release, threshold, ratio, knee, makeup).
  * Subtitles: track cycling, add file, subtitle delay.
* **10-band equalizer** in *Settings > Audio* exactly like the Figma (preamp + 10 bands, dB read-outs, presets from
  libvlc, reset, persisted).
* **Animation everywhere**: page cross-fades, sliding queue / tune panel, animated nav rail, control bar and title bar
  slide in fullscreen, dialog fade + rise, toast fade, hover transitions on buttons, tabs, tiles and rows.

## Not done yet (next steps, roughly by value)

| Area | What is missing |
|---|---|
| Native video output | Direct3D11 vout in a child window (needs an overlay strategy for the controls), HDR tone-mapping, SAR correction. |
| Settings (Figma "Settings – global") | Theme picker as preview tiles with radio dots (`Frame 151/159`); currently text buttons. Many VLC options are not exposed (video filters, audio output device list, hotkey editor). |
| Subtitles panel | Appearance block (font, text colour, outline colour, embedded sub format), subtitle speed / duration factor. libvlc 3.0 needs a restart for most of these. |
| Equalizer | Two-pass, spatial audio, headphone virtualisation, stereo widening (need extra libvlc filters). Compressor values apply on the next item (libvlc has no live setter). |
| Library | Real thumbnails, metadata scan, album art / music view, grid vs list, folder watching. |
| Network | Browsing UPnP / SMB / FTP sources; only manual URLs today. |
| Playlist | Drag & drop reordering, shuffle, saved-playlist editor. |
| Window | Aero-snap friendly drag from maximised, custom window shadow / rounded corners on Windows 10, taskbar thumbnail buttons. |
| Seek bar | Hover time + thumbnail preview, chapter marks. |
| Misc | Installer + icon resource, localisation, DVD/Blu-ray menus, Lua extension UI, Chromecast, Wayland/macOS builds QA. |

## Testing status
* Linux dev build, real libvlc 3.0.24, Xvfb: video + frame pacing verified (see `PERFORMANCE.md`).
* UI states verified by headless render (`docs/*.png`).
* Windows build: cross-compiled with MinGW-w64 (`x86_64-pc-windows-gnu`), imports system DLLs only.
