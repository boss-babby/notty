# VLC Redesign - progress

Rust + Slint UI on **libvlc 3.0.21**, following *VLC Redesign (Community)*. Design images: `docs/design/`, renders of the
current UI: `docs/*.png` (`cd tools/shot && cargo run --release -- ../../docs`).

## Session 3 (this release)
**Engine** - native Direct3D11 / D3D11VA video window instead of `vmem` (see `PERFORMANCE.md`); volume 0-200 % + sound boost.

**Subtitles** (Figma "Subtitles" panel)
* Tune panel > Subtitles: track, language, delay slider (live, G/H = -/+50 ms), speed, duration factor,
  embedded-format toggle, font, size, bold, text colour + opacity, outline colour + width, background box, shadow,
  bottom margin, text encoding - all with a **live preview** (styled sample + cue timeline of the next/previous 30 s).
* Style options are libvlc freetype options; changing one reloads the engine and resumes at the same position/tracks.
* **Subtitles on the seek bar**: cue marks drawn along the track (shifted live by the delay), hover tooltip shows the time
  and the subtitle line at that position. Parses SRT, WebVTT, ASS/SSA, MicroDVD; UTF-8/16/Latin-1.
  Speed / duration factor re-time the external file and hand it back to VLC.
* Auto-detects `movie.srt`, `movie.en.ass`, ... next to the video.

**Toolbar / interface customisation** - Settings > Interface: show/hide every toolbar button, two-tone vs solid
sliders, subtitle marks, remaining time, expanded rail, tile size; theme (dark/light/system) and 9 accent colours;
Hide-UI mode; docked queue / tune panels; full-height Figma settings dialog with search.

**More VLC tools** - aspect ratio, crop, zoom, deinterlace (live), stereo mode, A-B loop, frame-by-frame, chapters,
speed `[ ] =`, audio delay J/K, subtitle track V, audio track B, 3 s / 1 min jumps (Shift/Ctrl + arrows), snapshots,
recording, resume, playlists, network streams. Keyboard cheat-sheet in Settings > Controls.

## Not done yet
| Area | What is missing |
|---|---|
| Library | Real thumbnails / metadata scan, music view, UPnP/SMB browsing |
| Playlist | Drag & drop reordering, shuffle |
| Window | Aero-snap drag from maximised, rounded corners on Windows 10 |
| Subtitles | Cue marks for *embedded* tracks (libvlc 3.0 exposes no cue list) |
| Misc | Installer + icon resource, localisation, DVD/Blu-ray menus, Chromecast |

## Testing status
* Cross-compiled with llvm-mingw (`x86_64-pc-windows-gnu`); imports system DLLs only; all libvlc symbols verified
  against the shipped `libvlc.dll`. **Not executed on Windows in the build environment.**
* UI states verified by headless render (`docs/*.png`).
