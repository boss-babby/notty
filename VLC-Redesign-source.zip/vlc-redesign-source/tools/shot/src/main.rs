//! cargo run --release -- <out_dir>
slint::include_modules!();
use slint::platform::software_renderer::{MinimalSoftwareWindow, RepaintBufferType};
use slint::platform::{Platform, WindowAdapter};
use slint::{ComponentHandle, Model, ModelRc, PhysicalSize, Rgb8Pixel, SharedPixelBuffer, Rgba8Pixel, VecModel};
use std::rc::Rc;

struct P(Rc<MinimalSoftwareWindow>);
impl Platform for P {
    fn create_window_adapter(&self) -> Result<Rc<dyn WindowAdapter>, slint::PlatformError> { Ok(self.0.clone()) }
}

fn mi(t: &str, kind: i32, tint: (u8, u8, u8), meta: &str, resume: f32) -> MediaItem {
    MediaItem { title: t.into(), path: "".into(), kind, meta: meta.into(), tint: slint::Color::from_rgb_u8(tint.0, tint.1, tint.2), resume }
}
fn me(l: &str, sc: &str, ic: &str, id: &str, sub: bool) -> MenuEntry { MenuEntry { label: l.into(), shortcut: sc.into(), icon: ic.into(), id: id.into(), sub, checked: false } }
fn m<T: Clone + 'static>(v: Vec<T>) -> ModelRc<T> { ModelRc::new(VecModel::from(v)) }

fn main() {
    let out = std::env::args().nth(1).unwrap_or_else(|| ".".into());
    std::fs::create_dir_all(&out).unwrap();
    let win = MinimalSoftwareWindow::new(RepaintBufferType::NewBuffer);
    slint::platform::set_platform(Box::new(P(win.clone()))).unwrap();
    let (w, h) = (1280u32, 760u32);
    win.set_size(PhysicalSize::new(w, h));
    let ui = MainWindow::new().unwrap();
    ui.show().unwrap();

    let render = |name: &str| {
        std::thread::sleep(std::time::Duration::from_millis(450));
        slint::platform::update_timers_and_animations();
        std::thread::sleep(std::time::Duration::from_millis(450));
        slint::platform::update_timers_and_animations();
        let mut buf = vec![Rgb8Pixel { r: 0, g: 0, b: 0 }; (w * h) as usize];
        win.draw_if_needed(|r| { r.render(&mut buf, w as usize); });
        let mut bytes = Vec::with_capacity(buf.len() * 3);
        for p in &buf { bytes.extend_from_slice(&[p.r, p.g, p.b]); }
        let f = std::fs::File::create(format!("{}/{}.png", out, name)).unwrap();
        let mut enc = png::Encoder::new(std::io::BufWriter::new(f), w, h);
        enc.set_color(png::ColorType::Rgb);
        enc.set_depth(png::BitDepth::Eight);
        enc.write_header().unwrap().write_image_data(&bytes).unwrap();
        println!("wrote {}", name);
    };

    let tints = [(96, 44, 28), (28, 66, 110), (66, 34, 104), (24, 92, 66), (112, 84, 26), (104, 30, 66), (30, 88, 100)];
    let mut items = vec![];
    for i in 5..=15 { items.push(mi(&format!("The_Wand_S01E{:02}.mp4", i), 0, tints[i % 7], "412 MB", 0.0)); }
    for i in 1..=4 { items.push(mi(&format!("The_Wand_S01E{:02}.mp4", i), 0, tints[i % 7], "388 MB", 0.6)); }
    ui.set_items(m(items));
    ui.set_crumbs(m(["Videos", "Shows", "The Wand", "S01"].iter().map(|s| Crumb { label: (*s).into() }).collect()));
    ui.set_count_text("15 items".into());
    ui.set_nav("videos".into());
    render("library");

    // ---- player page: docked queue, native-video stage placeholder, seek bar with subtitle cue marks, 140 % volume
    let q: Vec<MediaItem> = (1..=6).map(|i| mi(&format!("The_Wand_S01E{:02}.mp4", i), 0, (0, 0, 0), "", 0.0)).collect();
    ui.set_queue(m(q));
    ui.set_current_index(1);
    ui.set_has_media(true);
    ui.set_player_page(true);
    ui.set_playing(true);
    ui.set_now_title("The_Wand_S01E02.mp4".into());
    ui.set_cur_time("00:02:10".into());
    ui.set_total_time("00:25:40".into());
    ui.set_position(0.14);
    ui.set_volume(1.4);
    let marks: Vec<Seg> = (0..120).map(|i| Seg { x: 0.02 + i as f32 * 0.0079, w: 0.0035 + (i % 5) as f32 * 0.0006, on: false }).collect();
    ui.set_sub_marks(m(marks));
    render("player-queue");
    ui.set_show_playlist(false);
    render("player-wide");

    // ---- tune panel: Subtitles tab with live preview + cue timeline
    let sp = |id: &str, label: &str, text: &str, kind: i32, norm: f32, sw: Option<(u8, u8, u8)>| Param {
        id: id.into(), label: label.into(), text: text.into(), norm, kind,
        swatch: sw.map(|c| slint::Color::from_rgb_u8(c.0, c.1, c.2)).unwrap_or_default(), has_swatch: sw.is_some(),
    };
    ui.set_tune_open(true);
    ui.set_tune_tab(3);
    ui.set_tune_params(m(vec![
        sp("", "Defaults", "", 1, 0.0, None), sp("strack", "Subtitle track (click to cycle)", "English", 2, 0.0, None),
        sp("sdelay", "Subtitle track delay", "-0.250 s", 0, 0.48, None), sp("k:sub_speed", "Subtitle speed", "1.000x", 2, 0.0, None),
        sp("", "Appearance", "", 1, 0.0, None), sp("k:sub_font", "Subtitle font", "Segoe UI", 2, 0.0, None),
        sp("k:sub_color", "Text color", "Yellow", 2, 0.0, Some((255, 230, 0))), sp("k:sub_outline_color", "Outline color", "Black", 2, 0.0, Some((0, 0, 0))),
        sp("k:sub_bold", "Bold", "on", 3, 0.0, None),
    ]));
    ui.set_sub_style(SubStyle { font: "Segoe UI".into(), color: slint::Color::from_rgb_u8(255, 230, 0), outline: slint::Color::from_rgb_u8(0, 0, 0), outline_w: 2.0, size: 14.0, bold: true, sample: "The quick brown fox jumps over the lazy dog".into() });
    ui.set_sub_win(m(vec![Seg { x: 0.05, w: 0.12, on: false }, Seg { x: 0.30, w: 0.18, on: false }, Seg { x: 0.46, w: 0.14, on: true }, Seg { x: 0.70, w: 0.1, on: false }]));
    ui.set_sub_cue_text("You shall not pass!".into());
    render("tune-subtitles");

    // ---- context menu (the real video window is cut out below this in the app)
    ui.set_tune_open(false);
    ui.set_menu_items(m(vec![
        me("Play", "Space", "play", "play", false), me("Stop", "S", "stop", "stop", false), me("Previous Item", "P", "prev", "prev", false),
        me("Next Item", "N", "next", "next", false), me("Record", "R", "record", "record", false), me("Hide UI", "Ctrl + \\", "hideui", "hideui", false),
        me("Playback", "", "playback", "menu:playback", true), me("Video", "", "clap", "menu:video", true), me("Audio", "", "wave", "menu:audio", true),
        me("Subtitle", "", "subtitle", "menu:subtitle", true), me("Playlist", "", "playlist", "menu:playlist", true), me("Quit VLC", "Ctrl + Q", "quit", "quit", false),
    ]));
    ui.invoke_open_context_menu(420.0, 120.0);
    render("context-menu");
    ui.invoke_close_menu();

    // ---- settings > Subtitles (preview + appearance rows) and Interface (toolbar customisation)
    let row = |l: &str, k: i32, on: bool, v: &str, sw: Option<(u8, u8, u8)>| Row { label: l.into(), kind: k, on, value: v.into(), swatch: sw.map(|c| slint::Color::from_rgb_u8(c.0, c.1, c.2)).unwrap_or_default(), has_swatch: sw.is_some() };
    ui.set_settings_open(true);
    ui.set_settings_page("Subtitles".into());
    ui.set_rows(m(vec![
        row("Appearance", 2, false, "", None), row("Subtitle font (reloads engine)", 1, false, "Segoe UI", None), row("Text size (reloads engine)", 1, false, "Large", None),
        row("Bold text (reloads engine)", 0, true, "", None), row("Text color (reloads engine)", 1, false, "Yellow", Some((255, 230, 0))),
        row("Outline color (reloads engine)", 1, false, "Black", Some((0, 0, 0))), row("Background box (reloads engine)", 1, false, "None", None),
    ]));
    render("settings-subtitles");
    ui.set_settings_page("Interface".into());
    ui.set_rows(m(vec![
        row("Appearance", 2, false, "", None), row("Two-tone sliders and seek bar", 0, true, "", None), row("Show subtitle cues on the seek bar", 0, true, "", None),
        row("Toolbar buttons", 2, false, "", None), row("Audio menu button", 0, true, "", None), row("Subtitle menu button", 0, false, "", None),
        row("Left/Right seek  Shift/Ctrl+arrows short/long jump  Up/Down volume", 3, false, "", None),
    ]));
    render("settings-interface");
}
