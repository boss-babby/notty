//! cargo run --release -- <out_dir>
slint::include_modules!();
use slint::platform::software_renderer::{MinimalSoftwareWindow, RepaintBufferType};
use slint::platform::{Platform, WindowAdapter};
use slint::{ComponentHandle, Model, ModelRc, PhysicalSize, Rgb8Pixel, SharedPixelBuffer, Rgba8Pixel, VecModel};
use std::rc::Rc;

struct P(Rc<MinimalSoftwareWindow>);
impl Platform for P {
    fn create_window_adapter(&self) -> Result<Rc<dyn WindowAdapter>, slint::PlatformError> { Ok(self.0.clone()) }
}

fn mi(t: &str, kind: i32, tint: (u8, u8, u8), meta: &str, resume: f32) -> MediaItem {
    MediaItem { title: t.into(), path: "".into(), kind, meta: meta.into(), tint: slint::Color::from_rgb_u8(tint.0, tint.1, tint.2), resume }
}
fn me(l: &str, sc: &str, ic: &str, id: &str, sub: bool) -> MenuEntry { MenuEntry { label: l.into(), shortcut: sc.into(), icon: ic.into(), id: id.into(), sub, checked: false } }
fn m<T: Clone + 'static>(v: Vec<T>) -> ModelRc<T> { ModelRc::new(VecModel::from(v)) }

fn main() {
    let out = std::env::args().nth(1).unwrap_or_else(|| ".".into());
    std::fs::create_dir_all(&out).unwrap();
    let win = MinimalSoftwareWindow::new(RepaintBufferType::NewBuffer);
    slint::platform::set_platform(Box::new(P(win.clone()))).unwrap();
    let (w, h) = (1280u32, 760u32);
    win.set_size(PhysicalSize::new(w, h));
    let ui = MainWindow::new().unwrap();
    ui.show().unwrap();

    let render = |name: &str| {
        std::thread::sleep(std::time::Duration::from_millis(450));
        slint::platform::update_timers_and_animations();
        std::thread::sleep(std::time::Duration::from_millis(450));
        slint::platform::update_timers_and_animations();
        let mut buf = vec![Rgb8Pixel { r: 0, g: 0, b: 0 }; (w * h) as usize];
        win.draw_if_needed(|r| { r.render(&mut buf, w as usize); });
        let mut bytes = Vec::with_capacity(buf.len() * 3);
        for p in &buf { bytes.extend_from_slice(&[p.r, p.g, p.b]); }
        let f = std::fs::File::create(format!("{}/{}.png", out, name)).unwrap();
        let mut enc = png::Encoder::new(std::io::BufWriter::new(f), w, h);
        enc.set_color(png::ColorType::Rgb);
        enc.set_depth(png::BitDepth::Eight);
        enc.write_header().unwrap().write_image_data(&bytes).unwrap();
        println!("wrote {}", name);
    };

    let tints = [(96, 44, 28), (28, 66, 110), (66, 34, 104), (24, 92, 66), (112, 84, 26), (104, 30, 66), (30, 88, 100)];
    let mut items = vec![];
    for i in 5..=15 { items.push(mi(&format!("The_Wand_S01E{:02}.mp4", i), 0, tints[i % 7], "412 MB", 0.0)); }
    for i in 1..=4 { items.push(mi(&format!("The_Wand_S01E{:02}.mp4", i), 0, tints[i % 7], "388 MB", 0.6)); }
    ui.set_items(m(items));
    ui.set_crumbs(m(["Videos", "Shows", "The Wand", "S01"].iter().map(|s| Crumb { label: (*s).into() }).collect()));
    ui.set_count_text("15 items".into());
    ui.set_nav("videos".into());
    render("library");

    // collapsed rail + light theme + other accent
    ui.set_nav_expanded(false);
    ui.set_theme_index(1);
    ui.set_accent_index(5);
    render("library-light");
    ui.set_theme_index(0);
    ui.set_accent_index(0);
    ui.set_nav_expanded(true);

    // player
    let q: Vec<MediaItem> = ["Cool Song - Intro.mp3", "The_Wand_S01E01.mp4", "The_Wand_S01E02.mp4", "Anime Opening.mkv"].iter().map(|t| mi(t, 0, (0, 0, 0), "", 0.0)).collect();
    ui.set_queue(m(q));
    ui.set_current_index(1);
    ui.set_has_media(true);
    ui.set_player_page(true);
    ui.set_playing(true);
    ui.set_now_title("The_Wand_S01E01.mp4".into());
    ui.set_cur_time("00:02:10".into());
    ui.set_total_time("00:25:40".into());
    ui.set_position(0.085);
    // synthetic frame
    let (fw, fh) = (640u32, 360u32);
    let mut fb = SharedPixelBuffer::<Rgba8Pixel>::new(fw, fh);
    for (i, px) in fb.make_mut_bytes().chunks_mut(4).enumerate() {
        let (x, y) = ((i as u32 % fw) as f32 / fw as f32, (i as u32 / fw) as f32 / fh as f32);
        let d = ((x - 0.5).powi(2) + (y - 0.5).powi(2)).sqrt();
        let v = (255.0 * (1.0 - d * 1.6)).clamp(10.0, 255.0) as u8;
        px.copy_from_slice(&[v, (v as f32 * 0.55) as u8, (v as f32 * 0.2) as u8, 255]);
    }
    ui.set_frame(slint::Image::from_rgba8(fb));
    ui.set_has_frame(true);
    render("player");

    // context menu
    let entries = vec![
        me("Play", "Space", "play", "play", false), me("Stop", "S", "stop", "stop", false), me("Previous Item", "P", "prev", "prev", false),
        me("Next Item", "N", "next", "next", false), me("Record", "R", "record", "record", false), me("Hide UI", "Ctrl + \\", "hideui", "hideui", false),
        me("Playback", "", "playback", "menu:playback", true), me("Video", "", "clap", "menu:video", true), me("Audio", "", "wave", "menu:audio", true),
        me("Subtitle", "", "subtitle", "menu:subtitle", true), me("More Settings", "", "settings", "settings", true), me("Playlist", "", "playlist", "menu:playlist", true),
        me("Open Media", "", "openmedia", "menu:open", true), me("Quit VLC", "Ctrl + Q", "quit", "quit", false),
    ];
    let ui_weak = ui.as_weak();
    ui.on_request_menu(move |_k| { if let Some(u) = ui_weak.upgrade() { u.set_menu_items(m(entries.clone())); } });
    ui.invoke_open_context_menu(560.0, 120.0);
    render("context-menu");
    ui.invoke_close_menu();
    render("_discard");

    // settings
    ui.set_settings_open(false);
    ui.set_settings_open(true);
    ui.set_rows(m(vec![
        Row { label: "Startup".into(), kind: 2, on: false, value: "".into() },
        Row { label: "Show confirmation and error dialogs".into(), kind: 0, on: false, value: "".into() },
        Row { label: "Check for updates automatically".into(), kind: 0, on: false, value: "".into() },
        Row { label: "Diagnostics".into(), kind: 2, on: false, value: "".into() },
        Row { label: "Developer mode".into(), kind: 0, on: false, value: "".into() },
        Row { label: "Save a log".into(), kind: 0, on: true, value: "".into() },
        Row { label: "Log details".into(), kind: 1, on: false, value: "Errors only".into() },
    ]));
    render("settings");

    // ---- settings > Audio with the 10-band equalizer
    ui.set_settings_page("Audio".into());
    let labels = ["Preamp", "60 Hz", "170 Hz", "310 Hz", "600 Hz", "1 KHz", "3 KHz", "6 KHz", "12 KHz", "14 KHz", "16 KHz"];
    let dbs = [12.0f32, 0.0, 2.0, 4.0, 3.0, 0.0, -2.0, 0.0, 3.5, 5.0, 6.0];
    ui.set_eq_bands(m(labels.iter().zip(dbs.iter()).map(|(l, d)| EqBand { label: (*l).into(), text: format!("{:.1} dB", d).into(), norm: (d + 20.0) / 40.0 }).collect()));
    ui.set_eq_on(true);
    ui.set_eq_preset_name("Rock".into());
    ui.set_rows(m(vec![
        Row { label: "Output".into(), kind: 2, on: false, value: "".into() },
        Row { label: "Normalize volume (needs restart)".into(), kind: 0, on: false, value: "".into() },
        Row { label: "Audio output (needs restart)".into(), kind: 1, on: false, value: "Auto".into() },
    ]));
    render("settings-audio");
    ui.set_settings_open(false);

    // ---- tune panel (all four tabs)
    let p = |id: &str, label: &str, text: &str, norm: f32, kind: i32| Param { id: id.into(), label: label.into(), text: text.into(), norm, kind };
    ui.set_tune_open(true);
    ui.set_tune_tab(1);
    ui.set_tune_params(m(vec![p("", "Adjustments", "", 0.0, 1), p("bright", "Brightness", "1.10", 0.55, 0), p("contrast", "Contrast", "1.00", 0.5, 0), p("sat", "Saturation", "1.40", 0.46, 0), p("hue", "Hue", "0°", 0.5, 0), p("gamma", "Gamma", "1.00", 0.31, 0),
        p("vreset", "Reset adjustments", "", 0.0, 2), p("", "Display", "", 0.0, 1), p("fit", "Video scaling", "Fit", 0.0, 2), p("snap", "Take snapshot", "", 0.0, 2)]));
    render("tune-video");
    ui.set_tune_tab(2);
    ui.set_tune_params(m(vec![p("", "Synchronization", "", 0.0, 1), p("adelay", "Audio track delay", "-0.250 s", 0.49, 0), p("", "Effects", "", 0.0, 1), p("eq", "Equalizer", "on", 0.0, 3), p("eq_open", "Open 10-band equalizer", "", 0.0, 2),
        p("", "Compressor", "", 0.0, 1), p("comp", "Dynamic range compressor", "off", 0.0, 3), p("", "Compressor settings apply from the next item that starts.", "", 0.0, 4), p("c0", "RMS / Peak", "0.20", 0.2, 0), p("c1", "Attack", "25.0 ms", 0.06, 0), p("c3", "Threshold", "-11.0 dB", 0.63, 0)]));
    render("tune-audio");
    ui.set_tune_tab(3);
    ui.set_tune_params(m(vec![p("", "Defaults", "", 0.0, 1), p("strack", "Subtitle track (click to cycle)", "English", 0.0, 2), p("sub_add", "Add subtitle file...", "", 0.0, 2), p("", "Synchronization", "", 0.0, 1), p("sdelay", "Subtitle track delay", "-4.000 s", 0.3, 0)]));
    render("tune-subtitles");
    ui.set_tune_open(false);
    ui.set_player_page(false);
    ui.set_nav("videos".into());
    render("library-final");
    let _ = ui.get_items().row_count();
}
