#!/usr/bin/env bash
set -euo pipefail
export PATH=$HOME/.cargo/bin:$HOME/llvm-mingw/bin:$PATH
cd "$(dirname "$0")/.."
cargo build --release --target x86_64-pc-windows-gnu
OUT=dist/VLC-Redesign-win64; rm -rf $OUT; mkdir -p $OUT
cp "${CARGO_TARGET_DIR:-target}/x86_64-pc-windows-gnu/release/vlc-redesign.exe" $OUT/
# libvlc runtime (VLC 3.0.24, LGPL libvlc + plugins)
VLC=3.0.24
[ -f /tmp/vlc-$VLC.zip ] || curl -L -o /tmp/vlc-$VLC.zip https://get.videolan.org/vlc/$VLC/win64/vlc-$VLC-win64.zip
rm -rf /tmp/vlcx && unzip -q /tmp/vlc-$VLC.zip -d /tmp/vlcx
S=/tmp/vlcx/vlc-$VLC
cp -r $S/libvlc.dll $S/libvlccore.dll $S/plugins $S/lua $S/hrtfs $S/COPYING.txt $S/AUTHORS.txt $OUT/
echo "done: $OUT"
