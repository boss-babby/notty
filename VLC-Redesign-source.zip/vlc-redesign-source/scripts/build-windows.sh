#!/usr/bin/env bash
# Cross-compiles the Windows x64 build and assembles dist/VLC-Redesign-win64(.zip).
#
# Toolchain (either works):
#   * Debian/Ubuntu:  sudo apt install mingw-w64 zip unzip curl
#                     sudo update-alternatives --set x86_64-w64-mingw32-gcc /usr/bin/x86_64-w64-mingw32-gcc-posix
#                     rustup target add x86_64-pc-windows-gnu
#   * Anything else:  ./scripts/fetch-toolchain.sh   (rustup + llvm-mingw in $HOME, no root)
set -euo pipefail
export PATH=$HOME/.cargo/bin:$HOME/llvm-mingw/bin:$PATH
cd "$(dirname "$0")/.."
cargo build --release --target x86_64-pc-windows-gnu
OUT=dist/VLC-Redesign-win64; rm -rf "$OUT"; mkdir -p "$OUT"
cp "${CARGO_TARGET_DIR:-target}/x86_64-pc-windows-gnu/release/vlc-redesign.exe" "$OUT/"
# libvlc runtime (VLC 3.0.24, LGPL libvlc + plugins)
VLC=3.0.24
ZIP=${VLC_ZIP:-/tmp/vlc-$VLC-win64.zip}
[ -f "$ZIP" ] || curl -L -o "$ZIP" https://get.videolan.org/vlc/$VLC/win64/vlc-$VLC-win64.zip
rm -rf /tmp/vlcx && unzip -q "$ZIP" -d /tmp/vlcx
S=/tmp/vlcx/vlc-$VLC
cp -r "$S/libvlc.dll" "$S/libvlccore.dll" "$S/plugins" "$S/lua" "$S/hrtfs" "$S/COPYING.txt" "$S/AUTHORS.txt" "$OUT/"
cp README.md docs/PROGRESS.md "$OUT/" 2>/dev/null || true
(cd dist && rm -f VLC-Redesign-win64.zip && zip -qr9 VLC-Redesign-win64.zip VLC-Redesign-win64)
echo "done: $OUT  and  dist/VLC-Redesign-win64.zip"
