#!/usr/bin/env bash
# Installs rustup (x86_64-pc-windows-gnu target) and llvm-mingw into $HOME - no root required.
set -euo pipefail
curl -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal -t x86_64-pc-windows-gnu
V=20261104
mkdir -p ~/llvm-mingw
curl -L https://github.com/mstorsjo/llvm-mingw/releases/download/$V/llvm-mingw-$V-ucrt-ubuntu-22.04-x86_64.tar.xz | tar xJ -C ~/llvm-mingw --strip-components=1
# llvm-mingw has no libgcc / libgcc_eh; rustc's windows-gnu target asks for them -> provide shims backed by libunwind
L=~/llvm-mingw/x86_64-w64-mingw32/lib
cp $L/libunwind.a $L/libgcc_eh.a
rm -f $L/libgcc.a && ~/llvm-mingw/bin/x86_64-w64-mingw32-ar rc $L/libgcc.a
echo 'add to PATH:  $HOME/.cargo/bin  $HOME/llvm-mingw/bin'
