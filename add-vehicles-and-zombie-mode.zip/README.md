# NEON TIDE — a neon-noir, top-down open-world crime game

> **v8 update — ZOMBIE OUTBREAK + armour, ships & airliners:** new menu mode *☣ Zombie Outbreak* (6-chapter story + endless survival where zombies, police, soldiers and civilians all interact), drivable tanks/APCs, jet skis, speedboats, cruisers, gunboats, container ships and cruise liners, and flyable airliners/jumbo/airlifter on the airport apron. See ANALYSIS.md (v8).

> **v4 update — infinite world:** the map no longer has an edge. The authored 768² map is an anchor island in an unbounded, seed-driven plane (biomes, rivers, themed towns/cities/metropolises, highways with bridges, airstrips, army outposts, resorts, ports, quarries, farms, cabins…). See ANALYSIS.md §9–13.
>
> **v3 update:** interior/sniper bug fixes, street-light control + evening glow, flyable helicopters (cheat menu), seeded procedural Frontier (768² world) — see ANALYSIS.md §5–8.
>
> **v2 update:** realistic lighting (ambient-multiply model), reliable vehicle summons, and a **9× larger single world** — Port Meridian plus Sol Costa, Fort Granite (army base), Saguaro Springs, Aurelia, Skyline International Airport, Pine Ridge, Ambrose Valley and Bayou Rouge & the Keys; 17 new interiors, 10 new vehicles, fast-travel flights. See **ANALYSIS.md** for the full analysis, changes, and the infinite-procedural-generation (No Man's Sky) discussion.

Original setting (Port Meridian, 1986), story, characters, art and audio. Everything is generated in code: tiles, buildings, vehicles, characters, UI, all sound effects and all music (Web Audio API). No external assets.

## How to run
* **Built game:** `npm run build`, then open / serve `dist/index.html`. Vite's single-file plugin inlines all JS/CSS, so it is one self-contained file. Open it directly from disk and it runs.
* **Dev:** `npm run dev`.
* *Trade-off note:* the brief asked for "no build step". This project template is a Vite + React shell, so the game is plain ES-module JavaScript in `src/game/*.js`, mounted by a 10-line React component. The game code has no dependency on React.

## Phase 0 — design doc
* **Title:** NEON TIDE. **Setting:** Port Meridian, 1986 — rain, neon, harbor cranes, five districts.
* **Protagonist:** Ray "Rook" Navarro, just out of Larkhaven prison after taking the fall for the Meridian Savings job.
* **Cast:** Gus Prieto (mentor, garage owner), Nina Zhao (crime reporter), Vance Kessler (rival, Docks boss), Juno (Chrome Vipers), Tiny (informant). Twist: Gus planned the job and framed Rook. Three endings: *The Tide Turns* (kill Gus), *Clean Slate* (turn him in), *Neon Crown* (take over).
* **Core loop:** steal a car → take work → cause trouble → heat → escape → spend → upgrade → bigger work.
* **Art direction:** neon-noir top-down 2.5D (roofs offset by building height, facades with lit windows), dynamic lightmap, bloom, rain.

### Signature ideas
1. **Tidal Focus + Style meter** — drifts, near-misses and kills fill a meter; press **F** to slow time (abilities unlock with total skill level).
2. **Living news & heat map** — crimes heat up individual blocks (shown on the map) and feed procedurally written headlines in the phone's Ledger app; radio DJs read the latest headline.
3. **Reputation economy** — gang reputation changes who shoots first, and gives (or removes) a street-cred discount in every shop.
4. **Turf wars** — gang blocks change hands dynamically; join a fight to tip it and shift reputation.
5. **Cop vision model** — cone-of-vision, shared last-known-position, search phase and cooldown; night, rain and stealth skill all shorten how long cops hunt you.

### Architecture (text diagram)
```
App.tsx → game/main.js (boot/dispose)
           └─ game.js  state · fixed 60 Hz loop · interaction · save/load · env/weather · cheats
               ├─ input.js       keyboard/mouse/gamepad/touch + rebinding
               ├─ audio.js       synth SFX · engines · Doppler siren · ambience · 4 radio stations · adaptive score
               ├─ world.js       seeded city gen · tiles · chunks' data · props · collision · A*
               ├─ gfx.js         chunk canvases · building/prop/vehicle sprites · characters · minimap overview
               ├─ render.js      camera · layered draw · lightmap · weather · post FX · quality presets
               ├─ actors.js      Actor/Vehicle pools · car physics · player control · enter/exit · collisions
               ├─ combat.js      weapons · bullets · melee · explosions · fire · damage · destructible props
               ├─ ai.js          pedestrians · combat AI · traffic & lights · police · helicopter · events · turf wars
               ├─ wanted.js      crime/witness system, stars, evade
               ├─ missions.js    12 story missions (step state machine) + side jobs + arena + theft list
               ├─ interiors.js   14 enterable interior types
               ├─ ui.js          HUD · minimap · map · phone · shops · settings · mini-games
               └─ data.js        weapons · vehicles · missions · dialogue · radio · shops
```

## Controls (all rebindable in Settings)
| Action | Default |
|---|---|
| Move / Sprint / Roll / Vault | WASD / Shift / V / Space |
| Aim / Fire / Scope | Mouse / LMB / RMB |
| Reload / Cover / Weapon wheel | R / C / hold Q (or mouse wheel) |
| Interact, enter vehicle, doors | E (parked cars: hotwire mini-game with arrow keys/WASD) |
| Drive | W gas · S brake/reverse · A/D steer · Space handbrake · H horn · G siren · X radio |
| Tidal Focus | F |
| Phone / Map / Pause | Tab / M / Esc |
| Debug overlay / Cheat menu | F3 / \` (backquote) or F2 |
Gamepad: sticks move/aim (with aim assist), RT fire, A interact, B roll, X reload, Y focus, LB/RB weapons, Start pause. Touch controls appear automatically on touch devices.

## Features
* **World:** 192×192-tile seeded city (6,144 px square) with 5 districts (Downtown, Industrial Docks, Greenfield Suburbs, Sunset Beach, Outskirts + highway), canal with bridges, piers, quay, parks, parking lots, crosswalks and traffic lights. Ground is streamed as per-chunk offscreen canvases with LRU eviction; props use a spatial hash.
* **Interiors:** shops (guns, mart, clothes, burger), bars, bank (vault), police HQ, safehouse, apartments, hospital, newsroom, casino, garage, fighting pit — fade transitions.
* **Time & weather:** day/night with sunset tints, long shadows, streetlamps, headlights, neon, muzzle flashes and explosions as lights; clear / rain (wet roads, reflections, reduced grip) / fog / storm (lightning + delayed thunder).
* **Player:** walk/run/sprint with stamina, roll, vault, swim, cover, procedural animation, hit reactions, ragdoll-lite death, character customisation and wardrobe.
* **Weapons:** fists, bat, knife, pistol, SMG, shotgun, rifle, sniper (scope), grenade, molotov, rocket launcher; distinct recoil, spread bloom, reload, ammo and sound.
* **Vehicles (14):** compact, sedan, sports, muscle, van, pickup, motorcycle, bus, taxi, police cruiser, ambulance, SWAT van, armoured APC, fire engine. Arcade physics with handbrake drift, surface/wet grip, dents, smoke, fire, explosion, skid marks painted into the ground chunks, stunt ramps, spike strips, garage customisation (paint, engine, tyres, armour, plate), engine-pitch audio.
* **AI:** pedestrians with routines (work/home/wander/jog), reactions (flee, film, phone the cops, fight back), A* pathing, separation and car-dodging; lane-following traffic that obeys lights, brakes for obstacles, honks and panics; police with patrols, cruisers, officers who unload, roadblocks, spikes, SWAT, helicopter, military; gangs and turf wars; ambient events (robbery, street race, car chase, ambulance, fire engine, protest).
* **Story & side:** 12 missions (tutorial, chase, stealth, escort, ambush with choice, bank heist, race, defense, assassination, boss fight, finale with 3 endings) plus taxi, delivery, vigilante, street race, theft list, stunt jumps, 24 collectible Tide Shards, arena fights, slots and coin-flip, 4 purchasable properties with daily income, AutoTrader vehicle purchases, bank with interest.
* **Progression:** four skills that level through use, gang reputation, abilities.
* **Audio:** all synthesized — layered engines, tire screech, impacts, weapons with convolution reverb, surface footsteps, rain/wind/crowd, Doppler sirens, stereo panning with distance falloff, 4 radio genres (synthwave, boom-bap, garage rock, techno) with ads/DJ text, adaptive score (calm → danger → chase), mixer sliders.
* **UI:** main menu, pause, settings (quality presets, audio, rebinding, colour-blind filters, screen-shake toggle, flash toggle, CRT, bloom, aberration, HUD scale), tutorial hints, HUD, rotating-optional minimap, full map with turf/heat overlay and waypoints, phone (contacts, messages, news, jobs, market), loading screen with tips, photo mode (filters + PNG capture), stats screen, debug overlay.
* **Persistence:** localStorage save (manual from the pause menu or safehouse desk, autosave every 90 s when safe and after missions).

## Cheat / debug menu (F2 or \`)
Money, heal, all weapons, invincibility, skip mission step, collect shards, spawn any vehicle, set wanted level, set time, set weather, teleport to any POI or waypoint, trigger gang war / random event, unlock all missions.

## Known limitations
* Boats, bicycles and a flyable helicopter were cut (the police helicopter is an enemy). The time went into polish of driving, police and lighting.
* Elevation is faked (canal bridges, stunt ramps, airborne scaling/shadows) rather than true multi-level roads.
* Audio can't start until the first click/key (browser policy) — the menu click does that.
* Software-rendered headless browsers run at ~20 fps; a GPU-accelerated browser is expected to hold 60 fps on High; use Low/Medium otherwise.
* Interiors pause the outdoor simulation.

## Roadmap
Boats and piers gameplay, multi-storey roads, more interiors per building, branching mission outcomes beyond Tiny/ending, multiplayer-free "heat director" tuning, mod-friendly mission JSON.

## Final self-review checklist
- [x] `npm run build` succeeds; the page launches to the main menu with no console errors.
- [x] New game → character creator → tutorial mission; save/continue wired.
- [x] Headless-browser tests exercised: menu, character creation, dialogue, walking/sprinting, hotwire and driving, shooting, rockets, wanted 4★ with cops/helicopter/storm/night, bank interior, phone, map, cheat menu, and a walk-through of **every step of all 12 missions** reaching an ending (no exceptions).
- [x] Systems verified present: chunk streaming, spatial hash, A*, traffic lights, lighting, weather, audio, settings, rebinding, photo mode, stats.
- [ ] Not verified in automation: long-session balance, real GPU performance, gamepad/touch hardware.

## v7
Flyable helicopters at the military base and heliport, three new aeroplanes (Sparrow, Cropmaster, Falcon), a dedicated mobile aircraft control set (▲ ▼ 🚀 FIRE LAND/BRAKE + ALT/THR gauges), a decluttered phone world map, a world audit/self-repair pass, new procedural props, and four new jobs (Sky Rings, Air Courier, Heli Medevac, Street Trial). See ANALYSIS.md → "v7 Update Notes".
