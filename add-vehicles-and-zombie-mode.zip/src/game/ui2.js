// ===== ui2.js — modern menus & HUD extras: main menu with save card, pause hub, journal, area banner, save indicator, touch helpers =====
import { fmtMoney } from './util.js';
import { CATS } from './atlas.js';
import { describeStyle } from './genome.js';
import { bkey } from './keys.js';
import { wipeAll } from './store.js';
import { airInfo } from './heli.js';

const ago = (t) => { const s = Math.max(0, Math.round((Date.now() - t) / 1000)); return s < 5 ? 'just now' : s < 60 ? s + 's ago' : s < 3600 ? Math.floor(s / 60) + ' min ago' : s < 86400 ? Math.floor(s / 3600) + ' h ago' : Math.floor(s / 86400) + ' d ago'; };
const dur = (sec) => { const m = Math.floor(sec / 60); return m >= 60 ? Math.floor(m / 60) + 'h ' + (m % 60) + 'm' : m + 'm'; };
const clock = (h) => String(Math.floor(h) % 24).padStart(2, '0') + ':' + String(Math.floor((h % 1) * 60)).padStart(2, '0');
const ICON = { place: '📍', area: '🧭', mission: '★', pin: '📌' };

export function extendUI(g, U, H) {
  const { modal, q, $, esc, hud } = H, root = g.root;

  // ---------- HUD extras ----------
  hud.insertAdjacentHTML('beforeend', `<div id="hudbtns"><button data-h="menu" aria-label="Menu">☰</button><button data-h="map" aria-label="Map">🗺</button><button data-h="phone" aria-label="Phone">☎</button></div>
    <div id="area"><small></small><b></b></div><div id="savepip">💾 saved</div>`);
  q('#hudbtns').addEventListener('click', (e) => { const a = e.target.closest('button'); if (!a || g.state !== 'play' || g.cut) return; g.audio.init(); g.audio.resume(); const k = a.dataset.h; if (g.uiOpen) U.closeAll(); if (k === 'menu') U.openPause(); else if (k === 'map') U.openMap(); else U.openPhone(); });
  let pip = 0; U.savedPing = () => { const el = q('#savepip'); if (!el) return; el.classList.add('on'); clearTimeout(pip); pip = setTimeout(() => el.classList.remove('on'), 1100); };
  let lastBanner = null;
  U.tick = (dt) => {
    const b = g.areaBanner, el = q('#area'); if (!el) return;
    if (b && b.t > 0 && g.state === 'play') { b.t -= dt; if (lastBanner !== b) { lastBanner = b; $('small', el).textContent = b.sub; $('b', el).textContent = b.text; el.classList.remove('show'); void el.offsetWidth; el.classList.add('show'); } } else if (!b || b.t <= 0) el.classList.remove('show');
    const playing = g.state === 'play' || g.state === 'cut'; document.body.classList.toggle('playing', playing); document.body.classList.toggle('uiopen', g.uiOpen);
    const ai = airInfo(g); document.body.classList.toggle('inair', !!ai);
    const t = g.input.touchEl;
    if (t) {
      const cl = t.classList; cl.toggle('incar', !!g.player.veh && !ai); cl.toggle('inair', !!ai); cl.toggle('inheli', !!ai && !ai.plane); cl.toggle('inplane', !!ai && ai.plane);
      cl.toggle('ac-gun', !!ai && ai.armed); cl.toggle('ac-rkt', !!ai && ai.rockets); cl.toggle('ac-aim', !!ai && ai.aim);
      if (ai) {
        const G = t._g || (t._g = { alt: t.querySelector('.gb.alt'), thr: t.querySelector('.gb.thr'), tl: t.querySelector('.gb.thr b'), rk: t.querySelector('.tb-rkt span'), last: {} });
        const L = G.last, av = Math.round(ai.alt * 100), tv = Math.round(ai.thr * 100);
        if (L.a !== av) { L.a = av; G.alt.style.setProperty('--v', av / 100); } if (L.t !== tv) { L.t = tv; G.thr.style.setProperty('--v', tv / 100); }
        if (L.k !== ai.key) { L.k = ai.key; G.tl.textContent = ai.plane ? 'THR' : 'RPM'; }
        if (L.n !== ai.n) { L.n = ai.n; if (G.rk) G.rk.textContent = '🚀 ' + ai.n; }
      }
    }
  };
  U.relayout = () => { /* modals are CSS-driven; nothing to recompute */ };

  // ---------- save card helpers ----------
  const saveInfo = () => {
    const d = g.saved && g.saved.core; if (!d) return null;
    return { cash: d.cash, day: d.env ? d.env.d : 1, hour: d.env ? d.env.h : 12, loc: d.loc || 'Port Meridian', play: d.stats ? d.stats.playTime : 0, t: d.t || 0, missions: d.stats ? d.stats.missions : 0, seed: d.seed, places: d.visited ? Object.keys(d.visited).length : 0 };
  };

  // ---------- main menu ----------
  U.showMenu = () => {
    g.state = 'menu'; U.closeAll(); hud.style.display = 'none'; const si = saveInfo();
    let m = q('#menu'); if (m) m.remove();
    root.insertAdjacentHTML('beforeend', `<div id="menu"><div class="mwrap">
      <div class="logo"><span>NEON</span><span class="b">TIDE</span></div><div class="tag">AN ENDLESS CITY · RAIN FALLS ON EVERYONE</div>
      ${si ? `<button class="savecard" data-a="continue"><div class="sc-h"><b>CONTINUE</b><span>saved ${ago(si.t)}</span></div><div class="sc-g"><span>💵 ${fmtMoney(si.cash)}</span><span>🕒 Day ${si.day} · ${clock(si.hour)}</span><span>📍 ${esc(si.loc)}</span><span>⏱ ${dur(si.play)}</span><span>★ ${si.missions}/12 missions</span><span>🧭 ${si.places} areas</span></div></button>` : ''}
      <div class="mbtns2"><button data-a="new" class="${si ? '' : 'primary'}">New Game</button><button data-a="settings">Settings</button><button data-a="controls">Controls</button><button data-a="about">How to Play</button><button data-a="full">⛶ Fullscreen</button>${si ? '<button data-a="wipe" class="danger">Delete save</button>' : ''}</div>
      <div class="seedrow">World seed <input id="seed" type="text" inputmode="numeric" value="${si ? si.seed : g.world.seed}"> <button data-a="rseed" title="random seed">🎲</button><small>Applies to New Game · same seed = same world, always</small></div>
      <div class="foot"><span class="kb">WASD move · Mouse aim/fire · E interact · M map · Esc menu</span><span class="tc">Touch: left side moves · right stick aims · buttons act</span></div>
      <div class="persist">Your world, map, place names and progress are saved continuously — refresh any time.</div></div></div>`);
    let armed = 0;
    q('#menu').addEventListener('click', (e) => {
      const el = e.target.closest('[data-a]'); const a = el && el.dataset.a; if (!a) return; g.audio.init(); g.audio.resume(); g.audio.sfx('ui');
      if (a === 'continue') { q('#menu').remove(); g.loadGame(); }
      else if (a === 'rseed') q('#seed').value = String(1 + Math.floor(Math.random() * 999999));
      else if (a === 'new') { g.pendingSeed = q('#seed') ? q('#seed').value.trim() : ''; q('#menu').remove(); U.openWardrobe(0, true); }
      else if (a === 'settings') U.openSettings(); else if (a === 'controls') U.openSettings(true); else if (a === 'about') U.openHelp();
      else if (a === 'full') { try { const d = document.documentElement; if (document.fullscreenElement) document.exitFullscreen(); else (d.requestFullscreen || d.webkitRequestFullscreen).call(d); } catch (er) { /* ignore */ } }
      else if (a === 'wipe') { if (!armed) { armed = 1; el.textContent = 'Tap again to confirm'; setTimeout(() => { armed = 0; if (el.isConnected) el.textContent = 'Delete save'; }, 3000); } else { wipeAll().then(() => { g.saved = { core: null, map: null }; U.showMenu(); }); } }
    });
  };

  // ---------- pause hub ----------
  const TILES = [['resume', '▶', 'Resume', 'Back to the city'], ['map', '🗺', 'Map', 'Places, search, pins'], ['journal', '📖', 'Journal', 'Places, log, pins'], ['phone', '☎', 'Phone', 'Jobs, news, properties'], ['stats', '📊', 'Stats & Skills', 'Progress'], ['save', '💾', 'Save now', 'Auto-saves every 4 s'],
    ['settings', '⚙', 'Settings', 'Graphics, audio, touch'], ['photo', '📷', 'Photo mode', 'Capture the city'], ['cheats', '⌘', 'Cheat menu', 'Spawn, travel, time'], ['quit', '⏏', 'Main menu', 'Saves first']];
  U.openPause = () => {
    const p = g.player, loc = g.scene ? g.scene.building.name || 'Interior' : g.world.areaName(p.x, p.y), st = g.saved && g.saved.core ? 'saved ' + ago(g.saved.core.t) : 'not saved yet';
    const m = modal('PAUSED', `<div class="hub"><div class="hubinfo"><span>💵 ${fmtMoney(g.cash)}</span><span>🕒 Day ${g.env.day} · ${clock(g.env.hour)} · ${g.env.weather}</span><span>📍 ${esc(loc)}</span><span>⏱ ${dur(g.stats.playTime)}</span><span id="hubsaved">💾 ${st}</span></div>
      <div class="hubgrid">${TILES.map(([k, i, n, s]) => `<button class="tile" data-a="${k}"><i>${i}</i><b>${n}</b><small>${s}</small></button>`).join('')}</div></div>`, { wide: true });
    m.classList.add('hubmodal');
    m.addEventListener('click', (e) => {
      const el = e.target.closest('[data-a]'); const a = el && el.dataset.a; if (!a) return;
      if (a === 'resume') U.close(); else if (a === 'map') { U.close(); U.openMap(); } else if (a === 'journal') { U.close(); U.openJournal(); } else if (a === 'phone') { U.close(); U.openPhone(); } else if (a === 'stats') U.openStats();
      else if (a === 'save') { g.saveGame(true); const s = $('#hubsaved', m); if (s) s.textContent = '💾 saved just now'; } else if (a === 'photo') { U.closeAll(); g.enterPhoto(); } else if (a === 'settings') U.openSettings(); else if (a === 'cheats') { U.close(); U.openCheats(); }
      else if (a === 'quit') { U.closeAll(); g.toMenu(); }
    });
  };

  // ---------- journal ----------
  U.openJournal = (tab = 'places') => {
    const m = modal('JOURNAL', `<div class="jr"><div class="tabs">${[['places', '🧭 Visited'], ['sites', '📍 Known places'], ['log', '📖 Log'], ['pins', '📌 Pins'], ['style', '🎨 Area style']].map(([k, n]) => `<button data-t="${k}" class="${k === tab ? 'on' : ''}">${n}</button>`).join('')}</div>
      <input id="jsearch" type="search" placeholder="Search…" autocomplete="off"><div id="jlist" class="jlist"></div></div>`, { wide: true });
    m.classList.add('jrmodal'); let cur = tab; const list = $('#jlist', m), inp = $('#jsearch', m);
    const row = (icon, title, sub, x, y, extra = '') => `<div class="jrow"><i>${icon}</i><div><b>${esc(title)}</b><small>${esc(sub || '')}</small></div>${x === undefined ? '' : `<button data-wp="${Math.round(x)},${Math.round(y)}" title="Set waypoint">⌖</button>`}${extra}</div>`;
    const render = () => {
      const f = inp.value.trim().toLowerCase(), w = g.world, out = [];
      if (cur === 'places') {
        const arr = Object.entries(g.visited || {}).filter(([n]) => !f || n.toLowerCase().includes(f)).sort((a, b) => b[1].c - a[1].c).slice(0, 250);
        for (const [n, e] of arr) out.push(row('🧭', n, `first seen ${e.f} · ${e.c} visit${e.c > 1 ? 's' : ''}${e.l ? ' · last ' + e.l : ''}`, e.x, e.y));
        if (!arr.length) out.push('<p class="empty">Nothing here yet — explore!</p>');
      } else if (cur === 'sites') {
        const seen = [];
        for (const s of w.atlas.sites.values()) { if (!(w.explored.has(bkey(Math.floor(s.x / 512), Math.floor(s.y / 512))) || g.disc[s.key])) continue; if (f && !s.name.toLowerCase().includes(f) && !s.cat.includes(f)) continue; seen.push(s); }
        seen.sort((a, b) => a.tier - b.tier || a.name.localeCompare(b.name));
        const px = g.player.x, py = g.player.y;
        for (const s of seen.slice(0, 300)) { const c = CATS[s.cat] || CATS.landmark, d = Math.round(Math.hypot(s.x - px, s.y - py) / 32 * 1.6); out.push(row(c.icon || '•', s.name, `${s.cat} · ${d >= 1000 ? (d / 1000).toFixed(1) + ' km' : d + ' m'} away`, s.x, s.y)); }
        if (!seen.length) out.push('<p class="empty">No places match.</p>'); else if (seen.length > 300) out.push(`<p class="empty">…and ${seen.length - 300} more — use search.</p>`);
      } else if (cur === 'log') {
        const arr = (g.journal || []).filter((e) => !f || e.text.toLowerCase().includes(f)).slice(-200).reverse();
        for (const e of arr) out.push(row(ICON[e.k] || '•', e.text, e.t, e.x, e.y));
        if (!arr.length) out.push('<p class="empty">Your story starts here.</p>');
      } else if (cur === 'pins') {
        const arr = (g.pins || []).filter((p) => !f || p.n.toLowerCase().includes(f));
        for (const p of arr) out.push(row('📌', p.n, `${Math.round(p.x / 32)}, ${Math.round(p.y / 32)} tiles`, p.x, p.y, `<button data-delpin="${p.id}" title="Delete pin">🗑</button>`));
        out.push(`<div class="jrow add"><input id="pinname" type="text" placeholder="Name for a pin at your position" maxlength="28"><button data-addpin>＋ Drop pin here</button></div>`);
      } else {
        const p = g.player, d = describeStyle(p.x, p.y, w.seed || 1), nm = ['Wealth', 'Age', 'Density', 'Ornament', 'Order', 'Novelty'];
        out.push(`<div class="style"><h4>${esc(w.areaName(p.x, p.y))}</h4><p>${d.wealth} · ${d.age} · ${d.density} · ${d.ornament} · ${d.order} · ${d.novelty}</p>${d.vec.map((v, i) => `<div class="sbar"><span>${nm[i]}</span><div><i style="width:${Math.round(v * 100)}%"></i></div><em>${Math.round(v * 100)}</em></div>`).join('')}<small>Every building facade, roof, palette, outfit and behaviour around you is sampled from this six-dimensional style field (see ANALYSIS.md §20).</small></div>`);
      }
      list.innerHTML = out.join('');
    };
    m.addEventListener('click', (e) => {
      const t = e.target.closest('[data-t]'); if (t) { cur = t.dataset.t; m.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b === t)); inp.style.display = cur === 'style' ? 'none' : ''; inp.value = ''; render(); return; }
      const wp = e.target.closest('[data-wp]'); if (wp) { const [x, y] = wp.dataset.wp.split(',').map(Number); g.waypoint = { x, y }; g.toast('Waypoint set', '#7cff4f'); g.audio.sfx('ui'); return; }
      const dp = e.target.closest('[data-delpin]'); if (dp) { g.pins = (g.pins || []).filter((p) => String(p.id) !== dp.dataset.delpin); render(); return; }
      if (e.target.closest('[data-addpin]')) { const n = ($('#pinname', m).value || '').trim() || 'Pin ' + ((g.pins || []).length + 1); U.addPin(n, g.player.x, g.player.y); render(); }
    });
    inp.addEventListener('input', render); render();
  };
  U.addPin = (name, x, y) => { g.pins = g.pins || []; const id = Date.now() % 1e9 + g.pins.length; g.pins.push({ id, n: String(name).slice(0, 28), x: Math.round(x), y: Math.round(y) }); if (g.pins.length > 80) g.pins.shift(); g.toast('Pinned: ' + name, '#ffd24a'); g.audio.sfx('ui'); g.saveGame(false); return id; };

  // ---------- touch-friendly hotwire pad ----------
  const hw = q('#hotwire'); if (hw) {
    hw.insertAdjacentHTML('beforeend', '<div class="hw-pad">' + [['ArrowUp', '↑'], ['ArrowLeft', '←'], ['ArrowDown', '↓'], ['ArrowRight', '→']].map(([c, t]) => `<button data-hk="${c}">${t}</button>`).join('') + '</div>');
    hw.addEventListener('pointerdown', (e) => { const b = e.target.closest('[data-hk]'); if (b) { e.preventDefault(); U.hotKeys.push(b.dataset.hk); } });
  }
}

/** touch wording for the tutorial strip & prompts */
export function touchText(s) {
  return String(s).replace(/Move with <b>WASD<\/b>/, 'Drag on the <b>left side</b> of the screen to move').replace(/Hold <b>Shift<\/b> while moving to sprint/, 'Hold <b>»</b> while moving to sprint')
    .replace(/Aim with the mouse, <b>left-click<\/b> to punch \/ fire/, 'Push the <b>AIM stick</b> to aim, tap <b>FIRE</b> to punch / shoot').replace(/Press <b>V<\/b> to dodge-roll/, 'Tap <b>↻</b> to dodge-roll')
    .replace(/Walk to a car and press <b>E<\/b> — hotwire it with the arrow keys/, 'Walk to a car and tap <b>E</b> — hotwire it with the arrow pad').replace(/<b>W\/S<\/b> gas & brake · <b>A\/D<\/b> steer · <b>Space<\/b> handbrake to drift · <b>H<\/b> horn · <b>X<\/b> radio/, '<b>Stick</b> steers &amp; drives · <b>BRAKE</b> to drift · 📣 horn · ♪ radio')
    .replace(/<b>Tab<\/b> opens your phone · <b>M<\/b> the map/, 'Top-right: <b>☎</b> phone · <b>🗺</b> map · <b>☰</b> menu').replace(/\[(E|e|F)\]/g, 'Tap $1:').replace(/\[Space\]/g, '[BRAKE]');
}
