// ===== ai.js — pedestrian routines & reactions, combat AI, traffic, police, population, events, gangs =====
import { T, M, TS, WS, NB } from './world.js';
import { TRAFFIC_TYPES, TRAFFIC_BY, GANGS, WEAPONS } from './data.js';
import { clamp, rnd, pick, chance, angDiff, rotToward, TAU } from './util.js';
import { stepActor, deadStep, spawnActor, spawnVehicle } from './actors.js';
import { fireWeapon } from './combat.js';
import { crime, setStars } from './wanted.js';

const DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]];
const WALK = [T.SIDEWALK, T.PLAZA, T.PATH, T.SAND, T.WOOD, T.QUAY, T.DESERT, T.GRAVEL, T.TURF, T.CONCRETE, T.TARMAC, T.FOREST, T.FARM];
const hyp = Math.hypot;

// ---------- shared helpers ----------
export function isFoe(g, a, b) {
  const fa = a.fac, fb = b.fac; if (fa === fb || a.dead || b.dead) return false;
  if (b === g.player) {
    if (a.ally) return false;
    if (a.mis && fa !== 'civ') return true;
    if (fa === 'pd') return g.wanted.stars > 0;
    if (fa === 'kes') return true;
    if (fa === 'civ') return a.st === 'fight';
    return a.provoked || g.rep[fa] < -20 || a.war;
  }
  if (a.ally) return (fb === 'kes' || (b.mis && fb !== 'civ' && fb !== 'pl')) && !b.ally;
  if (b.ally) return fa === 'kes' || (a.mis && fa !== 'civ');
  if (a.war && b.war) return true;
  if (a.mis && b.mis && a.fac !== b.fac && a.fac !== 'civ' && b.fac !== 'civ') return true;
  return false;
}
function findFoe(g, a) {
  const p = g.player; let best = null, bd = 1e9;
  if (isFoe(g, a, p) && p.inside === a.inside) { best = p; bd = hyp(p.x - a.x, p.y - a.y); }
  if (a.war || a.ally || g.hasAllies || a.mis) {
    g._fq = g._fq || []; g._fq.length = 0; g.hashA.query(a.x, a.y, 420, g._fq);
    for (const b of g._fq) { if (!b.on || b.dead || b === a || b.inside !== a.inside || !isFoe(g, a, b)) continue; const d = hyp(b.x - a.x, b.y - a.y); if (d < bd && g.lineClear(a.x, a.y, b.x, b.y)) { bd = d; best = b; } }
  }
  return best;
}
function canSee(g, a, tx, ty, range, fov) {
  const dx = tx - a.x, dy = ty - a.y, d = hyp(dx, dy); if (d > range) return false;
  if (fov < 6 && Math.abs(angDiff(a.a, Math.atan2(dy, dx))) > fov / 2 && d > 40) return false;
  return g.lineClear(a.x, a.y, tx, ty);
}
function sepVec(g, a) {
  let sx = 0, sy = 0; g._sq = g._sq || []; g._sq.length = 0; g.hashA.query(a.x, a.y, 30, g._sq);
  for (const b of g._sq) { if (b === a || !b.on || b.dead || b.veh) continue; const dx = a.x - b.x, dy = a.y - b.y, d2 = dx * dx + dy * dy; if (d2 < 484 && d2 > 0.01) { const d = Math.sqrt(d2); sx += (dx / d) * (22 - d) / 22; sy += (dy / d) * (22 - d) / 22; } }
  return [sx, sy];
}
function dodgeVehicles(g, a) {
  let ox = 0, oy = 0; g._dq = g._dq || []; g._dq.length = 0; g.hashV.query(a.x, a.y, 110, g._dq);
  for (const v of g._dq) {
    if (!v.on) continue; const sp = hyp(v.vx, v.vy); if (sp < 90) continue;
    const dx = a.x - v.x, dy = a.y - v.y, f = (dx * v.vx + dy * v.vy) / sp, l = (-dx * v.vy + dy * v.vx) / sp;
    if (f > -10 && f < 90 + sp * 0.25 && Math.abs(l) < 38) { const s = l >= 0 ? 1 : -1; ox += (-v.vy / sp) * s * 1.6; oy += (v.vx / sp) * s * 1.6; a.fear = Math.max(a.fear, 0.35); }
  }
  return [ox, oy];
}
function goTo(g, a, x, y, opt) {
  if (g.scene) { a.path = [{ x, y }]; a.pi = 0; return true; }
  a.path = g.world.path(a.x, a.y, x, y, opt || { max: 520 }); a.pi = 0; a.goal = { x, y }; a.stuck = 0; a.sx = a.x; a.sy = a.y;
  return !!(a.path && a.path.length);
}
function followPath(g, a, dt, speed) {
  if (!a.path || a.pi >= a.path.length) return true;
  const n = a.path[a.pi], dx = n.x - a.x, dy = n.y - a.y, d = hyp(dx, dy);
  if (d < 12) { a.pi++; return a.pi >= a.path.length; }
  let mx = dx / d, my = dy / d; const [sx, sy] = sepVec(g, a), [ox, oy] = dodgeVehicles(g, a);
  mx += sx * 0.8 + ox; my += sy * 0.8 + oy; const l = hyp(mx, my) || 1; mx /= l; my /= l;
  a.a = rotToward(a.a, Math.atan2(my, mx), 9 * dt); stepActor(g, a, dt, mx, my, speed);
  a.stuck += dt; if (a.stuck > 1.2) { if (hyp(a.x - a.sx, a.y - a.sy) < 8) { a.path = null; return true; } a.stuck = 0; a.sx = a.x; a.sy = a.y; }
  return false;
}
const night = (g) => g.env.dark > 0.55;

// ---------- actor AI entry ----------
export function updateActorsAI(g, dt) {
  const p = g.player;
  for (const a of g.actors) {
    if (!a.on || a === p) continue;
    if (a.inside !== g.insideId) continue;
    const dp = hyp(a.x - p.x, a.y - p.y);
    if (a.dead) { deadStep(g, a, dt); if (a.deadT > 40 && dp > 700 && !a.mis) a.on = false; continue; }
    if (dp > 1500 && !a.mis) { a.on = false; continue; }
    // noises
    for (const n of g.noises) { const d = hyp(a.x - n.x, a.y - n.y); if (d < n.r) hear(g, a, n, d); }
    if (a.fear > 0) a.fear = Math.max(0, a.fear - dt * 0.1);
    if (a.fac === 'civ' && !a.mis && a.st !== 'fight') civ(g, a, dt); else armed(g, a, dt);
    if (a.on && a.hp > 0 && a.fac !== 'civ') a.a = a.a;
  }
}
function hear(g, a, n, d) {
  const src = n.src && n.src.by;
  if (a.fac === 'civ') { a.fear = Math.min(1, a.fear + 1.1 * (1 - d / n.r)); if (src === g.player || src) a.threat = src; }
  else if (a.st !== 'combat' && (a.fac === 'kes' || a.fac === 'pd' || a.mis || a.war || GANGS.some((x) => x.id === a.fac)) && src === g.player && d < n.r * 0.7 && isFoe(g, a, g.player)) { a.alert = Math.max(a.alert, 0.5); a.lastKnownX = n.x; a.lastKnownY = n.y; }
}

// ---------- civilians ----------
function pickGoal(g, a) {
  const h = g.env.hour; let r = null;
  const doors = g.world.doorList;
  if ((h >= 22 || h < 5) && a.home && chance(0.7)) { a.goalDoor = true; r = a.home; }
  else if (h >= 7 && h < 9.5 && a.work && chance(0.7)) { a.goalDoor = true; r = a.work; }
  else if (a.role === 'jogger') { r = g.world.randomWalkable(a.x, a.y, 600, [T.WOOD, T.SAND, T.SIDEWALK]); }
  else { a.goalDoor = false; r = g.world.randomWalkable(a.x, a.y, 420 + Math.random() * 500, WALK); if (!r && doors.length) r = pick(doors); }
  if (!r) return false; return goTo(g, a, r.x, r.y, { max: 520 });
}
function civ(g, a, dt) {
  const p = g.player;
  switch (a.st) {
    case 'idle': {
      a.t -= dt; a.moveAmt *= 0.9; stepActor(g, a, dt, 0, 0, 0);
      if (a.fear > 0.45) { react(g, a); break; }
      if (a.t <= 0) { if (pickGoal(g, a)) { a.st = 'walk'; a.speed = a.role === 'jogger' ? 150 : 62 + Math.random() * 28; } else a.t = 2; }
      break;
    }
    case 'walk': {
      if (a.fear > 0.45) { react(g, a); break; }
      if (a.phone > 0) { a.phone -= dt; stepActor(g, a, dt, 0, 0, 0); break; }
      if (followPath(g, a, dt, a.speed * (night(g) && a.drunk ? 0.7 : 1))) {
        if (a.goalDoor && a.goal && hyp(a.x - a.goal.x, a.y - a.goal.y) < 90) { if (hyp(a.x - p.x, a.y - p.y) > 400) a.on = false; else a.goalDoor = false; }
        a.st = 'idle'; a.t = 1 + Math.random() * (chance(0.3) ? 20 : 4); a.path = null;
      } else if (Math.random() < dt * 0.02) { a.phone = 3 + Math.random() * 3; }
      break;
    }
    case 'flee': {
      a.t -= dt;
      if (!a.path || a.pi >= a.path.length || a.repath <= 0) {
        const th = a.threat || p, dx = a.x - th.x, dy = a.y - th.y, d = hyp(dx, dy) || 1, r = g.world.randomWalkable(a.x + (dx / d) * 380, a.y + (dy / d) * 380, 260, WALK);
        if (r) goTo(g, a, r.x, r.y, { max: 450, road: true }); a.repath = 2;
      }
      a.repath -= dt;
      followPath(g, a, dt, 175);
      if (a.t <= 0 && a.fear < 0.3) { a.st = 'idle'; a.t = 1; a.path = null; }
      break;
    }
    case 'film': {
      a.t -= dt; stepActor(g, a, dt, 0, 0, 0); const th = a.threat || p; a.a = rotToward(a.a, Math.atan2(th.y - a.y, th.x - a.x), 5 * dt);
      if (a.fear > 0.9 || a.t <= 0) { a.st = a.fear > 0.6 ? 'flee' : 'idle'; a.t = 4; }
      break;
    }
    case 'phone': {
      a.t -= dt; stepActor(g, a, dt, 0, 0, 0);
      if (a.t <= 0) { if (g.lastViolence > 0 && g.wanted.stars < 1) { crime(g, 'assault', a.x, a.y, true); crime(g, 'shots', a.x, a.y, true); setStars(g, Math.max(1, g.wanted.stars)); } a.st = 'flee'; a.t = 8; }
      break;
    }
    case 'stay': stepActor(g, a, dt, 0, 0, 0); if (a.fear > 0.6) { a.st = 'cower'; a.crouch = true; } break;
    case 'cower': stepActor(g, a, dt, 0, 0, 0); a.crouch = a.fear > 0.15; if (!a.crouch) a.st = 'stay'; break;
    case 'protest': stepActor(g, a, dt, 0, 0, 0); a.anim += dt * 4; if (a.fear > 0.6) react(g, a); break;
    default: a.st = 'idle'; break;
  }
}
function react(g, a) {
  const p = g.player;
  if (a.brave && a.wid !== 'fists' || (a.brave && a.provoked)) { a.st = 'fight'; a.fac = 'civ'; a.target = p; a.t = 12; if (a.wid === 'fists' && chance(0.5)) { a.wid = 'bat'; a.wdef = WEAPONS.bat; } return; }
  if (a.curious && a.fear < 0.8) { a.st = 'film'; a.t = 6 + Math.random() * 6; return; }
  if (a.snitch && a.fear < 0.9) { a.st = 'phone'; a.t = 3 + Math.random() * 2; return; }
  a.st = 'flee'; a.t = 7 + Math.random() * 6; a.repath = 0; a.path = null;
}

// ---------- armed actors (police, gangs, guards, allies, fighting civs) ----------
function armed(g, a, dt) {
  const p = g.player, W = g.wanted;
  a.retarget = (a.retarget || 0) - dt;
  if (a.retarget <= 0) { a.retarget = 0.35 + Math.random() * 0.2; if (!a.manual) a.target = findFoe(g, a); }
  if (a.manual && (!a.target || a.target.dead)) a.manual = false;
  const t = a.target;
  const wd = a.wdef, isCop = a.fac === 'pd';
  const vision = (isCop ? (night(g) ? 330 : 520) : a.vis || 380) * (t === p && p.crouch ? 0.6 : 1) * (t === p ? 1 - 0.04 * g.skillLvl('stealth') : 1);
  let sees = false;
  if (t && !t.dead) {
    const fov = a.st === 'combat' ? 6.4 : (a.fov || 2.0);
    sees = canSee(g, a, t.x, t.y, a.st === 'combat' ? vision * 1.4 : vision, fov);
    if (t === p && p.veh && !isCop) sees = sees && true;
  }
  if (isCop && sees && t === p) { W.seenFrame = true; a.seen = true; } else a.seen = false;
  // detection meter
  if (a.st !== 'combat') {
    if (sees) {
      const d = hyp(t.x - a.x, t.y - a.y), rate = (1.4 - d / (vision + 1)) * 1.6 / (1 + 0.1 * g.skillLvl('stealth')) * (t === p && p.crouch ? 0.6 : 1) * (a.alertFast ? 3 : 1);
      a.alert += Math.max(0.15, rate) * dt; a.lastKnownX = t.x; a.lastKnownY = t.y;
      if (a.alert >= 1) { a.st = 'combat'; a.alert = 1; if (g.onSpotted) g.onSpotted(a); alertNearby(g, a); }
    } else a.alert = Math.max(0, a.alert - dt * 0.18);
  }
  if (a.st === 'combat') return combat(g, a, dt, t, sees);
  if (a.alert > 0.3 && a.lastKnownX) { // suspicious: turn and creep to the noise
    a.a = rotToward(a.a, Math.atan2(a.lastKnownY - a.y, a.lastKnownX - a.x), 5 * dt);
    if (a.alert > 0.5 && hyp(a.lastKnownX - a.x, a.lastKnownY - a.y) > 60) { const dx = a.lastKnownX - a.x, dy = a.lastKnownY - a.y, d = hyp(dx, dy); stepActor(g, a, dt, dx / d, dy / d, 55); return; }
  }
  // cops chasing the player know where they are even without LOS
  if (isCop && W.stars > 0) { a.st = 'combat'; a.target = p; return; }
  if (a.ally) { allyFollow(g, a, dt); return; }
  routine(g, a, dt);
}
function alertNearby(g, a) {
  for (const b of g.actors) if (b.on && !b.dead && b !== a && b.fac === a.fac && b.st !== 'combat' && hyp(b.x - a.x, b.y - a.y) < 420) { b.alert = 1; b.st = 'combat'; }
}
function routine(g, a, dt) {
  if (a.st === 'stay') { stepActor(g, a, dt, 0, 0, 0); return; }
  // patrol waypoints (guards) or idle / wander
  if (a.patrol && a.patrol.length) {
    const w = a.patrol[a.pw % a.patrol.length], dx = w.x - a.x, dy = w.y - a.y, d = hyp(dx, dy);
    if (a.t > 0) { a.t -= dt; stepActor(g, a, dt, 0, 0, 0); a.a += Math.sin(g.time * 0.8 + a.i) * 0.6 * dt; return; }
    if (d < 14) { a.pw++; a.t = 1 + Math.random() * 1.5; return; }
    a.a = rotToward(a.a, Math.atan2(dy, dx), 4 * dt); stepActor(g, a, dt, dx / d, dy / d, 55); return;
  }
  if (a.st === 'idle') { a.t -= dt; stepActor(g, a, dt, 0, 0, 0); if (a.t <= 0) { if (a.fac === 'pd' || a.fac === 'civ' || a.role === 'wander') { if (pickGoal(g, a)) { a.st = 'walk'; a.speed = 60; } else a.t = 3; } else a.t = 2 + Math.random() * 4; if (a.fac !== 'pd' && a.fac !== 'civ') a.a += rnd(-1, 1); } return; }
  if (a.st === 'walk') { if (followPath(g, a, dt, a.speed)) { a.st = 'idle'; a.t = 2 + Math.random() * 6; } return; }
  a.st = 'idle';
}
function allyFollow(g, a, dt) {
  const p = g.player, d = hyp(p.x - a.x, p.y - a.y);
  if (d > 110) { a.repath -= dt; if (a.repath <= 0 || !a.path) { goTo(g, a, p.x, p.y, { max: 450, road: true }); a.repath = 1.2; } followPath(g, a, dt, d > 260 ? 190 : 130); }
  else stepActor(g, a, dt, 0, 0, 0);
}
function combat(g, a, dt, t, sees) {
  const p = g.player, W = g.wanted, wd = a.wdef, isCop = a.fac === 'pd';
  if (!t || t.dead) {
    // search last known position, then give up
    a.t -= dt;
    const lx = isCop && W.stars > 0 ? W.lx : a.lastKnownX, ly = isCop && W.stars > 0 ? W.ly : a.lastKnownY;
    if (lx && hyp(lx - a.x, ly - a.y) > 50) {
      a.repath -= dt; if (!a.path || a.repath <= 0) { goTo(g, a, lx, ly, { max: 600, road: true }); a.repath = 1.2; }
      followPath(g, a, dt, 120);
    } else { stepActor(g, a, dt, 0, 0, 0); a.a += Math.sin(g.time * 1.5 + a.i) * dt; }
    if (!(isCop && W.stars > 0) && a.t < -9) { a.st = 'idle'; a.alert = 0; a.t = 1; } else if (a.t > 0 || !(isCop && W.stars > 0)) { /* wait */ }
    if (a.ally) { a.st = 'idle'; }
    return;
  }
  a.t = 0;
  const dx = t.x - a.x, dy = t.y - a.y, d = hyp(dx, dy), ang = Math.atan2(dy, dx);
  if (sees) { a.lastKnownX = t.x; a.lastKnownY = t.y; a.aim = rotToward(a.aim, ang, 8 * dt); a.a = rotToward(a.a, a.aim, 10 * dt); }
  const range = wd.type === 'melee' ? 20 : wd.sfx === 'shotgun' ? 130 : wd.sfx === 'pistol' ? 230 : wd.sfx === 'sniper' ? 500 : wd.sfx === 'rocket' ? 320 : 280;
  const arrest = isCop && W.stars <= 1 && t === p && !a.provoked && !g.copHostile;
  if (arrest) {
    if (d > 26) { a.repath -= dt; if (sees && g.lineClear(a.x, a.y, t.x, t.y)) { stepActor(g, a, dt, dx / d, dy / d, 140); a.a = rotToward(a.a, ang, 10 * dt); } else { if (!a.path || a.repath <= 0) { goTo(g, a, t.x, t.y, { max: 600, road: true }); a.repath = 1; } followPath(g, a, dt, 140); } }
    else { stepActor(g, a, dt, 0, 0, 0); if (!p.veh && p.hp > 0 && !g.scene) { W.busted += dt; if (W.busted > 1.5 && g.onBusted) g.onBusted(); } }
    if (!(d <= 26)) W.busted = Math.max(0, W.busted - dt * 0.3);
    return;
  }
  if (sees) {
    let mx = 0, my = 0;
    if (d > range + 40) { mx = dx / d; my = dy / d; } else if (d < range * 0.55 && wd.type !== 'melee') { mx = -dx / d; my = -dy / d; } else { mx = -dy / d * a.strafe; my = dx / d * a.strafe; if (Math.random() < dt * 0.4) a.strafe *= -1; }
    const [sx, sy] = sepVec(g, a); mx += sx; my += sy; const l = hyp(mx, my) || 1;
    const spd = d > range + 40 ? 125 : a.fac === 'pd' ? 95 : 85;
    stepActor(g, a, dt, mx / l, my / l, spd * (a.speedMul || 1));
    // fire in bursts
    a.burst -= dt;
    if (d < wd.range * 0.95 && Math.abs(angDiff(a.aim, ang)) < 0.22 && a.stun <= 0) {
      if (wd.type === 'melee') { if (d < wd.range + 6) fireWeapon(g, a); }
      else if (a.burst <= 0) { if (wd.type === 'gun' && wd.auto) { if (fireWeapon(g, a)) { a.shots = (a.shots || 0) + 1; if (a.shots > 6 + Math.random() * 5) { a.shots = 0; a.burst = 0.7 + Math.random() * 1.1; } } } else if (fireWeapon(g, a)) a.burst = 0.15 + Math.random() * 0.6; }
    }
  } else {
    a.repath -= dt;
    if (!a.path || a.repath <= 0) { goTo(g, a, a.lastKnownX || t.x, a.lastKnownY || t.y, { max: 650, road: true }); a.repath = 1; }
    if (followPath(g, a, dt, 120)) { a.t -= 0; }
  }
}

// ---------- vehicle AI ----------
function nextLight(g, v) {
  const r = nextLight0(g, v); if (!r) return null; return (g.world.metaAt(r.cx * 512 + 64, r.cy * 512 + 64) & 3) === 3 && g.world.isRoad(r.cx * 512 + 64, r.cy * 512 + 64) ? r : null;
}
function nextLight0(g, v) {
  // returns {ds, light} for the intersection ahead along v.dir (ds = distance to stop line)
  const d = v.dir;
  const cxL = clamp(Math.round((v.x - 64) / 512), 0, NB - 1), cyL = clamp(Math.round((v.y - 64) / 512), 0, NB - 1);
  if (d === 3) { const cy = Math.floor((v.y - 128) / 512); return cy < 0 ? null : { ds: v.y - (cy * 512 + 128), l: g.world.trafficLight(cxL, cy, g.time, true), cx: cxL, cy }; }
  if (d === 1) { const cy = Math.ceil(v.y / 512); return cy > NB - 1 ? null : { ds: cy * 512 - v.y, l: g.world.trafficLight(cxL, cy, g.time, true), cx: cxL, cy }; }
  if (d === 0) { const cx = Math.ceil(v.x / 512); return cx > NB - 1 ? null : { ds: cx * 512 - v.x, l: g.world.trafficLight(cx, cyL, g.time, false), cx, cy: cyL }; }
  const cx = Math.floor((v.x - 128) / 512); return cx < 0 ? null : { ds: v.x - (cx * 512 + 128), l: g.world.trafficLight(cx, cyL, g.time, false), cx, cy: cyL };
}
function blockedDist(g, v, look) {
  const fx = Math.cos(v.a), fy = Math.sin(v.a), hw = v.def.wid / 2 + 5; let best = look;
  g._bq = g._bq || []; g._bq.length = 0; g.hashV.query(v.x + fx * look / 2, v.y + fy * look / 2, look / 2 + 70, g._bq);
  for (const o of g._bq) {
    if (o === v || !o.on || o.z > 3) continue;
    const dx = o.x - v.x, dy = o.y - v.y, f = dx * fx + dy * fy, l = -dx * fy + dy * fx; if (f < 0) continue;
    const ext = o.def.len / 2 * Math.abs(Math.cos(o.a - v.a)) + o.def.wid / 2 * Math.abs(Math.sin(o.a - v.a));
    if (Math.abs(l) < hw + o.def.wid / 2 * 0.8 && f - ext - v.def.len / 2 < best) best = Math.max(0, f - ext - v.def.len / 2);
  }
  g._bq.length = 0; g.hashA.query(v.x + fx * look / 2, v.y + fy * look / 2, look / 2 + 30, g._bq);
  for (const a of g._bq) { if (!a.on || a.dead || a.veh) continue; const dx = a.x - v.x, dy = a.y - v.y, f = dx * fx + dy * fy, l = -dx * fy + dy * fx; if (f > 0 && Math.abs(l) < hw + a.r && f - v.def.len / 2 - a.r < best) best = Math.max(0, f - v.def.len / 2 - a.r); }
  return best;
}
function control(v, tx, ty, tgtSpeed, brakeNow) {
  const fx = Math.cos(v.a), fy = Math.sin(v.a), err = angDiff(v.a, Math.atan2(ty - v.y, tx - v.x)), vF = v.vx * fx + v.vy * fy;
  v.str = clamp(err * 2.4, -1, 1); const tgt = tgtSpeed * (1 - 0.45 * Math.min(1, Math.abs(err)));
  if (brakeNow) { v.thr = 0; v.brk = 1; return; }
  if (vF < tgt - 12) { v.thr = clamp((tgt - vF) / 70, 0.2, 1); v.brk = 0; } else if (vF > tgt + 22) { v.thr = 0; v.brk = clamp((vF - tgt) / 130, 0, 1); } else { v.thr = 0.12; v.brk = 0; }
}
function laneFollow(g, v, dt, mode, tx, ty, cruise, ignoreLights) {
  const w = g.world, tile = w.tileAt(v.x, v.y), m = w.metaAt(v.x, v.y), onRoad = tile === T.ROAD || tile === T.BRIDGE, inter = onRoad && (m & M.V) && (m & M.H);
  if (onRoad && !inter) { if ((m & M.V) && (v.dir & 1) === 0) v.dir = Math.sin(v.a) >= 0 ? 1 : 3; else if ((m & M.H) && (v.dir & 1) === 1) v.dir = Math.cos(v.a) >= 0 ? 0 : 2; }
  else if (!onRoad && !inter && !v.offroad) { v.dir = Math.round(((v.a / (Math.PI / 2)) % 4 + 4) % 4) % 4; }
  const cx = clamp(Math.round((v.x - 64) / 512), 0, NB - 1), cy = clamp(Math.round((v.y - 64) / 512), 0, NB - 1), d = DIRS[v.dir];
  const lane = v.dir & 1 ? (v.dir === 3 ? cx * 512 + 96 : cx * 512 + 32) : (v.dir === 0 ? cy * 512 + 96 : cy * 512 + 32);
  const spd = hyp(v.vx, v.vy), LA = 64 + spd * 0.26;
  const px = v.dir & 1 ? lane : v.x + d[0] * LA, py = v.dir & 1 ? v.y + d[1] * LA : lane;
  let tgt = cruise * (m & M.HWY ? 1.35 : 1);
  // intersection logic
  if (inter) {
    if (!v.inInter) { v.inInter = true; v.ex = v.x; v.ey = v.y; chooseTurn(g, v, mode, tx, ty, cx, cy); }
    if (v.turn !== null && v.turn !== undefined) {
      const trav = hyp(v.x - v.ex, v.y - v.ey), right = v.turn === (v.dir + 1) % 4;
      if (trav > (right ? 40 : 104)) { v.dir = v.turn; v.turn = null; v.ind = 0; }
    }
    tgt = Math.min(tgt, v.turn !== null && v.turn !== undefined ? 150 : tgt);
  } else { v.inInter = false; v.turn = null; }
  let stop = false;
  if (!inter && !ignoreLights) {
    const L = nextLight(g, v);
    if (L && L.l !== 0 && L.ds > 8 && L.ds < 150 && !(L.l === 1 && L.ds < 55)) { tgt = Math.min(tgt, Math.max(0, (L.ds - 14) * 2.6)); if (L.ds < 20) stop = true; }
  }
  const look = 46 + spd * 0.5, bd = blockedDist(g, v, look);
  if (bd < look) { tgt = Math.min(tgt, Math.max(0, (bd - 14) * 3)); if (bd < 16) stop = true; if (bd < 40 && spd < 8) { v.honkT += dt; if (v.honkT > 2.5) { v.honkT = 0; g.audio.sfx('honk', v.x, v.y, 0.5); g.noise(v.x, v.y, 200, {}); } } } else v.honkT = 0;
  control(v, px, py, tgt, stop && spd > 4 ? true : stop);
  if (stop && spd < 6) { v.thr = 0; v.brk = 0.6; }
}
function chooseTurn(g, v, mode, tx, ty, cx, cy) {
  const ix = cx * 512, iy = cy * 512, opts = [];
  const exits = [[ix + 168, iy + 96], [ix + 32, iy + 168], [ix - 40, iy + 32], [ix + 96, iy - 40]];
  for (const [k, w] of [[0, 6], [1, 2], [3, 2]]) {
    const dd = (v.dir + k) % 4, e = exits[dd]; if (g.world.isRoad(e[0], e[1])) { let score = w; if (mode === 'chase' || mode === 'flee') { const dist = hyp(e[0] - tx, e[1] - ty); score = mode === 'chase' ? 1e5 - dist : dist; } opts.push({ dd, k, score }); }
  }
  if (!opts.length) { // dead end: turn around via any road
    for (let k = 1; k < 4; k++) { const dd = (v.dir + k) % 4, e = exits[dd]; if (g.world.isRoad(e[0], e[1])) opts.push({ dd, k, score: 1 }); } if (!opts.length) { v.turn = null; return; }
  }
  let ch;
  if (mode === 'chase' || mode === 'flee') ch = opts.reduce((a, b) => (b.score > a.score ? b : a));
  else { let tot = opts.reduce((s, o) => s + o.score, 0), r = Math.random() * tot; ch = opts[0]; for (const o of opts) { r -= o.score; if (r <= 0) { ch = o; break; } } }
  if (ch.dd === v.dir) v.turn = null; else { v.turn = ch.dd; v.ind = 2; v.turnDir = ch.k === 1 ? 1 : -1; }
}
function driveToward(g, v, dt, tx, ty, speed, avoidCars) {
  const fx = Math.cos(v.a), fy = Math.sin(v.a), spd = hyp(v.vx, v.vy);
  let aim = Math.atan2(ty - v.y, tx - v.x);
  const L = 70 + spd * 0.3;
  for (const off of [0, 0.5, -0.5]) { const a = v.a + off; if (g.world.solid(v.x + Math.cos(a) * L, v.y + Math.sin(a) * L)) { if (off === 0) { const lc = g.world.solid(v.x + Math.cos(v.a - 0.6) * L, v.y + Math.sin(v.a - 0.6) * L), rc = g.world.solid(v.x + Math.cos(v.a + 0.6) * L, v.y + Math.sin(v.a + 0.6) * L); aim = v.a + (lc && !rc ? 0.9 : rc && !lc ? -0.9 : 0.9); } else aim = v.a - off * 1.4; break; } }
  void fx; void fy;
  const px = v.x + Math.cos(aim) * 100, py = v.y + Math.sin(aim) * 100; let tgt = speed;
  if (avoidCars) { const bd = blockedDist(g, v, 50 + spd * 0.4); if (bd < 60) tgt = Math.min(tgt, Math.max(30, (bd - 8) * 3)); }
  control(v, px, py, tgt, false);
}
export function updateVehicleAI(g, v, dt) {
  if (!v.on || v.wreck || v.driver) return;
  const p = g.player, W = g.wanted, dp = hyp(v.x - p.x, v.y - p.y);
  const vF = v.vx * Math.cos(v.a) + v.vy * Math.sin(v.a);
  if (v.rev > 0) { v.rev -= dt; v.thr = -1; v.brk = 0; v.str = -Math.sign(v.str || 1) * 0.8; return; }
  switch (v.ai) {
    case 'traffic': {
      let mode = v.mode || 'random', cruise = v.cruise || 230, ig = false, tx = p.x, ty = p.y;
      if (v.panic > 0) { cruise *= 1.55; ig = true; if (Math.random() < dt) g.audio.sfx('honk', v.x, v.y, 0.4); }
      if (v.mode === 'flee') { cruise = v.def.vmax * 0.66 * v.speedMul; ig = true; }
      if (v.mode === 'race') { cruise = 360; ig = true; }
      if (v.mode === 'flee' && dp < 150 && !v.offroad) { /* keep running */ }
      laneFollow(g, v, dt, mode === 'flee' ? 'flee' : mode, tx, ty, cruise, ig);
      if (v.panic > 0) v.str = clamp(v.str + Math.sin(g.time * 6 + v.i) * 0.25, -1, 1);
      break;
    }
    case 'police': policeAI(g, v, dt, dp); break;
    case 'respond': {
      const t = v.tgt; if (!t) { v.ai = 'traffic'; break; }
      const dd = hyp(t.x - v.x, t.y - v.y); v.siren = true;
      if (dd < 110) { v.ai = 'park'; v.parkT = 8; v.brk = 1; v.thr = 0; if (v.def.shape === 'fire') g.extinguish(t.x, t.y); else g.medic(t.x, t.y); break; }
      if (dd < 280 && g.world.lineClear(v.x, v.y, t.x, t.y)) driveToward(g, v, dt, t.x, t.y, 280, true); else laneFollow(g, v, dt, 'chase', t.x, t.y, 300, true);
      break;
    }
    case 'park': { v.thr = 0; v.brk = 1; if (v.parkT !== undefined) { v.parkT -= dt; if (v.parkT <= 0 && !v.unloaded) { v.ai = 'traffic'; v.siren = false; v.parkT = undefined; } } if (v.unloaded && (W.stars === 0 || dp > 850) && v.cop) { v.unloaded = false; v.ai = 'police'; } break; }
    case 'block': v.thr = 0; v.brk = 1; break;
    case 'racer': { const t = v.tgt; if (!t) break; driveToward(g, v, dt, t.x, t.y, v.def.vmax * 0.8 * v.speedMul, true); break; }
    case 'hunter': {
      const cruise = v.def.vmax * 0.68 * v.speedMul, los = g.world.lineClear(v.x, v.y, p.x, p.y);
      if (dp < 500 && los) driveToward(g, v, dt, p.x + (p.veh ? p.veh.vx * 0.3 : 0), p.y + (p.veh ? p.veh.vy * 0.3 : 0), cruise * 1.25, true); else laneFollow(g, v, dt, 'chase', p.x, p.y, cruise, true);
      if (v.gunner && dp < 430 && los && !g.scene) { v.gun -= dt; if (v.gun <= 0) { v.gun = 0.4; const a = Math.atan2(p.y - v.y, p.x - v.x) + rnd(-0.12, 0.12); g.bullets.spawn({ x: v.x + Math.cos(a) * 30, y: v.y + Math.sin(a) * 30, vx: Math.cos(a) * 1100, vy: Math.sin(a) * 1100, dmg: 6, owner: null, ownerV: v, fac: 'kes', life: 600, kind: 'b', rad: 0 }); g.audio.sfx('smg', v.x, v.y, 0.5); } }
      if (dp > 1700 && !v.mis) v.on = false; break;
    }
    default: return;
  }
  // stuck detection
  if (Math.abs(vF) < 14 && v.thr > 0.3 && v.ai !== 'park') { v.stuck += dt; if (v.stuck > 1.6) { v.rev = 1; v.stuck = 0; } } else v.stuck = Math.max(0, v.stuck - dt);
}
function policeAI(g, v, dt, dp) {
  const p = g.player, W = g.wanted; v.siren = W.stars > 0 || !!v.tgtV;
  if (W.stars === 0 && !v.tgtV) { v.mode = 'random'; laneFollow(g, v, dt, 'random', 0, 0, 215, false); return; }
  const tv = v.tgtV && v.tgtV.on && !v.tgtV.wreck ? v.tgtV : null, tgt = tv || p;
  if (!tv) {
    if (dp < (night(g) ? 420 : 620) && g.world.lineClear(v.x, v.y, p.x, p.y) && !g.scene) { W.seenFrame = true; v.spotted = true; } else v.spotted = false;
  }
  const px = tv ? tv.x : (v.spotted ? p.x + (p.veh ? p.veh.vx * 0.35 : 0) : W.lx), py = tv ? tv.y : (v.spotted ? p.y + (p.veh ? p.veh.vy * 0.35 : 0) : W.ly);
  const dd = hyp(px - v.x, py - v.y), cruise = v.def.vmax * (0.62 + 0.04 * W.stars) * v.speedMul;
  // unload officers at the scene
  const ps = p.veh ? hyp(p.veh.vx, p.veh.vy) : hyp(p.vx, p.vy);
  if (!tv && dd < 150 && ps < 90 && v.spotted && !v.unloaded) {
    v.thr = 0; v.brk = 1; if (hyp(v.vx, v.vy) < 25) { v.unloaded = true; v.ai = 'park'; v.parkT = undefined; g.unloadCops(v); } return;
  }
  if (v.spotted && dd < 520 || tv && dd < 420) { driveToward(g, v, dt, px, py, cruise * 1.25, W.stars < 3 && !tv); }
  else laneFollow(g, v, dt, 'chase', px, py, cruise, true);
  if (v.gunner && v.spotted && dp < 460 && !g.scene) {
    v.gun -= dt; if (v.gun <= 0) { v.gun = 0.28; const a = Math.atan2(p.y - v.y, p.x - v.x) + rnd(-0.12, 0.12); g.bullets.spawn({ x: v.x + Math.cos(a) * 30, y: v.y + Math.sin(a) * 30, vx: Math.cos(a) * 1200, vy: Math.sin(a) * 1200, dmg: 5 + W.stars, owner: null, ownerV: v, fac: 'pd', life: 600, kind: 'b', rad: 0 }); g.audio.sfx('smg', v.x, v.y, 0.5); v.gunA = a - v.a; }
  }
}
export function unloadCops(g, v) {
  const n = v.def.shape === 'swat' ? 3 : 2, W = g.wanted;
  for (let i = 0; i < n; i++) {
    const side = i % 2 ? 1 : -1, x = v.x - Math.sin(v.a) * (v.def.wid / 2 + 14) * side * -1 + Math.cos(v.a) * (i - 1) * 12, y = v.y + Math.cos(v.a) * (v.def.wid / 2 + 14) * side * -1 + Math.sin(v.a) * (i - 1) * 12;
    const sw = v.def.shape === 'swat' || W.stars >= 4, w = W.stars >= 4 ? 'rifle' : W.stars >= 3 ? (sw ? 'rifle' : 'smg') : W.stars >= 2 ? 'smg' : 'pistol';
    const a = spawnActor(g, sw ? 'swat' : 'cop', x, y, { fac: 'pd', w, hp: sw ? 140 : 100, armor: sw ? 40 : 0 }); if (a) { a.st = 'combat'; a.target = g.player; a.alert = 1; }
  }
}

// ---------- spawning & population ----------
function inView(g, x, y, pad = 80) { return Math.abs(x - g.cam.x) < g.viewW / 2 + pad && Math.abs(y - g.cam.y) < g.viewH / 2 + pad; }
export function randomLaneSpawn(g, minD, maxD) {
  const p = g.player;
  for (let k = 0; k < 10; k++) {
    const ang = Math.random() * TAU, d = minD + Math.random() * (maxD - minD), x = p.x + Math.cos(ang) * d, y = p.y + Math.sin(ang) * d;
    if (x < 100 || y < 100 || x > WS - 200 || y > WS - 200) continue;
    const vert = Math.random() < 0.5, line = vert ? clamp(Math.round((x - 64) / 512), 0, NB - 1) : clamp(Math.round((y - 64) / 512), 0, NB - 1), east = Math.random() < 0.5;
    let sx, sy, dir;
    if (vert) { dir = east ? 3 : 1; sx = line * 512 + (east ? 96 : 32); sy = y; } else { dir = east ? 0 : 2; sx = x; sy = line * 512 + (east ? 96 : 32); }
    const m = g.world.metaAt(sx, sy); if (!g.world.isRoad(sx, sy) || ((m & M.V) && (m & M.H)) || inView(g, sx, sy, 40)) continue;
    if (hyp(sx - p.x, sy - p.y) < minD * 0.9) continue;
    return { x: sx, y: sy, dir };
  }
  return null;
}
const DENS = { downtown: 1, beach: 0.8, suburbs: 0.5, docks: 0.3, outskirts: 0.12, ocean: 0, solcosta: 0.95, aurelia: 1.2, saguaro: 0.35, fort: 0.08, fortbase: 0.05, airport: 0.7, airfield: 0.15, pine: 0.12, valley: 0.14, bayou: 0.3 };
export function updatePopulation(g, dt) {
  g.popT -= dt; if (g.popT > 0) return; g.popT = 0.25;
  const p = g.player, w = g.world, q = g.settings.quality, dens = (DENS[w.districtAt(p.x, p.y)] ?? 0.4) * (night(g) ? 0.4 : 1);
  const maxPeds = q === 'low' ? 24 : q === 'medium' ? 40 : 60, maxCars = q === 'low' ? 12 : q === 'medium' ? 20 : 28;
  if (g.scene) return;
  // peds
  let npc = 0, ncar = 0, ncops = 0, ngang = 0;
  for (const a of g.actors) if (a.on && !a.dead && a !== p) { if (a.fac === 'civ' && !a.mis) npc++; else if (a.fac === 'pd' && a.st !== 'combat') ncops++; else if (['vip', 'sun', 'vel'].includes(a.fac) && !a.mis) ngang++; }
  for (const v of g.vehicles) if (v.on && v.ai === 'traffic' && !v.mis && !v.wreck) ncar++;
  if (npc < maxPeds * dens + 4) {
    const s = w.randomWalkable(p.x, p.y, 1000, WALK);
    if (s && hyp(s.x - p.x, s.y - p.y) > 520 && !inView(g, s.x, s.y, 60)) {
      const a = spawnActor(g, 'civ', s.x, s.y, { fac: 'civ', w: chance(0.07) ? 'bat' : 'fists' });
      if (a) {
        const dist = w.districtAt(s.x, s.y); a.role = dist === 'beach' && chance(0.3) ? 'jogger' : ''; a.drunk = chance(0.12);
        if (a.role === 'jogger') { a.look.shirt = '#00e5ff'; a.look.pants = '#212121'; }
        const dl = w.doorList; if (dl.length) { a.home = pick(dl); a.work = pick(dl); }
        a.st = 'idle'; a.t = Math.random() * 8; a.speed = 62 + Math.random() * 28;
      }
    }
  }
  // soldiers on base
  const zk = w.districtAt(p.x, p.y);
  if (zk === 'fortbase' || zk === 'fort') {
    let sol = 0; for (const a of g.actors) if (a.on && !a.dead && a.soldier) sol++;
    if (sol < 9) { const s2 = w.randomWalkable(p.x, p.y, 900, [T.CONCRETE, T.GRAVEL, T.DIRT, T.GRASS]); if (s2 && hyp(s2.x - p.x, s2.y - p.y) > 380 && !inView(g, s2.x, s2.y, 60) && w.districtAt(s2.x, s2.y) === 'fortbase') { const a = spawnActor(g, 'cop', s2.x, s2.y, { fac: 'pd', w: 'rifle' }); if (a) { a.soldier = true; a.look.shirt = '#4f5a3f'; a.look.pants = '#3d4630'; a.look.hair = '#2b2b2b'; a.st = 'idle'; a.t = Math.random() * 5; a.speed = 55; } } }
  }
  // traffic
  if (ncar < maxCars * dens + 3) {
    const s = randomLaneSpawn(g, 700, 1200);
    if (s) {
      const tb = TRAFFIC_BY[w.districtAt(s.x, s.y)], type = chance(0.06) ? 'police' : pick(tb && chance(0.8) ? tb : TRAFFIC_TYPES);
      const ang = s.dir * Math.PI / 2, free = !g.vehicles.some((v) => v.on && hyp(v.x - s.x, v.y - s.y) < 90);
      if (free) {
        const v = spawnVehicle(g, type, s.x, s.y, ang, { ai: type === 'police' ? 'police' : 'traffic', npc: type === 'police' ? 'cop' : 'civ', cop: type === 'police' });
        if (v) { v.dir = s.dir; v.cruise = 190 + Math.random() * 80; v.vx = Math.cos(ang) * 120; v.vy = Math.sin(ang) * 120; }
      }
    }
  }
  // parked cars at parking spots
  if (g.parkT === undefined || (g.parkT -= 0.25) <= 0) {
    g.parkT = 1.5;
    for (const s of w.parkSpots) {
      const d = hyp(s.x - p.x, s.y - p.y);
      if (!s.v && d < 900 && d > 450 && !inView(g, s.x, s.y, 20) && !s.cool) {
        s.cool = true; if (chance(s.cop ? 0.9 : 0.45)) { const v = spawnVehicle(g, s.cop ? 'police' : (s.type || pick(['compact', 'sedan', 'sedan', 'sports', 'muscle', 'pickup', 'van', 'compact', 'moto'])), s.x, s.y, s.a + (Math.random() < 0.5 ? 0 : Math.PI), { ai: 'none', hot: false, cop: !!s.cop }); if (v) { s.v = v; v.spot = s; } }
      } else if (s.v && (!s.v.on || s.v.spot !== s || hyp(s.v.x - s.x, s.v.y - s.y) > 40)) { s.v = null; }
      else if (s.v && d > 1400 && !s.v.driver && !s.v.mis && !s.v.owned) { s.v.on = false; s.v = null; s.cool = false; }
      if (!s.v && d > 1500) s.cool = false;
    }
  }
  // gangs in their turf
  const bx = w.blockAt(p.x, p.y), turf = w.turf[bx];
  if (turf && ngang < 4 && chance(0.25)) {
    const s = w.randomWalkable(p.x, p.y, 800, WALK);
    if (s && hyp(s.x - p.x, s.y - p.y) > 500 && !inView(g, s.x, s.y, 60) && w.turf[w.blockAt(s.x, s.y)] === turf) {
      for (let i = 0; i < 2; i++) { const a = spawnActor(g, 'gang', s.x + rnd(-24, 24), s.y + rnd(-24, 24), { fac: turf, w: pick(['pistol', 'bat', 'smg', 'knife']) }); if (a) { a.st = 'idle'; a.t = 5 + Math.random() * 15; } }
    }
  }
  // calm police patrols on foot downtown
  if (g.wanted.stars === 0 && ncops < 2 && w.districtAt(p.x, p.y) === 'downtown' && chance(0.2)) {
    const s = w.randomWalkable(p.x, p.y, 900, WALK);
    if (s && hyp(s.x - p.x, s.y - p.y) > 520 && !inView(g, s.x, s.y, 60)) { const a = spawnActor(g, 'cop', s.x, s.y, { fac: 'pd', w: 'pistol' }); if (a) { a.st = 'idle'; a.t = 2; a.speed = 60; const dl = w.doorList; if (dl.length) { a.home = pick(dl); a.work = pick(dl); } } }
  }
  // despawn far traffic
  for (const v of g.vehicles) if (v.on && v.ai === 'traffic' && !v.mis && !v.driver && hyp(v.x - p.x, v.y - p.y) > 1700) v.on = false;
}

// ---------- police response ----------
export function updatePolice(g, dt) {
  const W = g.wanted, p = g.player, S = W.stars; g.polT -= dt;
  if (S === 0) { // clean up
    if (g.polT <= 0) { g.polT = 2; for (const v of g.vehicles) if (v.on && (v.ai === 'police' || v.ai === 'block') && v.cop && hyp(v.x - p.x, v.y - p.y) > 900 && v.ai === 'block') v.on = false; for (const rb of g.roadblocks) { if (hyp(rb.x - p.x, rb.y - p.y) > 1000) rb.dead = true; } g.roadblocks = g.roadblocks.filter((r) => !r.dead); }
    return;
  }
  if (g.polT <= 0) {
    g.polT = 1.6;
    const maxCars = [0, 2, 4, 5, 7, 8][S], maxFoot = [0, 3, 6, 9, 12, 16][S];
    let cars = 0, foot = 0;
    for (const v of g.vehicles) if (v.on && v.cop && !v.wreck && v.ai !== 'block' && hyp(v.x - p.x, v.y - p.y) < 1700) cars++;
    for (const a of g.actors) if (a.on && !a.dead && a.fac === 'pd') foot++;
    if (cars < maxCars && !g.scene) {
      const s = randomLaneSpawn(g, 650, 1100);
      if (s) {
        const type = S >= 5 && chance(0.4) ? 'army' : S >= 4 && chance(0.5) ? 'swat' : S >= 3 && chance(0.3) ? 'swat' : 'police';
        const v = spawnVehicle(g, type, s.x, s.y, s.dir * Math.PI / 2, { ai: 'police', npc: type === 'army' ? 'army' : type === 'swat' ? 'swat' : 'cop', cop: true, gunner: S >= 3 && (type !== 'police' || chance(0.4)), speedMul: 1 + S * 0.03 });
        if (v) { v.dir = s.dir; v.siren = true; v.vx = Math.cos(v.a) * 160; v.vy = Math.sin(v.a) * 160; }
      }
    }
    if (foot < maxFoot && !g.scene && chance(0.5)) {
      const s = g.world.randomWalkable(p.x, p.y, 800, WALK);
      if (s && hyp(s.x - p.x, s.y - p.y) > 450 && !inView(g, s.x, s.y, 50)) {
        const sw = S >= 4, a = spawnActor(g, sw ? (S >= 5 ? 'army' : 'swat') : 'cop', s.x, s.y, { fac: 'pd', w: S >= 4 ? 'rifle' : S >= 3 ? 'smg' : S >= 2 ? 'smg' : 'pistol', hp: sw ? 140 : 100, armor: sw ? 40 : 0 });
        if (a) { a.st = 'combat'; a.target = p; a.alert = 1; }
      }
    }
    if (S >= 3 && g.roadblocks.length < 1 && chance(0.5) && p.veh && hyp(p.veh.vx, p.veh.vy) > 150) spawnRoadblock(g);
  }
  for (const rb of g.roadblocks) { if (hyp(rb.x - p.x, rb.y - p.y) > 1800) rb.dead = true; }
  g.roadblocks = g.roadblocks.filter((r) => !r.dead);
  updateHeli(g, dt);
}
function spawnRoadblock(g) {
  const p = g.player, v = p.veh, sp = hyp(v.vx, v.vy) || 1;
  const tx = p.x + (v.vx / sp) * 950, ty = p.y + (v.vy / sp) * 950;
  const vert = Math.abs(v.vx) < Math.abs(v.vy), cx = clamp(Math.round((tx - 64) / 512), 0, 11), cy = clamp(Math.round((ty - 64) / 512), 0, 11);
  const x = vert ? cx * 512 + 64 : tx, y = vert ? ty : cy * 512 + 64;
  if (!g.world.isRoad(x, y) || (g.world.metaAt(x, y) & M.V && g.world.metaAt(x, y) & M.H) || inView(g, x, y, 30)) return;
  const rb = { x, y, vs: [] };
  for (const off of [-34, 34]) { const vv = spawnVehicle(g, 'police', vert ? x + off : x, vert ? y : y + off, vert ? Math.PI / 2 + (off > 0 ? 0.25 : -0.25) : (off > 0 ? 0.25 : -0.25), { ai: 'block', cop: true, npc: null }); if (vv) { vv.siren = true; vv.hot = true; rb.vs.push(vv); } }
  for (let i = 0; i < 3; i++) { const a = spawnActor(g, 'cop', vert ? x + (i - 1) * 30 : x - 40, vert ? y - 40 : y + (i - 1) * 30, { fac: 'pd', w: g.wanted.stars >= 4 ? 'rifle' : 'smg' }); if (a) { a.st = 'idle'; a.alert = 0.6; a.lastKnownX = p.x; a.lastKnownY = p.y; a.alertFast = true; } }
  const dx = vert ? 0 : (v.vx > 0 ? -1 : 1) * 120, dy = vert ? (v.vy > 0 ? -1 : 1) * 120 : 0;
  g.spikes.push({ x: x + dx, y: y + dy, a: vert ? 0 : Math.PI / 2, len: 100, life: 90 });
  g.roadblocks.push(rb); g.toast && g.toast('Roadblock ahead!', '#ff7788');
}
export function updateSpikes(g, dt) {
  for (let i = g.spikes.length - 1; i >= 0; i--) {
    const s = g.spikes[i]; s.life -= dt; if (s.life <= 0 || g.wanted.stars === 0 && s.life < 60) { g.spikes.splice(i, 1); continue; }
    const c = Math.cos(s.a), sn = Math.sin(s.a);
    for (const v of g.vehicles) {
      if (!v.on || v.flat || v.z > 2) continue;
      const dx = v.x - s.x, dy = v.y - s.y, l = dx * c + dy * sn, n = -dx * sn + dy * c;
      if (Math.abs(l) < s.len / 2 && Math.abs(n) < v.def.len / 2 + 4) { v.flat = true; g.audio.sfx('hit', v.x, v.y, 0.8); g.parts.burst(1, v.x, v.y, 8, 200, 0.3, 1.5, '#ffd27a'); if (v.driver === g.player) g.toast && g.toast('Tires shredded!', '#ff7788'); }
    }
  }
}
function updateHeli(g, dt) {
  const W = g.wanted, p = g.player, h = g.heli;
  if (W.stars >= 4 && !h.on && g.polT < 1.7 && !g.scene) { const a = Math.random() * TAU; h.on = true; h.x = p.x + Math.cos(a) * 1400; h.y = p.y + Math.sin(a) * 1400; h.a = a + Math.PI; h.hp = 450; h.fire = 0; h.rot = 0; h.vx = 0; h.vy = 0; g.toast && g.toast('Police helicopter inbound', '#ff7788'); }
  if (!h.on) return;
  if (W.stars < 4 && W.unseen > 3) h.leave = true; else h.leave = false;
  h.rot += dt * 30;
  const tx = h.leave ? h.x + 2000 : (W.seen ? p.x : W.lx), ty = h.leave ? h.y - 2000 : (W.seen ? p.y : W.ly), dx = tx - h.x, dy = ty - h.y, d = hyp(dx, dy) || 1;
  const want = h.leave ? 260 : d > 220 ? 230 : 40, k = 1 - Math.exp(-1.5 * dt); h.vx += ((dx / d) * want - h.vx) * k; h.vy += ((dy / d) * want - h.vy) * k;
  h.x += h.vx * dt; h.y += h.vy * dt; h.a = rotToward(h.a, Math.atan2(dy, dx), 2 * dt);
  const dp = hyp(p.x - h.x, p.y - h.y);
  if (h.leave && dp > 2200) { h.on = false; return; }
  if (!h.leave && dp < 330 && !g.scene) { W.seenFrame = true; if (dp < 500) { h.fire -= dt; if (h.fire <= 0 && W.stars >= 4) { h.fire = 0.14; const a = Math.atan2(p.y - h.y, p.x - h.x) + rnd(-0.14, 0.14); g.bullets.spawn({ x: h.x, y: h.y, vx: Math.cos(a) * 1100, vy: Math.sin(a) * 1100, dmg: 6, owner: null, ownerV: null, fac: 'pd', life: 700, kind: 'b', rad: 0 }); g.audio.sfx('smg', h.x, h.y, 0.4); } } }
  g.lights.add(p.x, p.y, 120, '#ffffff', 0.5);
  g.audio.sfx && Math.random() < dt * 4 && g.audio.sfx('thud', h.x, h.y, 0.25);
  if (h.hp <= 0) { h.on = false; g.explode(h.x, h.y, 140, 140, { by: p }, true); g.toast && g.toast('Helicopter down!', '#7cff4f'); }
}

// ---------- ambient events & gang turf wars ----------
export function updateEvents(g, dt) {
  g.evT -= dt; const p = g.player;
  if (g.evT <= 0 && !g.mission && !g.scene && g.wanted.stars === 0) {
    g.evT = 50 + Math.random() * 60;
    const k = pick(['robbery', 'race', 'chase', 'protest', 'robbery', 'chase']);
    startEvent(g, k);
  }
  for (let i = g.events.length - 1; i >= 0; i--) {
    const e = g.events[i]; e.t -= dt;
    if (e.t <= 0 || hyp(e.x - p.x, e.y - p.y) > 2200) { for (const o of e.ents || []) if (o.on && !o.mis && !o.driver && (o.hp === undefined || true)) { if (!o.dead && hyp(o.x - p.x, o.y - p.y) > 900) o.on = false; } g.events.splice(i, 1); }
  }
  // turf war
  g.turfT -= dt;
  if (g.turfT <= 0) {
    g.turfT = 150 + Math.random() * 120;
    if (!g.mission && !g.scene && g.wanted.stars === 0) startTurfWar(g);
  }
  for (let i = g.wars.length - 1; i >= 0; i--) {
    const wr = g.wars[i]; wr.t -= dt;
    const aliveA = wr.a.filter((x) => x.on && !x.dead).length, aliveB = wr.b.filter((x) => x.on && !x.dead).length;
    if (wr.t <= 0 || aliveA === 0 || aliveB === 0) {
      const win = aliveA > aliveB ? wr.A : aliveB > aliveA ? wr.B : null;
      if (win) { g.world.turf[wr.block] = win; g.news && g.news('turf', win); g.toast && g.toast(GANGS.find((x) => x.id === win)?.name + ' took the block', GANGS.find((x) => x.id === win)?.color); }
      for (const a of [...wr.a, ...wr.b]) { a.war = false; a.st = 'idle'; }
      g.wars.splice(i, 1);
    }
  }
}
function startTurfWar(g) {
  const w = g.world, p = g.player;
  const cands = []; for (let bx = 0; bx < 11; bx++) for (let by = 2; by < 11; by++) { const t = w.turf[bx * NB + by]; if (!t) continue; const wx = bx * 512 + 256, wy = by * 512 + 256; if (hyp(wx - p.x, wy - p.y) < 2200 && hyp(wx - p.x, wy - p.y) > 800) cands.push({ bx, by, t, wx, wy }); }
  if (!cands.length) return; const c = pick(cands), others = GANGS.filter((x) => x.id !== c.t); const B = pick(others).id;
  const pos = w.randomWalkable(c.wx, c.wy, 150, WALK); if (!pos) return;
  const A = [], Bm = [];
  for (let i = 0; i < 4; i++) { const a = spawnActor(g, 'gang', pos.x - 60 + rnd(-20, 20), pos.y + rnd(-30, 30), { fac: c.t, w: pick(['pistol', 'smg', 'bat']) }); if (a) { a.war = true; a.st = 'idle'; A.push(a); } const b = spawnActor(g, 'gang', pos.x + 60 + rnd(-20, 20), pos.y + rnd(-30, 30), { fac: B, w: pick(['pistol', 'smg', 'bat']) }); if (b) { b.war = true; b.st = 'idle'; Bm.push(b); } }
  g.wars.push({ a: A, b: Bm, A: c.t, B, block: c.bx * 11 + c.by, t: 80, x: pos.x, y: pos.y });
  g.toast && g.toast('Gang war brewing in ' + w.districtAt(pos.x, pos.y), '#ffb347'); g.news && g.news('war');
}
function startEvent(g, kind) {
  const p = g.player, w = g.world, ents = [];
  if (kind === 'robbery') {
    const s = w.randomWalkable(p.x, p.y, 700, WALK); if (!s || hyp(s.x - p.x, s.y - p.y) < 350) return;
    const thief = spawnActor(g, 'gang', s.x, s.y, { fac: 'vip', w: 'pistol' }), vic = spawnActor(g, 'civ', s.x + 60, s.y + 20, { fac: 'civ' });
    if (!thief || !vic) return; thief.st = 'combat'; thief.manual = true; thief.target = vic; thief.alert = 1; thief.eventThief = true; thief.vis = 400; vic.st = 'flee'; vic.fear = 1; vic.threat = thief; vic.t = 30;
    thief.noLoot = false; ents.push(thief, vic); g.events.push({ kind, x: s.x, y: s.y, t: 60, ents, thief }); g.toast('Robbery in progress! Stop the thief.', '#ffe14a'); g.blipEvent = { x: s.x, y: s.y, t: 40 };
  } else if (kind === 'race') {
    const s = randomLaneSpawn(g, 800, 1300); if (!s) return;
    for (let i = 0; i < 3; i++) { const v = spawnVehicle(g, pick(['sports', 'muscle', 'sports']), s.x - DIRS[s.dir][0] * i * 80, s.y - DIRS[s.dir][1] * i * 80, s.dir * Math.PI / 2, { ai: 'traffic', npc: 'civ' }); if (v) { v.dir = s.dir; v.mode = 'race'; v.vx = Math.cos(v.a) * 200; v.vy = Math.sin(v.a) * 200; ents.push(v); } }
    g.events.push({ kind, x: s.x, y: s.y, t: 50, ents }); g.toast('Street race underway!', '#7cff4f'); g.blipEvent = { x: s.x, y: s.y, t: 30 };
  } else if (kind === 'chase') {
    const s = randomLaneSpawn(g, 800, 1300); if (!s) return;
    const crook = spawnVehicle(g, 'sedan', s.x, s.y, s.dir * Math.PI / 2, { ai: 'traffic', npc: 'vip', color: '#ff1744' });
    if (crook) { crook.dir = s.dir; crook.mode = 'flee'; crook.vx = Math.cos(crook.a) * 220; crook.vy = Math.sin(crook.a) * 220; ents.push(crook); crook.siren = false;
      for (let i = 1; i <= 2; i++) { const c = spawnVehicle(g, 'police', s.x - DIRS[s.dir][0] * i * 90, s.y - DIRS[s.dir][1] * i * 90, s.dir * Math.PI / 2, { ai: 'police', npc: 'cop', cop: true }); if (c) { c.dir = s.dir; c.tgtV = crook; c.siren = true; c.vx = Math.cos(c.a) * 220; c.vy = Math.sin(c.a) * 220; ents.push(c); } }
      g.events.push({ kind, x: s.x, y: s.y, t: 70, ents }); g.toast('Police chase nearby!', '#ff7788'); g.blipEvent = { x: s.x, y: s.y, t: 30 }; }
  } else if (kind === 'protest') {
    const s = w.randomWalkable(p.x, p.y, 1200, [T.PLAZA]); if (!s || hyp(s.x - p.x, s.y - p.y) < 500) return;
    for (let i = 0; i < 8; i++) { const a = spawnActor(g, 'civ', s.x + rnd(-40, 40), s.y + rnd(-40, 40), { fac: 'civ' }); if (a) { a.st = 'protest'; a.role = 'protest'; ents.push(a); } }
    for (let i = 0; i < 3; i++) { const a = spawnActor(g, 'cop', s.x + 90, s.y + (i - 1) * 24, { fac: 'pd', w: 'pistol' }); if (a) { a.st = 'idle'; a.t = 999; ents.push(a); } }
    g.events.push({ kind, x: s.x, y: s.y, t: 120, ents }); g.toast('Protest downtown', '#bbb'); g.blipEvent = { x: s.x, y: s.y, t: 20 };
  }
}
/** emergency services — called from game when bodies / fires appear */
export function dispatchEmergency(g, kind, x, y) {
  const s = randomLaneSpawn(g, 700, 1100); if (!s) return;
  const v = spawnVehicle(g, kind === 'fire' ? 'fire' : 'ambulance', s.x, s.y, s.dir * Math.PI / 2, { ai: 'respond', npc: 'civ' });
  if (v) { v.dir = s.dir; v.tgt = { x, y }; v.siren = true; v.vx = Math.cos(v.a) * 160; v.vy = Math.sin(v.a) * 160; }
}
export function updateEmergency(g, dt) {
  g.emT -= dt; if (g.emT > 0) return; g.emT = 6; const p = g.player;
  if (g.scene) return;
  let hasAmb = g.vehicles.some((v) => v.on && v.def.shape === 'ambulance' && v.ai === 'respond'), hasFire = g.vehicles.some((v) => v.on && v.def.shape === 'fire' && v.ai === 'respond');
  if (!hasAmb) for (const a of g.actors) if (a.on && a.dead && a.deadT > 3 && a.deadT < 20 && !a.mis && a !== p && hyp(a.x - p.x, a.y - p.y) < 1400 && !a.claimed) { a.claimed = true; dispatchEmergency(g, 'amb', a.x, a.y); break; }
  if (!hasFire) for (const v of g.vehicles) if (v.on && v.burning && v.wreckT > 2 && hyp(v.x - p.x, v.y - p.y) < 1400 && !v.claimed) { v.claimed = true; dispatchEmergency(g, 'fire', v.x, v.y); break; }
}
