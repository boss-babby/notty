// ===== heli.js — flyable helicopters: civil "Skylark" (general aviation) + "Reaper" gunship (combat) =====
// Twin-stick arcade flight model: WASD = move, Space = climb, Shift/C = descend, E = board / exit (land first).
// Combat variant: the nose follows the mouse, LMB = chin minigun, RMB / R = rocket pods.
import { T, NT, WS } from './world.js';
import { P } from './fx.js';
import { clamp, rnd, rotToward, TAU } from './util.js';
import { crime } from './wanted.js';
import { damageActor } from './combat.js';

export const HELIS = {
  skylark: { n: 'Skylark Charter Helicopter', combat: false, hp: 340, vmax: 330, acc: 330, R: 54, rockets: 0, colors: ['#e8eaf0', '#d9462f', '#2f7bd9', '#f2c230', '#2a2f3a'] },
  reaper: { n: 'Reaper AH-9 Gunship', combat: true, hp: 1200, vmax: 410, acc: 400, R: 62, rockets: 24, colors: ['#4a5a35', '#17191f', '#8a7a55'] },
};
const MAXH = 5;
const ALT_PX = 70; // visual lift (px) at alt = 1 (2.5D, same trick the buildings use)

export function initHeli(g) {
  g.choppers = []; g.chopper = null;
  g.summonHeli = (kind, color) => summonHeli(g, kind, color);
  g.heliHit = (c, dmg, src) => heliHit(g, c, dmg, src);
}

// ground height under (x,y) in 0..1 altitude units — rooftops are landable, towers/mountains must be flown over
function floorAt(g, x, y) {
  const w = g.world, t = w.tileAt(x, y);
  if (t === T.BUILDING) { const bi = w.bid[clamp(Math.floor(y / 32), 0, NT - 1) * NT + clamp(Math.floor(x / 32), 0, NT - 1)], b = bi >= 0 ? w.buildings[bi] : null; return clamp(0.1 + (b ? b.hgt : 30) / 250, 0.14, 0.82); }
  if (t === T.WATER) return 0.06;
  return 0;
}

export function summonHeli(g, kind, color) {
  const def = HELIS[kind]; if (!def) return null;
  const p = g.player, w = g.world;
  if (g.scene) { g.toast('Step outside first to summon a helicopter', '#ff7788'); return null; }
  if (p.heli) { g.toast('Land and exit your current helicopter first', '#ff7788'); return null; }
  const base = p.veh ? p.veh.a : p.a, R = def.R + 12;
  const clear = (x, y) => { for (let k = 0; k < 9; k++) { const a = k * TAU / 8, px = x + Math.cos(a) * (k ? R : 0), py = y + Math.sin(a) * (k ? R : 0), t = w.tileAt(px, py); if (t === T.BUILDING || t === T.WATER) return false; } return !w.pushCircle(x, y, R, true).hit; };
  let pos = null;
  for (const r of [100, 130, 170, 220, 280, 350, 430]) { for (const da of [0, 0.5, -0.5, 1.0, -1.0, 1.6, -1.6, 2.3, -2.3, 3.14]) { const a = base + da, x = p.x + Math.cos(a) * r, y = p.y + Math.sin(a) * r; if (clear(x, y)) { pos = { x, y }; break; } } if (pos) break; }
  if (!pos) pos = { x: p.x + Math.cos(base) * 150, y: p.y + Math.sin(base) * 150 };
  // pool: evict the oldest unoccupied one
  if (g.choppers.length >= MAXH) { const i = g.choppers.findIndex((c) => !c.driver); if (i >= 0) g.choppers.splice(i, 1); else return null; }
  const c = { kind, def, x: pos.x, y: pos.y, a: base + Math.PI / 2, vx: 0, vy: 0, alt: 0, rot: Math.random() * 6, rpm: 0, hp: def.hp, driver: null, color: color || def.colors[Math.floor(Math.random() * def.colors.length)], cool: 0, rcool: 0, rockets: def.rockets, flash: 0, tilt: 0, dead: false, deadT: 0, hitT: 0, mgT: 0, regen: 0, strobe: Math.random() * 3 };
  g.choppers.push(c);
  g.toast(def.n + ' ready — press E to board' + (def.combat ? ' · LMB minigun · RMB rockets' : ''), '#7cff4f'); g.audio.sfx('pickup');
  return c;
}

export function nearestChopper(g, x, y, r = 84) {
  let best = null, bd = r; for (const c of g.choppers) { if (c.dead || c.driver || c.alt > 0.5) continue; const d = Math.hypot(c.x - x, c.y - y); if (d < bd) { bd = d; best = c; } } return best;
}

export function boardHeli(g, c) {
  const p = g.player; p.heli = c; c.driver = p; g.chopper = c; p.veh = null; p.vx = p.vy = 0; p.cover = null; p.crouch = false; g.aiming = false; p.entering = 0;
  p.x = c.x; p.y = c.y; g.audio.sfx('door', c.x, c.y, 0.6);
  g.toast('Hold [Space] to lift off · [Shift] descend · [E] exit once landed', '#4fe0ff');
}

export function exitHeli(g) {
  const p = g.player, c = p.heli; if (!c) return;
  const fl = floorAt(g, c.x, c.y);
  if (c.alt > fl + 0.1) { g.toast('Land first — hold [Shift] to descend', '#ff9a3c'); g.audio.sfx('error'); return; }
  const w = g.world; let pos = null;
  for (const r of [c.def.R + 8, c.def.R + 26, c.def.R + 50]) for (let k = 0; k < 12 && !pos; k++) { const a = c.a + Math.PI / 2 + k * TAU / 12, x = c.x + Math.cos(a) * r, y = c.y + Math.sin(a) * r, t = w.tileAt(x, y); if (t !== T.BUILDING && t !== T.WATER && !w.solid(x, y) && !w.pushCircle(x, y, 8, true).hit) pos = { x, y }; }
  if (!pos) { if (fl > 0.1) pos = { x: c.x, y: c.y }; else { g.toast('No room to get out here', '#ff7788'); return; } }
  p.heli = null; c.driver = null; g.chopper = null; p.x = p.px = pos.x; p.y = p.py = pos.y; p.vx = p.vy = 0; p.a = Math.atan2(pos.y - c.y, pos.x - c.x);
  g.audio.sfx('door', c.x, c.y, 0.6);
}

function heliHit(g, c, dmg, src) {
  if (c.dead || g.cheats.god) return;
  c.hp -= dmg * (c.def.combat ? 0.2 : 0.42); c.hitT = 0.2;
  g.parts.burst(P.SPARK, c.x, c.y - c.alt * ALT_PX, 3, 160, 0.3, 2, '#ffd27a');
  g.fx.hurt = Math.max(g.fx.hurt, 0.25); void src;
  if (c.hp <= 0) crash(g, c);
}
function crash(g, c) {
  if (c.dead) return; c.dead = true; c.hp = 0;
  g.explode(c.x, c.y, 120, 160, { by: null, fac: 'none' }, true);
  g.parts.burst(P.DEBRIS, c.x, c.y, 24, 280, 1, 4, '#333'); g.parts.burst(P.FIRE, c.x, c.y, 16, 120, 0.8, 6, '#f90');
  const p = g.player;
  if (p.heli === c) { p.heli = null; c.driver = null; g.chopper = null; p.x = c.x; p.y = c.y; damageActor(g, p, 9999, { kind: 'crash' }); }
}

export function updateChoppers(g, dt) {
  const w = g.world, p = g.player;
  for (let i = g.choppers.length - 1; i >= 0; i--) {
    const c = g.choppers[i];
    c.flash = Math.max(0, c.flash - dt); c.hitT = Math.max(0, c.hitT - dt); c.cool -= dt; c.rcool -= dt; c.strobe += dt;
    c.rot += c.rpm * 38 * dt;
    if (c.dead) {
      c.deadT += dt; c.rpm *= Math.exp(-0.6 * dt); c.alt = Math.max(0, c.alt - 0.5 * dt); c.vx *= Math.exp(-1.5 * dt); c.vy *= Math.exp(-1.5 * dt); c.x += c.vx * dt; c.y += c.vy * dt;
      if (Math.random() < 0.5) g.parts.emit(P.SMOKE, c.x + rnd(-14, 14), c.y - c.alt * ALT_PX + rnd(-8, 8), rnd(-8, 8), -30, 1.2, 8, '#222');
      if (Math.random() < 0.2) g.parts.emit(P.FIRE, c.x + rnd(-12, 12), c.y + rnd(-8, 8), 0, -20, 0.4, 5, '#f90');
      if (c.deadT > 60 && Math.hypot(c.x - p.x, c.y - p.y) > 900) g.choppers.splice(i, 1);
      continue;
    }
    if (c.driver === p && p.heli === c) control(g, c, dt); else idle(g, c, dt);
    if (c.hp < c.def.hp * 0.3 && Math.random() < 0.3) g.parts.emit(P.SMOKE, c.x + rnd(-8, 8), c.y - c.alt * ALT_PX, rnd(-10, 10), -26, 0.9, 5, '#333');
    // dust / spray under the rotor wash
    if (c.rpm > 0.5 && c.alt < 0.45 && Math.random() < 0.6) {
      const t = w.tileAt(c.x, c.y), col = t === T.WATER ? '#cfe6ff' : t === T.SAND || t === T.DESERT ? '#d8c08a' : t === T.GRASS || t === T.FOREST || t === T.FARM ? '#8fa070' : '#aaa', a = Math.random() * TAU, r = c.def.R * (0.4 + Math.random() * 0.5);
      g.parts.emit(t === T.WATER ? P.WATER : P.SMOKE, c.x + Math.cos(a) * r * 0.5, c.y + Math.sin(a) * r * 0.5, Math.cos(a) * 90 * c.rpm, Math.sin(a) * 90 * c.rpm, 0.5, t === T.WATER ? 2.5 : 4, col);
    }
  }
}
function idle(g, c, dt) {
  // abandoned helicopters spool down and settle
  c.rpm = Math.max(0, c.rpm - dt * 0.25); const fl = floorAt(g, c.x, c.y);
  if (c.alt > fl) c.alt = Math.max(fl, c.alt - dt * 0.35);
  const k = Math.exp(-2 * dt); c.vx *= k; c.vy *= k; c.x += c.vx * dt; c.y += c.vy * dt; c.tilt *= k;
}
function control(g, c, dt) {
  const p = g.player, inp = g.input, d = c.def, mv = inp.move(), pad = inp.pad;
  g.aiming = false; p.x = c.x; p.y = c.y; p.inside = null;
  c.rpm = Math.min(1, c.rpm + dt * 0.45);
  const fl = floorAt(g, c.x, c.y), ready = c.rpm > 0.8;
  const climb = (inp.down('jump') ? 1 : 0) - (inp.down('sprint') || inp.down('cover') ? 1 : 0);
  if (ready) c.alt += climb * (climb > 0 ? 0.36 : 0.5) * dt;
  c.alt = clamp(c.alt, fl, 1);
  const air = c.alt > fl + 0.04 && ready;
  const spd = d.vmax * (0.35 + 0.65 * clamp((c.alt - fl) * 3.2, 0, 1));
  const tvx = air ? mv.x * spd : 0, tvy = air ? mv.y * spd : 0, ac = d.acc * dt;
  c.vx += clamp(tvx - c.vx, -ac, ac); c.vy += clamp(tvy - c.vy, -ac, ac);
  if (!air) { const k = Math.exp(-4 * dt); c.vx *= k; c.vy *= k; }
  // move with low-altitude collisions (flying below a roofline = clipping it)
  const mx = c.vx * dt, my = c.vy * dt;
  const hitX = floorAt(g, c.x + mx + Math.sign(mx) * 14, c.y) > c.alt + 0.03, hitY = floorAt(g, c.x, c.y + my + Math.sign(my) * 14) > c.alt + 0.03;
  if (hitX) { const sp = Math.abs(c.vx); c.vx *= -0.35; if (sp > 80) bump(g, c, sp); } else c.x += mx;
  if (hitY) { const sp = Math.abs(c.vy); c.vy *= -0.35; if (sp > 80) bump(g, c, sp); } else c.y += my;
  c.x = clamp(c.x, 80, WS - 80); c.y = clamp(c.y, 80, WS - 80);
  // heading
  const sp = Math.hypot(c.vx, c.vy);
  if (d.combat) {
    let aim = c.a;
    if (pad.aimActive) aim = Math.atan2(pad.ay, pad.ax);
    else if (!pad.on || performance.now() - (inp.moveT || 0) < 2500) { const m = g.mouseWorld(); aim = Math.atan2(m.y - c.y, m.x - c.x); }
    else if (sp > 40) aim = Math.atan2(c.vy, c.vx);
    c.a = rotToward(c.a, aim, 4.6 * dt);
  } else if (sp > 45) c.a = rotToward(c.a, Math.atan2(c.vy, c.vx), 2.1 * dt);
  c.tilt += ((sp / d.vmax) - c.tilt) * Math.min(1, dt * 4);
  // weapons
  if (d.combat && ready) {
    if (inp.down('fire') && c.cool <= 0 && !g.uiOpen) {
      c.cool = 0.05; c.flash = 0.05; c.mgT++;
      const ox = c.x + Math.cos(c.a) * 40, oy = c.y + Math.sin(c.a) * 40, aa = c.a + (Math.random() - 0.5) * 0.07;
      g.bullets.spawn({ x: ox, y: oy, vx: Math.cos(aa) * 2300, vy: Math.sin(aa) * 2300, dmg: 15, owner: p, ownerV: null, fac: 'pl', life: 1100, kind: 'b', rad: 0 });
      if (c.mgT % 2 === 0) { g.audio.sfx('smg', c.x, c.y, 0.55); g.noise(c.x, c.y, 900, { by: p }); g.combatT = 6; crime(g, 'shots', c.x, c.y); }
      g.parts.emit(P.SHELL, c.x, c.y, Math.cos(c.a + 1.6) * 120 + rnd(-20, 20), Math.sin(c.a + 1.6) * 120 + rnd(-20, 20), 0.7, 3, '#d9b34a');
      g.tmpLights.push({ x: ox, y: oy, r: 120, col: '#ffd27a', life: 0.05, max: 0.05, i: 1 });
      g.cam.shake = Math.max(g.cam.shake, 2.5);
    }
    if ((inp.pressed('aim') || inp.pressed('reload')) && c.rcool <= 0 && !g.uiOpen) {
      if (c.rockets > 0) {
        c.rockets--; c.rcool = 0.7; const side = (c.rockets % 2 ? 1 : -1), a = c.a, ox = c.x + Math.cos(a) * 24 + Math.cos(a + 1.57) * side * 22, oy = c.y + Math.sin(a) * 24 + Math.sin(a + 1.57) * side * 22;
        g.bullets.spawn({ x: ox, y: oy, vx: Math.cos(a) * 880 + c.vx * 0.5, vy: Math.sin(a) * 880 + c.vy * 0.5, dmg: 230, owner: p, ownerV: null, fac: 'pl', life: 1300, kind: 'rk', rad: 120 });
        g.audio.sfx('rocket', c.x, c.y); g.noise(c.x, c.y, 1000, { by: p }); g.combatT = 8; crime(g, 'shots', c.x, c.y); g.cam.shake = Math.max(g.cam.shake, 5);
      } else { g.audio.sfx('empty'); c.rcool = 0.4; }
    }
    c.regen += dt; if (c.regen > 4 && c.rockets < d.rockets) { c.regen = 0; c.rockets++; }
  }
}
function bump(g, c, sp) {
  c.hp -= sp * 0.18; c.hitT = 0.25; g.cam.shake = Math.max(g.cam.shake, 10); g.audio.sfx('crash', c.x, c.y, 0.8); g.parts.burst(P.SPARK, c.x, c.y, 8, 200, 0.4, 2, '#ffd27a'); g.fx.hurt = Math.max(g.fx.hurt, 0.3);
  g.toast('Pull up! You clipped a rooftop', '#ff9a3c'); if (c.hp <= 0 && !g.cheats.god) crash(g, c);
}

// ---------- drawing ----------
export function chopperShadows(g, c) {
  for (const h of g.choppers) {
    const R = h.def.R, a = h.alt, s = 1 - a * 0.22; c.save(); c.translate(h.x + 10 + a * 46, h.y + 12 + a * 74); c.rotate(h.a); c.scale(s, s);
    c.fillStyle = `rgba(0,0,0,${0.3 - a * 0.12})`; c.beginPath(); c.ellipse(0, 0, R * 0.55, R * 0.2, 0, 0, TAU); c.fill(); c.fillRect(-R * 0.95, -2, R * 0.55, 4);
    if (h.rpm > 0.2) { c.fillStyle = `rgba(0,0,0,${0.1 * h.rpm})`; c.beginPath(); c.arc(R * 0.05, 0, R, 0, TAU); c.fill(); }
    c.restore();
  }
}
// pass 0 = grounded / low choppers (sorted under rooftops), pass 1 = airborne (over everything)
export function drawChoppers(g, c, pass) {
  for (const h of g.choppers) { const low = h.alt < 0.2; if ((pass === 0) !== low) continue; drawOne(g, c, h); }
}
function drawOne(g, c, h) {
  const d = h.def, R = d.R, lift = h.alt * ALT_PX, sc = 1 + h.alt * 0.2;
  c.save(); c.translate(h.x - h.vx * 0.012 * h.alt, h.y - lift - h.vy * 0.012 * h.alt); c.rotate(h.a + Math.sin(g.time * 2.1 + h.strobe) * 0.012 * h.rpm); c.scale(sc * (1 + h.tilt * 0.04), sc);
  const body = h.color, dark = '#111318';
  if (d.combat) {
    c.fillStyle = dark; c.fillRect(-52, -1.8, 20, 3.6); c.fillRect(-50, -9, 7, 3); c.fillRect(-50, 6, 7, 3);                       // twin tail + stabilisers
    for (const s of [-1, 1]) { c.fillStyle = '#23262d'; c.fillRect(-6, s * 12 - 2.5, 24, 5); c.fillRect(-4, s * 24 - 4, 20, 8); c.fillStyle = '#b02a2a'; c.fillRect(16, s * 24 - 3, 3, 6); }  // stub wings + rocket pods
    c.fillStyle = body; c.beginPath(); c.moveTo(42, 0); c.lineTo(28, -6.5); c.lineTo(6, -11); c.lineTo(-20, -8); c.lineTo(-40, -2.5); c.lineTo(-40, 2.5); c.lineTo(-20, 8); c.lineTo(6, 11); c.lineTo(28, 6.5); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(0,0,0,.45)'; c.lineWidth = 1.2; c.stroke();
    c.fillStyle = '#1d3a52'; c.beginPath(); c.ellipse(26, 0, 8, 4.2, 0, 0, TAU); c.fill(); c.beginPath(); c.ellipse(12, 0, 7, 5, 0, 0, TAU); c.fill();
    c.fillStyle = 'rgba(160,210,255,.45)'; c.beginPath(); c.ellipse(27, -1.2, 4.5, 1.6, 0, 0, TAU); c.fill(); c.beginPath(); c.ellipse(13, -1.5, 4, 1.8, 0, 0, TAU); c.fill();
    c.strokeStyle = '#0c0d10'; c.lineWidth = 2.6; c.beginPath(); c.moveTo(40, 0); c.lineTo(50, 0); c.stroke(); c.fillStyle = '#0c0d10'; c.beginPath(); c.arc(40, 0, 3, 0, TAU); c.fill();
    c.fillStyle = '#2a2d33'; for (const s of [-1, 1]) { c.beginPath(); c.arc(-8, s * 7, 3, 0, TAU); c.fill(); }
    if (h.flash > 0) { c.fillStyle = '#ffe9a0'; c.beginPath(); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4, r = i % 2 ? 4 : 11; c.lineTo(52 + Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); c.fill(); }
  } else {
    c.strokeStyle = '#1b1d22'; c.lineWidth = 2; for (const s of [-1, 1]) { c.beginPath(); c.moveTo(-16, s * 11); c.lineTo(22, s * 11); c.stroke(); } c.beginPath(); c.moveTo(-4, -11); c.lineTo(-4, 11); c.moveTo(12, -11); c.lineTo(12, 11); c.stroke();
    c.fillStyle = body; c.fillRect(-46, -2.2, 38, 4.4); c.fillStyle = 'rgba(0,0,0,.2)'; c.fillRect(-46, 0.5, 38, 1.7);
    c.fillStyle = body; c.fillRect(-48, -6.5, 5, 13);
    c.beginPath(); c.ellipse(4, 0, 23, 11.5, 0, 0, TAU); c.fill(); c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 1.2; c.stroke();
    c.fillStyle = 'rgba(0,0,0,.18)'; c.fillRect(-14, -11, 8, 22);
    c.fillStyle = '#6fa6c9'; c.beginPath(); c.ellipse(15, 0, 11, 8.5, 0, 0, TAU); c.fill(); c.fillStyle = 'rgba(255,255,255,.45)'; c.beginPath(); c.ellipse(17, -3, 6, 2.2, -0.2, 0, TAU); c.fill();
    c.fillStyle = 'rgba(0,0,0,.28)'; c.fillRect(8, -8, 1.5, 16);
  }
  // tail rotor
  const tr = Math.cos(h.rot * 3.1); c.strokeStyle = 'rgba(25,28,34,.85)'; c.lineWidth = 2; c.beginPath(); c.moveTo(-47, -9 * tr); c.lineTo(-47, 9 * tr); c.stroke();
  if (h.rpm > 0.4) { c.fillStyle = 'rgba(200,210,220,.14)'; c.beginPath(); c.ellipse(-47, 0, 3, 9, 0, 0, TAU); c.fill(); }
  // main rotor
  const nb = d.combat ? 4 : 2; c.save(); c.translate(d.combat ? 4 : 3, 0);
  if (h.rpm > 0.55) { c.fillStyle = `rgba(215,225,235,${0.07 + 0.08 * h.rpm})`; c.beginPath(); c.arc(0, 0, R, 0, TAU); c.fill(); }
  c.lineCap = 'round';
  for (let k = 0; k < nb; k++) {
    const a = h.rot + k * TAU / nb, spin = h.rpm > 0.55;
    c.strokeStyle = `rgba(22,25,31,${spin ? 0.5 : 0.95})`; c.lineWidth = spin ? 3 : 3.6; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(a) * R * (h.rpm > 0.05 ? 1 : 0.92), Math.sin(a) * R * (h.rpm > 0.05 ? 1 : 0.92)); c.stroke();
    if (spin) { c.strokeStyle = 'rgba(22,25,31,.16)'; c.lineWidth = 7; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(a - 0.22) * R, Math.sin(a - 0.22) * R); c.stroke(); }
  }
  c.fillStyle = '#0e0f13'; c.beginPath(); c.arc(0, 0, 4, 0, TAU); c.fill(); c.fillStyle = '#4a4f59'; c.beginPath(); c.arc(0, 0, 1.8, 0, TAU); c.fill(); c.restore();
  // navigation lights
  const blink = Math.floor(h.strobe * 1.7) % 2 === 0, wy = d.combat ? 25 : 12, wx = d.combat ? 4 : 2;
  c.fillStyle = '#ff2a2a'; c.beginPath(); c.arc(wx, -wy, 1.8, 0, TAU); c.fill(); c.fillStyle = '#2aff6a'; c.beginPath(); c.arc(wx, wy, 1.8, 0, TAU); c.fill();
  if (blink) { c.fillStyle = '#fff'; c.beginPath(); c.arc(-47, 0, 2, 0, TAU); c.fill(); }
  if (h.hitT > 0) { c.fillStyle = `rgba(255,80,60,${h.hitT * 2})`; c.beginPath(); c.ellipse(4, 0, 24, 12, 0, 0, TAU); c.fill(); }
  c.restore();
}
export function chopperLights(g, L, vis) {
  for (const h of g.choppers) {
    if (h.dead) { L.add(h.x, h.y, 120, '#ff8a3a', 0.6); continue; }
    const lift = h.alt * ALT_PX;
    if (vis > 0.03 && (h.driver || h.rpm > 0.3)) {
      const f = 90 + h.alt * 140, ca = Math.cos(h.a), sa = Math.sin(h.a);
      L.add(h.x + ca * f, h.y + sa * f, 150 + h.alt * 110, '#fff4d6', 0.95 * Math.min(1, vis + 0.2));      // searchlight pool on the ground
      L.add(h.x, h.y - lift, 70, '#ffffff', 0.35 * vis);
    }
    if (Math.floor(h.strobe * 1.7) % 2 === 0) L.add(h.x - Math.cos(h.a) * 47, h.y - Math.sin(h.a) * 47 - lift, 44, '#ffffff', 0.5);
    L.add(h.x - Math.sin(h.a) * 12, h.y + Math.cos(h.a) * 12 - lift, 30, '#ff2a2a', 0.45); L.add(h.x + Math.sin(h.a) * 12, h.y - Math.cos(h.a) * 12 - lift, 30, '#2aff6a', 0.45);
  }
}

// ---------- HUD (screen space) ----------
export function heliHud(g, c) {
  const h = g.player.heli; if (!h || g.state !== 'play') return;
  const W = g.W, H = g.H, k = g.dpr, d = h.def, bw = 220 * k, bh = 9 * k, x = W / 2 - bw / 2, y = H - 128 * k;
  const bar = (yy, v, col, label) => { c.fillStyle = 'rgba(0,0,0,.55)'; c.fillRect(x, yy, bw, bh); c.fillStyle = col; c.fillRect(x, yy, bw * clamp(v, 0, 1), bh); c.strokeStyle = 'rgba(255,255,255,.3)'; c.lineWidth = 1; c.strokeRect(x, yy, bw, bh); c.fillStyle = '#e8ecf5'; c.font = `bold ${10 * k}px sans-serif`; c.textAlign = 'right'; c.fillText(label, x - 8 * k, yy + bh - 0.5 * k); };
  bar(y, h.alt, '#4fe0ff', 'ALT'); bar(y + 16 * k, h.hp / d.hp, h.hp / d.hp > 0.35 ? '#7cff4f' : '#ff4f5f', 'HULL'); bar(y + 32 * k, h.rpm, '#ffe14a', 'ROTOR');
  c.textAlign = 'left'; c.font = `bold ${12 * k}px sans-serif`; c.fillStyle = '#fff'; c.fillText(`${d.n}  ·  ${Math.round(Math.hypot(h.vx, h.vy) * 0.12)} kt`, x, y - 8 * k);
  if (d.combat) {
    c.fillStyle = '#ffe14a'; c.textAlign = 'right'; c.font = `bold ${15 * k}px sans-serif`; c.fillText(`ROCKETS ${h.rockets}/${d.rockets}`, x + bw, y - 28 * k);
    if (!g.input.pad.on && !g.input.touch) { const mx = g.input.mx * k, my = g.input.my * k; c.strokeStyle = 'rgba(255,90,90,.9)'; c.lineWidth = 1.6 * k; c.beginPath(); c.arc(mx, my, 13 * k, 0, TAU); c.moveTo(mx - 20 * k, my); c.lineTo(mx - 6 * k, my); c.moveTo(mx + 6 * k, my); c.lineTo(mx + 20 * k, my); c.moveTo(mx, my - 20 * k); c.lineTo(mx, my - 6 * k); c.moveTo(mx, my + 6 * k); c.lineTo(mx, my + 20 * k); c.stroke(); }
  }
  c.textAlign = 'center'; c.font = `bold ${14 * k}px sans-serif`;
  if (h.rpm < 0.8) { c.fillStyle = '#ffe14a'; c.fillText('SPOOLING UP…', W / 2, y - 30 * k); }
  else if (h.alt < 0.05) { c.fillStyle = '#fff'; c.fillText('Hold [SPACE] to take off', W / 2, y - 30 * k); }
}

// ---------- audio ----------
export function chopperAudio(g, a) {
  let lvl = 0, spd = 0, drv = null;
  for (const h of g.choppers) { if (h.rpm < 0.03) continue; const dd = h.driver ? 0 : Math.hypot(h.x - g.cam.x, h.y - g.cam.y), v = h.rpm * Math.pow(clamp(1 - dd / 1100, 0, 1), 1.5); if (v > lvl) { lvl = v; spd = h.rpm; drv = h; } }
  if (g.state === 'menu' || g.scene) lvl = 0;
  a.rotor(lvl * (drv && drv.def.combat ? 1.1 : 0.9), spd);
}
