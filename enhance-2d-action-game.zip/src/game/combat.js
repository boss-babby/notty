// ===== combat.js — weapons, bullets, melee, explosions, fire, damage, props destruction =====
import { WEAPONS } from './data.js';
import { P } from './fx.js';
import { crime } from './wanted.js';
import { paintOnChunks } from './gfx.js';
import { clamp, rnd, chance, pick } from './util.js';

const _q = [];
export function inVehicleBox(v, x, y, m) {
  const dx = x - v.x, dy = y - v.y, c = Math.cos(v.a), s = Math.sin(v.a), lx = dx * c + dy * s, ly = -dx * s + dy * c;
  return Math.abs(lx) <= v.def.len / 2 + m && Math.abs(ly) <= v.def.wid / 2 + m;
}
const isFriendly = (a, fac) => a.fac === fac || (fac === 'pl' && a.fac === 'pl');

export class Bullets {
  constructor(n = 320) { this.n = n; this.a = Array.from({ length: n }, () => ({ on: false, x: 0, y: 0, vx: 0, vy: 0, dmg: 0, owner: null, ownerV: null, fac: '', life: 0, kind: 'b', rad: 0, fuse: 0, t: 0, tr: 0 })); }
  spawn(o) {
    for (let i = 0; i < this.n; i++) {
      const b = this.a[i]; if (b.on) continue;
      Object.assign(b, o); b.on = true; b.t = 0; return b;
    }
    return null;
  }
  update(g, dt) {
    for (let i = 0; i < this.n; i++) {
      const b = this.a[i]; if (!b.on) continue;
      b.t += dt;
      if (b.kind === 'gr' || b.kind === 'mo') { this.thrown(g, b, dt); continue; }
      const sp = Math.hypot(b.vx, b.vy), dist = sp * dt, steps = Math.max(1, Math.ceil(dist / 10)), sx = (b.vx * dt) / steps, sy = (b.vy * dt) / steps;
      for (let s = 0; s < steps; s++) {
        b.x += sx; b.y += sy;
        if (hitCheck(g, b)) { b.on = false; break; }
      }
      if (!b.on) continue;
      if (b.kind === 'rk') { g.parts.emit(P.SMOKE, b.x, b.y, rnd(-10, 10), rnd(-10, 10), 0.7, 5, '#aaa'); g.parts.emit(P.FIRE, b.x, b.y, 0, 0, 0.25, 5, '#f90'); g.lights.add(b.x, b.y, 110, '#ffa040', 0.8); }
      b.life -= dist;
      if (b.life <= 0) { if (b.kind === 'rk') explode(g, b.x, b.y, b.rad, b.dmg, { by: b.owner, fac: b.fac }); b.on = false; }
    }
  }
  thrown(g, b, dt) {
    const nx = b.x + b.vx * dt, ny = b.y + b.vy * dt, sp = Math.hypot(b.vx, b.vy);
    if (g.solidAt(nx, b.y)) b.vx *= -0.4; else b.x = nx;
    if (g.solidAt(b.x, ny)) b.vy *= -0.4; else b.y = ny;
    b.life -= sp * dt;
    if (b.kind === 'gr') { const f = Math.pow(b.life > 0 ? 0.8 : 0.05, dt); b.vx *= f; b.vy *= f; b.fuse -= dt; if (b.fuse <= 0) { explode(g, b.x, b.y, b.rad, b.dmg, { by: b.owner, fac: b.fac }); b.on = false; } }
    else if (b.life <= 0 || (g.solidAt(nx, ny))) { g.audio.sfx('glass', b.x, b.y, 0.8); g.fires.push({ x: b.x, y: b.y, r: 62, life: 7, by: b.owner }); explode(g, b.x, b.y, 40, 10, { by: b.owner, fac: b.fac }, true); b.on = false; }
  }
  draw(c, alpha) {
    for (let i = 0; i < this.n; i++) {
      const b = this.a[i]; if (!b.on) continue;
      const x = b.x + b.vx * alpha * 0.0167, y = b.y + b.vy * alpha * 0.0167;
      if (b.kind === 'b') { c.strokeStyle = 'rgba(255,225,140,.9)'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(x, y); c.lineTo(x - b.vx * 0.022, y - b.vy * 0.022); c.stroke(); }
      else if (b.kind === 'rk') { c.fillStyle = '#ddd'; c.save(); c.translate(x, y); c.rotate(Math.atan2(b.vy, b.vx)); c.fillRect(-7, -2, 14, 4); c.fillStyle = '#c33'; c.fillRect(5, -2, 4, 4); c.restore(); }
      else { const h = Math.sin(Math.min(1, b.t / 0.6) * Math.PI) * 6; c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(x, y + 2, 4, 2.5, 0, 0, 6.3); c.fill(); c.fillStyle = b.kind === 'gr' ? '#3d5a2a' : '#7ab37a'; c.beginPath(); c.arc(x, y - h, 4, 0, 6.3); c.fill(); if (b.kind === 'mo') { c.fillStyle = '#f90'; c.beginPath(); c.arc(x, y - h - 4, 2.2, 0, 6.3); c.fill(); } }
    }
  }
}

function hitCheck(g, b) {
  const x = b.x, y = b.y, src = { by: b.owner, fac: b.fac, kind: 'bullet', dx: b.vx, dy: b.vy };
  if (g.solidAt(x, y)) {
    g.parts.burst(P.SPARK, x - b.vx * 0.01, y - b.vy * 0.01, 4, 160, 0.25, 1.5, '#ffd27a', 2.5, Math.atan2(-b.vy, -b.vx));
    if (chance(0.3)) g.audio.sfx('hit', x, y, 0.5);
    if (!g.scene) { const bd = g.world.buildingAt(x, y); if (bd && bd.kind !== 'container' && chance(0.12)) { g.parts.burst(P.GLASS, x, y, 6, 90, 0.7, 3, '#bfe6ff'); g.audio.sfx('glass', x, y, 0.5); } }
    if (b.kind === 'rk') explode(g, x - b.vx * 0.01, y - b.vy * 0.01, b.rad, b.dmg, { by: b.owner, fac: b.fac });
    return true;
  }
  if (!g.scene) {
    _q.length = 0; g.world.propHash.query(x, y, 14 + 16, _q);
    for (let i = 0; i < _q.length; i++) {
      const p = _q[i]; if (p.dead || !p.solid) continue;
      const dx = x - p.x, dy = y - p.y, r = p.r + 1.5;
      if (dx * dx + dy * dy < r * r) {
        if (p.low && chance(0.55)) continue;
        damageProp(g, p, b.dmg, src); g.parts.burst(P.SPARK, x, y, 3, 120, 0.2, 1.5, '#ffd27a');
        if (b.kind === 'rk') explode(g, x, y, b.rad, b.dmg, { by: b.owner, fac: b.fac });
        return true;
      }
    }
  }
  _q.length = 0; g.hashA.query(x, y, 26, _q);
  for (let i = 0; i < _q.length; i++) {
    const a = _q[i]; if (!a.on || a.dead || a === b.owner || a.veh || a.inside !== g.insideId || isFriendly(a, b.fac)) continue;
    const dx = x - a.x, dy = y - a.y, r = a.r + 2;
    if (dx * dx + dy * dy < r * r) {
      if (a.roll > 0 && chance(0.7)) continue;
      if (a.cover && (b.vx * a.cover.x + b.vy * a.cover.y) > 0.2 * Math.hypot(b.vx, b.vy) && chance(0.85)) { g.parts.burst(P.SPARK, x, y, 3, 120, 0.2, 1.5, '#ffd27a'); return true; }
      damageActor(g, a, b.dmg, src);
      if (b.kind === 'rk') explode(g, x, y, b.rad, b.dmg, { by: b.owner, fac: b.fac });
      return true;
    }
  }
  if (g.heli && g.heli.on && b.owner === g.player && Math.hypot(x - g.heli.x, y - g.heli.y) < 24) { g.heli.hp -= b.dmg * 0.6; g.parts.burst(P.SPARK, x, y, 3, 120, 0.2, 1.5, '#ffd27a'); return true; }
  _q.length = 0; g.hashV.query(x, y, 70, _q);
  for (let i = 0; i < _q.length; i++) {
    const v = _q[i]; if (!v.on || v === b.ownerV || v.z > 6) continue;
    if (inVehicleBox(v, x, y, 0)) {
      damageVehicle(g, v, b.dmg * 0.5, src); g.parts.burst(P.SPARK, x, y, 4, 180, 0.25, 1.5, '#ffd27a'); g.audio.sfx('hit', x, y, 0.5);
      if (v.driver && v.driver !== b.owner && chance(0.4)) damageActor(g, v.driver, b.dmg * 0.8, src);
      if (v.npc) { v.panic = 8; if (b.owner === g.player) v.provoked = true; }
      if (v.def.shape !== 'bus' && chance(0.06 * b.dmg / 20)) v.flat = true;
      if (b.kind === 'rk') explode(g, x, y, b.rad, b.dmg, { by: b.owner, fac: b.fac });
      return true;
    }
  }
  return false;
}

// ---------- firing ----------
export function switchWeapon(g, a, id) {
  if (!WEAPONS[id]) return;
  a.wid = id; a.wdef = WEAPONS[id]; a.reload = 0; a.cool = Math.max(a.cool, 0.2);
  if (a === g.player) g.audio.sfx('click');
}
export function startReload(g, a) {
  const wd = a.wdef; if (a !== g.player || wd.type === 'melee' || wd.type === 'throw' || a.reload > 0) return;
  if (g.inv.mag[a.wid] >= wd.mag || (g.inv.ammo[wd.ammo] | 0) <= 0) return;
  a.reload = wd.reload * (1 - 0.05 * g.skillLvl('shooting')); g.audio.sfx('reload', a.x, a.y, 0.6);
}
export function finishReload(g, a) {
  const wd = a.wdef, need = wd.mag - g.inv.mag[a.wid], take = Math.min(need, g.inv.ammo[wd.ammo] | 0);
  g.inv.mag[a.wid] += take; g.inv.ammo[wd.ammo] -= take;
}
export function fireWeapon(g, a) {
  const wd = a.wdef, pl = a === g.player;
  if (a.cool > 0 || a.reload > 0 || a.roll > 0 || a.swim || a.stun > 0.3) return false;
  if (wd.type === 'melee') return melee(g, a);
  if (pl) {
    if (wd.type === 'throw') { if ((g.inv.ammo[wd.ammo] | 0) <= 0) { g.audio.sfx('empty'); a.cool = 0.3; return false; } g.inv.ammo[wd.ammo]--; if (g.inv.ammo[wd.ammo] <= 0 && !g.inv.ammo[wd.ammo]) { /* keep weapon for restock */ } }
    else if (g.inv.mag[a.wid] <= 0) { g.audio.sfx('empty'); a.cool = 0.25; startReload(g, a); return false; }
    else g.inv.mag[a.wid]--;
  }
  a.cool = 1 / wd.rate * (pl ? 1 : 1.5);
  const ang = a.aim, ox = a.x + Math.cos(ang) * 16, oy = a.y + Math.sin(ang) * 16, sk = pl ? g.skillLvl('shooting') : 0;
  let spread = (wd.spread + (a.bloom || 0)) * (1 - 0.06 * sk) * (a.moveAmt > 0.5 ? 1.35 : 1) * (a.crouch || a.cover ? 0.6 : 1) * (pl && g.aiming ? 0.7 : 1) * (g.focusT > 0 ? 0.35 : 1);
  if (!pl) spread *= 1.4;
  a.bloom = Math.min(0.12, (a.bloom || 0) + (wd.bloom || 0));
  const fac = a.fac, ownerV = a.veh || null, dmgMul = pl ? 1 : (a.dmgMul || 0.55);
  if (wd.type === 'gun') {
    const n = wd.pellets || 1;
    for (let i = 0; i < n; i++) { const aa = ang + (Math.random() - 0.5) * 2 * spread; g.bullets.spawn({ x: ox, y: oy, vx: Math.cos(aa) * wd.speed, vy: Math.sin(aa) * wd.speed, dmg: wd.dmg * dmgMul, owner: a, ownerV, fac, life: wd.range, kind: 'b', rad: 0 }); }
    a.flash = 0.06; g.audio.sfx(wd.sfx, a.x, a.y, pl ? 1 : 0.8);
    g.parts.emit(P.SHELL, a.x, a.y, Math.cos(ang + 1.6) * 90 + rnd(-20, 20), Math.sin(ang + 1.6) * 90 + rnd(-20, 20), 0.6, 3, '#d9b34a');
    g.parts.emit(P.SMOKE, ox + Math.cos(ang) * 8, oy + Math.sin(ang) * 8, 0, 0, 0.5, 3, '#bbb');
    g.tmpLights.push({ x: ox, y: oy, r: 110, col: '#ffd27a', life: 0.06, max: 0.06, i: 1 });
    g.noise(a.x, a.y, wd.sfx === 'sniper' || wd.sfx === 'shotgun' ? 950 : 750, { by: a }); g.combatT = 6;
    if (pl) { g.cam.kx -= Math.cos(ang) * wd.recoil * 5; g.cam.ky -= Math.sin(ang) * wd.recoil * 5; g.cam.shake = Math.max(g.cam.shake, wd.recoil * 2.5); g.stats.shots++; crime(g, 'shots', a.x, a.y); }
  } else if (wd.type === 'rocket') {
    g.bullets.spawn({ x: ox, y: oy, vx: Math.cos(ang) * wd.speed, vy: Math.sin(ang) * wd.speed, dmg: wd.dmg, owner: a, ownerV, fac, life: wd.range, kind: 'rk', rad: wd.radius });
    a.flash = 0.08; g.audio.sfx('rocket', a.x, a.y); g.noise(a.x, a.y, 1000, { by: a }); g.combatT = 8;
    if (pl) { g.cam.shake = Math.max(g.cam.shake, 6); g.cam.kx -= Math.cos(ang) * 14; g.cam.ky -= Math.sin(ang) * 14; crime(g, 'shots', a.x, a.y); startReload(g, a); }
  } else if (wd.type === 'throw') {
    const dd = clamp(a.aimDist || 300, 60, 480), sp = 380;
    g.bullets.spawn({ x: a.x, y: a.y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, dmg: wd.dmg, owner: a, ownerV: null, fac, life: dd, kind: wd.fire ? 'mo' : 'gr', rad: wd.radius, fuse: wd.fuse });
    g.audio.sfx('throw', a.x, a.y); a.swing = 0.4; g.combatT = 6; if (pl) crime(g, 'shots', a.x, a.y);
  }
  return true;
}
function melee(g, a) {
  const wd = a.wdef; a.cool = 1 / wd.rate; a.swing = 1; g.audio.sfx('swing', a.x, a.y, 0.5);
  const pl = a === g.player; let hit = false;
  _q.length = 0; g.hashA.query(a.x, a.y, wd.range + 20, _q);
  for (let i = 0; i < _q.length; i++) {
    const t = _q[i]; if (t === a || !t.on || t.dead || t.veh || t.inside !== a.inside) continue;
    if (!pl && isFriendly(t, a.fac)) continue;
    const dx = t.x - a.x, dy = t.y - a.y, d = Math.hypot(dx, dy); if (d > wd.range + t.r) continue;
    let da = Math.atan2(dy, dx) - a.aim; da = Math.atan2(Math.sin(da), Math.cos(da)); if (Math.abs(da) > wd.arc / 2 + 0.2 && d > 14) continue;
    const dm = wd.dmg * (pl ? 1 + 0.03 * g.skillLvl('shooting') : a.dmgMul || 0.6);
    damageActor(g, t, dm, { by: a, fac: a.fac, kind: 'melee', dx, dy }); t.kx += (dx / (d || 1)) * wd.knock; t.ky += (dy / (d || 1)) * wd.knock; t.stun = Math.max(t.stun, 0.28); hit = true;
    g.audio.sfx(wd.sfx, t.x, t.y, 0.8); g.noise(a.x, a.y, 250, { by: a });
  }
  const px = a.x + Math.cos(a.aim) * (wd.range - 6), py = a.y + Math.sin(a.aim) * (wd.range - 6);
  if (!g.scene) { _q.length = 0; g.world.propHash.query(px, py, 40, _q); for (const p of _q) if (!p.dead && p.hp < 1e8 && Math.hypot(p.x - px, p.y - py) < p.r + 14) { damageProp(g, p, wd.dmg, { by: a }); hit = true; } }
  _q.length = 0; g.hashV.query(px, py, 70, _q); for (const v of _q) if (v.on && !v.wreck && inVehicleBox(v, px, py, 4) && v !== a.veh) { damageVehicle(g, v, wd.dmg * 0.25, { by: a }); g.parts.burst(P.SPARK, px, py, 3, 100, 0.2, 1.5, '#ffd27a'); g.audio.sfx('hit', px, py, 0.6); hit = true; }
  if (pl && hit) { g.cam.shake = Math.max(g.cam.shake, 2.5); g.stats.shots++; }
  return true;
}

// ---------- damage ----------
export function damageActor(g, a, dmg, src = {}) {
  if (!a.on || a.dead) return;
  const by = src.by || null, pl = a === g.player;
  if (pl && (g.cheats.god || g.busting)) return;
  if (pl && a.heli && g.heliHit && src.kind !== 'crash') { g.heliHit(a.heli, dmg, src); return; }
  if (pl) { dmg *= g.focusT > 0 ? 0.7 : 1; if (a.roll > 0) dmg *= 0.5; }
  if (a.armor > 0) { const ab = Math.min(a.armor, dmg * 0.65); a.armor -= ab; dmg -= ab; }
  a.hp -= dmg; a.hurt = 0.25; a.lastHitBy = by; a.stun = Math.max(a.stun, src.kind === 'bullet' ? 0.12 : 0.2);
  const dx = src.dx || 0, dy = src.dy || 0, dl = Math.hypot(dx, dy) || 1;
  g.parts.burst(P.BLOOD, a.x, a.y, 5, 120, 0.5, 2.2, '#9d1018', 1.6, Math.atan2(dy, dx));
  if (src.kind === 'bullet') { a.kx += (dx / dl) * 40; a.ky += (dy / dl) * 40; g.audio.sfx('flesh', a.x, a.y, 0.6); }
  if (pl) { g.fx.hurt = Math.min(1, g.fx.hurt + dmg / 30); g.fx.ab = 1; g.cam.shake = Math.max(g.cam.shake, 5); g.stats.damageTaken += dmg; if (a.hp < 28 && !a.lowSound) { a.lowSound = true; } }
  if (by === g.player && !pl) {
    g.stats.hits++; g.xp('shooting', 0.5);
    if (a.fac === 'civ') { a.fear = 1; a.provoked = true; crime(g, a.hp <= 0 ? 'murder' : 'assault', a.x, a.y); }
    else if (a.fac === 'pd') { crime(g, a.hp <= 0 ? 'copKill' : 'copHit', a.x, a.y, true); }
    else if (['vip', 'sun', 'vel'].includes(a.fac)) { a.provoked = true; g.provoke(a.fac, a.hp <= 0 ? 8 : 1); }
  } else if (!pl && a.fac === 'civ') a.fear = 1;
  if (a.hp <= 0) killActor(g, a, src);
}
export function killActor(g, a, src = {}) {
  a.hp = 0; a.dead = true; a.deadT = 0; a.deadA = Math.random() * 6.28; a.roll = 0; a.cover = null;
  if (a.veh) g.exitVehicle(a, true);
  g.parts.burst(P.BLOOD, a.x, a.y, 10, 90, 0.8, 2.6, '#7d0c14');
  paintOnChunks(g.world, a.x, a.y, a.x, a.y, (c) => { c.fillStyle = 'rgba(100,8,14,.5)'; c.beginPath(); c.ellipse(a.x, a.y, 14, 10, Math.random() * 3, 0, 6.3); c.fill(); });
  const by = src.by || null, pl = a === g.player;
  if (pl) { g.onPlayerDeath(src); return; }
  g.stats.kills++; if (a.fac === 'civ') g.stats.civKills++;
  if (by === g.player) { g.style(0.14); g.xp('shooting', 2); if (a.fac !== 'civ') g.stats.gangKills++; }
  // loot
  const lt = a.fac === 'civ' ? [0.35, 8, 60] : a.fac === 'pd' ? [0.2, 20, 80] : [0.7, 20, 140];
  if (Math.random() < lt[0] && !a.noLoot) g.pickups.push({ type: 'cash', x: a.x + rnd(-8, 8), y: a.y + rnd(-8, 8), v: Math.round(rnd(lt[1], lt[2])), life: 80 });
  if (a.fac !== 'civ' && chance(0.3) && !a.noLoot) g.pickups.push({ type: 'ammo', x: a.x + rnd(-10, 10), y: a.y + rnd(-10, 10), v: 1, life: 80 });
  if (a.fac === 'pd' && chance(0.18)) g.pickups.push({ type: 'armor', x: a.x, y: a.y + 10, v: 25, life: 80 });
  if (g.onKill) g.onKill(a, src);
  g.audio.sfx('flesh', a.x, a.y, 0.8);
}
export function damageVehicle(g, v, dmg, src = {}) {
  if (!v.on || v.wreck) return;
  v.hp -= dmg / (1 + 0.15 * ((v.upg && v.upg.armor) || 0));
  if (src.by === g.player && v.npc && !v.exploded) { v.provoked = true; v.panic = 8; }
  if (v.hp <= 0) blow(g, v, src); else if (v.hp < v.def.hp * 0.2) v.burning = true;
}
export function blow(g, v, src = {}) {
  if (v.exploded) return; v.exploded = true; v.wreck = true; v.wreckT = 0; v.burning = true; v.siren = false; v.thr = 0;
  if (v.driver) { const d = v.driver; g.exitVehicle(d, true); damageActor(g, d, 70, { by: src.by, kind: 'explosion' }); d.kx += rnd(-200, 200); d.ky += rnd(-200, 200); }
  if (v.npc && src.by === g.player) { g.stats.kills++; g.style(0.18); }
  v.npc = null; v.ai = 'none'; v.vx *= 0.3; v.vy *= 0.3;
  if (v.mis && g.onVehDestroyed) g.onVehDestroyed(v);
  explode(g, v.x, v.y, 120, 150, { by: src.by, fac: src.fac || 'civ' }, true);
  g.cam.shake = Math.max(g.cam.shake, 10);
  if (src.by === g.player) g.stats.vehiclesDestroyed++;
}
export function explode(g, x, y, r, dmg, src = {}, fire = false) {
  g.audio.sfx('explosion', x, y, 1);
  const d0 = Math.hypot(x - g.cam.x, y - g.cam.y); g.cam.shake = Math.max(g.cam.shake, clamp(1 - d0 / 1000, 0, 1) * 26);
  g.tmpLights.push({ x, y, r: r * 3.2, col: '#ffae40', life: 0.55, max: 0.55, i: 1 });
  const pt = g.parts;
  pt.burst(P.FIRE, x, y, 30, 170, 0.8, 14, '#f90'); pt.burst(P.SMOKE, x, y, 16, 70, 2, 14, '#333'); pt.burst(P.DEBRIS, x, y, 14, 260, 0.8, 5, '#555'); pt.burst(P.SPARK, x, y, 18, 380, 0.6, 2, '#ffd27a');
  pt.emit(P.RING, x, y, 0, 0, 0.45, r * 0.5, '#ffd27a');
  paintOnChunks(g.world, x, y, x, y, (c) => { const gr = c.createRadialGradient(x, y, 2, x, y, r * 0.7); gr.addColorStop(0, 'rgba(0,0,0,.65)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = gr; c.fillRect(x - r, y - r, r * 2, r * 2); });
  _q.length = 0; g.hashA.query(x, y, r + 24, _q); const list = _q.slice();
  for (const a of list) {
    if (!a.on || a.dead || a.inside !== g.insideId) continue;
    const dx = a.x - x, dy = a.y - y, d = Math.hypot(dx, dy); if (d > r + a.r) continue;
    const f = Math.pow(1 - d / (r + a.r), 0.8);
    if (a.veh) { continue; }
    damageActor(g, a, dmg * f, { by: src.by, fac: src.fac, kind: 'explosion', dx, dy }); a.kx += (dx / (d || 1)) * 380 * f; a.ky += (dy / (d || 1)) * 380 * f; a.stun = 0.7; if (chance(0.5) && !a.dead) a.fire = 2.5;
  }
  _q.length = 0; g.hashV.query(x, y, r + 80, _q); const vl = _q.slice();
  for (const v of vl) {
    if (!v.on) continue;
    const dx = v.x - x, dy = v.y - y, d = Math.hypot(dx, dy); if (d > r + v.def.len / 2) continue;
    const f = 1 - d / (r + v.def.len / 2); v.vx += (dx / (d || 1)) * 520 * f / v.def.mass; v.vy += (dy / (d || 1)) * 520 * f / v.def.mass; v.av += (Math.random() - 0.5) * 6 * f;
    if (!v.wreck) damageVehicle(g, v, dmg * f * 1.1, src);
  }
  if (g.heli && g.heli.on) { const hd = Math.hypot(g.heli.x - x, g.heli.y - y); if (hd < r + 40) g.heli.hp -= dmg * (1 - hd / (r + 40)) * 1.4; }
  if (!g.scene) {
    _q.length = 0; g.world.propHash.query(x, y, r + 30, _q); const pl = _q.slice();
    for (const p of pl) { if (p.dead || p.hp > 1e8) continue; const d = Math.hypot(p.x - x, p.y - y); if (d < r) { if (p.expl) g.later(0.08 + Math.random() * 0.15, () => damageProp(g, p, 999, src)); else damageProp(g, p, dmg * (1 - d / r) + 20, src); } }
  }
  if (fire) g.fires.push({ x, y, r: r * 0.55, life: 5, by: src.by });
  g.noise(x, y, 1100, src); g.combatT = 8;
  if (src.by === g.player) crime(g, 'explosion', x, y);
}
export function updateFires(g, dt) {
  for (let i = g.fires.length - 1; i >= 0; i--) {
    const f = g.fires[i]; f.life -= dt; if (f.life <= 0) { g.fires.splice(i, 1); continue; }
    if (Math.random() < 0.8) g.parts.emit(P.FIRE, f.x + rnd(-f.r, f.r) * 0.7, f.y + rnd(-f.r, f.r) * 0.7, rnd(-8, 8), rnd(-30, -10), 0.6, 7, '#f90');
    if (Math.random() < 0.15) g.parts.emit(P.SMOKE, f.x + rnd(-f.r, f.r) * 0.5, f.y + rnd(-f.r, f.r) * 0.5, 0, -20, 1.4, 6, '#444');
    g.lights.add(f.x, f.y, f.r * 2.4, '#ff8a2a', 0.7);
    _q.length = 0; g.hashA.query(f.x, f.y, f.r + 20, _q);
    for (const a of _q) if (a.on && !a.dead && !a.veh && Math.hypot(a.x - f.x, a.y - f.y) < f.r) { a.fire = Math.max(a.fire, 2); }
    _q.length = 0; g.hashV.query(f.x, f.y, f.r + 60, _q);
    for (const v of _q) if (v.on && !v.wreck && Math.hypot(v.x - f.x, v.y - f.y) < f.r + v.def.len / 3) damageVehicle(g, v, 10 * dt, { by: f.by });
  }
  for (let i = g.geysers.length - 1; i >= 0; i--) { const s = g.geysers[i]; s.t -= dt; if (s.t <= 0) { g.geysers.splice(i, 1); continue; } g.parts.emit(P.WATER, s.x + rnd(-3, 3), s.y + rnd(-3, 3), rnd(-30, 30), rnd(-70, -20), 0.7, 2.2, '#bfe8ff'); }
}

// ---------- props ----------
export function damageProp(g, p, dmg, src = {}) {
  if (p.dead || p.hp > 1e8) return;
  p.hp -= dmg; g.stats.propsBroken += p.hp <= 0 ? 1 : 0;
  if (p.hp > 0) { if (p.t === 'hydrant') return; g.parts.burst(P.DEBRIS, p.x, p.y, 2, 80, 0.4, 3, '#a88'); return; }
  p.dead = true; const pt = g.parts, x = p.x, y = p.y;
  switch (p.t) {
    case 'crate': pt.burst(P.DEBRIS, x, y, 10, 160, 0.7, 5, '#b88a50'); g.audio.sfx('thud', x, y, 0.8); if (chance(0.4)) g.pickups.push({ type: pick(['cash', 'ammo', 'cash']), x, y, v: Math.round(rnd(10, 70)), life: 60 }); break;
    case 'barrel': explode(g, x, y, 110, 120, src, true); break;
    case 'pump': explode(g, x, y, 150, 160, src, true); break;
    case 'lamp': pt.burst(P.SPARK, x, y, 10, 220, 0.5, 2, '#9cf'); pt.burst(P.GLASS, x, y, 6, 120, 0.6, 3, '#ffe9a8'); g.audio.sfx('glass', x, y, 0.6); crime(g, 'vandal', x, y); break;
    case 'hydrant': g.geysers.push({ x, y, t: 9 }); g.audio.sfx('splash', x, y, 0.8); break;
    case 'cone': pt.burst(P.DEBRIS, x, y, 3, 90, 0.4, 3, '#ff6d00'); break;
    case 'fence': case 'sign': case 'bench': case 'bin': case 'hay': pt.burst(P.DEBRIS, x, y, 8, 140, 0.7, 4, p.t === 'hay' ? '#d4b04a' : '#777'); g.audio.sfx('thud', x, y, 0.6); break;
    default: pt.burst(P.DEBRIS, x, y, 6, 120, 0.6, 4, '#888'); break;
  }
}
