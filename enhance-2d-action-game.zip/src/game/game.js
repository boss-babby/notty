// ===== game.js — game state, fixed-timestep loop, systems orchestration, save/load, cheats =====
import { World, TS, WS, T } from './world.js';
import { Input } from './input.js';
import { AudioEngine } from './audio.js';
import { Particles, Lights, P } from './fx.js';
import { Bullets, updateFires, explode, switchWeapon, damageActor, finishReload } from './combat.js';
import { makeActors, makeVehicles, spawnActor, spawnVehicle, updatePlayerFoot, updatePlayerDrive, updateEntering, updateVehicle, collideAll, tryEnterVehicle, exitVehicle, nearestVehicle } from './actors.js';
import { updateActorsAI, updateVehicleAI, updatePopulation, updatePolice, updateSpikes, updateEvents, updateEmergency, unloadCops } from './ai.js';
import { newWanted, setStars, updateWanted } from './wanted.js';
import { SpatialHash, SpatialHash as SH, clamp, lerp, pick, rnd, chance } from './util.js';
import { buildOverview, clearSprites } from './gfx.js';
import { initRenderer, resizeRenderer, renderFrame, preloadChunks, QUAL } from './render.js';
import { createUI, pickBanter } from './ui.js';
import { buildInterior } from './interiors.js';
import { initHeli, updateChoppers, nearestChopper, boardHeli, exitHeli, chopperAudio } from './heli.js';
import { initMissions, updateMissions, startMission, missionMarkers, failMission, onMissionPickup, onSpotted, advanceMission, theftDeliver, startArena, abortMission, endSideJob, startSide } from './missions.js';
import { WEAPONS, WEAPON_ORDER, AMMO_MAX, VEHICLES, MISSIONS, STATIONS, PROPERTIES, SKILL_XP, SKILLS, SKINS, SHIRTS, PANTS, HAIR_COLORS } from './data.js';

const STEP = 1 / 60;
const MAP_DISC = ['safe', 'gus', 'bank', 'police', 'hosp', 'gun', 'clothes', 'casino', 'arena', 'nina', 'viper', 'pier', 'hotel', 'light', 'p_club', 'p_wh', 'p_apt', 'p_shop', 'cranes', 'park', 'kess'];
const NAMES = { safe: 'Safehouse', gus: "Gus's Garage", bank: 'Meridian Savings', police: 'Police HQ', hosp: 'Hospital', gun: 'Gun Den', clothes: 'Threads', casino: 'Casino', arena: 'The Pit', nina: 'Ledger Tower', viper: 'The Rusted Eel', pier: 'Sunset Pier', hotel: 'Sunset Hotel', light: 'Lighthouse', p_club: 'Club Tide', p_wh: 'Warehouse', p_apt: 'Apartments', p_shop: 'Lucky Noodle', cranes: 'The Cranes', park: 'Central Park', kess: 'Kessler Freight' };

export function createGame(root, ui0) {
  const canvas = document.createElement('canvas'); canvas.id = 'gc'; root.appendChild(canvas);
  const g = { root, canvas, ctx: canvas.getContext('2d', { alpha: false }) };
  g.settings = { quality: 'high', lamps: 'auto', glow: 1, bloom: true, crt: false, aberration: true, shake: true, flashes: true, colorblind: 'off', hud: 1, rotMap: false, debug: false };
  try { Object.assign(g.settings, JSON.parse(localStorage.getItem('nt_settings') || '{}')); } catch (e) { /* ignore */ }
  if (/Mobi|Android/i.test(navigator.userAgent) && !localStorage.getItem('nt_settings')) g.settings.quality = 'medium';
  g.input = new Input(canvas); g.audio = new AudioEngine();
  try { const sv = JSON.parse(localStorage.getItem('nt_audio') || 'null'); if (sv) Object.assign(g.audio.vol, sv); } catch (e) { /* ignore */ }
  g.parts = new Particles(1400); g.lights = new Lights(320); g.bullets = new Bullets(320);
  g.hashA = new SpatialHash(96); g.hashV = new SpatialHash(128);
  g.cam = { x: 3200, y: 2700, px: 3200, py: 2700, zoom: 1, shake: 0, shx: 0, shy: 0, kx: 0, ky: 0 };
  g.env = { hour: 16.2, day: 1, dark: 0, amb: [255, 247, 232], tint: [8, 12, 40], weather: 'clear', rain: 0, fog: 0, wet: 0, wind: 0.1, flash: 0, wtimer: 120, rainT: 0, fogT: 0, thunder: [] };
  g.fx = { hurt: 0, ab: 0 }; g.state = 'loading'; g.time = 0; g.frame = 0; g.dt60 = 0.016; g.frameDt = 0.016;
  Object.assign(g, { tmpLights: [], fires: [], geysers: [], pickups: [], noises: [], timers: [], events: [], wars: [], roadblocks: [], spikes: [], heli: { on: false, x: 0, y: 0, a: 0, hp: 0, rot: 0, vx: 0, vy: 0, fire: 0 },
    popT: 0, polT: 0, evT: 40, turfT: 160, emT: 5, combatT: 0, lastViolence: 0, copHostile: false, hasAllies: false, wheelOpen: false, hotwiring: false, markers: [], disc: {}, messages: [], newsLog: [], props: {}, shardsGot: 0, raceCool: 0,
    cheats: { god: false }, look: { skin: SKINS[1], hair: HAIR_COLORS[1], shirt: SHIRTS[1], pants: PANTS[0], style: 1, shades: false, vest: false }, viewW: 1600, viewH: 900, vehiclesDef: VEHICLES, aiming: false, focusT: 0, styleM: 0, timeScale: 1, fps: 60, regen: false,
    stats: {}, skills: {}, rep: {}, inv: { have: {}, mag: {}, ammo: {} }, scene: null, insideId: null, cash: 0, bank: 0, waypoint: null, tutC: {}, tutI: 0, lastCache: 0 });
  g.wanted = newWanted(); g.hashA.clear();
  resetStats(g);

  // ----- scene-aware helpers -----
  g.solidAt = (x, y) => (g.scene ? g.scene.solidAt(x, y) : g.world.solid(x, y));
  g.propSolidAt = (x, y) => { if (g.scene) return false; const q = []; g.world.propHash.query(x, y, 30, q); for (const p of q) if (!p.dead && p.solid && Math.hypot(p.x - x, p.y - y) < p.r + 3) return true; return false; };
  g.pushCircle = (x, y, r, props = true, vault = false) => (g.scene ? g.scene.pushCircle(x, y, r) : g.world.pushCircle(x, y, r, props, vault));
  g.lineClear = (x0, y0, x1, y1) => (g.scene ? g.scene.lineClear(x0, y0, x1, y1) : g.world.lineClear(x0, y0, x1, y1));
  g.mouseWorld = () => { const R = g.R, S = R.S || 1; return { x: (g.input.mx * g.dpr - g.W / 2) / S + (R.cx ?? g.cam.x), y: (g.input.my * g.dpr - g.H / 2) / S + (R.cy ?? g.cam.y) }; };
  g.noise = (x, y, r, src) => { g.noises.push({ x, y, r, src }); if (src && src.by === g.player) g.lastViolence = 25; };
  g.later = (t, fn) => g.timers.push({ t, fn });
  g.skillLvl = (k) => { const x = g.skills[k] || 0; let l = 0; for (let i = 0; i < SKILL_XP.length; i++) if (x >= SKILL_XP[i]) l = i; return l; };
  g.totalSkill = () => Object.keys(SKILLS).reduce((s, k) => s + g.skillLvl(k), 0);
  g.xp = (k, a) => { const b = g.skillLvl(k); g.skills[k] = (g.skills[k] || 0) + a; if (g.skillLvl(k) > b) { g.toast(SKILLS[k].n + ' increased to level ' + g.skillLvl(k), '#4fe0ff'); g.audio.sfx('levelup'); } };
  g.style = (v) => { g.styleM = clamp(g.styleM + v, 0, 1); };
  g.provoke = (fac, a) => { g.rep[fac] = clamp((g.rep[fac] || 0) - a, -100, 100); };
  g.explode = (x, y, r, d, s, f) => explode(g, x, y, r, d, s, f);
  g.exitVehicle = (a, f) => exitVehicle(g, a, f);
  g.unloadCops = (v) => unloadCops(g, v);
  g.setStars = (n) => setStars(g, n);
  g.clearWanted = () => { if (g.wanted.stars) { g.toast('Fresh paint — the cops lost the description.', '#7cff4f'); setStars(g, 0); } };
  g.news = (k, arg) => { g.newsLog.push({ k, arg, d: g.world.districtAt(g.player.x, g.player.y) }); if (g.newsLog.length > 14) g.newsLog.shift(); };
  g.priceMul = () => 1 - clamp((g.rep.vip + g.rep.sun + g.rep.vel) / 3, -30, 30) / 200;
  g.addDent = (v, wx, wy) => { if (v.dents.length > 9) v.dents.shift(); const dx = wx - v.x, dy = wy - v.y, c = Math.cos(v.a), s = Math.sin(v.a); v.dents.push({ x: dx * c + dy * s, y: -dx * s + dy * c, s: 2 + Math.random() * 4, r: Math.random() * 3 }); };
  g.stunt = (t) => { const r = Math.round(100 + t * 260); g.cash += r; g.stats.cashEarned += r; g.stats.stunts++; g.style(0.25); g.toast(`STUNT JUMP! ${t.toFixed(1)}s air  +$${r}`, '#ffe14a'); g.audio.sfx('cash'); };
  g.giveWeapon = (id, ammo = 0) => { const w = WEAPONS[id]; g.inv.have[id] = true; if (w.ammo) { g.inv.ammo[w.ammo] = Math.min(AMMO_MAX[w.ammo], (g.inv.ammo[w.ammo] | 0) + ammo); if (w.mag && g.inv.mag[id] === undefined) g.inv.mag[id] = 0; if (w.mag) { const take = Math.min(w.mag - (g.inv.mag[id] | 0), g.inv.ammo[w.ammo]); g.inv.mag[id] = (g.inv.mag[id] | 0) + take; g.inv.ammo[w.ammo] -= take; } } if (g.player.wid === 'fists') switchWeapon(g, g.player, id); };
  g.switchWeapon = (id) => switchWeapon(g, g.player, id);
  g.switchToMelee = () => switchWeapon(g, g.player, g.inv.have.bat ? 'bat' : 'fists');
  g.applyItem = (it) => {
    const p = g.player;
    if (it.k === 'weapon') { if (g.inv.have[it.id] && WEAPONS[it.id].type === 'melee') { g.toast('You already own that.', '#aaa'); return false; } g.giveWeapon(it.id, WEAPONS[it.id].pack || 0); g.toast('Bought ' + it.n, '#7cff4f'); return true; }
    if (it.k === 'ammo') { g.inv.ammo[it.id] = Math.min(AMMO_MAX[it.id], (g.inv.ammo[it.id] | 0) + it.q); return true; }
    if (it.k === 'heal') { p.hp = Math.min(p.max, p.hp + it.v); g.toast('+' + it.v + ' health', '#7cff4f'); return true; }
    if (it.k === 'armor') { p.armor = 100; g.toast('Armor restored', '#4aa8ff'); return true; }
    if (it.k === 'drink') { p.hp = Math.min(p.max, p.hp + it.v); g.toast('Cheers.', '#ffb347'); return true; }
    return false;
  };
  g.deliverCar = (type) => {
    const sp = g.world.pois.safe_park; const used = g.vehicles.filter((v) => v.on && v.owned).length; const v = spawnVehicle(g, type, sp.x + (used % 4) * 64, sp.y + 36 * Math.floor(used / 4), Math.PI / 2, { owned: true, hot: true, ai: 'none', force: true });
    if (!v) return false; g.waypoint = { x: v.x, y: v.y }; return true;
  };
  g.medic = (x, y) => { for (const a of g.actors) if (a.on && a.dead && !a.mis && Math.hypot(a.x - x, a.y - y) < 160) a.on = false; g.toast('Paramedics clear the scene.', '#bbb'); };
  g.extinguish = (x, y) => { g.fires = g.fires.filter((f) => Math.hypot(f.x - x, f.y - y) > 240); for (const v of g.vehicles) if (v.on && Math.hypot(v.x - x, v.y - y) < 240) v.burning = false; g.geysers.push({ x, y, t: 3 }); };
  g.nextStation = (d = 1) => { const a = g.audio; if (!a.ok) return; let s = a.station + (d > 0 ? 1 : -1); if (s >= STATIONS.length) s = -1; if (s < -1) s = STATIONS.length - 1; a.station = s; a.radioOn = s >= 0; a.step = 0; g.banterT = 6; g.audio.sfx('click'); a.nextT = 0; if (s >= 0) g.banter = { who: STATIONS[s].dj, text: 'You are listening to ' + STATIONS[s].n + ' — ' + STATIONS[s].genre, color: STATIONS[s].color, t: 5 }; };
  g.onSpotted = (a) => onSpotted(g, a);
  g.onKill = (a, src) => {
    if (a.eventThief && src.by === g.player) { g.cash += 150; g.toast('Thief stopped! +$150', '#7cff4f'); g.rep.pd = clamp((g.rep.pd || 0) + 5, -100, 100); }
    if (a.war && src.by === g.player) { const other = g.wars.find((w) => w.a.includes(a) || w.b.includes(a)); if (other) { const e = other.a.includes(a) ? other.B : other.A; g.rep[e] = clamp(g.rep[e] + 2, -100, 100); } }
    if (a.fac === 'pd' && src.by === g.player) g.rep.pd = clamp(g.rep.pd - 4, -100, 100);
    if (src.by === g.player && a.type === 'cop') g.copHostile = true;
  };
  g.onVehDestroyed = () => {};
  g.onEnterVehicle = (v) => {
    const a = g.audio; if (a.ok && a.station >= 0 && a.radioOn) { g.banterT = 8; } a.engine(0, 0.1, 0); g.audio.sfx('door', v.x, v.y, 0.5);
    if (v.spot) { v.spot.v = null; v.spot = null; }
  };
  g.onExitVehicle = () => { g.audio.engine(0, -1, 0); g.audio.setSiren(false); };
  g.onMissionDone = (d) => {
    const nx = MISSIONS.find((m) => !g.story.done[m.id] && (!m.after || g.story.done[m.after]));
    if (nx && !nx.auto) { g.messages.push({ from: nx.giver, text: `${nx.title}: meet me at ${g.world.pois[nx.at]?.name || nx.at}. Marked on your map.` }); g.waypoint = { ...g.world.pois[nx.at] }; g.toast('New message from ' + nx.giver, '#4fe0ff'); }
    g.saveGame(false); void d;
  };
  g.onBusted = () => { if (g.busting || g.player.dead) return; g.busting = true; g.stats.busted++; g.deathCard = { kind: 'busted', text: 'The PMPD took your weapons ammo and some cash.' }; g.audio.sfx('fail'); g.deathT = 3; g.deathKind = 'busted'; };
  g.onPlayerDeath = () => { if (g.deathT > 0) return; g.stats.wasted++; g.deathCard = { kind: 'wasted', text: 'Hospital fees apply.' }; g.audio.sfx('wasted'); g.deathT = 3.4; g.deathKind = 'wasted'; g.timeScale = 0.4; };

  // ----- settings -----
  g.applySettings = () => {
    const s = g.settings; const q = g.settings.quality; if (g._lastQ !== q) { g._lastQ = q; clearSprites(); if (g.R) resizeRenderer(g); }
    const f = { off: 'none', protanopia: 'url(#cb-pro)', deuteranopia: 'url(#cb-deu)', tritanopia: 'url(#cb-tri)' }[s.colorblind]; canvas.style.filter = f === 'none' ? '' : f;
    g.audio.applyVol(); g.cam.shakeOn = s.shake;
  };
  g.saveSettings = () => { try { localStorage.setItem('nt_settings', JSON.stringify(g.settings)); localStorage.setItem('nt_audio', JSON.stringify(g.audio.vol)); } catch (e) { /* ignore */ } };
  root.insertAdjacentHTML('beforeend', `<svg width="0" height="0" style="position:absolute"><defs>
    <filter id="cb-pro"><feColorMatrix type="matrix" values="0.567 0.433 0 0 0  0.558 0.442 0 0 0  0 0.242 0.758 0 0  0 0 0 1 0"/></filter>
    <filter id="cb-deu"><feColorMatrix type="matrix" values="0.625 0.375 0 0 0  0.7 0.3 0 0 0  0 0.3 0.7 0 0  0 0 0 1 0"/></filter>
    <filter id="cb-tri"><feColorMatrix type="matrix" values="0.95 0.05 0 0 0  0 0.433 0.567 0 0  0 0.475 0.525 0 0  0 0 0 1 0"/></filter></defs></svg>`);

  g.ui = ui0 || null;
  initHeli(g); g.scopeZ = 2.4;
  return g;
}
// (re)build the world from a seed: authored anchors stay, the procedural Frontier + all scatter change
function useSeed(g, seed) {
  seed = Number.isFinite(+seed) && seed !== undefined && seed !== null && seed !== '' ? Math.abs(Math.floor(+seed)) % 2147483647 : g.world.seed;
  if (seed === g.world.seed) return;
  g.world = new World(seed); clearSprites(); g.overview = buildOverview(g.world); g.R && g.R.lm && (g.world.chunks.clear());
  g.toast('World seed ' + seed + ' — new Frontier generated', '#4fe0ff');
}
function resetStats(g) {
  g.stats = { playTime: 0, missions: 0, cashEarned: 0, kills: 0, civKills: 0, gangKills: 0, crimes: 0, distance: 0, drift: 0, stunts: 0, vehiclesDestroyed: 0, carjacks: 0, propsBroken: 0, damageTaken: 0, busted: 0, wasted: 0, shots: 0, hits: 0, vehiclesDriven: 0 };
  g.skills = { driving: 0, shooting: 0, stamina: 0, stealth: 0 }; g.rep = { vip: 0, sun: 0, vel: 0, pd: 0 };
}

// ===== boot / lifecycle =====
export async function bootGame(root) {
  const g = createGame(root);
  g.ui = createUI(g); initMissions(g); g.messages.push({ from: 'System', text: 'Welcome to Port Meridian.' });
  g.ui.loading(0.05, 'Seeding city generator…'); await tick();
  g.world = new World(1337); g.ui.loading(0.35, 'Laying roads, blocks and canals…'); await tick();
  g.actors = makeActors(130); g.vehicles = makeVehicles(110); g.player = g.actors[0]; g.player.init('player', 3200, 2700, { fac: 'pl', look: g.look }); g.player.look = g.look;
  g.overview = buildOverview(g.world); g.ui.loading(0.6, 'Drawing the minimap…'); await tick();
  initRenderer(g); g.applySettings(); g.ui.loading(0.8, 'Streaming chunks…'); await tick();
  g.cam.x = g.cam.px = 3200; g.cam.y = g.cam.py = 2700; g.cheats.god = true; g.inv.have.fists = true;
  g.menuAngle = 0; g.state = 'menu'; preloadChunks(g, 9); g.ui.loading(1, 'Ready'); g.ui.showMenu();
  wireGame(g);
  const onResize = () => { resizeRenderer(g); }; window.addEventListener('resize', onResize);
  let raf = 0, last = performance.now() / 1000, acc = 0, fpsT = 0, fpsC = 0, alive = true;
  const loop = (ts) => {
    if (!alive) return; raf = requestAnimationFrame(loop);
    const now = ts / 1000; let fd = Math.min(0.1, now - last); last = now; g.frameDt = fd; g.dt60 = fd; g.frame++;
    fpsT += fd; fpsC++; if (fpsT >= 0.5) { g.fps = Math.round(fpsC / fpsT); fpsT = 0; fpsC = 0; }
    g.input.poll(); try { globalKeys(g); } catch (e) { console.error(e); }
    const paused = g.uiOpen || g.state === 'loading';
    if (!paused && g.state !== 'photo') {
      acc += fd * g.timeScale;
      let n = 0; while (acc >= STEP && n < 5) { try { stepSim(g, STEP); } catch (e) { console.error(e); } g.input.endStep(); acc -= STEP; n++; }
      if (n === 5) acc = 0;
    } else { if (g.state === 'photo') photoStep(g, fd); g.input.endStep(); }
    try { renderFrame(g, g.state === 'photo' ? 1 : Math.min(1, acc / STEP)); g.ui.update(fd); audioStep(g, fd); } catch (e) { console.error(e); }
  };
  raf = requestAnimationFrame(loop);
  g.destroy = () => { alive = false; cancelAnimationFrame(raf); window.removeEventListener('resize', onResize); g.input.destroy(); try { g.audio.ctx && g.audio.ctx.close(); } catch (e) { /* ignore */ } root.innerHTML = ''; };
  window.__game = g; return g;
}
const tick = () => new Promise((r) => setTimeout(r, 16));

function wireGame(g) {
  const startAudio = () => { g.audio.init(); g.audio.resume(); }; window.addEventListener('pointerdown', startAudio); window.addEventListener('keydown', startAudio);
  g.newGame = () => {
    resetStats(g); initMissions(g); g.inv = { have: { fists: true }, mag: {}, ammo: {} }; g.cash = 150; g.bank = 0; g.props = {}; g.shardsGot = 0; g.disc = {}; g.messages = []; g.newsLog = []; g.waypoint = null; g.styleM = 0; g.focusT = 0; g.tutI = 0; g.tutC = {}; g.tutDone = false;
    for (const p of g.world.props) if (p.t === 'shard') p.dead = false; g.world.heat.fill(0);
    for (const a of g.actors) a.on = false; for (const v of g.vehicles) v.on = false; g.pickups = []; g.fires = []; g.events = []; g.wars = []; g.spikes = []; g.roadblocks = []; g.heli.on = false;
    useSeed(g, g.pendingSeed); g.world.turf = g.world.turf0.slice();
    const st = g.world.pois.start; g.choppers.length = 0; g.chopper = null; g.player.init('player', st.x, st.y - 40, { fac: 'pl', look: g.look, a: 0 }); g.player.look = g.look; g.player.wid = 'fists'; g.player.wdef = WEAPONS.fists;
    g.wanted = newWanted(); g.cheats.god = false; g.scene = null; g.insideId = null; g.env.hour = 19.2; g.env.day = 1; g.env.weather = 'clear'; g.env.rain = 0; g.env.wet = 0; g.env.fog = 0; g.timeScale = 1; g.deathT = 0; g.busting = false; g.deathCard = null;
    g.cam.x = g.cam.px = g.player.x; g.cam.y = g.cam.py = g.player.y; g.state = 'play'; g.ui.hud.style.display = 'block'; g.audio.station = -1; g.audio.radioOn = false;
    g.rep = { vip: 0, sun: 0, vel: 0, pd: 0 };
    startMission(g, MISSIONS[0]); g.toast('Welcome to Port Meridian, Rook.  (world seed ' + g.world.seed + ')', '#4fe0ff');
  };
  g.toMenu = () => { g.state = 'menu'; g.choppers.length = 0; g.chopper = null; g.player.heli = null; g.cheats.god = true; g.scene = null; g.insideId = null; abortMission(g); g.ui.showMenu(); };
  g.enterPhoto = () => { g.state = 'photo'; g.photo = { x: g.cam.x, y: g.cam.y, zoom: g.cam.zoom, f: 0 }; g.ui.photoUI(true); g.ui.hud.style.display = 'none'; };
  g.exitPhoto = () => { g.state = 'play'; g.ui.photoUI(false); g.canvas.style.filter = ''; g.applySettings(); };
  // ----- save / load -----
  g.saveGame = (manual) => {
    if (g.state !== 'play') return; try {
      const p = g.player, owned = g.vehicles.filter((v) => v.on && v.owned && !v.wreck).map((v) => ({ t: v.type, c: v.color, u: v.upg, pl: v.plate, x: v.x, y: v.y, a: v.a, hp: v.hp })).slice(0, 6);
      const d = { v: 1, seed: g.world.seed, p: { x: g.scene ? g.scene.building.door.x : p.x, y: g.scene ? g.scene.building.door.y : p.y, hp: p.hp, ar: p.armor, w: p.wid }, cash: g.cash, bank: g.bank, look: g.look, inv: g.inv, skills: g.skills, rep: g.rep, story: g.story, stats: g.stats, props: g.props, disc: g.disc, shards: g.world.props.filter((x) => x.t === 'shard' && x.dead).map((x) => x.id), shardsGot: g.shardsGot, env: { h: g.env.hour, d: g.env.day, w: g.env.weather }, theft: g.theft, turf: g.world.turf, owned, msgs: g.messages, tut: g.tutDone, styleM: g.styleM };
      localStorage.setItem('nt_save', JSON.stringify(d)); if (manual) { g.toast('Game saved', '#7cff4f'); g.audio.sfx('pickup'); } else if (g.state === 'play') g.toast('Autosaved', '#889');
    } catch (e) { if (manual) g.toast('Save failed (storage unavailable)', '#ff7788'); }
  };
  g.loadGame = () => {
    let d; try { d = JSON.parse(localStorage.getItem('nt_save')); } catch (e) { d = null; } if (!d) { g.newGame(); return; }
    useSeed(g, d.seed); resetStats(g); initMissions(g); Object.assign(g.stats, d.stats); Object.assign(g.skills, d.skills); Object.assign(g.rep, d.rep); g.story = d.story; g.theft = d.theft || g.theft; g.look = d.look; g.inv = d.inv; g.cash = d.cash; g.bank = d.bank; g.props = d.props || {}; g.disc = d.disc || {}; g.shardsGot = d.shardsGot || 0; g.messages = d.msgs || []; g.styleM = d.styleM || 0; g.tutDone = d.tut;
    for (const p of g.world.props) if (p.t === 'shard') p.dead = d.shards.includes(p.id); if (d.turf && d.turf.length === g.world.turf.length) g.world.turf = d.turf; g.world.heat.fill(0);
    for (const a of g.actors) a.on = false; for (const v of g.vehicles) v.on = false; g.pickups = []; g.fires = []; g.events = []; g.wars = []; g.spikes = []; g.roadblocks = [];
    g.choppers.length = 0; g.chopper = null; g.player.init('player', d.p.x, d.p.y + 24, { fac: 'pl', look: g.look }); g.player.look = g.look; g.player.hp = d.p.hp; g.player.armor = d.p.ar; g.player.wid = d.p.w; g.player.wdef = WEAPONS[d.p.w] || WEAPONS.fists;
    for (const o of d.owned || []) { const v = spawnVehicle(g, o.t, o.x, o.y, o.a, { owned: true, hot: true, color: o.c, upg: o.u, plate: o.pl }); if (v) v.hp = o.hp; }
    g.env.hour = d.env.h; g.env.day = d.env.d; g.env.weather = d.env.w; g.wanted = newWanted(); g.cheats.god = false; g.scene = null; g.insideId = null; g.timeScale = 1; g.deathT = 0; g.busting = false; g.deathCard = null; g.mission = null; g.obj = null;
    g.cam.x = g.cam.px = g.player.x; g.cam.y = g.cam.py = g.player.y; g.state = 'play'; g.ui.hud.style.display = 'block'; g.toast('Game loaded', '#7cff4f');
    if (!g.story.done.m1) startMission(g, MISSIONS[0]);
  };
  g.startMission = (i) => startMission(g, MISSIONS[i]);
  // Summon a vehicle next to the player. Always succeeds: it frees a pool slot (evicting the farthest unoccupied car) and
  // searches a ring around the player for a spot that is not inside a building, water, a solid prop or another car.
  g.summonVehicle = (type, quiet) => {
    const p = g.player, def = VEHICLES[type]; if (!def) return null;
    if (g.scene) { g.toast('Step outside first to summon a vehicle', '#ff7788'); return null; }
    const base = p.veh ? p.veh.a : p.a, w = g.world, hw = def.len / 2 + 6;
    const clear = (x, y, a) => { for (const [ox, oy] of [[0, 0], [hw, 0], [-hw, 0], [0, def.wid / 2 + 3], [0, -def.wid / 2 - 3]]) { const px = x + Math.cos(a) * ox - Math.sin(a) * oy, py = y + Math.sin(a) * ox + Math.cos(a) * oy, t = w.tileAt(px, py); if (t === T.BUILDING || t === T.WATER) return false; } if (w.pushCircle(x, y, def.wid / 2 + 8, true).hit) return false; for (const v of g.vehicles) if (v.on && Math.hypot(v.x - x, v.y - y) < (def.len + v.def.len) / 2 * 0.8) return false; return true; };
    let pos = null;
    for (const r of [96, 128, 164, 210, 270, 340]) { for (const da of [0, 0.6, -0.6, 1.2, -1.2, 1.9, -1.9, 2.6, -2.6, 3.14]) { const a = base + da, x = p.x + Math.cos(a) * r, y = p.y + Math.sin(a) * r; const road = w.isRoad(x, y) ? ((w.metaAt(x, y) & 2) ? 0 : Math.PI / 2) : null; const ang = road !== null ? road : base + Math.PI / 2; if (clear(x, y, ang)) { pos = { x, y, a: ang }; break; } } if (pos) break; }
    if (!pos) pos = { x: p.x + Math.cos(base) * 110, y: p.y + Math.sin(base) * 110, a: base };
    const v = spawnVehicle(g, type, pos.x, pos.y, pos.a, { hot: true, ai: 'none', force: true, owned: !!quiet });
    if (!v) { g.toast('Could not summon ' + def.n, '#ff7788'); return null; }
    v.owned = !!quiet; if (!quiet) { g.toast(def.n + ' summoned — press E to get in', '#7cff4f'); g.audio.sfx('pickup'); } return v;
  };
  g.setLamps = (m) => setLamps(g, m); g.refreshEnv = () => updateEnv(g, 0);
  g.travel = (x, y, label) => g.ui.fade(() => { teleport(g, x, y); g.toast('Arrived: ' + label, '#4fe0ff'); g.wanted.stars && g.toast('You are still wanted…', '#ff7788'); }, 700);
  g.cheat = (d, tp) => {
    const p = g.player;
    if (d.c === 'cash') g.cash += 10000; else if (d.c === 'heal') { p.hp = p.max; p.armor = 100; if (p.veh) { p.veh.hp = p.veh.def.hp; p.veh.burning = false; p.veh.flat = false; } }
    else if (d.c === 'guns') { for (const k of WEAPON_ORDER) if (k !== 'fists') g.giveWeapon(k, 200); }
    else if (d.c === 'god') { g.cheats.god = !g.cheats.god; g.toast('Invincible: ' + g.cheats.god, '#ffe14a'); }
    else if (d.c === 'skip') { if (g.mission) { g.cut = null; advanceMission(g); g.toast('Step skipped'); } }
    else if (d.c === 'shards') { for (const q of g.world.props) if (q.t === 'shard' && !q.dead) { q.dead = true; g.shardsGot++; } g.cash += 10000; }
    else if (d.c === 'tp') { const q = g.world.pois[d.tp || tp]; if (q) teleport(g, q.x, q.y + 34); } else if (d.c === 'wp' && g.waypoint) teleport(g, g.waypoint.x, g.waypoint.y);
    else if (d.c === 'war') { g.turfT = 0; } else if (d.c === 'event') g.evT = 0; else if (d.c === 'story') { for (const m of MISSIONS) g.story.done[m.id] = true; g.toast('All missions marked done'); }
    else if (d.veh) return g.summonVehicle(d.veh);
    else if (d.heli) return g.summonHeli(d.heli, d.col);
    else if (d.lamp) setLamps(g, d.lamp);
    else if (d.c === 'fixcar') { const v = p.veh || nearestVehicle(g, p.x, p.y, 400); if (v) { v.hp = v.def.hp; v.burning = false; v.flat = false; v.wreck = false; g.toast('Vehicle repaired', '#7cff4f'); } else g.toast('No vehicle nearby', '#ff7788'); }
    else if (d.c === 'ownall') { for (const k of Object.keys(VEHICLES)) if (!['bus', 'police', 'ambulance', 'swat', 'army', 'fire', 'taxi'].includes(k)) g.summonVehicle(k, true); g.toast('Garage delivered', '#7cff4f'); }
    else if (d.w !== undefined) { setStars(g, +d.w); if (!+d.w) g.wanted.heat = 0; }
    else if (d.t !== undefined) g.env.hour = +d.t;
    else if (d.wx) setWeather(g, d.wx, true);
  };
}
function teleport(g, x, y) { if (g.scene) { g.scene = null; g.insideId = null; } const p = g.player; if (p.veh) { p.veh.x = x; p.veh.y = y; p.veh.vx = p.veh.vy = 0; } if (p.heli) { p.heli.x = x; p.heli.y = y; p.heli.vx = p.heli.vy = 0; } p.x = x; p.y = y; g.cam.x = g.cam.px = x; g.cam.y = g.cam.py = y; g.world.chunks.clear(); }

// ===== global keys (work while paused) =====
function globalKeys(g) {
  const inp = g.input, U = g.ui;
  if (inp.pr.has('F3')) { g.settings.debug = !g.settings.debug; g.saveSettings(); }
  if (g.state === 'play' && inp.pr.has('KeyL') && !g.uiOpen && !g.cut) setLamps(g, null);
  if (g.state === 'menu' || g.state === 'loading') { if (inp.pressed('pause')) U.escape(); inp.pr.clear(); return; }
  if (inp.pr.has('Backquote') || inp.pr.has('F2')) { if (U.stack.length && U.stack[U.stack.length - 1].el.querySelector('.cheat')) U.close(); else if (!g.uiOpen) U.openCheats(); }
  if (g.state === 'photo') { if (inp.pressed('pause')) g.exitPhoto(); return; }
  if (inp.pressed('pause')) { if (!U.escape()) { if (g.state === 'play' && !g.cut && !g.hotwiring) U.openPause(); } inp.pr.delete('Escape'); inp.pr.delete('KeyP'); }
  if (g.state === 'play' && !g.cut && !g.hotwiring) {
    if (inp.pressed('phone')) { if (g.uiOpen && U.stack[U.stack.length - 1].el.querySelector('.phone')) U.close(); else if (!g.uiOpen) { U.openPhone(); g.tutC.phone = 1; } }
    if (inp.pressed('map')) { if (g.uiOpen && U.stack[U.stack.length - 1].el.querySelector('#bigmap')) U.close(); else if (!g.uiOpen) { U.openMap(); g.tutC.phone = 1; } }
  }
  if (g.cut && !g.uiOpen && (inp.pressed('interact') || inp.pressed('jump') || inp.pr.has('Mouse0') || inp.pr.has('Enter'))) {
    const L = g.cut.lines[g.cut.i];
    if (!g.cut.typed) g.cut.t = 99; else { g.cut.i++; g.cut.t = 0; g.audio.sfx('click'); if (g.cut.i >= g.cut.lines.length) { g.cut = null; } }
    inp.pr.clear(); void L;
  }
}
function photoStep(g, dt) {
  const ph = g.photo, inp = g.input, m = inp.move(), sp = 500 / ph.zoom;
  ph.x += m.x * sp * dt; ph.y += m.y * sp * dt; ph.zoom = clamp(ph.zoom * (1 - inp.wheel * 0.1), 0.4, 2.2);
  g.cam.x = g.cam.px = ph.x; g.cam.y = g.cam.py = ph.y; g.cam.zoom = ph.zoom; g.cam.shx = g.cam.shy = 0;
  for (let i = 1; i <= 4; i++) if (inp.pr.has('Digit' + i)) { ph.f = i - 1; g.canvas.style.filter = ['', 'grayscale(1) contrast(1.25)', 'saturate(1.7) contrast(1.1)', 'sepia(.85) contrast(1.1)'][ph.f]; }
  if (inp.pr.has('Enter')) { g.canvas.toBlob((b) => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'neon-tide-photo.png'; a.click(); g.toast('Photo saved', '#7cff4f'); }); }
}

// ===== environment: time of day, weather =====
const AMB = [[0, [84, 98, 152]], [4.5, [88, 102, 156]], [5.5, [150, 122, 150]], [6.3, [255, 184, 136]], [7.6, [255, 228, 200]], [9, [255, 247, 238]], [12, [255, 255, 252]], [15.5, [255, 247, 234]], [17.3, [255, 216, 164]], [18.5, [255, 156, 106]], [19.5, [176, 108, 128]], [20.6, [104, 100, 154]], [22, [84, 98, 152]], [24, [84, 98, 152]]];
function setWeather(g, w, instant) {
  const e = g.env; e.weather = w; e.rainT = w === 'rain' ? 0.7 : w === 'storm' ? 1 : 0; e.fogT = w === 'fog' ? 0.85 : w === 'storm' ? 0.15 : 0; e.windT = w === 'storm' ? 1 : w === 'rain' ? 0.4 : 0.1; e.wtimer = 100 + Math.random() * 140;
  if (instant) { e.rain = e.rainT; e.fog = e.fogT; e.wet = e.rainT; }
}
function updateEnv(g, dt) {
  const e = g.env; e.hour += dt / 60; if (e.hour >= 24) { e.hour -= 24; e.day++; dailyTick(g); }
  const h = e.hour; let d;
  if (h >= 7.5 && h <= 17.5) d = 0; else if (h > 5 && h < 7.5) d = 1 - (h - 5) / 2.5; else if (h > 17.5 && h < 20.5) d = (h - 17.5) / 3; else d = 1;
  d = d * d * (3 - 2 * d); const twi = h > 5 && h < 7.5 || h > 17.5 && h < 20.5; e.dark = d * 0.86 + (e.weather === 'storm' ? 0.12 * (1 - d) : 0) + e.fog * 0.05;
  const tw = twi ? (1 - Math.abs(d - 0.5) * 2) : 0; e.tint = [Math.round(6 + tw * 70), Math.round(10 + tw * 14), Math.round(38 + tw * 12)];
  // ambient sky colour (multiplied over the world): moonlight → dawn gold → neutral noon → golden hour → sunset → dusk
  { let a = AMB[0], b = AMB[AMB.length - 1]; for (let i = 0; i < AMB.length - 1; i++) if (h >= AMB[i][0] && h <= AMB[i + 1][0]) { a = AMB[i]; b = AMB[i + 1]; break; }
    const f = b[0] === a[0] ? 0 : (h - a[0]) / (b[0] - a[0]), k2 = f * f * (3 - 2 * f); let r = a[1][0] + (b[1][0] - a[1][0]) * k2, gg = a[1][1] + (b[1][1] - a[1][1]) * k2, bb = a[1][2] + (b[1][2] - a[1][2]) * k2;
    const wx = Math.min(1, e.rain * 0.8 + e.fog * 0.5), av = (r + gg + bb) / 3; r += (av * 0.88 - r) * wx * 0.5; gg += (av * 0.92 - gg) * wx * 0.5; bb += (av * 1.0 - bb) * wx * 0.45; const dim = 1 - wx * 0.22 - (e.weather === 'storm' ? 0.08 : 0);
    e.amb = [Math.round(r * dim), Math.round(gg * dim), Math.round(bb * dim)]; }
  e.wtimer -= dt; if (e.wtimer <= 0 && !g.mission) { const r = Math.random(); setWeather(g, r < 0.42 ? 'clear' : r < 0.68 ? 'rain' : r < 0.84 ? 'fog' : 'storm'); if (e.weather !== 'clear') g.toast('Weather: ' + e.weather, '#9ac'); }
  const k = 1 - Math.exp(-0.35 * dt); e.rain += (e.rainT - e.rain) * k; e.fog += (e.fogT - e.fog) * k * 0.6; e.wind += ((e.windT || 0.1) - e.wind) * k; e.wet += ((e.rain > 0.15 ? 1 : 0) - e.wet) * (e.rain > 0.15 ? 1 - Math.exp(-0.15 * dt) : 1 - Math.exp(-0.03 * dt));
  if (e.weather === 'storm') { e.lt = (e.lt || 4) - dt; if (e.lt <= 0) { e.lt = 3 + Math.random() * 8; e.flash = 1; g.later(0.3 + Math.random() * 2.2, () => g.audio.sfx('thunder', g.cam.x + rnd(-600, 600), g.cam.y + rnd(-600, 600), 1)); } }
  e.flash = Math.max(0, e.flash - dt * 2.6);
  // street lights + window glow schedule: switch on through the evening (17:10 → 19:10), off through dawn (05:00 → 06:50); bad weather lifts them in daytime
  { let ev; if (h >= 19.2 || h <= 5.0) ev = 1; else if (h >= 17.2) ev = (h - 17.2) / 2.0; else if (h > 5.0 && h < 6.9) ev = 1 - (h - 5.0) / 1.9; else ev = 0;
    ev = ev * ev * (3 - 2 * ev); const wx = Math.min(1, e.rain * 0.6 + e.fog * 0.5 + (e.weather === 'storm' ? 0.25 : 0));
    e.eve = Math.max(ev, wx * 0.5); const m = g.settings.lamps; e.lamp = m === 'on' ? 1 : m === 'off' ? 0 : e.eve; }
}
const LAMP_MODES = ['auto', 'on', 'off'], LAMP_NAMES = { auto: 'AUTO — on from dusk to dawn', on: 'ALWAYS ON', off: 'ALWAYS OFF' };
export function setLamps(g, mode) {
  g.settings.lamps = mode && LAMP_MODES.includes(mode) ? mode : LAMP_MODES[(LAMP_MODES.indexOf(g.settings.lamps) + 1) % 3];
  g.saveSettings(); g.toast('Street lights: ' + LAMP_NAMES[g.settings.lamps], '#ffcf7a'); g.audio.sfx('click'); updateEnv(g, 0);
}
function dailyTick(g) {
  let inc = 0; for (const p of PROPERTIES) if (g.props[p.id]) inc += p.income; const int = Math.round(g.bank * 0.02);
  if (inc || int) { g.cash += inc; g.bank += int; g.stats.cashEarned += inc; g.toast(`New day: property income ${'$' + inc}${int ? ', bank interest $' + int : ''}`, '#7cff4f'); }
}

// ===== main simulation step =====
function stepSim(g, dt) {
  const p = g.player, inp = g.input, cam = g.cam;
  // snapshots for interpolation
  for (const a of g.actors) if (a.on) { a.px = a.x; a.py = a.y; a.pa = a.a; } for (const v of g.vehicles) if (v.on) { v.px = v.x; v.py = v.y; v.pa = v.a; } cam.px = cam.x; cam.py = cam.y;
  g.time += dt; g.insideId = g.scene ? g.scene.id : null; p.inside = g.insideId;
  g.fx.hurt = Math.max(0, g.fx.hurt - dt * 1.3); g.fx.ab = Math.max(0, g.fx.ab - dt * 2.2); g.combatT = Math.max(0, g.combatT - dt); g.lastViolence = Math.max(0, g.lastViolence - dt);
  if (g.state === 'menu') { menuStep(g, dt); return; }
  g.stats.playTime += dt;
  g.R && (g.R.t = g.time);
  if (g.deathT > 0) { g.deathT -= dt; if (g.deathT <= 0) respawn(g); }
  updateEnv(g, dt);
  // timers
  for (let i = g.timers.length - 1; i >= 0; i--) { const t = g.timers[i]; t.t -= dt; if (t.t <= 0) { g.timers.splice(i, 1); t.fn(); } }
  g.tmpLights = g.tmpLights.filter((l) => (l.life -= dt) > 0);
  g.parts.update(dt);
  if (g.cut) { cameraStep(g, dt); updateMissions(g, dt); g.noises.length = 0; return; }
  // focus
  if (g.focusT > 0) { g.focusT -= dt / g.timeScale * 0.9; g.styleM = Math.max(0, g.styleM - dt / (g.totalSkill() >= 8 ? 6 : 4)); g.timeScale = 0.38; if (g.focusT <= 0 || g.styleM <= 0) { g.focusT = 0; g.timeScale = g.deathT > 0 ? 0.4 : 1; } }
  else { if (g.deathT <= 0) g.timeScale = 1; g.styleM = Math.max(0, g.styleM - dt * 0.004); }
  if (inp.pressed('focus') && g.totalSkill() >= 3 && g.styleM >= 0.35 && g.focusT <= 0 && !p.dead) { g.focusT = 3 + (g.totalSkill() >= 8 ? 2 : 0); g.audio.sfx('slowmo'); g.toast('TIDAL FOCUS', '#4fe0ff'); }
  // hash rebuild
  g.hashA.clear(); g.hashV.clear();
  for (const a of g.actors) if (a.on && !a.dead && a.inside === g.insideId) g.hashA.insert(a, a.x, a.y);
  if (!g.scene) for (const v of g.vehicles) if (v.on) g.hashV.insert(v, v.x, v.y);
  // player
  if (!p.dead && !g.hotwiring && !g.busting) {
    if (p.heli) { /* flown by updateChoppers */ }
    else if (p.entering > 0) updateEntering(g, dt);
    else if (p.veh) { updatePlayerDrive(g, dt); }
    else updatePlayerFoot(g, dt);
    if (inp.pressed('interact') && p.entering <= 0) interact(g);
    if (p.hp < p.max * 0.25 && p.hp > 0 && g.tutI > 2 && false) p.hp += 0;
  } else if (p.dead) { p.deadT += dt; }
  else { p.vx = p.vy = 0; }
  if (p.veh) { p.x = p.veh.x; p.y = p.veh.y; }
  updateChoppers(g, dt); if (p.heli) { p.x = p.heli.x; p.y = p.heli.y; }
  // AI & physics
  updateActorsAI(g, dt);
  if (!g.scene) {
    for (const v of g.vehicles) { if (!v.on) continue; if (Math.hypot(v.x - p.x, v.y - p.y) > 2300 && !v.mis) continue; if (!v.driver) updateVehicleAI(g, v, dt); updateVehicle(g, v, dt); }
    collideAll(g);
  }
  g.bullets.update(g, dt); updateFires(g, dt);
  g.noises.length = 0;
  // wanted / police / world life
  updateWanted(g, dt); updatePolice(g, dt); updateSpikes(g, dt); updatePopulation(g, dt); updateEvents(g, dt); updateEmergency(g, dt);
  if (g.blipEvent) { g.blipEvent.t -= dt; if (g.blipEvent.t <= 0) g.blipEvent = null; }
  if (g.wanted.stars === 0) g.copHostile = false;
  // world heat decays
  if (Math.floor(g.time) !== Math.floor(g.time - dt)) for (let i = 0; i < g.world.heat.length; i++) g.world.heat[i] *= 0.985;
  // pickups, shards, discovery
  pickupStep(g, dt);
  // missions + markers
  updateMissions(g, dt); g.markers = missionMarkers(g); if (g.waypoint) { if (Math.hypot(g.waypoint.x - p.x, g.waypoint.y - p.y) < 90) { g.waypoint = null; } else g.markers.push({ x: g.waypoint.x, y: g.waypoint.y, kind: 'wp', color: '#7cff4f', label: 'Waypoint' }); }
  cameraStep(g, dt); promptStep(g); tutorialStep(g, dt); radioStep(g, dt);
  if (g.autoT === undefined) g.autoT = 90; g.autoT -= dt; if (g.autoT <= 0) { g.autoT = 90; if (!g.mission && !g.side && g.wanted.stars === 0 && !p.dead) g.saveGame(false); }
}
function menuStep(g, dt) {
  const t = g.time; g.menuAngle += dt * 0.04; const x = 3300 + Math.cos(g.menuAngle) * 900, y = 2700 + Math.sin(g.menuAngle * 1.3) * 700;
  const p = g.player; p.x = x; p.y = y; p.dead = false; p.hp = p.max; g.cam.x = x + 200; g.cam.y = y; g.cam.zoom = 0.85; g.env.hour += dt / 20; if (g.env.hour >= 24) g.env.hour -= 24; if (g.env.hour > 5 && g.env.hour < 17) g.env.hour = 17.5; updateEnv(g, 0); g.env.hour = g.env.hour;
  g.hashA.clear(); g.hashV.clear(); for (const a of g.actors) if (a.on && !a.dead) g.hashA.insert(a, a.x, a.y); for (const v of g.vehicles) if (v.on) g.hashV.insert(v, v.x, v.y);
  updateActorsAI(g, dt); for (const v of g.vehicles) { if (!v.on) continue; if (!v.driver) updateVehicleAI(g, v, dt); updateVehicle(g, v, dt); } collideAll(g); g.bullets.update(g, dt); g.parts.update(dt); g.noises.length = 0; updatePopulation(g, dt);
  g.tmpLights = g.tmpLights.filter((l) => (l.life -= dt) > 0); g.markers = []; void t;
}
// Camera lead is derived from the cursor's *screen* offset (not from the aim direction) so it can never feed back into the aim:
// aim point = cam + cursor/S, cam = player + k·cursor/S  →  the aim direction always points at the cursor.
function mouseLead(g, k, max) {
  const p = g.player, S = (g.R && g.R.S) || 1, pad = g.input.pad; let dx, dy;
  if (pad.aimActive || (g.input.touch && !g.input.moveT)) { dx = Math.cos(p.aim) * max * 0.6; dy = Math.sin(p.aim) * max * 0.6; }
  else { dx = (g.input.mx * g.dpr - g.W / 2) / S * k; dy = (g.input.my * g.dpr - g.H / 2) / S * k; }
  const l = Math.hypot(dx, dy); if (l > max) { dx *= max / l; dy *= max / l; } return { x: dx, y: dy };
}
function cameraStep(g, dt) {
  const cam = g.cam, p = g.player, v = p.veh; let tx = p.x, ty = p.y, tz = 1;
  if (g.scene) { tz = 1.15; }
  else if (v) { const sp = Math.hypot(v.vx, v.vy); tx += v.vx * 0.38; ty += v.vy * 0.38; tz = 1 - Math.min(0.34, sp / 560 * 0.34); }
  else if (p.heli) { const c = p.heli, sp = Math.hypot(c.vx, c.vy); tx = c.x + c.vx * 0.42; ty = c.y + c.vy * 0.42 - c.alt * 40; tz = 1 - c.alt * 0.2 - Math.min(0.12, sp / 400 * 0.12); if (c.def.combat && !g.input.pad.on) { const l = mouseLead(g, 0.22, 140); tx += l.x; ty += l.y; } }
  else if (g.aiming) { const sn = p.wid === 'sniper', l = mouseLead(g, sn ? 0.5 : 0.26, sn ? 560 : 150); tx += l.x; ty += l.y; tz = sn ? 0.86 : 0.94; }
  else { tx += Math.cos(p.aim) * 36; ty += Math.sin(p.aim) * 36; }
  if (g.cut && g.cut.cam) { tx = g.cut.cam.x; ty = g.cut.cam.y - 40; tz = 1.1; }
  if (g.deathT > 0) tz = 1.2;
  const k = 1 - Math.exp(-(g.cut ? 2.5 : 7) * dt / Math.max(0.3, g.timeScale)); cam.x += (tx - cam.x) * k; cam.y += (ty - cam.y) * k; cam.zoom += (tz - cam.zoom) * (1 - Math.exp(-(g.aiming ? 7 : 3) * dt));
  if (g.scene) { const I = g.scene, vw = g.viewW || 1200, vh = g.viewH || 800, W = I.w * TS, H = I.h * TS; cam.x = W < vw ? W / 2 : clamp(cam.x, vw / 2, W - vw / 2); cam.y = H < vh ? H / 2 : clamp(cam.y, vh / 2, H - vh / 2); }
  cam.shake = Math.max(0, cam.shake - dt * 30); cam.kx *= Math.exp(-9 * dt); cam.ky *= Math.exp(-9 * dt);
  const sh = g.settings.shake ? cam.shake : 0; cam.shx = (Math.random() - 0.5) * sh + cam.kx; cam.shy = (Math.random() - 0.5) * sh + cam.ky;
}

// ===== interaction =====
function nearestDoor(g, r = 46) {
  if (g.scene) return null; const p = g.player; let best = null, bd = r;
  for (const b of g.world.buildings) { if (!b.interior || !b.door) continue; const d = Math.hypot(p.x - b.door.x, p.y - b.door.y); if (d < bd) { bd = d; best = b; } }
  return best;
}
function nearestObj(g) {
  if (!g.scene) return null; const p = g.player; let best = null, bd = 1e9;
  for (const o of g.scene.objs) { const d = Math.hypot(p.x - o.x, p.y - o.y); if (d < o.r && d < bd) { bd = d; best = o; } } return best;
}
function interact(g) {
  const p = g.player, inp = g.input; if (g.fading) return;
  if (p.heli) { exitHeli(g); return; }
  if (p.veh) {
    const v = p.veh, gus = g.world.pois.gus;
    if (gus && Math.hypot(v.x - gus.x, v.y - gus.y) < 110 && Math.hypot(v.vx, v.vy) < 60) { if (theftDeliver(g, v)) return; g.ui.openGarage(v); return; }
    if (Math.hypot(v.vx, v.vy) < 520) { exitVehicle(g, p, false); }
    return;
  }
  if (g.scene) { const o = nearestObj(g); if (o) useObj(g, o); return; }
  const door = nearestDoor(g), veh = nearestVehicle(g, p.x, p.y, 46), hc = nearestChopper(g, p.x, p.y, 150);
  if (hc && !(door && Math.hypot(p.x - door.door.x, p.y - door.door.y) < 40) && (!veh || Math.hypot(hc.x - p.x, hc.y - p.y) < 56)) { boardHeli(g, hc); return; }
  const dd = door ? Math.hypot(p.x - door.door.x, p.y - door.door.y) : 1e9, dv = veh ? 30 : 1e9;
  if (door && dd < dv + 10) { enterBuilding(g, door); return; }
  if (veh) tryEnterVehicle(g);
  void inp;
}
function enterBuilding(g, b) {
  g.ui.fade(() => {
    const I = buildInterior(b.interior, b); g.scene = I; g.insideId = I.id; const p = g.player; p.x = p.px = I.pts.entry.x; p.y = p.py = I.pts.entry.y; p.a = -Math.PI / 2; p.vx = p.vy = 0; p.cover = null; p.crouch = false;
    g.cam.x = g.cam.px = p.x; g.cam.y = g.cam.py = p.y; g.audio.sfx('door');
    const heist = g.mission && g.mission.def.id === 'm7';
    for (const n of I.npcs) {
      if (n.role === 'guard' && heist) continue;
      const guard = n.role === 'guard' || n.role === 'officer' || n.role === 'sergeant' || n.role === 'soldier', fac = guard ? 'pd' : 'civ', a = spawnActor(g, guard ? 'cop' : 'civ', n.x, n.y, { fac, w: guard ? 'pistol' : 'fists', inside: I.id });
      if (a) { a.st = 'stay'; a.noLoot = true; a.a = Math.PI / 2; a.role = n.role; if (n.role === 'gus') { a.look.shirt = '#8d4a2a'; a.look.hair = '#c8c8c8'; a.look.style = 1; } if (n.role === 'clerk' || n.role === 'teller') a.look.shirt = '#ffffff'; if (n.role === 'nurse') a.look.shirt = '#7fd1c7'; if (n.role === 'soldier') { a.look.shirt = '#4f5a3f'; a.look.pants = '#3d4630'; } if (n.role === 'pilot' || n.role === 'agent') { a.look.shirt = '#1f3a63'; a.look.pants = '#1a1f2b'; } a.fear = 0; }
    }
    if (g.wanted.stars > 0) g.toast('Cops are waiting outside…', '#ff7788');
    g.news && g.news('enter', b.name);
  });
}
export function exitBuilding(g) {
  g.ui.fade(() => {
    const I = g.scene, b = I.building; for (const a of g.actors) if (a.on && a.inside === I.id && !a.mis) a.on = false; for (const a of g.actors) if (a.on && a.inside === I.id && a.mis) { a.inside = null; a.x = b.door.x + rnd(-20, 20); a.y = b.door.y + 30; }
    g.pickups = g.pickups.filter((q) => (q.inside || null) !== I.id); g.scene = null; g.insideId = null; g.arena = null; const p = g.player; p.x = p.px = b.door.x; p.y = p.py = b.door.y + 12; p.vx = p.vy = 0; g.cam.x = g.cam.px = p.x; g.cam.y = g.cam.py = p.y; g.audio.sfx('door');
    if (g.mission && g.mission.def.id === 'm7') g.mission.refs.exited = true;
  });
}
function useObj(g, o) {
  const p = g.player, a = o.act;
  if (a === 'exit') return exitBuilding(g);
  if (a.startsWith('shop:')) return g.ui.openShop(a.slice(5));
  if (a === 'wardrobe') return g.ui.openWardrobe(o.data || 0, false);
  if (a === 'sleep') { if (g.cash < (o.data || 0)) return g.toast('Not enough cash', '#ff7788'); g.cash -= o.data || 0; g.ui.fade(() => { if (g.env.hour > 7) g.env.day++, dailyTick(g); g.env.hour = 7.2; p.hp = p.max; g.wanted.stars && setStars(g, 0); setWeather(g, 'clear'); g.toast('You slept until morning.', '#4fe0ff'); g.saveGame(true); }, 500); return; }
  if (a === 'save') return g.saveGame(true);
  if (a === 'news') return g.ui.openPhone('news');
  if (a === 'cache') { if (g.lastCache === g.env.day) return g.toast('The cache is empty today.', '#aaa'); g.lastCache = g.env.day; for (const k of WEAPON_ORDER) if (g.inv.have[k] && WEAPONS[k].ammo) g.inv.ammo[WEAPONS[k].ammo] = Math.min(AMMO_MAX[WEAPONS[k].ammo], (g.inv.ammo[WEAPONS[k].ammo] | 0) + Math.ceil((WEAPONS[k].pack || 6) / 2)); g.toast('Ammo restocked.', '#7cff4f'); return g.audio.sfx('pickup'); }
  if (a === 'atm') return g.ui.openBank();
  if (a === 'heal') { if (g.cash < o.data) return g.toast('Not enough cash', '#ff7788'); g.cash -= o.data; p.hp = p.max; p.armor = Math.max(p.armor, 25); g.toast('Patched up.', '#7cff4f'); return g.audio.sfx('pickup'); }
  if (a === 'police') return g.ui.openPolice();
  if (a === 'slots') return g.ui.openSlots(o.data);
  if (a === 'coinflip') return g.ui.openCoin(o.data);
  if (a === 'fight') return startArena(g);
  if (a === 'jukebox') return g.nextStation();
  if (a === 'info') return g.ui.info(o.title || 'Info', o.data);
  if (a === 'flight') return g.ui.openFlights();
}
function promptStep(g) {
  const p = g.player; g.promptText = ''; g.prompt = null; if (p.dead || g.cut || g.hotwiring) return;
  const key = g.input.bind.interact[0].replace('Key', '');
  if (p.heli) { const c = p.heli; g.promptText = c.alt > 0.08 ? '[Space] climb · [Shift] descend · land to exit' + (c.def.combat ? ' · LMB minigun · RMB rockets' : '') : `[${key}] Exit helicopter`; return; }
  if (p.veh) { const gus = g.world.pois.gus; if (gus && Math.hypot(p.x - gus.x, p.y - gus.y) < 110 && Math.hypot(p.veh.vx, p.veh.vy) < 60) g.promptText = `[${key}] Garage — customise or sell`; else g.promptText = Math.hypot(p.veh.vx, p.veh.vy) < 200 ? `[${key}] Exit vehicle` : ''; return; }
  if (g.scene) { const o = nearestObj(g); if (o) { g.promptText = `[${key}] ${o.label}`; g.prompt = o; } return; }
  const d = nearestDoor(g), v = nearestVehicle(g, p.x, p.y, 46), hc = nearestChopper(g, p.x, p.y, 150);
  if (hc && !(d && Math.hypot(p.x - d.door.x, p.y - d.door.y) < 40) && (!v || Math.hypot(hc.x - p.x, hc.y - p.y) < 56)) { g.promptText = `[${key}] Board ${hc.def.n}`; g.prompt = hc; return; }
  if (d && (!v || Math.hypot(p.x - d.door.x, p.y - d.door.y) < 36)) { g.promptText = `[${key}] Enter ${d.name || 'building'}`; g.prompt = d.door; }
  else if (v && !p.entering) { g.promptText = `[${key}] ${v.npc ? 'Carjack ' : v.hot || v.owned ? 'Enter ' : 'Hotwire '}${v.def.n}`; g.prompt = v; }
}

// ===== pickups / shards / discovery =====
function pickupStep(g, dt) {
  const p = g.player;
  for (let i = g.pickups.length - 1; i >= 0; i--) {
    const k = g.pickups[i]; if ((k.inside || null) !== g.insideId) continue; k.life -= dt; if (k.life <= 0) { g.pickups.splice(i, 1); continue; }
    if (Math.hypot(k.x - p.x, k.y - p.y) < (k.type === 'mission' ? 32 : 20) && !p.dead) {
      if (k.type === 'cash') { g.cash += k.v; g.stats.cashEarned += k.v; g.audio.sfx('cash'); g.toast('+$' + k.v, '#7cff4f'); }
      else if (k.type === 'ammo') { for (const w of WEAPON_ORDER) { const wd = WEAPONS[w]; if (g.inv.have[w] && wd.ammo && wd.type === 'gun') g.inv.ammo[wd.ammo] = Math.min(AMMO_MAX[wd.ammo], (g.inv.ammo[wd.ammo] | 0) + Math.ceil((wd.pack || 12) / 3)); } g.audio.sfx('pickup'); g.toast('Ammo', '#d9b34a'); }
      else if (k.type === 'armor') { p.armor = Math.min(100, p.armor + k.v); g.audio.sfx('pickup'); }
      else if (k.type === 'mission') { onMissionPickup(g, k); }
      g.pickups.splice(i, 1);
    }
  }
  if (g.scene) return;
  g._sq = g._sq || []; g._sq.length = 0; g.world.propHash.query(p.x, p.y, 40, g._sq);
  for (const s of g._sq) if (s.t === 'shard' && !s.dead && Math.hypot(s.x - p.x, s.y - p.y) < 26) { s.dead = true; g.shardsGot++; g.cash += 100; g.stats.cashEarned += 100; g.audio.sfx('pickup'); g.toast(`Tide Shard ${g.shardsGot}/24  +$100`, '#4fe0ff'); if (g.shardsGot === 8) { g.cash += 1500; g.toast('8 shards: +$1,500', '#ffe14a'); } if (g.shardsGot === 16) { g.giveWeapon('rocket', 4); g.toast('16 shards: Hammer RPG unlocked!', '#ffe14a'); } if (g.shardsGot === 24) { g.cash += 15000; g.toast('All shards: +$15,000', '#ffe14a'); } }
  g.discT = (g.discT || 0) - dt; if (g.discT <= 0) { g.discT = 1; for (const k of MAP_DISC.concat(g.world.discList)) { if (g.disc[k]) continue; const q = g.world.pois[k]; if (q && Math.hypot(q.x - p.x, q.y - p.y) < 380) { g.disc[k] = true; g.cash += 25; g.toast('Discovered: ' + (NAMES[k] || q.name) + '  +$25', '#4fe0ff'); } }
  // restricted military base: trespass for a few seconds and the army opens fire
  { const zk = g.scene ? null : g.world.districtAt(p.x, p.y); if (zk === 'fortbase' && !g.cheats.god) { g.fortT = (g.fortT || 0) + dt; if (!g.fortWarn) { g.fortWarn = true; g.toast('⚠ RESTRICTED MILITARY AREA — turn back now!', '#ff9a3c'); } if (g.fortT > 7 && !g.fortHot) { g.fortHot = true; setStars(g, Math.max(g.wanted.stars, 3)); g.toast('Soldiers are shooting on sight!', '#ff3b5c'); for (let i = 0; i < 4; i++) { const a2 = Math.random() * 6.28, s = spawnActor(g, 'cop', p.x + Math.cos(a2) * 420, p.y + Math.sin(a2) * 420, { fac: 'pd', w: 'rifle' }); if (s) { s.soldier = true; s.look.shirt = '#4f5a3f'; s.look.pants = '#3d4630'; } } } } else { g.fortT = Math.max(0, (g.fortT || 0) - dt * 0.5); if (g.fortT === 0) { g.fortWarn = false; g.fortHot = false; } } } }
}

// ===== death / busted =====
function respawn(g) {
  const p = g.player, kind = g.deathKind; g.timeScale = 1; g.focusT = 0;
  const fee = kind === 'busted' ? Math.max(0, Math.min(g.cash, Math.max(100, Math.round(g.cash * 0.12)))) : Math.min(g.cash, 500);
  g.ui.fade(() => {
    g.cash -= fee; g.deathCard = null; g.busting = false; if (g.scene) { for (const a of g.actors) if (a.on && a.inside === g.scene.id) a.on = false; g.scene = null; g.insideId = null; } g.arena = null;
    if (g.mission) failMission(g, kind === 'busted' ? 'Busted.' : 'Wasted.'); if (g.side) endSideJob(g);
    if (p.veh) { p.veh.driver = null; p.veh = null; }
    if (p.heli) { p.heli.driver = null; p.heli = null; g.chopper = null; }
    const loc = g.world.pois[kind === 'busted' ? 'police' : 'hosp']; p.dead = false; p.hp = p.max; p.armor = 0; p.fire = 0; p.stun = 0; p.vx = p.vy = p.kx = p.ky = 0; p.x = p.px = loc.x; p.y = p.py = loc.y + 20; p.deadT = 0; p.roll = 0;
    if (kind === 'busted') { for (const k in g.inv.ammo) g.inv.ammo[k] = Math.floor(g.inv.ammo[k] * 0.5); }
    setStars(g, 0); g.wanted.heat = 0; for (const a of g.actors) if (a.on && a.fac === 'pd' && a !== p) a.st = 'idle';
    g.cam.x = g.cam.px = p.x; g.cam.y = g.cam.py = p.y; g.toast(`${kind === 'busted' ? 'Released from PMPD' : 'Discharged from Meridian General'} — fee ${'$' + fee}`, '#ffb347');
  }, 600);
}

// ===== tutorial + radio banter =====
const TUT = [
  ['Move with <b>WASD</b>', (g) => g.tutC.move > 150], ['Hold <b>Shift</b> while moving to sprint', (g) => g.tutC.sprint > 1.2], ['Aim with the mouse, <b>left-click</b> to punch / fire', (g) => g.stats.shots >= 1],
  ['Press <b>V</b> to dodge-roll', (g) => g.tutC.roll >= 1], ['Walk to a car and press <b>E</b> — hotwire it with the arrow keys', (g) => g.stats.vehiclesDriven >= 1], ['<b>W/S</b> gas & brake · <b>A/D</b> steer · <b>Space</b> handbrake to drift · <b>H</b> horn · <b>X</b> radio', (g) => g.stats.drift > 0.8 || g.tutC.drive > 14], ['<b>Tab</b> opens your phone · <b>M</b> the map', (g) => g.tutC.phone],
];
function tutorialStep(g, dt) {
  const p = g.player; g.tutText = '';
  if (g.tutDone || g.cut || g.state !== 'play') return;
  g.tutC.move = (g.tutC.move || 0) + (p.veh ? 0 : Math.hypot(p.vx, p.vy) * dt); if (g.input.down('sprint') && Math.hypot(p.vx, p.vy) > 150) g.tutC.sprint = (g.tutC.sprint || 0) + dt;
  if (p.roll > 0) g.tutC.roll = 1; if (p.veh && Math.hypot(p.veh.vx, p.veh.vy) > 100) g.tutC.drive = (g.tutC.drive || 0) + dt;
  if (g.tutI >= TUT.length) { g.tutDone = true; return; }
  const t = TUT[g.tutI]; g.tutText = t[0]; if (t[1](g)) { g.tutI++; g.audio.sfx('pickup'); g.tutC.t0 = g.time; }
}
function radioStep(g, dt) {
  const p = g.player; if (!p.veh || g.audio.station < 0 || !g.audio.radioOn) return;
  g.banterT = (g.banterT === undefined ? 12 : g.banterT) - dt; if (g.banterT <= 0) { g.banterT = 40 + Math.random() * 30; const b = pickBanter(g); if (b) { g.banter = { ...b, t: 7 }; if (b.jingle) g.audio.jingle(); } }
}

// ===== audio per frame =====
function audioStep(g, dt) {
  const a = g.audio; if (!a.ok) return;
  a.update(dt, g); chopperAudio(g, a); const p = g.player, v = p.veh;
  if (v && g.state !== 'menu') a.engine(0, v.rpm, Math.abs(v.thr), undefined, undefined, v.def.shape === 'moto' ? 0.8 : 1); else a.engine(0, -1, 0);
  let near = null, nd = 800; for (const o of g.vehicles) { if (!o.on || o === v || o.wreck || (!o.npc && o.ai === 'none')) continue; const d = Math.hypot(o.x - g.cam.x, o.y - g.cam.y); if (d < nd) { nd = d; near = o; } }
  if (near && !g.scene) a.engine(1, near.rpm, Math.abs(near.thr) * 0.8, near.x, near.y, 0.9); else a.engine(1, -1, 0);
  let sk = 0, sx, sy; if (v && v.skid > 0.1) sk = v.skid; else if (near && near.skid > 0.1) { sk = near.skid; sx = near.x; sy = near.y; } a.setTire(sk, sx, sy);
  let sn = null, sd = 1800; for (const o of g.vehicles) if (o.on && o.siren && o.def.siren && !o.wreck) { const d = Math.hypot(o.x - g.cam.x, o.y - g.cam.y); if (d < sd) { sd = d; sn = o; } }
  if (sn && !g.scene && g.state !== 'menu') { const cl = (sd - (g._sd || sd)) / Math.max(dt, 0.001); g._sd = sd; a.setSiren(true, sn.x, sn.y, -cl, g.time); } else { a.setSiren(false); g._sd = undefined; }
  const e = g.env, dist = g.world.districtAt(g.cam.x, g.cam.y), crowd = g.scene ? 0.4 : ({ downtown: 1, beach: 0.7, suburbs: 0.35, docks: 0.2, solcosta: 0.9, aurelia: 1, saguaro: 0.3, airport: 0.7, bayou: 0.3, valley: 0.15 }[dist] || 0.05) * (e.dark > 0.5 ? 0.6 : 1);
  a.setAmbience(g.scene ? 0 : e.rain, g.scene ? 0 : e.wind, crowd, e.dark > 0.5);
}
export { exitBuilding as exitBuildingFn, startSide, MISSIONS, SH, lerp, pick, chance, damageActor, finishReload, WS, P };
