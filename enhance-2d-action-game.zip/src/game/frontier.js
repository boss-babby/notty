// ===== frontier.js — procedural "Frontier" ring (step 1 of the infinite-world plan in ANALYSIS.md §3.4) =====
// The nine authored regions stay exactly where they were ("anchors"). East and south of them, across an ocean channel, the world now
// continues with land that is a PURE FUNCTION of (seed, tile): macro fields (elevation, moisture) → biome lookup → settlements by grammar.
//   elevation  < .30 lake / bay      .30-.34 beach      .72+ rock massifs      .84+ snowcaps
//   moisture   < .34 desert          < .54 grass/farm   < .72 forest           else marsh (low ground) / forest
//   cities     one candidate per 6×6-block super-cell (hash), radius & density from hash, urbanity falls off with distance:
//              towers (core) → shops (inner ring) → houses / parks (suburbs); landmark hotel + fountain at the centre.
// Roads follow the same 16-tile block grid as the rest of the game, so traffic AI, minimap, bridges and fast travel just work.
import { vnoise, hash2, mulberry32, shade } from './util.js';

const A = ['Ash', 'Bram', 'Cor', 'Dun', 'El', 'Fen', 'Gar', 'Hol', 'Iron', 'Jun', 'Kes', 'Lor', 'Mar', 'Nor', 'Oak', 'Pine', 'Quar', 'Red', 'Sil', 'Tor', 'Ul', 'Vale', 'Wyn', 'Yar', 'Zen', 'Cinder', 'Gull', 'Stone'];
const B = ['ton', 'ford', 'mouth', 'haven', 'field', 'port', 'bury', 'wick', 'dale', 'crest', 'ridge', 'gate', 'stead', 'mere', 'burg', 'view', 'fall', 'wood'];
export const cityName = (rng) => A[Math.floor(rng() * A.length)] + B[Math.floor(rng() * B.length)];
const GLASS = ['#3a5a7a', '#2f6b7a', '#4a5a8a', '#5a6a7a', '#2c4a6a', '#6a7a8a', '#4b6a8a'];
const WARM = ['#c9b79c', '#a7b8c9', '#c9a7a7', '#b5c9a7', '#d9d0b0', '#b98a5a', '#9fd8d0'];
const ROOFS = ['#7a4b3a', '#4a5a6a', '#5a3f3a', '#3f4a3a'];
const NEON = ['#ff4fd8', '#4fe0ff', '#ffe14a', '#7cff4f', '#ff6a3d', '#b36bff'];
const SHOPKINDS = [['shop_burger', ['SUNSET DINER', 'ROUTE 9 DINER', 'GRILL & CHILL']], ['shop_mart', ['GENERAL STORE', 'QUIK MART', 'CORNER MARKET']], ['shop_clothes', ['MAIN ST WEAR', 'THREADS & CO']], ['bar', ['THE LANTERN', 'LAST STOP', 'IRON HORSE']]];

export function genFrontier(W, K) {
  const { T, M, TS, NT, NT0, NB } = K;
  const tiles = W.tiles, meta = W.meta, seed = W.seed | 0, B0 = NT0 >> 4, OUT = NT - 16;
  const idx = (x, y) => (x < 0 || y < 0 || x >= NT || y >= NT ? -1 : y * NT + x);
  const put = (x, y, w, h, t) => { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const q = idx(x + i, y + j); if (q >= 0 && tiles[q] !== T.WATER && tiles[q] !== T.BUILDING) tiles[q] = t; } };
  const fbm = (x, y, s, o = 4) => { let v = 0, a = 1, t = 0, f = 1; for (let i = 0; i < o; i++) { v += vnoise(x * f, y * f, s + i * 13) * a; t += a; a *= 0.5; f *= 2; } return v / t; };
  const contrast = (v) => Math.min(1, Math.max(0, (v - 0.5) * 1.8 + 0.5));
  const front = (x, y) => x >= NT0 || y >= NT0;

  // ---------- macro fields ----------
  const elev = (tx, ty) => {
    let e = contrast(fbm(tx / 64, ty / 64, seed + 11));
    const edge = Math.min(NT - 1 - tx, NT - 1 - ty); if (edge < 26) e -= (26 - edge) / 26 * 0.55;           // outer coast
    const dch = tx >= NT0 && ty < NT0 ? tx - NT0 : ty >= NT0 && tx < NT0 ? ty - NT0 : 99; if (dch < 8) e = Math.max(e, 0.44);   // land at the bridge heads
    return e;
  };
  const moist = (tx, ty) => contrast(fbm(tx / 80 + 40, ty / 80 - 25, seed + 29, 3));
  const terrain = (tx, ty) => {
    const e = elev(tx, ty); if (tx >= OUT || ty >= OUT) return T.WATER;
    if (e < 0.3) return T.WATER; if (e < 0.34) return T.SAND; if (e > 0.84) return T.SNOW; if (e > 0.72) return T.GRAVEL;
    const m = moist(tx, ty);
    if (m < 0.34) return T.DESERT;
    if (m < 0.54) return vnoise(tx / 28, ty / 28, seed + 7) > 0.56 ? T.FARM : T.GRASS;
    if (m < 0.72) return T.FOREST;
    return e < 0.5 ? T.MARSH : T.FOREST;
  };

  // ---------- settlements (one candidate per 6×6-block super-cell) ----------
  const cities = [], CS = 6, nrng = mulberry32(seed + 777);
  for (let cy = 0; cy < NB / CS; cy++) for (let cx = 0; cx < NB / CS; cx++) {
    if (cx < B0 / CS && cy < B0 / CS) continue;
    if (hash2(cx, cy, seed + 1) > 0.88) continue;
    const bx = cx * CS + 1 + Math.floor(hash2(cx, cy, seed + 2) * 4), by = cy * CS + 1 + Math.floor(hash2(cx, cy, seed + 3) * 4);
    if (!front(bx * 16, by * 16) || bx > NB - 4 || by > NB - 4) continue;
    const e = elev(bx * 16 + 10, by * 16 + 10); if (e < 0.37 || e > 0.7) continue;
    cities.push({ bx, by, r: 1.3 + hash2(cx, cy, seed + 4) * 1.5, name: cityName(nrng), key: 'fr' + cities.length });
  }
  const cityAt = (bx, by) => { let best = null, bu = 0; for (const c of cities) { const d = Math.hypot(bx - c.bx, by - c.by); if (d <= c.r) { const u = 1 - d / c.r; if (u > bu) { bu = u; best = c; } } } return best ? { c: best, u: bu, center: bx === best.bx && by === best.by } : null; };

  // ---------- terrain + roads, block by block ----------
  const bridgeRows = [], bridgeCols = [];
  for (let by = 0; by < B0; by++) if (by % 3 === 1 && tiles[idx(NT0 - 18, by * 16 + 1)] === T.ROAD) bridgeRows.push(by);
  for (let bx = 0; bx < B0; bx++) if (bx % 3 === 1 && tiles[idx(bx * 16 + 1, NT0 - 18)] === T.ROAD) bridgeCols.push(bx);
  const cityOf = new Map();
  for (let by = 0; by < NB; by++) for (let bx = 0; bx < NB; bx++) {
    if (!front(bx * 16, by * 16)) continue;
    const ct = cityAt(bx, by); if (ct) cityOf.set(bx * NB + by, ct);
    const vR = !!ct || bx % 4 === 0, hR = !!ct || by % 4 === 0;
    for (let ly = 0; ly < 16; ly++) for (let lx = 0; lx < 16; lx++) {
      const tx = bx * 16 + lx, ty = by * 16 + ly, q = ty * NT + tx; if (!front(tx, ty)) continue;
      let t = terrain(tx, ty), m = 0; const wet = t === T.WATER, outer = tx >= OUT || ty >= OUT;
      const inV = vR && lx < 4 && !outer, inH = hR && ly < 4 && !outer;
      if (inV || inH) { t = wet ? T.BRIDGE : T.ROAD; if (inV) m |= M.V; if (inH) { m |= M.H; if (by % 12 === 0) m |= M.HWY; } }
      else if (ct && !outer && !wet && (lx === 4 || lx === 15 || ly === 4 || ly === 15)) t = T.SIDEWALK;
      else if ((tx >= NT0 && tx < NT0 + 4 && ty < NT0) || (ty >= NT0 && ty < NT0 + 4 && tx < NT0)) { if (t !== T.WATER) t = T.SAND; }
      tiles[q] = t; meta[q] = m;
    }
  }
  // bridges across the ocean channel (x 560..575 / y 560..575) wherever an authored road reaches the shore
  for (const by of bridgeRows) for (let ty = by * 16; ty < by * 16 + 4; ty++) for (let tx = NT0 - 16; tx < NT0; tx++) { const q = idx(tx, ty); tiles[q] = T.BRIDGE; meta[q] = M.H; }
  for (const bx of bridgeCols) for (let tx = bx * 16; tx < bx * 16 + 4; tx++) for (let ty = NT0 - 16; ty < NT0; ty++) { const q = idx(tx, ty); tiles[q] = T.BRIDGE; meta[q] = M.V; }
  W.poi('frontier_e', (NT0 - 8) * TS, ((bridgeRows[0] || 1) * 16 + 2) * TS, 'Frontier Bridge'); W.poi('frontier_s', ((bridgeCols[0] || 1) * 16 + 2) * TS, (NT0 - 8) * TS, 'Frontier Causeway');

  // ---------- nature: mountains, trees, cacti, rocks, hay ----------
  const walk = (q) => { const t = tiles[q]; return t !== T.WATER && t !== T.ROAD && t !== T.BRIDGE && t !== T.BUILDING && t !== T.SIDEWALK; };
  for (let by = 0; by < NB; by++) for (let bx = 0; bx < NB; bx++) {
    if (!front(bx * 16, by * 16) || cityOf.has(bx * NB + by)) continue;
    for (let ly = 4; ly < 16; ly += 2) for (let lx = 4; lx < 16; lx += 2) {
      const tx = bx * 16 + lx, ty = by * 16 + ly, q = idx(tx, ty); if (q < 0 || tx >= OUT - 2 || ty >= OUT - 2 || !front(tx, ty)) continue;
      const t = tiles[q], h = hash2(tx, ty, seed + 31), px = tx * TS + 4 + hash2(tx, ty, seed + 5) * 56, py = ty * TS + 4 + hash2(tx, ty, seed + 9) * 56;
      if (t === T.GRAVEL || t === T.SNOW) {
        if (h < 0.34 && ly < 13 && lx < 13) { let ok = true; for (let j = 0; j < 3 && ok; j++) for (let i = 0; i < 3; i++) { const qq = idx(tx + i, ty + j); const tt = qq < 0 ? T.WATER : tiles[qq]; if (tt !== T.GRAVEL && tt !== T.SNOW) { ok = false; break; } }
          if (ok) { const e = elev(tx, ty), hg = Math.round(38 + (e - 0.7) * 520 * (0.7 + hash2(tx, ty, seed + 3) * 0.6)); const c = ['#6b6358', '#756c60', '#5f5850', '#7a7065'][Math.floor(h * 12) % 4]; W.addBuilding(tx, ty, 3, 3, { kind: 'mountain', hgt: hg, color: c, roof: e > 0.82 ? '#e9eff3' : shade(c, 0.18), windows: false }); } }
        else if (h > 0.9) W.addProp('rock', px, py);
      } else if (!walk(q) || W.nearSolid(tx, ty)) continue;
      else if (t === T.FOREST) { if (h < 0.5) W.addProp(hash2(tx, ty, seed + 8) < 0.7 ? 'pine' : 'tree', px, py); }
      else if (t === T.GRASS) { if (h < 0.06) W.addProp('tree', px, py); else if (h > 0.985) W.addProp('rock', px, py); }
      else if (t === T.DESERT) { if (h < 0.1) W.addProp('cactus', px, py); else if (h > 0.96) W.addProp('rock', px, py); }
      else if (t === T.FARM) { if (h < 0.05) W.addProp('hay', px, py); }
      else if (t === T.MARSH) { if (h < 0.12) W.addProp('stump', px, py); }
      else if (t === T.SAND) { if (h < 0.05) W.addProp('palm', px, py); }
    }
  }

  // ---------- cities by grammar ----------
  W.discList = W.discList || [];
  const can = (x, y, w, h) => { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) if (!W.free(x + i, y + j)) return false; return true; };
  const B_ = (x, y, w, h, o) => (can(x, y, w, h) ? W.addBuilding(x, y, w, h, o) : null);
  for (const c of cities) {
    const rng = mulberry32(seed * 17 + c.bx * 131 + c.by * 7);
    const pick = (a) => a[Math.floor(rng() * a.length)];
    const zr = Math.ceil(c.r) + 1; W.zones.push({ key: 'frontcity', x0: (c.bx - zr + 0.2) * 16 * TS, y0: (c.by - zr + 0.2) * 16 * TS, x1: (c.bx + zr + 0.8) * 16 * TS, y1: (c.by + zr + 0.8) * 16 * TS });
    for (let by = Math.floor(c.by - c.r); by <= Math.ceil(c.by + c.r); by++) for (let bx = Math.floor(c.bx - c.r); bx <= Math.ceil(c.bx + c.r); bx++) {
      const ct = cityOf.get(bx * NB + by); if (!ct || ct.c !== c) continue;
      const u = ct.u, x0 = bx * 16 + 5, y0 = by * 16 + 5, r2 = mulberry32(seed * 3 + bx * 977 + by * 131), p2 = (a) => a[Math.floor(r2() * a.length)];
      // street furniture
      const a = bx * 16 + 4, b = bx * 16 + 15, cc = by * 16 + 4, d = by * 16 + 15;
      const L = (tx, ty) => { const q = idx(tx, ty); if (q >= 0 && tiles[q] === T.SIDEWALK) W.propAtTile('lamp', tx, ty); };
      L(a, cc); L(b, cc); L(a, d); L(b, d); L(a + 5, cc); L(a + 5, d); L(a, cc + 5); L(b, cc + 5);
      for (let i = 0; i < 4; i++) { W.xw(bx * 16 + i, by * 16 + 4, M.V); W.xw(bx * 16 + i, by * 16 - 1, M.V); W.xw(bx * 16 + 4, by * 16 + i, M.H); W.xw(bx * 16 - 1, by * 16 + i, M.H); }
      if (ct.center) {
        put(x0, y0, 10, 10, T.PLAZA);
        const hgt = 55 + Math.round(c.r * 22 + r2() * 20), tw = B_(x0 + 2, y0 + 1, 6, 5, { kind: 'tower', hgt, color: p2(GLASS), roof: '#cfd8e0', interior: 'hotel', name: c.name.toUpperCase() + ' GRAND', neon: p2(NEON) });
        W.addProp('fountain', (x0 + 5) * TS, (y0 + 7.6) * TS); W.scatter('tree', 3, x0, y0 + 6, 10, 4, r2);
        if (tw && tw.door) { W.poi(c.key + '_hotel', tw.door.x, tw.door.y, c.name + ' Grand'); W.discList.push(c.key + '_hotel'); }
        W.cities.push({ key: c.key, name: c.name, x: (x0 + 5) * TS, y: (y0 + 8.9) * TS }); W.poi('c_' + c.key, (x0 + 5) * TS, (y0 + 8.9) * TS, c.name); W.discList.push('c_' + c.key);
        continue;
      }
      const slots = [[x0, y0], [x0 + 6, y0], [x0, y0 + 5], [x0 + 6, y0 + 5]];
      if (u > 0.55) {
        put(x0, y0, 10, 10, T.PLAZA);
        for (const [sx, sy] of slots) if (r2() < 0.9) B_(sx, sy, 4, 4, { kind: 'tower', hgt: Math.round(36 + u * 70 + r2() * 40), color: p2(GLASS), roof: '#aeb8c2', neon: r2() < 0.4 ? p2(NEON) : null });
      } else if (u > 0.3) {
        put(x0, y0, 10, 10, T.PLAZA);
        for (const [sx, sy] of slots) { if (r2() < 0.12) continue; const [ik, names] = p2(SHOPKINDS); B_(sx, sy, 4, 4, { kind: 'shop', hgt: 22, color: p2(WARM), interior: ik, name: p2(names), neon: p2(NEON) }); }
      } else if (r2() < 0.22) {
        put(x0, y0, 10, 10, T.GRASS); W.addProp('fountain', (x0 + 5) * TS, (y0 + 5) * TS); W.scatter('tree', 12, x0, y0, 10, 10, r2); W.scatter('bench', 4, x0, y0, 10, 10, r2);
      } else {
        put(x0, y0, 10, 10, T.GRASS);
        for (const [sx, sy] of slots) if (r2() < 0.85) B_(sx, sy, 4, 3, { kind: 'house', hgt: 12 + Math.floor(r2() * 7), color: p2(WARM), roof: p2(ROOFS), door: true, interior: 'house' });
        W.scatter('tree', 3, x0, y0, 10, 10, r2);
      }
    }
  }
  W.frontierCities = cities;
  for (let i = 0; i < NT * NT; i++) if (tiles[i] === T.WATER) meta[i] = 0;
}
