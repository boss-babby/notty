// ===== render.js — camera, world drawing, dynamic lighting, weather and post-processing =====
import { TS, T, NT, NB } from './world.js';
import { renderChunk, wetLayer, buildingSprite, propSprite, drawActor, makeCanvas } from './gfx.js';
import { drawVehicle } from './actors.js';
import { clamp, lerp, hash2 } from './util.js';
import { WEAPONS } from './data.js';

export const QUAL = {
  low: { chunk: 0.5, light: 0.25, bloom: false, rain: 160, parts: 500, shadows: false, dpr: 1, maxChunks: 16 },
  medium: { chunk: 0.75, light: 0.33, bloom: true, rain: 380, parts: 900, shadows: true, dpr: 1.25, maxChunks: 22 },
  high: { chunk: 1, light: 0.5, bloom: true, rain: 700, parts: 1400, shadows: true, dpr: 2, maxChunks: 30 },
};
const ROTP = new Set(['airliner', 'jet', 'heli', 'tank', 'truck', 'boat', 'cattle', 'tent']);
const lightCache = new Map();
function lightSpr(col) {
  let s = lightCache.get(col); if (s) return s;
  s = makeCanvas(128, 128); const c = s.getContext('2d'), g = c.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, col); g.addColorStop(0.35, col.length === 7 ? col + '88' : col); g.addColorStop(1, col.length === 7 ? col + '00' : 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, 0, 128, 128);
  lightCache.set(col, s); return s;
}
const coneCache = new Map();
function coneSpr(col, cone) {
  const k = col + cone; let s = coneCache.get(k); if (s) return s;
  s = makeCanvas(256, 256); const c = s.getContext('2d'); c.translate(0, 128);
  const g = c.createRadialGradient(0, 0, 0, 0, 0, 256); g.addColorStop(0, col); g.addColorStop(0.5, col + '77'); g.addColorStop(1, col + '00');
  c.fillStyle = g; c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, 256, -cone / 2, cone / 2); c.closePath(); c.fill();
  coneCache.set(k, s); return s;
}

export function initRenderer(g) {
  const R = (g.R = { S: 1, rain: [], lastW: 0 });
  const mk = () => document.createElement('canvas');
  R.lm = mk(); R.lc = R.lm.getContext('2d'); R.bl = mk(); R.bc = R.bl.getContext('2d'); R.ab = mk(); R.ab2 = mk(); R.vig = mk(); R.scan = mk(); R.fogT = makeFog();
  resizeRenderer(g);
}
function makeFog() {
  const c = makeCanvas(256, 256), x = c.getContext('2d');
  for (let i = 0; i < 40; i++) { const px = Math.random() * 256, py = Math.random() * 256, r = 30 + Math.random() * 60; for (const ox of [-256, 0, 256]) for (const oy of [-256, 0, 256]) { const gr = x.createRadialGradient(px + ox, py + oy, 0, px + ox, py + oy, r); gr.addColorStop(0, 'rgba(210,220,230,.28)'); gr.addColorStop(1, 'rgba(210,220,230,0)'); x.fillStyle = gr; x.fillRect(px + ox - r, py + oy - r, r * 2, r * 2); } }
  return c;
}
export function resizeRenderer(g) {
  const q = QUAL[g.settings.quality], R = g.R, dpr = Math.min(window.devicePixelRatio || 1, q.dpr);
  const W = Math.max(320, Math.floor(window.innerWidth * dpr)), H = Math.max(240, Math.floor(window.innerHeight * dpr));
  g.canvas.width = W; g.canvas.height = H; g.W = W; g.H = H; g.dpr = dpr; R.ls = q.light;
  R.lm.width = Math.ceil(W * q.light); R.lm.height = Math.ceil(H * q.light); R.bl.width = Math.ceil(W / 5); R.bl.height = Math.ceil(H / 5);
  R.ab.width = W; R.ab.height = H; R.ab2.width = W; R.ab2.height = H;
  R.vig.width = W; R.vig.height = H; const v = R.vig.getContext('2d'), gr = v.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.75);
  gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.55)'); v.fillStyle = gr; v.fillRect(0, 0, W, H);
  R.scan.width = W; R.scan.height = H; const sc = R.scan.getContext('2d'); sc.fillStyle = 'rgba(0,0,0,.2)'; for (let y = 0; y < H; y += Math.max(2, Math.round(3 * dpr))) sc.fillRect(0, y, W, Math.max(1, Math.round(dpr)));
  g.world.chunks.clear(); R.rain.length = 0;
  g.parts.qmul = q.parts < 600 ? 0.5 : q.parts < 1000 ? 0.8 : 1;
}

// ---------- chunk streaming ----------
function ensureChunks(g, x0, y0, x1, y1, budget) {
  const w = g.world, q = QUAL[g.settings.quality], cx0 = clamp(Math.floor(x0 / 512), 0, NB - 1), cx1 = clamp(Math.floor(x1 / 512), 0, NB - 1), cy0 = clamp(Math.floor(y0 / 512), 0, NB - 1), cy1 = clamp(Math.floor(y1 / 512), 0, NB - 1);
  const need = [];
  for (let cy = cy0; cy <= cy1; cy++) for (let cx = cx0; cx <= cx1; cx++) { const k = cx * 64 + cy, ch = w.chunks.get(k); if (ch) ch.last = g.frame; else need.push([cx, cy, Math.hypot(cx * 512 + 256 - g.cam.x, cy * 512 + 256 - g.cam.y)]); }
  need.sort((a, b) => a[2] - b[2]);
  for (let i = 0; i < need.length && i < budget; i++) { const [cx, cy] = need[i]; const ch = renderChunk(w, cx, cy, q.chunk); ch.last = g.frame; w.chunks.set(cx * 64 + cy, ch); }
  if (w.chunks.size > q.maxChunks) { let old = null; for (const ch of w.chunks.values()) if (!old || ch.last < old.last) old = ch; if (old && g.frame - old.last > 30) w.chunks.delete(old.cx * 64 + old.cy); }
}
export function preloadChunks(g, n = 9) { ensureChunks(g, g.cam.x - 600, g.cam.y - 400, g.cam.x + 600, g.cam.y + 400, n); }

// ---------- main frame ----------
export function renderFrame(g, alpha) {
  const c = g.ctx, R = g.R, W = g.W, H = g.H, cam = g.cam;
  const cx = lerp(cam.px, cam.x, alpha) + cam.shx, cy = lerp(cam.py, cam.y, alpha) + cam.shy;
  const S = (R.S = cam.zoom * H / 880), vw = W / S, vh = H / S; g.viewW = vw; g.viewH = vh; R.cx = cx; R.cy = cy;
  const x0 = cx - vw / 2, y0 = cy - vh / 2, x1 = cx + vw / 2, y1 = cy + vh / 2; R.x0 = x0; R.y0 = y0; R.x1 = x1; R.y1 = y1;
  c.setTransform(1, 0, 0, 1, 0, 0); c.fillStyle = '#05080f'; c.fillRect(0, 0, W, H);
  c.setTransform(S, 0, 0, S, W / 2 - cx * S, H / 2 - cy * S);
  if (g.scene) renderInterior(g, c, alpha, x0, y0, x1, y1);
  else renderOutdoor(g, c, alpha, x0, y0, x1, y1);
  c.setTransform(1, 0, 0, 1, 0, 0);
  post(g, c);
}

function renderOutdoor(g, c, alpha, x0, y0, x1, y1) {
  const w = g.world, R = g.R, env = g.env, q = QUAL[g.settings.quality], t = g.time;
  ensureChunks(g, x0 - 100, y0 - 100, x1 + 100, y1 + 100, g.frame < 3 ? 12 : 2);
  // ground
  for (const ch of w.chunks.values()) {
    const px = ch.cx * 512, py = ch.cy * 512; if (px > x1 || py > y1 || px + 512 < x0 || py + 512 < y0) continue;
    c.drawImage(ch.cv, px, py, 512, 512);
    if (env.wet > 0.05) { c.globalAlpha = env.wet * 0.5; c.drawImage(wetLayer(w, ch), px, py, 512, 512); c.globalAlpha = 1; }
  }
  // water shimmer, traffic lights, ramps, spikes, fires
  const tx0 = Math.max(0, Math.floor(x0 / TS)), ty0 = Math.max(0, Math.floor(y0 / TS)), tx1 = Math.min(NT - 1, Math.floor(x1 / TS)), ty1 = Math.min(NT - 1, Math.floor(y1 / TS));
  c.fillStyle = 'rgba(200,235,255,.28)';
  for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) if (w.tiles[ty * NT + tx] === T.WATER) { const h = hash2(tx, ty, 3), o = Math.sin(t * 1.3 + h * 20) * 6; c.fillRect(tx * TS + 6 + o, ty * TS + h * 24, 9, 1.5); }
  // decals handled in chunk canvases; draw shards/ramps/spikes
  _q.length = 0; const midx = (x0 + x1) / 2, midy = (y0 + y1) / 2; w.propHash.query(midx, midy, Math.hypot(x1 - x0, y1 - y0) / 2 + 40, _q);
  const props = _q.slice();
  for (const p of props) {
    if (p.dead || p.x < x0 - 40 || p.x > x1 + 40 || p.y < y0 - 40 || p.y > y1 + 40) continue;
    if (p.t === 'ramp') { c.save(); c.translate(p.x, p.y); c.rotate(p.a); c.fillStyle = '#d4a017'; c.beginPath(); c.moveTo(-30, -30); c.lineTo(30, -22); c.lineTo(30, 22); c.lineTo(-30, 30); c.closePath(); c.fill(); c.fillStyle = '#222'; for (let i = -24; i < 24; i += 12) c.fillRect(i, -26, 6, 52); c.restore(); }
    else if (p.t === 'shard') { c.save(); c.translate(p.x, p.y); c.rotate(t * 2); c.fillStyle = '#4fe0ff'; c.shadowColor = '#4fe0ff'; c.shadowBlur = 12; c.beginPath(); c.moveTo(0, -9); c.lineTo(6, 0); c.lineTo(0, 9); c.lineTo(-6, 0); c.closePath(); c.fill(); c.restore(); }
    else if (p.t === 'umbrella' || p.t === 'fountain') c.drawImage(propSprite(p.t, p.v), p.x - propSprite(p.t, p.v).width / 2, p.y - propSprite(p.t, p.v).height / 2);
  }
  for (const s of g.spikes) { c.save(); c.translate(s.x, s.y); c.rotate(s.a); c.fillStyle = '#222'; c.fillRect(-s.len / 2, -3, s.len, 6); c.fillStyle = '#bbb'; for (let i = -s.len / 2 + 4; i < s.len / 2; i += 8) c.fillRect(i, -5, 2, 10); c.restore(); }
  for (const f of g.fires) { c.fillStyle = 'rgba(20,10,5,.45)'; c.beginPath(); c.ellipse(f.x, f.y, f.r, f.r * 0.8, 0, 0, 6.3); c.fill(); }
  trafficLights(g, c, x0, y0, x1, y1);
  // pickups
  for (const p of g.pickups) {
    if (p.inside || p.x < x0 - 20 || p.x > x1 + 20 || p.y < y0 - 20 || p.y > y1 + 20) continue;
    const bob = Math.sin(t * 4 + p.x) * 2;
    if (p.type === 'mission') { c.fillStyle = '#ffe14a'; c.shadowColor = '#ffe14a'; c.shadowBlur = 18; c.fillRect(p.x - 7, p.y - 7 + bob, 14, 14); c.shadowBlur = 0; c.strokeStyle = '#fff'; c.lineWidth = 2; c.strokeRect(p.x - 7, p.y - 7 + bob, 14, 14); continue; }
    c.fillStyle = p.type === 'cash' ? '#3ddc6a' : p.type === 'ammo' ? '#d9b34a' : p.type === 'armor' ? '#4aa8ff' : '#ff4f6a';
    c.beginPath(); c.arc(p.x, p.y + bob, 7, 0, 6.3); c.fill(); c.fillStyle = '#0b0b0b'; c.font = 'bold 9px sans-serif'; c.textAlign = 'center'; c.fillText(p.type === 'cash' ? '$' : p.type === 'ammo' ? 'A' : p.type === 'armor' ? 'V' : '+', p.x, p.y + bob + 3);
  }
  // building shadows
  const hr = env.hour, sun = clamp(1 - env.dark * 1.2, 0, 1);
  const bl = [];
  for (const b of w.buildings) { const bx = b.x * TS, by = b.y * TS, bw = b.w * TS, bh = b.h * TS; if (bx > x1 + 80 || by - b.hgt > y1 || bx + bw < x0 - 100 || by + bh < y0) continue; bl.push(b); }
  if (q.shadows && sun > 0.05) {
    const sxk = (hr - 12) / 6 * 0.8, a = 0.3 * sun; c.fillStyle = `rgba(0,0,0,${a})`;
    for (const b of bl) {
      const bx = b.x * TS, by = b.y * TS, bw = b.w * TS, bh = b.h * TS, sx = sxk * b.hgt, sy = b.hgt * 0.3;
      c.beginPath(); quadPath(c, [[bx, by], [bx + bw, by], [bx + bw, by + bh], [bx, by + bh]]); quadPath(c, [[bx + sx, by + sy], [bx + bw + sx, by + sy], [bx + bw + sx, by + bh + sy], [bx + sx, by + bh + sy]]);
      const E = [[[bx, by], [bx + bw, by]], [[bx + bw, by], [bx + bw, by + bh]], [[bx + bw, by + bh], [bx, by + bh]], [[bx, by + bh], [bx, by]]];
      for (const [p0, p1] of E) quadPath(c, [p0, p1, [p1[0] + sx, p1[1] + sy], [p0[0] + sx, p0[1] + sy]]);
      c.fill();
    }
  }
  // lamps' poles & ground props
  for (const p of props) {
    if (p.dead || p.t === 'ramp' || p.t === 'shard' || p.t === 'umbrella' || p.t === 'fountain' || p.t === 'tree' || p.t === 'palm' || p.t === 'pine' || p.t === 'spike') continue;
    if (p.x < x0 - 30 || p.x > x1 + 30 || p.y < y0 - 30 || p.y > y1 + 30) continue;
    if (p.t === 'blocker') continue;
    const s = propSprite(p.t, p.v); if (ROTP.has(p.t) && p.a) { c.save(); c.translate(p.x, p.y); c.rotate(p.a); c.drawImage(s, -s.width / 2, -s.height / 2); c.restore(); } else c.drawImage(s, p.x - s.width / 2, p.y - s.height / 2);
  }
  for (const p of props) if ((p.t === 'tree' || p.t === 'palm' || p.t === 'pine') && !(p.x < x0 - 40 || p.x > x1 + 40 || p.y < y0 - 40 || p.y > y1 + 40)) { c.fillStyle = '#4a3320'; c.beginPath(); c.arc(p.x, p.y, 4, 0, 6.3); c.fill(); }
  // vehicles + actors
  const vs = [], as = [];
  for (const v of g.vehicles) if (v.on && v.x > x0 - 120 && v.x < x1 + 120 && v.y > y0 - 120 && v.y < y1 + 120) vs.push(v);
  vs.sort((a, b) => a.z - b.z);
  for (const v of vs) { const a = v.pa + angD(v.pa, v.a) * alpha; drawVehicle(c, v, lerp(v.px, v.x, alpha), lerp(v.py, v.y, alpha), a, t, env.dark); }
  for (const a of g.actors) if (a.on && !a.veh && a.inside === null && !(g.state === 'menu' && a === g.player) && a.x > x0 - 40 && a.x < x1 + 40 && a.y > y0 - 40 && a.y < y1 + 40) as.push(a);
  for (const a of as) if (a.dead) actorDraw(g, c, a, alpha);
  for (const a of as) if (!a.dead) actorDraw(g, c, a, alpha);
  g.bullets.draw(c, alpha); g.parts.draw(c, x0, y0, x1, y1);
  // stealth cones & alert meters
  for (const a of as) if (!a.dead && a.alert > 0.04 && a.st !== 'combat' && a.fac !== 'civ') alertMeter(c, a);
  if (g.mission && g.mission.step && g.mission.step.t === 'stealth') for (const a of as) if (!a.dead && a.role !== 'x' && a.type === 'guard' && a.st !== 'combat') cone(c, a);
  // flying heli shadow
  if (g.heli.on) { c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.ellipse(g.heli.x + 30, g.heli.y + 50, 28, 12, g.heli.a, 0, 6.3); c.fill(); }
  // overhead: buildings, canopies
  const night = clamp((env.dark - 0.2) * 1.4, 0, 1);
  for (const b of bl.sort((a, b2) => a.y + a.h - (b2.y + b2.h))) { const s = buildingSprite(b); c.drawImage(s.base, b.x * TS, b.y * TS - b.hgt); }
  for (const p of props) if ((p.t === 'tree' || p.t === 'palm' || p.t === 'pine') && !(p.x < x0 - 50 || p.x > x1 + 50 || p.y < y0 - 50 || p.y > y1 + 50)) { const s = propSprite(p.t, p.v); c.globalAlpha = p.t === 'tree' && Math.hypot(g.player.x - p.x, g.player.y - p.y) < 26 ? 0.55 : 1; c.drawImage(s, p.x - 32, p.y - 40); c.globalAlpha = 1; }
  // silhouette of player hidden by roofs
  const pl = g.player;
  if (!pl.veh) for (const b of bl) { const bx = b.x * TS, by = b.y * TS - b.hgt; if (pl.x > bx && pl.x < bx + b.w * TS && pl.y > by && pl.y < b.y * TS + b.h * TS - b.hgt + 4 && !(pl.y > b.y * TS + b.h * TS)) { c.globalAlpha = 0.5; c.fillStyle = '#ffe14a'; c.beginPath(); c.arc(pl.x, pl.y, 7, 0, 6.3); c.fill(); c.globalAlpha = 1; } }
  if (g.heli.on) heliDraw(g, c);
  g.parts.drawGlow(c, x0, y0, x1, y1);
  worldHud(g, c, x0, y0, x1, y1);
  // weather & light (screen space)
  c.setTransform(1, 0, 0, 1, 0, 0);
  weather(g, c);
  lighting(g, c, props, bl);
  // window / neon glow layer (after darkness)
  if (night > 0.02) {
    const S = R.S; c.setTransform(S, 0, 0, S, g.W / 2 - R.cx * S, g.H / 2 - R.cy * S); c.globalAlpha = night * 0.95;
    for (const b of bl) { const s = buildingSprite(b); c.drawImage(s.glow, b.x * TS, b.y * TS - b.hgt); }
    c.globalAlpha = 1; c.setTransform(1, 0, 0, 1, 0, 0);
  }
}
const _q = [];
const angD = (a, b) => { let d = (b - a) % 6.283185; if (d > 3.14159) d -= 6.283185; else if (d < -3.14159) d += 6.283185; return d; };
function quadPath(c, pts) {
  let area = 0; for (let i = 0; i < pts.length; i++) { const j = (i + 1) % pts.length; area += pts[i][0] * pts[j][1] - pts[j][0] * pts[i][1]; }
  if (area < 0) pts = pts.slice().reverse();
  c.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]); c.closePath();
}
function actorDraw(g, c, a, alpha) {
  const x = lerp(a.px, a.x, alpha), y = lerp(a.py, a.y, alpha), ang = a.pa + angD(a.pa, a.a) * alpha;
  if (a.entering > 0 && a === g.player && false) return;
  drawActor(c, a, x, y, ang, g.time);
  if (a.fire > 0) { c.fillStyle = 'rgba(255,140,40,.5)'; c.beginPath(); c.arc(x, y, 8, 0, 6.3); c.fill(); }
  if (a.ally) { c.fillStyle = '#7cff4f'; c.beginPath(); c.moveTo(x, y - 18); c.lineTo(x + 4, y - 24); c.lineTo(x - 4, y - 24); c.fill(); }
  if (a.phone > 0 || a.st === 'phone' || a.st === 'film') { c.fillStyle = '#111'; c.fillRect(x + Math.cos(ang) * 9 - 2, y + Math.sin(ang) * 9 - 3, 4, 6); c.fillStyle = '#7cf'; c.fillRect(x + Math.cos(ang) * 9 - 1, y + Math.sin(ang) * 9 - 2, 2, 4); }
}
function alertMeter(c, a) {
  const x = a.x, y = a.y - 20, p = clamp(a.alert, 0, 1); c.fillStyle = 'rgba(0,0,0,.6)'; c.beginPath(); c.arc(x, y, 7, 0, 6.3); c.fill();
  c.strokeStyle = p > 0.7 ? '#ff3b3b' : '#ffd24a'; c.lineWidth = 3; c.beginPath(); c.arc(x, y, 5, -1.57, -1.57 + p * 6.283); c.stroke(); c.fillStyle = '#fff'; c.font = 'bold 9px sans-serif'; c.textAlign = 'center'; c.fillText(p > 0.7 ? '!' : '?', x, y + 3);
}
function cone(c, a) { c.fillStyle = a.alert > 0.3 ? 'rgba(255,60,60,.18)' : 'rgba(255,230,120,.12)'; c.beginPath(); c.moveTo(a.x, a.y); c.arc(a.x, a.y, a.vis || 360, a.a - (a.fov || 1.7) / 2, a.a + (a.fov || 1.7) / 2); c.closePath(); c.fill(); }
function trafficLights(g, c, x0, y0, x1, y1) {
  const w = g.world, t = g.time, cx0 = Math.max(0, Math.floor(x0 / 512) - 0), cx1 = Math.min(NB - 1, Math.floor(x1 / 512) + 1), cy0 = Math.max(0, Math.floor(y0 / 512)), cy1 = Math.min(NB - 1, Math.floor(y1 / 512) + 1);
  const col = ['#3dff6a', '#ffd24a', '#ff3b3b'];
  for (let cy = cy0; cy <= cy1; cy++) for (let cx = cx0; cx <= cx1; cx++) {
    const ix = cx * 512, iy = cy * 512; if ((w.metaAt(ix + 64, iy + 64) & 3) !== 3 || !w.isRoad(ix + 64, iy + 64)) continue; const v = w.trafficLight(cx, cy, t, true), h = w.trafficLight(cx, cy, t, false);
    for (const [px, py, st] of [[ix - 8, iy - 8, v], [ix + 136, iy + 136, v], [ix + 136, iy - 8, h], [ix - 8, iy + 136, h]]) { c.fillStyle = '#16171c'; c.beginPath(); c.arc(px, py, 6, 0, 6.3); c.fill(); c.fillStyle = col[st]; c.beginPath(); c.arc(px, py, 3.6, 0, 6.3); c.fill(); }
  }
}
function heliDraw(g, c) {
  const h = g.heli; c.save(); c.translate(h.x, h.y); c.rotate(h.a); c.fillStyle = '#12151c'; c.beginPath(); c.ellipse(0, 0, 22, 9, 0, 0, 6.3); c.fill(); c.fillRect(-40, -2, 24, 4); c.fillStyle = '#2b3a55'; c.beginPath(); c.ellipse(10, 0, 8, 6, 0, 0, 6.3); c.fill();
  c.strokeStyle = 'rgba(200,200,210,.55)'; c.lineWidth = 3; c.beginPath(); c.moveTo(Math.cos(h.rot) * 44, Math.sin(h.rot) * 44); c.lineTo(-Math.cos(h.rot) * 44, -Math.sin(h.rot) * 44); c.stroke(); c.beginPath(); c.moveTo(Math.cos(h.rot + 1.57) * 44, Math.sin(h.rot + 1.57) * 44); c.lineTo(-Math.cos(h.rot + 1.57) * 44, -Math.sin(h.rot + 1.57) * 44); c.stroke(); c.restore();
}
function worldHud(g, c, x0, y0, x1, y1) {
  const t = g.time, p = g.player;
  // objective beacons
  for (const m of g.markers) {
    if (m.kind === 'foe') continue;
    const pulse = 18 + Math.sin(t * 4) * 4; c.strokeStyle = m.color; c.lineWidth = 3; c.globalAlpha = 0.9;
    c.beginPath(); c.arc(m.x, m.y, pulse, 0, 6.3); c.stroke(); c.globalAlpha = 0.25; c.fillStyle = m.color; c.beginPath(); c.arc(m.x, m.y, pulse, 0, 6.3); c.fill(); c.globalAlpha = 1;
    if (m.x < x0 || m.x > x1 || m.y < y0 || m.y > y1) { /* offscreen arrow */ if (m.kind === 'obj') { const a = Math.atan2(m.y - p.y, m.x - p.x), d = 130; c.save(); c.translate(p.x + Math.cos(a) * d, p.y + Math.sin(a) * d); c.rotate(a); c.fillStyle = m.color; c.globalAlpha = 0.85; c.beginPath(); c.moveTo(12, 0); c.lineTo(-8, 8); c.lineTo(-8, -8); c.fill(); c.restore(); c.globalAlpha = 1; } }
  }
  if (g.hold) { c.strokeStyle = '#ffe14a'; c.lineWidth = 5; c.beginPath(); c.arc(p.x, p.y, 24, -1.57, -1.57 + g.hold.prog * 6.283); c.stroke(); }
  // aim laser
  if (!p.veh && p.wdef && (p.wdef.type === 'gun' || p.wdef.type === 'rocket') && g.aiming) { c.strokeStyle = 'rgba(255,60,60,.5)'; c.lineWidth = 1; c.beginPath(); c.moveTo(p.x + Math.cos(p.aim) * 14, p.y + Math.sin(p.aim) * 14); const d = Math.min(p.wdef.range, g.world.raycast(p.x, p.y, Math.cos(p.aim), Math.sin(p.aim), p.wdef.range)); c.lineTo(p.x + Math.cos(p.aim) * d, p.y + Math.sin(p.aim) * d); c.stroke(); }
  // boss / ally markers
  if (g.boss && !g.boss.dead) { c.strokeStyle = '#ff3b5c'; c.lineWidth = 2; c.beginPath(); c.arc(g.boss.x, g.boss.y, 14, 0, 6.3); c.stroke(); }
  // interact highlight
  if (g.prompt && g.prompt.x !== undefined) { c.strokeStyle = 'rgba(255,255,255,.7)'; c.lineWidth = 1.5; c.beginPath(); c.arc(g.prompt.x, g.prompt.y, 22 + Math.sin(t * 6) * 2, 0, 6.3); c.stroke(); }
}

// ---------- interior ----------
function renderInterior(g, c, alpha, x0, y0, x1, y1) {
  const I = g.scene; c.drawImage(I.cv, 0, 0);
  for (const o of I.objs) if (o.act !== 'exit' && o === g.prompt) { c.strokeStyle = '#ffe14a'; c.lineWidth = 2; c.beginPath(); c.arc(o.x, o.y, 16 + Math.sin(g.time * 6) * 2, 0, 6.3); c.stroke(); }
  for (const p of g.pickups) { if ((p.inside || null) !== g.insideId) continue; c.fillStyle = '#ffe14a'; c.shadowColor = '#ffe14a'; c.shadowBlur = 16; c.fillRect(p.x - 7, p.y - 7, 14, 14); c.shadowBlur = 0; }
  const as = []; for (const a of g.actors) if (a.on && a.inside === g.insideId && !a.veh) as.push(a);
  for (const a of as) if (a.dead) actorDraw(g, c, a, alpha); for (const a of as) if (!a.dead) actorDraw(g, c, a, alpha);
  for (const a of as) if (!a.dead && a.alert > 0.04 && a.st !== 'combat' && a.fac !== 'civ') alertMeter(c, a);
  g.bullets.draw(c, alpha); g.parts.draw(c, x0, y0, x1, y1); g.parts.drawGlow(c, x0, y0, x1, y1);
  worldHud(g, c, x0, y0, x1, y1);
  // exit door label
  c.fillStyle = '#fff'; c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillText('EXIT', I.exitDoor.x, I.h * TS - 6);
  // mood lighting: warm multiplicative ambient + additive lamps (never pitch black)
  c.setTransform(1, 0, 0, 1, 0, 0); const R = g.R, S = R.S;
  const lc = R.lc, ls = R.ls; lc.globalCompositeOperation = 'source-over'; lc.globalAlpha = 1; lc.fillStyle = I.theme.amb || 'rgb(150,140,160)'; lc.fillRect(0, 0, R.lm.width, R.lm.height);
  lc.globalCompositeOperation = 'lighter';
  const L = g.lights; const sx = (x) => ((x - R.cx) * S + g.W / 2) * ls, sy = (y) => ((y - R.cy) * S + g.H / 2) * ls;
  const add = (x, y, r, col, i) => { const rr = r * S * ls; lc.globalAlpha = i; lc.drawImage(lightSpr(col), sx(x) - rr, sy(y) - rr, rr * 2, rr * 2); };
  add(g.player.x, g.player.y, 230, '#fff1dc', 0.55); for (const o of I.objs) add(o.x, o.y, 130, I.theme.accent.length === 7 ? I.theme.accent : '#ffffff', 0.32);
  for (let k = 0; k < 6; k++) add(I.w * TS * (k + 0.5) / 6, I.h * TS * 0.32, 160, '#ffe9c4', 0.3);
  for (let i = 0; i < L.n; i++) { const l = L.a[i]; add(l.x, l.y, l.r, l.col.length === 7 ? l.col : '#ffffff', l.i); }
  for (const tl of g.tmpLights) add(tl.x, tl.y, tl.r, tl.col && tl.col.length === 7 ? tl.col : '#ffd27a', tl.life / tl.max);
  lc.globalAlpha = 1; lc.globalCompositeOperation = 'source-over'; c.globalCompositeOperation = 'multiply'; c.drawImage(R.lm, 0, 0, g.W, g.H); c.globalCompositeOperation = 'source-over';
  L.reset();
}

// ---------- weather ----------
function weather(g, c) {
  const env = g.env, R = g.R, W = g.W, H = g.H, q = QUAL[g.settings.quality];
  if (env.rain > 0.03) {
    const n = Math.floor(q.rain * env.rain), dr = R.rain; while (dr.length < n) dr.push({ x: Math.random() * W, y: Math.random() * H, v: 0.7 + Math.random() * 0.6 }); dr.length = Math.min(dr.length, n);
    c.strokeStyle = `rgba(190,215,255,${0.3 * (env.dark > 0.5 ? 0.9 : 1)})`; c.lineWidth = Math.max(1, g.dpr); c.beginPath();
    const spd = H * 1.1 * g.dt60, sl = 0.18 + env.wind * 0.2;
    for (const d of dr) { d.y += spd * d.v; d.x -= spd * d.v * sl; if (d.y > H) { d.y = -20; d.x = Math.random() * (W + 200); } if (d.x < -50) d.x += W + 100; c.moveTo(d.x, d.y); c.lineTo(d.x + 12 * g.dpr * sl * 3, d.y - 18 * g.dpr * d.v); }
    c.stroke();
    c.fillStyle = `rgba(30,50,80,${0.12 * env.rain})`; c.fillRect(0, 0, W, H);
    if (!g.scene && Math.random() < 0.5) g.parts.emit(7, g.cam.x + (Math.random() - 0.5) * g.viewW, g.cam.y + (Math.random() - 0.5) * g.viewH, 0, 0, 0.3, 2, '#cfe6ff');
  }
  if (env.fog > 0.03) {
    const ox = (g.time * 14) % 256, oy = (g.time * 6) % 256, S = R.S * 1.6;
    c.globalAlpha = env.fog * 0.75; c.save(); c.scale(S, S);
    for (let y = -256; y < H / S + 256; y += 256) for (let x = -256; x < W / S + 256; x += 256) c.drawImage(R.fogT, x + ox, y + oy);
    c.restore(); c.fillStyle = `rgba(170,185,200,${env.fog * 0.28})`; c.globalAlpha = 1; c.fillRect(0, 0, W, H);
  }
  c.globalAlpha = 1;
}

// ---------- lighting (multiplicative ambient lightmap + additive coloured lights) ----------
// Old model: a near-black overlay with holes punched out → harsh pools of light and unreadable shadows.
// New model: the lightmap starts at the *ambient colour of the sky* (sun / moon / weather), every light source ADDS
// coloured energy to it, and the lightmap is MULTIPLIED over the scene. Night is a readable blue moonlight, golden
// hour is warm, noon is neutral, and lamps/headlights bloom softly into the ambient instead of cutting black holes.
function lighting(g, c, props, bl) {
  const env = g.env, R = g.R, S = R.S, W = g.W, H = g.H, L = g.lights, amb = env.amb || [255, 255, 255];
  const dark = env.dark, vis = clamp((dark - 0.04) * 2.4, 0, 1);       // artificial lights fade in at dusk
  const bright = amb[0] > 250 && amb[1] > 250 && amb[2] > 246;
  if (bright && g.tmpLights.length === 0 && vis < 0.02) { L.reset(); return; }
  const ls = R.ls, lc = R.lc, lw = R.lm.width, lh = R.lm.height;
  if (vis > 0.02) {
    for (const p of props) if (p.t === 'lamp' && !p.dead) L.add(p.x, p.y, 190, '#ffd9a0', 0.95 * vis);
    for (const b of bl) if (b.neon && b.name && b.hgt >= 16) L.add((b.x + b.w / 2) * TS, (b.y + b.h) * TS + 18, 140 + b.w * 6, b.neon, 0.62 * vis);
    for (const b of bl) if (b.kind === 'atc' || b.kind === 'terminal') L.add((b.x + b.w / 2) * TS, (b.y + b.h / 2) * TS, 160 + b.w * 4, b.kind === 'atc' ? '#8fe8ff' : '#cfe8ff', 0.5 * vis);
    for (const p of props) if (p.t === 'helipad' || p.t === 'windsock') L.add(p.x, p.y, 90, '#fff4c0', 0.5 * vis);
    for (const v of g.vehicles) {
      if (!v.on || v.wreck || v.x < R.x0 - 300 || v.x > R.x1 + 300 || v.y < R.y0 - 300 || v.y > R.y1 + 300) continue;
      const engine = v.driver || v.npc || v.ai !== 'none'; const fx = Math.cos(v.a), fy = Math.sin(v.a);
      if (engine) { L.add(v.x + fx * v.def.len * 0.4, v.y + fy * v.def.len * 0.4, 290, '#fff4d0', Math.min(1, 1.1 * Math.max(vis, 0.3)), v.a, 0.7); L.add(v.x - fx * v.def.len * 0.5, v.y - fy * v.def.len * 0.5, v.brk > 0.1 ? 80 : 44, '#ff2a2a', (v.brk > 0.1 ? 0.9 : 0.5) * vis); L.add(v.x, v.y, 70, '#ffe8c0', 0.28 * vis); }
      if (v.siren && v.def.siren) { const ph = Math.floor(g.time * 8) % 2; L.add(v.x, v.y, 150, ph ? '#ff2a3a' : '#2a6aff', 0.9); }
    }
    for (const a of g.actors) if (a.on && a.flash > 0) L.add(a.x, a.y, 110, '#ffd27a', 1);
  }
  for (const a of g.actors) if (a.on && a.flash > 0 && vis <= 0.02) L.add(a.x, a.y, 110, '#ffd27a', 1);
  // the player is never lost in the dark: soft moon-fill + a faint torch-glow (scaled by darkness)
  L.add(g.player.x, g.player.y, 150, '#c9d4ff', 0.34 * vis + 0.04);
  for (const tl of g.tmpLights) L.add(tl.x, tl.y, tl.r, tl.col, tl.life / tl.max);
  if (g.heli.on) L.add(g.player.x, g.player.y, 190, '#ffffff', 0.5);
  lc.globalCompositeOperation = 'source-over'; lc.globalAlpha = 1; lc.fillStyle = `rgb(${amb[0] | 0},${amb[1] | 0},${amb[2] | 0})`; lc.fillRect(0, 0, lw, lh);
  lc.globalCompositeOperation = 'lighter';
  const sx = (x) => ((x - R.cx) * S + W / 2) * ls, sy = (y) => ((y - R.cy) * S + H / 2) * ls;
  for (let i = 0; i < L.n; i++) {
    const l = L.a[i], rr = l.r * S * ls; if (sx(l.x) < -rr * 2 || sx(l.x) > lw + rr * 2 || sy(l.y) < -rr * 2 || sy(l.y) > lh + rr * 2) continue;
    const col = l.col.length === 7 ? l.col : '#ffffff'; lc.globalAlpha = Math.min(1, l.i) * 0.85;
    if (l.cone) { lc.save(); lc.translate(sx(l.x), sy(l.y)); lc.rotate(l.ang); lc.drawImage(coneSpr(col, l.cone), 0, -rr, rr, rr * 2); lc.restore(); }
    else lc.drawImage(lightSpr(col), sx(l.x) - rr, sy(l.y) - rr, rr * 2, rr * 2);
  }
  lc.globalAlpha = 1; lc.globalCompositeOperation = 'source-over';
  c.globalCompositeOperation = 'multiply'; c.imageSmoothingEnabled = true; c.drawImage(R.lm, 0, 0, W, H); c.globalCompositeOperation = 'source-over';
  // soft additive bloom of the coloured lights + wet-road reflections
  if (vis > 0.05 || g.tmpLights.length) {
    c.globalCompositeOperation = 'lighter'; const wet = env.wet;
    for (let i = 0; i < L.n; i++) {
      const l = L.a[i], rr = l.r * S, X = (l.x - R.cx) * S + W / 2, Y = (l.y - R.cy) * S + H / 2; if (X < -rr * 2 || X > W + rr * 2 || Y < -rr * 2 || Y > H + rr * 2) continue;
      const col = l.col.length === 7 ? l.col : '#ffffff'; c.globalAlpha = Math.min(1, l.i) * 0.2 * Math.min(1, vis + 0.15);
      if (l.cone) { c.save(); c.translate(X, Y); c.rotate(l.ang); c.drawImage(coneSpr(col, l.cone), 0, -rr, rr, rr * 2); c.restore(); }
      else { c.drawImage(lightSpr(col), X - rr * 0.7, Y - rr * 0.7, rr * 1.4, rr * 1.4); if (wet > 0.3 && l.r > 100 && l.r < 220) { c.globalAlpha *= wet * 0.9; c.drawImage(lightSpr(col), X - rr * 0.3, Y, rr * 0.6, rr * 1.7); } }
    }
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
  }
  L.reset();
}

// ---------- post processing ----------
function post(g, c) {
  const W = g.W, H = g.H, R = g.R, s = g.settings, q = QUAL[s.quality], env = g.env;
  // lightning flash
  if (env.flash > 0.02) { c.fillStyle = `rgba(220,230,255,${env.flash * (s.flashes ? 0.55 : 0.12)})`; c.fillRect(0, 0, W, H); }
  // bloom-fake
  if (s.bloom && q.bloom && !g.scene) {
    R.bc.drawImage(g.canvas, 0, 0, R.bl.width, R.bl.height); c.globalCompositeOperation = 'screen'; c.globalAlpha = 0.06 + env.dark * 0.16; c.imageSmoothingEnabled = true; c.drawImage(R.bl, 0, 0, W, H); c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
  }
  // chromatic aberration on damage
  if (s.aberration && g.fx.ab > 0.04) {
    const d = Math.ceil(g.fx.ab * 7 * g.dpr), a1 = R.ab.getContext('2d'), a2 = R.ab2.getContext('2d');
    a1.globalCompositeOperation = 'source-over'; a1.drawImage(g.canvas, 0, 0); a2.globalCompositeOperation = 'source-over'; a2.drawImage(R.ab, 0, 0);
    a2.globalCompositeOperation = 'multiply'; a2.fillStyle = '#ff0000'; a2.fillRect(0, 0, W, H); a1.globalCompositeOperation = 'multiply'; a1.fillStyle = '#00ffff'; a1.fillRect(0, 0, W, H);
    c.globalCompositeOperation = 'source-over'; c.fillStyle = '#000'; c.fillRect(0, 0, W, H); c.drawImage(R.ab, d, 0); c.globalCompositeOperation = 'lighter'; c.drawImage(R.ab2, -d, 0); c.globalCompositeOperation = 'source-over';
  }
  // focus tint
  if (g.focusT > 0) { c.fillStyle = 'rgba(70,120,255,.14)'; c.fillRect(0, 0, W, H); c.globalAlpha = 0.5; c.drawImage(R.vig, 0, 0); c.globalAlpha = 1; }
  // vignette + hurt
  c.globalAlpha = 0.34 + (s.crt ? 0.25 : 0); c.drawImage(R.vig, 0, 0); c.globalAlpha = 1;
  if (g.fx.hurt > 0.02 || g.player.hp < 30) { const k = Math.max(g.fx.hurt * 0.5, g.player.hp < 30 ? 0.18 + Math.sin(g.time * 6) * 0.06 : 0); c.fillStyle = `rgba(200,0,20,${k})`; c.fillRect(0, 0, W, H); c.globalAlpha = k * 2; c.drawImage(R.vig, 0, 0); c.globalAlpha = 1; }
  if (s.crt) { c.drawImage(R.scan, 0, 0); c.fillStyle = `rgba(255,255,255,${0.015 + Math.random() * 0.015})`; c.fillRect(0, 0, W, H); }
  // sniper scope
  if (g.aiming && g.player.wid === 'sniper' && !g.player.veh) {
    const cx = W / 2, cy = H / 2, r = Math.min(W, H) * 0.42; c.fillStyle = '#000'; c.beginPath(); c.rect(0, 0, W, H); c.arc(cx, cy, r, 0, 6.283, true); c.fill();
    c.strokeStyle = 'rgba(255,60,60,.8)'; c.lineWidth = 1; c.beginPath(); c.moveTo(cx - r, cy); c.lineTo(cx + r, cy); c.moveTo(cx, cy - r); c.lineTo(cx, cy + r); c.stroke();
  }
  // crosshair
  if (g.state === 'play' && !g.player.veh && !g.input.pad.on && !g.input.touch && !g.uiOpen && !g.cut && g.player.wdef && g.player.wdef.type !== 'melee') {
    const mx = g.input.mx * g.dpr, my = g.input.my * g.dpr, sp = (g.player.bloom + (WEAPONS[g.player.wid].spread || 0.03)) * 260 * g.dpr + 6 * g.dpr;
    c.strokeStyle = 'rgba(255,255,255,.85)'; c.lineWidth = 1.5 * g.dpr; c.beginPath(); c.arc(mx, my, sp, 0, 6.283); c.stroke(); c.fillStyle = '#ff4466'; c.fillRect(mx - g.dpr, my - g.dpr, 2 * g.dpr, 2 * g.dpr);
  }
}
