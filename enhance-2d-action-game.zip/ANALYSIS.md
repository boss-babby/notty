# NEON TIDE — Analysis, fixes and the road to procedural infinity

## 1. What the game was (analysis of the uploaded ZIP)
A very complete engine (~4,600 dense lines, zero external assets): seeded city generator, chunked ground canvases, y-sorted sprites, AI (peds, traffic, police, gangs), 12 story missions, 14 interiors, synthesised audio. Weak points found:

| Area | Finding | Impact |
|---|---|---|
| **Lighting** | Night = a 0.86-alpha navy rectangle with soft holes punched out (`destination-out`). Dusk lasted 3 in-game hours, the game *started* at 18:50, vignette 0.55–0.7 black on top, bloom raised with darkness. | Large unreadable black areas, harsh pools of light, player lost in the dark. |
| **Cheat "summon car"** | Vehicle pool = 70 slots. Traffic + parked cars fill it, and `spawnVehicle` only recycled *wrecks* → returned `null`, the cheat silently did nothing. The car was also dropped 90 px in front of the player with no check for walls, water or props. Same bug in the AutoTrader delivery. | Car summons "randomly" failed. |
| **World** | 192×192 tiles, one city, one climate, 5 districts, no air/military/rural content. Many magic numbers (`11`, `192`, `180`) baked in. | Small, repetitive. |
| **Interiors** | 14 hand-made rooms; every house door was decoration. | Few places to go. |
| **Gameplay variety** | 14 vehicles, one region of traffic, no travel, no restricted areas, no regional identity. | Little reason to explore. |

## 2. What was changed

### 2.1 Lighting (realistic model — `render.js`, `game.js`)
* **Ambient colour of the sky is multiplied over the world** instead of a black overlay: moonlight blue at night (never below ~33 % brightness), pink/gold sunrise, neutral noon, golden hour, red sunset, purple dusk (14 keyframes, smooth-stepped, in `AMB`). Rain/fog/storm desaturate and dim it.
* **Every light adds coloured energy** to the lightmap (additive `lighter`), then the map is multiplied over the frame: lamp posts (warm 2700 K), neon signs, headlights (cones), brake lights, sirens, muzzle flashes, explosions, ATC tower/terminal glow. Lights fade in smoothly at dusk (`vis`) instead of popping on.
* A faint moon-fill/torch light always follows the player. A small additive bloom + wet-road reflections sit on top.
* Vignette 0.55 → 0.34, bloom 0.3×dark → 0.16×dark, game starts at 16:20 (sunny afternoon), interiors use a warm per-theme ambient + lamps, never black.

### 2.2 Cheat / car summons (`game.js`, `actors.js`, `ui.js`)
* `spawnVehicle(..., {force:true})` evicts the farthest unoccupied, non-mission, non-owned vehicle → **cannot fail**. Pool enlarged 70 → 110, actor pool 110 → 130.
* `g.summonVehicle()` searches rings around the player (96–340 px, 10 headings) for a spot not inside a building, water, solid prop or another car, aligns the car with the road if on one, and toasts "press E". Menu closes on click.
* New cheat items: repair vehicle, deliver every car to the garage, time presets (golden hour, sunset…), fast travel to every city, grouped vehicle list.
* AutoTrader deliveries use the same forced spawn.

### 2.3 One continuous world, 9× larger (`regions.js`, `world.js`)
18,432 px × 18,432 px (576×576 tiles, 36×36 blocks), 3×3 super-regions, all connected by roads/bridges and sharing the traffic grid:

| | Region | Contents |
|---|---|---|
| NW | **Port Meridian** | the original city (story missions untouched) |
| N | **Sol Costa** | neon pastel beach city: resort towers, Galleria mall, marina, mansions, Club Electra, stadium, SCPD, hospital, tiki bar |
| NE | **Fort Granite** | fenced **army camp**: HQ, barracks, armory, hangars, helipads + helicopters, tanks, tents, sandbags, watchtowers, gate/checkpoint, firing range; snowy highlands & quarry. Trespass 7 s → soldiers open fire (3★) |
| W | **Saguaro Springs** | desert town (saloon, sheriff, motel, mission church, diner, clinic, trailer park, gas), ranches, solar farm, copper mine, drive-in, red mesa canyon |
| Centre | **Aurelia** | mega-city: 80–170 px skyscrapers, central park, station, Dome stadium, university, casino, grand hotel, mall, police, hospital |
| E | **Skyline International Airport** | 156-tile runway + 2nd runway, taxiways, apron with 10 airliners / jets, terminal (**enter it, buy a ticket, fly to any city**), control tower (enterable), hangars, cargo, fuel farm, helipads, parking, hotel |
| SW | **Pine Ridge** | forest, Lake Verde with docks/boats, lodge, cabins, ranger station, campground, lumber mill, snowcapped mountains |
| S | **Ambrose Valley** | crop fields, farmsteads, Marlow town, power plant, wind farm, crop-duster airstrip |
| SE | **Bayou Rouge & the Keys** | swamp (marsh tiles), boardwalk stilt village, gator bar, bait shop, motel, three resort islands linked by the Overseas Highway bridge |

New tile types (runway, tarmac, desert, marsh, farm, forest, snow, concrete, gravel, turf) with their own art, driving grip and AI costs; new building kinds (mountain, hangar, terminal, ATC tower, stadium, solar); 25 new prop types (airliners, jets, helicopters, tanks, trucks, boats, tents, turbines, cattle, cacti, pines…) with collision "blockers" so planes are solid.

### 2.4 Rooms / interiors (`interiors.js`)
17 new enterable interiors: furnished multi-room **houses** (every house door works), cabins, lodge, motel, hotel, mansion, mall, nightclub, church, **airport terminal**, ATC tower, hangar, barracks, army HQ, armory & duty-free shops. Sleep/save/shop/ATM/flight objects, staff and passenger NPCs, per-theme warm lighting.

### 2.5 GTA-VI-style variety
* 10 new vehicles (SUV, off-road 4×4, cabrio, hypercar, limo, army jeep, long-haul truck, tractor, golf cart + existing) with **regional traffic mixes** (cabrios & limos in Sol Costa, pickups in the desert, tractors in farmland, jeeps at the fort, taxis in Aurelia).
* Regional population density, soldiers on base, street names per region, 100+ discoverable places (+$25 each), world map with city labels, fast-travel flights.
* Planned next (data hooks exist): boats/jet-ski, flyable helicopter, wildlife (gators, deer), heists per region, regional gang turf, social-media phone app, dynamic wanted-level by jurisdiction.

---

## 3. Infinite procedural worlds (No Man's Sky style) and how they relate to this game

### 3.1 How NMS-like generation actually works
1. **One seed → everything.** A 64-bit seed is hashed with coordinates (`hash(seed, x, y, z, salt)`); every attribute (terrain height, biome, creature morphology, colours) is a *pure function* of that hash. No world is stored — it is recomputed on demand and is identical for every player.
2. **Hierarchy of scales.** Galaxy → star system → planet → region → chunk → voxel. Each level only needs its parent's seed. This is why a planet can be generated without its neighbours.
3. **Layered noise.** Continents = low-frequency simplex/Perlin, mountains = ridged multifractal, erosion = domain warping, biomes = temperature × humidity lookup. Rules (not hand-placement) decide where life, ore, settlements appear.
4. **Streaming + LOD.** Only chunks near the camera exist; far chunks are discarded or kept at low detail. Generation runs on worker threads within a per-frame budget.
5. **Grammar-based content.** Creatures, ships, buildings are assembled from parts using weighted rules and constraints, so variety is combinatorial.
6. **Hand-authored anchors.** Story, missions and key set-pieces are placed *on top* of the generated substrate.

### 3.2 What we already share with it
* `hash2`, `vnoise`, `mulberry32` in `util.js` are exactly the primitives above; the whole world is generated from `seed = 1337`.
* The ground is already **streamed per 16×16-tile chunk** with LRU eviction (`ensureChunks`), and props/vehicles/peds are spawned around the camera.
* Block generators (`genBlock`, `genDowntown`, region blocks) are *functions of (seed, bx, by)* — re-running one block never needs the rest of the world.
* Regions are a 3×3 "galaxy map" of biomes with their own rules (palette, building grammar, traffic, density) — the same idea as NMS biomes, just authored on a fixed grid.

### 3.3 Why it is not infinite yet (and what blocks it)
| Limit | Today | Needed for infinity |
|---|---|---|
| Storage | `tiles/meta/bid` are fixed `Uint8Array(576²)`; buildings/props are global arrays | sparse **chunk store**: `Map<chunkKey, {tiles, buildings, props}>` generated on demand, freed when far |
| Coordinates | float px up to 18,432 | float32 jitters beyond ~100k px → **floating origin** (re-centre the world on the player, keep chunk ints) |
| Roads | global grid lines, hand-picked per region | procedural network: arterial lines from a low-frequency field, local streets via subdivision, bridges where road crosses water |
| Pathfinding | A* over the whole array | hierarchical A* (chunk graph) + local A* within loaded chunks |
| Persistence | save = player + a few globals | save only *deltas* (destroyed props, owned cars, mission flags); the base world is re-derived from the seed |
| Missions | POIs hard-coded in `data.js` | quest templates that pick a POI of a type from the nearest chunks ("steal a jet from an airfield", "deliver to a farm") |
| Global scans | `world.buildings` is iterated every frame | spatial hash / per-chunk lists (already in place for props) |

### 3.4 A concrete migration plan
1. **Chunk-local generators.** Convert each region block function to `genChunk(cx, cy)`; the call becomes `hash(seed, cx, cy)` seeded. Cross-chunk features (rivers, highways, mountains) use *continuous* noise sampled in world space so neighbouring chunks agree without communicating.
2. **Macro layer.** Sample 2-3 low-frequency fields per chunk (elevation, moisture, "urbanity"). Biome = lookup (`urbanity>0.7 → city; elevation>0.6 → mountains; moisture>0.6 → swamp; …`). The nine hand-made regions become *authored overrides* ("anchors") at fixed chunk ranges — exactly the NMS approach of hand-placed content in a procedural galaxy.
3. **Cities by grammar.** City = centre + radius; density falls off with distance; blocks pick a template (tower, shops, park, houses) weighted by distance from centre and district noise; landmarks (airport, army base, stadium) are placed by *rules* (flat land, near a highway, minimum spacing) from a per-super-cell hash.
4. **Streaming budget.** Generate ≤ 1 chunk per frame (or in a Web Worker returning transferable typed arrays); keep a ring of N chunks; render chunk canvases as already done.
5. **Floating origin** to keep precision, plus chunk-key integers (`(cx+32768)*65536+cy+32768`) instead of the current `cx*64+cy`.
6. **Planetary scale** (optional "Discovery mode"): a *seed browser* — each seed is a whole "state" (like a planet). Show the seed in the menu, let players share seeds, and use the same generator with different biome weights → a different continent with different city names (name grammar: syllable tables per region).
7. **Content variety with grammars:** building facades (kind × palette × signage grammar), vehicles (body shape × colour × livery tables), NPC outfits per biome, shop names from word-lists. This is the cheapest way to get the NMS "everything is different" feeling.

### 3.5 Where it helps us most
* **Replayability:** every new game can roll a new seed — new geography, same handcrafted story anchored at the player's starting city.
* **Size without authoring cost:** the 9 regions took ~600 lines because they reuse helpers and hash-based scattering (`sprinkle`, `massif`, `plane`). Infinite = the same helpers driven by noise instead of coordinates.
* **Risks:** procedural worlds are *wide but shallow* (the NMS criticism). The fix used in this project is the right one: **procedural substrate + authored anchors** (airport, fort, mansions, story missions) + systemic gameplay (heat, turf, traffic, weather) that makes any place feel alive.
* **Performance:** keep generation deterministic and cheap (< 3 ms/chunk), cache chunk canvases, never scan global arrays per frame.

## 4. Controls added
`E` at the airport terminal's *Departures* desk → fast travel (fare by distance). `` ` ``/`F2` cheat menu → summon any vehicle, travel to any city/POI, time presets, repair, deliver all cars.

---

# v3 update — bug fixes, street-light control, helicopters, procedural Frontier

## 5. Bugs fixed
| Bug | Root cause | Fix |
|---|---|---|
| **Player invisible inside buildings / rooms** | `renderInterior` only draws actors whose `inside === g.insideId`, but `player.inside` was never set (it stayed `null`), so the player was skipped (and interior guards could never target him). | `stepSim` now syncs `player.inside = g.insideId` every tick, and the interior renderer always draws the player as a safety net. |
| **Sniper zoom buggy** | (1) "scope" set `cam.zoom = 0.6` = *zoom out*; (2) camera lead was `aimDir × 330`, but the aim direction is computed from the cursor's world position, which depends on the camera → positive feedback loop (aim stuck / drifting); (3) a black disc hid the world and the reticle was at screen centre while the cursor aimed elsewhere. | Camera lead is now derived from the cursor's **screen** offset (`mouseLead`), so it can never feed back into the aim. The scope is a real magnifying lens that follows the cursor (×1.6–5, mouse wheel), surroundings dimmed not blacked out, mil-dot reticle, faster zoom blend. Same stable lead for normal aiming. |

## 6. Street lights & evening / night aesthetics
* `env.eve` = schedule curve (on 17:10→19:10, off 05:00→06:50, bad weather lifts it in the daytime); `env.lamp` = that, or the user override.
* **Control:** Settings → *Street lights* (Auto / Always on / Always off) + *Light glow* slider; **L** key cycles the mode; Cheat menu has three buttons.
* Lamp posts are now unlit fixtures in the sprite; the bulb, halo and light pool are drawn by the renderer only when on. Each lamp has its own switch-on threshold (they pop on one by one at dusk), ~6 % flicker, halos grow in fog/rain (volumetric haze), wet-road reflections kept.
* Windows light up building by building (staggered). Soft-light **golden-hour** grade from the low sun (mirrored at dawn), and a teal→magenta **night split-tone**. Bloom scales with lamps.

## 7. Helicopters (cheat menu → *Helicopters*)
`heli.js`: **Skylark** charter helicopter (general aviation, 5 colours) and **Reaper AH-9** gunship (combat; olive/black/desert). E boards, hold **Space** to lift off, **Shift/C** descend, land to exit (rooftops are landable; flying below a roofline clips it). Gunship: nose follows the mouse, **LMB** minigun, **RMB/R** rocket pods (24, regenerate). 2.5D lift + shadow, rotor blur, nav lights/strobes, searchlight pool at night, rotor-wash dust/spray, synthesised rotor audio, altitude/hull/rotor HUD. Damage to the pilot is redirected to the hull (armour factor 0.42 / 0.2); crashes explode.

## 8. Procedural Frontier — first concrete step of §3.4
The world grew from 576² to **768² tiles** (NT0 = 576 authored, NT = 768). East and south of the nine authored regions, across an ocean channel (with bridges/causeways wherever an authored road meets the shore), `frontier.js` generates land as a pure function of **(seed, tile)**:
* **Macro layer:** elevation + moisture fBm (value noise) → biome lookup: lakes/bays, beaches, desert, grass/farmland, forest, marsh, rock massifs, snow caps; outer coast falls off to ocean.
* **Cities by grammar:** one candidate per 6×6-block super-cell (hash) → centre, radius, name (syllable grammar); urbanity falls off with distance: towers → shops → houses/parks; landmark hotel (enterable, helipad roof) + fountain at the centre; shops/houses use the existing interiors; lamps, crosswalks, zones, discoveries, fast-travel + flight destinations are registered automatically.
* **Roads** follow the existing 16-tile block grid (arterials every 4th block, full grids in cities) so traffic AI, minimap, bridges and the map work unchanged.
* **Seeds:** the main menu has a *World seed* box (🎲 = random). New Game rebuilds the world from the seed (turf is restored from `turf0` instead of re-generating), the seed is shown in the welcome toast and stored in saves. Generation of the whole world takes ≈130 ms.
* **Still to do for true infinity** (see §3.3): chunk-sparse storage, floating origin, hierarchical A*. `frontier.js` is already written as pure per-tile / per-block functions, so those steps are mechanical.
