// ===== terra_gen.js — turns the macro layer into real blocks (tiles, buildings, props) =====
// UNIT OF GENERATION = one 16×16-tile block, or a whole 2×2 "plot" for special nodes.  A unit only reads PURE macro functions
// (never neighbouring generated data) so generating a block can never cascade and is reproducible after eviction.
import { mulberry32, hash2, vnoise, shade } from './util.js';
import { PROPDEF } from './world.js';
import { THEMES, CLS, NEON, PAL } from './terra_data.js';
import { bkey } from './terra.js';

const TS = 32;
let T, M;
const FREE = new Set();
const pk = (r, a) => a[Math.floor(r() * a.length)];

class Unit {
  constructor(W, terra, blocks) { this.W = W; this.terra = terra; this.map = new Map(); this.blocks = blocks; for (const b of blocks) this.map.set(b.key, b); }
  blkT(tx, ty) { return this.map.get(bkey(tx >> 4, ty >> 4)); }
  get(tx, ty) { const b = this.blkT(tx, ty); return b ? b.t[((ty & 15) << 4) | (tx & 15)] : -1; }
  set(tx, ty, t) { const b = this.blkT(tx, ty); if (b) b.t[((ty & 15) << 4) | (tx & 15)] = t; }
  free(tx, ty) { return FREE.has(this.get(tx, ty)); }
  can(x, y, w, h) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) if (!this.free(x + i, y + j)) return false; return true; }
  put(x, y, w, h, t, force) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const c = this.get(x + i, y + j); if (c < 0 || c === T.ROAD || c === T.BRIDGE || c === T.BUILDING || (c === T.WATER && !force)) continue; this.set(x + i, y + j, t); } }
  B(x, y, w, h, o = {}) {
    if (!this.can(x, y, w, h)) return null;
    const W = this.W, b = { id: W.buildings.length, x, y, w, h, hgt: o.hgt || 20, color: o.color || '#555', roof: o.roof || null, kind: o.kind || 'shop', interior: o.interior || null, name: o.name || '', neon: o.neon || null, door: null, seed: Math.floor(hash2(x, y, 7) * 1e6) + 1, windows: o.windows !== false, rt: o.rt || null };
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const bl = this.blkT(x + i, y + j), q = (((y + j) & 15) << 4) | ((x + i) & 15); bl.t[q] = T.BUILDING; bl.bid[q] = b.id; }
    if (b.interior || o.door) b.door = { x: (x + (w >> 1)) * TS + TS / 2, y: (y + h) * TS + TS / 2 };
    W.buildings.push(b); W.regBuilding(b); const own = this.blkT(x, y); own.bld.push(b.id); b.blk = own.key;
    return b;
  }
  prop(type, x, y, o) {
    const bl = this.blkT(Math.floor(x / TS), Math.floor(y / TS)); if (!bl) return null; const d = PROPDEF[type];
    const p = { t: type, x, y, r: d.r, hp: d.hp, a: 0, dead: false, solid: d.solid, low: d.low, id: -1, v: Math.floor(hash2(x | 0, y | 0, 3) * 4) };
    if (o) Object.assign(p, o); p.k = bl.key * 1024 + bl.props.length; if (this.W.deltas.has(p.k)) p.dead = true;
    bl.props.push(p); this.W.propHash.insert(p, x, y); return p;
  }
  propT(type, tx, ty, o) { return this.prop(type, tx * TS + TS / 2, ty * TS + TS / 2, o); }
  scatter(type, n, x, y, w, h, rng, ok) {
    for (let k = 0; k < n; k++) for (let tries = 0; tries < 8; tries++) {
      const tx = x + Math.floor(rng() * w), ty = y + Math.floor(rng() * h), t = this.get(tx, ty);
      if (FREE.has(t) && t !== T.SIDEWALK && (!ok || ok(t))) { this.prop(type, tx * TS + 6 + rng() * 20, ty * TS + 6 + rng() * 20); break; }
    }
  }
  fence(x0, y0, x1, y1, gap) { const n = Math.max(1, Math.floor(Math.hypot(x1 - x0, y1 - y0) / 22)); for (let i = 0; i <= n; i++) { const x = x0 + ((x1 - x0) * i) / n, y = y0 + ((y1 - y0) * i) / n; if (gap && gap(x, y)) continue; const t = this.get(Math.floor(x / TS), Math.floor(y / TS)); if (t === T.ROAD || t === T.BRIDGE || t === T.WATER || t === T.BUILDING) continue; this.prop('fence', x, y); } }
  lot(x, y, w, h, o = {}) { this.put(x, y, w, h, T.PARKING); const bl = this.blkT(x, y); if (bl) for (let j = 0; j < h - 1; j += 3) for (let i = 0; i < w - 1; i += 2) bl.park.push({ x: (x + i + 1) * TS, y: (y + j + 1.2) * TS, a: Math.PI / 2, ...o }); }
  poi(b, key, name) { if (!b || !b.door) return; const bl = this.blkT(Math.floor(b.door.x / TS), Math.floor(b.door.y / TS)) || this.blocks[0]; bl.poi.push({ key, x: b.door.x, y: b.door.y, name }); }
  park(x, y, w, h, rng, th) { this.put(x, y, w, h, T.GRASS); for (let i = 0; i < w; i++) this.put(x + i, y + (h >> 1), 1, 1, T.PATH); for (let j = 0; j < h; j++) this.put(x + (w >> 1), y + j, 1, 1, T.PATH); this.prop('fountain', (x + (w >> 1) + 0.5) * TS, (y + (h >> 1) + 0.5) * TS); this.scatter(th.tree === 'cactus' ? 'cactus' : th.tree === 'palm' ? 'palm' : 'tree', 12, x, y, w, h, rng); this.scatter('bench', 4, x, y, w, h, rng); }
}

// ------------------------------------------------------------------ base tiles (terrain + roads + sidewalks + crosswalks)
function base(terra, U, blk, S) {
  const bx = blk.bx, by = blk.by, th = S ? THEMES[S.n.theme] : null;
  const vS = terra.segAt(1, bx, by), vN = terra.segAt(1, bx, by - 1), hE = terra.segAt(0, bx, by), hW = terra.segAt(0, bx - 1, by);
  const gT = th ? T[th.ground] : T.GRASS;
  for (let ly = 0; ly < 16; ly++) for (let lx = 0; lx < 16; lx++) {
    const tx = bx * 16 + lx, ty = by * 16 + ly; let t = terra.terrain(tx, ty), m = 0; if (S && t === T.WATER) t = T.SAND; /* settlements are built on dry land */ const wet = t === T.WATER;
    const inV = lx < 4 && (ly < 4 ? vS || vN : vS), inH = ly < 4 && (lx < 4 ? hE || hW : hE);
    if (inV || inH) {
      t = wet ? T.BRIDGE : T.ROAD;
      if (inV) { m |= M.V; if ((ly < 4 ? Math.max(vS, vN) : vS) === 2) m |= M.HWY; }
      if (inH) { m |= M.H; if ((lx < 4 ? Math.max(hE, hW) : hE) === 2) m |= M.HWY; }
    } else if (S && !wet) {
      if (lx === 4 || lx === 15 || ly === 4 || ly === 15) t = T.SIDEWALK;
      else if (t !== T.WATER && (t === T.FOREST || t === T.MARSH || t === T.GRAVEL || t === T.SNOW || t === T.FARM || t === T.GRASS || t === T.DESERT || t === T.SAND)) t = gT === T.SAND && t !== T.SAND ? T.SAND : gT === T.DESERT ? T.DESERT : (t === T.SNOW ? T.SNOW : gT);
    }
    const q = (ly << 4) | lx; blk.t[q] = t; blk.m[q] = m;
  }
  if (S && S.u > 0.12) { // crosswalks next to real intersections
    const topI = hE || hW, botI = terra.segAt(0, bx, by + 1) || terra.segAt(0, bx - 1, by + 1), lefI = vS || vN, rigI = terra.segAt(1, bx + 1, by) || terra.segAt(1, bx + 1, by - 1);
    const xw = (lx, ly, bit) => { const q = (ly << 4) | lx; if (blk.t[q] === T.ROAD && (blk.m[q] & (M.V | M.H)) === bit) blk.m[q] |= M.XW; };
    for (let i = 0; i < 4; i++) { if (topI) xw(i, 4, M.V); if (botI) xw(i, 15, M.V); if (lefI) xw(4, i, M.H); if (rigI) xw(15, i, M.H); }
  }
}

// ------------------------------------------------------------------ settlements
function shopB(U, rng, th, x, y, w, h, kind, o = {}) {
  const names = th.shopNames[kind] || th.shopNames.mart;
  return U.B(x, y, w, h, { kind: 'shop', hgt: o.hgt || 22, color: pk(rng, th.shop), interior: kind === 'bar' ? 'bar' : 'shop_' + kind, name: pk(rng, names), neon: pk(rng, NEON), roof: o.roof });
}
function houseRow(U, rng, th, x0, y0, u) {
  const slots = [[x0, y0], [x0 + 5, y0], [x0, y0 + 5], [x0 + 5, y0 + 5]];
  for (const [sx, sy] of slots) {
    if (rng() < 0.12) continue; const w = 4 + (rng() < 0.3 ? 1 : 0), b = U.B(sx, sy, w, 3, { kind: 'house', hgt: 12 + Math.floor(rng() * 8), color: pk(rng, th.house), roof: pk(rng, th.roof), door: true, interior: 'house' });
    if (b) { const bl = U.blkT(sx, sy + 3); if (bl) bl.park.push({ x: (sx + 1) * TS, y: (sy + 3.6) * TS, a: Math.PI / 2 }); if (rng() < 0.4) U.fence(sx * TS, (sy + 4) * TS + 6, (sx + 5) * TS, (sy + 4) * TS + 6, (x) => x > (sx + 0.8) * TS && x < (sx + 2.6) * TS); }
  }
  U.scatter(th.tree === 'stump' ? 'tree' : th.tree, 3 + Math.floor(rng() * 3), x0, y0, 10, 10, rng);
  void u;
}
function settlementBlock(terra, U, blk, S, rng) {
  const n = S.n, th = THEMES[n.theme], bx = blk.bx, by = blk.by, u = S.u, x0 = bx * 16 + 5, y0 = by * 16 + 5, dx = bx - n.bx, dy = by - n.by, cls = n.cls, NAME = n.name.toUpperCase();
  const a = bx * 16 + 4, b = bx * 16 + 15, c = by * 16 + 4, d = by * 16 + 15;
  const L = (tx, ty) => { if (U.get(tx, ty) === T.SIDEWALK) U.propT('lamp', tx, ty); };
  if (u > 0.1 || cls >= 1) { L(a, c); L(b, c); L(a, d); L(b, d); if (cls >= 1) { L(a + 5, c); L(a + 5, d); L(a, c + 5); L(b, c + 5); } }
  if (rng() < 0.5) { const tx = a + 2 + Math.floor(rng() * 8); if (U.get(tx, c) === T.SIDEWALK) U.propT(rng() < 0.5 ? 'hydrant' : 'bin', tx, c); }
  const plazaT = T[th.plaza], tree = th.tree === 'stump' ? 'tree' : th.tree;
  let role;
  if (S.center) role = cls === 3 ? 'metroCenter' : cls === 2 ? 'cityCenter' : cls === 1 ? 'townSquare' : 'villageGreen';
  else if (dx === 1 && dy === 0 && cls >= 1) role = 'police';
  else if (dx === 1 && dy === 0) role = 'church';
  else if (dx === 0 && dy === 1 && cls >= 2) role = 'hospital';
  else if (dx === 0 && dy === 1 && cls === 1) role = 'church';
  else if (dx === -1 && dy === 0 && cls >= 2) role = cls === 3 ? 'mall' : 'hotel';
  else if (dx === 0 && dy === -1 && cls === 3) role = 'stadium';
  else if (dx === -1 && dy === 1 && cls >= 2) role = 'park';
  else {
    const r = rng();
    if (cls === 3) role = u > 0.5 ? (r < 0.8 ? 'tower' : r < 0.9 ? 'casino' : 'park') : u > 0.28 ? (r < 0.4 ? 'mid' : r < 0.7 ? 'shops' : r < 0.82 ? 'apts' : r < 0.9 ? 'garage' : 'park') : (r < 0.6 ? 'houses' : r < 0.8 ? 'warehouse' : 'apts');
    else if (cls === 2) role = u > 0.5 ? (r < 0.4 ? 'mid' : r < 0.8 ? 'shops' : 'tower') : u > 0.25 ? (r < 0.3 ? 'shops' : r < 0.5 ? 'apts' : r < 0.62 ? 'park' : r < 0.72 ? 'motel' : 'houses') : (r < 0.7 ? 'houses' : r < 0.82 ? 'gas' : r < 0.92 ? 'warehouse' : 'lot');
    else if (cls === 1) role = u > 0.45 ? (r < 0.6 ? 'shops' : r < 0.8 ? 'houses' : 'park') : (r < 0.7 ? 'houses' : r < 0.82 ? 'gas' : r < 0.92 ? 'farm' : 'park');
    else role = r < 0.5 ? 'houses' : r < 0.68 ? 'farm' : r < 0.8 ? 'gas' : r < 0.9 ? 'park' : 'houses';
  }
  const tw = (w, h, hg, o = {}) => U.B(x0 + 1, y0 + 1, w, h, { kind: 'tower', hgt: hg, color: pk(rng, th.tower), roof: '#aeb8c2', neon: rng() < 0.45 ? pk(rng, NEON) : null, ...o });
  const reg = (bd, key, name) => { U.poi(bd, 'x' + bx + '_' + by + key, name); };
  blk.role = role;
  switch (role) {
    case 'metroCenter': {
      U.put(x0, y0, 10, 10, T.PLAZA); const bd = U.B(x0 + 2, y0, 6, 6, { kind: 'tower', hgt: 150 + Math.floor(rng() * 40), color: '#3a5a7a', roof: '#6fa0c0', interior: 'office', name: NAME + ' FINANCIAL', neon: '#4fe0ff' });
      U.B(x0, y0 + 1, 2, 4, { kind: 'tower', hgt: 90, color: pk(rng, th.tower), roof: '#aeb8c2' }); U.B(x0 + 8, y0 + 1, 2, 4, { kind: 'tower', hgt: 100, color: pk(rng, th.tower), roof: '#aeb8c2' });
      U.prop('fountain', (x0 + 5) * TS, (y0 + 8) * TS); U.scatter('tree', 4, x0, y0 + 6, 10, 4, rng); reg(bd, 'c', NAME + ' Financial Center'); break;
    }
    case 'cityCenter': {
      U.put(x0, y0, 10, 10, T.PLAZA); const bd = U.B(x0 + 2, y0 + 1, 6, 5, { kind: 'tower', hgt: 70 + Math.floor(rng() * 30), color: pk(rng, th.tower), roof: '#cfd8e0', interior: 'hotel', name: NAME + ' GRAND', neon: pk(rng, NEON) });
      U.prop('fountain', (x0 + 5) * TS, (y0 + 7.6) * TS); U.scatter(tree, 3, x0, y0 + 6, 10, 4, rng); reg(bd, 'c', NAME + ' Grand Hotel'); break;
    }
    case 'townSquare': {
      U.put(x0, y0, 10, 10, plazaT); const bd = U.B(x0 + 2, y0, 6, 4, { kind: 'civic', hgt: 26, color: pk(rng, th.shop), roof: pk(rng, th.roof), interior: 'bank', name: NAME + ' SAVINGS', neon: '#ffe14a' });
      U.prop('fountain', (x0 + 5) * TS, (y0 + 6.5) * TS); U.scatter(tree, 4, x0, y0 + 4, 10, 6, rng); U.scatter('bench', 3, x0, y0 + 4, 10, 6, rng); reg(bd, 'c', NAME + ' Town Hall'); break;
    }
    case 'villageGreen': {
      U.put(x0, y0, 10, 10, plazaT === T.WOOD ? T.WOOD : T.PATH); U.put(x0, y0 + 4, 10, 6, T.GRASS === T[th.ground] ? T.GRASS : T[th.ground]);
      const s1 = shopB(U, rng, th, x0, y0, 4, 4, 'mart'), s2 = shopB(U, rng, th, x0 + 5, y0, 5, 4, rng() < 0.5 ? 'burger' : 'bar');
      U.scatter(tree, 5, x0, y0 + 5, 10, 5, rng); U.scatter('bench', 2, x0, y0 + 5, 10, 5, rng); U.prop('fountain', (x0 + 5) * TS, (y0 + 7) * TS); reg(s1 || s2, 'c', NAME); break;
    }
    case 'police': { const bd = U.B(x0 + 1, y0 + 1, 8, 6, { kind: 'civic', hgt: 34, color: '#2a3f6b', interior: 'police', name: n.cls >= 2 ? NAME + ' PD' : th.civic[0], neon: '#4aa8ff' }); blk.park.push({ x: (x0 + 2) * TS, y: (y0 + 8.5) * TS, a: 0, cop: 1 }, { x: (x0 + 7) * TS, y: (y0 + 8.5) * TS, a: 0, cop: 1 }); reg(bd, 'p', NAME + ' Police'); break; }
    case 'hospital': { const bd = U.B(x0 + 1, y0 + 1, 8, 6, { kind: 'civic', hgt: 34, color: '#e3e8ee', roof: '#f3f6fa', interior: 'hospital', name: th.civic[1], neon: '#ff4f6a' }); reg(bd, 'h', NAME + ' Hospital'); break; }
    case 'church': { U.put(x0, y0, 10, 10, T.GRASS); const bd = U.B(x0 + 2, y0 + 1, 5, 6, { kind: 'civic', hgt: 32, color: '#e6e0d4', roof: '#6b4a3a', interior: 'church', name: 'CHAPEL OF ' + n.name.toUpperCase() }); U.scatter(tree, 6, x0, y0, 10, 10, rng); reg(bd, 'f', NAME + ' Chapel'); break; }
    case 'mall': { U.put(x0, y0, 10, 10, T.PLAZA); const bd = U.B(x0, y0 + 1, 10, 6, { kind: 'civic', hgt: 34, color: '#9fd8d0', roof: '#d8f1ee', interior: 'mall', name: NAME + ' GALLERIA', neon: '#4fe0ff' }); U.lot(x0, y0 + 8, 10, 2); reg(bd, 'm', NAME + ' Galleria'); break; }
    case 'hotel': { U.put(x0, y0, 10, 10, T.PLAZA); const bd = U.B(x0 + 1, y0 + 1, 8, 6, { kind: 'tower', hgt: 60 + Math.floor(rng() * 30), color: pk(rng, th.tower), roof: '#cfd8e0', interior: 'hotel', name: pk(rng, ['PALMS', 'GRAND', 'ROYAL', 'PLAZA']) + ' HOTEL', neon: pk(rng, NEON) }); U.scatter(tree, 3, x0, y0 + 7, 10, 3, rng); reg(bd, 'o', NAME + ' Hotel'); break; }
    case 'stadium': { U.put(x0, y0, 10, 10, T.GRASS); const bd = U.B(x0, y0, 10, 9, { kind: 'stadium', hgt: 40, color: '#c8ccd2', roof: '#3f8f46', name: NAME + ' ARENA', neon: '#ffe14a', windows: false }); if (bd) U.blkT(x0, y0).poi.push({ key: 'x' + bx + '_' + by + 's', x: (x0 + 5) * TS, y: (y0 + 10) * TS, name: NAME + ' Arena' }); break; }
    case 'casino': { U.put(x0, y0, 10, 10, T.PLAZA); const bd = U.B(x0 + 1, y0 + 1, 8, 7, { kind: 'tower', hgt: 56, color: '#5b2f6b', interior: 'casino', name: NAME + ' CASINO', neon: '#ffd24a' }); reg(bd, 'k', NAME + ' Casino'); break; }
    case 'tower': { U.put(x0, y0, 10, 10, T.PLAZA); const r = rng(); if (r < 0.55) tw(8, 8, Math.round(60 + u * 90 + rng() * 40), { interior: rng() < 0.3 ? 'office' : null, name: rng() < 0.3 ? NAME + ' ' + pk(rng, ['TOWER', 'PLAZA', 'CENTER']) : '' }); else for (const [sx, sy] of [[0, 0], [6, 0], [0, 5], [6, 5]]) if (rng() < 0.9) U.B(x0 + sx, y0 + sy, 4, 4, { kind: 'tower', hgt: Math.round(45 + u * 70 + rng() * 40), color: pk(rng, th.tower), roof: '#aeb8c2', neon: rng() < 0.4 ? pk(rng, NEON) : null }); break; }
    case 'mid': { U.put(x0, y0, 10, 10, T.PLAZA); shopB(U, rng, th, x0, y0, 5, 4, pk(rng, ['burger', 'mart', 'clothes', 'bar'])); shopB(U, rng, th, x0 + 5, y0, 5, 4, pk(rng, ['burger', 'clothes', 'bar'])); U.B(x0, y0 + 5, 6, 5, { kind: 'tower', hgt: 40 + Math.floor(rng() * 30), color: pk(rng, th.tower), neon: pk(rng, NEON) }); shopB(U, rng, th, x0 + 6, y0 + 5, 4, 5, pk(rng, ['mart', 'clothes']), { hgt: 26 }); break; }
    case 'shops': { U.put(x0, y0, 10, 10, plazaT === T.WOOD ? T.WOOD : T.PLAZA); const ks = ['burger', 'mart', 'clothes', 'bar']; for (const [sx, sy, w, h] of [[0, 0, 4, 4], [4, 0, 3, 4], [7, 0, 3, 4]]) { if (rng() < 0.1) continue; shopB(U, rng, th, x0 + sx, y0 + sy, w, h, pk(rng, ks)); } if (rng() < 0.5) U.B(x0, y0 + 5, 10, 5, { kind: 'tower', hgt: 30 + Math.floor(rng() * 20), color: pk(rng, th.tower), neon: pk(rng, NEON) }); else { U.lot(x0, y0 + 5, 10, 5); U.scatter(tree, 3, x0, y0 + 5, 10, 5, rng); } break; }
    case 'apts': { const bd = U.B(x0 + 1, y0 + 1, 8, 4, { kind: 'apt', hgt: 28 + Math.floor(rng() * 12), color: pk(rng, th.house), interior: 'apartment', name: 'RESIDENCES', neon: null }); U.lot(x0 + 1, y0 + 6, 8, 3); U.scatter(tree, 5, x0, y0, 10, 10, rng); void bd; break; }
    case 'houses': houseRow(U, rng, th, x0, y0, u); break;
    case 'park': U.park(x0, y0, 10, 10, rng, th); break;
    case 'gas': { U.put(x0, y0, 10, 10, T.PARKING); const bd = U.B(x0 + 2, y0 + 1, 5, 3, { kind: 'shop', hgt: 16, color: '#cfd8dc', interior: 'shop_mart', name: pk(rng, ['GAS-N-GO', 'FUEL STOP', 'PIT STOP']), neon: '#ffe14a' }); for (const i of [2, 4, 6]) U.propT('pump', x0 + i, y0 + 6); blk.park.push({ x: (x0 + 3) * TS, y: (y0 + 8) * TS, a: Math.PI / 2 }); void bd; break; }
    case 'motel': { U.put(x0, y0, 10, 10, T.PARKING); const bd = U.B(x0 + 1, y0 + 1, 8, 3, { kind: 'shop', hgt: 18, color: pk(rng, th.shop), roof: pk(rng, th.roof), interior: 'motel', name: pk(rng, ['SUNSET MOTEL', 'ROUTE INN', 'STAR LODGE', 'THE REST STOP']), neon: '#ff4fd8' }); U.lot(x0 + 1, y0 + 5, 8, 4); void bd; break; }
    case 'farm': { U.put(x0, y0, 10, 10, T.DIRT); U.B(x0 + 1, y0 + 1, 5, 4, { kind: 'barn', hgt: 24, color: pk(rng, PAL.barn), roof: '#6b2a20', door: true, windows: false }); U.B(x0 + 7, y0 + 1, 3, 3, { kind: 'house', hgt: 16, color: pk(rng, th.house), roof: pk(rng, th.roof), door: true, interior: 'house' }); U.B(x0 + 7, y0 + 5, 2, 2, { kind: 'silo', hgt: 42, color: '#9aa0a6', windows: false }); U.scatter('hay', 5, x0, y0 + 5, 7, 5, rng); U.scatter(tree, 4, x0, y0, 10, 10, rng); break; }
    case 'warehouse': { U.put(x0, y0, 10, 10, T.PARKING); U.B(x0, y0, 10, 4, { kind: 'warehouse', hgt: 24, color: pk(rng, PAL.ind), door: true }); if (rng() < 0.6) U.B(x0, y0 + 6, 10, 4, { kind: 'warehouse', hgt: 22, color: pk(rng, PAL.ind), door: true }); else for (let i = 0; i < 3; i++) U.B(x0 + i * 3, y0 + 7, 2, 1, { kind: 'container', hgt: 14, color: pk(rng, PAL.cont), windows: false }); U.scatter('barrel', 4, x0, y0 + 4, 10, 2, rng); U.scatter('crate', 3, x0, y0 + 4, 10, 2, rng); break; }
    case 'garage': { U.put(x0, y0, 10, 10, T.PARKING); const bd = U.B(x0 + 1, y0 + 2, 7, 4, { kind: 'warehouse', hgt: 22, color: '#7a5d44', interior: 'garage', name: NAME + ' AUTO', neon: '#ff6a3d' }); U.scatter('barrel', 3, x0, y0 + 6, 10, 3, rng); void bd; break; }
    default: U.lot(x0, y0, 10, 10); U.scatter(tree, 4, x0, y0, 10, 10, rng);
  }
  if (S.center) blk.found = n;
}

// ------------------------------------------------------------------ wilderness
function wild(terra, U, blk, rng, biome) {
  const bx = blk.bx, by = blk.by, s = terra.seed, T_ = T;
  // mountain massifs where the ground is gravel/snow (3×3 footprints, bigger/higher towards the peaks)
  for (let ly = 0; ly < 14; ly += 2) for (let lx = 0; lx < 14; lx += 2) {
    const tx = bx * 16 + lx, ty = by * 16 + ly, t = U.get(tx, ty); if (t !== T_.GRAVEL && t !== T_.SNOW) continue;
    const h = hash2(tx, ty, s + 31); if (h >= 0.4) continue;
    let ok = true; for (let j = 0; j < 3 && ok; j++) for (let i = 0; i < 3; i++) { const tt = U.get(tx + i, ty + j); if (tt !== T_.GRAVEL && tt !== T_.SNOW) { ok = false; break; } }
    if (!ok) continue;
    const e = terra.elev(tx, ty), hg = Math.round(38 + (e - 0.7) * 560 * (0.7 + hash2(tx, ty, s + 3) * 0.6)), c = pk(rng, ['#6b6358', '#756c60', '#5f5850', '#7a7065']);
    U.B(tx, ty, 3, 3, { kind: 'mountain', hgt: Math.max(30, hg), color: c, roof: e > 0.82 ? '#e9eff3' : shade(c, 0.18), windows: false });
  }
  // trees, cacti, rocks … in noisy groves (not uniformly sprinkled)
  for (let ly = 0; ly < 16; ly += 2) for (let lx = 0; lx < 16; lx += 2) {
    const tx = bx * 16 + lx, ty = by * 16 + ly, t = U.get(tx, ty); if (t === T_.ROAD || t === T_.BRIDGE || t === T_.BUILDING || t === T_.WATER || t === T_.SIDEWALK) continue;
    let near = false; for (const [i, j] of [[-1, 0], [1, 0], [0, -1], [0, 1], [1, 1], [-1, -1]]) { const tt = U.get(tx + i, ty + j); if (tt === T_.ROAD || tt === T_.BRIDGE || tt === T_.BUILDING) { near = true; break; } }
    if (near) continue;
    const h = hash2(tx, ty, s + 41), grove = vnoise(tx / 11, ty / 11, s + 43), px = tx * TS + 8 + hash2(tx, ty, s + 5) * 40, py = ty * TS + 8 + hash2(tx, ty, s + 9) * 40;
    if (t === T_.FOREST) { if (h < 0.12 + grove * 0.55) U.prop(biome === 'taiga' || hash2(tx, ty, s + 8) < 0.5 ? 'pine' : 'tree', px, py); }
    else if (t === T_.GRASS) { if (h < (grove > 0.6 ? 0.34 : 0.04)) U.prop('tree', px, py); else if (h > 0.985) U.prop('rock', px, py); }
    else if (t === T_.DESERT) { if (h < 0.03 + (grove > 0.55 ? 0.14 : 0)) U.prop('cactus', px, py); else if (h > 0.955) U.prop('rock', px, py); }
    else if (t === T_.FARM) { if (h < 0.05) U.prop('hay', px, py); }
    else if (t === T_.MARSH) { if (h < 0.14) U.prop('stump', px, py); else if (h > 0.95) U.prop('tree', px, py); }
    else if (t === T_.SAND) { if (h < 0.06) U.prop('palm', px, py); }
    else if (t === T_.GRAVEL || t === T_.SNOW) { if (h > 0.88) U.prop('rock', px, py); else if (t === T_.SNOW && h < 0.05) U.prop('pine', px, py); }
  }
}

// one-block points of interest — the "set pieces" of the wilderness, each matched to its biome
function poiBlock(terra, U, blk, rng, biome, roadside) {
  const bx = blk.bx, by = blk.by, x0 = bx * 16 + 5, y0 = by * 16 + 5, s = terra.seed;
  for (let j = 0; j < 10; j += 3) for (let i = 0; i < 10; i += 3) { const t = U.get(x0 + i, y0 + j); if (t === T.WATER || t === T.ROAD || t === T.BRIDGE) return false; }
  const kits = roadside ? ['gas', 'diner', 'motel', 'gas'] : {
    plains: ['farm', 'wind', 'ranch', 'radio', 'farm'], farm: ['farm', 'farm', 'wind', 'ranch'], desert: ['mine', 'solar', 'ranch', 'shack', 'solar'], forest: ['cabins', 'camp', 'lumber', 'radio'],
    taiga: ['cabins', 'camp', 'lumber'], tundra: ['cabins', 'radio', 'wind'], alpine: ['cabins', 'radio', 'mine'], marsh: ['stilt', 'stilt', 'shack'], coast: ['light', 'beachbar', 'wind'],
  }[biome];
  if (!kits) return false;
  const kind = kits[Math.floor(rng() * kits.length)], th = THEMES[{ plains: 'prairie', farm: 'prairie', desert: 'west', forest: 'timber', taiga: 'timber', tundra: 'alpine', alpine: 'alpine', marsh: 'bayou', coast: 'resort' }[biome] || 'prairie'];
  const nm = (k) => pk(rng, th.shopNames[k]);
  const gT = { farm: T.DIRT, ranch: T.GRASS, mine: T.GRAVEL, radio: T.DIRT, shack: T.DIRT, lumber: T.DIRT, camp: T.GRASS, gas: T.PARKING, diner: T.PARKING, motel: T.PARKING, solar: T.DIRT, wind: null, cabins: null, stilt: null, light: T.SAND, beachbar: T.SAND }[kind];
  if (gT) U.put(x0, y0, 10, 10, gT);
  let door = null, title = '';
  switch (kind) {
    case 'farm': U.B(x0 + 1, y0 + 1, 5, 4, { kind: 'barn', hgt: 24, color: pk(rng, PAL.barn), roof: '#6b2a20', door: true, windows: false }); door = U.B(x0 + 7, y0 + 1, 3, 3, { kind: 'house', hgt: 16, color: pk(rng, th.house), roof: pk(rng, th.roof), door: true, interior: 'house' }); U.B(x0 + 7, y0 + 5, 2, 2, { kind: 'silo', hgt: 42, color: '#9aa0a6', windows: false }); U.scatter('hay', 6, x0, y0 + 5, 7, 5, rng); title = 'Farmstead'; break;
    case 'ranch': U.fence(x0 * TS, y0 * TS, (x0 + 10) * TS, y0 * TS); U.fence(x0 * TS, (y0 + 10) * TS, (x0 + 10) * TS, (y0 + 10) * TS, (x) => x > (x0 + 4) * TS && x < (x0 + 6) * TS); U.fence(x0 * TS, y0 * TS, x0 * TS, (y0 + 10) * TS); U.fence((x0 + 10) * TS, y0 * TS, (x0 + 10) * TS, (y0 + 10) * TS); for (let i = 0; i < 6; i++) U.prop('cattle', (x0 + 1 + rng() * 8) * TS, (y0 + 3 + rng() * 6) * TS, { a: rng() * 6.28, v: i & 3 }); door = U.B(x0 + 3, y0 + 1, 4, 2, { kind: 'barn', hgt: 20, color: '#9b3a2a', roof: '#6b2a20', door: true, windows: false }); title = 'Cattle Ranch'; break;
    case 'wind': for (let i = 0; i < 4; i++) U.prop('turbine', (x0 + 1 + (i % 2) * 5 + rng() * 2) * TS, (y0 + 1 + (i >> 1) * 5 + rng() * 2) * TS); title = 'Wind Farm'; break;
    case 'radio': door = U.B(x0 + 4, y0 + 4, 2, 2, { kind: 'silo', hgt: 96, color: '#b9bec4', windows: false }); U.B(x0 + 1, y0 + 6, 3, 2, { kind: 'house', hgt: 12, color: '#8a8f94', door: true, interior: 'house' }); U.fence((x0 + 2) * TS, (y0 + 2) * TS, (x0 + 8) * TS, (y0 + 2) * TS); title = 'Radio Mast'; door = null; break;
    case 'mine': door = U.B(x0 + 1, y0 + 1, 4, 3, { kind: 'warehouse', hgt: 20, color: '#6b6f73', door: true, interior: 'garage', name: 'ORE & CO', neon: '#ffb347' }); for (let i = 0; i < 3; i++) U.B(x0 + 1 + i * 3, y0 + 6, 2, 1, { kind: 'container', hgt: 14, color: pk(rng, PAL.cont), windows: false }); U.scatter('rock', 6, x0, y0, 10, 10, rng); U.scatter('barrel', 3, x0, y0 + 4, 10, 2, rng); U.scatter('crate', 3, x0, y0 + 4, 10, 2, rng); title = 'Open Mine'; break;
    case 'solar': U.B(x0, y0, 5, 4, { kind: 'solar', hgt: 8, color: '#2a3f6b', windows: false }); U.B(x0 + 5, y0, 5, 4, { kind: 'solar', hgt: 8, color: '#2a3f6b', windows: false }); U.B(x0, y0 + 5, 5, 4, { kind: 'solar', hgt: 8, color: '#2a3f6b', windows: false }); U.B(x0 + 5, y0 + 5, 5, 4, { kind: 'solar', hgt: 8, color: '#2a3f6b', windows: false }); title = 'Solar Array'; break;
    case 'shack': door = U.B(x0 + 3, y0 + 3, 3, 3, { kind: 'house', hgt: 12, color: pk(rng, th.house), roof: pk(rng, th.roof), door: true, interior: 'house' }); U.scatter('barrel', 2, x0, y0, 10, 10, rng); U.scatter('crate', 2, x0, y0, 10, 10, rng); U.scatter(th.tree, 4, x0, y0, 10, 10, rng); title = 'Hermit Shack'; break;
    case 'cabins': for (const [sx, sy] of [[1, 1], [6, 2], [3, 6]]) { const b = U.B(x0 + sx, y0 + sy, 3, 3, { kind: 'house', hgt: 14, color: pk(rng, PAL.log), roof: pk(rng, PAL.darkroofs), door: true, interior: 'cabin' }); if (b && !door) door = b; } U.scatter('pine', 8, x0, y0, 10, 10, rng); title = 'Cabin Cluster'; break;
    case 'camp': for (let i = 0; i < 4; i++) U.prop('tent', (x0 + 1.5 + (i % 2) * 5 + rng()) * TS, (y0 + 2 + (i >> 1) * 4 + rng()) * TS, { a: rng() * 6.28, v: i & 3 }); U.scatter('bench', 2, x0, y0, 10, 10, rng); U.scatter('barrel', 1, x0 + 4, y0 + 4, 2, 2, rng); U.scatter('pine', 6, x0, y0, 10, 10, rng); door = U.B(x0 + 6, y0 + 7, 3, 2, { kind: 'shop', hgt: 14, color: pk(rng, PAL.log), interior: 'shop_mart', name: 'TRAILHEAD MART', neon: '#7cff4f' }); title = 'Campground'; break;
    case 'lumber': door = U.B(x0 + 1, y0 + 1, 6, 4, { kind: 'warehouse', hgt: 22, color: '#7a5230', door: true, interior: 'garage', name: 'LUMBER MILL', neon: '#ff9a3c' }); U.scatter('crate', 6, x0, y0 + 5, 10, 4, rng); U.scatter('barrel', 2, x0, y0 + 5, 10, 4, rng); U.scatter('pine', 5, x0, y0, 10, 10, rng); title = 'Lumber Mill'; break;
    case 'stilt': { U.put(x0 + 1, y0 + 2, 8, 6, T.WOOD, true); door = U.B(x0 + 2, y0 + 3, 3, 2, { kind: 'house', hgt: 12, color: pk(rng, PAL.swamp), roof: pk(rng, PAL.roofs), door: true, interior: 'cabin' }); U.B(x0 + 6, y0 + 3, 2, 2, { kind: 'house', hgt: 12, color: pk(rng, PAL.swamp), roof: pk(rng, PAL.roofs), door: true, interior: 'cabin' }); U.scatter('stump', 4, x0, y0, 10, 10, rng); title = 'Stilt Shack'; break; }
    case 'light': door = U.B(x0 + 4, y0 + 3, 2, 2, { kind: 'light', hgt: 96, color: '#ece7e0', roof: '#c0392b', windows: false, door: true }); U.scatter('rock', 6, x0, y0, 10, 10, rng); U.scatter('palm', 3, x0, y0, 10, 10, rng); U.put(x0 + 4, y0 + 5, 2, 5, T.PATH); title = 'Lighthouse'; break;
    case 'beachbar': door = U.B(x0 + 1, y0 + 1, 5, 3, { kind: 'shop', hgt: 18, color: '#f2d28b', interior: 'bar', name: nm('bar'), neon: '#ff9a3c' }); U.scatter('umbrella', 5, x0, y0 + 4, 10, 6, rng, (t) => t === T.SAND); U.scatter('lounger', 4, x0, y0 + 4, 10, 6, rng); U.scatter('palm', 5, x0, y0, 10, 10, rng); title = 'Beach Bar'; break;
    case 'gas': door = U.B(x0 + 2, y0 + 1, 5, 3, { kind: 'shop', hgt: 16, color: '#cfd8dc', interior: 'shop_mart', name: pk(rng, ['GAS-N-GO', 'FUEL STOP', 'PIT STOP', 'ROUTE 9 GAS']), neon: '#ffe14a' }); for (const i of [2, 4, 6]) U.propT('pump', x0 + i, y0 + 6); blk.park.push({ x: (x0 + 3) * TS, y: (y0 + 8) * TS, a: Math.PI / 2 }); title = 'Service Station'; break;
    case 'diner': door = U.B(x0 + 1, y0 + 1, 6, 3, { kind: 'shop', hgt: 16, color: pk(rng, th.shop), interior: 'shop_burger', name: nm('burger'), neon: pk(rng, NEON) }); U.lot(x0 + 1, y0 + 5, 8, 4); U.propT('sign', x0 + 8, y0 + 1); title = 'Roadside Diner'; break;
    case 'motel': door = U.B(x0 + 1, y0 + 1, 8, 3, { kind: 'shop', hgt: 18, color: pk(rng, th.shop), roof: pk(rng, th.roof), interior: 'motel', name: pk(rng, ['SUNSET MOTEL', 'ROUTE INN', 'STAR LODGE', 'THE REST STOP']), neon: '#ff4fd8' }); U.lot(x0 + 1, y0 + 5, 8, 4); title = 'Roadside Motel'; break;
    default: return false;
  }
  if (door && door.door) U.poi(door, 'x' + bx + '_' + by + 'p', title);
  else if (title) blk.poi.push({ key: 'x' + bx + '_' + by + 'p', x: (x0 + 5) * TS, y: (y0 + 5) * TS, name: title });
  blk.kit = kind; return true;
}

// ------------------------------------------------------------------ 2×2 plots for special nodes
function plotKit(terra, U, n, rng, biome) {
  const bx0 = n.bx, by0 = n.by, X = bx0 * 16 + 5, Y = by0 * 16 + 5, TW = 26, th = THEMES[n.theme], own = U.blkT(X, Y), NAME = n.name.toUpperCase();
  const gnd = { desert: T.DESERT, coast: T.SAND, tundra: T.SNOW, alpine: T.GRAVEL }[biome] || T.GRASS;
  const planeProp = (tx, ty, ang, type) => { const x = tx * TS, y = ty * TS; U.prop(type, x, y, { a: ang, v: Math.floor(rng() * 4) }); const L = type === 'jet' ? 30 : 0; for (let d = -L; d <= L && L; d += 24) U.prop('blocker', x + Math.cos(ang) * d, y + Math.sin(ang) * d); };
  let zone = null, dk = null;
  switch (n.kit) {
    case 'airstrip': {
      U.put(X, Y, TW, TW, gnd === T.SNOW ? T.GRAVEL : gnd); U.put(X, Y + 2, TW, 4, T.RUNWAY); U.put(X, Y + 6, TW, 1, T.TARMAC); U.put(X + 3, Y + 7, 14, 6, T.TARMAC); U.put(X + 18, Y + 7, 2, 4, T.TARMAC);
      U.B(X + 2, Y + 15, 8, 5, { kind: 'hangar', hgt: 26, color: '#7d848c', roof: '#9aa3ad', interior: 'hangar', name: NAME + ' AERO', neon: '#4fe0ff' });
      const tw = U.B(X + 18, Y + 12, 3, 3, { kind: 'atc', hgt: 60, color: '#b9c0c8', roof: '#4fe0ff', interior: 'atc', name: 'TOWER' });
      planeProp(X + 8, Y + 10, 0, 'jet'); planeProp(X + 13, Y + 10, 0.2, 'jet'); U.prop('windsock', (X + 24) * TS, (Y + 7) * TS); U.propT('pump', X + 14, Y + 14); U.propT('pump', X + 15, Y + 14);
      U.lot(X + 12, Y + 17, 8, 4); U.scatter('barrel', 3, X, Y + 21, 14, 4, rng); U.poi(tw, 'x' + bx0 + '_' + by0 + 'a', NAME + ' Airstrip'); dk = 'x_airstrip'; break;
    }
    case 'military': {
      U.put(X, Y, TW, TW, gnd === T.SAND ? T.DIRT : gnd); U.put(X + 2, Y + 2, 22, 20, T.CONCRETE);
      const rect = [(X + 1) * TS, (Y + 1) * TS, (X + 25) * TS, (Y + 23) * TS];
      U.fence(rect[0], rect[1], rect[2], rect[1]); U.fence(rect[0], rect[1], rect[0], rect[3]); U.fence(rect[2], rect[1], rect[2], rect[3]); U.fence(rect[0], rect[3], rect[2], rect[3], (x) => x > (X + 11) * TS && x < (X + 15) * TS);
      U.B(X + 4, Y + 4, 8, 3, { kind: 'warehouse', hgt: 20, color: '#5a6248', interior: 'barracks', name: 'BARRACKS', door: true }); U.B(X + 4, Y + 9, 8, 3, { kind: 'warehouse', hgt: 20, color: '#4f5a3f', interior: 'barracks', name: 'BARRACKS B', door: true });
      const hq = U.B(X + 15, Y + 4, 6, 5, { kind: 'civic', hgt: 28, color: '#5a6248', roof: '#4a523c', interior: 'hq', name: n.name.toUpperCase() + ' HQ', neon: '#ffb347' }); U.B(X + 15, Y + 11, 4, 3, { kind: 'warehouse', hgt: 18, color: '#58604a', interior: 'shop_armory', name: 'ARMORY', door: true });
      for (const [tx, ty] of [[X + 2, Y + 2], [X + 22, Y + 2], [X + 2, Y + 20], [X + 22, Y + 20]]) U.B(tx, ty, 2, 2, { kind: 'silo', hgt: 52, color: '#6b6f58', windows: false });
      for (let i = 0; i < 3; i++) U.prop('tent', (X + 5 + i * 3.5) * TS, (Y + 16) * TS, { a: 0, v: i }); U.prop('tank', (X + 17) * TS, (Y + 17) * TS, { a: -0.4 }); for (const d of [-26, 0, 26]) U.prop('blocker', (X + 17) * TS + d, (Y + 17) * TS + 0.4 * d * 0); U.prop('helipad', (X + 20) * TS, (Y + 19) * TS); U.prop('heli', (X + 20) * TS, (Y + 19) * TS, { a: 0.5, v: 0 }); for (let i = 0; i < 6; i++) U.prop('sandbag', (X + 10 + i * 0.7) * TS, (Y + 22.4) * TS);
      U.poi(hq, 'x' + bx0 + '_' + by0 + 'm', n.name + ' Outpost'); zone = rect; dk = 'fortbase'; break;
    }
    case 'resort': {
      U.put(X, Y, TW, TW, T.SAND); U.put(X + 2, Y + 10, 10, 6, T.WOOD); U.put(X + 3, Y + 11, 8, 4, T.WATER, true); U.put(X + 14, Y + 2, 10, 22, T.PLAZA);
      const t1 = U.B(X + 15, Y + 3, 8, 7, { kind: 'tower', hgt: 100, color: pk(rng, PAL.pastel), roof: '#fff1f5', interior: 'hotel', name: NAME + ' RESORT', neon: '#ff4fd8' }); U.B(X + 15, Y + 13, 8, 7, { kind: 'tower', hgt: 78, color: pk(rng, PAL.pastel), roof: '#fff1f5', neon: '#4fe0ff' });
      U.B(X + 2, Y + 2, 6, 4, { kind: 'shop', hgt: 20, color: '#f2d28b', interior: 'bar', name: 'TIKI POOL BAR', neon: '#ff9a3c' });
      U.scatter('lounger', 8, X + 1, Y + 8, 12, 10, rng, (t) => t === T.WOOD || t === T.SAND); U.scatter('umbrella', 6, X + 1, Y + 8, 12, 10, rng, (t) => t === T.WOOD || t === T.SAND); U.scatter('palm', 10, X, Y, 14, TW, rng); U.prop('fountain', (X + 19) * TS, (Y + 11.5) * TS);
      U.lot(X + 14, Y + 21, 10, 3, { type: 'supercar' }); U.poi(t1, 'x' + bx0 + '_' + by0 + 'r', NAME + ' Resort'); dk = 'x_resort'; break;
    }
    case 'port': {
      U.put(X, Y, TW, TW, T.CONCRETE); U.put(X, Y + 17, TW, 9, T.PARKING);
      for (const tx of [X + 2, X + 20]) U.B(tx, Y + 2, 2, 2, { kind: 'crane', hgt: 80, color: '#e0a526', windows: false });
      for (let j = 0; j < 3; j++) for (let i = 0; i < 4; i++) if (rng() < 0.8) U.B(X + 2 + i * 3, Y + 6 + j * 3, 2, 1, { kind: 'container', hgt: 14, color: pk(rng, PAL.cont), windows: false });
      const wh = U.B(X + 15, Y + 6, 10, 5, { kind: 'warehouse', hgt: 24, color: pk(rng, PAL.ind), door: true, interior: 'garage', name: NAME + ' FREIGHT', neon: '#ff3b5c' });
      for (let i = 0; i < 3; i++) U.B(X + 16 + i * 3, Y + 13, 2, 2, { kind: 'silo', hgt: 36, color: '#aab0b6', windows: false });
      U.scatter('barrel', 8, X, Y + 17, TW, 8, rng); U.scatter('crate', 6, X, Y + 17, TW, 8, rng); U.fence(X * TS, (Y + 16) * TS, (X + TW) * TS, (Y + 16) * TS, (x) => x > (X + 11) * TS && x < (X + 14) * TS); U.poi(wh, 'x' + bx0 + '_' + by0 + 'h', NAME + ' Port'); dk = 'x_port'; break;
    }
    default: { // quarry
      U.put(X, Y, TW, TW, T.GRAVEL); U.put(X + 4, Y + 4, 14, 12, T.DIRT);
      for (let i = 0; i < 22; i++) { const a = rng() * 6.28, r = 9 + rng() * 3, tx = Math.round(X + 11 + Math.cos(a) * r * 1.3), ty = Math.round(Y + 10 + Math.sin(a) * r); U.B(tx, ty, 3, 3, { kind: 'mountain', hgt: 40 + Math.floor(rng() * 40), color: pk(rng, ['#6b6358', '#756c60', '#7a7065']), roof: '#8a8176', windows: false }); }
      const sh = U.B(X + 19, Y + 19, 5, 3, { kind: 'warehouse', hgt: 20, color: '#6b6f73', door: true, interior: 'garage', name: 'ROCK CRUSHER', neon: '#ffb347' }); for (let i = 0; i < 3; i++) U.prop('truck', (X + 8 + i * 3) * TS, (Y + 9) * TS, { a: rng() * 6.28, v: i & 3 });
      U.scatter('rock', 8, X, Y, TW, TW, rng); U.scatter('barrel', 3, X + 18, Y + 16, 8, 3, rng); U.scatter('crate', 3, X + 18, Y + 16, 8, 3, rng); U.poi(sh, 'x' + bx0 + '_' + by0 + 'q', NAME + ' Quarry'); dk = 'x_quarry';
    }
  }
  if (zone) { own.zr = zone; own.zk = 'fortbase'; }
  for (const b of U.blocks) { b.dk = dk; b.kitName = n.kit; }
  own.found = null;
}

// ------------------------------------------------------------------ entry point
const mkBlock = (bx, by) => ({ bx, by, key: bkey(bx, by), t: new Uint8Array(256), m: new Uint8Array(256), bid: new Int32Array(256).fill(-1), bld: [], props: [], park: [], poi: [], dk: 'x_wild_plains', place: '', st: null, hw: 0, zr: null, zk: null, found: null, role: '', kit: null, last: 0, unit: 0 });

export function genUnit(terra, W, K, bx, by) {
  T = K.T; M = K.M; if (!FREE.size) for (const n of ['GRASS', 'DIRT', 'DESERT', 'FOREST', 'GRAVEL', 'SAND', 'FARM', 'SNOW', 'TURF', 'CONCRETE', 'PLAZA', 'PARKING', 'SIDEWALK', 'TARMAC', 'PATH', 'MARSH']) FREE.add(T[n]);
  const plot = terra.plotAt(bx, by), blocks = [];
  if (plot) for (let j = 0; j < 2; j++) for (let i = 0; i < 2; i++) blocks.push(mkBlock(plot.bx + i, plot.by + j)); else blocks.push(mkBlock(bx, by));
  const U = new Unit(W, terra, blocks), uid = ++W.unitCounter;
  for (const blk of blocks) {
    blk.unit = uid; const S = plot ? null : terra.settlementAt(blk.bx, blk.by), rng = mulberry32(Math.imul(blk.bx * 73856093 ^ blk.by * 19349663, 83492791) + terra.seed * 7 | 0);
    base(terra, U, blk, S); blk.S = S;
    const cx = blk.bx * 16 + 8, cy = blk.by * 16 + 8, prov = terra.province(blk.bx, blk.by);
    blk.biome = terra.biomeAt(cx, cy); blk.place = prov.name;
    if (S) { const n = S.n; blk.dk = `x_${n.theme}_${CLS[n.cls]}`; blk.place = n.name; blk.st = THEMES[n.theme].streets; }
    else if (!plot) { blk.dk = 'x_wild_' + blk.biome; blk.st = THEMES[{ plains: 'prairie', farm: 'prairie', desert: 'west', forest: 'timber', taiga: 'timber', tundra: 'alpine', alpine: 'alpine', marsh: 'bayou', coast: 'resort', lake: 'timber', ocean: 'resort' }[blk.biome]].streets; }
    if (plot) continue;
    if (S) settlementBlock(terra, U, blk, S, rng);
    else {
      wild(terra, U, blk, rng, blk.biome);
      const road = terra.segAt(0, blk.bx, blk.by) || terra.segAt(1, blk.bx, blk.by) || terra.segAt(0, blk.bx, blk.by + 1) || terra.segAt(1, blk.bx + 1, blk.by);
      const nd = terra.node(Math.floor(blk.bx / 8), Math.floor(blk.by / 8)), junction = nd.valid && nd.cls === -1 && nd.bx === blk.bx && nd.by === blk.by;
      const h = hash2(blk.bx, blk.by, terra.seed + 90);
      if (blk.biome !== 'ocean' && blk.biome !== 'lake') { if (junction) poiBlock(terra, U, blk, rng, blk.biome, true); else if (road && h < 0.1) poiBlock(terra, U, blk, rng, blk.biome, true); else if (!road && h < 0.075) poiBlock(terra, U, blk, rng, blk.biome, false); }
    }
  }
  if (plot) {
    const rng = mulberry32(plot.sd), biome = plot.biome; plotKit(terra, U, plot, rng, biome);
    // trees/props around the plot's own roads
    for (const blk of blocks) { blk.place = plot.name + ' ' + ({ airstrip: 'Airstrip', military: 'Outpost', resort: 'Resort', port: 'Port', quarry: 'Quarry' }[plot.kit]); blk.st = th0(plot); }
  }
  return blocks;
}
const th0 = (n) => THEMES[n.theme].streets;
