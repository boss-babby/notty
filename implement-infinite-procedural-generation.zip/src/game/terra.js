// ===== terra.js — the macro layer of the INFINITE world =====
// Everything here is a PURE FUNCTION of (seed, coordinates). Nothing is stored except memo caches, so any part of the infinite
// plane can be (re)built independently and always comes out identical — the NMS rule "one seed → everything".
//   fields      continents (domain-warped fBm) · hills · rivers (iso-lines of a 3rd field) · temperature · moisture → biome
//   settlements one NODE per 8×8-block macro cell (jittered, 4 retries to find land) → class (none/village/town/city/metro/special),
//               theme (from biome), grammar name, radius.  Cities have organic, noise-perturbed outlines and overlap into conurbations.
//   roads       a node graph (E, S and two diagonal links per node); every link is routed over the 16-tile block LATTICE with a
//               turn-penalised A* whose cost sees water (→ bridges), mountains and the authored core.  Memoised per link, so a block only
//               needs the links of the 5×5 cells around it.  Highways = links between big nodes.  Core exits ("gateways") are
//               routed the same way from the authored map's border roads to the nearest node, so authored + procedural roads join up.
//   plots       "special" nodes own a 2×2-block plot (airstrip, army outpost, resort, port, quarry) — roads never cross a plot interior.
import { vnoise, hash2, mulberry32, clamp } from './util.js';
import { THEMES, THEME_OF_BIOME, nameFor, PROVINCE_ADJ, PROVINCE_NOUN } from './terra_data.js';

export const CELL = 8; // blocks per macro cell
const OFF = 32768;
export const bkey = (x, y) => (x + OFF) * 65536 + (y + OFF);
const segKey = (o, x, y) => bkey(x, y) * 2 + o;
const contrast = (v, k = 1.8) => clamp((v - 0.5) * k + 0.5, 0, 1);
const smoothstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const NATURAL = new Set();
const SPECIAL_KITS = { coast: ['resort', 'port', 'resort'], desert: ['airstrip', 'military', 'quarry', 'airstrip'], plains: ['airstrip', 'military', 'quarry'], farm: ['airstrip', 'quarry'], forest: ['military', 'quarry'], taiga: ['military', 'quarry'], tundra: ['quarry', 'military'], alpine: ['quarry', 'military'] };
const RANK = [1, 2, 3, 4]; // class → route rank
const DIRS4 = [[1, 0], [0, 1], [1, 1], [-1, 1]];

export class Terra {
  constructor(seed, K) {
    this.seed = seed | 0; this.K = K; const { T } = K; this.T = T; this.NT = K.NT; this.NB = K.NT >> 4;
    for (const n of ['GRASS', 'SAND', 'DESERT', 'MARSH', 'FARM', 'FOREST', 'SNOW', 'GRAVEL', 'DIRT', 'WATER']) NATURAL.add(T[n]);
    this.nodes = new Map(); this.sCache = new Map(); this.pCache = new Map(); this.routes = new Map(); this.cells = new Map(); this.sc = new Map(); this.prov = new Map();
    this.gateSegs = new Map(); this.core = null; this.gates = [];
    this._wx = 0; this._wy = 0;
  }
  attachCore(W) { this.core = W; this.initGates(); }
  inCore(bx, by, m = 0) { return bx >= -m && by >= -m && bx < this.NB + m && by < this.NB + m; }

  // ---------------------------------------------------------------- fields
  fbm(x, y, s, o = 4) { let v = 0, a = 1, t = 0, f = 1; for (let i = 0; i < o; i++) { v += vnoise(x * f, y * f, s + i * 13) * a; t += a; a *= 0.5; f *= 2; } return v / t; }
  moat(tx, ty) {
    const NT = this.NT; let m = 0;
    if (tx >= NT - 16) m = Math.max(m, clamp(1 - (tx - (NT - 16)) / 120, 0, 1) * clamp(1 + Math.min(ty, 0) / 100, 0, 1));
    if (ty >= NT - 16) m = Math.max(m, clamp(1 - (ty - (NT - 16)) / 120, 0, 1) * clamp(1 + Math.min(tx, 0) / 100, 0, 1));
    return m;
  }
  /** elevation 0..1 (sea level .30). Also leaves the domain-warped coords in _wx/_wy for the river field. */
  elev(tx, ty) {
    const s = this.seed, wx = tx + (vnoise(tx / 190, ty / 190, s + 5) - 0.5) * 150, wy = ty + (vnoise(tx / 190 + 9, ty / 190 - 4, s + 6) - 0.5) * 150;
    this._wx = wx; this._wy = wy;
    const c = this.fbm(wx / 720, wy / 720, s + 11, 4), l = this.fbm(tx / 74, ty / 74, s + 17, 3);
    let e = contrast(c * 0.7 + l * 0.3, 1.9);
    const mo = this.moat(tx, ty); if (mo > 0) e -= mo * 0.58;
    return e;
  }
  river(e) { // call right after elev() for the same tile
    if (e < 0.34) return false;
    const r = this.fbm(this._wx / 400 + 17, this._wy / 400 - 5, this.seed + 41, 3);
    return Math.abs(r - 0.5) < 0.0105 * clamp((0.74 - e) / 0.26, 0, 1);
  }
  moist(tx, ty) { return contrast(this.fbm(tx / 560 + 40, ty / 560 - 25, this.seed + 29, 4), 1.7); }
  temp(tx, ty) { return contrast(this.fbm(tx / 1150 - 13, ty / 1150 + 31, this.seed + 53, 3), 1.7); }

  /** authored border biome continued outward (blends the finite authored map into the infinite one, no visible seam) */
  contTerrain(tx, ty) {
    const NT = this.NT, core = this.core; if (!core) return -1;
    let cx = clamp(tx, 0, NT - 1), cy = clamp(ty, 0, NT - 1); const d = Math.hypot(tx - cx, ty - cy), BL = 80;
    if (d > 0 && d < BL) { const j = Math.floor((hash2(tx >> 3, ty >> 3, this.seed + 9) - 0.5) * 36); if (tx === cx) cx = clamp(cx + j, 0, NT - 1); else if (ty === cy) cy = clamp(cy + j, 0, NT - 1); }
    if (d >= BL || d === 0) return -1;
    if (hash2(tx >> 1, ty >> 1, this.seed + 5) >= (1 - d / BL) * 1.2 - 0.05) return -1;
    const dx = cx === tx ? 0 : tx < 0 ? 1 : -1, dy = cy === ty ? 0 : ty < 0 ? 1 : -1, tl = core.tiles;
    for (let k = 0; k < 14; k++) for (const lat of [0, 7, -7, 13, -13]) {
      const x = clamp(cx + dx * k + (dx ? 0 : lat), 0, NT - 1), y = clamp(cy + dy * k + (dy ? 0 : lat), 0, NT - 1), t = tl[y * NT + x];
      if (NATURAL.has(t)) return t;
    }
    return -1;
  }
  terrain(tx, ty) {
    const c = this.contTerrain(tx, ty); if (c >= 0) return c;
    return this.rawTerrain(tx, ty);
  }
  rawTerrain(tx, ty) {
    const T = this.T, e = this.elev(tx, ty);
    if (e < 0.3) return T.WATER; if (e < 0.335) return T.SAND;
    if (this.river(e)) return T.WATER;
    if (e > 0.84) return T.SNOW; if (e > 0.72) return T.GRAVEL;
    const m = this.moist(tx, ty), t = this.temp(tx, ty);
    if (t < 0.24) return T.SNOW;
    if (t < 0.38) return m > 0.44 ? T.FOREST : T.GRASS;
    if ((t > 0.6 && m < 0.46) || m < 0.28) return T.DESERT;
    if (m < 0.54) return vnoise(tx / 30, ty / 30, this.seed + 7) > 0.56 ? T.FARM : T.GRASS;
    if (m < 0.7) return T.FOREST;
    return t > 0.5 && e < 0.52 ? T.MARSH : T.FOREST;
  }
  biomeOfTile(t, tx, ty) {
    const T = this.T;
    switch (t) {
      case T.WATER: return this.elev(tx, ty) < 0.24 ? 'ocean' : 'lake';
      case T.SAND: return 'coast'; case T.SNOW: return this.elev(tx, ty) > 0.8 ? 'alpine' : 'tundra'; case T.GRAVEL: return 'alpine';
      case T.DESERT: return 'desert'; case T.MARSH: return 'marsh'; case T.FARM: return 'farm';
      case T.FOREST: return this.temp(tx, ty) < 0.4 ? 'taiga' : 'forest';
      default: return 'plains';
    }
  }
  biomeAt(tx, ty) { return this.biomeOfTile(this.terrain(tx, ty), tx, ty); }
  landAt(bx, by) { const e = this.elev(bx * 16 + 8, by * 16 + 8); return e >= 0.31 && !this.river(e); }

  // ---------------------------------------------------------------- settlements
  node(ci, cj) { const k = bkey(ci, cj); let n = this.nodes.get(k); if (n === undefined) { n = this._mkNode(ci, cj, k); this.nodes.set(k, n); } return n; }
  _mkNode(ci, cj, id) {
    const s = this.seed, r = mulberry32(Math.imul(ci * 73856093 ^ cj * 19349663, 83492791) + s + 700 | 0);
    let bx = 0, by = 0, ok = false;
    for (let k = 0; k < 4 && !ok; k++) {
      bx = ci * CELL + 1 + Math.floor(r() * 6); by = cj * CELL + 1 + Math.floor(r() * 6);
      if (this.inCore(bx, by, 2)) continue;
      const e = this.elev(bx * 16 + 8, by * 16 + 8); if (e > 0.37 && e < 0.7 && !this.river(e)) ok = true;
    }
    if (!ok) return { id, valid: false, ci, cj };
    const tx = bx * 16 + 8, ty = by * 16 + 8, e = this.elev(tx, ty); let biome = this.biomeAt(tx, ty);
    const q = r(), rr = r(); let cls = q < 0.17 ? -1 : q < 0.45 ? 0 : q < 0.69 ? 1 : q < 0.82 ? 2 : q < 0.865 ? 3 : 4;
    if (cls >= 2 && (e > 0.62 || biome === 'alpine' || biome === 'marsh')) cls = 1;
    if (cls === 3 && (biome === 'tundra' || biome === 'taiga')) cls = 2;
    // near the sea → coastal theme
    let sea = 0; for (const [dx, dy] of [[56, 0], [-56, 0], [0, 56], [0, -56]]) if (this.elev(tx + dx, ty + dy) < 0.3) sea++;
    if (sea && cls >= 0 && cls < 4 && biome !== 'alpine' && biome !== 'tundra' && r() < 0.8) biome = 'coast';
    let theme = THEME_OF_BIOME[biome] || 'prairie', kit = null;
    if (cls === 4) {
      const ks = SPECIAL_KITS[biome]; let good = !!ks;
      if (good) for (const [dx, dy] of [[1, 0], [0, 1], [1, 1]]) { const e2 = this.elev((bx + dx) * 16 + 8, (by + dy) * 16 + 8); if (e2 < 0.35 || e2 > 0.72) good = false; }
      if (good) { kit = ks[Math.floor(r() * ks.length)]; if (kit === 'port' && sea < 1) kit = 'quarry'; } else { cls = 1; }
    }
    if (cls === 3) theme = 'metro';
    const rad = cls === 0 ? 0.95 + rr * 0.55 : cls === 1 ? 1.5 + rr * 0.6 : cls === 2 ? 2.3 + rr * 0.7 : cls === 3 ? 3.2 + rr * 0.7 : 1;
    return { id, valid: true, ci, cj, bx, by, cls, kit, theme, biome, rad, e, name: cls >= 0 && cls < 4 ? nameFor(theme, r) : kit ? nameFor(theme, r) : null, key: 'x' + id, sd: Math.floor(r() * 1e9) };
  }
  settlementAt(bx, by) {
    if (this.inCore(bx, by, 0)) return null;
    const k = bkey(bx, by), c = this.sCache.get(k); if (c !== undefined) return c;
    if (this.sCache.size > 40000) this.sCache.clear();
    const ci = Math.floor(bx / CELL), cj = Math.floor(by / CELL); let best = null, bu = 0;
    for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) {
      const n = this.node(ci + di, cj + dj); if (!n.valid || n.cls < 0 || n.cls > 3) continue;
      const dx = bx - n.bx, dy = by - n.by; let d = Math.hypot(dx, dy); if (d > n.rad * 1.4) continue;
      d *= 0.74 + 0.5 * vnoise(bx * 0.6 + n.bx * 3.1, by * 0.6 + n.by * 1.7, this.seed + 61);
      if (d <= n.rad) { const u = 1 - d / n.rad; if (u > bu || (d === 0)) { bu = u; best = n; } }
    }
    let res = null;
    if (best && !this.plotAt(bx, by) && (this.landAt(bx, by) || (bx === best.bx && by === best.by))) res = { n: best, u: bu, center: bx === best.bx && by === best.by };
    this.sCache.set(k, res); return res;
  }
  plotAt(bx, by) {
    if (this.inCore(bx, by, 0)) return null;
    const k = bkey(bx, by), c = this.pCache.get(k); if (c !== undefined) return c;
    if (this.pCache.size > 40000) this.pCache.clear();
    const ci = Math.floor(bx / CELL), cj = Math.floor(by / CELL); let res = null;
    for (let dj = -1; dj <= 1 && !res; dj++) for (let di = -1; di <= 1; di++) { const n = this.node(ci + di, cj + dj); if (n.valid && n.cls === 4 && bx >= n.bx && bx <= n.bx + 1 && by >= n.by && by <= n.by + 1) { res = n; break; } }
    this.pCache.set(k, res); return res;
  }
  province(bx, by) {
    const PS = 13, ci = Math.floor(bx / PS), cj = Math.floor(by / PS); let best = null, bd = 1e9;
    for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) {
      const i = ci + di, j = cj + dj, px = (i + hash2(i, j, this.seed + 81)) * PS, py = (j + hash2(i, j, this.seed + 82)) * PS, d = Math.hypot(bx - px, by - py);
      if (d < bd) { bd = d; best = { i, j, px, py }; }
    }
    const k = bkey(best.i, best.j); let p = this.prov.get(k);
    if (!p) {
      const b = this.biomeAt(Math.round(best.px * 16 + 8), Math.round(best.py * 16 + 8)), N = PROVINCE_NOUN[b], h = hash2(best.i, best.j, this.seed + 83);
      p = { id: k, biome: b, name: PROVINCE_ADJ[Math.floor(h * PROVINCE_ADJ.length)] + ' ' + N[Math.floor(hash2(best.i, best.j, this.seed + 84) * N.length)] };
      if (this.prov.size > 5000) this.prov.clear(); this.prov.set(k, p);
    }
    return p;
  }

  // ---------------------------------------------------------------- road lattice
  coreSeg(o, bx, by) {
    const { T, M } = this.K, c = this.core; if (!c) return 0, 0;
    const tx = o === 0 ? bx * 16 + 8 : bx * 16 + 1, ty = o === 0 ? by * 16 + 1 : by * 16 + 8, q = ty * this.NT + tx, t = c.tiles[q];
    if ((t === T.ROAD || t === T.BRIDGE) && (c.meta[q] & (o === 0 ? M.H : M.V))) return c.meta[q] & M.HWY ? 2 : 1;
    return 0;
  }
  segAt(o, bx, by) {
    if (this.inCore(bx, by, 0)) return this.coreSeg(o, bx, by);
    const pa = this.plotAt(bx, by), pb = o === 0 ? this.plotAt(bx, by - 1) : this.plotAt(bx - 1, by);
    if (pa && pa === pb) return 0;
    if (!pa && this.settlementAt(bx, by)) return 1;
    if (!pb && (o === 0 ? this.settlementAt(bx, by - 1) : this.settlementAt(bx - 1, by))) return 1;
    const key = segKey(o, bx, by), v = this.roadCell(Math.floor(bx / CELL), Math.floor(by / CELL)).get(key);
    return v || this.gateSegs.get(key) || 0;
  }
  segCost(o, x, y) {
    const key = segKey(o, x, y); let c = this.sc.get(key); if (c !== undefined) return c;
    if (this.inCore(x, y, 0)) c = Infinity;
    else {
      const pa = this.plotAt(x, y), pb = o === 0 ? this.plotAt(x, y - 1) : this.plotAt(x - 1, y);
      if (pa && pa === pb) c = Infinity;
      else {
        c = 1; const ox = o === 0 ? 0 : 2, oy = o === 0 ? 2 : 0;
        for (let i = 3; i < 16; i += 5) {
          const e = this.elev(x * 16 + (o === 0 ? i : ox), y * 16 + (o === 0 ? oy : i));
          if (e < 0.3) c += 2.6; else if (e > 0.84) c += 3.2; else if (e > 0.72) c += 1.6;
        }
        c *= 0.88 + 0.24 * hash2(x, y, this.seed + 91 + o);
      }
    }
    if (this.sc.size > 400000) this.sc.clear();
    this.sc.set(key, c); return c;
  }
  /** turn-penalised A* over the block lattice. returns { xs, ys, os, water } or null */
  astar(sx, sy, gx, gy, margin = 5, maxWet = 1e9) {
    const x0 = Math.min(sx, gx) - margin, y0 = Math.min(sy, gy) - margin, W = Math.abs(gx - sx) + 2 * margin + 1, H = Math.abs(gy - sy) + 2 * margin + 1;
    const N = W * H * 4, g = new Float32Array(N).fill(1e9), par = new Int32Array(N).fill(-1), closed = new Uint8Array(N);
    const hf = [], hi = [];
    const push = (f, i) => { let k = hf.length; hf.push(f); hi.push(i); while (k > 0) { const p = (k - 1) >> 1; if (hf[p] <= f) break; hf[k] = hf[p]; hi[k] = hi[p]; k = p; } hf[k] = f; hi[k] = i; };
    const pop = () => { const top = hi[0], lf = hf.pop(), li = hi.pop(), n = hf.length; if (n > 0) { let k = 0; for (;;) { let c = 2 * k + 1; if (c >= n) break; if (c + 1 < n && hf[c + 1] < hf[c]) c++; if (hf[c] >= lf) break; hf[k] = hf[c]; hi[k] = hi[c]; k = c; } hf[k] = lf; hi[k] = li; } return top; };
    const st = (x, y, d) => (((y - y0) * W) + (x - x0)) * 4 + d, DX = [1, 0, -1, 0], DY = [0, 1, 0, -1];
    const hh = (x, y) => (Math.abs(x - gx) + Math.abs(y - gy)) * 0.95 * 1.12;
    for (let d = 0; d < 4; d++) { g[st(sx, sy, d)] = 0; push(hh(sx, sy), st(sx, sy, d)); }
    let goal = -1, it = 0;
    while (hf.length && it++ < 60000) {
      const cur = pop(); if (closed[cur]) continue; closed[cur] = 1;
      const d = cur & 3, cell = cur >> 2, x = x0 + (cell % W), y = y0 + ((cell / W) | 0);
      if (x === gx && y === gy) { goal = cur; break; }
      for (let nd = 0; nd < 4; nd++) {
        if (((nd + 2) & 3) === d) continue;
        const nx = x + DX[nd], ny = y + DY[nd]; if (nx < x0 || ny < y0 || nx >= x0 + W || ny >= y0 + H) continue;
        const o = nd & 1 ? 1 : 0, sxk = nd === 0 ? x : nd === 2 ? x - 1 : x, syk = nd === 1 ? y : nd === 3 ? y - 1 : y;
        const c = this.segCost(o ? 1 : 0, o ? x : sxk, o ? syk : y); if (c === Infinity) continue;
        const ni = st(nx, ny, nd), ng = g[cur] + c + (nd !== d ? 0.45 : 0);
        if (ng < g[ni]) { g[ni] = ng; par[ni] = cur; push(ng + hh(nx, ny), ni); }
      }
    }
    if (goal < 0) return null;
    const xs = [], ys = [], os = []; let wet = 0, run = 0, cur = goal;
    while (par[cur] >= 0) {
      const p = par[cur], cell = cur >> 2, x = x0 + (cell % W), y = y0 + ((cell / W) | 0), pc = p >> 2, px = x0 + (pc % W), py = y0 + ((pc / W) | 0);
      const o = px === x ? 1 : 0, sx2 = Math.min(px, x), sy2 = Math.min(py, y); xs.push(sx2); ys.push(sy2); os.push(o);
      const e = this.elev(sx2 * 16 + 8 + (o ? 0 : 0), sy2 * 16 + 8); if (e < 0.3) { run++; if (run > wet) wet = run; } else run = 0;
      cur = p;
    }
    if (wet > maxWet) return null;
    return { xs, ys, os, wet };
  }
  rank(n) { return n.cls < 0 ? 0.5 : n.cls === 4 ? 2 : RANK[n.cls]; }
  edgeOK(A, B, di, dj) { if (!A.valid || !B.valid) return false; const h = hash2(A.ci * 31 + di, A.cj * 17 + dj, this.seed + 700); return di !== 0 && dj !== 0 ? h < 0.2 : h < 0.93; }
  route(A, B) {
    const k = A.id * 3 + B.id; let r = this.routes.get(k); if (r !== undefined) return r;
    r = this.astar(A.bx, A.by, B.bx, B.by, 5, 10);
    if (r) r.hw = this.rank(A) + this.rank(B) >= 5;
    if (this.routes.size > 20000) this.routes.clear();
    this.routes.set(k, r); return r;
  }
  roadCell(ci, cj) {
    const ck = bkey(ci, cj); let m = this.cells.get(ck); if (m) return m;
    m = new Map(); const bx0 = ci * CELL, by0 = cj * CELL;
    for (let dj = -2; dj <= 2; dj++) for (let di = -2; di <= 2; di++) {
      const A = this.node(ci + di, cj + dj); if (!A.valid) continue;
      for (const [dx, dy] of DIRS4) {
        const B = this.node(ci + di + dx, cj + dj + dy); if (!this.edgeOK(A, B, dx, dy)) continue;
        const r = this.route(A, B); if (!r) continue;
        for (let i = 0; i < r.xs.length; i++) { const x = r.xs[i], y = r.ys[i]; if (x < bx0 || y < by0 || x >= bx0 + CELL || y >= by0 + CELL) continue; const k = segKey(r.os[i], x, y), v = r.hw ? 2 : 1; if ((m.get(k) || 0) < v) m.set(k, v); }
      }
    }
    if (this.cells.size > 600) this.cells.clear();
    this.cells.set(ck, m); return m;
  }

  // ---------------------------------------------------------------- core gateways (authored border roads → procedural network)
  initGates() {
    const NB = this.NB, add = (o, x, y) => this.gateSegs.set(segKey(o, x, y), 2), starts = [];
    let last = -99;
    for (let bx = 0; bx < NB; bx += 1) if (bx % 4 === 0 && this.coreSeg(1, bx, 0)) starts.push({ o: 1, f: [[bx, -1], [bx, -2]], s: [bx, -2], dir: [0, -1] });
    for (let by = 0; by < NB; by += 1) if (by % 4 === 0 && this.coreSeg(0, 0, by)) starts.push({ o: 0, f: [[-1, by], [-2, by]], s: [-2, by], dir: [-1, 0] });
    for (let by = 0; by < NB; by += 1) if (by % 4 === 0 && this.coreSeg(0, NB - 1, by)) starts.push({ o: 0, f: [[NB, by], [NB + 1, by]], s: [NB + 2, by], dir: [1, 0] });
    for (let bx = 0; bx < NB; bx += 1) if (bx % 4 === 0 && this.coreSeg(1, bx, NB - 1)) starts.push({ o: 1, f: [[bx, NB], [bx, NB + 1]], s: [bx, NB + 2], dir: [0, 1] });
    void last;
    for (const st of starts) {
      for (const [x, y] of st.f) add(st.o, x, y);
      // nearest valid node in the outward direction
      const ci = Math.floor(st.s[0] / CELL), cj = Math.floor(st.s[1] / CELL); let best = null, bd = 1e9;
      for (let r = 0; r <= 4 && !best; r++) for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) {
        if (Math.max(Math.abs(di), Math.abs(dj)) !== r) continue;
        const n = this.node(ci + di, cj + dj); if (!n.valid) continue;
        const d = Math.abs(n.bx - st.s[0]) + Math.abs(n.by - st.s[1]) + (this.inCore(n.bx, n.by, 3) ? 999 : 0);
        if (d < bd) { bd = d; best = n; }
      }
      if (!best) continue;
      const r = this.astar(st.s[0], st.s[1], best.bx, best.by, 6, 1e9);
      if (!r) continue;
      for (let i = 0; i < r.xs.length; i++) add(r.os[i], r.xs[i], r.ys[i]);
      this.gates.push({ node: best.id, at: st.s });
    }
  }

  // ---------------------------------------------------------------- colours for the macro map (minimap / world map of unloaded blocks)
  macroRGB(tx, ty) {
    const T = this.T, t = this.terrain(tx, ty);
    switch (t) {
      case T.WATER: return [24, 66, 95]; case T.SAND: return [185, 165, 111]; case T.DESERT: return [205, 170, 112]; case T.MARSH: return [48, 92, 72]; case T.FARM: return [126, 154, 72];
      case T.FOREST: return [38, 84, 40]; case T.SNOW: return [225, 235, 240]; case T.GRAVEL: return [128, 120, 108]; default: return [47, 90, 51];
    }
  }
  mini(bx, by) { // 16×16 RGBA (Uint8ClampedArray) from pure functions only
    const out = new Uint8ClampedArray(16 * 16 * 4), s = this.settlementAt(bx, by), pl = this.plotAt(bx, by);
    const vS = this.segAt(1, bx, by), vN = this.segAt(1, bx, by - 1), hE = this.segAt(0, bx, by), hW = this.segAt(0, bx - 1, by);
    for (let ly = 0; ly < 16; ly++) for (let lx = 0; lx < 16; lx++) {
      let c = this.macroRGB(bx * 16 + lx, by * 16 + ly);
      const inV = lx < 4 && (ly < 4 ? vS || vN : vS), inH = ly < 4 && (lx < 4 ? hE || hW : hE);
      if (inV || inH) c = [92, 97, 112];
      else if (s && lx >= 4 && ly >= 4) c = (lx + ly) % 5 === 0 ? [122, 125, 134] : s.u > 0.5 ? [64, 69, 84] : s.u > 0.25 ? [88, 84, 92] : [96, 112, 86];
      else if (pl) c = [88, 92, 98];
      const q = (ly * 16 + lx) * 4; out[q] = c[0]; out[q + 1] = c[1]; out[q + 2] = c[2]; out[q + 3] = 255;
    }
    return out;
  }
}
export { THEMES, segKey, smoothstep };
