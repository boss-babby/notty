// ===== terra_data.js — identity tables for the INFINITE world ("Terra") =====
// The authored regions each have an identity (palette, building grammar, traffic, street names, density).
// Terra gives every procedural settlement the same kind of identity by choosing one of these THEMES from the local biome,
// so that a desert town feels like Saguaro Springs, a coastal one like Sol Costa, a metropolis like Aurelia, etc.
import { TRAFFIC_BY, DISTRICT_NAMES } from './data.js';

export const CLS = ['village', 'town', 'city', 'metro'];
export const CLS_LABEL = ['Village', 'Town', 'City', 'Metropolis'];

const PAL = {
  pastel: ['#e8a6b8', '#9fd8d0', '#f2d28b', '#a8c5e8', '#d8b4e8', '#f5b895'],
  glass: ['#3a5a7a', '#2f6b7a', '#4a5a8a', '#5a6a7a', '#2c4a6a', '#6a7a8a', '#4b6a8a'],
  west: ['#b98a5a', '#c9a26a', '#a7774a', '#d3b27a', '#c08a6a'],
  log: ['#7a5230', '#8a6038', '#6a4528', '#935f38'],
  swamp: ['#6a7a5a', '#8a7a5a', '#5a6a4a', '#7a6a50'],
  house: ['#c9b79c', '#a7b8c9', '#c9a7a7', '#b5c9a7', '#d9d0b0'],
  barn: ['#9b3a2a', '#8a3326', '#a8452f'],
  snow: ['#c9d3dc', '#b8c4d0', '#d8dde2', '#a9b6c4'],
  roofs: ['#7a4b3a', '#4a5a6a', '#5a3f3a', '#3f4a3a'],
  redroofs: ['#c26a4a', '#a8573a', '#b9694a', '#8a4a30'],
  darkroofs: ['#3a3f46', '#2f343b', '#46403a'],
  warm: ['#c9b79c', '#a7b8c9', '#c9a7a7', '#b5c9a7', '#d9d0b0', '#b98a5a', '#9fd8d0'],
  ind: ['#6b6f73', '#7a6f5c', '#5f6b73', '#70655a'],
  cont: ['#b5442d', '#2d6fb5', '#d49b2a', '#3a8a5a', '#7a3ab5', '#c2c2c2'],
};
export const NEON = ['#ff4fd8', '#4fe0ff', '#ffe14a', '#7cff4f', '#ff6a3d', '#b36bff'];
export { PAL };

const SHOP = {
  bar: ['SALTY DOG', 'THE LANTERN', 'LAST STOP', 'IRON HORSE', 'RED DOOR', 'THE ANCHOR', 'NIGHT OWL', 'LAST CALL'],
  burger: ['SUNNY DINER', 'ROUTE DINER', 'GRILL & CHILL', 'BURGER BARN', 'LUCKY NOODLE', 'TACO LOCO', 'PIE & COFFEE'],
  mart: ['QUIK-E', 'GENERAL STORE', 'CORNER MARKET', '24/7 MINI', 'PRONTO MART', 'QUICKSTOP'],
  clothes: ['THREADS & CO', 'MAIN ST WEAR', 'URBAN CUT', 'STITCH & CO', 'BOOT BARN'],
};

// Every theme = one of the "identities" the authored world already has.
export const THEMES = {
  prairie: {
    label: 'Prairie', ground: 'GRASS', tree: 'tree', house: PAL.house, roof: PAL.roofs, shop: PAL.warm, tower: PAL.glass, plaza: 'PLAZA',
    names: [['Ash', 'Bram', 'Cor', 'Dun', 'El', 'Fen', 'Gar', 'Hol', 'Iron', 'Jun', 'Kes', 'Lor', 'Mar', 'Nor', 'Oak', 'Red', 'Sil', 'Tor', 'Wyn', 'Gull', 'Stone', 'Clover'], ['ton', 'ford', 'field', 'stead', 'dale', 'ridge', 'view', 'wick', 'mere', 'bury', 'crest', 'gate']],
    streets: ['Harvest', 'County Rd', 'Orchard', 'Furrow', 'Meadow', 'Corn Belt', 'Mill', 'Silo', 'Barley', 'Main St', 'Elm', 'Maple'],
    traffic: ['pickup', 'pickup', 'tractor', 'truck', 'van', 'offroad', 'sedan'], civic: ['SHERIFF', 'COUNTY CLINIC'], shopNames: SHOP,
  },
  west: {
    label: 'Desert', ground: 'DESERT', tree: 'cactus', house: PAL.west, roof: PAL.redroofs, shop: PAL.west, tower: PAL.west, plaza: 'PATH',
    names: [['San', 'Santa', 'Villa', 'El', 'Dos', 'Rio', 'Mesa', 'Cruz', 'Agua', 'Nuevo', 'Los', 'Paso'], ['Verde', 'Blanca', 'Rojo', 'Piedra', 'Cobre', 'Arroyo', 'Seco', 'Hondo', 'Cielo', 'Springs', 'Wells', 'Gulch']],
    streets: ['Route 18', 'Mesquite', 'Cactus', 'Adobe', 'Tumbleweed', 'Sundown', 'Copper', 'Dune', 'Cholla', 'Mission', 'Wagon', 'Arroyo'],
    traffic: ['pickup', 'pickup', 'offroad', 'muscle', 'van', 'truck', 'sedan', 'moto'], civic: ['SHERIFF', 'DESERT CLINIC'],
    shopNames: { ...SHOP, bar: ['THE SALOON', 'BLUE AGAVE', 'DUSTY BOOT', 'RATTLER BAR', 'EL TORO'], burger: ['DUSTY DINER', 'TACO LOCO', 'CHILI QUEEN', 'ROUTE DINER'] },
  },
  timber: {
    label: 'Timber', ground: 'GRASS', tree: 'pine', house: PAL.log, roof: PAL.darkroofs, shop: PAL.log, tower: PAL.glass, plaza: 'PATH',
    names: [['Pine', 'Cedar', 'Elk', 'Bear', 'Timber', 'Raven', 'Spruce', 'Fox', 'Lynx', 'Moose', 'Aspen', 'Birch'], ['Hollow', 'Ridge', 'Falls', 'Lake', 'Camp', 'Crossing', 'Pass', 'Landing', 'Creek', 'Bluff']],
    streets: ['Ridge Rd', 'Timber', 'Lakeview', 'Aspen', 'Cedar', 'Summit', 'Trailhead', 'Spruce', 'Birch', 'Antler'],
    traffic: ['offroad', 'pickup', 'suv', 'pickup', 'van', 'tractor'], civic: ['RANGER STATION', 'FOREST CLINIC'],
    shopNames: { ...SHOP, bar: ['THE ANTLER', 'BEAR CLAW TAVERN', 'LOGGERS REST'], mart: ['TRAILHEAD MART', 'BAIT & TACKLE', 'GENERAL STORE'], burger: ['PANCAKE HOUSE', 'LODGE DINER', 'CAMPFIRE GRILL'] },
  },
  alpine: {
    label: 'Alpine', ground: 'GRASS', tree: 'pine', house: PAL.snow, roof: PAL.darkroofs, shop: PAL.snow, tower: PAL.glass, plaza: 'PLAZA',
    names: [['Sil', 'Fjell', 'Hav', 'Norr', 'Sno', 'Vik', 'Berg', 'Troll', 'Aska', 'Hel', 'Frost', 'Glac'], ['dal', 'berg', 'vik', 'heim', 'stad', 'fjord', 'haven', 'spitz']],
    streets: ['Summit', 'Glacier', 'Avalanche', 'Edelweiss', 'Piste', 'Frost', 'Alpen', 'Chalet', 'Lift', 'Snowline'],
    traffic: ['offroad', 'suv', 'suv', 'pickup', 'van', 'hummer'], civic: ['MOUNTAIN RESCUE', 'ALPINE CLINIC'],
    shopNames: { ...SHOP, bar: ['APRES-SKI', 'THE YETI', 'FIRESIDE'], burger: ['FONDUE HAUS', 'COCOA & CO', 'CHALET CAFE'], clothes: ['SKI & SHRED', 'ALPINE GEAR', 'PARKA SHOP'] },
  },
  bayou: {
    label: 'Bayou', ground: 'GRASS', tree: 'stump', house: PAL.swamp, roof: PAL.roofs, shop: PAL.swamp, tower: PAL.swamp, plaza: 'WOOD',
    names: [['Bayou', 'Cypress', 'Gator', 'Heron', 'Pelican', 'Marais', 'Delta', 'Voodoo', 'Mangrove', 'Egret'], [' Landing', ' Bend', ' Point', 'ville', 'aux', ' Parish', ' Crossing', ' Mire']],
    streets: ['Cypress', 'Gator Alley', 'Mangrove', 'Heron', 'Delta', 'Voodoo', 'Bayou Rd', 'Moss', 'Egret'],
    traffic: ['pickup', 'offroad', 'muscle', 'sedan', 'van', 'cabrio', 'golf'], civic: ['PARISH SHERIFF', 'BAYOU CLINIC'],
    shopNames: { ...SHOP, bar: ['THE GATOR', 'VOODOO LOUNGE', 'LAST RESORT'], burger: ['CAJUN KITCHEN', 'CRAWFISH SHACK', 'BAYOU BITES'], mart: ['BAIT & TACKLE', 'GENERAL STORE'] },
  },
  resort: {
    label: 'Coastal', ground: 'SAND', tree: 'palm', house: PAL.pastel, roof: PAL.redroofs, shop: PAL.pastel, tower: PAL.pastel, plaza: 'PLAZA',
    names: [['Palm', 'Coral', 'Sun', 'Azure', 'Marlin', 'Flamingo', 'Lido', 'Pearl', 'Tropic', 'Mango', 'Opal', 'Pelican'], [' Beach', ' Cove', ' Key', ' Shores', ' Bay', ' Harbor', ' Strand', ' Point']],
    streets: ['Ocean Prom', 'Flamingo', 'Palmetto', 'Coral', 'Biscayne', 'Neon Mile', 'Sunset Strip', 'Marlin', 'Azul', 'Costa', 'Tropic', 'Lido'],
    traffic: ['cabrio', 'cabrio', 'sports', 'supercar', 'limo', 'suv', 'moto', 'taxi', 'sedan', 'golf'], civic: ['COASTAL PD', 'COASTAL MEDICAL'],
    shopNames: { ...SHOP, bar: ['TIKI HUT', 'SALTY DOG', 'THE LIDO', 'BEACH CLUB'], burger: ['BEACH BITES', 'SUNNY DINER', 'SURF & TURF'], clothes: ['SOL WEAR', 'SWIMSUIT CO', 'RESORT WEAR'] },
  },
  metro: {
    label: 'Metro', ground: 'GRASS', tree: 'tree', house: PAL.warm, roof: PAL.darkroofs, shop: PAL.glass, tower: PAL.glass, plaza: 'PLAZA',
    names: [['New ', 'Port ', 'Grand ', 'Fort ', 'Mount ', 'Lake ', 'Saint ', 'North '], ['Aurora', 'Meridian', 'Capital', 'Liberty', 'Hudson', 'Atlas', 'Madison', 'Orion', 'Vega', 'Union', 'Gotham', 'Halcyon']],
    streets: ['Federal', 'Liberty', 'Broadway', 'Wall', 'Union', 'Capitol', 'Madison', 'Gotham', 'Lakeshore', 'Atlas', 'Grand Blvd', 'Market St'],
    traffic: ['sedan', 'taxi', 'taxi', 'taxi', 'suv', 'limo', 'bus', 'van', 'compact', 'sports', 'moto'], civic: ['METRO PD', 'METRO GENERAL'], shopNames: SHOP,
  },
};

// biome → settlement theme
export const THEME_OF_BIOME = { desert: 'west', plains: 'prairie', farm: 'prairie', forest: 'timber', taiga: 'timber', tundra: 'alpine', alpine: 'alpine', marsh: 'bayou', coast: 'resort' };
// biome keys that exist for the wilderness (district = 'x_wild_<biome>')
export const BIOMES = { tundra: 'Frozen Tundra', taiga: 'Taiga', plains: 'Open Plains', farm: 'Farmland', desert: 'Desert Badlands', forest: 'Woodland', marsh: 'Marshland', alpine: 'Highlands', coast: 'Coastline', lake: 'Lakeland', ocean: 'Open Water' };
const BIOME_THEME = { tundra: 'alpine', taiga: 'timber', plains: 'prairie', farm: 'prairie', desert: 'west', forest: 'timber', marsh: 'bayou', alpine: 'alpine', coast: 'resort', lake: 'timber', ocean: 'resort' };

// ----- register the dynamic districts into the shared tables the engine already reads -----
const CLS_DENS = [0.34, 0.55, 0.85, 1.1], CLS_CROWD = [0.2, 0.35, 0.6, 0.9];
export const XDENS = {}, XCROWD = {};
for (const th of Object.keys(THEMES)) for (let c = 0; c < 4; c++) {
  const k = `x_${th}_${CLS[c]}`; XDENS[k] = CLS_DENS[c]; XCROWD[k] = CLS_CROWD[c]; TRAFFIC_BY[k] = THEMES[th].traffic; DISTRICT_NAMES[k] = `${THEMES[th].label} ${CLS_LABEL[c]}`;
}
for (const b of Object.keys(BIOMES)) { const k = 'x_wild_' + b; XDENS[k] = b === 'ocean' ? 0 : b === 'lake' ? 0.02 : 0.15; XCROWD[k] = 0.04; TRAFFIC_BY[k] = THEMES[BIOME_THEME[b]].traffic; DISTRICT_NAMES[k] = BIOMES[b]; }
for (const [k, n, d] of [['x_airstrip', 'Private Airstrip', 0.14], ['x_resort', 'Grand Resort', 0.7], ['x_port', 'Industrial Port', 0.3], ['x_quarry', 'Open-Cast Quarry', 0.08]]) { XDENS[k] = d; XCROWD[k] = 0.1; DISTRICT_NAMES[k] = n; }
TRAFFIC_BY.x_airstrip = ['pickup', 'truck', 'van', 'offroad']; TRAFFIC_BY.x_port = ['truck', 'truck', 'van', 'pickup', 'sedan']; TRAFFIC_BY.x_quarry = ['truck', 'offroad', 'pickup'];
export const xCrowd = (d) => XCROWD[d];

export const nameFor = (theme, rng) => { const [A, B] = THEMES[theme].names; return A[Math.floor(rng() * A.length)] + (theme === 'west' ? ' ' : '') + B[Math.floor(rng() * B.length)]; };
export const PROVINCE_ADJ = ['Amber', 'Ash', 'Cobalt', 'Hollow', 'Iron', 'Jade', 'Lone', 'Misty', 'Pale', 'Quiet', 'Raven', 'Scarlet', 'Silent', 'Tawny', 'Velvet', 'Wild', 'Golden', 'Broken', 'Crimson', 'Ivory'];
export const PROVINCE_NOUN = {
  tundra: ['Tundra', 'Wastes', 'Barrens'], taiga: ['Pines', 'Timberland', 'Hollow'], plains: ['Prairie', 'Downs', 'Plains'], farm: ['Fields', 'Valley', 'Acres'],
  desert: ['Badlands', 'Flats', 'Dunes', 'Mesa'], forest: ['Woods', 'Forest', 'Glen'], marsh: ['Fens', 'Mire', 'Delta', 'Bayou'], alpine: ['Peaks', 'Highlands', 'Range', 'Crown'],
  coast: ['Coast', 'Shore', 'Strand'], lake: ['Lakes', 'Reach', 'Waters'], ocean: ['Sea', 'Deep', 'Channel'],
};
