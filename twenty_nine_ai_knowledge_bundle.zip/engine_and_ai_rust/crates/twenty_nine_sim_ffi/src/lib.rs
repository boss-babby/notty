//! Zero-allocation C-ABI vectorized 29 card-game self-play simulator for PyTorch GPU training on Kaggle.
//! Exposes full trick-by-trick sequence tensors [N, 32, 16], 128-dim board tensors [N, 128],
//! 33-dim legal masks [N, 33] (32 canonical cards + ShowTrump), and built-in Frozen Pro RL v3.2 evaluation!

use std::slice;
use twenty_nine_core::rl_v3::{
    choose_v3_fast_play, extract_v3_bid_features, extract_v3_state_features,
    fast_heuristic_action, FastRng, FastState, ProBidNetV3, ProValueNetV3, V3_BID_IN, V3_IN,
};

pub const SEQ_MAX: usize = 32;
pub const SEQ_DIM: usize = 16; // [4 rel-seat one-hot, 4 canonical-suit one-hot, 8 rank one-hot]
pub const ACT_DIM: usize = 33; // 0..32 canonical cards, 32 = ShowTrump

#[derive(Clone, Copy)]
struct PlayRecord {
    seat: u8,
    card: u8,
}

struct SingleEnv {
    st: FastState,
    hist: [PlayRecord; SEQ_MAX],
    hist_len: usize,
    hand_id: u64,
    bid_feat: [f32; V3_BID_IN],
    rng: FastRng,
    v5_team: usize, // in eval modes: which team (0 or 1) is controlled by PyTorch GPU agent
    pair_idx: u64,
    saved_deck: [u8; 32],
}

pub struct SimBatch {
    envs: Vec<SingleEnv>,
    opp_mode: u32, // 0 = Pure Self-Play (all 4 seats PyTorch), 1 = Duplicate Eval vs Frozen v3.2, 2 = vs Heuristic
    opp_v32_samples: usize,
    v3_val: ProValueNetV3,
    v3_bid: ProBidNetV3,
}

#[inline]
fn shuffle_no_4j(rng: &mut FastRng) -> [u8; 32] {
    loop {
        let d = rng.shuffle_deck();
        let mut bad = false;
        for s in 0..4 {
            let mut jc = 0u8;
            for k in 0..4 {
                if (d[s * 4 + k] & 7) == 0 { jc += 1; }
                if (d[16 + s * 4 + k] & 7) == 0 { jc += 1; }
            }
            if jc == 4 { bad = true; break; }
        }
        if !bad { return d; }
    }
}

#[inline]
fn choose_trump_fast(hand_mask: u32, is_opening_leader: bool) -> (i8, bool) {
    let mut best_suit = 0i8;
    let mut best_rev = false;
    let mut best_sc = -100.0_f32;
    let tot_j = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 1) != 0).count() as f32;
    let tot_9 = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 2) != 0).count() as f32;
    let tot_7 = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 128) != 0).count() as f32;
    let tot_8 = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 64) != 0).count() as f32;
    let max_len = (0..4u8).map(|s| ((hand_mask >> (s * 8)) & 0xFF).count_ones()).max().unwrap_or(0);

    if max_len <= 2 && (tot_j >= 3.0 || (tot_j >= 2.0 && tot_9 >= 1.0)) { return (-1, false); }
    if max_len <= 2 && tot_7 >= 3.0 && tot_j == 0.0 && tot_9 == 0.0 { return (-1, true); }

    for s in 0..4u8 {
        let sm = (hand_mask >> (s * 8)) & 0xFF;
        let len = sm.count_ones() as f32;
        if len == 0.0 { continue; }
        let mut s_str = 0.0_f32;
        for r in 0..8u8 { if (sm & (1 << r)) != 0 { s_str += (7 - r) as f32; } }
        let has_m = (sm & 48) == 48;
        let straight_sc = len * 5.0 + s_str * 1.4 + if has_m { 6.0 } else { 0.0 };
        if straight_sc > best_sc { best_sc = straight_sc; best_suit = s as i8; best_rev = false; }

        let has_7 = (sm & 128) != 0;
        let has_8 = (sm & 64) != 0;
        if (has_7 || has_8) && (len >= 2.0 || (has_7 && (tot_7 + tot_8) >= 2.0)) {
            let has_78 = has_7 && has_8;
            let side_78 = (tot_7 + tot_8) - if has_7 { 1.0 } else { 0.0 } - if has_8 { 1.0 } else { 0.0 };
            let nt_j9 = (tot_j + tot_9) - if (sm & 1) != 0 { 1.0 } else { 0.0 } - if (sm & 2) != 0 { 1.0 } else { 0.0 };
            let pred_edge = -1.6387
                + if is_opening_leader { 1.5190 } else { 0.0 }
                + len * 0.8454 + if has_7 { 0.5625 } else { 0.0 } + if has_8 { 0.1186 } else { 0.0 }
                + if has_78 { 0.6811 } else { 0.0 } + side_78 * 0.7265
                - tot_j * 1.5052 - tot_9 * 1.4561 + nt_j9 * 1.2706;
            if pred_edge > 0.75 {
                let rev_sc = straight_sc + pred_edge * 3.5;
                if rev_sc > best_sc { best_sc = rev_sc; best_suit = s as i8; best_rev = true; }
            }
        }
    }
    (best_suit, best_rev)
}

impl SingleEnv {
    fn reset(&mut self, opp_mode: u32, v3_bid: &ProBidNetV3) {
        self.hand_id += 1;
        // In eval mode (opp_mode >= 1), play each deal TWICE swapping Team 0 / Team 1 for exact duplicate-deal fairness!
        let deck = if opp_mode >= 1 && (self.hand_id & 1) == 0 {
            self.v5_team = 1;
            self.saved_deck
        } else {
            self.v5_team = 0;
            self.pair_idx += 1;
            let d = shuffle_no_4j(&mut self.rng);
            self.saved_deck = d;
            d
        };

        let dealer = (self.pair_idx & 3) as u8;
        let first_bidder = (dealer + 1) & 3;
        let mut h4 = [0u32; 4];
        for s in 0..4 {
            for k in 0..4 { h4[s] |= 1u32 << deck[s * 4 + k]; }
        }

        let mut passed = [false; 4];
        let mut high_bid = 0u8;
        let mut high_bidder = dealer;
        let mut turn = first_bidder;
        let mut passed_cnt = 0u8;
        let mut win_bfeat = [0.0_f32; V3_BID_IN];

        for _ in 0..16 {
            let next_b = if high_bid == 0 { 16 } else { high_bid + 1 };
            let partner_win = high_bid > 0 && FastState::team_of(high_bidder) == FastState::team_of(turn);
            let is_lead = turn == first_bidder;
            let bfeat = extract_v3_bid_features(h4[turn as usize], is_lead, true, high_bid, partner_win, passed_cnt);
            let est = v3_bid.predict_expected_pts(&bfeat);
            let has_kq = (0..4u8).any(|s| ((h4[turn as usize] >> (s * 8)) & 48) == 48);
            let jitter = if opp_mode == 0 { (self.rng.next_f32() - 0.5) * 0.8 } else { 0.0 };
            let max_w = ((est - 0.25 + if has_kq { 0.75 } else { 0.0 } + jitter).round() as u8).clamp(15, 28);

            let will_bid = next_b <= 28 && next_b <= max_w && !(partner_win && max_w < next_b + 2);
            if will_bid {
                high_bid = next_b;
                high_bidder = turn;
                win_bfeat = bfeat;
                if passed_cnt >= 3 || high_bid == 28 { break; }
            } else {
                passed[turn as usize] = true;
                passed_cnt += 1;
                if passed_cnt == 3 {
                    if high_bid == 0 {
                        high_bid = 16;
                        high_bidder = (0..4u8).find(|&s| !passed[s as usize]).unwrap_or(dealer);
                        win_bfeat = extract_v3_bid_features(
                            h4[high_bidder as usize], high_bidder == first_bidder, true, 0, false, 3,
                        );
                    }
                    break;
                }
            }
            for step in 1..=4u8 {
                let nxt = (turn + step) & 3;
                if !passed[nxt as usize] { turn = nxt; break; }
            }
        }

        let (trump_suit, rev_en) = choose_trump_fast(h4[high_bidder as usize], high_bidder == first_bidder);
        let mut hands = h4;
        for s in 0..4 {
            for k in 0..4 { hands[s] |= 1u32 << deck[16 + s * 4 + k]; }
        }
        self.st = FastState {
            hands, played: 0, voids: [0; 4], failed_beat: [0; 4], dealer, bidder: high_bidder,
            bid: high_bid, eff_bid: high_bid, stakes: 1, trump_suit,
            reverse_enabled: rev_en, trump_exposed: false,
            exposed_at_idx: -1, reverse_at_idx: -1, must_play_trump: -1,
            marriage_done: false, seventh_card: -1,
            trick_cards: [0; 4], trick_seats: [0; 4], trick_len: 0,
            leader: first_bidder, turn: first_bidder, tricks_done: 0, pts: [0, 0],
        };
        self.hist_len = 0;
        self.bid_feat = win_bfeat;
    }

    #[inline]
    fn apply_play(&mut self, sh: bool, card: u8) {
        let s = self.st.turn;
        self.st.check_auto_marriage(s);
        if sh && self.st.can_show_trump(s) {
            self.st.expose_trump(s);
            self.st.check_auto_marriage(s);
        } else {
            if self.hist_len < SEQ_MAX {
                self.hist[self.hist_len] = PlayRecord { seat: s, card };
                self.hist_len += 1;
            }
            self.st.play_card(card);
        }
    }

    fn advance_opponents(&mut self, opp_mode: u32, v3_val: &ProValueNetV3, samples: usize) {
        if opp_mode == 0 {
            return;
        }
        while self.st.tricks_done < 8 && FastState::team_of(self.st.turn) != self.v5_team {
            let s = self.st.turn;
            self.st.check_auto_marriage(s);
            let (sh, c) = if opp_mode == 1 {
                choose_v3_fast_play(&self.st, v3_val, samples, true, true, &mut self.rng)
            } else {
                fast_heuristic_action(&self.st)
            };
            self.apply_play(sh, c);
        }
    }
}

#[no_mangle]
pub extern "C" fn sim_create(n_envs: u32, seed: u64, opp_mode: u32) -> *mut SimBatch {
    let v3_val = ProValueNetV3::from_embedded();
    let v3_bid = ProBidNetV3::from_embedded();
    let mut envs = Vec::with_capacity(n_envs as usize);
    for i in 0..(n_envs as usize) {
        let mut e = SingleEnv {
            st: FastState {
                hands: [0; 4], played: 0, voids: [0; 4], failed_beat: [0; 4],
                dealer: 0, bidder: 0, bid: 16, eff_bid: 16, stakes: 1, trump_suit: 0,
                reverse_enabled: false, trump_exposed: false, exposed_at_idx: -1,
                reverse_at_idx: -1, must_play_trump: -1, marriage_done: false,
                seventh_card: -1, trick_cards: [0; 4], trick_seats: [0; 4],
                trick_len: 0, leader: 1, turn: 1, tricks_done: 0, pts: [0, 0],
            },
            hist: [PlayRecord { seat: 0, card: 0 }; SEQ_MAX],
            hist_len: 0,
            hand_id: 0,
            bid_feat: [0.0; V3_BID_IN],
            rng: FastRng::new(seed + (i as u64) * 1000033 + 17),
            v5_team: 0,
            pair_idx: i as u64,
            saved_deck: [0; 32],
        };
        e.reset(opp_mode, &v3_bid);
        e.advance_opponents(opp_mode, &v3_val, 4);
        if e.st.tricks_done >= 8 {
            e.reset(opp_mode, &v3_bid);
            e.advance_opponents(opp_mode, &v3_val, 4);
        }
        envs.push(e);
    }
    Box::into_raw(Box::new(SimBatch {
        envs,
        opp_mode,
        opp_v32_samples: 4,
        v3_val,
        v3_bid,
    }))
}

#[no_mangle]
pub unsafe extern "C" fn sim_free(ptr: *mut SimBatch) {
    if !ptr.is_null() {
        drop(Box::from_raw(ptr));
    }
}

#[no_mangle]
pub unsafe extern "C" fn sim_set_opp_v32_samples(ptr: *mut SimBatch, samples: u32) {
    let b = &mut *ptr;
    b.opp_v32_samples = (samples as usize).max(1);
}

#[no_mangle]
pub unsafe extern "C" fn sim_get_obs(
    ptr: *mut SimBatch,
    out_board: *mut f32,   // [N, 128]
    out_seq: *mut f32,     // [N, 32, 16]
    out_seq_len: *mut i32, // [N]
    out_legal: *mut f32,   // [N, 33]
    out_team: *mut i32,    // [N] (0 or 1)
    out_hand_id: *mut u64, // [N]
) {
    let b = &mut *ptr;
    let n = b.envs.len();
    let board = slice::from_raw_parts_mut(out_board, n * V3_IN);
    let seq = slice::from_raw_parts_mut(out_seq, n * SEQ_MAX * SEQ_DIM);
    let seq_len = slice::from_raw_parts_mut(out_seq_len, n);
    let legal = slice::from_raw_parts_mut(out_legal, n * ACT_DIM);
    let team = slice::from_raw_parts_mut(out_team, n);
    let hand_id = slice::from_raw_parts_mut(out_hand_id, n);

    for (i, e) in b.envs.iter().enumerate() {
        let seat = e.st.turn;
        let known_t = if e.st.trump_exposed || (seat == e.st.bidder && e.st.seventh_card < 0) { e.st.trump_suit } else { -1 };
        let suit_shift: u8 = if known_t >= 0 { known_t as u8 } else { 0 };

        // 1. 128-dim board
        let bf = extract_v3_state_features(&e.st, seat);
        board[i * V3_IN..(i + 1) * V3_IN].copy_from_slice(&bf);

        // 2. Trick-by-trick sequence [32, 16]
        let sbase = i * SEQ_MAX * SEQ_DIM;
        seq[sbase..sbase + SEQ_MAX * SEQ_DIM].fill(0.0);
        for t in 0..e.hist_len {
            let rec = e.hist[t];
            let rel = ((rec.seat + 4 - seat) & 3) as usize;
            let cs = (((rec.card >> 3) + 4 - suit_shift) & 3) as usize;
            let r = (rec.card & 7) as usize;
            let off = sbase + t * SEQ_DIM;
            seq[off + rel] = 1.0;
            seq[off + 4 + cs] = 1.0;
            seq[off + 8 + r] = 1.0;
        }
        seq_len[i] = e.hist_len as i32;

        // 3. 33-dim canonical legal mask
        let lbase = i * ACT_DIM;
        legal[lbase..lbase + ACT_DIM].fill(0.0);
        let mut lm = e.st.legal_mask(seat);
        while lm != 0 {
            let c = lm.trailing_zeros() as u8;
            lm &= lm - 1;
            let cs = (((c >> 3) + 4 - suit_shift) & 3) as usize;
            let ci = (cs << 3) | (c & 7) as usize;
            legal[lbase + ci] = 1.0;
        }
        if e.st.can_show_trump(seat) {
            legal[lbase + 32] = 1.0;
        }

        team[i] = FastState::team_of(seat) as i32;
        hand_id[i] = ((i as u64) << 40) | (e.hand_id & 0xFF_FFFF_FFFF);
    }
}

#[no_mangle]
pub unsafe extern "C" fn sim_step(
    ptr: *mut SimBatch,
    actions: *const i32,     // [N] canonical action 0..32 (32 = ShowTrump)
    out_done: *mut i32,      // [N] 1 if hand finished
    out_win_team: *mut i32,  // [N] winning team (0 or 1)
    out_v5_set_pts: *mut i32,// [N] set points for v5_team (or team 0 in self-play)
    out_bid_pts: *mut f32,   // [N] bidder team card points (0..28)
    out_bid_feat: *mut f32,  // [N, 32]
) {
    let b = &mut *ptr;
    let n = b.envs.len();
    let acts = slice::from_raw_parts(actions, n);
    let done = slice::from_raw_parts_mut(out_done, n);
    let win_team = slice::from_raw_parts_mut(out_win_team, n);
    let v5_sp = slice::from_raw_parts_mut(out_v5_set_pts, n);
    let bid_pts = slice::from_raw_parts_mut(out_bid_pts, n);
    let bid_feat = slice::from_raw_parts_mut(out_bid_feat, n * V3_BID_IN);

    let opp_mode = b.opp_mode;
    let samples = b.opp_v32_samples;
    let v3_val = &b.v3_val;
    let v3_bid = &b.v3_bid;

    for (i, e) in b.envs.iter_mut().enumerate() {
        let seat = e.st.turn;
        let known_t = if e.st.trump_exposed || (seat == e.st.bidder && e.st.seventh_card < 0) { e.st.trump_suit } else { -1 };
        let suit_shift: u8 = if known_t >= 0 { known_t as u8 } else { 0 };

        let act = acts[i];
        if act == 32 && e.st.can_show_trump(seat) {
            e.apply_play(true, 0);
        } else {
            let cs = ((act as u8) >> 3) & 3;
            let raw_s = (cs + suit_shift) & 3;
            let raw_c = (raw_s << 3) | ((act as u8) & 7);
            let lm = e.st.legal_mask(seat);
            let chosen = if (lm & (1u32 << raw_c)) != 0 {
                raw_c
            } else {
                lm.trailing_zeros() as u8
            };
            e.apply_play(false, chosen);
        }

        // Advance opponent seats if in eval mode
        e.advance_opponents(opp_mode, v3_val, samples);

        if e.st.tricks_done >= 8 {
            let bt = FastState::team_of(e.st.bidder);
            let bt_won = e.st.bidding_team_won();
            let wt = if bt_won { bt } else { 1 - bt };
            done[i] = 1;
            win_team[i] = wt as i32;
            let target_team = if opp_mode >= 1 { e.v5_team } else { 0 };
            v5_sp[i] = e.st.set_points_for_team(target_team);
            bid_pts[i] = e.st.pts[bt] as f32;
            bid_feat[i * V3_BID_IN..(i + 1) * V3_BID_IN].copy_from_slice(&e.bid_feat);

            // Auto-reset to next hand!
            e.reset(opp_mode, v3_bid);
            e.advance_opponents(opp_mode, v3_val, samples);
            if e.st.tricks_done >= 8 {
                e.reset(opp_mode, v3_bid);
                e.advance_opponents(opp_mode, v3_val, samples);
            }
        } else {
            done[i] = 0;
            win_team[i] = -1;
            v5_sp[i] = 0;
            bid_pts[i] = 0.0;
        }
    }
}

// ============================================================================
// Stage 2 FFI Extensions: Exact Contract Playout + ProBidNetV3 Baseline Anchor
// ============================================================================

/// Load N pre-decided hands + contracts (from Stage 2 Auction/Trump/Double nets)
/// directly into `SimBatch` for exact 8-trick playout via frozen Stage 1 `ProQNetV55`.
#[no_mangle]
pub unsafe extern "C" fn sim_load_contracts(
    ptr: *mut SimBatch,
    hands_mask: *const u32,    // [N * 4] 8-card hand bitmasks (seat 0..3)
    dealers: *const u8,        // [N]
    bidders: *const u8,        // [N]
    bids: *const u8,           // [N] 16..28
    trump_suits: *const i8,    // [N] 0..3 or -1 (NoTrump)
    reverse_flags: *const u8,  // [N] 0 or 1
    seventh_cards: *const i8,  // [N] 0..31 if 7th-card trump, else -1
    stakes: *const u8,         // [N] 1=Normal, 2=Doubled, 4=Redoubled
) {
    let b = &mut *ptr;
    let n = b.envs.len();
    let hm = slice::from_raw_parts(hands_mask, n * 4);
    let dl = slice::from_raw_parts(dealers, n);
    let bd = slice::from_raw_parts(bidders, n);
    let ba = slice::from_raw_parts(bids, n);
    let ts = slice::from_raw_parts(trump_suits, n);
    let rv = slice::from_raw_parts(reverse_flags, n);
    let sc = slice::from_raw_parts(seventh_cards, n);
    let st = slice::from_raw_parts(stakes, n);

    for (i, e) in b.envs.iter_mut().enumerate() {
        let mut hands = [hm[i * 4], hm[i * 4 + 1], hm[i * 4 + 2], hm[i * 4 + 3]];
        let dealer = dl[i] & 3;
        let bidder = bd[i] & 3;
        let first_leader = (dealer + 1) & 3;
        let bid = ba[i].clamp(16, 28);
        let seventh = sc[i];
        let mut trump_suit = ts[i];

        if seventh >= 0 && seventh < 32 {
            // Hold 7th card face-down until trump exposure (matches FastState::expose_trump)
            hands[bidder as usize] &= !(1u32 << (seventh as u8));
            trump_suit = (seventh >> 3) as i8;
        }

        e.hand_id += 1;
        e.hist_len = 0;
        e.st = FastState {
            hands,
            played: 0,
            voids: [0; 4],
            failed_beat: [0; 4],
            dealer,
            bidder,
            bid,
            eff_bid: bid,
            stakes: st[i].max(1),
            trump_suit,
            reverse_enabled: rv[i] != 0,
            trump_exposed: false,
            exposed_at_idx: -1,
            reverse_at_idx: -1,
            must_play_trump: -1,
            marriage_done: false,
            seventh_card: seventh,
            trick_cards: [0; 4],
            trick_seats: [0; 4],
            trick_len: 0,
            leader: first_leader,
            turn: first_leader,
            tricks_done: 0,
            pts: [0, 0],
        };
    }
}

/// Step N Stage 2 playout environments WITHOUT auto-resetting completed hands.
/// Returns `out_done[i] == 1` once env `i` finishes all 8 tricks, with exact
/// `out_bid_team_sp[i]` (`FastState::set_points_for_team(bid_team)`) and `out_bid_pts[i]`.
#[no_mangle]
pub unsafe extern "C" fn sim_step_playout(
    ptr: *mut SimBatch,
    actions: *const i32,         // [N] canonical action 0..32 (32 = ShowTrump)
    out_done: *mut i32,          // [N] 1 if finished
    out_bid_team_sp: *mut i32,   // [N] exact set points for bidding team
    out_bid_pts: *mut f32,       // [N] bidder team card points
) {
    let b = &mut *ptr;
    let n = b.envs.len();
    let acts = slice::from_raw_parts(actions, n);
    let done = slice::from_raw_parts_mut(out_done, n);
    let bt_sp = slice::from_raw_parts_mut(out_bid_team_sp, n);
    let bid_pts = slice::from_raw_parts_mut(out_bid_pts, n);

    for (i, e) in b.envs.iter_mut().enumerate() {
        if e.st.tricks_done >= 8 {
            let bt = FastState::team_of(e.st.bidder);
            done[i] = 1;
            bt_sp[i] = e.st.set_points_for_team(bt);
            bid_pts[i] = e.st.pts[bt] as f32;
            continue;
        }

        let seat = e.st.turn;
        // Safety for 7th-card trump if bidder reaches last card without prior exposure
        if e.st.seventh_card >= 0 && e.st.hands[seat as usize] == 0 && seat == e.st.bidder {
            e.st.expose_trump(seat);
        }

        let known_t = if e.st.trump_exposed || (seat == e.st.bidder && e.st.seventh_card < 0) {
            e.st.trump_suit
        } else {
            -1
        };
        let suit_shift: u8 = if known_t >= 0 { known_t as u8 } else { 0 };

        let act = acts[i];
        if act == 32 && e.st.can_show_trump(seat) {
            e.apply_play(true, 0);
        } else {
            let cs = ((act as u8) >> 3) & 3;
            let raw_s = (cs + suit_shift) & 3;
            let raw_c = (raw_s << 3) | ((act as u8) & 7);
            let lm = e.st.legal_mask(seat);
            let chosen = if (lm & (1u32 << raw_c)) != 0 {
                raw_c
            } else {
                lm.trailing_zeros() as u8
            };
            e.apply_play(false, chosen);
        }

        if e.st.tricks_done >= 8 {
            let bt = FastState::team_of(e.st.bidder);
            done[i] = 1;
            bt_sp[i] = e.st.set_points_for_team(bt);
            bid_pts[i] = e.st.pts[bt] as f32;
        } else {
            done[i] = 0;
            bt_sp[i] = 0;
            bid_pts[i] = 0.0;
        }
    }
}

/// Exact production ProBidNetV3 + choose_trump_fast baseline for Stage 2 opponent anchor & eval.
/// Outputs:
///   - `out_bid_act[i]`: 0 = Pass, 1..13 = Bid 16..28
///   - `out_trump_act[i]`: 0..3 = Suit Straight, 4..7 = Suit Reverse, 8 = NT Straight, 9 = NT Reverse, 10 = 7th Card
#[no_mangle]
pub unsafe extern "C" fn sim_v3_baseline_actions(
    ptr: *mut SimBatch,
    n_items: u32,
    h4_masks: *const u32,
    is_lead: *const u8,
    allow_rev: *const u8,
    cur_high: *const u8,
    partner_win: *const u8,
    passed_cnt: *const u8,
    force_min: *const u8,
    out_bid_act: *mut i32,
    out_trump_act: *mut i32,
) {
    let b = &*ptr;
    let n = n_items as usize;
    let hm = slice::from_raw_parts(h4_masks, n);
    let il = slice::from_raw_parts(is_lead, n);
    let ar = slice::from_raw_parts(allow_rev, n);
    let ch = slice::from_raw_parts(cur_high, n);
    let pw = slice::from_raw_parts(partner_win, n);
    let pc = slice::from_raw_parts(passed_cnt, n);
    let fm = slice::from_raw_parts(force_min, n);
    let ob = slice::from_raw_parts_mut(out_bid_act, n);
    let ot = slice::from_raw_parts_mut(out_trump_act, n);

    for i in 0..n {
        let mask = hm[i];
        let lead = il[i] != 0;
        let rev_ok = ar[i] != 0;
        let high = ch[i];
        let pwin = pw[i] != 0;
        let pcnt = pc[i];
        let next_b = if high == 0 { 16 } else { high + 1 };

        let bfeat = extract_v3_bid_features(mask, lead, rev_ok, high, pwin, pcnt);
        let est = b.v3_bid.predict_expected_pts(&bfeat);
        let has_kq = (0..4u8).any(|s| ((mask >> (s * 8)) & 48) == 48);
        let max_w = ((est - 0.25 + if has_kq { 0.75 } else { 0.0 }).round() as u8).clamp(15, 28);

        if fm[i] != 0 {
            ob[i] = (next_b.min(28) - 16 + 1) as i32;
        } else if next_b <= 28 && next_b <= max_w && !(pwin && max_w < next_b + 2) {
            ob[i] = (next_b - 16 + 1) as i32;
        } else {
            ob[i] = 0;
        }

        // Exact 11-action trump baseline matching bot.rs + choose_trump_fast
        let max_len = (0..4u8).map(|s| ((mask >> (s * 8)) & 0xFF).count_ones()).max().unwrap_or(0);
        let tot_j = (0..4u8).filter(|&s| ((mask >> (s * 8)) & 1) != 0).count();
        let tot_9 = (0..4u8).filter(|&s| ((mask >> (s * 8)) & 2) != 0).count();
        let mut pts = 0u8;
        let mut tmp = mask;
        while tmp != 0 {
            let c = tmp.trailing_zeros() as u8;
            tmp &= tmp - 1;
            pts += twenty_nine_core::rl_v3::card_pts(c);
        }
        let has_rev_pair = (0..4u8).any(|s| ((mask >> (s * 8)) & 192) == 192);
        if high <= 16 && max_len <= 2 && tot_j == 0 && tot_9 == 0 && pts <= 2 && !has_rev_pair {
            ot[i] = 10; // 7th-card trump gamble
        } else {
            let (ts, rev) = choose_trump_fast(mask, lead);
            ot[i] = if ts < 0 {
                if rev { 9 } else { 8 }
            } else if rev {
                4 + ts as i32
            } else {
                ts as i32
            };
        }
    }
}
