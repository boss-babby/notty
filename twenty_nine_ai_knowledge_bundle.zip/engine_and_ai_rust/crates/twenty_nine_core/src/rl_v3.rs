//! Pro RL v3: High-speed bitboard FastState, 128-dim exact-card ProValueNetV3,
//! 32-dim opening-lead-aware ProBidNetV3, 4-trick exact Alpha-Beta endgame solver,
//! pre-exposure + Show-Trump RL PIMC, and multi-generation 1M+ hand self-play trainer.

use crate::cards::{Card, Rank, Suit};
use crate::engine::GameEngine;
use crate::protocol::{StakesLevel, TrumpMode};

// Card encoding: 0..32 where suit = c >> 3 (0=Spades,1=Hearts,2=Diamonds,3=Clubs),
// rank_idx = c & 7 (0=J, 1=9, 2=A, 3=10, 4=K, 5=Q, 6=8, 7=7).
pub const CARD_PTS: [u8; 8] = [3, 2, 1, 1, 0, 0, 0, 0];

#[inline(always)]
pub fn card_to_u8(c: Card) -> u8 {
    let s = match c.suit {
        Suit::Spades => 0u8,
        Suit::Hearts => 1u8,
        Suit::Diamonds => 2u8,
        Suit::Clubs => 3u8,
    };
    let r = match c.rank {
        Rank::Jack => 0u8,
        Rank::Nine => 1u8,
        Rank::Ace => 2u8,
        Rank::Ten => 3u8,
        Rank::King => 4u8,
        Rank::Queen => 5u8,
        Rank::Eight => 6u8,
        Rank::Seven => 7u8,
    };
    (s << 3) | r
}

#[inline(always)]
pub fn u8_to_card(id: u8) -> Card {
    let suit = match id >> 3 {
        0 => Suit::Spades,
        1 => Suit::Hearts,
        2 => Suit::Diamonds,
        _ => Suit::Clubs,
    };
    let rank = match id & 7 {
        0 => Rank::Jack,
        1 => Rank::Nine,
        2 => Rank::Ace,
        3 => Rank::Ten,
        4 => Rank::King,
        5 => Rank::Queen,
        6 => Rank::Eight,
        _ => Rank::Seven,
    };
    Card::new(rank, suit)
}

#[inline(always)]
pub fn card_pts(c: u8) -> u8 {
    CARD_PTS[(c & 7) as usize]
}

#[inline(always)]
pub fn card_strength(c: u8, reverse: bool) -> u8 {
    let r = c & 7;
    if reverse { r } else { 7 - r }
}

/// Fast xorshift64* PRNG (zero allocation, ~1 ns/call).
#[derive(Clone, Copy)]
pub struct FastRng(pub u64);

impl FastRng {
    #[inline(always)]
    pub fn new(seed: u64) -> Self {
        Self(seed ^ 0x9E3779B97F4A7C15)
    }
    #[inline(always)]
    pub fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.0 = x;
        x.wrapping_mul(0x2545F4914F6CDD1D)
    }
    #[inline(always)]
    pub fn next_f32(&mut self) -> f32 {
        ((self.next_u64() >> 40) as f32) * (1.0 / 16777216.0)
    }
    #[inline(always)]
    pub fn shuffle_deck(&mut self) -> [u8; 32] {
        let mut d = [0u8; 32];
        for i in 0..32 {
            d[i] = i as u8;
        }
        for i in (1..32).rev() {
            let j = (self.next_u64() as usize) % (i + 1);
            d.swap(i, j);
        }
        d
    }
}

/// Zero-allocation stack-only 29 hand state for blazing-fast self-play, PIMC, and 4-trick Alpha-Beta.
#[derive(Clone, Copy)]
pub struct FastState {
    pub hands: [u32; 4],
    pub played: u32,
    pub voids: [u8; 4], // bitmask of 4 suits known void per seat
    pub failed_beat: [u8; 4], // bitmask of 4 suits where seat failed to beat a winning opp high card
    pub dealer: u8,
    pub bidder: u8,
    pub bid: u8,
    pub eff_bid: u8,
    pub stakes: u8, // 1=Normal, 2=Doubled, 4=Redoubled
    pub trump_suit: i8, // 0..3 or -1 (NoTrump)
    pub reverse_enabled: bool,
    pub trump_exposed: bool,
    pub exposed_at_idx: i8, // -1 if not exposed mid-trick, else 0..3
    pub reverse_at_idx: i8, // -1 if not activated mid-trick, else 0..3
    pub must_play_trump: i8, // seat or -1
    pub marriage_done: bool,
    pub seventh_card: i8, // card id 0..31 held face-down by bidder, or -1
    pub trick_cards: [u8; 4],
    pub trick_seats: [u8; 4],
    pub trick_len: u8,
    pub leader: u8,
    pub turn: u8,
    pub tricks_done: u8,
    pub pts: [u8; 2], // [TeamA (0,2), TeamB (1,3)]
}

impl FastState {
    #[inline(always)]
    pub fn team_of(seat: u8) -> usize {
        (seat & 1) as usize
    }

    pub fn from_engine(e: &GameEngine) -> Self {
        let mut hands = [0u32; 4];
        for s in 0..4 {
            for &c in &e.hands[s] {
                hands[s] |= 1u32 << card_to_u8(c);
            }
        }
        let mut played = 0u32;
        let mut voids = [0u8; 4];
        let mut failed_beat = [0u8; 4];
        let rev_now = e.is_reverse_active();
        for tr in &e.completed_tricks {
            let led = tr.plays.first().map(|p| card_to_u8(p.card) >> 3).unwrap_or(0);
            let mut best_str = tr.plays.first().map(|p| card_strength(card_to_u8(p.card), rev_now)).unwrap_or(0);
            let mut best_seat = tr.plays.first().map(|p| p.seat as u8).unwrap_or(0);
            let mut tpts = 0u8;
            for (idx, p) in tr.plays.iter().enumerate() {
                let cid = card_to_u8(p.card);
                played |= 1u32 << cid;
                if (cid >> 3) != led {
                    voids[p.seat] |= 1u8 << led;
                } else if idx > 0 {
                    let cstr = card_strength(cid, rev_now);
                    if cstr > best_str {
                        best_str = cstr;
                        best_seat = p.seat as u8;
                    } else if Self::team_of(best_seat) != Self::team_of(p.seat as u8) && (tpts >= 2 || best_str >= 5) {
                        failed_beat[p.seat] |= 1u8 << led;
                    }
                }
                tpts += card_pts(cid);
            }
        }
        let mut trick_cards = [0u8; 4];
        let mut trick_seats = [0u8; 4];
        let cur_led = e.current_trick.first().map(|p| card_to_u8(p.card) >> 3).unwrap_or(0);
        for (i, p) in e.current_trick.iter().enumerate().take(4) {
            let cid = card_to_u8(p.card);
            trick_cards[i] = cid;
            trick_seats[i] = p.seat as u8;
            played |= 1u32 << cid;
            if i > 0 && (cid >> 3) != cur_led {
                voids[p.seat] |= 1u8 << cur_led;
            }
        }
        let trump_suit = match e.trump_mode() {
            Some(TrumpMode::NoTrump) => -1,
            _ => e.hidden_trump().map(|s| match s {
                Suit::Spades => 0,
                Suit::Hearts => 1,
                Suit::Diamonds => 2,
                Suit::Clubs => 3,
            }).unwrap_or(-1),
        };
        let stakes = match e.stakes {
            StakesLevel::Normal => 1,
            StakesLevel::Doubled => 2,
            StakesLevel::Redoubled => 4,
        };
        let seventh_card = e.seventh_card_held().map(|c| card_to_u8(c) as i8).unwrap_or(-1);
        let eff_bid = e.effective_bid().unwrap_or(e.current_high_bid.unwrap_or(16));
        Self {
            hands,
            played,
            voids,
            failed_beat,
            dealer: e.dealer as u8,
            bidder: e.current_high_bidder.unwrap_or(0) as u8,
            bid: e.current_high_bid.unwrap_or(16),
            eff_bid,
            stakes,
            trump_suit,
            reverse_enabled: e.is_reverse_enabled_for_hand(),
            trump_exposed: e.trump_exposed,
            exposed_at_idx: e.trump_exposed_at_play_index.map(|x| x as i8).unwrap_or(-1),
            reverse_at_idx: e.reverse_activated_at_play_index.map(|x| x as i8).unwrap_or(-1),
            must_play_trump: e.must_play_trump_seat.map(|x| x as i8).unwrap_or(-1),
            marriage_done: e.marriage_declared_by.is_some(),
            seventh_card,
            trick_cards,
            trick_seats,
            trick_len: e.current_trick.len() as u8,
            leader: e.current_trick_leader.unwrap_or(e.current_turn) as u8,
            turn: e.current_turn as u8,
            tricks_done: e.completed_tricks.len() as u8,
            pts: [e.hand_points_team_a, e.hand_points_team_b],
        }
    }

    #[inline(always)]
    pub fn reverse_active(&self) -> bool {
        self.reverse_enabled && self.trump_exposed
    }

    #[inline(always)]
    pub fn can_show_trump(&self, seat: u8) -> bool {
        if self.trump_exposed || self.trick_len == 0 {
            return false;
        }
        let led_suit = self.trick_cards[0] >> 3;
        let suit_mask = 0xFFu32 << (led_suit * 8);
        (self.hands[seat as usize] & suit_mask) == 0
    }

    #[inline(always)]
    pub fn expose_trump(&mut self, seat: u8) {
        if self.trump_exposed {
            return;
        }
        self.trump_exposed = true;
        if self.trick_len > 0 {
            self.exposed_at_idx = self.trick_len as i8;
            if self.reverse_enabled {
                self.reverse_at_idx = self.trick_len as i8;
            }
        }
        if self.seventh_card >= 0 {
            self.hands[self.bidder as usize] |= 1u32 << (self.seventh_card as u8);
            self.seventh_card = -1;
        }
        if self.trump_suit >= 0 {
            let tmask = 0xFFu32 << ((self.trump_suit as u8) * 8);
            if (self.hands[seat as usize] & tmask) != 0 {
                self.must_play_trump = seat as i8;
            }
        }
    }

    #[inline(always)]
    pub fn legal_mask(&self, seat: u8) -> u32 {
        let h = self.hands[seat as usize];
        if self.must_play_trump == seat as i8 && self.trump_suit >= 0 {
            let tmask = 0xFFu32 << ((self.trump_suit as u8) * 8);
            if (h & tmask) != 0 {
                return h & tmask;
            }
        }
        if self.trick_len > 0 {
            let led_suit = self.trick_cards[0] >> 3;
            let smask = 0xFFu32 << (led_suit * 8);
            if (h & smask) != 0 {
                return h & smask;
            }
        }
        h
    }

    #[inline(always)]
    pub fn check_auto_marriage(&mut self, seat: u8) {
        if self.marriage_done || !self.trump_exposed || self.trump_suit < 0 {
            return;
        }
        let k_bit = 1u32 << (((self.trump_suit as u8) << 3) | 4);
        let q_bit = 1u32 << (((self.trump_suit as u8) << 3) | 5);
        if (self.hands[seat as usize] & (k_bit | q_bit)) == (k_bit | q_bit) {
            self.marriage_done = true;
            if Self::team_of(seat) == Self::team_of(self.bidder) {
                self.eff_bid = self.eff_bid.saturating_sub(4).max(16);
            } else {
                self.eff_bid = self.eff_bid.saturating_add(4).min(28);
            }
        }
    }

    #[inline(always)]
    pub fn trick_winner_now(&self) -> u8 {
        let led_suit = self.trick_cards[0] >> 3;
        let rev = self.reverse_active();
        let active_t = if self.trump_exposed { self.trump_suit } else { -1 };
        let exp_cut = if self.exposed_at_idx >= 0 { self.exposed_at_idx as usize } else { 0 };
        let rev_cut = if self.reverse_at_idx >= 0 { self.reverse_at_idx as usize } else { 0 };

        let mut win_idx = 0usize;
        let mut win_is_trump = active_t >= 0 && (self.trick_cards[0] >> 3) == active_t as u8 && 0 >= exp_cut;
        let mut win_str = card_strength(self.trick_cards[0], rev && 0 >= rev_cut);

        for i in 1..(self.trick_len as usize) {
            let c = self.trick_cards[i];
            let s = c >> 3;
            let is_trump = active_t >= 0 && s == active_t as u8 && i >= exp_cut;
            let c_str = card_strength(c, rev && i >= rev_cut);
            if is_trump && !win_is_trump {
                win_idx = i;
                win_is_trump = true;
                win_str = c_str;
            } else if is_trump && win_is_trump {
                if c_str > win_str {
                    win_idx = i;
                    win_str = c_str;
                }
            } else if !win_is_trump && s == led_suit && c_str > win_str {
                win_idx = i;
                win_str = c_str;
            }
        }
        self.trick_seats[win_idx]
    }

    #[inline(always)]
    pub fn play_card(&mut self, card: u8) {
        let s = self.turn as usize;
        self.hands[s] &= !(1u32 << card);
        self.played |= 1u32 << card;
        if self.trick_len > 0 {
            let led_suit = self.trick_cards[0] >> 3;
            if (card >> 3) != led_suit {
                self.voids[s] |= 1u8 << led_suit;
            }
        }
        if self.must_play_trump == self.turn as i8 {
            self.must_play_trump = -1;
        }
        let idx = self.trick_len as usize;
        self.trick_cards[idx] = card;
        self.trick_seats[idx] = self.turn;
        self.trick_len += 1;

        if self.trick_len == 4 {
            let winner = self.trick_winner_now();
            let mut tpts = 0u8;
            for i in 0..4 {
                tpts += card_pts(self.trick_cards[i]);
            }
            self.pts[Self::team_of(winner)] += tpts;
            self.trick_len = 0;
            self.tricks_done += 1;
            self.exposed_at_idx = -1;
            self.reverse_at_idx = -1;
            self.leader = winner;
            self.turn = winner;
        } else {
            self.turn = (self.turn + 1) & 3;
        }
    }

    #[inline(always)]
    pub fn bidding_team_won(&self) -> bool {
        let bt = Self::team_of(self.bidder);
        self.pts[bt] >= self.eff_bid
    }

    #[inline(always)]
    pub fn set_points_for_team(&self, team: usize) -> i32 {
        let bt = Self::team_of(self.bidder);
        let bpts = self.pts[bt];
        let mult = self.stakes as i32;
        let bt_delta = if bpts >= self.eff_bid {
            if bpts == 28 { 3 * mult } else { mult }
        } else {
            if self.eff_bid.saturating_sub(bpts) >= 8 { -2 * mult } else { -mult }
        };
        if team == bt { bt_delta } else { -bt_delta }
    }
}

// ============================================================================
// Pro RL v3 Neural Architectures (AVX-512 friendly fixed-size dimensions)
// ============================================================================

pub const V3_IN: usize = 128;
pub const V3_H1: usize = 96;
pub const V3_H2: usize = 48;

pub const V3_BID_IN: usize = 32;
pub const V3_BID_H1: usize = 64;
pub const V3_BID_H2: usize = 32;

#[derive(Clone)]
pub struct ProValueNetV3 {
    pub w1: Vec<f32>, // V3_H1 * V3_IN = 12,288
    pub b1: Vec<f32>, // 96
    pub w2: Vec<f32>, // V3_H2 * V3_H1 = 4,608
    pub b2: Vec<f32>, // 48
    pub w3: Vec<f32>, // 48
    pub b3: f32,      // 1 -> Total: 17,089 weights (~68 KB)
}

impl ProValueNetV3 {
    pub fn from_embedded() -> Self {
        use crate::rl_weights_v3::*;
        Self {
            w1: V3_W1.to_vec(), b1: V3_B1.to_vec(),
            w2: V3_W2.to_vec(), b2: V3_B2.to_vec(),
            w3: V3_W3.to_vec(), b3: V3_B3,
        }
    }
    pub fn new_random(seed: u64) -> Self {
        let mut rng = FastRng::new(seed);
        let mut init = |n: usize, scale: f32| -> Vec<f32> {
            (0..n).map(|_| (rng.next_f32() * 2.0 - 1.0) * scale).collect()
        };
        Self {
            w1: init(V3_H1 * V3_IN, (2.0 / V3_IN as f32).sqrt()),
            b1: vec![0.0; V3_H1],
            w2: init(V3_H2 * V3_H1, (2.0 / V3_H1 as f32).sqrt()),
            b2: vec![0.0; V3_H2],
            w3: init(V3_H2, (1.0 / V3_H2 as f32).sqrt()),
            b3: 0.0,
        }
    }

    #[inline]
    pub fn predict(&self, x: &[f32; V3_IN]) -> f32 {
        let mut h1 = [0.0_f32; V3_H1];
        for j in 0..V3_H1 {
            let row = &self.w1[j * V3_IN..(j + 1) * V3_IN];
            let mut s = self.b1[j];
            for i in 0..V3_IN {
                s += row[i] * x[i];
            }
            h1[j] = if s > 0.0 { s } else { 0.01 * s };
        }
        let mut h2 = [0.0_f32; V3_H2];
        for k in 0..V3_H2 {
            let row = &self.w2[k * V3_H1..(k + 1) * V3_H1];
            let mut s = self.b2[k];
            for j in 0..V3_H1 {
                s += row[j] * h1[j];
            }
            h2[k] = if s > 0.0 { s } else { 0.01 * s };
        }
        let mut out = self.b3;
        for k in 0..V3_H2 {
            out += self.w3[k] * h2[k];
        }
        1.0 / (1.0 + (-out.clamp(-12.0, 12.0)).exp())
    }
}

#[derive(Clone)]
pub struct ProBidNetV3 {
    pub w1: Vec<f32>, // V3_BID_H1 * V3_BID_IN = 2,048
    pub b1: Vec<f32>, // 64
    pub w2: Vec<f32>, // V3_BID_H2 * V3_BID_H1 = 2,048
    pub b2: Vec<f32>, // 32
    pub w3: Vec<f32>, // 32
    pub b3: f32,      // 1 -> Total: 4,225 weights (~16.5 KB)
}

impl ProBidNetV3 {
    pub fn from_embedded() -> Self {
        use crate::rl_weights_v3::*;
        Self {
            w1: V3_BW1.to_vec(), b1: V3_BB1.to_vec(),
            w2: V3_BW2.to_vec(), b2: V3_BB2.to_vec(),
            w3: V3_BW3.to_vec(), b3: V3_BB3,
        }
    }
    pub fn new_random(seed: u64) -> Self {
        let mut rng = FastRng::new(seed);
        let mut init = |n: usize, scale: f32| -> Vec<f32> {
            (0..n).map(|_| (rng.next_f32() * 2.0 - 1.0) * scale).collect()
        };
        Self {
            w1: init(V3_BID_H1 * V3_BID_IN, (2.0 / V3_BID_IN as f32).sqrt()),
            b1: vec![0.0; V3_BID_H1],
            w2: init(V3_BID_H2 * V3_BID_H1, (2.0 / V3_BID_H1 as f32).sqrt()),
            b2: vec![0.0; V3_BID_H2],
            w3: init(V3_BID_H2, (1.0 / V3_BID_H2 as f32).sqrt()),
            b3: 16.0,
        }
    }

    #[inline]
    pub fn predict_expected_pts(&self, x: &[f32; V3_BID_IN]) -> f32 {
        let mut h1 = [0.0_f32; V3_BID_H1];
        for j in 0..V3_BID_H1 {
            let row = &self.w1[j * V3_BID_IN..(j + 1) * V3_BID_IN];
            let mut s = self.b1[j];
            for i in 0..V3_BID_IN {
                s += row[i] * x[i];
            }
            h1[j] = if s > 0.0 { s } else { 0.01 * s };
        }
        let mut h2 = [0.0_f32; V3_BID_H2];
        for k in 0..V3_BID_H2 {
            let row = &self.w2[k * V3_BID_H1..(k + 1) * V3_BID_H1];
            let mut s = self.b2[k];
            for j in 0..V3_BID_H1 {
                s += row[j] * h1[j];
            }
            h2[k] = if s > 0.0 { s } else { 0.01 * s };
        }
        let mut out = self.b3;
        for k in 0..V3_BID_H2 {
            out += self.w3[k] * h2[k];
        }
        out.clamp(11.0, 27.0)
    }
}

/// Extract 128 strictly fair (zero-peeking) exact-card + game-state features from `FastState`.
/// Suit-canonicalized when trump is known (trump suit is rotated to plane 0 for 4x sample efficiency!).
#[inline]
pub fn extract_v3_state_features(st: &FastState, seat: u8) -> [f32; V3_IN] {
    let mut f = [0.0_f32; V3_IN];
    let my_team = FastState::team_of(seat);
    let bt = FastState::team_of(st.bidder);
    let on_bt = my_team == bt;
    let known_t = if st.trump_exposed || seat == st.bidder { st.trump_suit } else { -1 };
    let suit_shift: u8 = if known_t >= 0 { known_t as u8 } else { 0 };

    // Helper: canonicalize card suit so known trump is always suit 0!
    let canon = |c: u8| -> usize {
        let s = ((c >> 3) + 4 - suit_shift) & 3;
        ((s << 3) | (c & 7)) as usize
    };

    // [0..32]: my_hand exact 32-card plane
    let mut h = st.hands[seat as usize];
    while h != 0 {
        let c = h.trailing_zeros() as u8;
        h &= h - 1;
        f[canon(c)] = 1.0;
    }

    // [32..64]: played_cards exact 32-card plane
    let mut p = st.played;
    while p != 0 {
        let c = p.trailing_zeros() as u8;
        p &= p - 1;
        f[32 + canon(c)] = 1.0;
    }

    // [64..96]: current trick cards (signed: +1 if played by my team, -1 if opponent)
    let mut trick_pts = 0u8;
    for i in 0..(st.trick_len as usize) {
        let c = st.trick_cards[i];
        trick_pts += card_pts(c);
        let sign = if FastState::team_of(st.trick_seats[i]) == my_team { 1.0 } else { -1.0 };
        f[64 + canon(c)] = sign;
    }

    // [96..112]: seat-relative voids (self, left, partner, right) x 4 canonical suits
    for rel in 0..4u8 {
        let abs_s = ((seat + rel) & 3) as usize;
        let vm = st.voids[abs_s];
        for s in 0..4u8 {
            let cs = ((s + 4 - suit_shift) & 3) as usize;
            if (vm & (1u8 << s)) != 0 {
                f[96 + (rel as usize) * 4 + cs] = 1.0;
            }
        }
    }

    // [112..128]: 16 high-signal scalar game-state features
    let my_pts = st.pts[my_team] as f32;
    let opp_pts = st.pts[1 - my_team] as f32;
    let target = st.eff_bid as f32;
    let pts_needed = if on_bt { (target - my_pts).max(0.0) } else { ((29.0 - target) - my_pts).max(0.0) };
    let opp_needed = if on_bt { ((29.0 - target) - opp_pts).max(0.0) } else { (target - opp_pts).max(0.0) };
    let my_t_cnt = if known_t >= 0 {
        (st.hands[seat as usize] & (0xFFu32 << ((known_t as u8) * 8))).count_ones() as f32
    } else {
        0.0
    };
    let unseen_t = if known_t >= 0 {
        let tmask = 0xFFu32 << ((known_t as u8) * 8);
        let seen_or_mine = (st.played | st.hands[seat as usize]) & tmask;
        (8 - seen_or_mine.count_ones()) as f32
    } else {
        0.0
    };
    let partner = (seat + 2) & 3;
    let cur_win_ours = if st.trick_len > 0 {
        if FastState::team_of(st.trick_winner_now()) == my_team { 1.0 } else { -1.0 }
    } else {
        0.0
    };

    f[112] = if on_bt { 1.0 } else { 0.0 };
    f[113] = (target - 16.0) / 12.0;
    f[114] = my_pts / 28.0;
    f[115] = opp_pts / 28.0;
    f[116] = pts_needed / 28.0;
    f[117] = opp_needed / 28.0;
    f[118] = st.tricks_done as f32 / 8.0;
    f[119] = if st.trump_exposed { 1.0 } else { 0.0 };
    f[120] = if st.reverse_active() { 1.0 } else if seat == st.bidder && st.reverse_enabled { 0.5 } else { 0.0 };
    f[121] = if known_t < 0 && st.trump_exposed { 1.0 } else { 0.0 }; // NoTrump known
    f[122] = if st.leader == seat { 1.0 } else if st.leader == partner { 0.5 } else { 0.0 };
    f[123] = my_t_cnt / 8.0;
    f[124] = unseen_t / 8.0;
    f[125] = if seat == ((st.dealer + 1) & 3) { 1.0 } else { 0.0 };
    f[126] = trick_pts as f32 / 12.0;
    f[127] = cur_win_ours;
    f
}

/// Extract 32 opening-hand + auction features for `ProBidNetV3`.
#[inline]
pub fn extract_v3_bid_features(
    hand_mask: u32,
    is_opening_leader: bool,
    allow_reverse: bool,
    cur_high_bid: u8,
    partner_winning: bool,
    passed_count: u8,
) -> [f32; V3_BID_IN] {
    let mut f = [0.0_f32; V3_BID_IN];
    let mut best_s = 0u8;
    let mut best_s_sc = -1i32;
    let mut best_r = 0u8;
    let mut best_r_sc = -1i32;
    let mut lens = [0u32; 4];

    for s in 0..4u8 {
        let sm = (hand_mask >> (s * 8)) & 0xFF;
        let cnt = sm.count_ones();
        lens[s as usize] = cnt;
        if cnt == 0 { continue; }
        let mut ss = (cnt as i32) * 4;
        let mut rs = (cnt as i32) * 4;
        for r in 0..8u8 {
            if (sm & (1 << r)) != 0 {
                ss += (7 - r) as i32;
                rs += r as i32;
            }
        }
        if ss > best_s_sc { best_s_sc = ss; best_s = s; }
        if rs > best_r_sc { best_r_sc = rs; best_r = s; }
    }

    let sm = (hand_mask >> (best_s * 8)) & 0xFF;
    let has_j = (sm & 1) != 0;
    let has_9 = (sm & 2) != 0;
    let has_a = (sm & 4) != 0;
    let has_10 = (sm & 8) != 0;
    let has_kq = (sm & 48) == 48;
    let mut s_pts = 0u8;
    for r in 0..4u8 { if (sm & (1 << r)) != 0 { s_pts += CARD_PTS[r as usize]; } }

    let mut side_j = 0u8; let mut side_9 = 0u8; let mut side_a = 0u8;
    let mut tot_j = 0u8; let mut tot_9 = 0u8; let mut tot_a = 0u8;
    for s in 0..4u8 {
        let m = (hand_mask >> (s * 8)) & 0xFF;
        if (m & 1) != 0 { tot_j += 1; if s != best_s { side_j += 1; } }
        if (m & 2) != 0 { tot_9 += 1; if s != best_s { side_9 += 1; } }
        if (m & 4) != 0 { tot_a += 1; if s != best_s { side_a += 1; } }
    }
    let voids = lens.iter().filter(|&&l| l == 0).count() as f32;
    let singletons = lens.iter().filter(|&&l| l == 1).count() as f32;

    f[0] = lens[best_s as usize] as f32 / 4.0;
    f[1] = if has_j { 1.0 } else { 0.0 };
    f[2] = if has_9 { 1.0 } else { 0.0 };
    f[3] = if has_j && has_9 { 1.0 } else { 0.0 };
    f[4] = if has_a { 1.0 } else { 0.0 };
    f[5] = if has_10 { 1.0 } else { 0.0 };
    f[6] = if has_kq { 1.0 } else { 0.0 };
    f[7] = s_pts as f32 / 7.0;
    f[8] = side_j as f32 / 3.0;
    f[9] = side_9 as f32 / 3.0;
    f[10] = side_a as f32 / 3.0;
    f[11] = voids / 3.0;
    f[12] = singletons / 4.0;

    let rm = (hand_mask >> (best_r * 8)) & 0xFF;
    let r7 = (rm & 128) != 0;
    let r8 = (rm & 64) != 0;
    let rkq = (rm & 48) == 48;
    let mut s7 = 0u8; let mut s8 = 0u8; let mut nt_j9 = 0u8; let mut t_j9 = 0u8;
    for s in 0..4u8 {
        let m = (hand_mask >> (s * 8)) & 0xFF;
        if s != best_r {
            if (m & 128) != 0 { s7 += 1; }
            if (m & 64) != 0 { s8 += 1; }
            if (m & 1) != 0 { nt_j9 += 1; }
            if (m & 2) != 0 { nt_j9 += 1; }
        } else {
            if (m & 1) != 0 { t_j9 += 1; }
            if (m & 2) != 0 { t_j9 += 1; }
        }
    }
    if allow_reverse {
        f[13] = lens[best_r as usize] as f32 / 4.0;
        f[14] = if r7 { 1.0 } else { 0.0 };
        f[15] = if r8 { 1.0 } else { 0.0 };
        f[16] = if r7 && r8 { 1.0 } else { 0.0 };
        f[17] = if rkq { 1.0 } else { 0.0 };
        f[18] = s7 as f32 / 3.0;
        f[19] = s8 as f32 / 3.0;
        f[20] = (tot_j + tot_9) as f32 / 4.0;
    }
    f[21] = tot_j as f32 / 4.0;
    f[22] = tot_9 as f32 / 4.0;
    f[23] = tot_a as f32 / 4.0;

    // 8 NEW v3 features: opening lead, trump vs non-trump J/9 split, auction context!
    f[24] = if is_opening_leader { 1.0 } else { 0.0 };
    f[25] = if is_opening_leader && r7 && r8 { 1.0 } else { 0.0 };
    f[26] = nt_j9 as f32 / 4.0;
    f[27] = t_j9 as f32 / 2.0;
    f[28] = if cur_high_bid > 0 { (cur_high_bid as f32 - 15.0) / 13.0 } else { 0.0 };
    f[29] = if partner_winning { 1.0 } else { 0.0 };
    f[30] = passed_count as f32 / 3.0;
    let total_pts: u8 = (0..32u8).filter(|&c| (hand_mask & (1u32 << c)) != 0).map(card_pts).sum();
    f[31] = total_pts as f32 / 10.0;
    f
}

// ============================================================================
// Fast Tactical Rollout Policy on FastState (zero allocations, ~40 ns/move)
// ============================================================================

#[inline]
pub fn fast_heuristic_action(st: &FastState) -> (bool, u8) {
    // Returns (show_trump_first, card_to_play)
    let seat = st.turn;
    let my_team = FastState::team_of(seat);
    let partner = (seat + 2) & 3;
    let rev = st.reverse_active();
    let known_t = if st.trump_exposed || seat == st.bidder { st.trump_suit } else { -1 };

    // Optional Show Trump decision when void in led suit
    if st.can_show_trump(seat) {
        let mut tpts = 0u8;
        for i in 0..(st.trick_len as usize) {
            tpts += card_pts(st.trick_cards[i]);
        }
        let cur_win = st.trick_winner_now();
        let partner_winning = cur_win == partner;
        let should_show = if seat == st.bidder && st.reverse_enabled {
            // Bidder with hidden Reverse wants to expose as soon as safe or trick has points!
            !partner_winning || tpts >= 2 || st.tricks_done >= 2
        } else if !partner_winning && (tpts >= 2 || st.trick_len == 3) {
            true
        } else {
            false
        };
        if should_show {
            return (true, 0);
        }
    }

    let legal = st.legal_mask(seat);
    let mut cards = [0u8; 8];
    let mut n = 0usize;
    let mut m = legal;
    while m != 0 {
        cards[n] = m.trailing_zeros() as u8;
        m &= m - 1;
        n += 1;
    }
    if n == 1 {
        return (false, cards[0]);
    }

    // Leading a trick
    if st.trick_len == 0 {
        // Pre-exposure Reverse strategy for bidder: cash non-trump J/9 first, else lead repeated/long non-trump saving 7/8
        if !st.trump_exposed && seat == st.bidder && st.reverse_enabled {
            for &c in &cards[..n] {
                if (c >> 3) as i8 != known_t && (c & 7) == 0 {
                    return (false, c);
                }
            }
            let mut best = cards[0];
            let mut best_sc = -100i32;
            for &c in &cards[..n] {
                let s = c >> 3;
                if s as i8 == known_t || (c & 7) >= 6 { continue; }
                let seen_s = (st.played & (0xFFu32 << (s * 8))).count_ones() as i32;
                let held_s = (st.hands[seat as usize] & (0xFFu32 << (s * 8))).count_ones() as i32;
                let sc = seen_s * 3 + held_s * 2 + if card_pts(c) == 0 { 2 } else { 0 };
                if sc > best_sc { best_sc = sc; best = c; }
            }
            if best_sc > -100 { return (false, best); }
        }
        // Cash boss card safely: avoid leading non-trump 9/J on a 2nd round of a suit
        // (or when <=4 cards remain among others) while opponents may still hold trumps!
        let trumps_out = if known_t >= 0 {
            let tmask = 0xFFu32 << ((known_t as u8) * 8);
            ((st.played | st.hands[seat as usize]) & tmask).count_ones() < 8
        } else {
            !st.trump_exposed
        };
        for &c in &cards[..n] {
            let s = c >> 3;
            let is_boss = is_fast_boss(c, st.played | st.hands[seat as usize], rev);
            if !is_boss { continue; }
            if s as i8 == known_t {
                if st.trump_exposed { return (false, c); }
                continue;
            }
            if !trumps_out {
                return (false, c);
            }
            let sbit = 1u8 << s;
            let opp_void = (0..4usize).any(|o| FastState::team_of(o as u8) != my_team && (st.voids[o] & sbit) != 0);
            if opp_void { continue; }
            let smask = 0xFFu32 << (s * 8);
            let seen_s = (st.played & smask).count_ones();
            let held_s = (st.hands[seat as usize] & smask).count_ones();
            let others_rem = 8u32.saturating_sub(seen_s + held_s);
            if seen_s == 0 && others_rem >= 5 {
                return (false, c);
            }
        }
        // Otherwise lead cheapest non-trump low card
        let mut best = cards[0];
        let mut best_k = (99u8, 99u8, 99u8);
        for &c in &cards[..n] {
            let k = (card_pts(c), if (c >> 3) as i8 == known_t { 1 } else { 0 }, card_strength(c, rev));
            if k < best_k { best_k = k; best = c; }
        }
        return (false, best);
    }

    // Following / ruffing / discarding
    let cur_win = st.trick_winner_now();
    let partner_winning = FastState::team_of(cur_win) == my_team;
    let mut best_win: Option<(u8, (u8, u8))> = None;
    let mut best_lose: Option<(u8, (u8, u8, u8))> = None;

    for &c in &cards[..n] {
        let mut sim = *st;
        sim.trick_cards[sim.trick_len as usize] = c;
        sim.trick_seats[sim.trick_len as usize] = seat;
        sim.trick_len += 1;
        let wins = sim.trick_winner_now() == seat;
        if wins {
            let is_t = if st.trump_exposed && (c >> 3) as i8 == st.trump_suit { 1 } else { 0 };
            let k = (is_t, card_strength(c, rev));
            if best_win.map(|bw| k < bw.1).unwrap_or(true) {
                best_win = Some((c, k));
            }
        }
        let is_t = if (c >> 3) as i8 == known_t { 1 } else { 0 };
        let k_lose = if partner_winning {
            // Feed points to partner when safe (4th seat or partner has boss)
            (is_t, 3 - card_pts(c), card_strength(c, rev))
        } else {
            (card_pts(c), is_t, card_strength(c, rev))
        };
        if best_lose.map(|bl| k_lose < bl.1).unwrap_or(true) {
            best_lose = Some((c, k_lose));
        }
    }

    if partner_winning && st.trick_len == 3 {
        return (false, best_lose.unwrap().0);
    }
    if !partner_winning {
        if let Some((wc, _)) = best_win {
            return (false, wc);
        }
    }
    (false, best_lose.unwrap().0)
}

#[inline(always)]
fn is_fast_boss(c: u8, known_mask: u32, rev: bool) -> bool {
    let s = c >> 3;
    let r = c & 7;
    let suit_unseen = (!known_mask >> (s * 8)) & 0xFF;
    let stronger_mask = if rev {
        // Stronger ranks have r' > r
        if r == 7 { 0 } else { 0xFFu32 << (r + 1) }
    } else {
        // Stronger ranks have r' < r
        (1u32 << r) - 1
    };
    (suit_unseen & stronger_mask) == 0
}

// ============================================================================
// 4-Trick Exact Double-Dummy Alpha-Beta Endgame Solver (16 cards, move ordered)
// ============================================================================

pub fn alphabeta_4trick(
    st: &FastState,
    root_team: usize,
    mut alpha: i32,
    mut beta: i32,
    nodes: &mut usize,
    node_limit: usize,
) -> i32 {
    if st.tricks_done >= 8 {
        let bt = FastState::team_of(st.bidder);
        let won = st.bidding_team_won();
        let root_won = if root_team == bt { won } else { !won };
        return (if root_won { 100 } else { 0 }) + st.pts[root_team] as i32;
    }
    *nodes += 1;
    if *nodes >= node_limit {
        return st.pts[root_team] as i32 + 50;
    }

    // Early cutoff if contract outcome is already mathematically clinched
    let rem_pts = 28i32 - (st.pts[0] + st.pts[1]) as i32;
    let bt = FastState::team_of(st.bidder);
    if st.pts[bt] >= st.eff_bid {
        let root_won = root_team == bt;
        if root_won {
            let min_score = 100 + st.pts[root_team] as i32;
            if min_score >= beta { return min_score; }
        } else {
            let max_score = st.pts[root_team] as i32 + rem_pts;
            if max_score <= alpha { return max_score; }
        }
    } else if (st.pts[bt] as i32 + rem_pts) < st.eff_bid as i32 {
        let root_won = root_team != bt;
        if root_won {
            let min_score = 100 + st.pts[root_team] as i32;
            if min_score >= beta { return min_score; }
        } else {
            let max_score = st.pts[root_team] as i32 + rem_pts;
            if max_score <= alpha { return max_score; }
        }
    }

    let seat = st.turn;
    let legal = st.legal_mask(seat);
    let mut moves = [0u8; 8];
    let mut n = 0usize;
    let mut m = legal;
    while m != 0 {
        moves[n] = m.trailing_zeros() as u8;
        m &= m - 1;
        n += 1;
    }

    // Move ordering: sort high-strength / trump cards first for faster alpha-beta pruning
    let rev = st.reverse_active();
    let ts = if st.trump_exposed { st.trump_suit } else { -1 };
    if n > 1 {
        moves[..n].sort_unstable_by(|&a, &b| {
            let ka = (if (a >> 3) as i8 == ts { 1u8 } else { 0 }, card_strength(a, rev));
            let kb = (if (b >> 3) as i8 == ts { 1u8 } else { 0 }, card_strength(b, rev));
            kb.cmp(&ka)
        });
    }

    let maximizing = FastState::team_of(seat) == root_team;
    if maximizing {
        let mut best = i32::MIN;
        for &c in &moves[..n] {
            let mut child = *st;
            child.play_card(c);
            let v = alphabeta_4trick(&child, root_team, alpha, beta, nodes, node_limit);
            if v > best { best = v; }
            if best > alpha { alpha = best; }
            if alpha >= beta { break; }
        }
        best
    } else {
        let mut best = i32::MAX;
        for &c in &moves[..n] {
            let mut child = *st;
            child.play_card(c);
            let v = alphabeta_4trick(&child, root_team, alpha, beta, nodes, node_limit);
            if v < best { best = v; }
            if best < beta { beta = best; }
            if alpha >= beta { break; }
        }
        best
    }
}

// ============================================================================
// Fast Zero-Allocation PIMC World Sampler + Pro RL v3 Move Selector
// ============================================================================

#[inline]
pub fn sample_fast_world(st: &FastState, seat: u8, rng: &mut FastRng) -> [u32; 4] {
    let mut sizes = [0usize; 4];
    for s in 0..4 {
        sizes[s] = st.hands[s].count_ones() as usize;
    }
    let known = st.played | st.hands[seat as usize]
        | if st.seventh_card >= 0 { 1u32 << (st.seventh_card as u8) } else { 0 };
    let mut unseen = [0u8; 28];
    let mut un = 0usize;
    let mut um = (!known) & 0xFFFF_FFFF;
    while um != 0 {
        unseen[un] = um.trailing_zeros() as u8;
        um &= um - 1;
        un += 1;
    }

    // Try up to 4 void-consistent shuffles (fallback to best-fit)
    for _ in 0..4 {
        for i in (1..un).rev() {
            let j = (rng.next_u64() as usize) % (i + 1);
            unseen.swap(i, j);
        }
        let mut hands = [0u32; 4];
        hands[seat as usize] = st.hands[seat as usize];
        let mut rem = sizes;
        rem[seat as usize] = 0;
        let mut ok = true;
        for &c in &unseen[..un] {
            let sbit = 1u8 << (c >> 3);
            let mut placed = false;
            // Bayesian bid-consistent weighting: when bidder won a real bid (>=17),
            // bias trump cards and high/reverse-strong cards toward bidder if not void!
            let b = st.bidder as usize;
            let is_trump_c = st.trump_exposed && st.trump_suit >= 0 && (c >> 3) == st.trump_suit as u8;
            let is_strong_c = if st.reverse_active() { (c & 7) >= 6 } else { (c & 7) <= 1 };
            let want_bidder = b != seat as usize
                && rem[b] > 0
                && (st.voids[b] & sbit) == 0
                && !(is_strong_c && (st.failed_beat[b] & sbit) != 0)
                && ((is_trump_c && (rng.next_u64() & 3) != 0)
                    || (st.bid >= 18 && is_strong_c && (rng.next_u64() & 1) == 0));
            if want_bidder {
                hands[b] |= 1u32 << c;
                rem[b] -= 1;
                placed = true;
            } else {
                let start = (rng.next_u64() as usize) & 3;
                if is_strong_c {
                    for k in 0..4 {
                        let s = (start + k) & 3;
                        if rem[s] > 0 && (st.voids[s] & sbit) == 0 && (st.failed_beat[s] & sbit) == 0 {
                            hands[s] |= 1u32 << c;
                            rem[s] -= 1;
                            placed = true;
                            break;
                        }
                    }
                }
                if !placed {
                    for k in 0..4 {
                        let s = (start + k) & 3;
                        if rem[s] > 0 && (st.voids[s] & sbit) == 0 {
                            hands[s] |= 1u32 << c;
                            rem[s] -= 1;
                            placed = true;
                            break;
                        }
                    }
                }
            }
            if !placed {
                ok = false;
                break;
            }
        }
        if ok {
            return hands;
        }
    }

    // Fallback: unconstrained deal
    let mut hands = [0u32; 4];
    hands[seat as usize] = st.hands[seat as usize];
    let mut idx = 0usize;
    for s in 0..4 {
        if s == seat as usize { continue; }
        for _ in 0..sizes[s] {
            if idx < un {
                hands[s] |= 1u32 << unseen[idx];
                idx += 1;
            }
        }
    }
    hands
}

/// Pro RL v3 decision on `FastState`:
/// - Works BOTH pre-exposure and post-exposure!
/// - Evaluates `Show Trump` vs `PlayCard` directly through PIMC + `ProValueNetV3`!
/// - Uses 4-Trick Exact Alpha-Beta Endgame when `tricks_done >= 4` (<= 4 cards left)!
pub fn choose_v3_fast_play(
    st: &FastState,
    vnet: &ProValueNetV3,
    samples: usize,
    use_4trick_ab: bool,
    eval_pre_exposure: bool,
    rng: &mut FastRng,
) -> (bool, u8) {
    let seat = st.turn;
    let legal = st.legal_mask(seat);
    let can_show = st.can_show_trump(seat);

    if legal.count_ones() == 1 && !can_show {
        return (false, legal.trailing_zeros() as u8);
    }
    if !eval_pre_exposure && !st.trump_exposed {
        return fast_heuristic_action(st);
    }

    let mut actions = [(false, 0u8); 9];
    let mut na = 0usize;
    let mut m = legal;
    while m != 0 {
        actions[na] = (false, m.trailing_zeros() as u8);
        m &= m - 1;
        na += 1;
    }
    if can_show {
        actions[na] = (true, 0);
        na += 1;
    }

    let my_team = FastState::team_of(seat);
    let cards_left = st.hands[seat as usize].count_ones() as usize;
    let use_ab = st.trump_exposed && ((use_4trick_ab && cards_left <= 4) || (!use_4trick_ab && cards_left <= 3));
    let node_limit = if cards_left == 4 { 1800 } else { 4000 };
    let rollout_tricks = if cards_left <= 5 { 8 } else { 2 };

    let mut scores = [0.0_f32; 9];
    for _ in 0..samples {
        let world = sample_fast_world(st, seat, rng);
        for ai in 0..na {
            let mut sim = *st;
            sim.hands = world;
            let start_tr = sim.tricks_done;
            let (is_show, card) = actions[ai];
            if is_show {
                sim.expose_trump(seat);
                sim.check_auto_marriage(seat);
                // Immediately play best follow-up card after showing trump
                let (_, c2) = fast_heuristic_action(&sim);
                sim.play_card(c2);
            } else {
                sim.play_card(card);
            }

            if use_ab && sim.tricks_done < 8 {
                let mut nodes = 0usize;
                let ab = alphabeta_4trick(&sim, my_team, i32::MIN + 1, i32::MAX - 1, &mut nodes, node_limit);
                let won = if ab >= 100 { 10.0_f32 } else { 0.0_f32 };
                let pts = (ab % 100) as f32;
                scores[ai] += won + pts * 0.08;
                continue;
            }

            let mut guard = 0u8;
            while sim.tricks_done < 8 && (sim.tricks_done - start_tr) < rollout_tricks && guard < 36 {
                guard += 1;
                let t = sim.turn;
                sim.check_auto_marriage(t);
                let (sh, c) = fast_heuristic_action(&sim);
                if sh {
                    sim.expose_trump(t);
                    sim.check_auto_marriage(t);
                } else {
                    sim.play_card(c);
                }
            }

            if sim.tricks_done >= 8 {
                let bt = FastState::team_of(sim.bidder);
                let won = if my_team == bt { sim.bidding_team_won() } else { !sim.bidding_team_won() };
                scores[ai] += (if won { 10.0 } else { 0.0 }) + (sim.pts[my_team] as f32) * 0.08;
            } else {
                let feat = extract_v3_state_features(&sim, seat);
                scores[ai] += vnet.predict(&feat) * 10.0;
            }
        }
    }

    let mut best_i = 0usize;
    for i in 1..na {
        if scores[i] > scores[best_i] {
            best_i = i;
        }
    }
    actions[best_i]
}

// ============================================================================
// Multi-Generation Parallel Self-Play Trainer & 100k-Hand Head-to-Head Arena
// ============================================================================

#[cfg(test)]
pub mod v3_trainer {
    use super::*;
    use crate::rl_weights_v2 as v2w;
    use std::path::Path;
    use std::time::Instant;

    /// Frozen Pro RL v2 networks loaded from `rl_weights_v2.rs` for 100k-hand apples-to-apples evaluation!
    #[derive(Clone)]
    struct FrozenV2 {
        w1: Vec<f32>, b1: Vec<f32>, w2: Vec<f32>, b2: Vec<f32>, w3: Vec<f32>, b3: f32,
        bw1: Vec<f32>, bb1: Vec<f32>, bw2: Vec<f32>, bb2: f32,
    }

    impl FrozenV2 {
        fn load() -> Self {
            Self {
                w1: v2w::W1.to_vec(), b1: v2w::B1.to_vec(),
                w2: v2w::W2.to_vec(), b2: v2w::B2.to_vec(),
                w3: v2w::W3.to_vec(), b3: v2w::B3,
                bw1: v2w::BW1.to_vec(), bb1: v2w::BB1.to_vec(),
                bw2: v2w::BW2.to_vec(), bb2: v2w::BB2,
            }
        }

        #[inline]
        fn predict_bid(&self, hand_mask: u32) -> f32 {
            let f32_full = extract_v3_bid_features(hand_mask, false, true, 0, false, 0);
            let mut h = [0.0_f32; v2w::BID_H_DIM];
            for j in 0..v2w::BID_H_DIM {
                let mut s = self.bb1[j];
                let row = j * v2w::BID_IN_DIM;
                for i in 0..v2w::BID_IN_DIM {
                    s += self.bw1[row + i] * f32_full[i];
                }
                h[j] = if s > 0.0 { s } else { 0.01 * s };
            }
            let mut out = self.bb2;
            for j in 0..v2w::BID_H_DIM { out += self.bw2[j] * h[j]; }
            out.clamp(12.0, 26.0)
        }

        #[inline]
        fn predict_val(&self, st: &FastState, seat: u8) -> f32 {
            // Exact 42-dim v2 feature extractor on FastState
            let mut f = [0.0_f32; v2w::IN_DIM];
            let my_team = FastState::team_of(seat);
            let bt = FastState::team_of(st.bidder);
            let on_bt = my_team == bt;
            let target = st.eff_bid as f32;
            let my_pts = st.pts[my_team] as f32;
            let opp_pts = st.pts[1 - my_team] as f32;
            let pts_needed = if on_bt { (target - my_pts).max(0.0) } else { ((29.0 - target) - my_pts).max(0.0) };
            let known_t = if st.trump_exposed || seat == st.bidder { st.trump_suit } else { -1 };
            let partner = (seat + 2) & 3;
            let rev = st.reverse_active();

            f[0] = if on_bt { 1.0 } else { 0.0 };
            f[1] = (target - 16.0) / 12.0;
            f[2] = my_pts / 28.0;
            f[3] = opp_pts / 28.0;
            f[4] = pts_needed / 28.0;
            f[5] = st.tricks_done as f32 / 8.0;
            f[6] = if st.trump_exposed { 1.0 } else { 0.0 };
            f[7] = if rev { 1.0 } else { 0.0 };
            f[8] = if known_t < 0 && st.trump_exposed { 1.0 } else { 0.0 };
            f[9] = if st.leader == seat { 1.0 } else { 0.0 };
            f[10] = if st.leader == partner { 1.0 } else { 0.0 };
            let my_t_cnt = if known_t >= 0 { (st.hands[seat as usize] & (0xFFu32 << ((known_t as u8) * 8))).count_ones() as f32 } else { 0.0 };
            let unseen_t = if known_t >= 0 {
                let tmask = 0xFFu32 << ((known_t as u8) * 8);
                (8 - ((st.played | st.hands[seat as usize]) & tmask).count_ones()) as f32
            } else { 0.0 };
            f[11] = my_t_cnt / 8.0;
            f[12] = unseen_t / 8.0;

            let mut bosses = 0u8;
            let mut my_hpts = 0u8;
            let mut h = st.hands[seat as usize];
            while h != 0 {
                let c = h.trailing_zeros() as u8;
                h &= h - 1;
                my_hpts += card_pts(c);
                if is_fast_boss(c, st.played | st.hands[seat as usize], rev) { bosses += 1; }
            }
            f[14] = bosses as f32 / 8.0;
            f[15] = my_hpts as f32 / 20.0;
            let opp_needed = if on_bt { ((29.0 - target) - opp_pts).max(0.0) } else { (target - opp_pts).max(0.0) };
            f[16] = opp_needed / 28.0;
            f[17] = (my_pts - opp_pts) / 28.0;

            let mut h1 = [0.0_f32; v2w::H1_DIM];
            for j in 0..v2w::H1_DIM {
                let mut s = self.b1[j];
                let row = j * v2w::IN_DIM;
                for i in 0..v2w::IN_DIM { s += self.w1[row + i] * f[i]; }
                h1[j] = if s > 0.0 { s } else { 0.01 * s };
            }
            let mut h2 = [0.0_f32; v2w::H2_DIM];
            for k in 0..v2w::H2_DIM {
                let mut s = self.b2[k];
                let row = k * v2w::H1_DIM;
                for j in 0..v2w::H1_DIM { s += self.w2[row + j] * h1[j]; }
                h2[k] = if s > 0.0 { s } else { 0.01 * s };
            }
            let mut out = self.b3;
            for k in 0..v2w::H2_DIM { out += self.w3[k] * h2[k]; }
            1.0 / (1.0 + (-out.clamp(-12.0, 12.0)).exp())
        }

        fn choose_play(&self, st: &FastState, samples: usize, rng: &mut FastRng) -> (bool, u8) {
            // Exact Pro RL v2 behavior: skips pre-exposure RL, 3-trick AB, never RL-evaluates Show Trump
            let seat = st.turn;
            if !st.trump_exposed {
                return fast_heuristic_action(st);
            }
            let legal = st.legal_mask(seat);
            if legal.count_ones() == 1 {
                return (false, legal.trailing_zeros() as u8);
            }
            let mut cards = [0u8; 8];
            let mut na = 0usize;
            let mut m = legal;
            while m != 0 { cards[na] = m.trailing_zeros() as u8; m &= m - 1; na += 1; }

            let my_team = FastState::team_of(seat);
            let cards_left = st.hands[seat as usize].count_ones() as usize;
            let use_ab = cards_left <= 3; // v2 only had 3-trick AB!
            let rollout_tricks = if cards_left <= 5 { 8 } else { 2 };
            let mut scores = [0.0_f32; 8];

            for _ in 0..samples {
                let world = sample_fast_world(st, seat, rng);
                for ai in 0..na {
                    let mut sim = *st;
                    sim.hands = world;
                    let start_tr = sim.tricks_done;
                    sim.play_card(cards[ai]);
                    if use_ab && sim.tricks_done < 8 {
                        let mut nodes = 0usize;
                        let ab = alphabeta_4trick(&sim, my_team, i32::MIN + 1, i32::MAX - 1, &mut nodes, 3500);
                        scores[ai] += (if ab >= 100 { 10.0 } else { 0.0 }) + (ab % 100) as f32 * 0.08;
                        continue;
                    }
                    let mut guard = 0u8;
                    while sim.tricks_done < 8 && (sim.tricks_done - start_tr) < rollout_tricks && guard < 36 {
                        guard += 1;
                        let t = sim.turn;
                        sim.check_auto_marriage(t);
                        let (sh, c) = fast_heuristic_action(&sim);
                        if sh { sim.expose_trump(t); } else { sim.play_card(c); }
                    }
                    if sim.tricks_done >= 8 {
                        let bt = FastState::team_of(sim.bidder);
                        let won = if my_team == bt { sim.bidding_team_won() } else { !sim.bidding_team_won() };
                        scores[ai] += (if won { 10.0 } else { 0.0 }) + sim.pts[my_team] as f32 * 0.08;
                    } else {
                        scores[ai] += self.predict_val(&sim, seat) * 10.0;
                    }
                }
            }
            let mut best = 0;
            for i in 1..na { if scores[i] > scores[best] { best = i; } }
            (false, cards[best])
        }
    }

    /// Trump selection on 4-card opening hand (using our 16,928-hand simulation-calibrated Reverse formula!)
    #[inline]
    fn choose_fast_trump(hand_mask: u32, is_opening_leader: bool) -> (i8, bool) {
        let mut best_suit = 0i8;
        let mut best_rev = false;
        let mut best_sc = -100.0_f32;

        let tot_j = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 1) != 0).count() as f32;
        let tot_9 = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 2) != 0).count() as f32;
        let tot_7 = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 128) != 0).count() as f32;
        let tot_8 = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 64) != 0).count() as f32;
        let max_len = (0..4u8).map(|s| ((hand_mask >> (s * 8)) & 0xFF).count_ones()).max().unwrap_or(0);

        // NoTrump (Joker)
        if max_len <= 2 && (tot_j >= 3.0 || (tot_j >= 2.0 && tot_9 >= 1.0)) {
            return (-1, false);
        }
        if max_len <= 2 && tot_7 >= 3.0 && tot_j == 0.0 && tot_9 == 0.0 {
            return (-1, true);
        }

        for s in 0..4u8 {
            let sm = (hand_mask >> (s * 8)) & 0xFF;
            let len = sm.count_ones() as f32;
            if len == 0.0 { continue; }
            let mut s_str = 0.0_f32;
            for r in 0..8u8 {
                if (sm & (1 << r)) != 0 { s_str += (7 - r) as f32; }
            }
            let has_m = (sm & 48) == 48;
            let straight_sc = len * 5.0 + s_str * 1.4 + if has_m { 6.0 } else { 0.0 };
            if straight_sc > best_sc {
                best_sc = straight_sc;
                best_suit = s as i8;
                best_rev = false;
            }

            let has_7 = (sm & 128) != 0;
            let has_8 = (sm & 64) != 0;
            if (has_7 || has_8) && (len >= 2.0 || (has_7 && (tot_7 + tot_8) >= 2.0)) {
                let has_78 = has_7 && has_8;
                let side_78 = (tot_7 + tot_8) - if has_7 { 1.0 } else { 0.0 } - if has_8 { 1.0 } else { 0.0 };
                let nt_j9 = (tot_j + tot_9) - if (sm & 1) != 0 { 1.0 } else { 0.0 } - if (sm & 2) != 0 { 1.0 } else { 0.0 };
                let pred_edge = -1.6387
                    + if is_opening_leader { 1.5190 } else { 0.0 }
                    + len * 0.8454
                    + if has_7 { 0.5625 } else { 0.0 }
                    + if has_8 { 0.1186 } else { 0.0 }
                    + if has_78 { 0.6811 } else { 0.0 }
                    + side_78 * 0.7265
                    - tot_j * 1.5052
                    - tot_9 * 1.4561
                    + nt_j9 * 1.2706;
                if pred_edge > 0.75 {
                    let rev_sc = straight_sc + pred_edge * 3.5;
                    if rev_sc > best_sc {
                        best_sc = rev_sc;
                        best_suit = s as i8;
                        best_rev = true;
                    }
                }
            }
        }
        (best_suit, best_rev)
    }

    // AdamW trainer for ProValueNetV3
    struct AdamV3 {
        net: ProValueNetV3,
        mw1: Vec<f32>, vw1: Vec<f32>, mb1: Vec<f32>, vb1: Vec<f32>,
        mw2: Vec<f32>, vw2: Vec<f32>, mb2: Vec<f32>, vb2: Vec<f32>,
        mw3: Vec<f32>, vw3: Vec<f32>, mb3: f32, vb3: f32,
        step: i32,
    }

    impl AdamV3 {
        fn new(net: ProValueNetV3) -> Self {
            Self {
                mw1: vec![0.0; V3_H1 * V3_IN], vw1: vec![0.0; V3_H1 * V3_IN],
                mb1: vec![0.0; V3_H1], vb1: vec![0.0; V3_H1],
                mw2: vec![0.0; V3_H2 * V3_H1], vw2: vec![0.0; V3_H2 * V3_H1],
                mb2: vec![0.0; V3_H2], vb2: vec![0.0; V3_H2],
                mw3: vec![0.0; V3_H2], vw3: vec![0.0; V3_H2],
                mb3: 0.0, vb3: 0.0, step: 0, net,
            }
        }

        fn train_batch(&mut self, batch: &[([f32; V3_IN], f32)], lr: f32, wd: f32) -> f32 {
            let mut gw1 = vec![0.0_f32; V3_H1 * V3_IN];
            let mut gb1 = vec![0.0_f32; V3_H1];
            let mut gw2 = vec![0.0_f32; V3_H2 * V3_H1];
            let mut gb2 = vec![0.0_f32; V3_H2];
            let mut gw3 = vec![0.0_f32; V3_H2];
            let mut gb3 = 0.0_f32;
            let mut loss = 0.0_f32;

            for &(ref x, target) in batch {
                let mut z1 = [0.0_f32; V3_H1];
                let mut h1 = [0.0_f32; V3_H1];
                for j in 0..V3_H1 {
                    let row = &self.net.w1[j * V3_IN..(j + 1) * V3_IN];
                    let mut s = self.net.b1[j];
                    for i in 0..V3_IN { s += row[i] * x[i]; }
                    z1[j] = s;
                    h1[j] = if s > 0.0 { s } else { 0.01 * s };
                }
                let mut z2 = [0.0_f32; V3_H2];
                let mut h2 = [0.0_f32; V3_H2];
                for k in 0..V3_H2 {
                    let row = &self.net.w2[k * V3_H1..(k + 1) * V3_H1];
                    let mut s = self.net.b2[k];
                    for j in 0..V3_H1 { s += row[j] * h1[j]; }
                    z2[k] = s;
                    h2[k] = if s > 0.0 { s } else { 0.01 * s };
                }
                let mut out = self.net.b3;
                for k in 0..V3_H2 { out += self.net.w3[k] * h2[k]; }
                let pred = 1.0 / (1.0 + (-out.clamp(-12.0, 12.0)).exp());
                let p_c = pred.clamp(1e-6, 1.0 - 1e-6);
                loss += -(target * p_c.ln() + (1.0 - target) * (1.0 - p_c).ln());

                let dout = pred - target;
                gb3 += dout;
                let mut dh2 = [0.0_f32; V3_H2];
                for k in 0..V3_H2 {
                    gw3[k] += dout * h2[k];
                    dh2[k] = dout * self.net.w3[k] * if z2[k] > 0.0 { 1.0 } else { 0.01 };
                }
                let mut dh1 = [0.0_f32; V3_H1];
                for k in 0..V3_H2 {
                    gb2[k] += dh2[k];
                    let d = dh2[k];
                    let wrow = &self.net.w2[k * V3_H1..(k + 1) * V3_H1];
                    let grow = &mut gw2[k * V3_H1..(k + 1) * V3_H1];
                    for j in 0..V3_H1 {
                        grow[j] += d * h1[j];
                        dh1[j] += d * wrow[j];
                    }
                }
                for j in 0..V3_H1 {
                    let d = dh1[j] * if z1[j] > 0.0 { 1.0 } else { 0.01 };
                    gb1[j] += d;
                    let grow = &mut gw1[j * V3_IN..(j + 1) * V3_IN];
                    for i in 0..V3_IN {
                        grow[i] += d * x[i];
                    }
                }
            }

            let inv = 1.0 / batch.len() as f32;
            self.step += 1;
            let b1c = 1.0 - 0.9_f32.powi(self.step);
            let b2c = 1.0 - 0.999_f32.powi(self.step);
            let upd = |w: &mut [f32], g: &[f32], m: &mut [f32], v: &mut [f32], decay: f32| {
                for i in 0..w.len() {
                    let gi = g[i] * inv;
                    m[i] = 0.9 * m[i] + 0.1 * gi;
                    v[i] = 0.999 * v[i] + 0.001 * gi * gi;
                    let mh = m[i] / b1c;
                    let vh = v[i] / b2c;
                    w[i] -= lr * (mh / (vh.sqrt() + 1e-8) + decay * w[i]);
                }
            };
            upd(&mut self.net.w1, &gw1, &mut self.mw1, &mut self.vw1, wd);
            upd(&mut self.net.b1, &gb1, &mut self.mb1, &mut self.vb1, 0.0);
            upd(&mut self.net.w2, &gw2, &mut self.mw2, &mut self.vw2, wd);
            upd(&mut self.net.b2, &gb2, &mut self.mb2, &mut self.vb2, 0.0);
            upd(&mut self.net.w3, &gw3, &mut self.mw3, &mut self.vw3, wd);
            let g3 = gb3 * inv;
            self.mb3 = 0.9 * self.mb3 + 0.1 * g3;
            self.vb3 = 0.999 * self.vb3 + 0.001 * g3 * g3;
            self.net.b3 -= lr * (self.mb3 / b1c) / ((self.vb3 / b2c).sqrt() + 1e-8);
            loss * inv
        }
    }

    // AdamW trainer for ProBidNetV3
    struct AdamBidV3 {
        net: ProBidNetV3,
        mw1: Vec<f32>, vw1: Vec<f32>, mb1: Vec<f32>, vb1: Vec<f32>,
        mw2: Vec<f32>, vw2: Vec<f32>, mb2: Vec<f32>, vb2: Vec<f32>,
        mw3: Vec<f32>, vw3: Vec<f32>, mb3: f32, vb3: f32,
        step: i32,
    }

    impl AdamBidV3 {
        fn new(net: ProBidNetV3) -> Self {
            Self {
                mw1: vec![0.0; V3_BID_H1 * V3_BID_IN], vw1: vec![0.0; V3_BID_H1 * V3_BID_IN],
                mb1: vec![0.0; V3_BID_H1], vb1: vec![0.0; V3_BID_H1],
                mw2: vec![0.0; V3_BID_H2 * V3_BID_H1], vw2: vec![0.0; V3_BID_H2 * V3_BID_H1],
                mb2: vec![0.0; V3_BID_H2], vb2: vec![0.0; V3_BID_H2],
                mw3: vec![0.0; V3_BID_H2], vw3: vec![0.0; V3_BID_H2],
                mb3: 0.0, vb3: 0.0, step: 0, net,
            }
        }

        fn train_batch(&mut self, batch: &[([f32; V3_BID_IN], f32)], lr: f32) -> f32 {
            let mut gw1 = vec![0.0_f32; V3_BID_H1 * V3_BID_IN];
            let mut gb1 = vec![0.0_f32; V3_BID_H1];
            let mut gw2 = vec![0.0_f32; V3_BID_H2 * V3_BID_H1];
            let mut gb2 = vec![0.0_f32; V3_BID_H2];
            let mut gw3 = vec![0.0_f32; V3_BID_H2];
            let mut gb3 = 0.0_f32;
            let mut mse = 0.0_f32;

            for &(ref x, target) in batch {
                let mut z1 = [0.0_f32; V3_BID_H1];
                let mut h1 = [0.0_f32; V3_BID_H1];
                for j in 0..V3_BID_H1 {
                    let row = &self.net.w1[j * V3_BID_IN..(j + 1) * V3_BID_IN];
                    let mut s = self.net.b1[j];
                    for i in 0..V3_BID_IN { s += row[i] * x[i]; }
                    z1[j] = s;
                    h1[j] = if s > 0.0 { s } else { 0.01 * s };
                }
                let mut z2 = [0.0_f32; V3_BID_H2];
                let mut h2 = [0.0_f32; V3_BID_H2];
                for k in 0..V3_BID_H2 {
                    let row = &self.net.w2[k * V3_BID_H1..(k + 1) * V3_BID_H1];
                    let mut s = self.net.b2[k];
                    for j in 0..V3_BID_H1 { s += row[j] * h1[j]; }
                    z2[k] = s;
                    h2[k] = if s > 0.0 { s } else { 0.01 * s };
                }
                let mut pred = self.net.b3;
                for k in 0..V3_BID_H2 { pred += self.net.w3[k] * h2[k]; }
                let err = pred - target;
                mse += err * err;
                // Smooth Huber-like clipped gradient for stability
                let dout = (2.0 * err).clamp(-10.0, 10.0);
                gb3 += dout;
                let mut dh2 = [0.0_f32; V3_BID_H2];
                for k in 0..V3_BID_H2 {
                    gw3[k] += dout * h2[k];
                    dh2[k] = dout * self.net.w3[k] * if z2[k] > 0.0 { 1.0 } else { 0.01 };
                }
                let mut dh1 = [0.0_f32; V3_BID_H1];
                for k in 0..V3_BID_H2 {
                    gb2[k] += dh2[k];
                    let d = dh2[k];
                    let wrow = &self.net.w2[k * V3_BID_H1..(k + 1) * V3_BID_H1];
                    let grow = &mut gw2[k * V3_BID_H1..(k + 1) * V3_BID_H1];
                    for j in 0..V3_BID_H1 {
                        grow[j] += d * h1[j];
                        dh1[j] += d * wrow[j];
                    }
                }
                for j in 0..V3_BID_H1 {
                    let d = dh1[j] * if z1[j] > 0.0 { 1.0 } else { 0.01 };
                    gb1[j] += d;
                    let grow = &mut gw1[j * V3_BID_IN..(j + 1) * V3_BID_IN];
                    for i in 0..V3_BID_IN { grow[i] += d * x[i]; }
                }
            }
            let inv = 1.0 / batch.len() as f32;
            self.step += 1;
            let b1c = 1.0 - 0.9_f32.powi(self.step);
            let b2c = 1.0 - 0.999_f32.powi(self.step);
            let upd = |w: &mut [f32], g: &[f32], m: &mut [f32], v: &mut [f32]| {
                for i in 0..w.len() {
                    let gi = g[i] * inv;
                    m[i] = 0.9 * m[i] + 0.1 * gi;
                    v[i] = 0.999 * v[i] + 0.001 * gi * gi;
                    w[i] -= lr * ((m[i] / b1c) / ((v[i] / b2c).sqrt() + 1e-8) + 1e-4 * w[i]);
                }
            };
            upd(&mut self.net.w1, &gw1, &mut self.mw1, &mut self.vw1);
            upd(&mut self.net.b1, &gb1, &mut self.mb1, &mut self.vb1);
            upd(&mut self.net.w2, &gw2, &mut self.mw2, &mut self.vw2);
            upd(&mut self.net.b2, &gb2, &mut self.mb2, &mut self.vb2);
            upd(&mut self.net.w3, &gw3, &mut self.mw3, &mut self.vw3);
            let g3 = gb3 * inv;
            self.mb3 = 0.9 * self.mb3 + 0.1 * g3;
            self.vb3 = 0.999 * self.vb3 + 0.001 * g3 * g3;
            self.net.b3 -= lr * (self.mb3 / b1c) / ((self.vb3 / b2c).sqrt() + 1e-8);
            mse * inv
        }
    }

    /// Run a single full 8-trick hand between Team A (seats 0,2) and Team B (seats 1,3) on an exact deal.
    /// `team_a_mode`: 0=Heuristic, 1=FrozenV2, 2=V3
    /// `team_b_mode`: 0=Heuristic, 1=FrozenV2, 2=V3
    fn play_arena_hand(
        deck: &[u8; 32],
        dealer: u8,
        team_a_mode: u8,
        team_b_mode: u8,
        v2: &FrozenV2,
        v3_val: &ProValueNetV3,
        v3_bid: &ProBidNetV3,
        v3_bid_cushion: f32,
        v3_samples: usize,
        v3_4trick_ab: bool,
        v3_pre_exp: bool,
        rng: &mut FastRng,
    ) -> (i32, bool, bool, bool) {
        // Deal first 4 cards per seat
        let mut h4 = [0u32; 4];
        for s in 0..4 {
            for k in 0..4 {
                h4[s] |= 1u32 << deck[s * 4 + k];
            }
        }
        // Bidding rotation starting at (dealer + 1) % 4
        let first_bidder = (dealer + 1) & 3;
        let mut passed = [false; 4];
        let mut high_bid = 0u8;
        let mut high_bidder = dealer;
        let mut turn = first_bidder;
        let mut passed_cnt = 0u8;

        for _ in 0..16 {
            let mode = if FastState::team_of(turn) == 0 { team_a_mode } else { team_b_mode };
            let next_b = if high_bid == 0 { 16 } else { high_bid + 1 };
            let partner_win = high_bid > 0 && FastState::team_of(high_bidder) == FastState::team_of(turn);
            let is_lead = turn == first_bidder;

            let max_willing = match mode {
                1 => {
                    let est = v2.predict_bid(h4[turn as usize]);
                    let has_kq = (0..4u8).any(|s| ((h4[turn as usize] >> (s * 8)) & 48) == 48);
                    ((est - 0.45 + if has_kq { 0.85 } else { 0.0 }).round() as u8).clamp(15, 28)
                }
                2 => {
                    let feat = extract_v3_bid_features(h4[turn as usize], is_lead, true, high_bid, partner_win, passed_cnt);
                    let est = v3_bid.predict_expected_pts(&feat);
                    let has_kq = (0..4u8).any(|s| ((h4[turn as usize] >> (s * 8)) & 48) == 48);
                    ((est - v3_bid_cushion + if has_kq { 0.75 } else { 0.0 }).round() as u8).clamp(15, 28)
                }
                _ => {
                    let feat = extract_v3_bid_features(h4[turn as usize], is_lead, true, 0, false, 0);
                    let est = 14.5 + feat[0] * 4.0 + feat[1] * 2.5 + feat[2] * 1.5;
                    (est.round() as u8).clamp(15, 24)
                }
            };

            let will_bid = next_b <= 28 && next_b <= max_willing && !(partner_win && max_willing < next_b + 2);
            if will_bid {
                high_bid = next_b;
                high_bidder = turn;
                if passed_cnt >= 3 || high_bid == 28 { break; }
            } else {
                passed[turn as usize] = true;
                passed_cnt += 1;
                if passed_cnt == 3 {
                    if high_bid == 0 {
                        high_bid = 16;
                        high_bidder = (0..4u8).find(|&s| !passed[s as usize]).unwrap_or(dealer);
                    }
                    break;
                }
            }
            for step in 1..=4u8 {
                let nxt = (turn + step) & 3;
                if !passed[nxt as usize] { turn = nxt; break; }
            }
        }

        // Trump selection
        let (trump_suit, rev_en) = choose_fast_trump(h4[high_bidder as usize], high_bidder == first_bidder);

        // Deal remaining 4 cards per seat
        let mut hands = h4;
        for s in 0..4 {
            for k in 0..4 {
                hands[s] |= 1u32 << deck[16 + s * 4 + k];
            }
        }

        let mut st = FastState {
            hands,
            played: 0,
            voids: [0; 4], failed_beat: [0; 4],
            dealer,
            bidder: high_bidder,
            bid: high_bid,
            eff_bid: high_bid,
            stakes: 1,
            trump_suit,
            reverse_enabled: rev_en,
            trump_exposed: false,
            exposed_at_idx: -1,
            reverse_at_idx: -1,
            must_play_trump: -1,
            marriage_done: false,
            seventh_card: -1,
            trick_cards: [0; 4],
            trick_seats: [0; 4],
            trick_len: 0,
            leader: first_bidder,
            turn: first_bidder,
            tricks_done: 0,
            pts: [0, 0],
        };

        while st.tricks_done < 8 {
            let s = st.turn;
            st.check_auto_marriage(s);
            let mode = if FastState::team_of(s) == 0 { team_a_mode } else { team_b_mode };
            let (sh, c) = match mode {
                1 => v2.choose_play(&st, 8, rng),
                2 => choose_v3_fast_play(&st, v3_val, v3_samples, v3_4trick_ab, v3_pre_exp, rng),
                _ => fast_heuristic_action(&st),
            };
            if sh {
                st.expose_trump(s);
                st.check_auto_marriage(s);
            } else {
                st.play_card(c);
            }
        }

        let a_set_pts = st.set_points_for_team(0);
        let a_was_bidder = FastState::team_of(st.bidder) == 0;
        let bt_won = st.bidding_team_won();
        (a_set_pts, a_was_bidder, bt_won, rev_en)
    }

    /// Parallel duplicate-deal head-to-head team match (each deal played TWICE swapping Team A & Team B seats!).
    fn eval_head_to_head(
        num_hands: usize,
        seed_base: u64,
        v2: &FrozenV2,
        v3_val: &ProValueNetV3,
        v3_bid: &ProBidNetV3,
        v3_bid_cushion: f32,
        v3_samples: usize,
        v3_4trick_ab: bool,
        v3_pre_exp: bool,
        opp_mode: u8, // 1=FrozenV2, 0=Heuristic
    ) -> (f64, f64, f64, f64, f64, f64) {
        let pairs = num_hands / 2;
        let threads = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2);
        let chunk = (pairs + threads - 1) / threads;

        let res: Vec<(i64, usize, usize, usize, usize, usize, usize, usize, usize)> = std::thread::scope(|sc| {
            let mut handles = Vec::new();
            for tid in 0..threads {
                let start = tid * chunk;
                let end = ((tid + 1) * chunk).min(pairs);
                handles.push(sc.spawn(move || {
                    let mut rng = FastRng::new(seed_base + (tid as u64) * 999983);
                    let mut v3_set_pts = 0i64;
                    let mut v3_hand_wins = 0usize;
                    let mut v3_bids = 0usize;
                    let mut v3_bid_makes = 0usize;
                    let mut v3_defs = 0usize;
                    let mut v3_def_sets = 0usize;
                    let mut v3_revs = 0usize;
                    let mut v3_rev_wins = 0usize;
                    let mut total = 0usize;

                    for p in start..end {
                        let deck = rng.shuffle_deck();
                        let dealer = (p & 3) as u8;

                        // Game 1: V3 is Team A, Opp is Team B
                        let (pts1, a_bid1, bt_won1, rev1) = play_arena_hand(
                            &deck, dealer, 2, opp_mode, v2, v3_val, v3_bid,
                            v3_bid_cushion, v3_samples, v3_4trick_ab, v3_pre_exp, &mut rng,
                        );
                        v3_set_pts += pts1 as i64;
                        if pts1 > 0 { v3_hand_wins += 1; }
                        if a_bid1 {
                            v3_bids += 1;
                            if bt_won1 { v3_bid_makes += 1; }
                            if rev1 { v3_revs += 1; if bt_won1 { v3_rev_wins += 1; } }
                        } else {
                            v3_defs += 1;
                            if !bt_won1 { v3_def_sets += 1; }
                        }
                        total += 1;

                        // Game 2 (seat-swapped duplicate): Opp is Team A, V3 is Team B
                        let (pts2, a_bid2, bt_won2, rev2) = play_arena_hand(
                            &deck, dealer, opp_mode, 2, v2, v3_val, v3_bid,
                            v3_bid_cushion, v3_samples, v3_4trick_ab, v3_pre_exp, &mut rng,
                        );
                        let v3_p2 = -pts2;
                        v3_set_pts += v3_p2 as i64;
                        if v3_p2 > 0 { v3_hand_wins += 1; }
                        if !a_bid2 {
                            v3_bids += 1;
                            if bt_won2 { v3_bid_makes += 1; }
                            if rev2 { v3_revs += 1; if bt_won2 { v3_rev_wins += 1; } }
                        } else {
                            v3_defs += 1;
                            if !bt_won2 { v3_def_sets += 1; }
                        }
                        total += 1;
                    }
                    (v3_set_pts, v3_hand_wins, v3_bids, v3_bid_makes, v3_defs, v3_def_sets, v3_revs, v3_rev_wins, total)
                }));
            }
            handles.into_iter().map(|h| h.join().unwrap()).collect()
        });

        let mut set_pts = 0i64;
        let mut wins = 0usize; let mut bids = 0usize; let mut bmakes = 0usize;
        let mut defs = 0usize; let mut dsets = 0usize; let mut revs = 0usize; let mut rwins = 0usize;
        let mut tot = 0usize;
        for r in res {
            set_pts += r.0; wins += r.1; bids += r.2; bmakes += r.3;
            defs += r.4; dsets += r.5; revs += r.6; rwins += r.7; tot += r.8;
        }
        let win_pct = 100.0 * wins as f64 / tot as f64;
        let sp_per_100 = 100.0 * set_pts as f64 / tot as f64;
        let bid_make_pct = 100.0 * bmakes as f64 / bids.max(1) as f64;
        let def_set_pct = 100.0 * dsets as f64 / defs.max(1) as f64;
        let rev_win_pct = 100.0 * rwins as f64 / revs.max(1) as f64;
        let bid_share = 100.0 * bids as f64 / tot as f64;
        (win_pct, sp_per_100, bid_make_pct, def_set_pct, rev_win_pct, bid_share)
    }

    /// Generate `n_hands` parallel self-play hands, returning (value_samples, bid_samples).
    /// Policy mode: 0 = fast heuristic + eps, 1 = 1-ply value-net greedy + eps, 2 = 1-ply value-net + 4-trick exact AB + eps
    fn generate_selfplay_data(
        n_hands: usize,
        seed_base: u64,
        policy_mode: u8,
        eps: f32,
        td_blend: f32, // 0.0 = pure Monte-Carlo outcome, 0.25 = 75% MC + 25% next-state V
        vnet: &ProValueNetV3,
        bnet: &ProBidNetV3,
        sample_stride: usize, // keep 1 of every `sample_stride` value transitions to fit RAM cleanly
    ) -> (Vec<([f32; V3_IN], f32)>, Vec<([f32; V3_BID_IN], f32)>) {
        let threads = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2);
        let chunk = (n_hands + threads - 1) / threads;

        let parts: Vec<(Vec<([f32; V3_IN], f32)>, Vec<([f32; V3_BID_IN], f32)>)> = std::thread::scope(|sc| {
            let mut handles = Vec::new();
            for tid in 0..threads {
                let start = tid * chunk;
                let end = ((tid + 1) * chunk).min(n_hands);
                handles.push(sc.spawn(move || {
                    let mut rng = FastRng::new(seed_base + (tid as u64) * 1000003);
                    let mut v_data = Vec::with_capacity(((end - start) * 12) / sample_stride.max(1));
                    let mut b_data = Vec::with_capacity((end - start) / 2);
                    let mut tr_counter = 0usize;

                    for hidx in start..end {
                        let deck = rng.shuffle_deck();
                        let dealer = (hidx & 3) as u8;
                        let first_bidder = (dealer + 1) & 3;
                        let mut h4 = [0u32; 4];
                        for s in 0..4 {
                            for k in 0..4 { h4[s] |= 1u32 << deck[s * 4 + k]; }
                        }

                        // Self-play bidding
                        let mut passed = [false; 4];
                        let mut high_bid = 0u8;
                        let mut high_bidder = dealer;
                        let mut turn = first_bidder;
                        let mut passed_cnt = 0u8;
                        let mut winner_bid_feat = [0.0_f32; V3_BID_IN];

                        for _ in 0..16 {
                            let next_b = if high_bid == 0 { 16 } else { high_bid + 1 };
                            let partner_win = high_bid > 0 && FastState::team_of(high_bidder) == FastState::team_of(turn);
                            let is_lead = turn == first_bidder;
                            let bfeat = extract_v3_bid_features(h4[turn as usize], is_lead, true, high_bid, partner_win, passed_cnt);
                            let est = if policy_mode == 0 {
                                14.2 + bfeat[0] * 4.2 + bfeat[1] * 2.6 + bfeat[2] * 1.4 + bfeat[24] * 0.7
                            } else {
                                bnet.predict_expected_pts(&bfeat)
                            };
                            let jitter = (rng.next_f32() - 0.5) * 1.6;
                            let max_w = ((est - 0.35 + jitter).round() as u8).clamp(15, 28);
                            let will_bid = next_b <= 28 && next_b <= max_w && !(partner_win && max_w < next_b + 2);
                            if will_bid {
                                high_bid = next_b;
                                high_bidder = turn;
                                winner_bid_feat = bfeat;
                                if passed_cnt >= 3 || high_bid == 28 { break; }
                            } else {
                                passed[turn as usize] = true;
                                passed_cnt += 1;
                                if passed_cnt == 3 {
                                    if high_bid == 0 {
                                        high_bid = 16;
                                        high_bidder = (0..4u8).find(|&s| !passed[s as usize]).unwrap_or(dealer);
                                        winner_bid_feat = extract_v3_bid_features(
                                            h4[high_bidder as usize], high_bidder == first_bidder, true, 0, false, 3,
                                        );
                                    }
                                    break;
                                }
                            }
                            for step in 1..=4u8 {
                                let nxt = (turn + step) & 3;
                                if !passed[nxt as usize] { turn = nxt; break; }
                            }
                        }

                        let (trump_suit, rev_en) = choose_fast_trump(h4[high_bidder as usize], high_bidder == first_bidder);
                        let mut hands = h4;
                        for s in 0..4 {
                            for k in 0..4 { hands[s] |= 1u32 << deck[16 + s * 4 + k]; }
                        }
                        let mut st = FastState {
                            hands, played: 0, voids: [0; 4], failed_beat: [0; 4], dealer, bidder: high_bidder,
                            bid: high_bid, eff_bid: high_bid, stakes: 1, trump_suit,
                            reverse_enabled: rev_en, trump_exposed: false,
                            exposed_at_idx: -1, reverse_at_idx: -1, must_play_trump: -1,
                            marriage_done: false, seventh_card: -1,
                            trick_cards: [0; 4], trick_seats: [0; 4], trick_len: 0,
                            leader: first_bidder, turn: first_bidder, tricks_done: 0, pts: [0, 0],
                        };

                        let mut traj: Vec<([f32; V3_IN], usize, f32)> = Vec::with_capacity(16);

                        while st.tricks_done < 8 {
                            let s = st.turn;
                            st.check_auto_marriage(s);
                            let my_team = FastState::team_of(s);

                            // Record state feature (tricks 1..7)
                            tr_counter += 1;
                            if st.tricks_done >= 1 && (tr_counter % sample_stride == 0) {
                                let feat = extract_v3_state_features(&st, s);
                                let v_est = if td_blend > 0.0 { vnet.predict(&feat) } else { 0.5 };
                                traj.push((feat, my_team, v_est));
                            }

                            let (sh, c) = if rng.next_f32() < eps {
                                let legal = st.legal_mask(s);
                                let cnt = legal.count_ones();
                                let pick = (rng.next_u64() as u32) % cnt;
                                let mut m = legal;
                                for _ in 0..pick { m &= m - 1; }
                                (false, m.trailing_zeros() as u8)
                            } else if policy_mode == 0 {
                                fast_heuristic_action(&st)
                            } else {
                                // Fast 1-ply self-play policy using vnet (plus 4-trick AB on last 3 tricks for mode 2)
                                let legal = st.legal_mask(s);
                                if legal.count_ones() == 1 && !st.can_show_trump(s) {
                                    (false, legal.trailing_zeros() as u8)
                                } else if policy_mode == 2 && st.trump_exposed && st.hands[s as usize].count_ones() <= 3 {
                                    let mut best_c = legal.trailing_zeros() as u8;
                                    let mut best_v = i32::MIN;
                                    let mut m = legal;
                                    while m != 0 {
                                        let cand = m.trailing_zeros() as u8;
                                        m &= m - 1;
                                        let mut ch = st;
                                        ch.play_card(cand);
                                        let mut nodes = 0usize;
                                        let v = alphabeta_4trick(&ch, my_team, i32::MIN + 1, i32::MAX - 1, &mut nodes, 600);
                                        if v > best_v { best_v = v; best_c = cand; }
                                    }
                                    (false, best_c)
                                } else {
                                    // 1-ply neural evaluation over all legal actions (including Show Trump!)
                                    let mut best_act = (false, legal.trailing_zeros() as u8);
                                    let mut best_sc = -1e9_f32;
                                    let mut m = legal;
                                    while m != 0 {
                                        let cand = m.trailing_zeros() as u8;
                                        m &= m - 1;
                                        let mut ch = st;
                                        ch.play_card(cand);
                                        let sc = if ch.tricks_done >= 8 {
                                            let bt = FastState::team_of(ch.bidder);
                                            if (my_team == bt) == ch.bidding_team_won() { 1.0 } else { 0.0 }
                                        } else {
                                            vnet.predict(&extract_v3_state_features(&ch, s))
                                        };
                                        if sc > best_sc { best_sc = sc; best_act = (false, cand); }
                                    }
                                    if st.can_show_trump(s) {
                                        let mut ch = st;
                                        ch.expose_trump(s);
                                        ch.check_auto_marriage(s);
                                        let (_, c2) = fast_heuristic_action(&ch);
                                        ch.play_card(c2);
                                        let sc = vnet.predict(&extract_v3_state_features(&ch, s));
                                        if sc > best_sc { best_act = (true, 0); }
                                    }
                                    best_act
                                }
                            };

                            if sh {
                                st.expose_trump(s);
                                st.check_auto_marriage(s);
                            } else {
                                st.play_card(c);
                            }
                        }

                        let bt = FastState::team_of(st.bidder);
                        let bt_won = st.bidding_team_won();
                        let bpts = st.pts[bt] as f32;

                        // Store bidding sample (every 2nd hand to keep memory lean)
                        if (hidx & 1) == 0 {
                            b_data.push((winner_bid_feat, bpts));
                        }

                        // Label trajectory with MC outcome (optionally TD-blended with later v_est)
                        for (i, (feat, team, _)) in traj.iter().enumerate() {
                            let won = if *team == bt { bt_won } else { !bt_won };
                            let mc_y = if won { 1.0_f32 } else { 0.0_f32 };
                            let y = if td_blend > 0.0 && i + 1 < traj.len() && traj[i + 1].1 == *team {
                                (1.0 - td_blend) * mc_y + td_blend * traj[i + 1].2
                            } else {
                                mc_y
                            };
                            v_data.push((*feat, y));
                        }
                    }
                    (v_data, b_data)
                }));
            }
            handles.into_iter().map(|h| h.join().unwrap()).collect()
        });

        let mut all_v = Vec::new();
        let mut all_b = Vec::new();
        for (mut v, mut b) in parts {
            all_v.append(&mut v);
            all_b.append(&mut b);
        }
        (all_v, all_b)
    }

    fn eval_val_metrics(net: &ProValueNetV3, val: &[([f32; V3_IN], f32)]) -> (f32, f32) {
        let mut loss = 0.0_f32;
        let mut correct = 0usize;
        for &(ref x, y) in val {
            let p = net.predict(x).clamp(1e-6, 1.0 - 1e-6);
            loss += -(y * p.ln() + (1.0 - y) * (1.0 - p).ln());
            if (p >= 0.5) == (y >= 0.5) { correct += 1; }
        }
        (loss / val.len() as f32, 100.0 * correct as f32 / val.len() as f32)
    }

    fn eval_bid_rmse(net: &ProBidNetV3, val: &[([f32; V3_BID_IN], f32)]) -> f32 {
        let mse: f32 = val.iter().map(|(x, y)| {
            let e = net.predict_expected_pts(x) - *y;
            e * e
        }).sum::<f32>() / val.len() as f32;
        mse.sqrt()
    }

    fn export_v3_weights(vnet: &ProValueNetV3, bnet: &ProBidNetV3, path: &Path) {
        use std::fmt::Write;
        let mut s = String::with_capacity(280_000);
        writeln!(s, "// Auto-generated Pro RL v3 weights (1M+ hand multi-gen self-play):").unwrap();
        writeln!(s, "// ProValueNetV3 ({}->{}->{}->1, 17,089 weights) + ProBidNetV3 ({}->{}->{}->1, 4,225 weights).",
            V3_IN, V3_H1, V3_H2, V3_BID_IN, V3_BID_H1, V3_BID_H2).unwrap();
        writeln!(s, "pub const V3_IN_DIM: usize = {};", V3_IN).unwrap();
        writeln!(s, "pub const V3_H1_DIM: usize = {};", V3_H1).unwrap();
        writeln!(s, "pub const V3_H2_DIM: usize = {};", V3_H2).unwrap();
        writeln!(s, "pub const V3_BID_IN_DIM: usize = {};", V3_BID_IN).unwrap();
        writeln!(s, "pub const V3_BID_H1_DIM: usize = {};", V3_BID_H1).unwrap();
        writeln!(s, "pub const V3_BID_H2_DIM: usize = {};", V3_BID_H2).unwrap();

        let write_arr = |out: &mut String, name: &str, data: &[f32]| {
            writeln!(out, "pub static {}: [f32; {}] = [", name, data.len()).unwrap();
            for chunk in data.chunks(10) {
                out.push_str("    ");
                for &v in chunk { write!(out, "{:.5}, ", v).unwrap(); }
                out.push('\n');
            }
            writeln!(out, "];").unwrap();
        };
        write_arr(&mut s, "V3_W1", &vnet.w1);
        write_arr(&mut s, "V3_B1", &vnet.b1);
        write_arr(&mut s, "V3_W2", &vnet.w2);
        write_arr(&mut s, "V3_B2", &vnet.b2);
        write_arr(&mut s, "V3_W3", &vnet.w3);
        writeln!(s, "pub const V3_B3: f32 = {:.5};", vnet.b3).unwrap();

        write_arr(&mut s, "V3_BW1", &bnet.w1);
        write_arr(&mut s, "V3_BB1", &bnet.b1);
        write_arr(&mut s, "V3_BW2", &bnet.w2);
        write_arr(&mut s, "V3_BB2", &bnet.b2);
        write_arr(&mut s, "V3_BW3", &bnet.w3);
        writeln!(s, "pub const V3_BB3: f32 = {:.5};", bnet.b3).unwrap();

        std::fs::write(path, s).expect("write rl_weights_v3.rs");
    }

    #[test]
    #[ignore]
    fn run_v3_million_hand_selfplay_and_100k_eval() {
        let t0 = Instant::now();
        let v2 = FrozenV2::load();
        let mut adam_v = AdamV3::new(ProValueNetV3::new_random(2026112601));
        let mut adam_b = AdamBidV3::new(ProBidNetV3::new_random(2026112602));

        println!("=========================================================================");
        println!("PRO RL v3: 1,050,000-HAND MULTI-GEN SELF-PLAY + 100,000-HAND EVALUATION");
        println!("Hardware threads: {} | ValueNet: 128->96->48->1 (17,089w) | BidNet: 32->64->32->1 (4,225w)",
            std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2));
        println!("=========================================================================");

        // Fixed held-out validation set (15,000 unseen hands) for apples-to-apples tracking across generations!
        let (val_v, val_b) = generate_selfplay_data(15_000, 777777, 0, 0.05, 0.0, &adam_v.net, &adam_b.net, 4);
        println!("Held-out validation set: {} state transitions, {} opening hands ({:.1}s)",
            val_v.len(), val_b.len(), t0.elapsed().as_secs_f32());

        // 3 Iterative Self-Play Generations totaling 1,050,000 simulated hands!
        // Gen 1: 400,000 fast self-play hands (bootstrap exact 128-dim card planes + 32-dim opening-lead bid net)
        // Gen 2: 350,000 neural self-play hands (1-ply V3 policy + eps=0.12 + TD(0.20) blend + Show Trump eval)
        // Gen 3: 300,000 neural + exact-endgame self-play hands (1-ply V3 + 3-trick AB + eps=0.06 + cosine LR fine-tune)
        let gens: [(usize, u8, f32, f32, usize, f32, usize, &str); 3] = [
            (400_000, 0, 0.10, 0.00, 12, 0.0022, 6, "Gen 1: 400k Bootstrap (128-dim Bitmasks + Opening-Lead BidNet)"),
            (350_000, 1, 0.12, 0.20, 10, 0.0014, 6, "Gen 2: 350k Neural Self-Play (TD-Blend + Pre-Exposure ShowTrump)"),
            (300_000, 2, 0.06, 0.15,  9, 0.0007, 6, "Gen 3: 300k Neural+Exact-AB Self-Play (Cosine Fine-Tune)"),
        ];

        let mut total_hands_sim = 0usize;
        let mut total_transitions_trained = 0usize;

        for (gi, &(nhands, pmode, eps, tdb, stride, base_lr, epochs, label)) in gens.iter().enumerate() {
            let tg = Instant::now();
            println!("\n--- {} ---", label);
            let (mut tv, mut tb) = generate_selfplay_data(
                nhands, 100_000 + (gi as u64) * 50_000, pmode, eps, tdb, &adam_v.net, &adam_b.net, stride,
            );
            total_hands_sim += nhands;
            total_transitions_trained += tv.len();
            let sim_s = tg.elapsed().as_secs_f32();
            println!("  Simulated {} hands ({:.0} hands/s) -> {} value samples, {} bid samples",
                nhands, nhands as f32 / sim_s.max(0.01), tv.len(), tb.len());

            // Train ValueNet with cosine LR decay
            let mut shuf_rng = FastRng::new(9001 + gi as u64);
            let bs = 256usize;
            for ep in 0..epochs {
                // Fisher-Yates shuffle
                for i in (1..tv.len()).rev() {
                    let j = (shuf_rng.next_u64() as usize) % (i + 1);
                    tv.swap(i, j);
                }
                let cos_mult = 0.5 * (1.0 + (std::f32::consts::PI * ep as f32 / epochs as f32).cos());
                let lr = base_lr * (0.15 + 0.85 * cos_mult);
                let mut tr_loss = 0.0_f32;
                let mut nb = 0usize;
                for ch in tv.chunks(bs) {
                    if ch.len() < 32 { continue; }
                    tr_loss += adam_v.train_batch(ch, lr, 1.5e-4);
                    nb += 1;
                }
                if ep == epochs - 1 {
                    let (vl, va) = eval_val_metrics(&adam_v.net, &val_v);
                    println!("  ValueNet ep {}/{}: train_bce={:.4} | val_bce={:.4} | val_acc={:.2}%",
                        ep + 1, epochs, tr_loss / nb.max(1) as f32, vl, va);
                }
            }

            // Train BidNet
            for ep in 0..epochs {
                for i in (1..tb.len()).rev() {
                    let j = (shuf_rng.next_u64() as usize) % (i + 1);
                    tb.swap(i, j);
                }
                let lr = base_lr * 1.2 * (1.0 - 0.75 * ep as f32 / epochs as f32);
                for ch in tb.chunks(256) {
                    if ch.len() < 32 { continue; }
                    adam_b.train_batch(ch, lr);
                }
                if ep == epochs - 1 {
                    let rmse = eval_bid_rmse(&adam_b.net, &val_b);
                    println!("  BidNet   ep {}/{}: val_RMSE={:.3} pts", ep + 1, epochs, rmse);
                }
            }

            // Quick 10,000-hand duplicate-deal arena vs Frozen Pro RL v2 after EACH generation!
            let use_ab4 = gi >= 2;
            let use_pre = gi >= 1;
            let (wp, sp100, bm, ds, rw, _bs) = eval_head_to_head(
                10_000, 5_000_000 + (gi as u64) * 100_000, &v2, &adam_v.net, &adam_b.net,
                0.45, 8, use_ab4, use_pre, 1,
            );
            println!("  [Gen {} Checkpoint vs Pro RL v2 (10k dup hands)] Win={:.2}% | SetPts/100={:+.2} | BidMake={:.1}% | DefSet={:.1}% | RevWin={:.1}% ({:.1}s)",
                gi + 1, wp, sp100, bm, ds, rw, tg.elapsed().as_secs_f32());
        }

        // Algorithmic Sweep on Gen 3: test bidding safety cushion & pre-exposure RL + 4-trick AB
        println!("\n--- Algorithmic Optimization Sweep (10k dup hands each vs Pro RL v2) ---");
        let mut best_cushion = 0.45_f32;
        let mut best_sp = -999.0_f64;
        for &cush in &[0.25_f32, 0.45_f32, 0.65_f32] {
            let (wp, sp100, bm, ds, rw, bs) = eval_head_to_head(
                10_000, 8_800_000, &v2, &adam_v.net, &adam_b.net,
                cush, 8, true, true, 1,
            );
            println!("  cushion={:.2}: Win={:.2}% | SetPts/100={:+.2} | BidMake={:.1}% (share {:.1}%) | DefSet={:.1}% | RevWin={:.1}%",
                cush, wp, sp100, bm, bs, ds, rw);
            if sp100 > best_sp {
                best_sp = sp100;
                best_cushion = cush;
            }
        }
        println!("  Selected optimal bid cushion: {:.2}", best_cushion);

        // Save best weights to crates/twenty_nine_core/src/rl_weights_v3.rs
        let out_path = Path::new("src/rl_weights_v3.rs");
        export_v3_weights(&adam_v.net, &adam_b.net, out_path);
        println!("Exported Pro RL v3 weights to {:?}!", out_path);

        // =========================================================================
        // FINAL HELD-OUT 100,000-HAND HEAD-TO-HEAD TEAM EVALUATION (UNSEEN SEEDS!)
        // =========================================================================
        println!("\n=========================================================================");
        println!("FINAL 100,000-HAND HELD-OUT EVALUATION: Pro RL v3 vs Frozen Pro RL v2");
        println!("(50,000 unseen duplicate deals x 2 seat-swapped games = 100,000 hands)");
        println!("=========================================================================");
        let te = Instant::now();
        let (wp, sp100, bm, ds, rw, bsh) = eval_head_to_head(
            100_000, 99_999_999, &v2, &adam_v.net, &adam_b.net,
            best_cushion, 8, true, true, 1,
        );
        let eval_s = te.elapsed().as_secs_f32();
        println!("  Pro RL v3 vs Pro RL v2 (100,000 hands in {:.1}s, {:.0} hands/s):", eval_s, 100_000.0 / eval_s.max(0.1));
        println!("    Hand Win Rate        : {:.2}% (vs 50.00% even)", wp);
        println!("    Net Set Points / 100 : {:+.2} set pts / 100 hands", sp100);
        println!("    V3 Bid Make Rate     : {:.2}% (bid share {:.1}%)", bm, bsh);
        println!("    V3 Defend Set Rate   : {:.2}%", ds);
        println!("    V3 Reverse Win Rate  : {:.2}%", rw);

        // Also run 20,000-hand check vs Normal Heuristic
        let (wp_n, sp_n, bm_n, ds_n, rw_n, _) = eval_head_to_head(
            20_000, 77_777_777, &v2, &adam_v.net, &adam_b.net,
            best_cushion, 8, true, true, 0,
        );
        println!("  Pro RL v3 vs Normal Heuristic (20,000 dup hands):");
        println!("    Hand Win Rate: {:.2}% | SetPts/100: {:+.2} | BidMake: {:.2}% | DefSet: {:.2}% | RevWin: {:.2}%",
            wp_n, sp_n, bm_n, ds_n, rw_n);
        println!("TOTAL TRAINING HANDS SIMULATED: {} | TOTAL TRANSITIONS TRAINED: {} | TOTAL TIME: {:.1}s",
            total_hands_sim, total_transitions_trained, t0.elapsed().as_secs_f32());
    }

    #[test]
    #[ignore]
    fn eval_v3_100k_head_to_head() {
        let t0 = Instant::now();
        let v2 = FrozenV2::load();
        let v3_val = ProValueNetV3::from_embedded();
        let v3_bid = ProBidNetV3::from_embedded();

        // 1. Validation metrics on 20,000 held-out unseen hands
        let (val_v, val_b) = generate_selfplay_data(20_000, 888888, 0, 0.0, 0.0, &v3_val, &v3_bid, 4);
        let (vl, va) = eval_val_metrics(&v3_val, &val_v);
        let brmse = eval_bid_rmse(&v3_bid, &val_b);
        println!("=== PRO RL v3 (1.05M-hand trained) VALIDATION METRICS (20k unseen hands) ===");
        println!("  ValueNet (128->96->48->1, 17,089w): Val BCE = {:.4} | Val Accuracy = {:.2}%", vl, va);
        println!("  BidNet   (32->64->32->1,   4,225w): Val RMSE = {:.3} pts", brmse);

        // 2. Algorithmic ablation (10k duplicate hands each vs Frozen Pro RL v2)
        println!("\n=== ALGORITHMIC ABLATION vs FROZEN PRO RL v2 (10,000 duplicate hands each) ===");
        let configs = [
            ("V3-Base (v3 nets, 3-trick AB, post-exp only)",  0.45_f32, 4usize, false, false),
            ("V3-Pre  (+ Pre-Exposure RL & ShowTrump eval)",  0.45_f32, 4usize, false, true),
            ("V3-AB4  (+ 4-Trick Exact Alpha-Beta Endgame)",  0.45_f32, 4usize, true,  true),
            ("V3-Cush (+ Tuned Bid Cushion = 0.65)",          0.65_f32, 4usize, true,  true),
            ("V3-Cush (+ Tuned Bid Cushion = 0.25)",          0.25_f32, 4usize, true,  true),
        ];
        let mut best_cfg = configs[2];
        let mut best_sp = -999.0_f64;
        for cfg in configs {
            let (wp, sp100, bm, ds, rw, bs) = eval_head_to_head(
                10_000, 31_415_926, &v2, &v3_val, &v3_bid, cfg.1, cfg.2, cfg.3, cfg.4, 1,
            );
            println!("  {:47} | Win={:.2}% | SetPts/100={:+.2} | BidMake={:.1}% (sh {:.1}%) | DefSet={:.1}% | RevWin={:.1}%",
                cfg.0, wp, sp100, bm, bs, ds, rw);
            if sp100 > best_sp {
                best_sp = sp100;
                best_cfg = cfg;
            }
        }
        println!("  --> Best config: {} (SetPts/100 = {:+.2})", best_cfg.0, best_sp);

        // 3. FINAL 100,000-HAND HELD-OUT EVALUATION (50,000 unseen deals x 2 seat swaps = 100,000 hands!)
        println!("\n=========================================================================");
        println!("FINAL 100,000-HAND HELD-OUT EVALUATION: Pro RL v3 vs Frozen Pro RL v2");
        println!("=========================================================================");
        let te = Instant::now();
        let (wp, sp100, bm, ds, rw, bsh) = eval_head_to_head(
            100_000, 99_999_999, &v2, &v3_val, &v3_bid, best_cfg.1, 4, best_cfg.3, best_cfg.4, 1,
        );
        let es = te.elapsed().as_secs_f32();
        println!("  100,000 hands completed in {:.1}s ({:.0} hands/s):", es, 100_000.0 / es.max(0.1));
        println!("    Hand Win Rate        : {:.2}% (vs 50.00% even)", wp);
        println!("    Net Set Points / 100 : {:+.2} set pts / 100 hands", sp100);
        println!("    V3 Bid Make Rate     : {:.2}% (bid share {:.1}%)", bm, bsh);
        println!("    V3 Defend Set Rate   : {:.2}%", ds);
        println!("    V3 Reverse Win Rate  : {:.2}%", rw);

        // 4. Also 20,000-hand check vs Normal Heuristic
        let (wp_n, sp_n, bm_n, ds_n, rw_n, _) = eval_head_to_head(
            20_000, 77_777_777, &v2, &v3_val, &v3_bid, best_cfg.1, 4, best_cfg.3, best_cfg.4, 0,
        );
        println!("\n  Pro RL v3 vs Normal Heuristic (20,000 duplicate hands):");
        println!("    Hand Win Rate: {:.2}% | SetPts/100: {:+.2} | BidMake: {:.2}% | DefSet: {:.2}% | RevWin: {:.2}%",
            wp_n, sp_n, bm_n, ds_n, rw_n);
        println!("Total eval wall time: {:.1}s", t0.elapsed().as_secs_f32());
    }


    #[test]
    #[ignore]
    fn run_v3_iter2_refine_and_100k_eval() {
        let t0 = Instant::now();
        let v2 = FrozenV2::load();
        let mut adam_v = AdamV3::new(ProValueNetV3::from_embedded());
        let mut adam_b = AdamBidV3::new(ProBidNetV3::from_embedded());

        println!("=========================================================================");
        println!("PRO RL v3.2 (ITERATION 2): GEN-4 CLEAN FINE-TUNE + BAYESIAN PIMC + 100K EVAL");
        println!("=========================================================================");

        // Fixed held-out validation set (20k unseen hands, zero exploration)
        let (val_v, val_b) = generate_selfplay_data(20_000, 888888, 0, 0.0, 0.0, &adam_v.net, &adam_b.net, 4);
        let (vl0, va0) = eval_val_metrics(&adam_v.net, &val_v);
        let br0 = eval_bid_rmse(&adam_b.net, &val_b);
        println!("Before Gen-4 fine-tune: Val BCE={:.4} | Val Acc={:.2}% | Bid Val RMSE={:.3} pts", vl0, va0, br0);

        // Gen 4: 300,000 clean zero-blunder self-play hands (unbiased BidNet + exact endgame ValueNet!)
        let tg = Instant::now();
        let (mut tv, mut tb) = generate_selfplay_data(
            300_000, 444_444, 0, 0.02, 0.10, &adam_v.net, &adam_b.net, 8,
        );
        println!("Gen-4 simulated 300,000 clean hands ({:.0} hands/s) -> {} value samples, {} unbiased bid samples",
            300_000.0 / tg.elapsed().as_secs_f32().max(0.1), tv.len(), tb.len());

        let mut shuf_rng = FastRng::new(20261127);
        for ep in 0..5 {
            for i in (1..tv.len()).rev() {
                let j = (shuf_rng.next_u64() as usize) % (i + 1);
                tv.swap(i, j);
            }
            let lr = 0.00055 * (1.0 - 0.75 * ep as f32 / 5.0);
            for ch in tv.chunks(256) {
                if ch.len() < 32 { continue; }
                adam_v.train_batch(ch, lr, 1.5e-4);
            }
            for i in (1..tb.len()).rev() {
                let j = (shuf_rng.next_u64() as usize) % (i + 1);
                tb.swap(i, j);
            }
            let blr = 0.0012 * (1.0 - 0.75 * ep as f32 / 5.0);
            for ch in tb.chunks(256) {
                if ch.len() < 32 { continue; }
                adam_b.train_batch(ch, blr);
            }
        }
        let (vl1, va1) = eval_val_metrics(&adam_v.net, &val_v);
        let br1 = eval_bid_rmse(&adam_b.net, &val_b);
        println!("After  Gen-4 fine-tune: Val BCE={:.4} ({:+.4}) | Val Acc={:.2}% ({:+.2}%) | Bid Val RMSE={:.3} pts ({:+.3})",
            vl1, vl1 - vl0, va1, va1 - va0, br1, br1 - br0);

        // Save improved weights if validation improved
        if vl1 <= vl0 + 0.002 || br1 < br0 {
            export_v3_weights(&adam_v.net, &adam_b.net, Path::new("src/rl_weights_v3.rs"));
            println!("Updated src/rl_weights_v3.rs with Gen-4 weights!");
        }

        // Optimal Bidding Threshold Sweep (STRICTLY EQUAL 8 vs 8 PIMC samples vs Frozen Pro RL v2!)
        println!("\n=== EQUAL-BUDGET (8 vs 8 PIMC) BIDDING CALIBRATION vs FROZEN PRO RL v2 (10,000 dup hands each) ===");
        let mut best_cush = 0.0_f32;
        let mut best_sp = -999.0_f64;
        for &cush in &[-0.50_f32, -0.25_f32, 0.00_f32, 0.25_f32] {
            let (wp, sp100, bm, ds, rw, bs) = eval_head_to_head(
                10_000, 42_424_242, &v2, &adam_v.net, &adam_b.net,
                cush, 8, true, true, 1,
            );
            println!("  cushion={:+.2}: Win={:.2}% | SetPts/100={:+.2} | BidMake={:.1}% (share {:.1}%) | DefSet={:.1}% | RevWin={:.1}%",
                cush, wp, sp100, bm, bs, ds, rw);
            if sp100 > best_sp {
                best_sp = sp100;
                best_cush = cush;
            }
        }
        println!("  --> Optimal bid cushion: {:+.2} (SetPts/100 = {:+.2})", best_cush, best_sp);

        // FINAL 100,000-HAND HELD-OUT EVALUATION (STRICTLY EQUAL 8 vs 8 PIMC SAMPLES!)
        println!("\n=========================================================================");
        println!("FINAL 100,000-HAND HELD-OUT EVALUATION: Pro RL v3.2 vs Frozen Pro RL v2");
        println!("(50,000 unseen duplicate deals x 2 seat swaps = 100,000 hands | Equal 8 vs 8 PIMC)");
        println!("=========================================================================");
        let te = Instant::now();
        let (wp, sp100, bm, ds, rw, bsh) = eval_head_to_head(
            100_000, 99_999_999, &v2, &adam_v.net, &adam_b.net,
            best_cush, 8, true, true, 1,
        );
        let es = te.elapsed().as_secs_f32();
        println!("  100,000 hands completed in {:.1}s ({:.0} hands/s):", es, 100_000.0 / es.max(0.1));
        println!("    Hand Win Rate        : {:.2}% (vs 50.00% even)", wp);
        println!("    Net Set Points / 100 : {:+.2} set pts / 100 hands", sp100);
        println!("    V3.2 Bid Make Rate   : {:.2}% (bid share {:.1}%)", bm, bsh);
        println!("    V3.2 Defend Set Rate : {:.2}%", ds);
        println!("    V3.2 Reverse Win Rate: {:.2}%", rw);

        // Also 20,000-hand check vs Normal Heuristic
        let (wp_n, sp_n, bm_n, ds_n, rw_n, _) = eval_head_to_head(
            20_000, 77_777_777, &v2, &adam_v.net, &adam_b.net,
            best_cush, 8, true, true, 0,
        );
        println!("\n  Pro RL v3.2 vs Normal Heuristic (20,000 duplicate hands):");
        println!("    Hand Win Rate: {:.2}% | SetPts/100: {:+.2} | BidMake: {:.2}% | DefSet: {:.2}% | RevWin: {:.2}%",
            wp_n, sp_n, bm_n, ds_n, rw_n);
        println!("Total Iter-2 wall time: {:.1}s", t0.elapsed().as_secs_f32());
    }

}
