use crate::bot::{
    choose_normal_bot_action, decide_play_heuristic_pub, is_boss_in_suit_pub, played_cards_set_pub,
    simulated_winner_pub, suit_to_idx_pub, track_known_voids_pub, unseen_trumps_count_pub,
    FastRngPub,
};
use crate::cards::{Card, Rank, Suit, NORMAL_RANK_ORDER, REVERSED_RANK_ORDER};
use crate::engine::GameEngine;
use crate::protocol::{ClientMessage, GamePhase, SeatIndex, StakesLevel, Team, TrickPlay, TrumpMode};
use crate::rl_weights::{
    B1, B2, B3, BB1, BB2, BID_H_DIM, BID_IN_DIM, BW1, BW2, H1_DIM, H2_DIM, IN_DIM, W1, W2, W3,
};

/// Compact pure-Rust 2-hidden-layer MLP value network (42 -> 48 -> 24 -> 1, ~13 KB).
#[derive(Clone)]
pub struct ProValueNet {
    pub w1: Vec<f32>,
    pub b1: Vec<f32>,
    pub w2: Vec<f32>,
    pub b2: Vec<f32>,
    pub w3: Vec<f32>,
    pub b3: f32,
}

impl ProValueNet {
    pub fn from_embedded() -> Self {
        Self {
            w1: W1.to_vec(),
            b1: B1.to_vec(),
            w2: W2.to_vec(),
            b2: B2.to_vec(),
            w3: W3.to_vec(),
            b3: B3,
        }
    }

    #[inline]
    pub fn predict(&self, x: &[f32; IN_DIM]) -> f32 {
        let mut h1 = [0.0_f32; H1_DIM];
        for j in 0..H1_DIM {
            let mut sum = self.b1[j];
            let row = j * IN_DIM;
            for i in 0..IN_DIM {
                sum += self.w1[row + i] * x[i];
            }
            h1[j] = if sum > 0.0 { sum } else { 0.01 * sum };
        }
        let mut h2 = [0.0_f32; H2_DIM];
        for k in 0..H2_DIM {
            let mut sum = self.b2[k];
            let row = k * H1_DIM;
            for j in 0..H1_DIM {
                sum += self.w2[row + j] * h1[j];
            }
            h2[k] = if sum > 0.0 { sum } else { 0.01 * sum };
        }
        let mut out = self.b3;
        for k in 0..H2_DIM {
            out += self.w3[k] * h2[k];
        }
        1.0 / (1.0 + (-out.clamp(-12.0, 12.0)).exp())
    }
}

/// Compact pure-Rust nonlinear RL Bidding MLP (24 -> 32 -> 1, ~3.3 KB).
/// Predicts expected bidder points (0..28) from 4-card opening hand synergies.
#[derive(Clone)]
pub struct ProBidNet {
    pub w1: Vec<f32>,
    pub b1: Vec<f32>,
    pub w2: Vec<f32>,
    pub b2: f32,
}

impl ProBidNet {
    pub fn from_embedded() -> Self {
        Self {
            w1: BW1.to_vec(),
            b1: BB1.to_vec(),
            w2: BW2.to_vec(),
            b2: BB2,
        }
    }

    #[inline]
    pub fn predict_expected_pts(&self, x: &[f32; BID_IN_DIM]) -> f32 {
        let mut h = [0.0_f32; BID_H_DIM];
        for j in 0..BID_H_DIM {
            let mut s = self.b1[j];
            let row = j * BID_IN_DIM;
            for i in 0..BID_IN_DIM {
                s += self.w1[row + i] * x[i];
            }
            h[j] = if s > 0.0 { s } else { 0.01 * s };
        }
        let mut out = self.b2;
        for j in 0..BID_H_DIM {
            out += self.w2[j] * h[j];
        }
        out.clamp(12.0, 26.0)
    }
}

/// Extract 24 nonlinear synergy features from a 4-card opening hand for `ProBidNet`.
pub fn extract_bid_features(hand: &[Card], allow_reverse: bool) -> [f32; BID_IN_DIM] {
    let mut f = [0.0_f32; BID_IN_DIM];
    let mut best_s_suit = Suit::Spades;
    let mut best_s_score = -1.0_f32;
    for suit in Suit::ALL {
        let sc: Vec<Card> = hand.iter().copied().filter(|c| c.suit == suit).collect();
        if sc.is_empty() { continue; }
        let s: f32 = sc.len() as f32 * 4.0 + sc.iter().map(|c| c.rank.strength(&NORMAL_RANK_ORDER) as f32).sum::<f32>();
        if s > best_s_score {
            best_s_score = s;
            best_s_suit = suit;
        }
    }
    let sc: Vec<Card> = hand.iter().copied().filter(|c| c.suit == best_s_suit).collect();
    let has_j = sc.iter().any(|c| c.rank == Rank::Jack);
    let has_9 = sc.iter().any(|c| c.rank == Rank::Nine);
    let has_a = sc.iter().any(|c| c.rank == Rank::Ace);
    let has_10 = sc.iter().any(|c| c.rank == Rank::Ten);
    let has_kq = sc.iter().any(|c| c.rank == Rank::King) && sc.iter().any(|c| c.rank == Rank::Queen);
    let suit_pts: f32 = sc.iter().map(|c| c.points() as f32).sum();
    let side_j = hand.iter().filter(|c| c.suit != best_s_suit && c.rank == Rank::Jack).count() as f32;
    let side_9 = hand.iter().filter(|c| c.suit != best_s_suit && c.rank == Rank::Nine).count() as f32;
    let side_a = hand.iter().filter(|c| c.suit != best_s_suit && c.rank == Rank::Ace).count() as f32;

    let mut lens = [0usize; 4];
    for c in hand { lens[suit_to_idx_pub(c.suit)] += 1; }
    let voids = lens.iter().filter(|&&l| l == 0).count() as f32;
    let singletons = lens.iter().filter(|&&l| l == 1).count() as f32;

    f[0] = sc.len() as f32 / 4.0;
    f[1] = if has_j { 1.0 } else { 0.0 };
    f[2] = if has_9 { 1.0 } else { 0.0 };
    f[3] = if has_j && has_9 { 1.0 } else { 0.0 };
    f[4] = if has_a { 1.0 } else { 0.0 };
    f[5] = if has_10 { 1.0 } else { 0.0 };
    f[6] = if has_kq { 1.0 } else { 0.0 };
    f[7] = suit_pts / 7.0;
    f[8] = side_j / 3.0;
    f[9] = side_9 / 3.0;
    f[10] = side_a / 3.0;
    f[11] = voids / 3.0;
    f[12] = singletons / 4.0;

    // Best Reverse suit profile
    if allow_reverse {
        let mut best_r_suit = Suit::Spades;
        let mut best_r_score = -1.0_f32;
        for suit in Suit::ALL {
            let rc: Vec<Card> = hand.iter().copied().filter(|c| c.suit == suit).collect();
            if rc.is_empty() { continue; }
            let s: f32 = rc.len() as f32 * 4.0 + rc.iter().map(|c| c.rank.strength(&REVERSED_RANK_ORDER) as f32).sum::<f32>();
            if s > best_r_score {
                best_r_score = s;
                best_r_suit = suit;
            }
        }
        let rc: Vec<Card> = hand.iter().copied().filter(|c| c.suit == best_r_suit).collect();
        let r7 = rc.iter().any(|c| c.rank == Rank::Seven);
        let r8 = rc.iter().any(|c| c.rank == Rank::Eight);
        let rkq = rc.iter().any(|c| c.rank == Rank::King) && rc.iter().any(|c| c.rank == Rank::Queen);
        let s7 = hand.iter().filter(|c| c.suit != best_r_suit && c.rank == Rank::Seven).count() as f32;
        let s8 = hand.iter().filter(|c| c.suit != best_r_suit && c.rank == Rank::Eight).count() as f32;
        let hi = hand.iter().filter(|c| matches!(c.rank, Rank::Jack | Rank::Nine)).count() as f32;
        f[13] = rc.len() as f32 / 4.0;
        f[14] = if r7 { 1.0 } else { 0.0 };
        f[15] = if r8 { 1.0 } else { 0.0 };
        f[16] = if r7 && r8 { 1.0 } else { 0.0 };
        f[17] = if rkq { 1.0 } else { 0.0 };
        f[18] = s7 / 3.0;
        f[19] = s8 / 3.0;
        f[20] = hi / 4.0;
    }

    // Balanced NT totals
    f[21] = hand.iter().filter(|c| c.rank == Rank::Jack).count() as f32 / 4.0;
    f[22] = hand.iter().filter(|c| c.rank == Rank::Nine).count() as f32 / 4.0;
    f[23] = hand.iter().filter(|c| c.rank == Rank::Ace).count() as f32 / 4.0;
    f
}

/// Extract 42 strictly fair (zero-peeking) game-state features from `seat`'s perspective.
pub fn extract_state_features(engine: &GameEngine, seat: SeatIndex) -> [f32; IN_DIM] {
    let view = engine.view_for_seat(seat, None);
    let mut f = [0.0_f32; IN_DIM];

    let my_team = Team::of_seat(seat);
    let partner = (seat + 2) % 4;
    let on_bidding_team = view
        .current_high_bidder
        .map(|b| Team::of_seat(b) == my_team)
        .unwrap_or(false);
    let target_bid = view
        .effective_bid
        .unwrap_or(view.current_high_bid.unwrap_or(16)) as f32;
    let (my_pts, opp_pts) = if my_team == Team::TeamA {
        (view.hand_points_team_a as f32, view.hand_points_team_b as f32)
    } else {
        (view.hand_points_team_b as f32, view.hand_points_team_a as f32)
    };
    let max_total = if view.config.last_trick_bonus_point { 29.0 } else { 28.0 };
    let pts_needed = if on_bidding_team {
        (target_bid - my_pts).max(0.0)
    } else {
        ((max_total - target_bid + 1.0) - my_pts).max(0.0)
    };
    let opp_needed = if on_bidding_team {
        ((max_total - target_bid + 1.0) - opp_pts).max(0.0)
    } else {
        (target_bid - opp_pts).max(0.0)
    };

    let seen = played_cards_set_pub(engine);
    let voids = track_known_voids_pub(engine);
    let rank_order = &view.current_rank_order;
    let known_trump = view.visible_trump;
    let is_no_trump = view.visible_trump_mode == Some(TrumpMode::NoTrump);
    let unseen_trumps = if is_no_trump {
        0
    } else {
        unseen_trumps_count_pub(known_trump, &seen, &view.your_hand)
    };

    f[0] = if on_bidding_team { 1.0 } else { 0.0 };
    f[1] = (target_bid - 16.0) / 12.0;
    f[2] = my_pts / 28.0;
    f[3] = opp_pts / 28.0;
    f[4] = pts_needed / 28.0;
    f[5] = engine.completed_tricks.len() as f32 / 8.0;
    f[6] = if view.trump_exposed { 1.0 } else { 0.0 };
    f[7] = if view.reverse_active { 1.0 } else { 0.0 };

    f[8] = if is_no_trump { 1.0 } else { 0.0 };
    let leader = engine
        .current_trick
        .first()
        .map(|p| p.seat)
        .unwrap_or(engine.current_turn);
    f[9] = if leader == seat { 1.0 } else { 0.0 };
    f[10] = if leader == partner { 1.0 } else { 0.0 };
    let my_trump_cnt = known_trump
        .map(|t| view.your_hand.iter().filter(|c| c.suit == t).count())
        .unwrap_or(0);
    f[11] = my_trump_cnt as f32 / 8.0;
    f[12] = unseen_trumps as f32 / 8.0;
    f[13] = if !view.marriage_cards.is_empty() { 1.0 } else { 0.0 };

    let hand = &view.your_hand;
    let hand_pts: f32 = hand.iter().map(|c| c.points() as f32).sum();
    let opp_is_void = |s: Suit| -> bool {
        (0..4usize).any(|o| Team::of_seat(o) != my_team && voids[o][suit_to_idx_pub(s)])
    };

    let mut boss_total = 0.0_f32;
    let mut trump_boss = 0.0_f32;
    let mut safe_side_boss = 0.0_f32;
    let mut vuln_side_boss = 0.0_f32;
    let mut rank_sum = 0.0_f32;
    let mut zero_cnt = 0.0_f32;

    for &c in hand {
        rank_sum += c.rank.strength(rank_order) as f32;
        if c.points() == 0 { zero_cnt += 1.0; }
        if is_boss_in_suit_pub(c, &seen, hand, rank_order) {
            boss_total += 1.0;
            if Some(c.suit) == known_trump {
                trump_boss += 1.0;
            } else if unseen_trumps == 0 || !opp_is_void(c.suit) {
                safe_side_boss += 1.0;
            } else {
                vuln_side_boss += 1.0;
            }
        }
    }

    let mut suit_lens = [0usize; 4];
    let mut suit_has_boss = [false; 4];
    for &c in hand {
        let si = suit_to_idx_pub(c.suit);
        suit_lens[si] += 1;
        if is_boss_in_suit_pub(c, &seen, hand, rank_order) {
            suit_has_boss[si] = true;
        }
    }
    let my_voids = suit_lens.iter().filter(|&&l| l == 0).count() as f32;
    let my_singletons = suit_lens.iter().filter(|&&l| l == 1).count() as f32;

    f[14] = hand_pts / 14.0;
    f[15] = boss_total / 6.0;
    f[16] = trump_boss / 4.0;
    f[17] = safe_side_boss / 4.0;
    f[18] = vuln_side_boss / 4.0;
    f[19] = my_voids / 3.0;
    f[20] = my_singletons / 3.0;
    f[21] = rank_sum / 56.0;
    f[22] = zero_cnt / 8.0;
    f[23] = hand.len() as f32 / 8.0;

    let opp_voids_cnt: usize = (0..4usize)
        .filter(|&o| Team::of_seat(o) != my_team)
        .map(|o| voids[o].iter().filter(|&&v| v).count())
        .sum();
    let partner_voids_cnt = voids[partner].iter().filter(|&&v| v).count();
    let can_feed_partner = Suit::ALL.iter().any(|&s| {
        Some(s) != known_trump && voids[partner][suit_to_idx_pub(s)] && suit_lens[suit_to_idx_pub(s)] > 0
    });
    let opps_void_trump = known_trump
        .map(|t| {
            (0..4usize)
                .filter(|&o| Team::of_seat(o) != my_team && voids[o][suit_to_idx_pub(t)])
                .count()
        })
        .unwrap_or(0);
    let rem_pts = (max_total - my_pts - opp_pts).max(0.0);

    f[24] = opp_voids_cnt as f32 / 6.0;
    f[25] = partner_voids_cnt as f32 / 3.0;
    f[26] = if can_feed_partner { 1.0 } else { 0.0 };
    f[27] = if opps_void_trump >= 1 { 1.0 } else { 0.0 };
    f[28] = if opps_void_trump >= 2 { 1.0 } else { 0.0 };
    f[29] = rem_pts / 28.0;
    f[30] = if rem_pts > 0.5 { (hand_pts / rem_pts).min(1.0) } else { 0.0 };
    f[31] = if pts_needed <= 0.0 { 1.0 } else if opp_needed <= 0.0 { -1.0 } else { 0.0 };

    let trick = &view.current_trick;
    if !trick.is_empty() {
        let trick_pts: f32 = trick.iter().map(|p| p.card.points() as f32).sum();
        let active_t = if view.trump_exposed { view.visible_trump } else { None };
        let cw = simulated_winner_pub(trick, active_t, view.reverse_active, engine.trump_exposed_at_play_index);
        let led = trick[0].card.suit;
        f[32] = trick.len() as f32 / 3.0;
        f[33] = trick_pts / 9.0;
        f[34] = if Team::of_seat(cw) == my_team { 1.0 } else { 0.0 };
        f[35] = if trick.iter().any(|p| Some(p.card.suit) == active_t && p.card.suit != led) { 1.0 } else { 0.0 };
        f[36] = if hand.iter().any(|c| c.suit == led) { 1.0 } else { 0.0 };
        f[37] = if trick.len() == 3 { 1.0 } else { 0.0 };
    }

    let mut suit_ctrl: [f32; 4] = [0.0; 4];
    for i in 0..4 {
        suit_ctrl[i] = (suit_lens[i] as f32 / 4.0) * if suit_has_boss[i] { 1.0 } else { 0.35 };
    }
    suit_ctrl.sort_by(|a, b| b.partial_cmp(a).unwrap_or(std::cmp::Ordering::Equal));
    f[38] = suit_ctrl[0];
    f[39] = suit_ctrl[1];
    f[40] = suit_ctrl[2];
    f[41] = suit_ctrl[3];
    f
}

/// Bid-consistent & void-consistent world sampler (Bayesian hand reading!).
/// Biases unseen high trumps & Jacks toward the high bidder (when bid >= 17) while strictly respecting voids & hand sizes.
fn sample_bid_consistent_hands(
    unseen: &[Card],
    self_seat: SeatIndex,
    sizes: &[usize; 4],
    voids: &[[bool; 4]; 4],
    bidder: Option<SeatIndex>,
    high_bid: u8,
    known_trump: Option<Suit>,
    reverse_active: bool,
    rng: &mut FastRngPub,
) -> [Vec<Card>; 4] {
    let mut pool = unseen.to_vec();
    let order = if reverse_active { &REVERSED_RANK_ORDER } else { &NORMAL_RANK_ORDER };

    // Sort high-value/trump cards first so bidder gets realistic priority proportional to bid strength
    let bidder_bias_pct: u64 = match bidder {
        Some(b) if b != self_seat && high_bid >= 17 => ((high_bid - 15) as u64 * 12).min(55),
        _ => 0,
    };

    for _attempt in 0..10 {
        rng.shuffle(&mut pool);
        let mut hands: [Vec<Card>; 4] = Default::default();
        let mut used = vec![false; pool.len()];

        // Phase A: If bidder is another seat with strong bid, bias a few unseen high trumps / Jacks toward bidder
        if let Some(b) = bidder {
            if b != self_seat && bidder_bias_pct > 0 {
                for (idx, &c) in pool.iter().enumerate() {
                    if hands[b].len() >= sizes[b] { break; }
                    if used[idx] || voids[b][suit_to_idx_pub(c.suit)] { continue; }
                    let is_key = (Some(c.suit) == known_trump && c.rank.strength(order) >= 5)
                        || c.rank.strength(order) == 7; // Top card (J in Straight, 7 in Reverse)
                    if is_key && (rng.next_u64() % 100) < bidder_bias_pct {
                        hands[b].push(c);
                        used[idx] = true;
                    }
                }
            }
        }

        // Phase B: Fill remaining slots most-constrained seat first
        let mut seat_order: Vec<usize> = (0..4usize).filter(|&s| s != self_seat).collect();
        seat_order.sort_by_key(|&s| std::cmp::Reverse(voids[s].iter().filter(|&&v| v).count()));

        let mut valid = true;
        for s in seat_order {
            let need = sizes[s];
            for (idx, &c) in pool.iter().enumerate() {
                if hands[s].len() == need { break; }
                if !used[idx] && !voids[s][suit_to_idx_pub(c.suit)] {
                    hands[s].push(c);
                    used[idx] = true;
                }
            }
            if hands[s].len() != need {
                valid = false;
                break;
            }
        }
        if valid {
            return hands;
        }
    }

    // Fallback: simple random deal
    let mut hands: [Vec<Card>; 4] = Default::default();
    rng.shuffle(&mut pool);
    let mut cur = 0;
    for s in 0..4usize {
        if s != self_seat {
            let need = sizes[s];
            hands[s] = pool[cur..cur + need].to_vec();
            cur += need;
        }
    }
    hands
}

/// Fast Double-Dummy Alpha-Beta Endgame Solver for the last <= 3 tricks (<= 12 cards left!).
/// Returns exact score from `root_team`'s perspective: `(won_contract ? 100 : 0) + root_team_pts`.
#[derive(Clone)]
struct MiniEndgame {
    hands: [Vec<Card>; 4],
    trick: Vec<TrickPlay>,
    turn: SeatIndex,
    pts_a: i32,
    pts_b: i32,
    trump: Option<Suit>,
    reverse: bool,
    exposed_idx: Option<usize>,
    last_trick_bonus: bool,
    bidding_team: Team,
    target_bid: i32,
}

impl MiniEndgame {
    fn from_engine(sim: &GameEngine) -> Self {
        let v = sim.view_for_seat(sim.current_turn, None);
        let trump = if v.trump_exposed { v.visible_trump } else { None };
        let bidding_team = sim
            .current_high_bidder
            .map(Team::of_seat)
            .unwrap_or(Team::TeamA);
        let target_bid = sim.effective_bid().unwrap_or(sim.current_high_bid.unwrap_or(16)) as i32;
        Self {
            hands: sim.hands.clone(),
            trick: sim.current_trick.clone(),
            turn: sim.current_turn,
            pts_a: sim.hand_points_team_a as i32,
            pts_b: sim.hand_points_team_b as i32,
            trump,
            reverse: v.reverse_active,
            exposed_idx: sim.trump_exposed_at_play_index,
            last_trick_bonus: sim.config.last_trick_bonus_point,
            bidding_team,
            target_bid,
        }
    }

    #[inline]
    fn eval_terminal(&self, root_team: Team) -> i32 {
        let bidder_pts = if self.bidding_team == Team::TeamA { self.pts_a } else { self.pts_b };
        let bidder_won = bidder_pts >= self.target_bid;
        let root_won = (self.bidding_team == root_team) == bidder_won;
        let root_pts = if root_team == Team::TeamA { self.pts_a } else { self.pts_b };
        (if root_won { 100 } else { 0 }) + root_pts
    }

    fn legal_moves(&self) -> Vec<Card> {
        let hand = &self.hands[self.turn];
        if let Some(first) = self.trick.first() {
            let led = first.card.suit;
            let same: Vec<Card> = hand.iter().copied().filter(|c| c.suit == led).collect();
            if !same.is_empty() {
                return same;
            }
        }
        hand.clone()
    }

    fn step(&self, card: Card) -> Self {
        let mut next = self.clone();
        if let Some(pos) = next.hands[self.turn].iter().position(|&c| c == card) {
            next.hands[self.turn].swap_remove(pos);
        }
        next.trick.push(TrickPlay { seat: self.turn, card });
        if next.trick.len() == 4 {
            let winner = simulated_winner_pub(&next.trick, next.trump, next.reverse, next.exposed_idx);
            let mut tpts: i32 = next.trick.iter().map(|p| p.card.points() as i32).sum();
            let all_empty = next.hands.iter().all(|h| h.is_empty());
            if all_empty && next.last_trick_bonus {
                tpts += 1;
            }
            if Team::of_seat(winner) == Team::TeamA {
                next.pts_a += tpts;
            } else {
                next.pts_b += tpts;
            }
            next.trick.clear();
            next.exposed_idx = None;
            next.turn = winner;
        } else {
            next.turn = (self.turn + 1) % 4;
        }
        next
    }
}

fn alphabeta_endgame(
    state: &MiniEndgame,
    root_team: Team,
    mut alpha: i32,
    mut beta: i32,
    nodes: &mut usize,
) -> i32 {
    *nodes += 1;
    if state.hands.iter().all(|h| h.is_empty()) || *nodes > 600 {
        return state.eval_terminal(root_team);
    }

    let mut moves = state.legal_moves();
    // Order moves: trumps & high-point cards first for rapid alpha-beta cutoffs
    moves.sort_by_key(|c| {
        let is_t = if Some(c.suit) == state.trump { 1 } else { 0 };
        std::cmp::Reverse((is_t, c.points()))
    });

    let maximizing = Team::of_seat(state.turn) == root_team;
    if maximizing {
        let mut best = i32::MIN;
        for c in moves {
            let child = state.step(c);
            let v = alphabeta_endgame(&child, root_team, alpha, beta, nodes);
            if v > best { best = v; }
            if best > alpha { alpha = best; }
            if alpha >= beta { break; }
        }
        best
    } else {
        let mut best = i32::MAX;
        for c in moves {
            let child = state.step(c);
            let v = alphabeta_endgame(&child, root_team, alpha, beta, nodes);
            if v < best { best = v; }
            if best < beta { beta = best; }
            if alpha >= beta { break; }
        }
        best
    }
}

/// Pro v2 RL Bidding using `ProBidNet` (nonlinear 24->32->1 MLP trained on 35k hands).
fn decide_bid_pro_rl(engine: &GameEngine, seat: SeatIndex, bid_net: &ProBidNet) -> ClientMessage {
    let view = engine.view_for_seat(seat, None);
    let feat = extract_bid_features(&view.your_hand, view.config.allow_reverse_rule_option);
    let pred_pts = bid_net.predict_expected_pts(&feat);

    // Slight safety cushion (-0.45) to target ~60% contract success + slight Marriage boost
    let has_kq_any = Suit::ALL.iter().any(|&s| {
        view.your_hand.iter().any(|c| c.suit == s && c.rank == Rank::King)
            && view.your_hand.iter().any(|c| c.suit == s && c.rank == Rank::Queen)
    });
    let adj = pred_pts - 0.45 + if has_kq_any { 0.85 } else { 0.0 };
    let max_willing = (adj.round() as u8).clamp(15, view.config.max_bid);

    let next_bid = view
        .current_high_bid
        .map(|h| h + 1)
        .unwrap_or(view.config.starting_bid);
    let partner_winning = view
        .current_high_bidder
        .map(|b| Team::of_seat(b) == Team::of_seat(seat))
        .unwrap_or(false);

    if partner_winning && max_willing < next_bid + 2 {
        return ClientMessage::PassBid;
    }
    if next_bid <= max_willing {
        ClientMessage::PlaceBid { amount: next_bid }
    } else {
        ClientMessage::PassBid
    }
}

/// Pro v2 Double/Redouble: sharper defensive doubling using `ProBidNet` hand strength!
fn decide_double_pro_rl(engine: &GameEngine, seat: SeatIndex, bid_net: &ProBidNet) -> Option<ClientMessage> {
    let view = engine.view_for_seat(seat, None);
    let hand = &view.your_hand;
    let pts: u8 = hand.iter().map(|c| c.points()).sum();
    let jacks = hand.iter().filter(|c| c.rank == Rank::Jack).count();
    let high_bid = view.current_high_bid.unwrap_or(16);
    let my_est = bid_net.predict_expected_pts(&extract_bid_features(hand, view.config.allow_reverse_rule_option));

    if view.can_double && view.stakes == StakesLevel::Normal {
        // Double when opponent overbids AND our 4-card hand itself projects strong trick-taking power!
        if (high_bid >= 19 && (pts >= 5 || my_est >= 17.4))
            || (high_bid >= 18 && jacks >= 2)
            || (high_bid >= 17 && pts >= 8 && jacks >= 2)
        {
            Some(ClientMessage::DoubleStakes)
        } else {
            Some(ClientMessage::PassDoubleWindow)
        }
    } else if view.can_redouble && view.stakes == StakesLevel::Doubled {
        if my_est >= 19.8 || (pts >= 7 && jacks >= 2) {
            Some(ClientMessage::RedoubleStakes)
        } else {
            Some(ClientMessage::PassDoubleWindow)
        }
    } else {
        None
    }
}

/// Pro v2 Difficulty AI:
/// 1) Nonlinear RL Bidding & Doubling MLP (`ProBidNet`)
/// 2) Bid-Consistent Void-Aware PIMC World Sampling (Bayesian Hand Reading)
/// 3) Exact 3-Trick Double-Dummy Alpha-Beta Endgame Solver (tricks 6..8) + Gen-2 RL Value Net (tricks 2..5)
pub fn choose_pro_rl_action(engine: &GameEngine, seat: SeatIndex) -> Option<ClientMessage> {
    use crate::rl_v3::{
        card_to_u8, choose_v3_fast_play, extract_v3_bid_features, u8_to_card, FastRng, FastState,
        ProBidNetV3, ProValueNetV3,
    };

    let view = engine.view_for_seat(seat, None);
    match view.phase {
        GamePhase::Bidding if view.current_turn == seat => {
            let bnet = ProBidNetV3::from_embedded();
            let mut hmask = 0u32;
            for &c in &view.your_hand {
                hmask |= 1u32 << card_to_u8(c);
            }
            let is_opening_leader = seat == (engine.dealer + 1) % 4;
            let cur_high = view.current_high_bid.unwrap_or(0);
            let partner_winning = view
                .current_high_bidder
                .map(|b| Team::of_seat(b) == Team::of_seat(seat))
                .unwrap_or(false);
            let passed_cnt = engine.passed_bidding.iter().filter(|&&p| p).count() as u8;
            let feat = extract_v3_bid_features(
                hmask,
                is_opening_leader,
                view.config.allow_reverse_rule_option,
                cur_high,
                partner_winning,
                passed_cnt,
            );
            let pred_pts = bnet.predict_expected_pts(&feat);
            let has_kq_any = (0..4u8).any(|s| ((hmask >> (s * 8)) & 48) == 48);
            // Optimal simulation-calibrated cushion (+0.25) from 100k-hand evaluation
            let adj = pred_pts - 0.25 + if has_kq_any { 0.75 } else { 0.0 };
            let max_willing = (adj.round() as u8).clamp(15, view.config.max_bid);
            let next_bid = view
                .current_high_bid
                .map(|h| h + 1)
                .unwrap_or(view.config.starting_bid);

            if partner_winning && max_willing < next_bid + 2 {
                return Some(ClientMessage::PassBid);
            }
            if next_bid <= max_willing {
                Some(ClientMessage::PlaceBid { amount: next_bid })
            } else {
                Some(ClientMessage::PassBid)
            }
        }
        GamePhase::DoubleWindow => {
            let bnet = ProBidNetV3::from_embedded();
            let mut hmask = 0u32;
            for &c in &view.your_hand {
                hmask |= 1u32 << card_to_u8(c);
            }
            let is_opening_leader = seat == (engine.dealer + 1) % 4;
            let feat = extract_v3_bid_features(
                hmask,
                is_opening_leader,
                view.config.allow_reverse_rule_option,
                view.current_high_bid.unwrap_or(16),
                false,
                0,
            );
            let my_est = bnet.predict_expected_pts(&feat);
            let pts: u8 = view.your_hand.iter().map(|c| c.points()).sum();
            let jacks = view.your_hand.iter().filter(|c| c.rank == Rank::Jack).count();
            let high_bid = view.current_high_bid.unwrap_or(16);

            if view.can_double && view.stakes == StakesLevel::Normal {
                if (high_bid >= 19 && (pts >= 5 || my_est >= 17.3))
                    || (high_bid >= 18 && jacks >= 2)
                    || (high_bid >= 17 && pts >= 8 && jacks >= 2)
                {
                    Some(ClientMessage::DoubleStakes)
                } else {
                    Some(ClientMessage::PassDoubleWindow)
                }
            } else if view.can_redouble && view.stakes == StakesLevel::Doubled {
                if my_est >= 19.6 || (pts >= 7 && jacks >= 2) {
                    Some(ClientMessage::RedoubleStakes)
                } else {
                    Some(ClientMessage::PassDoubleWindow)
                }
            } else {
                None
            }
        }
        GamePhase::Playing if view.current_turn == seat => {
            if let Some(&mcard) = view.marriage_cards.first() {
                return Some(ClientMessage::DeclareMarriage { card_id: mcard.id() });
            }
            if view.legal_cards.is_empty() {
                return None;
            }
            if view.legal_cards.len() == 1 && !view.can_request_trump_show {
                return Some(ClientMessage::PlayCard { card_id: view.legal_cards[0].id() });
            }
            // Fast zero-allocation Pro RL v3.2: 128-dim ValueNetV3 + Bayesian PIMC + Pre-Exposure ShowTrump + 4-Trick Exact AB
            let st = FastState::from_engine(engine);
            let vnet = ProValueNetV3::from_embedded();
            let cards_left = view.your_hand.len();
            let samples = if cards_left <= 4 { 24 } else if cards_left <= 6 { 18 } else { 14 };
            let mut rng = FastRng::new(
                (view.hand_number as u64) * 2027
                    + (engine.completed_tricks.len() as u64) * 131
                    + (seat as u64) * 19
                    + (engine.current_trick.len() as u64),
            );
            let (show_trump, cid) = choose_v3_fast_play(&st, &vnet, samples, true, true, &mut rng);
            if show_trump && view.can_request_trump_show {
                Some(ClientMessage::RequestTrumpShow)
            } else {
                let c = u8_to_card(cid);
                if view.legal_cards.contains(&c) {
                    Some(ClientMessage::PlayCard { card_id: c.id() })
                } else {
                    Some(ClientMessage::PlayCard { card_id: view.legal_cards[0].id() })
                }
            }
        }
        _ => choose_normal_bot_action(engine, seat),
    }
}

pub fn decide_play_pro_rl(
    engine: &GameEngine,
    seat: SeatIndex,
    net: &ProValueNet,
) -> Option<ClientMessage> {
    let view = engine.view_for_seat(seat, None);
    let legal = &view.legal_cards;
    if legal.is_empty() {
        return None;
    }
    if let Some(&mcard) = view.marriage_cards.first() {
        return Some(ClientMessage::DeclareMarriage { card_id: mcard.id() });
    }
    if legal.len() == 1 && !view.can_request_trump_show {
        return Some(ClientMessage::PlayCard { card_id: legal[0].id() });
    }

    // 4th seat losing trick -> always dump 0-pt trash via heuristic
    if view.current_trick.len() == 3 {
        let active_t = if view.trump_exposed { view.visible_trump } else { None };
        let any_win = legal.iter().any(|&c| {
            let mut sim = view.current_trick.clone();
            sim.push(TrickPlay { seat, card: c });
            simulated_winner_pub(&sim, active_t, view.reverse_active, engine.trump_exposed_at_play_index) == seat
        });
        if !any_win && !view.can_request_trump_show {
            return decide_play_heuristic_pub(engine, seat);
        }
    }

    if !view.trump_exposed {
        return decide_play_heuristic_pub(engine, seat);
    }

    let seen = played_cards_set_pub(engine);
    let voids = track_known_voids_pub(engine);
    let mut unseen: Vec<Card> = Vec::with_capacity(28);
    for suit in Suit::ALL {
        for rank in NORMAL_RANK_ORDER {
            let c = Card::new(rank, suit);
            if !seen.contains(&c) && !view.your_hand.contains(&c) {
                unseen.push(c);
            }
        }
    }
    let other_sizes: [usize; 4] = [
        view.seats[0].card_count,
        view.seats[1].card_count,
        view.seats[2].card_count,
        view.seats[3].card_count,
    ];
    let expected_unseen: usize = (0..4usize)
        .filter(|&s| s != seat)
        .map(|s| other_sizes[s])
        .sum();
    if unseen.len() != expected_unseen {
        return decide_play_heuristic_pub(engine, seat);
    }

    let my_team = Team::of_seat(seat);
    let hand_len = view.your_hand.len();
    let use_exact_ab = hand_len <= 3; // Exact Double-Dummy Alpha-Beta on last 3 tricks!
    let samples = if use_exact_ab {
        36
    } else if hand_len <= 5 {
        28
    } else {
        18
    };
    let rollout_tricks = if hand_len <= 5 { 8 } else { 2 };

    let mut rng = FastRngPub::new(
        (view.hand_number as u64) * 2027
            + (engine.completed_tricks.len() as u64) * 131
            + (seat as u64) * 19
            + (engine.current_trick.len() as u64),
    );

    let actions: Vec<ClientMessage> = legal
        .iter()
        .map(|&c| ClientMessage::PlayCard { card_id: c.id() })
        .collect();

    let heur_act = decide_play_heuristic_pub(engine, seat);
    let mut scores: Vec<f32> = actions
        .iter()
        .map(|a| if Some(a) == heur_act.as_ref() { 0.25 } else { 0.0 })
        .collect();

    let high_bid = view.current_high_bid.unwrap_or(16);

    for _ in 0..samples {
        let world_hands = sample_bid_consistent_hands(
            &unseen,
            seat,
            &other_sizes,
            &voids,
            view.current_high_bidder,
            high_bid,
            view.visible_trump,
            view.reverse_active,
            &mut rng,
        );

        for (ai, act) in actions.iter().enumerate() {
            let mut sim = engine.clone();
            for s in 0..4usize {
                if s != seat {
                    sim.hands[s] = world_hands[s].clone();
                }
            }
            let start_tricks = sim.completed_tricks.len();
            let applied = match act {
                ClientMessage::PlayCard { card_id } => {
                    Card::from_id(card_id).and_then(|c| sim.play_card(seat, c).ok()).is_some()
                }
                _ => false,
            };
            if !applied {
                scores[ai] -= 100.0;
                continue;
            }

            if use_exact_ab && sim.phase == GamePhase::Playing {
                // EXACT Double-Dummy Alpha-Beta Endgame Solver!
                let mini = MiniEndgame::from_engine(&sim);
                let mut nodes = 0usize;
                let ab_val = alphabeta_endgame(&mini, my_team, i32::MIN + 1, i32::MAX - 1, &mut nodes);
                let won = if ab_val >= 100 { 10.0_f32 } else { 0.0_f32 };
                let pts = (ab_val % 100) as f32;
                scores[ai] += won + pts * 0.08;
                continue;
            }

            let mut guard = 0usize;
            while sim.phase == GamePhase::Playing
                && (sim.completed_tricks.len() - start_tricks) < rollout_tricks
                && guard < 36
            {
                guard += 1;
                let turn = sim.current_turn;
                let Some(next_act) = decide_play_heuristic_pub(&sim, turn) else {
                    break;
                };
                let ok = match next_act {
                    ClientMessage::RequestTrumpShow => sim.request_trump_show(turn).is_ok(),
                    ClientMessage::DeclareMarriage { card_id } => {
                        Card::from_id(&card_id).and_then(|c| sim.declare_marriage(turn, c).ok()).is_some()
                    }
                    ClientMessage::PlayCard { card_id } => {
                        Card::from_id(&card_id).and_then(|c| sim.play_card(turn, c).ok()).is_some()
                    }
                    _ => false,
                };
                if !ok {
                    break;
                }
            }

            if sim.phase == GamePhase::HandComplete || sim.phase == GamePhase::MatchComplete {
                if let Some(sum) = sim.hand_history.last() {
                    let won = sum.winning_team == my_team;
                    let my_pts = if sum.bidding_team == my_team {
                        sum.bidding_team_points as f32
                    } else {
                        sum.opposing_team_points as f32
                    };
                    scores[ai] += if won { 10.0 } else { 0.0 } + my_pts * 0.08;
                }
            } else {
                let feat = extract_state_features(&sim, seat);
                scores[ai] += net.predict(&feat) * 10.0;
            }
        }
    }

    let best_idx = scores
        .iter()
        .enumerate()
        .max_by(|a, b| a.1.partial_cmp(b.1).unwrap_or(std::cmp::Ordering::Equal))
        .map(|(i, _)| i)
        .unwrap_or(0);

    Some(actions[best_idx].clone())
}

#[cfg(test)]
mod rl_trainer {
    use super::*;
    use crate::config::GameConfig;
    use rand::rngs::StdRng;
    use rand::SeedableRng;
    use std::path::Path;

    struct AdamValNet {
        net: ProValueNet,
        mw1: Vec<f32>, vw1: Vec<f32>, mb1: Vec<f32>, vb1: Vec<f32>,
        mw2: Vec<f32>, vw2: Vec<f32>, mb2: Vec<f32>, vb2: Vec<f32>,
        mw3: Vec<f32>, vw3: Vec<f32>, mb3: f32, vb3: f32,
        step: i32,
    }

    impl AdamValNet {
        fn new(seed: u64) -> Self {
            let mut rng = FastRngPub::new(seed);
            let mut rw = |n: usize, s: f32| -> Vec<f32> {
                (0..n).map(|_| (((rng.next_u64() % 10000) as f32 / 5000.0) - 1.0) * s).collect()
            };
            let net = ProValueNet {
                w1: rw(IN_DIM * H1_DIM, (2.0 / IN_DIM as f32).sqrt()),
                b1: vec![0.0; H1_DIM],
                w2: rw(H1_DIM * H2_DIM, (2.0 / H1_DIM as f32).sqrt()),
                b2: vec![0.0; H2_DIM],
                w3: rw(H2_DIM, (1.0 / H2_DIM as f32).sqrt()),
                b3: 0.0,
            };
            Self {
                mw1: vec![0.0; IN_DIM * H1_DIM], vw1: vec![0.0; IN_DIM * H1_DIM],
                mb1: vec![0.0; H1_DIM], vb1: vec![0.0; H1_DIM],
                mw2: vec![0.0; H1_DIM * H2_DIM], vw2: vec![0.0; H1_DIM * H2_DIM],
                mb2: vec![0.0; H2_DIM], vb2: vec![0.0; H2_DIM],
                mw3: vec![0.0; H2_DIM], vw3: vec![0.0; H2_DIM],
                mb3: 0.0, vb3: 0.0, step: 0, net,
            }
        }

        fn train_batch(&mut self, batch: &[([f32; IN_DIM], f32)], lr: f32) -> f32 {
            let mut gw1 = vec![0.0_f32; IN_DIM * H1_DIM];
            let mut gb1 = vec![0.0_f32; H1_DIM];
            let mut gw2 = vec![0.0_f32; H1_DIM * H2_DIM];
            let mut gb2 = vec![0.0_f32; H2_DIM];
            let mut gw3 = vec![0.0_f32; H2_DIM];
            let mut gb3 = 0.0_f32;
            let mut loss = 0.0_f32;

            for &(ref x, target) in batch {
                let mut z1 = [0.0_f32; H1_DIM];
                let mut h1 = [0.0_f32; H1_DIM];
                for j in 0..H1_DIM {
                    let mut s = self.net.b1[j];
                    let row = j * IN_DIM;
                    for i in 0..IN_DIM { s += self.net.w1[row + i] * x[i]; }
                    z1[j] = s;
                    h1[j] = if s > 0.0 { s } else { 0.01 * s };
                }
                let mut z2 = [0.0_f32; H2_DIM];
                let mut h2 = [0.0_f32; H2_DIM];
                for k in 0..H2_DIM {
                    let mut s = self.net.b2[k];
                    let row = k * H1_DIM;
                    for j in 0..H1_DIM { s += self.net.w2[row + j] * h1[j]; }
                    z2[k] = s;
                    h2[k] = if s > 0.0 { s } else { 0.01 * s };
                }
                let mut logit = self.net.b3;
                for k in 0..H2_DIM { logit += self.net.w3[k] * h2[k]; }
                let pred = 1.0 / (1.0 + (-logit.clamp(-12.0, 12.0)).exp());
                let pc = pred.clamp(1e-6, 1.0 - 1e-6);
                loss += -(target * pc.ln() + (1.0 - target) * (1.0 - pc).ln());
                let d_out = pred - target;
                gb3 += d_out;
                let mut dh2 = [0.0_f32; H2_DIM];
                for k in 0..H2_DIM {
                    gw3[k] += d_out * h2[k];
                    dh2[k] = d_out * self.net.w3[k] * if z2[k] > 0.0 { 1.0 } else { 0.01 };
                }
                let mut dh1 = [0.0_f32; H1_DIM];
                for k in 0..H2_DIM {
                    gb2[k] += dh2[k];
                    let row = k * H1_DIM;
                    for j in 0..H1_DIM {
                        gw2[row + j] += dh2[k] * h1[j];
                        dh1[j] += dh2[k] * self.net.w2[row + j];
                    }
                }
                for j in 0..H1_DIM {
                    let dz1 = dh1[j] * if z1[j] > 0.0 { 1.0 } else { 0.01 };
                    gb1[j] += dz1;
                    let row = j * IN_DIM;
                    for i in 0..IN_DIM { gw1[row + i] += dz1 * x[i]; }
                }
            }
            let inv = 1.0 / batch.len().max(1) as f32;
            self.step += 1;
            let b1c = 1.0 - 0.9_f32.powi(self.step);
            let b2c = 1.0 - 0.999_f32.powi(self.step);
            let upd = |w: &mut [f32], g: &[f32], m: &mut [f32], v: &mut [f32], wd: f32| {
                for i in 0..w.len() {
                    let gi = g[i] * inv + wd * w[i];
                    m[i] = 0.9 * m[i] + 0.1 * gi;
                    v[i] = 0.999 * v[i] + 0.001 * gi * gi;
                    w[i] -= lr * (m[i] / b1c) / ((v[i] / b2c).sqrt() + 1e-8);
                }
            };
            upd(&mut self.net.w1, &gw1, &mut self.mw1, &mut self.vw1, 1e-4);
            upd(&mut self.net.b1, &gb1, &mut self.mb1, &mut self.vb1, 0.0);
            upd(&mut self.net.w2, &gw2, &mut self.mw2, &mut self.vw2, 1e-4);
            upd(&mut self.net.b2, &gb2, &mut self.mb2, &mut self.vb2, 0.0);
            upd(&mut self.net.w3, &gw3, &mut self.mw3, &mut self.vw3, 1e-4);
            let g3 = gb3 * inv;
            self.mb3 = 0.9 * self.mb3 + 0.1 * g3;
            self.vb3 = 0.999 * self.vb3 + 0.001 * g3 * g3;
            self.net.b3 -= lr * (self.mb3 / b1c) / ((self.vb3 / b2c).sqrt() + 1e-8);
            loss * inv
        }
    }

    struct AdamBidNet {
        net: ProBidNet,
        mw1: Vec<f32>, vw1: Vec<f32>, mb1: Vec<f32>, vb1: Vec<f32>,
        mw2: Vec<f32>, vw2: Vec<f32>, mb2: f32, vb2: f32,
        step: i32,
    }

    impl AdamBidNet {
        fn new(seed: u64) -> Self {
            let mut rng = FastRngPub::new(seed);
            let mut rw = |n: usize, s: f32| -> Vec<f32> {
                (0..n).map(|_| (((rng.next_u64() % 10000) as f32 / 5000.0) - 1.0) * s).collect()
            };
            let net = ProBidNet {
                w1: rw(BID_IN_DIM * BID_H_DIM, (2.0 / BID_IN_DIM as f32).sqrt()),
                b1: vec![0.0; BID_H_DIM],
                w2: rw(BID_H_DIM, (1.0 / BID_H_DIM as f32).sqrt()),
                b2: 16.5,
            };
            Self {
                mw1: vec![0.0; BID_IN_DIM * BID_H_DIM], vw1: vec![0.0; BID_IN_DIM * BID_H_DIM],
                mb1: vec![0.0; BID_H_DIM], vb1: vec![0.0; BID_H_DIM],
                mw2: vec![0.0; BID_H_DIM], vw2: vec![0.0; BID_H_DIM],
                mb2: 0.0, vb2: 0.0, step: 0, net,
            }
        }

        fn train_batch(&mut self, batch: &[([f32; BID_IN_DIM], f32)], lr: f32) -> f32 {
            let mut gw1 = vec![0.0_f32; BID_IN_DIM * BID_H_DIM];
            let mut gb1 = vec![0.0_f32; BID_H_DIM];
            let mut gw2 = vec![0.0_f32; BID_H_DIM];
            let mut gb2 = 0.0_f32;
            let mut mse = 0.0_f32;

            for &(ref x, target) in batch {
                let mut z1 = [0.0_f32; BID_H_DIM];
                let mut h1 = [0.0_f32; BID_H_DIM];
                for j in 0..BID_H_DIM {
                    let mut s = self.net.b1[j];
                    let row = j * BID_IN_DIM;
                    for i in 0..BID_IN_DIM { s += self.net.w1[row + i] * x[i]; }
                    z1[j] = s;
                    h1[j] = if s > 0.0 { s } else { 0.01 * s };
                }
                let mut pred = self.net.b2;
                for j in 0..BID_H_DIM { pred += self.net.w2[j] * h1[j]; }
                let diff = pred - target;
                mse += diff * diff;
                let d_out = 2.0 * diff;
                gb2 += d_out;
                for j in 0..BID_H_DIM {
                    gw2[j] += d_out * h1[j];
                    let dz = d_out * self.net.w2[j] * if z1[j] > 0.0 { 1.0 } else { 0.01 };
                    gb1[j] += dz;
                    let row = j * BID_IN_DIM;
                    for i in 0..BID_IN_DIM { gw1[row + i] += dz * x[i]; }
                }
            }
            let inv = 1.0 / batch.len().max(1) as f32;
            self.step += 1;
            let b1c = 1.0 - 0.9_f32.powi(self.step);
            let b2c = 1.0 - 0.999_f32.powi(self.step);
            let upd = |w: &mut [f32], g: &[f32], m: &mut [f32], v: &mut [f32], wd: f32| {
                for i in 0..w.len() {
                    let gi = g[i] * inv + wd * w[i];
                    m[i] = 0.9 * m[i] + 0.1 * gi;
                    v[i] = 0.999 * v[i] + 0.001 * gi * gi;
                    w[i] -= lr * (m[i] / b1c) / ((v[i] / b2c).sqrt() + 1e-8);
                }
            };
            upd(&mut self.net.w1, &gw1, &mut self.mw1, &mut self.vw1, 1e-3);
            upd(&mut self.net.b1, &gb1, &mut self.mb1, &mut self.vb1, 0.0);
            upd(&mut self.net.w2, &gw2, &mut self.mw2, &mut self.vw2, 1e-3);
            let g2 = gb2 * inv;
            self.mb2 = 0.9 * self.mb2 + 0.1 * g2;
            self.vb2 = 0.999 * self.vb2 + 0.001 * g2 * g2;
            self.net.b2 -= lr * (self.mb2 / b1c) / ((self.vb2 / b2c).sqrt() + 1e-8);
            mse * inv
        }
    }

    #[test]
    #[ignore]
    fn train_pro_rl_v2_offline() {
        let mut rng = StdRng::seed_from_u64(2026_999);
        let mut explore_rng = FastRngPub::new(2026_777);

        let total_hands = 30_000usize;
        let mut bid_samples: Vec<([f32; BID_IN_DIM], f32)> = Vec::with_capacity(total_hands);
        let mut val_samples: Vec<([f32; IN_DIM], f32)> = Vec::with_capacity(550_000);

        let mut hands = 0usize;
        let mut engine = GameEngine::new("RLV2", GameConfig::default());
        engine.start_hand(&mut rng);
        let mut opening_4: [Vec<Card>; 4] = Default::default();
        let mut captured_open = false;
        let mut hand_traj: Vec<([f32; IN_DIM], Team)> = Vec::with_capacity(32);

        while hands < total_hands {
            if engine.phase == GamePhase::Bidding && !captured_open {
                for s in 0..4usize { opening_4[s] = engine.hands[s].clone(); }
                captured_open = true;
            }
            match engine.phase {
                GamePhase::HandComplete | GamePhase::MatchComplete => {
                    hands += 1;
                    if let Some(sum) = engine.hand_history.last() {
                        // Record bidder 4-card opening hand -> actual captured points
                        let bf = extract_bid_features(&opening_4[sum.bidder], engine.config.allow_reverse_rule_option);
                        bid_samples.push((bf, sum.bidding_team_points as f32));

                        // Collect Gen-2 value transitions from the first 16,000 hands
                        if hands <= 16_000 {
                            for (feat, team) in hand_traj.drain(..) {
                                let won = if sum.winning_team == team { 1.0_f32 } else { 0.0_f32 };
                                let pts = if sum.bidding_team == team {
                                    sum.bidding_team_points as f32
                                } else {
                                    sum.opposing_team_points as f32
                                };
                                val_samples.push((feat, 0.85 * won + 0.15 * (pts / 28.0)));
                            }
                        } else {
                            hand_traj.clear();
                        }
                    }
                    if engine.phase == GamePhase::MatchComplete {
                        engine = GameEngine::new("RLV2", GameConfig::default());
                    }
                    engine.start_hand(&mut rng);
                    captured_open = false;
                }
                GamePhase::DoubleWindow => {
                    for s in 0..4usize {
                        if let Some(msg) = crate::bot::choose_calibrated_heuristic_only_action(&engine, s) {
                            match msg {
                                ClientMessage::DoubleStakes => { engine.call_double(s).unwrap(); }
                                ClientMessage::RedoubleStakes => { engine.call_redouble(s).unwrap(); }
                                ClientMessage::PassDoubleWindow => { engine.pass_double_window(s).unwrap(); }
                                _ => {}
                            }
                            break;
                        }
                    }
                }
                GamePhase::Playing => {
                    let seat = engine.current_turn;
                    if hands < 16_000 {
                        hand_traj.push((extract_state_features(&engine, seat), Team::of_seat(seat)));
                    }
                    let view = engine.view_for_seat(seat, None);
                    // On last 2 tricks of first 4,000 hands, use exact Alpha-Beta so Gen-2 Value Net learns optimal endgame values!
                    let msg = if hands < 4_000 && view.your_hand.len() <= 2 && view.trump_exposed && view.legal_cards.len() > 1 {
                        let my_team = Team::of_seat(seat);
                        let mut best_c = view.legal_cards[0];
                        let mut best_v = i32::MIN;
                        for &c in &view.legal_cards {
                            let mut sim = engine.clone();
                            if sim.play_card(seat, c).is_ok() {
                                let mini = MiniEndgame::from_engine(&sim);
                                let mut nodes = 0usize;
                                let v = alphabeta_endgame(&mini, my_team, i32::MIN + 1, i32::MAX - 1, &mut nodes);
                                if v > best_v { best_v = v; best_c = c; }
                            }
                        }
                        ClientMessage::PlayCard { card_id: best_c.id() }
                    } else if (explore_rng.next_u64() % 100) < 10 && !view.legal_cards.is_empty() {
                        let pick = view.legal_cards[(explore_rng.next_u64() as usize) % view.legal_cards.len()];
                        ClientMessage::PlayCard { card_id: pick.id() }
                    } else {
                        decide_play_heuristic_pub(&engine, seat).unwrap()
                    };
                    match msg {
                        ClientMessage::RequestTrumpShow => { engine.request_trump_show(seat).unwrap(); }
                        ClientMessage::DeclareMarriage { card_id } => {
                            engine.declare_marriage(seat, Card::from_id(&card_id).unwrap()).unwrap();
                        }
                        ClientMessage::PlayCard { card_id } => {
                            engine.play_card(seat, Card::from_id(&card_id).unwrap()).unwrap();
                        }
                        _ => {}
                    }
                }
                _ => {
                    let seat = engine.current_turn;
                    let msg = crate::bot::choose_calibrated_heuristic_only_action(&engine, seat).unwrap();
                    match msg {
                        ClientMessage::PlaceBid { amount } => { engine.place_bid(seat, amount).unwrap(); }
                        ClientMessage::PassBid => { engine.pass_bid(seat, &mut rng).unwrap(); }
                        ClientMessage::ChooseSeventhCard => { engine.choose_seventh_card(seat).unwrap(); }
                        ClientMessage::SelectTrump { suit, reverse_enabled, mode } => {
                            engine.select_trump_with_mode(seat, suit, reverse_enabled, mode).unwrap();
                        }
                        _ => {}
                    }
                }
            }
        }

        // 1. Train ProBidNet on 30,000 hands
        let bid_n = bid_samples.len();
        let bsplit = (bid_n * 9) / 10;
        let (b_train, b_val) = bid_samples.split_at_mut(bsplit);
        let mut btrainer = AdamBidNet::new(42_029);
        for ep in 0..16 {
            explore_rng.shuffle(b_train);
            let lr = 0.005 * (0.86_f32).powi(ep);
            for chunk in b_train.chunks(128) {
                btrainer.train_batch(chunk, lr);
            }
        }
        let mut b_val_mse = 0.0_f32;
        for &(ref x, y) in b_val.iter() {
            let p = btrainer.net.predict_expected_pts(x);
            b_val_mse += (p - y) * (p - y);
        }
        println!("ProBidNet trained on {} hands | Val RMSE = {:.3} pts", bid_n, (b_val_mse / b_val.len() as f32).sqrt());

        // 2. Train Gen-2 ProValueNet on 520k transitions (with Alpha-Beta endgame trajectories!)
        let val_n = val_samples.len();
        let vsplit = (val_n * 9) / 10;
        let (v_train, v_val) = val_samples.split_at_mut(vsplit);
        let mut vtrainer = AdamValNet::new(99_029);
        for ep in 0..8 {
            explore_rng.shuffle(v_train);
            let lr = 0.0025 * (0.78_f32).powi(ep);
            for chunk in v_train.chunks(256) {
                vtrainer.train_batch(chunk, lr);
            }
        }
        let mut v_ok = 0usize;
        for &(ref x, y) in v_val.iter() {
            if (vtrainer.net.predict(x) >= 0.5) == (y >= 0.5) { v_ok += 1; }
        }
        println!("Gen-2 ProValueNet trained on {} transitions | Val Acc = {:.2}%",
            val_n, (v_ok as f64 / v_val.len() as f64) * 100.0);

        // Save both networks to rl_weights.rs
        let mut out = String::new();
        out.push_str("// Auto-generated Offline-RL v2 weights: ProValueNet (42->48->24->1) + ProBidNet (24->32->1).\n");
        out.push_str(&format!("pub const IN_DIM: usize = {};\npub const H1_DIM: usize = {};\npub const H2_DIM: usize = {};\n\n", IN_DIM, H1_DIM, H2_DIM));
        let fmt_arr = |name: &str, arr: &[f32]| -> String {
            let mut s = format!("pub static {}: [f32; {}] = [\n", name, arr.len());
            for chunk in arr.chunks(8) {
                s.push_str("    ");
                for &v in chunk { s.push_str(&format!("{:.5}, ", v)); }
                s.push('\n');
            }
            s.push_str("];\n\n");
            s
        };
        out.push_str(&fmt_arr("W1", &vtrainer.net.w1));
        out.push_str(&fmt_arr("B1", &vtrainer.net.b1));
        out.push_str(&fmt_arr("W2", &vtrainer.net.w2));
        out.push_str(&fmt_arr("B2", &vtrainer.net.b2));
        out.push_str(&fmt_arr("W3", &vtrainer.net.w3));
        out.push_str(&format!("pub static B3: f32 = {:.5};\n\n", vtrainer.net.b3));

        out.push_str(&format!("pub const BID_IN_DIM: usize = {};\npub const BID_H_DIM: usize = {};\n\n", BID_IN_DIM, BID_H_DIM));
        out.push_str(&fmt_arr("BW1", &btrainer.net.w1));
        out.push_str(&fmt_arr("BB1", &btrainer.net.b1));
        out.push_str(&fmt_arr("BW2", &btrainer.net.w2));
        out.push_str(&format!("pub static BB2: f32 = {:.5};\n", btrainer.net.b2));

        let weights_path = Path::new(env!("CARGO_MANIFEST_DIR")).join("src/rl_weights.rs");
        std::fs::write(&weights_path, out).expect("write rl_weights.rs");
        println!("Saved Offline-RL v2 weights (~16 KB total) to {:?}", weights_path);
    }
}
