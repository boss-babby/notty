//! Pro RL v4:
//! - 240-dim suit-canonicalized seat-attributed + "failed-to-beat" logical deduction state
//! - ProValueNetV4 (240 -> 128 -> 64 -> 1, 39,169 weights)
//! - ProPolicyNetV4 (240 -> 64 -> 33 [32 cards + ShowTrump], 17,569 weights) for pure neural PIMC rollouts
//! - ProBidNetV4 (32 -> 64 -> 32 -> 2 [expected_pts + double_win_prob], 4,258 weights)
//! - Deduction-guided Bayesian PIMC + 4-Trick Move-Ordered Exact Alpha-Beta Endgame
//! - Population-diverse multi-generation self-play trainer (1M+ hands) + 100k-hand eval vs Frozen v3.2.

use crate::engine::GameEngine;
use crate::rl_v3::{
    alphabeta_4trick, card_pts, card_strength, card_to_u8, extract_v3_bid_features,
    fast_heuristic_action, FastRng, FastState, V3_BID_IN,
};

pub const V4_IN: usize = 240;
pub const V4_H1: usize = 128;
pub const V4_H2: usize = 64;

pub const V4_POL_H: usize = 64;
pub const V4_POL_OUT: usize = 33; // 0..32 canonical cards, 32 = ShowTrump

pub const V4_BID_IN: usize = V3_BID_IN; // 32
pub const V4_BID_H1: usize = 64;
pub const V4_BID_H2: usize = 32;

/// Seat-attributed & deduction-enriched fast state wrapping `FastState` (zero heap allocations).
#[derive(Clone, Copy)]
pub struct FastStateV4 {
    pub base: FastState,
    pub played_by: [u32; 4],    // exact 32-card bitmask played by each seat
    pub failed_beat: [u8; 4],   // 4-bit suit mask: seat followed suit & failed to beat a winning opp high card
}

impl FastStateV4 {
    pub fn from_base(base: FastState) -> Self {
        Self {
            base,
            played_by: [0; 4],
            failed_beat: [0; 4],
        }
    }

    pub fn from_engine(e: &GameEngine) -> Self {
        let base = FastState::from_engine(e);
        let mut played_by = [0u32; 4];
        let mut failed_beat = [0u8; 4];
        let rev = e.is_reverse_active();

        let mut scan_trick = |plays: &[crate::protocol::TrickPlay]| {
            if plays.is_empty() { return; }
            let led_suit = card_to_u8(plays[0].card) >> 3;
            let mut best_str = card_strength(card_to_u8(plays[0].card), rev);
            let mut best_seat = plays[0].seat as u8;
            let mut trick_pts = card_pts(card_to_u8(plays[0].card));
            played_by[plays[0].seat] |= 1u32 << card_to_u8(plays[0].card);

            for p in &plays[1..] {
                let cid = card_to_u8(p.card);
                played_by[p.seat] |= 1u32 << cid;
                let s = cid >> 3;
                let cstr = card_strength(cid, rev);
                if s == led_suit {
                    if cstr > best_str {
                        best_str = cstr;
                        best_seat = p.seat as u8;
                    } else if FastState::team_of(best_seat) != FastState::team_of(p.seat as u8)
                        && (trick_pts >= 2 || best_str >= 5)
                    {
                        failed_beat[p.seat] |= 1u8 << led_suit;
                    }
                }
                trick_pts += card_pts(cid);
            }
        };

        for tr in &e.completed_tricks {
            scan_trick(&tr.plays);
        }
        scan_trick(&e.current_trick);

        Self { base, played_by, failed_beat }
    }

    #[inline(always)]
    pub fn expose_trump(&mut self, seat: u8) {
        self.base.expose_trump(seat);
    }

    #[inline(always)]
    pub fn check_auto_marriage(&mut self, seat: u8) {
        self.base.check_auto_marriage(seat);
    }

    #[inline(always)]
    pub fn play_card(&mut self, card: u8) {
        let seat = self.base.turn;
        if self.base.trick_len > 0 {
            let led_suit = self.base.trick_cards[0] >> 3;
            if (card >> 3) == led_suit {
                let cur_win = self.base.trick_winner_now();
                if FastState::team_of(cur_win) != FastState::team_of(seat) {
                    let mut tpts = 0u8;
                    for i in 0..(self.base.trick_len as usize) {
                        tpts += card_pts(self.base.trick_cards[i]);
                    }
                    let mut sim = self.base;
                    sim.trick_cards[sim.trick_len as usize] = card;
                    sim.trick_seats[sim.trick_len as usize] = seat;
                    sim.trick_len += 1;
                    if sim.trick_winner_now() != seat && tpts >= 2 {
                        self.failed_beat[seat as usize] |= 1u8 << led_suit;
                    }
                }
            }
        }
        self.played_by[seat as usize] |= 1u32 << card;
        self.base.play_card(card);
    }
}

/// Extract 240 suit-canonicalized, seat-attributed + logical-deduction features.
#[inline]
pub fn extract_v4_features(st: &FastStateV4, seat: u8) -> [f32; V4_IN] {
    let mut f = [0.0_f32; V4_IN];
    let b = &st.base;
    let my_team = FastState::team_of(seat);
    let bt = FastState::team_of(b.bidder);
    let on_bt = my_team == bt;
    let known_t = if b.trump_exposed || seat == b.bidder { b.trump_suit } else { -1 };
    let suit_shift: u8 = if known_t >= 0 { known_t as u8 } else { 0 };

    let canon = |c: u8| -> usize {
        let s = ((c >> 3) + 4 - suit_shift) & 3;
        ((s << 3) | (c & 7)) as usize
    };

    // [0..32]: my_hand
    let mut h = b.hands[seat as usize];
    while h != 0 {
        let c = h.trailing_zeros() as u8;
        h &= h - 1;
        f[canon(c)] = 1.0;
    }

    // [32..160]: 4 seat-relative played_by planes (self=0, left=1, partner=2, right=3)
    for rel in 0..4u8 {
        let abs_s = ((seat + rel) & 3) as usize;
        let base_off = 32 + (rel as usize) * 32;
        let mut p = st.played_by[abs_s];
        while p != 0 {
            let c = p.trailing_zeros() as u8;
            p &= p - 1;
            f[base_off + canon(c)] = 1.0;
        }
    }

    // [160..192]: current trick (signed: +1 our team, -1 opponent)
    let mut trick_pts = 0u8;
    for i in 0..(b.trick_len as usize) {
        let c = b.trick_cards[i];
        trick_pts += card_pts(c);
        let sign = if FastState::team_of(b.trick_seats[i]) == my_team { 1.0 } else { -1.0 };
        f[160 + canon(c)] = sign;
    }

    // [192..208]: seat-relative voids (4 seats x 4 canonical suits)
    // [208..224]: seat-relative failed_beat deductions (4 seats x 4 canonical suits)
    for rel in 0..4u8 {
        let abs_s = ((seat + rel) & 3) as usize;
        let vm = b.voids[abs_s];
        let fm = st.failed_beat[abs_s];
        for s in 0..4u8 {
            let cs = ((s + 4 - suit_shift) & 3) as usize;
            if (vm & (1u8 << s)) != 0 {
                f[192 + (rel as usize) * 4 + cs] = 1.0;
            }
            if (fm & (1u8 << s)) != 0 {
                f[208 + (rel as usize) * 4 + cs] = 1.0;
            }
        }
    }

    // [224..240]: 16 rich scalar game-state features
    let my_pts = b.pts[my_team] as f32;
    let opp_pts = b.pts[1 - my_team] as f32;
    let target = b.eff_bid as f32;
    let pts_needed = if on_bt { (target - my_pts).max(0.0) } else { ((29.0 - target) - my_pts).max(0.0) };
    let opp_needed = if on_bt { ((29.0 - target) - opp_pts).max(0.0) } else { (target - opp_pts).max(0.0) };
    let my_t_cnt = if known_t >= 0 {
        (b.hands[seat as usize] & (0xFFu32 << ((known_t as u8) * 8))).count_ones() as f32
    } else {
        0.0
    };
    let unseen_t = if known_t >= 0 {
        let tmask = 0xFFu32 << ((known_t as u8) * 8);
        (8 - ((b.played | b.hands[seat as usize]) & tmask).count_ones()) as f32
    } else {
        0.0
    };
    let partner = (seat + 2) & 3;
    let cur_win_ours = if b.trick_len > 0 {
        if FastState::team_of(b.trick_winner_now()) == my_team { 1.0 } else { -1.0 }
    } else {
        0.0
    };

    f[224] = if on_bt { 1.0 } else { 0.0 };
    f[225] = (target - 16.0) / 12.0;
    f[226] = my_pts / 28.0;
    f[227] = opp_pts / 28.0;
    f[228] = pts_needed / 28.0;
    f[229] = opp_needed / 28.0;
    f[230] = b.tricks_done as f32 / 8.0;
    f[231] = if b.trump_exposed { 1.0 } else { 0.0 };
    f[232] = if b.reverse_active() { 1.0 } else if seat == b.bidder && b.reverse_enabled { 0.5 } else { 0.0 };
    f[233] = if known_t < 0 && b.trump_exposed { 1.0 } else { 0.0 };
    f[234] = if b.leader == seat { 1.0 } else if b.leader == partner { 0.5 } else { 0.0 };
    f[235] = my_t_cnt / 8.0;
    f[236] = unseen_t / 8.0;
    f[237] = if seat == ((b.dealer + 1) & 3) { 1.0 } else { 0.0 };
    f[238] = trick_pts as f32 / 12.0;
    f[239] = cur_win_ours;
    f
}

#[inline(always)]
pub fn canonical_card_idx(st: &FastState, seat: u8, c: u8) -> usize {
    let known_t = if st.trump_exposed || seat == st.bidder { st.trump_suit } else { -1 };
    let suit_shift: u8 = if known_t >= 0 { known_t as u8 } else { 0 };
    let s = ((c >> 3) + 4 - suit_shift) & 3;
    ((s << 3) | (c & 7)) as usize
}

// ============================================================================
// Pro RL v4 Neural Networks (Value + Policy + Dual-Head Bid/Double)
// ============================================================================

#[derive(Clone)]
pub struct ProValueNetV4 {
    pub w1: Vec<f32>, // 128 * 240 = 30,720
    pub b1: Vec<f32>, // 128
    pub w2: Vec<f32>, // 64 * 128 = 8,192
    pub b2: Vec<f32>, // 64
    pub w3: Vec<f32>, // 64
    pub b3: f32,      // 1 -> Total: 39,169 weights
}

impl ProValueNetV4 {
    pub fn from_embedded() -> Self {
        use crate::rl_weights_v4::*;
        Self {
            w1: V4_W1.to_vec(), b1: V4_B1.to_vec(),
            w2: V4_W2.to_vec(), b2: V4_B2.to_vec(),
            w3: V4_W3.to_vec(), b3: V4_B3,
        }
    }
    pub fn new_random(seed: u64) -> Self {
        let mut rng = FastRng::new(seed);
        let mut init = |n: usize, s: f32| -> Vec<f32> {
            (0..n).map(|_| (rng.next_f32() * 2.0 - 1.0) * s).collect()
        };
        Self {
            w1: init(V4_H1 * V4_IN, (2.0 / V4_IN as f32).sqrt()),
            b1: vec![0.0; V4_H1],
            w2: init(V4_H2 * V4_H1, (2.0 / V4_H1 as f32).sqrt()),
            b2: vec![0.0; V4_H2],
            w3: init(V4_H2, (1.0 / V4_H2 as f32).sqrt()),
            b3: 0.0,
        }
    }

    #[inline]
    pub fn predict(&self, x: &[f32; V4_IN]) -> f32 {
        let mut h1 = [0.0_f32; V4_H1];
        for j in 0..V4_H1 {
            let row = &self.w1[j * V4_IN..(j + 1) * V4_IN];
            let mut s = self.b1[j];
            for i in 0..V4_IN { s += row[i] * x[i]; }
            h1[j] = if s > 0.0 { s } else { 0.01 * s };
        }
        let mut h2 = [0.0_f32; V4_H2];
        for k in 0..V4_H2 {
            let row = &self.w2[k * V4_H1..(k + 1) * V4_H1];
            let mut s = self.b2[k];
            for j in 0..V4_H1 { s += row[j] * h1[j]; }
            h2[k] = if s > 0.0 { s } else { 0.01 * s };
        }
        let mut out = self.b3;
        for k in 0..V4_H2 { out += self.w3[k] * h2[k]; }
        1.0 / (1.0 + (-out.clamp(-12.0, 12.0)).exp())
    }
}

/// Lightweight Neural Policy Network (240 -> 64 -> 33, 17,569 weights):
/// Scores all 32 canonical cards + ShowTrump in ONE fast forward pass (~15 us),
/// replacing hard-coded heuristics inside PIMC rollouts!
#[derive(Clone)]
pub struct ProPolicyNetV4 {
    pub w1: Vec<f32>, // 64 * 240 = 15,360
    pub b1: Vec<f32>, // 64
    pub w2: Vec<f32>, // 33 * 64 = 2,112
    pub b2: Vec<f32>, // 33 -> Total: 17,569 weights
}

impl ProPolicyNetV4 {
    pub fn from_embedded() -> Self {
        use crate::rl_weights_v4::*;
        Self {
            w1: V4_PW1.to_vec(), b1: V4_PB1.to_vec(),
            w2: V4_PW2.to_vec(), b2: V4_PB2.to_vec(),
        }
    }
    pub fn new_random(seed: u64) -> Self {
        let mut rng = FastRng::new(seed);
        let mut init = |n: usize, s: f32| -> Vec<f32> {
            (0..n).map(|_| (rng.next_f32() * 2.0 - 1.0) * s).collect()
        };
        Self {
            w1: init(V4_POL_H * V4_IN, (2.0 / V4_IN as f32).sqrt()),
            b1: vec![0.0; V4_POL_H],
            w2: init(V4_POL_OUT * V4_POL_H, (1.0 / V4_POL_H as f32).sqrt()),
            b2: vec![0.0; V4_POL_OUT],
        }
    }

    #[inline]
    pub fn logits(&self, x: &[f32; V4_IN]) -> [f32; V4_POL_OUT] {
        let mut h = [0.0_f32; V4_POL_H];
        for j in 0..V4_POL_H {
            let row = &self.w1[j * V4_IN..(j + 1) * V4_IN];
            let mut s = self.b1[j];
            for i in 0..V4_IN { s += row[i] * x[i]; }
            h[j] = if s > 0.0 { s } else { 0.01 * s };
        }
        let mut out = [0.0_f32; V4_POL_OUT];
        for k in 0..V4_POL_OUT {
            let row = &self.w2[k * V4_POL_H..(k + 1) * V4_POL_H];
            let mut s = self.b2[k];
            for j in 0..V4_POL_H { s += row[j] * h[j]; }
            out[k] = s;
        }
        out
    }

    /// Pick the highest-logit legal action (card or ShowTrump) in one pass!
    #[inline]
    pub fn choose_action(&self, st: &FastStateV4) -> (bool, u8) {
        let seat = st.base.turn;
        let legal = st.base.legal_mask(seat);
        let can_show = st.base.can_show_trump(seat);
        if legal.count_ones() == 1 && !can_show {
            return (false, legal.trailing_zeros() as u8);
        }
        let feat = extract_v4_features(st, seat);
        let lg = self.logits(&feat);
        let mut best_act = (false, legal.trailing_zeros() as u8);
        let mut best_l = -1e9_f32;
        let mut m = legal;
        while m != 0 {
            let c = m.trailing_zeros() as u8;
            m &= m - 1;
            let ci = canonical_card_idx(&st.base, seat, c);
            if lg[ci] > best_l {
                best_l = lg[ci];
                best_act = (false, c);
            }
        }
        if can_show && lg[32] > best_l {
            best_act = (true, 0);
        }
        best_act
    }
}

/// Dual-head Bid + Double/Redouble Network (32 -> 64 -> 32 -> 2, 4,258 weights).
#[derive(Clone)]
pub struct ProBidNetV4 {
    pub w1: Vec<f32>, // 64 * 32 = 2,048
    pub b1: Vec<f32>, // 64
    pub w2: Vec<f32>, // 32 * 64 = 2,048
    pub b2: Vec<f32>, // 32
    pub w3: Vec<f32>, // 2 * 32 = 64 ([0..32]=pts head, [32..64]=win_prob head)
    pub b3: [f32; 2], // 2 -> Total: 4,258 weights
}

impl ProBidNetV4 {
    pub fn from_embedded() -> Self {
        use crate::rl_weights_v4::*;
        Self {
            w1: V4_BW1.to_vec(), b1: V4_BB1.to_vec(),
            w2: V4_BW2.to_vec(), b2: V4_BB2.to_vec(),
            w3: V4_BW3.to_vec(), b3: V4_BB3,
        }
    }
    pub fn new_random(seed: u64) -> Self {
        let mut rng = FastRng::new(seed);
        let mut init = |n: usize, s: f32| -> Vec<f32> {
            (0..n).map(|_| (rng.next_f32() * 2.0 - 1.0) * s).collect()
        };
        Self {
            w1: init(V4_BID_H1 * V4_BID_IN, (2.0 / V4_BID_IN as f32).sqrt()),
            b1: vec![0.0; V4_BID_H1],
            w2: init(V4_BID_H2 * V4_BID_H1, (2.0 / V4_BID_H1 as f32).sqrt()),
            b2: vec![0.0; V4_BID_H2],
            w3: init(2 * V4_BID_H2, (1.0 / V4_BID_H2 as f32).sqrt()),
            b3: [16.0, 0.0],
        }
    }

    #[inline]
    pub fn predict(&self, x: &[f32; V4_BID_IN]) -> (f32, f32) {
        let mut h1 = [0.0_f32; V4_BID_H1];
        for j in 0..V4_BID_H1 {
            let row = &self.w1[j * V4_BID_IN..(j + 1) * V4_BID_IN];
            let mut s = self.b1[j];
            for i in 0..V4_BID_IN { s += row[i] * x[i]; }
            h1[j] = if s > 0.0 { s } else { 0.01 * s };
        }
        let mut h2 = [0.0_f32; V4_BID_H2];
        for k in 0..V4_BID_H2 {
            let row = &self.w2[k * V4_BID_H1..(k + 1) * V4_BID_H1];
            let mut s = self.b2[k];
            for j in 0..V4_BID_H1 { s += row[j] * h1[j]; }
            h2[k] = if s > 0.0 { s } else { 0.01 * s };
        }
        let mut pts = self.b3[0];
        let mut wlog = self.b3[1];
        for k in 0..V4_BID_H2 {
            pts += self.w3[k] * h2[k];
            wlog += self.w3[V4_BID_H2 + k] * h2[k];
        }
        let win_p = 1.0 / (1.0 + (-wlog.clamp(-10.0, 10.0)).exp());
        (pts.clamp(11.0, 27.0), win_p)
    }
}

// ============================================================================
// Deduction-Guided Bayesian PIMC Sampler + Pro RL v4 Move Selector
// ============================================================================

#[inline]
pub fn sample_v4_world(st: &FastStateV4, seat: u8, rng: &mut FastRng) -> [u32; 4] {
    let b = &st.base;
    let mut sizes = [0usize; 4];
    for s in 0..4 {
        sizes[s] = b.hands[s].count_ones() as usize;
    }
    let known = b.played | b.hands[seat as usize]
        | if b.seventh_card >= 0 { 1u32 << (b.seventh_card as u8) } else { 0 };
    let mut unseen = [0u8; 28];
    let mut un = 0usize;
    let mut um = (!known) & 0xFFFF_FFFF;
    while um != 0 {
        unseen[un] = um.trailing_zeros() as u8;
        um &= um - 1;
        un += 1;
    }

    let rev = b.reverse_active();
    for _ in 0..5 {
        for i in (1..un).rev() {
            let j = (rng.next_u64() as usize) % (i + 1);
            unseen.swap(i, j);
        }
        let mut hands = [0u32; 4];
        hands[seat as usize] = b.hands[seat as usize];
        let mut rem = sizes;
        rem[seat as usize] = 0;
        let mut ok = true;

        for &c in &unseen[..un] {
            let suit = c >> 3;
            let sbit = 1u8 << suit;
            let is_top_card = if rev { (c & 7) >= 6 } else { (c & 7) <= 1 };
            let is_trump_c = b.trump_exposed && b.trump_suit >= 0 && suit == b.trump_suit as u8;
            let bid_s = b.bidder as usize;

            // Deduction-guided placement:
            // 1) Respect exact voids strictly.
            // 2) If `is_top_card`, avoid placing it in a seat that already `failed_beat` in that suit!
            // 3) Bias trump & strong cards toward bidder when bid >= 17.
            let mut placed = false;
            let want_bidder = bid_s != seat as usize
                && rem[bid_s] > 0
                && (b.voids[bid_s] & sbit) == 0
                && !(is_top_card && (st.failed_beat[bid_s] & sbit) != 0)
                && ((is_trump_c && (rng.next_u64() & 3) != 0)
                    || (b.bid >= 18 && is_top_card && (rng.next_u64() & 1) == 0));
            if want_bidder {
                hands[bid_s] |= 1u32 << c;
                rem[bid_s] -= 1;
                placed = true;
            } else {
                let start = (rng.next_u64() as usize) & 3;
                // Pass 1: respect voids AND failed_beat deduction for top cards
                if is_top_card {
                    for k in 0..4 {
                        let s = (start + k) & 3;
                        if rem[s] > 0 && (b.voids[s] & sbit) == 0 && (st.failed_beat[s] & sbit) == 0 {
                            hands[s] |= 1u32 << c;
                            rem[s] -= 1;
                            placed = true;
                            break;
                        }
                    }
                }
                // Pass 2: respect exact voids
                if !placed {
                    for k in 0..4 {
                        let s = (start + k) & 3;
                        if rem[s] > 0 && (b.voids[s] & sbit) == 0 {
                            hands[s] |= 1u32 << c;
                            rem[s] -= 1;
                            placed = true;
                            break;
                        }
                    }
                }
            }
            if !placed {
                ok = false;
                break;
            }
        }
        if ok {
            return hands;
        }
    }

    // Fallback
    let mut hands = [0u32; 4];
    hands[seat as usize] = b.hands[seat as usize];
    let mut idx = 0usize;
    for s in 0..4 {
        if s == seat as usize { continue; }
        for _ in 0..sizes[s] {
            if idx < un {
                hands[s] |= 1u32 << unseen[idx];
                idx += 1;
            }
        }
    }
    hands
}

/// Pro RL v4 Move Selector:
/// - Deduction-guided Bayesian PIMC
/// - Neural Policy Rollouts (`ProPolicyNetV4`) when `use_policy_rollout` is true!
/// - 4-Trick Move-Ordered Exact Alpha-Beta Endgame
/// - 240-dim Seat-Attributed `ProValueNetV4` leaf evaluation!
pub fn choose_v4_fast_play(
    st: &FastStateV4,
    vnet: &ProValueNetV4,
    pnet: &ProPolicyNetV4,
    samples: usize,
    use_policy_rollout: bool,
    rng: &mut FastRng,
) -> (bool, u8) {
    let seat = st.base.turn;
    let legal = st.base.legal_mask(seat);
    let can_show = st.base.can_show_trump(seat);

    if legal.count_ones() == 1 && !can_show {
        return (false, legal.trailing_zeros() as u8);
    }

    let mut actions = [(false, 0u8); 9];
    let mut na = 0usize;
    let mut m = legal;
    while m != 0 {
        actions[na] = (false, m.trailing_zeros() as u8);
        m &= m - 1;
        na += 1;
    }
    if can_show {
        actions[na] = (true, 0);
        na += 1;
    }

    let my_team = FastState::team_of(seat);
    let cards_left = st.base.hands[seat as usize].count_ones() as usize;
    let use_ab = st.base.trump_exposed && cards_left <= 4;
    let node_limit = if cards_left == 4 { 2000 } else { 4000 };
    let rollout_tricks = if cards_left <= 5 { 8 } else { 2 };

    // Small prior from PolicyNetV4 for tie-breaking & variance reduction
    let p_logits = if use_policy_rollout {
        Some(pnet.logits(&extract_v4_features(st, seat)))
    } else {
        None
    };

    let mut scores = [0.0_f32; 9];
    if let Some(lg) = p_logits {
        for ai in 0..na {
            let (sh, c) = actions[ai];
            let idx = if sh { 32 } else { canonical_card_idx(&st.base, seat, c) };
            scores[ai] += lg[idx].clamp(-3.0, 3.0) * 0.12;
        }
    }

    for _ in 0..samples {
        let world = sample_v4_world(st, seat, rng);
        for ai in 0..na {
            let mut sim = *st;
            sim.base.hands = world;
            let start_tr = sim.base.tricks_done;
            let (is_show, card) = actions[ai];
            if is_show {
                sim.expose_trump(seat);
                sim.check_auto_marriage(seat);
                let (_, c2) = if use_policy_rollout {
                    pnet.choose_action(&sim)
                } else {
                    fast_heuristic_action(&sim.base)
                };
                sim.play_card(c2);
            } else {
                sim.play_card(card);
            }

            if use_ab && sim.base.tricks_done < 8 {
                let mut nodes = 0usize;
                let ab = alphabeta_4trick(&sim.base, my_team, i32::MIN + 1, i32::MAX - 1, &mut nodes, node_limit);
                let won = if ab >= 100 { 10.0_f32 } else { 0.0_f32 };
                let pts = (ab % 100) as f32;
                scores[ai] += won + pts * 0.08;
                continue;
            }

            let mut guard = 0u8;
            while sim.base.tricks_done < 8
                && (sim.base.tricks_done - start_tr) < rollout_tricks
                && guard < 36
            {
                guard += 1;
                let t = sim.base.turn;
                sim.check_auto_marriage(t);
                let (sh, c) = if use_policy_rollout {
                    pnet.choose_action(&sim)
                } else {
                    fast_heuristic_action(&sim.base)
                };
                if sh {
                    sim.expose_trump(t);
                    sim.check_auto_marriage(t);
                } else {
                    sim.play_card(c);
                }
            }

            if sim.base.tricks_done >= 8 {
                let bt = FastState::team_of(sim.base.bidder);
                let won = if my_team == bt { sim.base.bidding_team_won() } else { !sim.base.bidding_team_won() };
                scores[ai] += (if won { 10.0 } else { 0.0 }) + (sim.base.pts[my_team] as f32) * 0.08;
            } else {
                let feat = extract_v4_features(&sim, seat);
                scores[ai] += vnet.predict(&feat) * 10.0;
            }
        }
    }

    let mut best_i = 0usize;
    for i in 1..na {
        if scores[i] > scores[best_i] {
            best_i = i;
        }
    }
    actions[best_i]
}

// ============================================================================
// Pro RL v4 Multi-Gen Population Self-Play Trainer & 100k Eval vs Frozen v3.2
// ============================================================================

#[cfg(test)]
pub mod v4_trainer {
    use super::*;
    use crate::rl_v3::{choose_v3_fast_play, ProBidNetV3, ProValueNetV3};
    use std::path::Path;
    use std::time::Instant;

    /// Unbiased deal respecting the real `no_four_jacks_deal` rule!
    #[inline]
    fn shuffle_no_4j(rng: &mut FastRng) -> [u8; 32] {
        loop {
            let d = rng.shuffle_deck();
            let mut bad = false;
            for s in 0..4 {
                let mut jc = 0u8;
                for k in 0..4 {
                    if (d[s * 4 + k] & 7) == 0 { jc += 1; }
                    if (d[16 + s * 4 + k] & 7) == 0 { jc += 1; }
                }
                if jc == 4 { bad = true; break; }
            }
            if !bad { return d; }
        }
    }

    #[inline]
    fn choose_fast_trump(hand_mask: u32, is_opening_leader: bool) -> (i8, bool) {
        let mut best_suit = 0i8;
        let mut best_rev = false;
        let mut best_sc = -100.0_f32;
        let tot_j = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 1) != 0).count() as f32;
        let tot_9 = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 2) != 0).count() as f32;
        let tot_7 = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 128) != 0).count() as f32;
        let tot_8 = (0..4u8).filter(|&s| ((hand_mask >> (s * 8)) & 64) != 0).count() as f32;
        let max_len = (0..4u8).map(|s| ((hand_mask >> (s * 8)) & 0xFF).count_ones()).max().unwrap_or(0);

        if max_len <= 2 && (tot_j >= 3.0 || (tot_j >= 2.0 && tot_9 >= 1.0)) { return (-1, false); }
        if max_len <= 2 && tot_7 >= 3.0 && tot_j == 0.0 && tot_9 == 0.0 { return (-1, true); }

        for s in 0..4u8 {
            let sm = (hand_mask >> (s * 8)) & 0xFF;
            let len = sm.count_ones() as f32;
            if len == 0.0 { continue; }
            let mut s_str = 0.0_f32;
            for r in 0..8u8 { if (sm & (1 << r)) != 0 { s_str += (7 - r) as f32; } }
            let has_m = (sm & 48) == 48;
            let straight_sc = len * 5.0 + s_str * 1.4 + if has_m { 6.0 } else { 0.0 };
            if straight_sc > best_sc { best_sc = straight_sc; best_suit = s as i8; best_rev = false; }

            let has_7 = (sm & 128) != 0;
            let has_8 = (sm & 64) != 0;
            if (has_7 || has_8) && (len >= 2.0 || (has_7 && (tot_7 + tot_8) >= 2.0)) {
                let has_78 = has_7 && has_8;
                let side_78 = (tot_7 + tot_8) - if has_7 { 1.0 } else { 0.0 } - if has_8 { 1.0 } else { 0.0 };
                let nt_j9 = (tot_j + tot_9) - if (sm & 1) != 0 { 1.0 } else { 0.0 } - if (sm & 2) != 0 { 1.0 } else { 0.0 };
                let pred_edge = -1.6387
                    + if is_opening_leader { 1.5190 } else { 0.0 }
                    + len * 0.8454 + if has_7 { 0.5625 } else { 0.0 } + if has_8 { 0.1186 } else { 0.0 }
                    + if has_78 { 0.6811 } else { 0.0 } + side_78 * 0.7265
                    - tot_j * 1.5052 - tot_9 * 1.4561 + nt_j9 * 1.2706;
                if pred_edge > 0.75 {
                    let rev_sc = straight_sc + pred_edge * 3.5;
                    if rev_sc > best_sc { best_sc = rev_sc; best_suit = s as i8; best_rev = true; }
                }
            }
        }
        (best_suit, best_rev)
    }

    // AdamW for ProValueNetV4
    struct AdamValV4 {
        net: ProValueNetV4,
        mw1: Vec<f32>, vw1: Vec<f32>, mb1: Vec<f32>, vb1: Vec<f32>,
        mw2: Vec<f32>, vw2: Vec<f32>, mb2: Vec<f32>, vb2: Vec<f32>,
        mw3: Vec<f32>, vw3: Vec<f32>, mb3: f32, vb3: f32,
        step: i32,
    }
    impl AdamValV4 {
        fn new(net: ProValueNetV4) -> Self {
            Self {
                mw1: vec![0.0; V4_H1 * V4_IN], vw1: vec![0.0; V4_H1 * V4_IN],
                mb1: vec![0.0; V4_H1], vb1: vec![0.0; V4_H1],
                mw2: vec![0.0; V4_H2 * V4_H1], vw2: vec![0.0; V4_H2 * V4_H1],
                mb2: vec![0.0; V4_H2], vb2: vec![0.0; V4_H2],
                mw3: vec![0.0; V4_H2], vw3: vec![0.0; V4_H2],
                mb3: 0.0, vb3: 0.0, step: 0, net,
            }
        }
        fn train_batch(&mut self, batch: &[([f32; V4_IN], f32)], lr: f32, wd: f32) -> f32 {
            let mut gw1 = vec![0.0_f32; V4_H1 * V4_IN];
            let mut gb1 = vec![0.0_f32; V4_H1];
            let mut gw2 = vec![0.0_f32; V4_H2 * V4_H1];
            let mut gb2 = vec![0.0_f32; V4_H2];
            let mut gw3 = vec![0.0_f32; V4_H2];
            let mut gb3 = 0.0_f32;
            let mut loss = 0.0_f32;

            for &(ref x, target) in batch {
                let mut z1 = [0.0_f32; V4_H1];
                let mut h1 = [0.0_f32; V4_H1];
                for j in 0..V4_H1 {
                    let row = &self.net.w1[j * V4_IN..(j + 1) * V4_IN];
                    let mut s = self.net.b1[j];
                    for i in 0..V4_IN { s += row[i] * x[i]; }
                    z1[j] = s;
                    h1[j] = if s > 0.0 { s } else { 0.01 * s };
                }
                let mut z2 = [0.0_f32; V4_H2];
                let mut h2 = [0.0_f32; V4_H2];
                for k in 0..V4_H2 {
                    let row = &self.net.w2[k * V4_H1..(k + 1) * V4_H1];
                    let mut s = self.net.b2[k];
                    for j in 0..V4_H1 { s += row[j] * h1[j]; }
                    z2[k] = s;
                    h2[k] = if s > 0.0 { s } else { 0.01 * s };
                }
                let mut out = self.net.b3;
                for k in 0..V4_H2 { out += self.net.w3[k] * h2[k]; }
                let pred = 1.0 / (1.0 + (-out.clamp(-12.0, 12.0)).exp());
                let p_c = pred.clamp(1e-6, 1.0 - 1e-6);
                loss += -(target * p_c.ln() + (1.0 - target) * (1.0 - p_c).ln());

                let dout = pred - target;
                gb3 += dout;
                let mut dh2 = [0.0_f32; V4_H2];
                for k in 0..V4_H2 {
                    gw3[k] += dout * h2[k];
                    dh2[k] = dout * self.net.w3[k] * if z2[k] > 0.0 { 1.0 } else { 0.01 };
                }
                let mut dh1 = [0.0_f32; V4_H1];
                for k in 0..V4_H2 {
                    gb2[k] += dh2[k];
                    let d = dh2[k];
                    let wrow = &self.net.w2[k * V4_H1..(k + 1) * V4_H1];
                    let grow = &mut gw2[k * V4_H1..(k + 1) * V4_H1];
                    for j in 0..V4_H1 { grow[j] += d * h1[j]; dh1[j] += d * wrow[j]; }
                }
                for j in 0..V4_H1 {
                    let d = dh1[j] * if z1[j] > 0.0 { 1.0 } else { 0.01 };
                    gb1[j] += d;
                    let grow = &mut gw1[j * V4_IN..(j + 1) * V4_IN];
                    for i in 0..V4_IN { grow[i] += d * x[i]; }
                }
            }
            let inv = 1.0 / batch.len() as f32;
            self.step += 1;
            let b1c = 1.0 - 0.9_f32.powi(self.step);
            let b2c = 1.0 - 0.999_f32.powi(self.step);
            let upd = |w: &mut [f32], g: &[f32], m: &mut [f32], v: &mut [f32], dec: f32| {
                for i in 0..w.len() {
                    let gi = g[i] * inv;
                    m[i] = 0.9 * m[i] + 0.1 * gi;
                    v[i] = 0.999 * v[i] + 0.001 * gi * gi;
                    w[i] -= lr * ((m[i] / b1c) / ((v[i] / b2c).sqrt() + 1e-8) + dec * w[i]);
                }
            };
            upd(&mut self.net.w1, &gw1, &mut self.mw1, &mut self.vw1, wd);
            upd(&mut self.net.b1, &gb1, &mut self.mb1, &mut self.vb1, 0.0);
            upd(&mut self.net.w2, &gw2, &mut self.mw2, &mut self.vw2, wd);
            upd(&mut self.net.b2, &gb2, &mut self.mb2, &mut self.vb2, 0.0);
            upd(&mut self.net.w3, &gw3, &mut self.mw3, &mut self.vw3, wd);
            let g3 = gb3 * inv;
            self.mb3 = 0.9 * self.mb3 + 0.1 * g3;
            self.vb3 = 0.999 * self.vb3 + 0.001 * g3 * g3;
            self.net.b3 -= lr * (self.mb3 / b1c) / ((self.vb3 / b2c).sqrt() + 1e-8);
            loss * inv
        }
    }

    // AdamW for ProPolicyNetV4 (masked cross-entropy over legal actions!)
    struct AdamPolV4 {
        net: ProPolicyNetV4,
        mw1: Vec<f32>, vw1: Vec<f32>, mb1: Vec<f32>, vb1: Vec<f32>,
        mw2: Vec<f32>, vw2: Vec<f32>, mb2: Vec<f32>, vb2: Vec<f32>,
        step: i32,
    }
    impl AdamPolV4 {
        fn new(net: ProPolicyNetV4) -> Self {
            Self {
                mw1: vec![0.0; V4_POL_H * V4_IN], vw1: vec![0.0; V4_POL_H * V4_IN],
                mb1: vec![0.0; V4_POL_H], vb1: vec![0.0; V4_POL_H],
                mw2: vec![0.0; V4_POL_OUT * V4_POL_H], vw2: vec![0.0; V4_POL_OUT * V4_POL_H],
                mb2: vec![0.0; V4_POL_OUT], vb2: vec![0.0; V4_POL_OUT],
                step: 0, net,
            }
        }
        // Sample: (features, legal_mask_u64 [bits 0..32], target_action_idx 0..32, sample_weight)
        fn train_batch(&mut self, batch: &[([f32; V4_IN], u64, u8, f32)], lr: f32) -> (f32, f32) {
            let mut gw1 = vec![0.0_f32; V4_POL_H * V4_IN];
            let mut gb1 = vec![0.0_f32; V4_POL_H];
            let mut gw2 = vec![0.0_f32; V4_POL_OUT * V4_POL_H];
            let mut gb2 = vec![0.0_f32; V4_POL_OUT];
            let mut loss = 0.0_f32;
            let mut acc = 0usize;

            for &(ref x, lmask, tgt, sw) in batch {
                let mut z1 = [0.0_f32; V4_POL_H];
                let mut h1 = [0.0_f32; V4_POL_H];
                for j in 0..V4_POL_H {
                    let row = &self.net.w1[j * V4_IN..(j + 1) * V4_IN];
                    let mut s = self.net.b1[j];
                    for i in 0..V4_IN { s += row[i] * x[i]; }
                    z1[j] = s;
                    h1[j] = if s > 0.0 { s } else { 0.01 * s };
                }
                // Masked softmax over legal actions only
                let mut logits = [0.0_f32; V4_POL_OUT];
                let mut max_l = -1e9_f32;
                let mut best_k = 0usize;
                for k in 0..V4_POL_OUT {
                    if (lmask & (1u64 << k)) == 0 { continue; }
                    let row = &self.net.w2[k * V4_POL_H..(k + 1) * V4_POL_H];
                    let mut s = self.net.b2[k];
                    for j in 0..V4_POL_H { s += row[j] * h1[j]; }
                    logits[k] = s;
                    if s > max_l { max_l = s; best_k = k; }
                }
                if best_k == tgt as usize { acc += 1; }
                let mut denom = 0.0_f32;
                let mut probs = [0.0_f32; V4_POL_OUT];
                for k in 0..V4_POL_OUT {
                    if (lmask & (1u64 << k)) == 0 { continue; }
                    let e = (logits[k] - max_l).clamp(-20.0, 0.0).exp();
                    probs[k] = e;
                    denom += e;
                }
                let inv_d = 1.0 / denom.max(1e-9);
                for k in 0..V4_POL_OUT { probs[k] *= inv_d; }
                loss += -probs[tgt as usize].clamp(1e-6, 1.0).ln() * sw;

                let mut dh1 = [0.0_f32; V4_POL_H];
                for k in 0..V4_POL_OUT {
                    if (lmask & (1u64 << k)) == 0 { continue; }
                    let dk = (probs[k] - if k == tgt as usize { 1.0 } else { 0.0 }) * sw;
                    gb2[k] += dk;
                    let wrow = &self.net.w2[k * V4_POL_H..(k + 1) * V4_POL_H];
                    let grow = &mut gw2[k * V4_POL_H..(k + 1) * V4_POL_H];
                    for j in 0..V4_POL_H { grow[j] += dk * h1[j]; dh1[j] += dk * wrow[j]; }
                }
                for j in 0..V4_POL_H {
                    let d = dh1[j] * if z1[j] > 0.0 { 1.0 } else { 0.01 };
                    gb1[j] += d;
                    let grow = &mut gw1[j * V4_IN..(j + 1) * V4_IN];
                    for i in 0..V4_IN { grow[i] += d * x[i]; }
                }
            }
            let inv = 1.0 / batch.len() as f32;
            self.step += 1;
            let b1c = 1.0 - 0.9_f32.powi(self.step);
            let b2c = 1.0 - 0.999_f32.powi(self.step);
            let upd = |w: &mut [f32], g: &[f32], m: &mut [f32], v: &mut [f32], dec: f32| {
                for i in 0..w.len() {
                    let gi = g[i] * inv;
                    m[i] = 0.9 * m[i] + 0.1 * gi;
                    v[i] = 0.999 * v[i] + 0.001 * gi * gi;
                    w[i] -= lr * ((m[i] / b1c) / ((v[i] / b2c).sqrt() + 1e-8) + dec * w[i]);
                }
            };
            upd(&mut self.net.w1, &gw1, &mut self.mw1, &mut self.vw1, 1e-4);
            upd(&mut self.net.b1, &gb1, &mut self.mb1, &mut self.vb1, 0.0);
            upd(&mut self.net.w2, &gw2, &mut self.mw2, &mut self.vw2, 1e-4);
            upd(&mut self.net.b2, &gb2, &mut self.mb2, &mut self.vb2, 0.0);
            (loss * inv, 100.0 * acc as f32 * inv)
        }
    }

    // AdamW for Dual-Head ProBidNetV4
    struct AdamBidV4 {
        net: ProBidNetV4,
        mw1: Vec<f32>, vw1: Vec<f32>, mb1: Vec<f32>, vb1: Vec<f32>,
        mw2: Vec<f32>, vw2: Vec<f32>, mb2: Vec<f32>, vb2: Vec<f32>,
        mw3: Vec<f32>, vw3: Vec<f32>, mb3: [f32; 2], vb3: [f32; 2],
        step: i32,
    }
    impl AdamBidV4 {
        fn new(net: ProBidNetV4) -> Self {
            Self {
                mw1: vec![0.0; V4_BID_H1 * V4_BID_IN], vw1: vec![0.0; V4_BID_H1 * V4_BID_IN],
                mb1: vec![0.0; V4_BID_H1], vb1: vec![0.0; V4_BID_H1],
                mw2: vec![0.0; V4_BID_H2 * V4_BID_H1], vw2: vec![0.0; V4_BID_H2 * V4_BID_H1],
                mb2: vec![0.0; V4_BID_H2], vb2: vec![0.0; V4_BID_H2],
                mw3: vec![0.0; 2 * V4_BID_H2], vw3: vec![0.0; 2 * V4_BID_H2],
                mb3: [0.0; 2], vb3: [0.0; 2], step: 0, net,
            }
        }
        fn train_batch(&mut self, batch: &[([f32; V4_BID_IN], f32, f32)], lr: f32) -> f32 {
            let mut gw1 = vec![0.0_f32; V4_BID_H1 * V4_BID_IN];
            let mut gb1 = vec![0.0_f32; V4_BID_H1];
            let mut gw2 = vec![0.0_f32; V4_BID_H2 * V4_BID_H1];
            let mut gb2 = vec![0.0_f32; V4_BID_H2];
            let mut gw3 = vec![0.0_f32; 2 * V4_BID_H2];
            let mut gb3 = [0.0_f32; 2];
            let mut mse = 0.0_f32;

            for &(ref x, target_pts, target_win) in batch {
                let mut z1 = [0.0_f32; V4_BID_H1];
                let mut h1 = [0.0_f32; V4_BID_H1];
                for j in 0..V4_BID_H1 {
                    let row = &self.net.w1[j * V4_BID_IN..(j + 1) * V4_BID_IN];
                    let mut s = self.net.b1[j];
                    for i in 0..V4_BID_IN { s += row[i] * x[i]; }
                    z1[j] = s;
                    h1[j] = if s > 0.0 { s } else { 0.01 * s };
                }
                let mut z2 = [0.0_f32; V4_BID_H2];
                let mut h2 = [0.0_f32; V4_BID_H2];
                for k in 0..V4_BID_H2 {
                    let row = &self.net.w2[k * V4_BID_H1..(k + 1) * V4_BID_H1];
                    let mut s = self.net.b2[k];
                    for j in 0..V4_BID_H1 { s += row[j] * h1[j]; }
                    z2[k] = s;
                    h2[k] = if s > 0.0 { s } else { 0.01 * s };
                }
                let mut p_pts = self.net.b3[0];
                let mut wlog = self.net.b3[1];
                for k in 0..V4_BID_H2 {
                    p_pts += self.net.w3[k] * h2[k];
                    wlog += self.net.w3[V4_BID_H2 + k] * h2[k];
                }
                let p_win = 1.0 / (1.0 + (-wlog.clamp(-10.0, 10.0)).exp());
                let err = p_pts - target_pts;
                mse += err * err;
                let d0 = (2.0 * err).clamp(-10.0, 10.0);
                let d1 = (p_win - target_win) * 4.0;
                gb3[0] += d0;
                gb3[1] += d1;

                let mut dh2 = [0.0_f32; V4_BID_H2];
                for k in 0..V4_BID_H2 {
                    gw3[k] += d0 * h2[k];
                    gw3[V4_BID_H2 + k] += d1 * h2[k];
                    dh2[k] = (d0 * self.net.w3[k] + d1 * self.net.w3[V4_BID_H2 + k])
                        * if z2[k] > 0.0 { 1.0 } else { 0.01 };
                }
                let mut dh1 = [0.0_f32; V4_BID_H1];
                for k in 0..V4_BID_H2 {
                    gb2[k] += dh2[k];
                    let d = dh2[k];
                    let wrow = &self.net.w2[k * V4_BID_H1..(k + 1) * V4_BID_H1];
                    let grow = &mut gw2[k * V4_BID_H1..(k + 1) * V4_BID_H1];
                    for j in 0..V4_BID_H1 { grow[j] += d * h1[j]; dh1[j] += d * wrow[j]; }
                }
                for j in 0..V4_BID_H1 {
                    let d = dh1[j] * if z1[j] > 0.0 { 1.0 } else { 0.01 };
                    gb1[j] += d;
                    let grow = &mut gw1[j * V4_BID_IN..(j + 1) * V4_BID_IN];
                    for i in 0..V4_BID_IN { grow[i] += d * x[i]; }
                }
            }
            let inv = 1.0 / batch.len() as f32;
            self.step += 1;
            let b1c = 1.0 - 0.9_f32.powi(self.step);
            let b2c = 1.0 - 0.999_f32.powi(self.step);
            let upd = |w: &mut [f32], g: &[f32], m: &mut [f32], v: &mut [f32]| {
                for i in 0..w.len() {
                    let gi = g[i] * inv;
                    m[i] = 0.9 * m[i] + 0.1 * gi;
                    v[i] = 0.999 * v[i] + 0.001 * gi * gi;
                    w[i] -= lr * ((m[i] / b1c) / ((v[i] / b2c).sqrt() + 1e-8) + 1e-4 * w[i]);
                }
            };
            upd(&mut self.net.w1, &gw1, &mut self.mw1, &mut self.vw1);
            upd(&mut self.net.b1, &gb1, &mut self.mb1, &mut self.vb1);
            upd(&mut self.net.w2, &gw2, &mut self.mw2, &mut self.vw2);
            upd(&mut self.net.b2, &gb2, &mut self.mb2, &mut self.vb2);
            upd(&mut self.net.w3, &gw3, &mut self.mw3, &mut self.vw3);
            for k in 0..2 {
                let gk = gb3[k] * inv;
                self.mb3[k] = 0.9 * self.mb3[k] + 0.1 * gk;
                self.vb3[k] = 0.999 * self.vb3[k] + 0.001 * gk * gk;
                self.net.b3[k] -= lr * (self.mb3[k] / b1c) / ((self.vb3[k] / b2c).sqrt() + 1e-8);
            }
            mse * inv
        }
    }

    /// Generate `n_hands` population-diverse self-play hands returning (val_samples, policy_samples, bid_samples).
    /// `mode`:
    /// - 0: Bootstrap fast self-play + 4-trick AB exact endgame labels
    /// - 1: Neural Value + Policy self-play (distilling 1-ply ValueNet + 4-trick AB moves into PolicyNetV4!)
    /// - 2: Clean Population Self-Play (v4 vs v4 + v4 vs v3.2 mix, low noise, exact 4-trick AB!)
    fn generate_v4_data(
        n_hands: usize,
        seed_base: u64,
        mode: u8,
        eps: f32,
        vnet: &ProValueNetV4,
        pnet: &ProPolicyNetV4,
        bnet: &ProBidNetV4,
        v3_val: &ProValueNetV3,
        v3_bid: &ProBidNetV3,
        val_stride: usize,
        pol_stride: usize,
    ) -> (
        Vec<([f32; V4_IN], f32)>,
        Vec<([f32; V4_IN], u64, u8, f32)>,
        Vec<([f32; V4_BID_IN], f32, f32)>,
    ) {
        let threads = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2);
        let chunk = (n_hands + threads - 1) / threads;

        let parts: Vec<_> = std::thread::scope(|sc| {
            let mut handles = Vec::new();
            for tid in 0..threads {
                let start = tid * chunk;
                let end = ((tid + 1) * chunk).min(n_hands);
                handles.push(sc.spawn(move || {
                    let mut rng = FastRng::new(seed_base + (tid as u64) * 1000033);
                    let mut v_data = Vec::with_capacity(((end - start) * 10) / val_stride.max(1));
                    let mut p_data = Vec::with_capacity(((end - start) * 8) / pol_stride.max(1));
                    let mut b_data = Vec::with_capacity((end - start) / 2);
                    let mut vc = 0usize;
                    let mut pc = 0usize;

                    for hidx in start..end {
                        let deck = shuffle_no_4j(&mut rng);
                        let dealer = (hidx & 3) as u8;
                        let first_bidder = (dealer + 1) & 3;
                        let mut h4 = [0u32; 4];
                        for s in 0..4 {
                            for k in 0..4 { h4[s] |= 1u32 << deck[s * 4 + k]; }
                        }

                        // Population diversity in mode 2: 40% of hands pit v4 Team A against frozen v3.2 Team B!
                        let vs_v3 = mode == 2 && (hidx % 5) < 2;

                        let mut passed = [false; 4];
                        let mut high_bid = 0u8;
                        let mut high_bidder = dealer;
                        let mut turn = first_bidder;
                        let mut passed_cnt = 0u8;
                        let mut win_bfeat = [0.0_f32; V4_BID_IN];

                        for _ in 0..16 {
                            let next_b = if high_bid == 0 { 16 } else { high_bid + 1 };
                            let partner_win = high_bid > 0 && FastState::team_of(high_bidder) == FastState::team_of(turn);
                            let is_lead = turn == first_bidder;
                            let bfeat = extract_v3_bid_features(h4[turn as usize], is_lead, true, high_bid, partner_win, passed_cnt);
                            let est = if vs_v3 && FastState::team_of(turn) == 1 {
                                v3_bid.predict_expected_pts(&bfeat)
                            } else if mode == 0 {
                                v3_bid.predict_expected_pts(&bfeat)
                            } else {
                                bnet.predict(&bfeat).0
                            };
                            let jitter = if eps > 0.03 { (rng.next_f32() - 0.5) * 1.2 } else { 0.0 };
                            let max_w = ((est - 0.25 + jitter).round() as u8).clamp(15, 28);
                            let will_bid = next_b <= 28 && next_b <= max_w && !(partner_win && max_w < next_b + 2);
                            if will_bid {
                                high_bid = next_b;
                                high_bidder = turn;
                                win_bfeat = bfeat;
                                if passed_cnt >= 3 || high_bid == 28 { break; }
                            } else {
                                passed[turn as usize] = true;
                                passed_cnt += 1;
                                if passed_cnt == 3 {
                                    if high_bid == 0 {
                                        high_bid = 16;
                                        high_bidder = (0..4u8).find(|&s| !passed[s as usize]).unwrap_or(dealer);
                                        win_bfeat = extract_v3_bid_features(
                                            h4[high_bidder as usize], high_bidder == first_bidder, true, 0, false, 3,
                                        );
                                    }
                                    break;
                                }
                            }
                            for step in 1..=4u8 {
                                let nxt = (turn + step) & 3;
                                if !passed[nxt as usize] { turn = nxt; break; }
                            }
                        }

                        let (trump_suit, rev_en) = choose_fast_trump(h4[high_bidder as usize], high_bidder == first_bidder);
                        let mut hands = h4;
                        for s in 0..4 {
                            for k in 0..4 { hands[s] |= 1u32 << deck[16 + s * 4 + k]; }
                        }
                        let mut st = FastStateV4::from_base(FastState {
                            hands, played: 0, voids: [0; 4], failed_beat: [0; 4], dealer, bidder: high_bidder,
                            bid: high_bid, eff_bid: high_bid, stakes: 1, trump_suit,
                            reverse_enabled: rev_en, trump_exposed: false,
                            exposed_at_idx: -1, reverse_at_idx: -1, must_play_trump: -1,
                            marriage_done: false, seventh_card: -1,
                            trick_cards: [0; 4], trick_seats: [0; 4], trick_len: 0,
                            leader: first_bidder, turn: first_bidder, tricks_done: 0, pts: [0, 0],
                        });

                        let mut v_traj: Vec<([f32; V4_IN], usize)> = Vec::with_capacity(14);
                        let mut p_traj: Vec<([f32; V4_IN], u64, u8, usize)> = Vec::with_capacity(10);

                        while st.base.tricks_done < 8 {
                            let s = st.base.turn;
                            st.check_auto_marriage(s);
                            let my_team = FastState::team_of(s);
                            let legal = st.base.legal_mask(s);
                            let can_show = st.base.can_show_trump(s);
                            let n_legal = legal.count_ones() + if can_show { 1 } else { 0 };

                            let mut cached_feat: Option<[f32; V4_IN]> = None;
                            vc += 1;
                            if st.base.tricks_done >= 1 && (vc % val_stride == 0) {
                                let ft = extract_v4_features(&st, s);
                                v_traj.push((ft, my_team));
                                cached_feat = Some(ft);
                            }

                            let (sh, c) = if rng.next_f32() < eps && n_legal > 1 {
                                let cnt = legal.count_ones();
                                let pick = (rng.next_u64() as u32) % cnt;
                                let mut m = legal;
                                for _ in 0..pick { m &= m - 1; }
                                (false, m.trailing_zeros() as u8)
                            } else if n_legal == 1 {
                                (false, legal.trailing_zeros() as u8)
                            } else if vs_v3 && my_team == 1 {
                                // Frozen v3.2 opponent in population mix!
                                choose_v3_fast_play(&st.base, v3_val, 3, true, true, &mut rng)
                            } else if st.base.trump_exposed && st.base.hands[s as usize].count_ones() <= 3 && mode >= 1 {
                                // Exact Alpha-Beta endgame teacher for both Value & Policy!
                                let mut best_c = legal.trailing_zeros() as u8;
                                let mut best_v = i32::MIN;
                                let mut m = legal;
                                while m != 0 {
                                    let cand = m.trailing_zeros() as u8;
                                    m &= m - 1;
                                    let mut ch = st.base;
                                    ch.play_card(cand);
                                    let mut nodes = 0usize;
                                    let v = alphabeta_4trick(&ch, my_team, i32::MIN + 1, i32::MAX - 1, &mut nodes, 500);
                                    if v > best_v { best_v = v; best_c = cand; }
                                }
                                (false, best_c)
                            } else if mode == 0 {
                                fast_heuristic_action(&st.base)
                            } else if mode == 1 {
                                // 1-ply ValueNetV4 teacher (including ShowTrump!)
                                let mut best_act = (false, legal.trailing_zeros() as u8);
                                let mut best_sc = -1e9_f32;
                                let mut m = legal;
                                while m != 0 {
                                    let cand = m.trailing_zeros() as u8;
                                    m &= m - 1;
                                    let mut ch = st;
                                    ch.play_card(cand);
                                    let sc = if ch.base.tricks_done >= 8 {
                                        let bt = FastState::team_of(ch.base.bidder);
                                        if (my_team == bt) == ch.base.bidding_team_won() { 1.0 } else { 0.0 }
                                    } else {
                                        vnet.predict(&extract_v4_features(&ch, s))
                                    };
                                    if sc > best_sc { best_sc = sc; best_act = (false, cand); }
                                }
                                if can_show {
                                    let mut ch = st;
                                    ch.expose_trump(s);
                                    ch.check_auto_marriage(s);
                                    let (_, c2) = fast_heuristic_action(&ch.base);
                                    ch.play_card(c2);
                                    let sc = vnet.predict(&extract_v4_features(&ch, s));
                                    if sc > best_sc { best_act = (true, 0); }
                                }
                                best_act
                            } else {
                                // Mode 2: 2-sample neural-rollout PIMC teacher -> distills super-sharp search moves into PolicyNetV4!
                                choose_v4_fast_play(&st, vnet, pnet, 2, true, &mut rng)
                            };

                            // Record policy distillation target whenever there's a real choice (n_legal > 1)
                            pc += 1;
                            if n_legal > 1 && (pc % pol_stride == 0) && !(vs_v3 && my_team == 1) {
                                let ft = cached_feat.unwrap_or_else(|| extract_v4_features(&st, s));
                                let mut lmask = 0u64;
                                let mut m = legal;
                                while m != 0 {
                                    let cc = m.trailing_zeros() as u8;
                                    m &= m - 1;
                                    lmask |= 1u64 << canonical_card_idx(&st.base, s, cc);
                                }
                                if can_show { lmask |= 1u64 << 32; }
                                let tgt = if sh { 32u8 } else { canonical_card_idx(&st.base, s, c) as u8 };
                                p_traj.push((ft, lmask, tgt, my_team));
                            }

                            if sh {
                                st.expose_trump(s);
                                st.check_auto_marriage(s);
                            } else {
                                st.play_card(c);
                            }
                        }

                        let bt = FastState::team_of(st.base.bidder);
                        let bt_won = st.base.bidding_team_won();
                        let bpts = st.base.pts[bt] as f32;

                        if (hidx & 1) == 0 {
                            b_data.push((win_bfeat, bpts, if bt_won { 1.0 } else { 0.0 }));
                        }
                        for (ft, team) in v_traj {
                            let won = if team == bt { bt_won } else { !bt_won };
                            v_data.push((ft, if won { 1.0 } else { 0.0 }));
                        }
                        // Outcome-weighted policy distillation: up-weight winning team's choices (1.35x vs 0.65x)!
                        for (ft, lmask, tgt, team) in p_traj {
                            let won = if team == bt { bt_won } else { !bt_won };
                            let w = if won { 1.35 } else { 0.65 };
                            p_data.push((ft, lmask, tgt, w));
                        }
                    }
                    (v_data, p_data, b_data)
                }));
            }
            handles.into_iter().map(|h| h.join().unwrap()).collect()
        });

        let mut all_v = Vec::new();
        let mut all_p = Vec::new();
        let mut all_b = Vec::new();
        for (mut v, mut p, mut b) in parts {
            all_v.append(&mut v);
            all_p.append(&mut p);
            all_b.append(&mut b);
        }
        (all_v, all_p, all_b)
    }

    fn export_v4_weights(vnet: &ProValueNetV4, pnet: &ProPolicyNetV4, bnet: &ProBidNetV4, path: &Path) {
        use std::fmt::Write;
        let mut s = String::with_capacity(720_000);
        writeln!(s, "// Auto-generated Pro RL v4 weights (1M+ hand population self-play):").unwrap();
        writeln!(s, "// ValueNetV4 (240->128->64->1: 39,169w) + PolicyNetV4 (240->64->33: 17,569w) + BidNetV4 (32->64->32->2: 4,258w).").unwrap();
        let write_arr = |out: &mut String, name: &str, data: &[f32]| {
            writeln!(out, "pub static {}: [f32; {}] = [", name, data.len()).unwrap();
            for chunk in data.chunks(12) {
                out.push_str("    ");
                for &v in chunk { write!(out, "{:.5}, ", v).unwrap(); }
                out.push('\n');
            }
            writeln!(out, "];").unwrap();
        };
        write_arr(&mut s, "V4_W1", &vnet.w1);
        write_arr(&mut s, "V4_B1", &vnet.b1);
        write_arr(&mut s, "V4_W2", &vnet.w2);
        write_arr(&mut s, "V4_B2", &vnet.b2);
        write_arr(&mut s, "V4_W3", &vnet.w3);
        writeln!(s, "pub const V4_B3: f32 = {:.5};", vnet.b3).unwrap();

        write_arr(&mut s, "V4_PW1", &pnet.w1);
        write_arr(&mut s, "V4_PB1", &pnet.b1);
        write_arr(&mut s, "V4_PW2", &pnet.w2);
        write_arr(&mut s, "V4_PB2", &pnet.b2);

        write_arr(&mut s, "V4_BW1", &bnet.w1);
        write_arr(&mut s, "V4_BB1", &bnet.b1);
        write_arr(&mut s, "V4_BW2", &bnet.w2);
        write_arr(&mut s, "V4_BB2", &bnet.b2);
        write_arr(&mut s, "V4_BW3", &bnet.w3);
        writeln!(s, "pub const V4_BB3: [f32; 2] = [{:.5}, {:.5}];", bnet.b3[0], bnet.b3[1]).unwrap();
        std::fs::write(path, s).expect("write rl_weights_v4.rs");
    }

    /// Play 1 hand: Team A = mode_a (0=Heur, 3=V3.2, 4=V4), Team B = mode_b
    fn play_v4_arena_hand(
        deck: &[u8; 32],
        dealer: u8,
        mode_a: u8,
        mode_b: u8,
        v3_val: &ProValueNetV3,
        v3_bid: &ProBidNetV3,
        v4_val: &ProValueNetV4,
        v4_pol: &ProPolicyNetV4,
        v4_bid: &ProBidNetV4,
        v4_cush: f32,
        samples: usize,
        v4_use_pol: bool,
        rng: &mut FastRng,
    ) -> (i32, bool, bool, bool) {
        let mut h4 = [0u32; 4];
        for s in 0..4 {
            for k in 0..4 { h4[s] |= 1u32 << deck[s * 4 + k]; }
        }
        let first_bidder = (dealer + 1) & 3;
        let mut passed = [false; 4];
        let mut high_bid = 0u8;
        let mut high_bidder = dealer;
        let mut turn = first_bidder;
        let mut passed_cnt = 0u8;

        for _ in 0..16 {
            let m = if FastState::team_of(turn) == 0 { mode_a } else { mode_b };
            let next_b = if high_bid == 0 { 16 } else { high_bid + 1 };
            let partner_win = high_bid > 0 && FastState::team_of(high_bidder) == FastState::team_of(turn);
            let is_lead = turn == first_bidder;
            let bfeat = extract_v3_bid_features(h4[turn as usize], is_lead, true, high_bid, partner_win, passed_cnt);
            let has_kq = (0..4u8).any(|s| ((h4[turn as usize] >> (s * 8)) & 48) == 48);

            let max_w = match m {
                3 => {
                    let est = v3_bid.predict_expected_pts(&bfeat);
                    ((est - 0.25 + if has_kq { 0.75 } else { 0.0 }).round() as u8).clamp(15, 28)
                }
                4 => {
                    let (est, _wp) = v4_bid.predict(&bfeat);
                    ((est - v4_cush + if has_kq { 0.75 } else { 0.0 }).round() as u8).clamp(15, 28)
                }
                _ => {
                    let est = 14.5 + bfeat[0] * 4.0 + bfeat[1] * 2.5 + bfeat[2] * 1.5;
                    (est.round() as u8).clamp(15, 24)
                }
            };

            let will_bid = next_b <= 28 && next_b <= max_w && !(partner_win && max_w < next_b + 2);
            if will_bid {
                high_bid = next_b;
                high_bidder = turn;
                if passed_cnt >= 3 || high_bid == 28 { break; }
            } else {
                passed[turn as usize] = true;
                passed_cnt += 1;
                if passed_cnt == 3 {
                    if high_bid == 0 {
                        high_bid = 16;
                        high_bidder = (0..4u8).find(|&s| !passed[s as usize]).unwrap_or(dealer);
                    }
                    break;
                }
            }
            for step in 1..=4u8 {
                let nxt = (turn + step) & 3;
                if !passed[nxt as usize] { turn = nxt; break; }
            }
        }

        let (trump_suit, rev_en) = choose_fast_trump(h4[high_bidder as usize], high_bidder == first_bidder);
        let mut hands = h4;
        for s in 0..4 {
            for k in 0..4 { hands[s] |= 1u32 << deck[16 + s * 4 + k]; }
        }
        let mut st = FastStateV4::from_base(FastState {
            hands, played: 0, voids: [0; 4], failed_beat: [0; 4], dealer, bidder: high_bidder,
            bid: high_bid, eff_bid: high_bid, stakes: 1, trump_suit,
            reverse_enabled: rev_en, trump_exposed: false,
            exposed_at_idx: -1, reverse_at_idx: -1, must_play_trump: -1,
            marriage_done: false, seventh_card: -1,
            trick_cards: [0; 4], trick_seats: [0; 4], trick_len: 0,
            leader: first_bidder, turn: first_bidder, tricks_done: 0, pts: [0, 0],
        });

        while st.base.tricks_done < 8 {
            let s = st.base.turn;
            st.check_auto_marriage(s);
            let m = if FastState::team_of(s) == 0 { mode_a } else { mode_b };
            let (sh, c) = match m {
                3 => choose_v3_fast_play(&st.base, v3_val, samples, true, true, rng),
                4 => choose_v4_fast_play(&st, v4_val, v4_pol, samples, v4_use_pol, rng),
                _ => fast_heuristic_action(&st.base),
            };
            if sh {
                st.expose_trump(s);
                st.check_auto_marriage(s);
            } else {
                st.play_card(c);
            }
        }
        (st.base.set_points_for_team(0), FastState::team_of(st.base.bidder) == 0, st.base.bidding_team_won(), rev_en)
    }

    pub fn eval_v4_vs(
        num_hands: usize,
        seed_base: u64,
        opp_mode: u8, // 3=FrozenV3.2, 0=Heuristic
        v3_val: &ProValueNetV3,
        v3_bid: &ProBidNetV3,
        v4_val: &ProValueNetV4,
        v4_pol: &ProPolicyNetV4,
        v4_bid: &ProBidNetV4,
        v4_cush: f32,
        samples: usize,
        v4_use_pol: bool,
    ) -> (f64, f64, f64, f64, f64, f64) {
        let pairs = num_hands / 2;
        let threads = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2);
        let chunk = (pairs + threads - 1) / threads;

        let res = std::thread::scope(|sc| {
            let mut hs = Vec::new();
            for tid in 0..threads {
                let start = tid * chunk;
                let end = ((tid + 1) * chunk).min(pairs);
                hs.push(sc.spawn(move || {
                    let mut rng = FastRng::new(seed_base + (tid as u64) * 999983);
                    let mut sp = 0i64;
                    let mut w = 0usize; let mut b = 0usize; let mut bm = 0usize;
                    let mut d = 0usize; let mut ds = 0usize; let mut rv = 0usize; let mut rw = 0usize;
                    let mut tot = 0usize;
                    for p in start..end {
                        let deck = shuffle_no_4j(&mut rng);
                        let dealer = (p & 3) as u8;

                        let (p1, ab1, bw1, r1) = play_v4_arena_hand(
                            &deck, dealer, 4, opp_mode, v3_val, v3_bid, v4_val, v4_pol, v4_bid,
                            v4_cush, samples, v4_use_pol, &mut rng,
                        );
                        sp += p1 as i64; if p1 > 0 { w += 1; }
                        if ab1 { b += 1; if bw1 { bm += 1; } if r1 { rv += 1; if bw1 { rw += 1; } } }
                        else { d += 1; if !bw1 { ds += 1; } }
                        tot += 1;

                        let (p2, ab2, bw2, r2) = play_v4_arena_hand(
                            &deck, dealer, opp_mode, 4, v3_val, v3_bid, v4_val, v4_pol, v4_bid,
                            v4_cush, samples, v4_use_pol, &mut rng,
                        );
                        let vp2 = -p2;
                        sp += vp2 as i64; if vp2 > 0 { w += 1; }
                        if !ab2 { b += 1; if bw2 { bm += 1; } if r2 { rv += 1; if bw2 { rw += 1; } } }
                        else { d += 1; if !bw2 { ds += 1; } }
                        tot += 1;
                    }
                    (sp, w, b, bm, d, ds, rv, rw, tot)
                }));
            }
            hs.into_iter().map(|h| h.join().unwrap()).collect::<Vec<_>>()
        });

        let (mut sp, mut w, mut b, mut bm, mut d, mut ds, mut rv, mut rw, mut tot) = (0i64, 0, 0, 0, 0, 0, 0, 0, 0);
        for r in res {
            sp += r.0; w += r.1; b += r.2; bm += r.3; d += r.4; ds += r.5; rv += r.6; rw += r.7; tot += r.8;
        }
        (
            100.0 * w as f64 / tot as f64,
            100.0 * sp as f64 / tot as f64,
            100.0 * bm as f64 / b.max(1) as f64,
            100.0 * ds as f64 / d.max(1) as f64,
            100.0 * rw as f64 / rv.max(1) as f64,
            100.0 * b as f64 / tot as f64,
        )
    }

    #[test]
    #[ignore]
    fn train_pro_rl_v4_million_hands() {
        let t0 = Instant::now();
        let v3_val = ProValueNetV3::from_embedded();
        let v3_bid = ProBidNetV3::from_embedded();

        let mut adam_v = AdamValV4::new(ProValueNetV4::new_random(4040401));
        let mut adam_p = AdamPolV4::new(ProPolicyNetV4::new_random(4040402));
        let mut adam_b = AdamBidV4::new(ProBidNetV4::new_random(4040403));

        println!("=========================================================================");
        println!("PRO RL v4: 1,000,000-HAND SEAT-ATTRIBUTED + POLICY-DISTILLATION TRAINING");
        println!("ValueNetV4: 240->128->64->1 (39,169w) | PolicyNetV4: 240->64->33 (17,569w) | BidNetV4: 32->64->32->2 (4,258w)");
        println!("Total: 60,996 weights (~244 KB) | No-4-Jacks deal rule active");
        println!("=========================================================================");

        let (val_v, _val_p, val_b) = generate_v4_data(
            15_000, 909090, 0, 0.0, &adam_v.net, &adam_p.net, &adam_b.net, &v3_val, &v3_bid, 4, 16,
        );
        println!("Held-out validation set: {} states, {} opening hands ({:.1}s)",
            val_v.len(), val_b.len(), t0.elapsed().as_secs_f32());

        // 3 Iterative Self-Play Generations = 1,000,000 hands!
        // Gen 1: 600k ultra-fast bootstrap (50k+ hands/s) -> strong 240-dim ValueNetV4 + BidNetV4 + PolicyNetV4
        // Gen 2: 300k 1-ply ValueNetV4 + Exact AB teacher -> sharp Policy Distillation + Value refinement
        // Gen 3: 100k Population PIMC + Neural-Rollout Self-Play (60% v4 vs v4, 40% v4 vs frozen v3.2!)
        let gens: [(usize, u8, f32, usize, usize, f32, usize, &str); 3] = [
            (600_000, 0, 0.06, 14, 14, 0.0020, 5, "Gen 1: 600k Fast Bootstrap (240-dim Seat-Attributed + Deductions)"),
            (300_000, 1, 0.06, 10,  8, 0.0011, 5, "Gen 2: 300k Value+ExactAB Teacher + Policy Distillation"),
            (100_000, 2, 0.03,  5,  4, 0.0005, 5, "Gen 3: 100k Population Self-Play (v4 vs v4 & Frozen v3.2)"),
        ];

        let mut shuf_rng = FastRng::new(2026112704);
        for (gi, &(nh, mode, eps, vs, ps, base_lr, epochs, label)) in gens.iter().enumerate() {
            let tg = Instant::now();
            println!("\n--- {} ---", label);
            let (mut tv, mut tp, mut tb) = generate_v4_data(
                nh, 200_000 + (gi as u64) * 77_777, mode, eps,
                &adam_v.net, &adam_p.net, &adam_b.net, &v3_val, &v3_bid, vs, ps,
            );
            let sim_s = tg.elapsed().as_secs_f32();
            println!("  Simulated {} hands ({:.0} hands/s) -> {} val, {} policy, {} bid samples",
                nh, nh as f32 / sim_s.max(0.01), tv.len(), tp.len(), tb.len());

            for ep in 0..epochs {
                for i in (1..tv.len()).rev() { let j = (shuf_rng.next_u64() as usize) % (i + 1); tv.swap(i, j); }
                let cos_m = 0.5 * (1.0 + (std::f32::consts::PI * ep as f32 / epochs as f32).cos());
                let lr = base_lr * (0.15 + 0.85 * cos_m);
                let mut _vloss = 0.0_f32;
                for ch in tv.chunks(256) {
                    if ch.len() < 32 { continue; }
                    _vloss += adam_v.train_batch(ch, lr, 1.5e-4);
                }

                for i in (1..tp.len()).rev() { let j = (shuf_rng.next_u64() as usize) % (i + 1); tp.swap(i, j); }
                let mut ploss = 0.0_f32; let mut pacc = 0.0_f32; let mut pnb = 0usize;
                for ch in tp.chunks(256) {
                    if ch.len() < 32 { continue; }
                    let (pl, pa) = adam_p.train_batch(ch, lr * 1.4);
                    ploss += pl; pacc += pa; pnb += 1;
                }

                for i in (1..tb.len()).rev() { let j = (shuf_rng.next_u64() as usize) % (i + 1); tb.swap(i, j); }
                for ch in tb.chunks(256) {
                    if ch.len() < 32 { continue; }
                    adam_b.train_batch(ch, lr * 1.2);
                }

                if ep == epochs - 1 {
                    let mut vl = 0.0_f32; let mut vc = 0usize;
                    for &(ref x, y) in &val_v {
                        let p = adam_v.net.predict(x).clamp(1e-6, 1.0 - 1e-6);
                        vl += -(y * p.ln() + (1.0 - y) * (1.0 - p).ln());
                        if (p >= 0.5) == (y >= 0.5) { vc += 1; }
                    }
                    let bmse: f32 = val_b.iter().map(|(x, y, _)| {
                        let e = adam_b.net.predict(x).0 - *y; e * e
                    }).sum::<f32>() / val_b.len() as f32;
                    println!("  Epoch {}/{}: Val BCE={:.4} | Val Acc={:.2}% | Pol Acc={:.1}% (ce={:.3}) | Bid RMSE={:.3} pts ({:.1}s)",
                        ep + 1, epochs, vl / val_v.len() as f32, 100.0 * vc as f32 / val_v.len() as f32,
                        pacc / pnb.max(1) as f32, ploss / pnb.max(1) as f32, bmse.sqrt(), tg.elapsed().as_secs_f32());
                }
            }

            // Export checkpoint after every generation so nothing is ever lost!
            export_v4_weights(&adam_v.net, &adam_p.net, &adam_b.net, Path::new("src/rl_weights_v4.rs"));

            // Quick 4,000-hand duplicate-deal check vs Frozen Pro RL v3.2
            let (wp, sp100, bm, ds, rw, _bs) = eval_v4_vs(
                4_000, 6_000_000 + (gi as u64) * 50_000, 3,
                &v3_val, &v3_bid, &adam_v.net, &adam_p.net, &adam_b.net,
                0.25, 6, gi >= 1,
            );
            println!("  [Gen {} Checkpoint vs Frozen Pro RL v3.2 (4k dup hands)] Win={:.2}% | SetPts/100={:+.2} | BidMake={:.1}% | DefSet={:.1}% | RevWin={:.1}%",
                gi + 1, wp, sp100, bm, ds, rw);
        }

        println!("\nExported final Pro RL v4 weights to src/rl_weights_v4.rs in {:.1}s total!", t0.elapsed().as_secs_f32());
    }

    #[test]
    #[ignore]
    fn eval_and_finalize_pro_rl_v4_100k() {
        let t0 = Instant::now();
        let v3_val = ProValueNetV3::from_embedded();
        let v3_bid = ProBidNetV3::from_embedded();
        let mut adam_v = AdamValV4::new(ProValueNetV4::from_embedded());
        let mut adam_p = AdamPolV4::new(ProPolicyNetV4::from_embedded());
        let mut adam_b = AdamBidV4::new(ProBidNetV4::from_embedded());

        println!("=========================================================================");
        println!("PRO RL v4: GEN-3 CLEAN FINE-TUNE (+250K HANDS = 1.15M TOTAL) + 100K EVAL vs v3.2");
        println!("=========================================================================");

        // Fixed 20k unseen validation set
        let (val_v, _val_p, val_b) = generate_v4_data(
            20_000, 909090, 0, 0.0, &adam_v.net, &adam_p.net, &adam_b.net, &v3_val, &v3_bid, 4, 20,
        );
        let eval_metrics = |vn: &ProValueNetV4, bn: &ProBidNetV4| -> (f32, f32, f32) {
            let mut vl = 0.0_f32; let mut vc = 0usize;
            for &(ref x, y) in &val_v {
                let p = vn.predict(x).clamp(1e-6, 1.0 - 1e-6);
                vl += -(y * p.ln() + (1.0 - y) * (1.0 - p).ln());
                if (p >= 0.5) == (y >= 0.5) { vc += 1; }
            }
            let bmse: f32 = val_b.iter().map(|(x, y, _)| { let e = bn.predict(x).0 - *y; e * e }).sum::<f32>() / val_b.len() as f32;
            (vl / val_v.len() as f32, 100.0 * vc as f32 / val_v.len() as f32, bmse.sqrt())
        };

        let (vl0, va0, br0) = eval_metrics(&adam_v.net, &adam_b.net);
        println!("Checkpoint (Gen 1-2, 900k hands): Val BCE={:.4} | Val Acc={:.2}% | Bid RMSE={:.3} pts", vl0, va0, br0);

        // Gen 3 Clean Fine-Tune: 250,000 clean low-noise hands (eps=0.02, 1-ply Value+ExactAB)
        let tg = Instant::now();
        let (mut tv, mut tp, mut tb) = generate_v4_data(
            250_000, 555_555, 0, 0.02, &adam_v.net, &adam_p.net, &adam_b.net, &v3_val, &v3_bid, 7, 7,
        );
        println!("Gen-3 simulated 250,000 clean hands ({:.0} hands/s) -> {} val, {} pol, {} bid samples",
            250_000.0 / tg.elapsed().as_secs_f32().max(0.1), tv.len(), tp.len(), tb.len());

        let mut shuf_rng = FastRng::new(2026112799);
        for ep in 0..4 {
            for i in (1..tv.len()).rev() { let j = (shuf_rng.next_u64() as usize) % (i + 1); tv.swap(i, j); }
            let lr = 0.00045 * (1.0 - 0.7 * ep as f32 / 4.0);
            for ch in tv.chunks(256) { if ch.len() >= 32 { adam_v.train_batch(ch, lr, 1.5e-4); } }
            for i in (1..tp.len()).rev() { let j = (shuf_rng.next_u64() as usize) % (i + 1); tp.swap(i, j); }
            for ch in tp.chunks(256) { if ch.len() >= 32 { adam_p.train_batch(ch, lr * 1.4); } }
            for i in (1..tb.len()).rev() { let j = (shuf_rng.next_u64() as usize) % (i + 1); tb.swap(i, j); }
            for ch in tb.chunks(256) { if ch.len() >= 32 { adam_b.train_batch(ch, lr * 1.3); } }
        }
        let (vl1, va1, br1) = eval_metrics(&adam_v.net, &adam_b.net);
        println!("After Gen-3 (1.15M hands total):  Val BCE={:.4} ({:+.4}) | Val Acc={:.2}% ({:+.2}%) | Bid RMSE={:.3} pts ({:+.3})",
            vl1, vl1 - vl0, va1, va1 - va0, br1, br1 - br0);

        if vl1 <= vl0 + 0.002 || br1 < br0 {
            export_v4_weights(&adam_v.net, &adam_p.net, &adam_b.net, Path::new("src/rl_weights_v4.rs"));
            println!("Saved Gen-3 refined weights to src/rl_weights_v4.rs!");
        }

        // Algorithmic Ablation vs Frozen Pro RL v3.2 (6,000 duplicate hands each, strictly equal 6 vs 6 PIMC!)
        println!("\n=== ALGORITHMIC ABLATION vs FROZEN PRO RL v3.2 (6,000 dup hands each, Equal 6 vs 6 PIMC) ===");
        let configs = [
            ("V4-ValOnly (240-dim + Deduction PIMC, Heur rollouts, cush 0.25)", 0.25_f32, false),
            ("V4-PolRoll (+ Neural PolicyNetV4 Rollouts, cush 0.25)          ", 0.25_f32, true),
            ("V4-ValOnly (240-dim + Deduction PIMC, Heur rollouts, cush 0.05)", 0.05_f32, false),
            ("V4-PolRoll (+ Neural PolicyNetV4 Rollouts, cush 0.05)          ", 0.05_f32, true),
        ];
        let mut best_cfg = configs[0];
        let mut best_sp = -999.0_f64;
        for cfg in configs {
            let (wp, sp100, bm, ds, rw, bs) = eval_v4_vs(
                6_000, 33_333_333, 3, &v3_val, &v3_bid, &adam_v.net, &adam_p.net, &adam_b.net,
                cfg.1, 6, cfg.2,
            );
            println!("  {} | Win={:.2}% | SetPts/100={:+.2} | BidMake={:.1}% (sh {:.1}%) | DefSet={:.1}% | RevWin={:.1}%",
                cfg.0, wp, sp100, bm, bs, ds, rw);
            if sp100 > best_sp {
                best_sp = sp100;
                best_cfg = cfg;
            }
        }
        println!("  --> Best V4 Config: {} (SetPts/100 = {:+.2})", best_cfg.0.trim(), best_sp);

        // FINAL 100,000-HAND HELD-OUT EVALUATION: Pro RL v4 vs Frozen Pro RL v3.2 (Equal 4 vs 4 PIMC for fast 100k!)
        println!("\n=========================================================================");
        println!("FINAL 100,000-HAND HELD-OUT EVALUATION: Pro RL v4 vs Frozen Pro RL v3.2");
        println!("(50,000 unseen duplicate deals x 2 seat swaps = 100,000 hands | Equal 4 vs 4 PIMC)");
        println!("=========================================================================");
        let te = Instant::now();
        let (wp, sp100, bm, ds, rw, bsh) = eval_v4_vs(
            100_000, 99_999_999, 3, &v3_val, &v3_bid, &adam_v.net, &adam_p.net, &adam_b.net,
            best_cfg.1, 4, best_cfg.2,
        );
        let es = te.elapsed().as_secs_f32();
        println!("  100,000 hands completed in {:.1}s ({:.0} hands/s):", es, 100_000.0 / es.max(0.1));
        println!("    Pro RL v4 Hand Win Rate   : {:.2}% (vs Frozen v3.2: {:.2}%)", wp, 100.0 - wp);
        println!("    Net Set Points / 100      : {:+.2} set pts / 100 hands", sp100);
        println!("    V4 Bid Make Rate          : {:.2}% (bid share {:.1}%)", bm, bsh);
        println!("    V4 Defend Set Rate        : {:.2}%", ds);
        println!("    V4 Reverse Win Rate       : {:.2}%", rw);

        // Also 20,000-hand check vs Normal Heuristic
        let (wp_n, sp_n, bm_n, ds_n, rw_n, _) = eval_v4_vs(
            20_000, 77_777_777, 0, &v3_val, &v3_bid, &adam_v.net, &adam_p.net, &adam_b.net,
            best_cfg.1, 4, best_cfg.2,
        );
        println!("\n  Pro RL v4 vs Normal Heuristic (20,000 duplicate hands):");
        println!("    Hand Win Rate: {:.2}% | SetPts/100: {:+.2} | BidMake: {:.2}% | DefSet: {:.2}% | RevWin: {:.2}%",
            wp_n, sp_n, bm_n, ds_n, rw_n);
        println!("Total wall time: {:.1}s", t0.elapsed().as_secs_f32());
    }


    #[test]
    #[ignore]
    fn eval_v4_only_100k() {
        let t0 = Instant::now();
        let v3_val = ProValueNetV3::from_embedded();
        let v3_bid = ProBidNetV3::from_embedded();
        let v4_val = ProValueNetV4::from_embedded();
        let v4_pol = ProPolicyNetV4::from_embedded();
        let v4_bid = ProBidNetV4::from_embedded();

        // 1. Held-out validation metrics (20k unseen hands)
        let (val_v, _val_p, val_b) = generate_v4_data(
            20_000, 909090, 0, 0.0, &v4_val, &v4_pol, &v4_bid, &v3_val, &v3_bid, 4, 20,
        );
        let mut vl = 0.0_f32; let mut vc = 0usize;
        for &(ref x, y) in &val_v {
            let p = v4_val.predict(x).clamp(1e-6, 1.0 - 1e-6);
            vl += -(y * p.ln() + (1.0 - y) * (1.0 - p).ln());
            if (p >= 0.5) == (y >= 0.5) { vc += 1; }
        }
        let bmse: f32 = val_b.iter().map(|(x, y, _)| { let e = v4_bid.predict(x).0 - *y; e * e }).sum::<f32>() / val_b.len() as f32;
        println!("=== PRO RL v4 (1.15M-hand trained) VALIDATION METRICS (20k unseen hands) ===");
        println!("  ValueNetV4 (240->128->64->1, 39,169w): Val BCE = {:.4} | Val Accuracy = {:.2}%",
            vl / val_v.len() as f32, 100.0 * vc as f32 / val_v.len() as f32);
        println!("  BidNetV4   (32->64->32->2,    4,258w): Val RMSE = {:.3} pts", bmse.sqrt());

        // 2. Algorithmic Ablation vs Frozen Pro RL v3.2 (4,000 duplicate hands each, Equal 4 vs 4 PIMC)
        println!("\n=== ALGORITHMIC ABLATION vs FROZEN PRO RL v3.2 (4,000 dup hands each, Equal 4 vs 4 PIMC) ===");
        let configs = [
            ("V4-ValOnly (240-dim + Deduction PIMC, cush 0.25)", 0.25_f32, false),
            ("V4-ValOnly (240-dim + Deduction PIMC, cush 0.15)", 0.15_f32, false),
            ("V4-ValOnly (240-dim + Deduction PIMC, cush 0.35)", 0.35_f32, false),
            ("V4-PolRoll (+ Neural PolicyNetV4 Roll, cush 0.25)", 0.25_f32, true),
        ];
        let mut best_fast_cush = 0.25_f32;
        let mut best_fast_sp = -999.0_f64;
        for cfg in configs {
            let ta = Instant::now();
            let (wp, sp100, bm, ds, rw, bs) = eval_v4_vs(
                4_000, 33_333_333, 3, &v3_val, &v3_bid, &v4_val, &v4_pol, &v4_bid,
                cfg.1, 4, cfg.2,
            );
            println!("  {} | Win={:.2}% | SetPts/100={:+.2} | BidMake={:.1}% (sh {:.1}%) | DefSet={:.1}% | RevWin={:.1}% ({:.1}s)",
                cfg.0, wp, sp100, bm, bs, ds, rw, ta.elapsed().as_secs_f32());
            if !cfg.2 && sp100 > best_fast_sp {
                best_fast_sp = sp100;
                best_fast_cush = cfg.1;
            }
        }

        // 3. FINAL 100,000-HAND HELD-OUT EVALUATION: Pro RL v4 vs Frozen Pro RL v3.2 (Equal 4 vs 4 PIMC)
        println!("\n=========================================================================");
        println!("FINAL 100,000-HAND HELD-OUT EVALUATION: Pro RL v4 vs Frozen Pro RL v3.2");
        println!("(50,000 unseen duplicate deals x 2 seat swaps = 100,000 hands | Equal 4 vs 4 PIMC, cush={:.2})", best_fast_cush);
        println!("=========================================================================");
        let te = Instant::now();
        let (wp, sp100, bm, ds, rw, bsh) = eval_v4_vs(
            100_000, 99_999_999, 3, &v3_val, &v3_bid, &v4_val, &v4_pol, &v4_bid,
            best_fast_cush, 4, false,
        );
        let es = te.elapsed().as_secs_f32();
        println!("  100,000 hands completed in {:.1}s ({:.0} hands/s):", es, 100_000.0 / es.max(0.1));
        println!("    Pro RL v4 Hand Win Rate   : {:.2}% (vs Frozen v3.2: {:.2}%)", wp, 100.0 - wp);
        println!("    Net Set Points / 100      : {:+.2} set pts / 100 hands", sp100);
        println!("    V4 Bid Make Rate          : {:.2}% (bid share {:.1}%)", bm, bsh);
        println!("    V4 Defend Set Rate        : {:.2}%", ds);
        println!("    V4 Reverse Win Rate       : {:.2}%", rw);

        // 4. Also 20,000-hand check vs Normal Heuristic
        let (wp_n, sp_n, bm_n, ds_n, rw_n, _) = eval_v4_vs(
            20_000, 77_777_777, 0, &v3_val, &v3_bid, &v4_val, &v4_pol, &v4_bid,
            best_fast_cush, 4, false,
        );
        println!("\n  Pro RL v4 vs Normal Heuristic (20,000 duplicate hands):");
        println!("    Hand Win Rate: {:.2}% | SetPts/100: {:+.2} | BidMake: {:.2}% | DefSet: {:.2}% | RevWin: {:.2}%",
            wp_n, sp_n, bm_n, ds_n, rw_n);
        println!("Total wall time: {:.1}s", t0.elapsed().as_secs_f32());
    }

}
