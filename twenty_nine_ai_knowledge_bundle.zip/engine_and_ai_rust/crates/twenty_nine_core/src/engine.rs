use crate::protocol::TrumpMode;
use crate::cards::{
    shuffled_deck, sort_hand, Card, Rank, Suit, NORMAL_RANK_ORDER, REVERSED_RANK_ORDER,
};
use crate::config::{GameConfig, TrumpExposeTrigger};
use crate::protocol::{
    BidEntry, CompletedTrick, GamePhase, HandSummary, PlayerView, PublicSeatInfo, SeatIndex,
    ServerMessage, StakesLevel, Team, TrickPlay,
};
use rand::Rng;
use thiserror::Error;

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum GameError {
    #[error("Action is not allowed in phase {0:?}")]
    WrongPhase(GamePhase),
    #[error("It is not seat {0}'s turn")]
    NotYourTurn(SeatIndex),
    #[error("Invalid bid {0}: must be between {1} and {2}")]
    InvalidBid(u8, u8, u8),
    #[error("Only the winning bidder (seat {0}) may select trump")]
    NotBidder(SeatIndex),
    #[error("Reverse rule option is disabled for this table")]
    ReverseDisabled,
    #[error("Joker (No Trump) rule option is disabled for this table")]
    JokerDisabled,
    #[error("Double/Redouble is not enabled for this table")]
    DoublingDisabled,
    #[error("Only the opposing team may call Double")]
    CannotDouble,
    #[error("Only the bidding team may call Redouble after a Double")]
    CannotRedouble,
    #[error("Card {0} is not in your hand")]
    CardNotInHand(String),
    #[error("You must follow the led suit ({0})")]
    MustFollowSuit(Suit),
    #[error("Trump is already exposed")]
    TrumpAlreadyExposed,
    #[error("The bidder cannot call Show Trump")]
    BidderCannotShowTrump,
    #[error("You can only call Show Trump when you cannot follow the led suit")]
    CanFollowLedSuit,
    #[error("After calling Show Trump, you must play a trump card ({0}) if you hold one")]
    MustPlayTrump(Suit),
    #[error("Marriage can only be declared once per hand")]
    MarriageAlreadyDeclared,
    #[error("Marriage can only be declared after trump is exposed")]
    TrumpNotExposedForMarriage,
    #[error("You can only declare a 0-point reshuffle before Trick 1 starts when your 8-card hand has 0 points")]
    CannotReshuffle,
    #[error("You must hold both King and Queen of trump and play one of them to declare Marriage")]
    InvalidMarriage,
    #[error("Invalid card ID: {0}")]
    InvalidCardId(String),
    #[error("Seat {0} is out of bounds")]
    InvalidSeat(SeatIndex),
}

/// Authoritative server-side game state for a 4-player 29 table.
#[derive(Debug, Clone)]
pub struct GameEngine {
    pub room_id: String,
    pub config: GameConfig,
    pub phase: GamePhase,
    pub seats: [PublicSeatInfo; 4],
    pub dealer: SeatIndex,
    pub hand_number: u32,
    pub current_turn: SeatIndex,

    // Per-hand private/authoritative state
    deck_remainder: Vec<Card>,
    pub(crate) hands: [Vec<Card>; 4],
    pub bid_history: Vec<BidEntry>,
    pub current_high_bid: Option<u8>,
    pub current_high_bidder: Option<SeatIndex>,
    pub passed_bidding: [bool; 4],

    // Hidden trump & Reverse two-gate state
    trump_suit: Option<Suit>,
    trump_mode: Option<TrumpMode>,
    seventh_card_committed: bool,
    seventh_card_held: Option<Card>,
    reverse_enabled: bool,
    pub trump_exposed: bool,
    pub exposure_trigger: Option<TrumpExposeTrigger>,
    /// Single source of truth for card ranking in every suit.
    /// Starts as NORMAL_RANK_ORDER; flips ONLY inside `expose_trump` when both gates are true.
    pub current_rank_order: [Rank; 8],

    // Double / Redouble window state (pre-2nd-deal only)
    pub stakes: StakesLevel,
    double_passed: [bool; 4],

    // Trick play state
    pub current_trick_leader: Option<SeatIndex>,
    pub current_trick: Vec<TrickPlay>,
    pub completed_tricks: Vec<CompletedTrick>,
    pub tricks_won_team_a: u8,
    pub tricks_won_team_b: u8,
    pub hand_points_team_a: u8,
    pub hand_points_team_b: u8,
    pub marriage_declared_by: Option<SeatIndex>,
    pub must_play_trump_seat: Option<SeatIndex>,
    /// Play index (0..3) in the current trick at which trump was exposed (None if exposed before trick or still hidden).
    pub trump_exposed_at_play_index: Option<usize>,
    /// Play index (0..3) in the current trick at which Reverse became active (None if already active before trick or inactive).
    pub reverse_activated_at_play_index: Option<usize>,

    // Match state
    pub match_score_team_a: i32,
    pub match_score_team_b: i32,
    pub hand_history: Vec<HandSummary>,
    pub match_winner: Option<Team>,
}

impl GameEngine {
    pub fn new(room_id: impl Into<String>, config: GameConfig) -> Self {
        let seats = std::array::from_fn(|i| PublicSeatInfo {
            seat: i,
            player_id: None,
            name: format!("Seat {}", i + 1),
            team: Team::of_seat(i),
            is_bot: false,
            connected: false,
            ready: false,
            card_count: 0,
        });

        Self {
            room_id: room_id.into(),
            config,
            phase: GamePhase::Lobby,
            seats,
            dealer: 0,
            hand_number: 0,
            current_turn: 1,
            deck_remainder: Vec::new(),
            hands: Default::default(),
            bid_history: Vec::new(),
            current_high_bid: None,
            current_high_bidder: None,
            passed_bidding: [false; 4],
            trump_suit: None,
            trump_mode: None,
            seventh_card_committed: false,
            seventh_card_held: None,
            reverse_enabled: false,
            trump_exposed: false,
            exposure_trigger: None,
            current_rank_order: NORMAL_RANK_ORDER,
            stakes: StakesLevel::Normal,
            double_passed: [false; 4],
            current_trick_leader: None,
            current_trick: Vec::new(),
            completed_tricks: Vec::new(),
            tricks_won_team_a: 0,
            tricks_won_team_b: 0,
            hand_points_team_a: 0,
            hand_points_team_b: 0,
            marriage_declared_by: None,
            must_play_trump_seat: None,
            trump_exposed_at_play_index: None,
            reverse_activated_at_play_index: None,
            match_score_team_a: 0,
            match_score_team_b: 0,
            hand_history: Vec::new(),
            match_winner: None,
        }
    }

    /// Returns whether Reverse ranking is currently active (both gates must be true).
    pub fn is_reverse_active(&self) -> bool {
        self.reverse_enabled
            && self.trump_exposed
            && self.current_rank_order == REVERSED_RANK_ORDER
    }

    pub fn authoritative_hand(&self, seat: SeatIndex) -> &[Card] {
        &self.hands[seat]
    }

    pub fn hidden_trump(&self) -> Option<Suit> {
        self.trump_suit
    }

    pub fn is_reverse_enabled_for_hand(&self) -> bool {
        self.reverse_enabled
    }

    /// Start a new hand: shuffle 32 cards, deal 4 to each player, begin bidding to dealer's left.
    /// When `no_four_jacks_deal` is enabled (default), uses unbiased full-deck rejection sampling
    /// so no single player's 8-card hand can ever contain all 4 Jacks.
    pub fn start_hand<R: Rng + ?Sized>(&mut self, rng: &mut R) -> Vec<ServerMessage> {
        let mut deck = shuffled_deck(rng);
        if self.config.no_four_jacks_deal {
            for _ in 0..64 {
                let has_four_jacks = (0..4usize).any(|s| {
                    let j1 = deck[s * 4..s * 4 + 4].iter().filter(|c| c.rank == Rank::Jack).count();
                    let j2 = deck[16 + s * 4..16 + s * 4 + 4].iter().filter(|c| c.rank == Rank::Jack).count();
                    j1 + j2 == 4
                });
                if !has_four_jacks {
                    break;
                }
                deck = shuffled_deck(rng);
            }
        }
        self.start_hand_with_deck(deck)
    }

    /// Deterministic start_hand for testing with a pre-arranged 32-card deck.
    pub fn start_hand_with_deck(&mut self, mut deck: Vec<Card>) -> Vec<ServerMessage> {
        assert_eq!(deck.len(), 32, "29 requires an exact 32-card deck");
        self.hand_number += 1;
        if self.hand_number > 1 {
            self.dealer = (self.dealer + 1) % 4;
        }
        self.reset_hand_fields();

        // First half of the deal: 4 cards to each player
        for seat in 0..4 {
            let mut hand: Vec<Card> = deck.drain(0..4).collect();
            sort_hand(&mut hand, &self.current_rank_order);
            self.seats[seat].card_count = hand.len();
            self.hands[seat] = hand;
        }
        // Remaining 16 cards held on server until Double/Redouble window closes
        self.deck_remainder = deck;
        self.phase = GamePhase::Bidding;
        self.current_turn = (self.dealer + 1) % 4;

        vec![ServerMessage::RoomState {
            seats: self.seats.clone(),
            dealer: self.dealer,
            phase: self.phase,
        }]
    }

    fn reset_hand_fields(&mut self) {
        self.deck_remainder.clear();
        for h in &mut self.hands {
            h.clear();
        }
        for s in &mut self.seats {
            s.card_count = 0;
        }
        self.bid_history.clear();
        self.current_high_bid = None;
        self.current_high_bidder = None;
        self.passed_bidding = [false; 4];
        self.trump_suit = None;
        self.trump_mode = None;
        self.seventh_card_committed = false;
        self.seventh_card_held = None;
        self.reverse_enabled = false;
        self.trump_exposed = false;
        self.exposure_trigger = None;
        self.current_rank_order = NORMAL_RANK_ORDER;
        self.stakes = StakesLevel::Normal;
        self.double_passed = [false; 4];
        self.current_trick_leader = None;
        self.current_trick.clear();
        self.completed_tricks.clear();
        self.tricks_won_team_a = 0;
        self.tricks_won_team_b = 0;
        self.hand_points_team_a = 0;
        self.hand_points_team_b = 0;
        self.marriage_declared_by = None;
        self.must_play_trump_seat = None;
        self.trump_exposed_at_play_index = None;
        self.reverse_activated_at_play_index = None;
    }

    /// Place a numeric bid.
    pub fn place_bid(&mut self, seat: SeatIndex, amount: u8) -> Result<Vec<ServerMessage>, GameError> {
        if self.phase != GamePhase::Bidding {
            return Err(GameError::WrongPhase(self.phase));
        }
        if seat != self.current_turn {
            return Err(GameError::NotYourTurn(seat));
        }
        let min_allowed = match self.current_high_bid {
            None => self.config.starting_bid,
            Some(high) => high.saturating_add(1),
        };
        if amount < min_allowed || amount > self.config.max_bid {
            return Err(GameError::InvalidBid(
                amount,
                min_allowed,
                self.config.max_bid,
            ));
        }

        self.current_high_bid = Some(amount);
        self.current_high_bidder = Some(seat);
        self.bid_history.push(BidEntry {
            seat,
            amount: Some(amount),
        });

        let mut events = vec![ServerMessage::BidUpdate {
            seat,
            amount: Some(amount),
            current_high_bid: self.current_high_bid,
        }];

        // If 3 other players already passed, or max_bid reached, bidding completes immediately!
        let passed_count = self.passed_bidding.iter().filter(|&&p| p).count();
        if passed_count >= 3 || amount == self.config.max_bid {
            self.finish_bidding(&mut events);
        } else {
            self.advance_bidding_turn();
        }

        Ok(events)
    }

    /// Pass during bidding.
    pub fn pass_bid<R: Rng + ?Sized>(
        &mut self,
        seat: SeatIndex,
        rng: &mut R,
    ) -> Result<Vec<ServerMessage>, GameError> {
        if self.phase != GamePhase::Bidding {
            return Err(GameError::WrongPhase(self.phase));
        }
        if seat != self.current_turn {
            return Err(GameError::NotYourTurn(seat));
        }

        self.passed_bidding[seat] = true;
        self.bid_history.push(BidEntry { seat, amount: None });

        let mut events = vec![ServerMessage::BidUpdate {
            seat,
            amount: None,
            current_high_bid: self.current_high_bid,
        }];

        let passed_count = self.passed_bidding.iter().filter(|&&p| p).count();
        if passed_count == 4 {
            // Everyone passed without bidding: redeal cleanly with same dealer
            self.hand_number = self.hand_number.saturating_sub(1);
            let redeal_events = self.start_hand(rng);
            events.extend(redeal_events);
            return Ok(events);
        }

        if passed_count == 3 {
            if self.current_high_bidder.is_some() {
                self.finish_bidding(&mut events);
            } else if self.config.force_last_bidder_min_bid {
                // First 3 players passed with no bid -> last remaining bidder (dealer) must take starting_bid (16)
                let last_seat = (0..4).find(|&s| !self.passed_bidding[s]).unwrap_or(self.dealer);
                self.current_high_bid = Some(self.config.starting_bid);
                self.current_high_bidder = Some(last_seat);
                self.bid_history.push(BidEntry {
                    seat: last_seat,
                    amount: Some(self.config.starting_bid),
                });
                events.push(ServerMessage::BidUpdate {
                    seat: last_seat,
                    amount: Some(self.config.starting_bid),
                    current_high_bid: self.current_high_bid,
                });
                self.finish_bidding(&mut events);
            } else {
                self.advance_bidding_turn();
            }
        } else {
            self.advance_bidding_turn();
        }

        Ok(events)
    }

    fn advance_bidding_turn(&mut self) {
        for step in 1..=4 {
            let next = (self.current_turn + step) % 4;
            if !self.passed_bidding[next] {
                self.current_turn = next;
                return;
            }
        }
    }

    fn finish_bidding(&mut self, events: &mut Vec<ServerMessage>) {
        let bidder = self.current_high_bidder.expect("bidder exists");
        let bid = self.current_high_bid.expect("bid exists");
        self.phase = GamePhase::SelectTrump;
        self.current_turn = bidder;
        events.push(ServerMessage::BiddingComplete { bidder, bid });
    }

    /// Bidder privately selects trump suit and per-hand Reverse toggle.
    /// Peek at the bidder's upcoming 7th card (index 2 of their next 4-card deal).
    pub fn peek_bidder_seventh_card(&self) -> Option<Card> {
        let bidder = self.current_high_bidder?;
        let idx = bidder * 4 + 2;
        self.deck_remainder.get(idx).copied()
    }

    pub fn trump_mode(&self) -> Option<TrumpMode> {
        self.trump_mode
    }
    pub fn seventh_card_held(&self) -> Option<Card> {
        self.seventh_card_held
    }
    #[cfg(test)]
    pub(crate) fn deck_remainder(&self) -> &[Card] { &self.deck_remainder }

    /// Bidder commits to 7th-card trump during SelectTrump so they can see their 7th card
    /// and choose Straight or Reverse (suit is locked to that 7th card's suit).
    pub fn choose_seventh_card(&mut self, seat: SeatIndex) -> Result<Card, GameError> {
        if self.phase != GamePhase::SelectTrump {
            return Err(GameError::WrongPhase(self.phase));
        }
        let bidder = self.current_high_bidder.ok_or(GameError::WrongPhase(self.phase))?;
        if seat != bidder {
            return Err(GameError::NotBidder(bidder));
        }
        let card = self
            .peek_bidder_seventh_card()
            .ok_or(GameError::WrongPhase(self.phase))?;
        self.seventh_card_committed = true;
        Ok(card)
    }

    /// Standard single-suit trump selection (backward-compatible helper).
    pub fn select_trump(
        &mut self,
        seat: SeatIndex,
        suit: Suit,
        reverse_enabled: bool,
    ) -> Result<Vec<ServerMessage>, GameError> {
        self.select_trump_with_mode(seat, Some(suit), reverse_enabled, TrumpMode::Suit)
    }

    /// Full trump selection supporting Standard Suit, Joker (No Trump), and 7th Card Trump.
    pub fn select_trump_with_mode(
        &mut self,
        seat: SeatIndex,
        suit: Option<Suit>,
        reverse_enabled: bool,
        mode: TrumpMode,
    ) -> Result<Vec<ServerMessage>, GameError> {
        if self.phase != GamePhase::SelectTrump {
            return Err(GameError::WrongPhase(self.phase));
        }
        let bidder = self.current_high_bidder.ok_or(GameError::WrongPhase(self.phase))?;
        if seat != bidder {
            return Err(GameError::NotBidder(bidder));
        }
        if reverse_enabled && !self.config.allow_reverse_rule_option {
            return Err(GameError::ReverseDisabled);
        }

        let effective_mode = if self.seventh_card_committed {
            TrumpMode::SeventhCard
        } else {
            mode
        };
        if effective_mode == TrumpMode::NoTrump && !self.config.allow_joker_rule_option {
            return Err(GameError::JokerDisabled);
        }

        let chosen_suit = match effective_mode {
            TrumpMode::Suit => Some(suit.ok_or(GameError::WrongPhase(self.phase))?),
            TrumpMode::NoTrump => None,
            TrumpMode::SeventhCard => {
                let seventh = self
                    .peek_bidder_seventh_card()
                    .ok_or(GameError::WrongPhase(self.phase))?;
                Some(seventh.suit)
            }
        };

        self.trump_suit = chosen_suit;
        self.trump_mode = Some(effective_mode);
        self.reverse_enabled = reverse_enabled;
        self.current_rank_order = NORMAL_RANK_ORDER;

        let mut events = Vec::new();
        if self.config.allow_doubling {
            self.phase = GamePhase::DoubleWindow;
            self.double_passed = [false; 4];
            self.current_turn = (bidder + 1) % 4;
            events.push(ServerMessage::RoomState {
                seats: self.seats.clone(),
                dealer: self.dealer,
                phase: self.phase,
            });
        } else {
            self.deal_remaining_and_start_play(&mut events);
        }

        Ok(events)
    }

    /// Opposing team calls Double strictly during DoubleWindow (before 2nd 4-card deal).
    pub fn call_double(&mut self, seat: SeatIndex) -> Result<Vec<ServerMessage>, GameError> {
        if self.phase != GamePhase::DoubleWindow {
            return Err(GameError::WrongPhase(self.phase));
        }
        if !self.config.allow_doubling {
            return Err(GameError::DoublingDisabled);
        }
        let bidder = self.current_high_bidder.expect("bidder exists");
        if self.stakes != StakesLevel::Normal || Team::of_seat(seat) == Team::of_seat(bidder) {
            return Err(GameError::CannotDouble);
        }

        self.stakes = StakesLevel::Doubled;
        let mut events = vec![ServerMessage::StakesUpdated {
            stakes: self.stakes,
            by_seat: seat,
        }];

        if self.config.allow_redoubling {
            self.double_passed = [false; 4];
            self.current_turn = bidder;
        } else {
            self.deal_remaining_and_start_play(&mut events);
        }

        Ok(events)
    }

    /// Bidder's team calls Redouble strictly during DoubleWindow after a Double.
    pub fn call_redouble(&mut self, seat: SeatIndex) -> Result<Vec<ServerMessage>, GameError> {
        if self.phase != GamePhase::DoubleWindow {
            return Err(GameError::WrongPhase(self.phase));
        }
        if !self.config.allow_redoubling {
            return Err(GameError::DoublingDisabled);
        }
        let bidder = self.current_high_bidder.expect("bidder exists");
        if self.stakes != StakesLevel::Doubled || Team::of_seat(seat) != Team::of_seat(bidder) {
            return Err(GameError::CannotRedouble);
        }

        self.stakes = StakesLevel::Redoubled;
        let mut events = vec![ServerMessage::StakesUpdated {
            stakes: self.stakes,
            by_seat: seat,
        }];
        self.deal_remaining_and_start_play(&mut events);
        Ok(events)
    }

    /// Pass on doubling/redoubling during DoubleWindow.
    pub fn pass_double_window(&mut self, seat: SeatIndex) -> Result<Vec<ServerMessage>, GameError> {
        if self.phase != GamePhase::DoubleWindow {
            return Err(GameError::WrongPhase(self.phase));
        }
        let bidder = self.current_high_bidder.expect("bidder exists");
        let eligible_team = match self.stakes {
            StakesLevel::Normal => Team::of_seat(bidder).opponent(),
            StakesLevel::Doubled => Team::of_seat(bidder),
            StakesLevel::Redoubled => return Err(GameError::WrongPhase(self.phase)),
        };
        if Team::of_seat(seat) != eligible_team {
            return Err(GameError::NotYourTurn(seat));
        }

        self.double_passed[seat] = true;
        let team_all_passed = (0..4)
            .filter(|&s| Team::of_seat(s) == eligible_team)
            .all(|s| self.double_passed[s]);

        let mut events = Vec::new();
        if team_all_passed {
            self.deal_remaining_and_start_play(&mut events);
        } else {
            // Advance turn to partner on eligible_team
            let partner = (seat + 2) % 4;
            self.current_turn = partner;
            events.push(ServerMessage::RoomState {
                seats: self.seats.clone(),
                dealer: self.dealer,
                phase: self.phase,
            });
        }
        Ok(events)
    }

    /// Close DoubleWindow, deal remaining 4 cards to each player (8 total), start trick 1.
    fn deal_remaining_and_start_play(&mut self, events: &mut Vec<ServerMessage>) {
        let bidder = self.current_high_bidder.expect("bidder exists");
        for seat in 0..4 {
            let mut extra: Vec<Card> = self.deck_remainder.drain(0..4).collect();
            if seat == bidder && self.trump_mode == Some(TrumpMode::SeventhCard) && extra.len() >= 3 {
                let seventh = extra.remove(2);
                self.seventh_card_held = Some(seventh);
                self.hands[seat].extend(extra);
                sort_hand(&mut self.hands[seat], &self.current_rank_order);
                self.seats[seat].card_count = self.hands[seat].len() + 1;
            } else {
                self.hands[seat].extend(extra);
                sort_hand(&mut self.hands[seat], &self.current_rank_order);
                self.seats[seat].card_count = self.hands[seat].len();
            }
        }
        self.phase = GamePhase::Playing;
        // First trick is led by the same player who started the bidding (dealer's left, rotating clockwise each hand)
        let leader = (self.dealer + 1) % 4;
        self.current_trick_leader = Some(leader);
        self.current_turn = leader;

        events.push(ServerMessage::RoomState {
            seats: self.seats.clone(),
            dealer: self.dealer,
            phase: self.phase,
        });
    }

    /// Single shared exposure handler: reveals trump and applies the two-gate Reverse rank flip.
    fn expose_trump(&mut self, trigger: TrumpExposeTrigger) -> ServerMessage {
        let suit = self.trump_suit;
        let mode = self.trump_mode.unwrap_or(TrumpMode::Suit);
        let already_exposed = self.trump_exposed;
        self.trump_exposed = true;
        if !already_exposed {
            self.exposure_trigger = Some(trigger);
            if !self.current_trick.is_empty() {
                self.trump_exposed_at_play_index = Some(self.current_trick.len());
            }
        }

        let reverse_activated = !already_exposed
            && self.reverse_enabled
            && self.config.reverse_trigger_on.contains(&trigger);

        if reverse_activated {
            self.current_rank_order = REVERSED_RANK_ORDER;
            if !self.current_trick.is_empty() {
                self.reverse_activated_at_play_index = Some(self.current_trick.len());
            }
        }

        if let (Some(bidder), Some(seventh)) = (self.current_high_bidder, self.seventh_card_held.take()) {
            self.hands[bidder].push(seventh);
            sort_hand(&mut self.hands[bidder], &self.current_rank_order);
            self.seats[bidder].card_count = self.hands[bidder].len();
        }

        if reverse_activated {
            for seat in 0..4 {
                sort_hand(&mut self.hands[seat], &self.current_rank_order);
            }
        }

        ServerMessage::TrumpExposed {
            suit,
            mode,
            trigger,
            reverse_activated,
        }
    }

    /// Check if `seat` is legally permitted to call REQUEST_TRUMP_SHOW right now.
    /// Rule 2.6: Any non-bidding player holding ZERO trump cards may call this at any time it is
    /// their turn to play, regardless of suit led or whether they can follow suit.
    /// Optional Show Trump: legal on your turn when trump is still concealed and you have NO
    /// cards of the led suit. You are not forced to show trump; you may discard without showing,
    /// OR call Show Trump (in which case you must play a trump card on this turn if you hold one).
    pub fn can_request_trump_show(&self, seat: SeatIndex) -> bool {
        if self.phase != GamePhase::Playing || seat != self.current_turn || self.trump_exposed {
            return false;
        }
        let Some(first) = self.current_trick.first() else {
            return false;
        };
        let led_suit = first.card.suit;
        !self.hands[seat].iter().any(|c| c.suit == led_suit)
    }

    /// Execute REQUEST_TRUMP_SHOW with strict server-side hand validation.
    pub fn request_trump_show(&mut self, seat: SeatIndex) -> Result<Vec<ServerMessage>, GameError> {
        if self.phase != GamePhase::Playing {
            return Err(GameError::WrongPhase(self.phase));
        }
        if seat != self.current_turn {
            return Err(GameError::NotYourTurn(seat));
        }
        if self.trump_exposed {
            return Err(GameError::TrumpAlreadyExposed);
        }
        let Some(first) = self.current_trick.first() else {
            return Err(GameError::CanFollowLedSuit);
        };
        let led_suit = first.card.suit;
        if self.hands[seat].iter().any(|c| c.suit == led_suit) {
            return Err(GameError::CanFollowLedSuit);
        }

        let evt = self.expose_trump(TrumpExposeTrigger::ShowTrump);
        self.must_play_trump_seat = Some(seat);
        Ok(vec![evt])
    }

    /// Legal cards `seat` can play right now (enforcing follow-suit).
    pub fn legal_cards_for(&self, seat: SeatIndex) -> Vec<Card> {
        if self.phase != GamePhase::Playing || seat != self.current_turn {
            return Vec::new();
        }
        let hand = &self.hands[seat];
        if let Some(first) = self.current_trick.first() {
            let led_suit = first.card.suit;
            let matching: Vec<Card> = hand
                .iter()
                .copied()
                .filter(|c| c.suit == led_suit)
                .collect();
            if !matching.is_empty() {
                return matching;
            }
            // If this player just called Show Trump on this turn, they MUST play a trump card if they hold one
            if self.must_play_trump_seat == Some(seat) {
                if let Some(trump) = self.trump_suit {
                    let trumps: Vec<Card> = hand
                        .iter()
                        .copied()
                        .filter(|c| c.suit == trump)
                        .collect();
                    if !trumps.is_empty() {
                        return trumps;
                    }
                }
            }
        }
        hand.clone()
    }

    /// Returns the cards (K and/or Q of trump) with which `seat` may currently declare Marriage.
    pub fn legal_marriage_cards(&self, seat: SeatIndex) -> Vec<Card> {
        if self.phase != GamePhase::Playing
            || seat != self.current_turn
            || !self.trump_exposed
            || self.marriage_declared_by.is_some()
        {
            return Vec::new();
        }
        let Some(trump) = self.trump_suit else {
            return Vec::new();
        };
        let king = Card::new(Rank::King, trump);
        let queen = Card::new(Rank::Queen, trump);
        let hand = &self.hands[seat];
        if !hand.contains(&king) || !hand.contains(&queen) {
            return Vec::new();
        }
        let legal = self.legal_cards_for(seat);
        [king, queen]
            .into_iter()
            .filter(|c| legal.contains(c))
            .collect()
    }

    /// Declare Marriage ("Bali" / "Jodi") while playing either the K or Q of trump.
    pub fn declare_marriage(
        &mut self,
        seat: SeatIndex,
        card: Card,
    ) -> Result<Vec<ServerMessage>, GameError> {
        if self.phase != GamePhase::Playing {
            return Err(GameError::WrongPhase(self.phase));
        }
        if seat != self.current_turn {
            return Err(GameError::NotYourTurn(seat));
        }
        if !self.trump_exposed {
            return Err(GameError::TrumpNotExposedForMarriage);
        }
        if self.marriage_declared_by.is_some() {
            return Err(GameError::MarriageAlreadyDeclared);
        }
        let legal_marriage = self.legal_marriage_cards(seat);
        if !legal_marriage.contains(&card) {
            return Err(GameError::InvalidMarriage);
        }

        let mut events = Vec::new();
        self.marriage_declared_by = Some(seat);
        let team = Team::of_seat(seat);
        // Marriage shifts the effective bid by -4 (if bidding team declares) or +4 (if opposing team declares)!
        events.push(ServerMessage::MarriageDeclared {
            seat,
            team,
            bonus_points: self.config.marriage_bonus_points,
        });

        // Now play the King or Queen into the trick
        let play_events = self.play_card_internal(seat, card)?;
        events.extend(play_events);
        Ok(events)
    }

    /// Play a card into the current trick.
    pub fn play_card(
        &mut self,
        seat: SeatIndex,
        card: Card,
    ) -> Result<Vec<ServerMessage>, GameError> {
        self.play_card_internal(seat, card)
    }

    fn play_card_internal(
        &mut self,
        seat: SeatIndex,
        card: Card,
    ) -> Result<Vec<ServerMessage>, GameError> {
        if self.phase != GamePhase::Playing {
            return Err(GameError::WrongPhase(self.phase));
        }
        if seat != self.current_turn {
            return Err(GameError::NotYourTurn(seat));
        }
        let pos = self.hands[seat]
            .iter()
            .position(|&c| c == card)
            .ok_or_else(|| GameError::CardNotInHand(card.id()))?;

        // Enforce follow-suit and mandatory trump play after calling Show Trump
        if let Some(first) = self.current_trick.first() {
            let led_suit = first.card.suit;
            if card.suit != led_suit && self.hands[seat].iter().any(|c| c.suit == led_suit) {
                return Err(GameError::MustFollowSuit(led_suit));
            }
            if self.must_play_trump_seat == Some(seat) {
                if let Some(trump) = self.trump_suit {
                    if card.suit != trump && self.hands[seat].iter().any(|c| c.suit == trump) {
                        return Err(GameError::MustPlayTrump(trump));
                    }
                }
            }
        }

        if self.must_play_trump_seat == Some(seat) {
            self.must_play_trump_seat = None;
        }
        self.hands[seat].remove(pos);
        let extra_held = if self.current_high_bidder == Some(seat) && self.seventh_card_held.is_some() { 1 } else { 0 };
        self.seats[seat].card_count = self.hands[seat].len() + extra_held;
        self.current_trick.push(TrickPlay { seat, card });

        let leader = self.current_trick_leader.expect("trick leader exists");
        let mut events = vec![ServerMessage::TrickUpdate {
            plays: self.current_trick.clone(),
            leader,
        }];

        if self.current_trick.len() < 4 {
            self.current_turn = (self.current_turn + 1) % 4;
            return Ok(events);
        }

        // Resolve completed trick using the single `current_rank_order`!
        let winner = self.resolve_trick_winner(&self.current_trick);
        let card_points: u8 = self.current_trick.iter().map(|p| p.card.points()).sum();
        let is_last_trick = self.completed_tricks.len() == 7;
        let trick_points = card_points + if is_last_trick && self.config.last_trick_bonus_point { 1 } else { 0 };

        let winning_team = Team::of_seat(winner);
        match winning_team {
            Team::TeamA => {
                self.tricks_won_team_a += 1;
                self.hand_points_team_a += trick_points;
            }
            Team::TeamB => {
                self.tricks_won_team_b += 1;
                self.hand_points_team_b += trick_points;
            }
        }

        let completed = CompletedTrick {
            trick_number: (self.completed_tricks.len() + 1) as u8,
            leader,
            plays: std::mem::take(&mut self.current_trick),
            winner,
            points: trick_points,
        };
        self.completed_tricks.push(completed);
        self.trump_exposed_at_play_index = None;
        self.reverse_activated_at_play_index = None;

        events.push(ServerMessage::TrickResolved {
            winner_seat: winner,
            points: trick_points,
        });

        if self.completed_tricks.len() == 8 {
            self.finish_hand(winning_team, &mut events);
        } else {
            if self.completed_tricks.len() == 7 && self.seventh_card_held.is_some() {
                let evt = self.expose_trump(TrumpExposeTrigger::ShowTrump);
                events.push(evt);
            }
            self.current_trick_leader = Some(winner);
            self.current_turn = winner;
        }

        Ok(events)
    }

    /// Compute trick winner via `self.current_rank_order`, respecting mid-trick Reverse cutoff:
    /// When Reverse is exposed mid-trick at index `k`, plays before `k` were Straight; the contest
    /// takes place among the post-exposure plays (`plays[k..]`) under Reverse rank order!
    pub fn resolve_trick_winner(&self, plays: &[TrickPlay]) -> SeatIndex {
        assert!(!plays.is_empty());
        let led_suit = plays[0].card.suit;
        let active_trump = if self.trump_exposed { self.trump_suit } else { None };
        let exposed_from = self.trump_exposed_at_play_index.unwrap_or(0);
        let rank_order = &self.current_rank_order;

        // Case 1: Post-exposure trump cuts (when trump suit != led suit).
        // Cards of the trump suit played BEFORE exposure (i < exposed_from) NEVER count as trump!
        if let Some(trump) = active_trump {
            if trump != led_suit {
                let mut best_trump: Option<TrickPlay> = None;
                for (i, &play) in plays.iter().enumerate() {
                    if i >= exposed_from && play.card.suit == trump {
                        match best_trump {
                            None => best_trump = Some(play),
                            Some(b) => {
                                if play.card.rank.strength(rank_order)
                                    > b.card.rank.strength(rank_order)
                                {
                                    best_trump = Some(play);
                                }
                            }
                        }
                    }
                }
                if let Some(winner) = best_trump {
                    return winner.seat;
                }
            }
        }

        // Case 2: No trump cut won the trick (no post-exposure trump played, trump == led_suit,
        // or Joker / No Trump). Only cards of `led_suit` can win!
        if let Some(k) = self.reverse_activated_at_play_index {
            let post_led: Vec<TrickPlay> = plays
                .iter()
                .enumerate()
                .filter(|(i, p)| *i >= k && p.card.suit == led_suit)
                .map(|(_, &p)| p)
                .collect();
            if !post_led.is_empty() {
                let mut best = post_led[0];
                for &play in &post_led[1..] {
                    if play.card.rank.strength(&REVERSED_RANK_ORDER)
                        > best.card.rank.strength(&REVERSED_RANK_ORDER)
                    {
                        best = play;
                    }
                }
                return best.seat;
            } else {
                let mut best = plays[0];
                for &play in &plays[1..] {
                    if play.card.suit == led_suit
                        && play.card.rank.strength(&NORMAL_RANK_ORDER)
                            > best.card.rank.strength(&NORMAL_RANK_ORDER)
                    {
                        best = play;
                    }
                }
                return best.seat;
            }
        }

        let mut best = plays[0];
        for &play in &plays[1..] {
            if play.card.suit == led_suit
                && play.card.rank.strength(rank_order) > best.card.rank.strength(rank_order)
            {
                best = play;
            }
        }
        best.seat
    }

    fn finish_hand(&mut self, last_trick_winner_team: Team, events: &mut Vec<ServerMessage>) {
        let bidder = self.current_high_bidder.expect("bidder exists");
        let bid = self.current_high_bid.expect("bid exists");
        let bidding_team = Team::of_seat(bidder);
        let trump_suit = self.trump_suit;
        let trump_mode = self.trump_mode.unwrap_or(TrumpMode::Suit);

        let (bidding_team_points, opposing_team_points, bidding_tricks, opposing_tricks) =
            match bidding_team {
                Team::TeamA => (
                    self.hand_points_team_a,
                    self.hand_points_team_b,
                    self.tricks_won_team_a,
                    self.tricks_won_team_b,
                ),
                Team::TeamB => (
                    self.hand_points_team_b,
                    self.hand_points_team_a,
                    self.tricks_won_team_b,
                    self.tricks_won_team_a,
                ),
            };

        let eff_bid = self.effective_bid().unwrap_or(bid);
        let bidding_won = bidding_team_points >= eff_bid;
        let winning_team = if bidding_won {
            bidding_team
        } else {
            bidding_team.opponent()
        };

        let clean_sweep = (bidding_won && bidding_tricks == 8)
            || (!bidding_won && opposing_tricks == 8);

        let delta = self.stakes.multiplier();
        let set_points_awarded = if bidding_won { delta } else { -delta };

        // Authentic 29 scoring: bidding team gains +1 (x stakes) on success or loses -1 (x stakes) on failure
        match bidding_team {
            Team::TeamA => self.match_score_team_a += set_points_awarded,
            Team::TeamB => self.match_score_team_b += set_points_awarded,
        }

        let summary = HandSummary {
            hand_number: self.hand_number,
            dealer: self.dealer,
            bidder,
            bidding_team,
            bid,
            trump_suit,
            trump_mode,
            reverse_enabled: self.reverse_enabled,
            trump_exposed: self.trump_exposed,
            exposure_trigger: self.exposure_trigger,
            reverse_activated: self.is_reverse_active(),
            marriage_declared_by: self.marriage_declared_by,
            stakes: self.stakes,
            bidding_team_points,
            opposing_team_points,
            last_trick_winner_team,
            clean_sweep,
            winning_team,
            set_points_awarded,
            match_score_team_a: self.match_score_team_a,
            match_score_team_b: self.match_score_team_b,
        };

        self.hand_history.push(summary.clone());
        if self.hand_history.len() > 30 {
            let excess = self.hand_history.len() - 30;
            self.hand_history.drain(0..excess);
        }
        events.push(ServerMessage::HandComplete { summary });

        let target = self.config.target_set_points_to_win_match;
        if self.match_score_team_a >= target || self.match_score_team_b <= -target {
            self.match_winner = Some(Team::TeamA);
            self.phase = GamePhase::MatchComplete;
            events.push(ServerMessage::MatchComplete {
                winning_team: Team::TeamA,
                match_score_team_a: self.match_score_team_a,
                match_score_team_b: self.match_score_team_b,
            });
        } else if self.match_score_team_b >= target || self.match_score_team_a <= -target {
            self.match_winner = Some(Team::TeamB);
            self.phase = GamePhase::MatchComplete;
            events.push(ServerMessage::MatchComplete {
                winning_team: Team::TeamB,
                match_score_team_a: self.match_score_team_a,
                match_score_team_b: self.match_score_team_b,
            });
        } else {
            self.phase = GamePhase::HandComplete;
        }
    }

    /// Effective bid target for the bidding team after Marriage (+4 if opposing team declared, -4 if bidding team declared).
    pub fn effective_bid(&self) -> Option<u8> {
        let bid = self.current_high_bid?;
        let bidder = self.current_high_bidder?;
        let bidding_team = Team::of_seat(bidder);
        let bonus = self.config.marriage_bonus_points;
        let max_pts = 28 + if self.config.last_trick_bonus_point { 1 } else { 0 };
        match self.marriage_declared_by {
            None => Some(bid),
            Some(mseat) if Team::of_seat(mseat) == bidding_team => {
                // Marriage can NEVER lower the effective call below starting_bid (16)!
                Some(bid.saturating_sub(bonus).max(self.config.starting_bid))
            }
            Some(_) => Some(bid.saturating_add(bonus).min(max_pts)),
        }
    }

    /// True if `seat` holds an 8-card hand with 0 total points before Trick 1 has started.
    pub fn can_declare_no_points_reshuffle(&self, seat: SeatIndex) -> bool {
        if self.phase != GamePhase::Playing
            || !self.completed_tricks.is_empty()
            || !self.current_trick.is_empty()
        {
            return false;
        }
        let hand = &self.hands[seat];
        let held = if self.current_high_bidder == Some(seat) { self.seventh_card_held } else { None };
        let total_cards = hand.len() + if held.is_some() { 1 } else { 0 };
        let held_zero = held.map(|c| c.points() == 0).unwrap_or(true);
        total_cards == 8 && held_zero && hand.iter().all(|c| c.points() == 0)
    }

    /// Optional player-triggered reshuffle when all 8 cards in their hand have 0 points.
    pub fn declare_no_points_reshuffle<R: Rng + ?Sized>(
        &mut self,
        seat: SeatIndex,
        rng: &mut R,
    ) -> Result<Vec<ServerMessage>, GameError> {
        if !self.can_declare_no_points_reshuffle(seat) {
            return Err(GameError::CannotReshuffle);
        }
        let player_name = self.seats[seat].name.clone();
        self.hand_number = self.hand_number.saturating_sub(1);
        let mut evts = vec![ServerMessage::NoPointsReshuffle { seat, player_name }];
        evts.extend(self.start_hand(rng));
        Ok(evts)
    }

        /// Produce a strictly sanitized view for a specific seat (no hidden cards, no hidden trump).
    pub fn view_for_seat(
        &self,
        seat: SeatIndex,
        turn_seconds_remaining: Option<u32>,
    ) -> PlayerView {
        let is_bidder = self.current_high_bidder == Some(seat);
        let reveal_trump_info = self.trump_exposed
            || is_bidder
            || matches!(self.phase, GamePhase::HandComplete | GamePhase::MatchComplete);
        let visible_trump = if reveal_trump_info {
            self.trump_suit
        } else {
            None
        };
        let visible_trump_mode = if reveal_trump_info {
            self.trump_mode
        } else {
            None
        };
        let reverse_choice_visible = if reveal_trump_info {
            self.trump_mode.map(|_| self.reverse_enabled)
        } else {
            None
        };
        let seventh_card_committed = self.phase == GamePhase::SelectTrump && is_bidder && self.seventh_card_committed;
        let seventh_card_preview = if seventh_card_committed {
            self.peek_bidder_seventh_card()
        } else {
            None
        };
        let seventh_card_held_face_down = is_bidder && self.seventh_card_held.is_some();

        let (can_double, can_redouble, can_pass_double) = if self.phase == GamePhase::DoubleWindow {
            let bidder = self.current_high_bidder.unwrap_or(0);
            let seat_team = Team::of_seat(seat);
            let bidder_team = Team::of_seat(bidder);
            let dbl = self.config.allow_doubling
                && self.stakes == StakesLevel::Normal
                && seat_team != bidder_team
                && !self.double_passed[seat];
            let rdbl = self.config.allow_redoubling
                && self.stakes == StakesLevel::Doubled
                && seat_team == bidder_team
                && !self.double_passed[seat];
            let pass = dbl || rdbl;
            (dbl, rdbl, pass)
        } else {
            (false, false, false)
        };

        PlayerView {
            room_id: self.room_id.clone(),
            config: self.config.clone(),
            phase: self.phase,
            your_seat: seat,
            your_hand: self.hands[seat].clone(),
            legal_cards: self.legal_cards_for(seat),
            can_request_trump_show: self.can_request_trump_show(seat),
            must_play_trump: self.must_play_trump_seat == Some(seat),
            can_declare_no_points_reshuffle: self.can_declare_no_points_reshuffle(seat),
            marriage_cards: self.legal_marriage_cards(seat),
            seats: self.seats.clone(),
            dealer: self.dealer,
            hand_number: self.hand_number,
            current_turn: self.current_turn,
            bid_history: self.bid_history.clone(),
            current_high_bid: self.current_high_bid,
            effective_bid: self.effective_bid(),
            current_high_bidder: self.current_high_bidder,
            passed_bidding: self.passed_bidding,
            visible_trump,
            visible_trump_mode,
            seventh_card_committed,
            seventh_card_preview,
            seventh_card_held_face_down,
            trump_exposed: self.trump_exposed,
            exposure_trigger: self.exposure_trigger,
            reverse_choice_visible,
            reverse_active: self.is_reverse_active(),
            current_rank_order: self.current_rank_order,
            stakes: self.stakes,
            can_double,
            can_redouble,
            can_pass_double,
            current_trick_leader: self.current_trick_leader,
            current_trick: self.current_trick.clone(),
            last_completed_trick: self.completed_tricks.last().cloned(),
            tricks_won_team_a: self.tricks_won_team_a,
            tricks_won_team_b: self.tricks_won_team_b,
            hand_points_team_a: self.hand_points_team_a,
            hand_points_team_b: self.hand_points_team_b,
            marriage_declared_by: self.marriage_declared_by,
            match_score_team_a: self.match_score_team_a,
            match_score_team_b: self.match_score_team_b,
            last_hand_summary: self.hand_history.last().cloned(),
            hand_history: self.hand_history.clone(),
            match_winner: self.match_winner,
            turn_seconds_remaining,
        }
    }
}
