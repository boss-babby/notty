use crate::protocol::TrumpMode;
use crate::bot::choose_bot_action;
use crate::cards::{
    standard_32_deck, Card, Rank, Suit, NORMAL_RANK_ORDER, REVERSED_RANK_ORDER,
};
use crate::config::{GameConfig, TrumpExposeTrigger};
use crate::engine::{GameEngine, GameError};
use crate::protocol::{ClientMessage, GamePhase, ServerMessage, StakesLevel, Team, TrickPlay};
use rand::rngs::StdRng;
use rand::SeedableRng;

fn c(rank: Rank, suit: Suit) -> Card {
    Card::new(rank, suit)
}

/// Build a deterministic 32-card deck from explicit 4+4 hands for seats 0..3.
fn deck_from_hands(first4: [[Card; 4]; 4], second4: [[Card; 4]; 4]) -> Vec<Card> {
    let mut deck = Vec::with_capacity(32);
    for h in first4 {
        deck.extend_from_slice(&h);
    }
    for h in second4 {
        deck.extend_from_slice(&h);
    }
    assert_eq!(deck.len(), 32);
    deck
}

#[test]
fn deck_has_32_cards_and_28_card_points() {
    let deck = standard_32_deck();
    assert_eq!(deck.len(), 32);
    let total_points: u8 = deck.iter().map(|card| card.points()).sum();
    assert_eq!(total_points, 28);
}

#[test]
fn double_window_enforced_strictly_before_second_deal() {
    let mut rng = StdRng::seed_from_u64(42);
    let mut engine = GameEngine::new("ROOM1", GameConfig::default());
    engine.start_hand(&mut rng);

    // Every player has 4 cards during bidding
    for s in 0..4 {
        assert_eq!(engine.authoritative_hand(s).len(), 4);
    }

    // Dealer = 0, so seat 1 bids first
    assert_eq!(engine.current_turn, 1);
    engine.place_bid(1, 16).unwrap();
    engine.pass_bid(2, &mut rng).unwrap();
    engine.pass_bid(3, &mut rng).unwrap();
    engine.pass_bid(0, &mut rng).unwrap();

    assert_eq!(engine.phase, GamePhase::SelectTrump);
    assert_eq!(engine.current_high_bidder, Some(1));

    // Double rejected before trump is chosen
    assert_eq!(
        engine.call_double(0),
        Err(GameError::WrongPhase(GamePhase::SelectTrump))
    );

    // Bidder (seat 1, Team B) selects Spades with Reverse OFF
    engine.select_trump(1, Suit::Spades, false).unwrap();
    assert_eq!(engine.phase, GamePhase::DoubleWindow);
    // Still only 4 cards each!
    for s in 0..4 {
        assert_eq!(engine.authoritative_hand(s).len(), 4);
    }

    // Concealed trump check: Bidder sees Spades, others see None
    assert_eq!(engine.view_for_seat(1, None).visible_trump, Some(Suit::Spades));
    assert_eq!(engine.view_for_seat(0, None).visible_trump, None);
    assert_eq!(engine.view_for_seat(2, None).visible_trump, None);
    assert_eq!(engine.view_for_seat(3, None).visible_trump, None);

    // Bidding team (seat 3, Team B) cannot Double
    assert_eq!(engine.call_double(3), Err(GameError::CannotDouble));

    // Opposing team (seat 0, Team A) calls Double -> stakes 2x
    engine.call_double(0).unwrap();
    assert_eq!(engine.stakes, StakesLevel::Doubled);
    assert_eq!(engine.phase, GamePhase::DoubleWindow);

    // Opposing team cannot Redouble
    assert_eq!(engine.call_redouble(2), Err(GameError::CannotRedouble));

    // Bidding team (seat 3, Team B) calls Redouble -> stakes 4x, window closes, remaining 4 cards dealt!
    engine.call_redouble(3).unwrap();
    assert_eq!(engine.stakes, StakesLevel::Redoubled);
    assert_eq!(engine.phase, GamePhase::Playing);
    for s in 0..4 {
        assert_eq!(engine.authoritative_hand(s).len(), 8);
    }

    // Double / Redouble strictly rejected once Playing begins
    assert_eq!(
        engine.call_double(0),
        Err(GameError::WrongPhase(GamePhase::Playing))
    );
    assert_eq!(
        engine.call_redouble(1),
        Err(GameError::WrongPhase(GamePhase::Playing))
    );
}

#[test]
fn show_trump_validation_and_two_gate_reverse_rule() {
    // Craft hands where:
    // Bidder = Seat 1 chooses Trump = Spades, Reverse = TRUE.
    // Seat 2 (leads trick 1, non-bidder) holds NO Spades (all Hearts/Clubs/Diamonds).
    // Seat 3 holds a Spade.
    let first4 = [
        [c(Rank::Jack, Suit::Hearts), c(Rank::Nine, Suit::Hearts), c(Rank::Ace, Suit::Hearts), c(Rank::Ten, Suit::Hearts)],
        [c(Rank::Jack, Suit::Spades), c(Rank::Nine, Suit::Spades), c(Rank::Seven, Suit::Spades), c(Rank::Eight, Suit::Spades)],
        [c(Rank::Seven, Suit::Hearts), c(Rank::Eight, Suit::Hearts), c(Rank::Seven, Suit::Clubs), c(Rank::Eight, Suit::Clubs)],
        [c(Rank::Ace, Suit::Spades), c(Rank::Ten, Suit::Spades), c(Rank::Jack, Suit::Clubs), c(Rank::Nine, Suit::Clubs)],
    ];
    let second4 = [
        [c(Rank::King, Suit::Hearts), c(Rank::Queen, Suit::Hearts), c(Rank::King, Suit::Clubs), c(Rank::Queen, Suit::Clubs)],
        [c(Rank::King, Suit::Spades), c(Rank::Queen, Suit::Spades), c(Rank::Ace, Suit::Clubs), c(Rank::Ten, Suit::Clubs)],
        [c(Rank::Seven, Suit::Diamonds), c(Rank::Eight, Suit::Diamonds), c(Rank::Queen, Suit::Diamonds), c(Rank::King, Suit::Diamonds)],
        [c(Rank::Jack, Suit::Diamonds), c(Rank::Nine, Suit::Diamonds), c(Rank::Ace, Suit::Diamonds), c(Rank::Ten, Suit::Diamonds)],
    ];
    let deck = deck_from_hands(first4, second4);

    let mut cfg = GameConfig::default();
    cfg.allow_doubling = false;
    let mut engine = GameEngine::new("REV1", cfg);
    engine.config.force_last_bidder_min_bid = false;
    engine.dealer = 1;
    let mut rng = StdRng::seed_from_u64(7);
    engine.start_hand_with_deck(deck);

    // Seat 1 bids 16, others pass
    engine.pass_bid(2, &mut rng).unwrap();
    engine.pass_bid(3, &mut rng).unwrap();
    engine.pass_bid(0, &mut rng).unwrap();
    engine.place_bid(1, 16).unwrap();

    // Seat 1 selects Spades with Reverse = ON (Gate 1 TRUE, Gate 2 FALSE)
    engine.select_trump(1, Suit::Spades, true).unwrap();
    assert_eq!(engine.phase, GamePhase::Playing);
    assert!(!engine.trump_exposed);
    assert!(!engine.is_reverse_active());
    assert_eq!(engine.current_rank_order, NORMAL_RANK_ORDER);

    // Trick 1: Seat 2 leads 7 of Hearts (normal order: Jack of Hearts > 7 of Hearts!)
    assert_eq!(engine.current_turn, 2);
    engine.play_card(2, c(Rank::Seven, Suit::Hearts)).unwrap();
    // Seat 3 has no Hearts -> Show Trump is OPTIONAL: Seat 3 chooses NOT to show trump and discards Jack of Clubs!
    assert!(engine.can_request_trump_show(3));
    engine.play_card(3, c(Rank::Jack, Suit::Clubs)).unwrap();
    // Seat 0 HAS Hearts -> cannot call Show Trump!
    assert!(!engine.can_request_trump_show(0));
    assert_eq!(engine.request_trump_show(0), Err(GameError::CanFollowLedSuit));
    engine.play_card(0, c(Rank::Jack, Suit::Hearts)).unwrap();
    // Seat 1 has no Hearts -> chooses NOT to show trump, discards Ten of Clubs
    let evts = engine.play_card(1, c(Rank::Ten, Suit::Clubs)).unwrap();

    // Because trump was NOT exposed, Reverse was NOT active! Jack of Hearts beat 7 of Hearts!
    assert!(evts.contains(&ServerMessage::TrickResolved {
        winner_seat: 0,
        points: 7, // J(3) + J(3) + 10(1) = 7
    }));
    assert!(!engine.is_reverse_active());

    // Trick 2: Seat 0 leads King of Hearts; Seat 1 is void in Hearts and calls Show Trump!
    engine.play_card(0, c(Rank::King, Suit::Hearts)).unwrap();
    assert!(engine.can_request_trump_show(1));
    let show_evts = engine.request_trump_show(1).unwrap();
    assert_eq!(
        show_evts,
        vec![ServerMessage::TrumpExposed {
            suit: Some(Suit::Spades),
            mode: TrumpMode::Suit,
            trigger: TrumpExposeTrigger::ShowTrump,
            reverse_activated: true,
        }]
    );
    // BOTH GATES TRUE: Rank order is now REVERSED for ALL suits!
    assert!(engine.is_reverse_active());
    assert_eq!(engine.current_rank_order, REVERSED_RANK_ORDER);

    // Because Seat 1 called Show Trump and holds Spades, Seat 1 MUST play a Spade (non-trump rejected!)
    assert_eq!(
        engine.play_card(1, c(Rank::Ace, Suit::Clubs)),
        Err(GameError::MustPlayTrump(Suit::Spades))
    );
    // Seat 1 plays 7 of Spades (strongest trump under Reverse!)
    engine.play_card(1, c(Rank::Seven, Suit::Spades)).unwrap();
    engine.play_card(2, c(Rank::Eight, Suit::Hearts)).unwrap();
    // Seat 3 plays Ace of Spades (weaker than 7 of Spades under Reverse!)
    let t2_evts = engine.play_card(3, c(Rank::Ace, Suit::Spades)).unwrap();
    assert!(t2_evts.contains(&ServerMessage::TrickResolved {
        winner_seat: 1,
        points: 1, // Ace of Spades = 1 pt
    }));

    // Verify reversed order ALSO applies to trump suit (Spades): 7S beats JS!
    let sim = vec![
        TrickPlay { seat: 0, card: c(Rank::Jack, Suit::Spades) },
        TrickPlay { seat: 1, card: c(Rank::Seven, Suit::Spades) },
    ];
    assert_eq!(engine.resolve_trick_winner(&sim), 1);
}

#[test]
fn marriage_exposes_trump_triggers_reverse_and_awards_bonus() {
    let first4 = [
        [c(Rank::King, Suit::Spades), c(Rank::Queen, Suit::Spades), c(Rank::Seven, Suit::Hearts), c(Rank::Eight, Suit::Hearts)],
        [c(Rank::Jack, Suit::Spades), c(Rank::Nine, Suit::Spades), c(Rank::Ace, Suit::Spades), c(Rank::Ten, Suit::Spades)],
        [c(Rank::Seven, Suit::Spades), c(Rank::Eight, Suit::Spades), c(Rank::Jack, Suit::Hearts), c(Rank::Nine, Suit::Hearts)],
        [c(Rank::Ace, Suit::Hearts), c(Rank::Ten, Suit::Hearts), c(Rank::King, Suit::Hearts), c(Rank::Queen, Suit::Hearts)],
    ];
    let second4 = [
        [c(Rank::Jack, Suit::Clubs), c(Rank::Nine, Suit::Clubs), c(Rank::Ace, Suit::Clubs), c(Rank::Ten, Suit::Clubs)],
        [c(Rank::King, Suit::Clubs), c(Rank::Queen, Suit::Clubs), c(Rank::Eight, Suit::Clubs), c(Rank::Seven, Suit::Clubs)],
        [c(Rank::Jack, Suit::Diamonds), c(Rank::Nine, Suit::Diamonds), c(Rank::Ace, Suit::Diamonds), c(Rank::Ten, Suit::Diamonds)],
        [c(Rank::King, Suit::Diamonds), c(Rank::Queen, Suit::Diamonds), c(Rank::Eight, Suit::Diamonds), c(Rank::Seven, Suit::Diamonds)],
    ];
    let mut cfg = GameConfig::default();
    cfg.allow_doubling = false;
    let mut engine = GameEngine::new("MAR1", cfg);
    engine.config.force_last_bidder_min_bid = false;
    engine.dealer = 1;
    let mut rng = StdRng::seed_from_u64(99);
    engine.start_hand_with_deck(deck_from_hands(first4, second4));

    engine.pass_bid(2, &mut rng).unwrap();
    engine.pass_bid(3, &mut rng).unwrap();
    engine.pass_bid(0, &mut rng).unwrap();
    engine.place_bid(1, 16).unwrap();
    engine.select_trump(1, Suit::Spades, true).unwrap();

    // Seat 2 leads 7 of Spades; Seat 3 is void in Spades -> calls Show Trump!
    // Before trump is exposed, Marriage cannot be declared; AFTER trump is exposed, Seat 0 declares Marriage!
    engine.play_card(2, c(Rank::Seven, Suit::Spades)).unwrap();
    engine.request_trump_show(3).unwrap();
    assert!(engine.is_reverse_active());
    engine.play_card(3, c(Rank::King, Suit::Hearts)).unwrap();

    // Now trump IS exposed, and Seat 0 (Opposing team, Team A) holds K & Q of Spades!
    assert_eq!(engine.legal_marriage_cards(0).len(), 2);
    let evts = engine.declare_marriage(0, c(Rank::King, Suit::Spades)).unwrap();
    assert!(evts.contains(&ServerMessage::MarriageDeclared {
        seat: 0,
        team: Team::TeamA,
        bonus_points: 4,
    }));
    // Opposing team declared Marriage -> Bidding team's effective bid increases by +4 (16 -> 20)!
    assert_eq!(engine.effective_bid(), Some(20));
}

#[test]
fn reverse_option_disabled_in_config_rejects_reverse_toggle() {
    let mut cfg = GameConfig::default();
    cfg.allow_reverse_rule_option = false;
    let mut engine = GameEngine::new("NOREV", cfg);
    let mut rng = StdRng::seed_from_u64(5);
    engine.start_hand(&mut rng);
    engine.place_bid(1, 16).unwrap();
    engine.pass_bid(2, &mut rng).unwrap();
    engine.pass_bid(3, &mut rng).unwrap();
    engine.pass_bid(0, &mut rng).unwrap();
    assert_eq!(
        engine.select_trump(1, Suit::Hearts, true),
        Err(GameError::ReverseDisabled)
    );
    assert!(engine.select_trump(1, Suit::Hearts, false).is_ok());
}

#[test]
fn full_match_simulation_with_bots_completes_cleanly() {
    let mut rng = StdRng::seed_from_u64(2026);
    let mut engine = GameEngine::new("BOTMATCH", GameConfig::default());
    engine.start_hand(&mut rng);

    let mut safety = 0;
    while engine.phase != GamePhase::MatchComplete && safety < 5000 {
        safety += 1;
        if engine.phase == GamePhase::HandComplete {
            // Verify reverse & exposure reset cleanly on next hand
            engine.start_hand(&mut rng);
            assert!(!engine.trump_exposed);
            assert!(!engine.is_reverse_active());
            assert_eq!(engine.current_rank_order, NORMAL_RANK_ORDER);
            continue;
        }
        let seat = engine.current_turn;
        let action = choose_bot_action(&engine, seat)
            .expect("bot should always produce an action on its turn");
        match action {
            ClientMessage::PlaceBid { amount } => {
                engine.place_bid(seat, amount).unwrap();
            }
            ClientMessage::PassBid => {
                engine.pass_bid(seat, &mut rng).unwrap();
            }
            ClientMessage::ChooseSeventhCard => {
                engine.choose_seventh_card(seat).unwrap();
            }
            ClientMessage::SelectTrump {
                suit,
                reverse_enabled,
                mode,
            } => {
                engine.select_trump_with_mode(seat, suit, reverse_enabled, mode).unwrap();
            }
            ClientMessage::DoubleStakes => {
                engine.call_double(seat).unwrap();
            }
            ClientMessage::RedoubleStakes => {
                engine.call_redouble(seat).unwrap();
            }
            ClientMessage::PassDoubleWindow => {
                engine.pass_double_window(seat).unwrap();
            }
            ClientMessage::RequestTrumpShow => {
                engine.request_trump_show(seat).unwrap();
            }
            ClientMessage::DeclareMarriage { card_id } => {
                let card = Card::from_id(&card_id).unwrap();
                engine.declare_marriage(seat, card).unwrap();
            }
            ClientMessage::PlayCard { card_id } => {
                let card = Card::from_id(&card_id).unwrap();
                engine.play_card(seat, card).unwrap();
            }
            _ => unreachable!(),
        }
    }

    assert_eq!(engine.phase, GamePhase::MatchComplete);
    assert!(engine.match_winner.is_some());
    assert!(!engine.hand_history.is_empty());
    // Verify total points in every hand are at least 29 (28 card pts + 1 last trick + optional marriage)
    for h in &engine.hand_history {
        let total = h.bidding_team_points + h.opposing_team_points;
        assert!(total == 28 || total == 32, "unexpected hand total {}", total);
    }
}


#[test]
fn max_bid_is_28_and_last_bidder_forced_to_take_16() {
    let mut rng = StdRng::seed_from_u64(11);
    let mut engine = GameEngine::new("BID28", GameConfig::default());
    assert_eq!(engine.config.max_bid, 28);
    assert!(engine.config.force_last_bidder_min_bid);
    engine.start_hand(&mut rng);

    // Bid 29 must be rejected!
    assert!(engine.place_bid(1, 29).is_err());

    // First 3 players (seats 1, 2, 3) all pass -> dealer (seat 0) is automatically forced to take 16!
    engine.pass_bid(1, &mut rng).unwrap();
    engine.pass_bid(2, &mut rng).unwrap();
    engine.pass_bid(3, &mut rng).unwrap();
    assert_eq!(engine.phase, GamePhase::SelectTrump);
    assert_eq!(engine.current_high_bidder, Some(0));
    assert_eq!(engine.current_high_bid, Some(16));
}

#[test]
fn mid_trick_reverse_cutoff_at_third_and_fourth_card() {
    // Test Reverse opened on 3rd player (index 2): contest is ONLY between 3rd and 4th players!
    let first4 = [
        [c(Rank::Jack, Suit::Hearts), c(Rank::Nine, Suit::Hearts), c(Rank::Ace, Suit::Hearts), c(Rank::Ten, Suit::Hearts)],
        [c(Rank::Jack, Suit::Spades), c(Rank::Nine, Suit::Spades), c(Rank::Seven, Suit::Spades), c(Rank::Eight, Suit::Spades)],
        [c(Rank::King, Suit::Hearts), c(Rank::Queen, Suit::Hearts), c(Rank::Seven, Suit::Clubs), c(Rank::Eight, Suit::Clubs)],
        [c(Rank::Ace, Suit::Spades), c(Rank::Ten, Suit::Spades), c(Rank::Jack, Suit::Clubs), c(Rank::Nine, Suit::Clubs)],
    ];
    let second4 = [
        [c(Rank::Seven, Suit::Hearts), c(Rank::Eight, Suit::Hearts), c(Rank::King, Suit::Clubs), c(Rank::Queen, Suit::Clubs)],
        [c(Rank::King, Suit::Spades), c(Rank::Queen, Suit::Spades), c(Rank::Ace, Suit::Clubs), c(Rank::Ten, Suit::Clubs)],
        [c(Rank::Seven, Suit::Diamonds), c(Rank::Eight, Suit::Diamonds), c(Rank::Queen, Suit::Diamonds), c(Rank::King, Suit::Diamonds)],
        [c(Rank::Jack, Suit::Diamonds), c(Rank::Nine, Suit::Diamonds), c(Rank::Ace, Suit::Diamonds), c(Rank::Ten, Suit::Diamonds)],
    ];
    let mut cfg = GameConfig::default();
    cfg.allow_doubling = false;
    let mut engine = GameEngine::new("MIDREV", cfg);
    engine.config.force_last_bidder_min_bid = false;
    engine.dealer = 1;
    let mut rng = StdRng::seed_from_u64(55);
    engine.start_hand_with_deck(deck_from_hands(first4, second4));

    engine.pass_bid(2, &mut rng).unwrap();
    engine.pass_bid(3, &mut rng).unwrap();
    engine.pass_bid(0, &mut rng).unwrap();
    engine.place_bid(1, 16).unwrap();
    engine.select_trump(1, Suit::Spades, true).unwrap();

    // Seat 2 leads 7 of Clubs; Seat 3 follows with Jack of Clubs; Seat 0 follows with King of Clubs;
    // Seat 1 is void in Clubs (wait: Seat 1 has Ace of Clubs! Let's lead Diamonds where Seat 0 has NO Diamonds!)
    // Seat 2 leads 7 of Diamonds; Seat 3 follows with Ace of Diamonds;
    // Now Seat 0 (3rd player, index 2) has NO Diamonds -> calls Show Trump! Reverse flips ON at index 2!
    engine.play_card(2, c(Rank::Seven, Suit::Diamonds)).unwrap();
    engine.play_card(3, c(Rank::Ace, Suit::Diamonds)).unwrap();
    engine.request_trump_show(0).unwrap();
    assert_eq!(engine.reverse_activated_at_play_index, Some(2));
    // Seat 0 holds no Spades, plays 8 of Hearts (Reverse rank 8);
    // Seat 1 (4th player, index 3) has no Diamonds, plays 7 of Spades (trump + smallest Reverse rank!) -> Seat 1 wins!
    engine.play_card(0, c(Rank::Eight, Suit::Hearts)).unwrap();
    let evts = engine.play_card(1, c(Rank::Seven, Suit::Spades)).unwrap();
    assert!(evts.contains(&ServerMessage::TrickResolved {
        winner_seat: 1,
        points: 1,
    }));
}

#[test]
fn zero_point_8card_hand_can_reshuffle() {
    let first4 = [
        [c(Rank::Seven, Suit::Spades), c(Rank::Eight, Suit::Spades), c(Rank::Queen, Suit::Spades), c(Rank::King, Suit::Spades)],
        [c(Rank::Jack, Suit::Spades), c(Rank::Nine, Suit::Spades), c(Rank::Ace, Suit::Spades), c(Rank::Ten, Suit::Spades)],
        [c(Rank::Jack, Suit::Hearts), c(Rank::Nine, Suit::Hearts), c(Rank::Ace, Suit::Hearts), c(Rank::Ten, Suit::Hearts)],
        [c(Rank::Jack, Suit::Diamonds), c(Rank::Nine, Suit::Diamonds), c(Rank::Ace, Suit::Diamonds), c(Rank::Ten, Suit::Diamonds)],
    ];
    let second4 = [
        [c(Rank::Seven, Suit::Hearts), c(Rank::Eight, Suit::Hearts), c(Rank::Queen, Suit::Hearts), c(Rank::King, Suit::Hearts)],
        [c(Rank::Jack, Suit::Clubs), c(Rank::Nine, Suit::Clubs), c(Rank::Ace, Suit::Clubs), c(Rank::Ten, Suit::Clubs)],
        [c(Rank::Seven, Suit::Diamonds), c(Rank::Eight, Suit::Diamonds), c(Rank::Queen, Suit::Diamonds), c(Rank::King, Suit::Diamonds)],
        [c(Rank::Seven, Suit::Clubs), c(Rank::Eight, Suit::Clubs), c(Rank::Queen, Suit::Clubs), c(Rank::King, Suit::Clubs)],
    ];
    let mut cfg = GameConfig::default();
    cfg.allow_doubling = false;
    let mut engine = GameEngine::new("ZERO", cfg);
    let mut rng = StdRng::seed_from_u64(88);
    engine.start_hand_with_deck(deck_from_hands(first4, second4));
    engine.place_bid(1, 16).unwrap();
    engine.pass_bid(2, &mut rng).unwrap();
    engine.pass_bid(3, &mut rng).unwrap();
    engine.pass_bid(0, &mut rng).unwrap();
    engine.select_trump(1, Suit::Spades, false).unwrap();

    // Seat 0 holds 8 cards with 0 points -> can optionally reshuffle!
    assert!(engine.can_declare_no_points_reshuffle(0));
    assert!(!engine.can_declare_no_points_reshuffle(1));
    engine.declare_no_points_reshuffle(0, &mut rng).unwrap();
    assert_eq!(engine.phase, GamePhase::Bidding);
}


fn make_32_deck(first16: [Card; 16], second16: [Card; 16]) -> Vec<Card> {
    let mut v = Vec::with_capacity(32);
    v.extend_from_slice(&first16);
    v.extend_from_slice(&second16);
    v
}

#[test]
fn joker_no_trump_allows_straight_and_reverse_with_no_cuts() {
    let mut cfg = GameConfig::default();
    cfg.allow_doubling = false;
    let mut rng = StdRng::seed_from_u64(42);
    let mut engine = GameEngine::new("JOKR", cfg);
    engine.config.force_last_bidder_min_bid = false;
    engine.dealer = 1;
    engine.start_hand_with_deck(make_32_deck(
        [
            c(Rank::Ace, Suit::Hearts), c(Rank::King, Suit::Hearts), c(Rank::Seven, Suit::Clubs), c(Rank::Eight, Suit::Clubs),
            c(Rank::Jack, Suit::Hearts), c(Rank::Nine, Suit::Hearts), c(Rank::Ten, Suit::Diamonds), c(Rank::Queen, Suit::Diamonds),
            c(Rank::Seven, Suit::Hearts), c(Rank::Eight, Suit::Hearts), c(Rank::Jack, Suit::Spades), c(Rank::Nine, Suit::Spades),
            c(Rank::Ten, Suit::Hearts), c(Rank::Queen, Suit::Hearts), c(Rank::Ace, Suit::Spades), c(Rank::King, Suit::Spades),
        ],
        [
            c(Rank::Nine, Suit::Clubs), c(Rank::Ten, Suit::Clubs), c(Rank::Queen, Suit::Clubs), c(Rank::King, Suit::Clubs),
            c(Rank::Seven, Suit::Diamonds), c(Rank::Eight, Suit::Diamonds), c(Rank::Nine, Suit::Diamonds), c(Rank::Jack, Suit::Diamonds),
            c(Rank::Ten, Suit::Spades), c(Rank::Queen, Suit::Spades), c(Rank::Seven, Suit::Spades), c(Rank::Eight, Suit::Spades),
            c(Rank::Ace, Suit::Clubs), c(Rank::Jack, Suit::Clubs), c(Rank::Ace, Suit::Diamonds), c(Rank::King, Suit::Diamonds),
        ],
    ));
    engine.pass_bid(2, &mut rng).unwrap();
    engine.pass_bid(3, &mut rng).unwrap();
    engine.pass_bid(0, &mut rng).unwrap();
    engine.place_bid(1, 16).unwrap();

    engine
        .select_trump_with_mode(1, None, true, TrumpMode::NoTrump)
        .unwrap();
    assert_eq!(engine.trump_mode(), Some(TrumpMode::NoTrump));
    let v1 = engine.view_for_seat(1, None);
    assert_eq!(v1.visible_trump, None);
    assert_eq!(v1.visible_trump_mode, Some(TrumpMode::NoTrump));
    assert_eq!(v1.reverse_choice_visible, Some(true));

    engine.play_card(2, c(Rank::Seven, Suit::Spades)).unwrap();
    engine.play_card(3, c(Rank::Ace, Suit::Spades)).unwrap();
    let evts = engine.request_trump_show(0).unwrap();
    assert!(matches!(
        evts[0],
        ServerMessage::TrumpExposed { suit: None, mode: TrumpMode::NoTrump, reverse_activated: true, .. }
    ));
    assert!(engine.is_reverse_active());
    engine.play_card(0, c(Rank::Seven, Suit::Clubs)).unwrap();
    engine.play_card(1, c(Rank::Seven, Suit::Diamonds)).unwrap();
    assert_eq!(engine.completed_tricks.last().unwrap().winner, 3);
}

#[test]
fn seventh_card_trump_held_face_down_and_returns_on_exposure() {
    let mut cfg = GameConfig::default();
    cfg.allow_doubling = false;
    let mut rng = StdRng::seed_from_u64(43);
    let mut engine = GameEngine::new("SEVN", cfg);
    engine.config.force_last_bidder_min_bid = false;
    engine.dealer = 1;
    engine.start_hand_with_deck(make_32_deck(
        [
            c(Rank::Ace, Suit::Clubs), c(Rank::King, Suit::Clubs), c(Rank::Seven, Suit::Clubs), c(Rank::Eight, Suit::Clubs),
            c(Rank::Jack, Suit::Spades), c(Rank::Nine, Suit::Spades), c(Rank::Ten, Suit::Diamonds), c(Rank::Queen, Suit::Diamonds),
            c(Rank::Seven, Suit::Hearts), c(Rank::Eight, Suit::Hearts), c(Rank::Nine, Suit::Hearts), c(Rank::Ten, Suit::Hearts),
            c(Rank::Queen, Suit::Hearts), c(Rank::King, Suit::Hearts), c(Rank::Ace, Suit::Spades), c(Rank::King, Suit::Spades),
        ],
        [
            c(Rank::Nine, Suit::Clubs), c(Rank::Ten, Suit::Clubs), c(Rank::Queen, Suit::Clubs), c(Rank::Jack, Suit::Clubs),
            c(Rank::Seven, Suit::Diamonds), c(Rank::Eight, Suit::Diamonds), c(Rank::Jack, Suit::Hearts), c(Rank::Nine, Suit::Diamonds),
            c(Rank::Ten, Suit::Spades), c(Rank::Queen, Suit::Spades), c(Rank::Seven, Suit::Spades), c(Rank::Eight, Suit::Spades),
            c(Rank::Ace, Suit::Hearts), c(Rank::Jack, Suit::Diamonds), c(Rank::Ace, Suit::Diamonds), c(Rank::King, Suit::Diamonds),
        ],
    ));
    engine.pass_bid(2, &mut rng).unwrap();
    engine.pass_bid(3, &mut rng).unwrap();
    engine.pass_bid(0, &mut rng).unwrap();
    engine.place_bid(1, 16).unwrap();

    let preview = engine.choose_seventh_card(1).unwrap();
    assert_eq!(preview, c(Rank::Jack, Suit::Hearts));
    assert_eq!(engine.view_for_seat(1, None).seventh_card_preview, Some(c(Rank::Jack, Suit::Hearts)));
    assert_eq!(engine.view_for_seat(2, None).seventh_card_preview, None);

    engine
        .select_trump_with_mode(1, None, false, TrumpMode::SeventhCard)
        .unwrap();

    let v1 = engine.view_for_seat(1, None);
    assert_eq!(v1.visible_trump, Some(Suit::Hearts));
    assert_eq!(v1.your_hand.len(), 7);
    assert!(v1.seventh_card_held_face_down);
    assert!(!v1.your_hand.contains(&c(Rank::Jack, Suit::Hearts)));

    engine.play_card(2, c(Rank::Seven, Suit::Hearts)).unwrap();
    engine.play_card(3, c(Rank::Queen, Suit::Hearts)).unwrap();
    engine.play_card(0, c(Rank::Seven, Suit::Clubs)).unwrap();
    assert!(engine.can_request_trump_show(1));

    engine.request_trump_show(1).unwrap();
    let v1_after = engine.view_for_seat(1, None);
    assert!(!v1_after.seventh_card_held_face_down);
    assert!(v1_after.your_hand.contains(&c(Rank::Jack, Suit::Hearts)));
    engine.play_card(1, c(Rank::Jack, Suit::Hearts)).unwrap();
    assert_eq!(engine.completed_tricks.last().unwrap().winner, 1);
}

#[test]
fn edge_cases_pre_exposure_trump_and_mid_trick_reverse() {
    let mut cfg = GameConfig::default();
    cfg.allow_doubling = false;
    let mut rng = StdRng::seed_from_u64(44);

    // Edge Case A: Pre-exposure hidden trump discard (JS) is NOT counted as trump; post-exposure 7S wins!
    let mut e1 = GameEngine::new("EDGA", cfg.clone());
    e1.config.force_last_bidder_min_bid = false;
    e1.dealer = 1;
    e1.start_hand_with_deck(make_32_deck(
        [
            c(Rank::Seven, Suit::Spades), c(Rank::Eight, Suit::Diamonds), c(Rank::Nine, Suit::Diamonds), c(Rank::Ten, Suit::Diamonds),
            c(Rank::Seven, Suit::Hearts), c(Rank::Eight, Suit::Hearts), c(Rank::Nine, Suit::Hearts), c(Rank::Ten, Suit::Hearts),
            c(Rank::Ace, Suit::Clubs), c(Rank::King, Suit::Clubs), c(Rank::Queen, Suit::Clubs), c(Rank::Ten, Suit::Clubs),
            c(Rank::Jack, Suit::Spades), c(Rank::Nine, Suit::Spades), c(Rank::Ace, Suit::Spades), c(Rank::King, Suit::Spades),
        ],
        [
            c(Rank::Queen, Suit::Diamonds), c(Rank::King, Suit::Diamonds), c(Rank::Ace, Suit::Diamonds), c(Rank::Jack, Suit::Diamonds),
            c(Rank::Seven, Suit::Clubs), c(Rank::Eight, Suit::Clubs), c(Rank::Nine, Suit::Clubs), c(Rank::Jack, Suit::Clubs),
            c(Rank::Queen, Suit::Hearts), c(Rank::King, Suit::Hearts), c(Rank::Ace, Suit::Hearts), c(Rank::Jack, Suit::Hearts),
            c(Rank::Ten, Suit::Spades), c(Rank::Queen, Suit::Spades), c(Rank::Eight, Suit::Spades), c(Rank::Seven, Suit::Diamonds),
        ],
    ));
    e1.pass_bid(2, &mut rng).unwrap();
    e1.pass_bid(3, &mut rng).unwrap();
    e1.pass_bid(0, &mut rng).unwrap();
    e1.place_bid(1, 16).unwrap();
    e1.select_trump(1, Suit::Spades, false).unwrap();

    e1.play_card(2, c(Rank::Ace, Suit::Clubs)).unwrap();
    e1.play_card(3, c(Rank::Jack, Suit::Spades)).unwrap();
    e1.request_trump_show(0).unwrap();
    e1.play_card(0, c(Rank::Seven, Suit::Spades)).unwrap();
    e1.play_card(1, c(Rank::Seven, Suit::Clubs)).unwrap();
    assert_eq!(e1.completed_tricks.last().unwrap().winner, 0);

    // Edge Case B: 7H, 8H, QH played Straight, then 4th player shows Reverse Spades with no Spades -> discards 10D -> QH (seat 0) wins!
    let mut e2 = GameEngine::new("EDGB", cfg.clone());
    e2.config.force_last_bidder_min_bid = false;
    e2.dealer = 1;
    e2.start_hand_with_deck(make_32_deck(
        [
            c(Rank::Queen, Suit::Hearts), c(Rank::Seven, Suit::Clubs), c(Rank::Eight, Suit::Clubs), c(Rank::Nine, Suit::Clubs),
            c(Rank::Ten, Suit::Diamonds), c(Rank::Queen, Suit::Diamonds), c(Rank::King, Suit::Diamonds), c(Rank::Ace, Suit::Diamonds),
            c(Rank::Seven, Suit::Hearts), c(Rank::Nine, Suit::Hearts), c(Rank::Ten, Suit::Hearts), c(Rank::Ace, Suit::Hearts),
            c(Rank::Eight, Suit::Hearts), c(Rank::King, Suit::Hearts), c(Rank::Jack, Suit::Hearts), c(Rank::Seven, Suit::Spades),
        ],
        [
            c(Rank::Ten, Suit::Clubs), c(Rank::Queen, Suit::Clubs), c(Rank::King, Suit::Clubs), c(Rank::Ace, Suit::Clubs),
            c(Rank::Jack, Suit::Clubs), c(Rank::Seven, Suit::Diamonds), c(Rank::Eight, Suit::Diamonds), c(Rank::Nine, Suit::Diamonds),
            c(Rank::Eight, Suit::Spades), c(Rank::Nine, Suit::Spades), c(Rank::Ten, Suit::Spades), c(Rank::Jack, Suit::Spades),
            c(Rank::Queen, Suit::Spades), c(Rank::King, Suit::Spades), c(Rank::Ace, Suit::Spades), c(Rank::Jack, Suit::Diamonds),
        ],
    ));
    e2.pass_bid(2, &mut rng).unwrap();
    e2.pass_bid(3, &mut rng).unwrap();
    e2.pass_bid(0, &mut rng).unwrap();
    e2.place_bid(1, 16).unwrap();
    e2.select_trump(1, Suit::Spades, true).unwrap();

    e2.play_card(2, c(Rank::Seven, Suit::Hearts)).unwrap();
    e2.play_card(3, c(Rank::Eight, Suit::Hearts)).unwrap();
    e2.play_card(0, c(Rank::Queen, Suit::Hearts)).unwrap();
    e2.request_trump_show(1).unwrap();
    e2.play_card(1, c(Rank::Ten, Suit::Diamonds)).unwrap();
    assert_eq!(e2.completed_tricks.last().unwrap().winner, 0);

    // Edge Case C: Led suit IS Reverse trump (Spades); 3rd player void shows Reverse Spades & discards 10D;
    // 4th player plays JS (post-Reverse!) -> Seat 1 takes the trick automatically!
    let mut e3 = GameEngine::new("EDGC", cfg);
    e3.config.force_last_bidder_min_bid = false;
    e3.dealer = 1;
    e3.start_hand_with_deck(make_32_deck(
        [
            c(Rank::Ten, Suit::Diamonds), c(Rank::Seven, Suit::Clubs), c(Rank::Eight, Suit::Clubs), c(Rank::Nine, Suit::Clubs),
            c(Rank::Jack, Suit::Spades), c(Rank::Queen, Suit::Diamonds), c(Rank::King, Suit::Diamonds), c(Rank::Ace, Suit::Diamonds),
            c(Rank::Seven, Suit::Spades), c(Rank::Eight, Suit::Spades), c(Rank::Ten, Suit::Spades), c(Rank::Queen, Suit::Spades),
            c(Rank::Nine, Suit::Spades), c(Rank::King, Suit::Spades), c(Rank::Ace, Suit::Spades), c(Rank::Seven, Suit::Hearts),
        ],
        [
            c(Rank::Ten, Suit::Clubs), c(Rank::Queen, Suit::Clubs), c(Rank::King, Suit::Clubs), c(Rank::Ace, Suit::Clubs),
            c(Rank::Jack, Suit::Clubs), c(Rank::Seven, Suit::Diamonds), c(Rank::Eight, Suit::Diamonds), c(Rank::Nine, Suit::Diamonds),
            c(Rank::Eight, Suit::Hearts), c(Rank::Nine, Suit::Hearts), c(Rank::Ten, Suit::Hearts), c(Rank::Jack, Suit::Hearts),
            c(Rank::Queen, Suit::Hearts), c(Rank::King, Suit::Hearts), c(Rank::Ace, Suit::Hearts), c(Rank::Jack, Suit::Diamonds),
        ],
    ));
    e3.pass_bid(2, &mut rng).unwrap();
    e3.pass_bid(3, &mut rng).unwrap();
    e3.pass_bid(0, &mut rng).unwrap();
    e3.place_bid(1, 16).unwrap();
    e3.select_trump(1, Suit::Spades, true).unwrap();

    e3.play_card(2, c(Rank::Seven, Suit::Spades)).unwrap();
    e3.play_card(3, c(Rank::Nine, Suit::Spades)).unwrap();
    e3.request_trump_show(0).unwrap();
    e3.play_card(0, c(Rank::Ten, Suit::Diamonds)).unwrap();
    e3.play_card(1, c(Rank::Jack, Suit::Spades)).unwrap();
    assert_eq!(e3.completed_tricks.last().unwrap().winner, 1);
}


#[test]
fn marriage_never_lowers_bid_below_minimum_16() {
    let mut cfg = GameConfig::default();
    cfg.allow_doubling = false;
    let mut rng = StdRng::seed_from_u64(99);
    let mut engine = GameEngine::new("MRG1", cfg.clone());
    engine.config.force_last_bidder_min_bid = false;
    engine.dealer = 1;
    engine.start_hand_with_deck(make_32_deck(
        [
            c(Rank::Seven, Suit::Clubs), c(Rank::Eight, Suit::Clubs), c(Rank::Nine, Suit::Clubs), c(Rank::Ten, Suit::Clubs),
            c(Rank::King, Suit::Spades), c(Rank::Queen, Suit::Spades), c(Rank::Jack, Suit::Spades), c(Rank::Nine, Suit::Spades),
            c(Rank::Seven, Suit::Hearts), c(Rank::Eight, Suit::Hearts), c(Rank::Nine, Suit::Hearts), c(Rank::Ten, Suit::Hearts),
            c(Rank::Seven, Suit::Diamonds), c(Rank::Eight, Suit::Diamonds), c(Rank::Nine, Suit::Diamonds), c(Rank::Ten, Suit::Diamonds),
        ],
        [
            c(Rank::Queen, Suit::Clubs), c(Rank::King, Suit::Clubs), c(Rank::Ace, Suit::Clubs), c(Rank::Jack, Suit::Clubs),
            c(Rank::Seven, Suit::Spades), c(Rank::Eight, Suit::Spades), c(Rank::Ten, Suit::Spades), c(Rank::Ace, Suit::Spades),
            c(Rank::Queen, Suit::Hearts), c(Rank::King, Suit::Hearts), c(Rank::Ace, Suit::Hearts), c(Rank::Jack, Suit::Hearts),
            c(Rank::Queen, Suit::Diamonds), c(Rank::King, Suit::Diamonds), c(Rank::Ace, Suit::Diamonds), c(Rank::Jack, Suit::Diamonds),
        ],
    ));
    // Bid 18 -> Marriage reduces by 4, clamped to minimum 16 (not 14!)
    engine.pass_bid(2, &mut rng).unwrap();
    engine.pass_bid(3, &mut rng).unwrap();
    engine.pass_bid(0, &mut rng).unwrap();
    engine.place_bid(1, 18).unwrap();
    engine.select_trump(1, Suit::Spades, false).unwrap();

    // Seat 2 leads 7H; Seat 3 void in Hearts exposes Spades; Seat 0 discards; Seat 1 declares Marriage!
    engine.play_card(2, c(Rank::Seven, Suit::Hearts)).unwrap();
    engine.request_trump_show(3).unwrap();
    engine.play_card(3, c(Rank::Seven, Suit::Diamonds)).unwrap();
    engine.play_card(0, c(Rank::Seven, Suit::Clubs)).unwrap();
    engine.declare_marriage(1, c(Rank::King, Suit::Spades)).unwrap();
    assert_eq!(engine.effective_bid(), Some(16));
}

#[test]
fn last_trick_bonus_point_is_off_by_default_and_works_when_enabled() {
    assert!(!GameConfig::default().last_trick_bonus_point);

    for enabled in [false, true] {
        let mut cfg = GameConfig::default();
        cfg.allow_doubling = false;
        cfg.last_trick_bonus_point = enabled;
        let mut rng = StdRng::seed_from_u64(123);
        let mut engine = GameEngine::new("LTBP", cfg);
        engine.start_hand(&mut rng);
        while engine.phase != GamePhase::HandComplete && engine.phase != GamePhase::MatchComplete {
            let seat = engine.current_turn;
            if let Some(action) = crate::bot::choose_bot_action(&engine, seat) {
                match action {
                    ClientMessage::PlaceBid { amount } => { engine.place_bid(seat, amount).unwrap(); }
                    ClientMessage::PassBid => { engine.pass_bid(seat, &mut rng).unwrap(); }
                    ClientMessage::ChooseSeventhCard => { engine.choose_seventh_card(seat).unwrap(); }
                    ClientMessage::SelectTrump { suit, reverse_enabled, mode } => {
                        engine.select_trump_with_mode(seat, suit, reverse_enabled, mode).unwrap();
                    }
                    ClientMessage::RequestTrumpShow => { engine.request_trump_show(seat).unwrap(); }
                    ClientMessage::DeclareMarriage { card_id } => { engine.declare_marriage(seat, Card::from_id(&card_id).unwrap()).unwrap(); }
                    ClientMessage::PlayCard { card_id } => { engine.play_card(seat, Card::from_id(&card_id).unwrap()).unwrap(); }
                    _ => break,
                }
            } else {
                break;
            }
        }
        let summary = engine.hand_history.last().expect("hand finished");
        let expected_total = if enabled { 29 } else { 28 };
        assert_eq!(summary.bidding_team_points + summary.opposing_team_points, expected_total);
    }
}

#[test]
fn upgraded_bot_ai_plays_50_hands_cleanly_including_joker_and_seventh_card() {
    let mut rng = StdRng::seed_from_u64(424242);
    let mut engine = GameEngine::new("BOT50", GameConfig::default());
    engine.start_hand(&mut rng);
    let mut hands_finished = 0usize;
    let mut steps = 0usize;
    let mut joker_hands = 0usize;
    let mut seventh_hands = 0usize;
    while hands_finished < 50 && steps < 40000 {
        steps += 1;
        match engine.phase {
            GamePhase::HandComplete | GamePhase::MatchComplete => {
                hands_finished += 1;
                if engine.phase == GamePhase::MatchComplete {
                    engine = GameEngine::new("BOT50", GameConfig::default());
                }
                engine.start_hand(&mut rng);
            }
            GamePhase::DoubleWindow => {
                let mut acted = false;
                for s in 0..4usize {
                    if let Some(msg) = crate::bot::choose_bot_action(&engine, s) {
                        match msg {
                            ClientMessage::DoubleStakes => { engine.call_double(s).unwrap(); }
                            ClientMessage::RedoubleStakes => { engine.call_redouble(s).unwrap(); }
                            ClientMessage::PassDoubleWindow => { engine.pass_double_window(s).unwrap(); }
                            _ => panic!("unexpected double msg"),
                        }
                        acted = true;
                        break;
                    }
                }
                assert!(acted, "stuck in DoubleWindow");
            }
            _ => {
                let seat = engine.current_turn;
                let msg = crate::bot::choose_bot_action(&engine, seat)
                    .expect("bot must return action on its turn");
                match msg {
                    ClientMessage::PlaceBid { amount } => { engine.place_bid(seat, amount).unwrap(); }
                    ClientMessage::PassBid => { engine.pass_bid(seat, &mut rng).unwrap(); }
                    ClientMessage::ChooseSeventhCard => {
                        seventh_hands += 1;
                        engine.choose_seventh_card(seat).unwrap();
                    }
                    ClientMessage::SelectTrump { suit, reverse_enabled, mode } => {
                        if mode == crate::protocol::TrumpMode::NoTrump {
                            joker_hands += 1;
                        }
                        engine.select_trump_with_mode(seat, suit, reverse_enabled, mode).unwrap();
                    }
                    ClientMessage::RequestTrumpShow => { engine.request_trump_show(seat).unwrap(); }
                    ClientMessage::DeclareMarriage { card_id } => {
                        engine.declare_marriage(seat, Card::from_id(&card_id).unwrap()).unwrap();
                    }
                    ClientMessage::PlayCard { card_id } => {
                        engine.play_card(seat, Card::from_id(&card_id).unwrap()).unwrap();
                    }
                    other => panic!("unexpected bot action: {:?}", other),
                }
            }
        }
    }
    assert_eq!(hands_finished, 50, "expected 50 completed hands");
    println!("50-hand AI stress test passed! Joker hands: {joker_hands}, 7th-card hands: {seventh_hands}");
}

#[test]
fn simulate_500_hands_ai_telemetry() {
    use std::collections::BTreeMap;
    let mut rng = StdRng::seed_from_u64(202629);
    let mut engine = GameEngine::new("SIM500", GameConfig::default());
    engine.start_hand(&mut rng);

    let mut hands = 0usize;
    let mut matches_completed = 0usize;
    let mut team_a_wins = 0usize;
    let mut team_b_wins = 0usize;

    let mut bid_counts: BTreeMap<u8, (usize, usize)> = BTreeMap::new(); // bid -> (total, made)
    let mut mode_counts: BTreeMap<&'static str, (usize, usize)> = BTreeMap::new();
    let mut total_bid_sum = 0usize;
    let mut total_made = 0usize;
    let mut total_bidder_pts = 0usize;
    let mut total_def_pts = 0usize;

    let mut doubles = 0usize;
    let mut doubles_def_won = 0usize;
    let mut redoubles = 0usize;
    let mut marriages = 0usize;
    let mut trump_exposures = 0usize;
    let mut exposure_trick_sum = 0usize;
    let mut show_trump_pts_sum = 0usize;
    let mut show_trump_zero_pts = 0usize;

    let mut smear_to_opp_blunders = 0usize;
    let mut steps = 0usize;

    while hands < 500 && steps < 400_000 {
        steps += 1;
        match engine.phase {
            GamePhase::HandComplete | GamePhase::MatchComplete => {
                hands += 1;
                if let Some(sum) = engine.hand_history.last() {
                    let bid = sum.bid;
                    let made = sum.winning_team == sum.bidding_team;
                    total_bid_sum += bid as usize;
                    if made {
                        total_made += 1;
                    }
                    total_bidder_pts += sum.bidding_team_points as usize;
                    total_def_pts += sum.opposing_team_points as usize;
                    let e = bid_counts.entry(bid).or_insert((0, 0));
                    e.0 += 1;
                    if made {
                        e.1 += 1;
                    }
                    let mode_label = match (sum.trump_mode, sum.reverse_enabled) {
                        (crate::protocol::TrumpMode::NoTrump, false) => "Joker (Straight)",
                        (crate::protocol::TrumpMode::NoTrump, true) => "Joker (Reverse)",
                        (crate::protocol::TrumpMode::SeventhCard, false) => "7th Card (Straight)",
                        (crate::protocol::TrumpMode::SeventhCard, true) => "7th Card (Reverse)",
                        (crate::protocol::TrumpMode::Suit, false) => "Suit (Straight)",
                        (crate::protocol::TrumpMode::Suit, true) => "Suit (Reverse)",
                    };
                    let me = mode_counts.entry(mode_label).or_insert((0, 0));
                    me.0 += 1;
                    if made {
                        me.1 += 1;
                    }
                    if sum.stakes == StakesLevel::Doubled {
                        doubles += 1;
                        if !made {
                            doubles_def_won += 1;
                        }
                    } else if sum.stakes == StakesLevel::Redoubled {
                        redoubles += 1;
                    }
                    if engine.trump_exposed {
                        trump_exposures += 1;
                    }
                }
                if engine.phase == GamePhase::MatchComplete {
                    matches_completed += 1;
                    if engine.match_score_team_a >= engine.config.target_set_points_to_win_match
                        || engine.match_score_team_b <= -engine.config.target_set_points_to_win_match
                    {
                        team_a_wins += 1;
                    } else {
                        team_b_wins += 1;
                    }
                    engine = GameEngine::new("SIM500", GameConfig::default());
                }
                engine.start_hand(&mut rng);
            }
            GamePhase::DoubleWindow => {
                let mut acted = false;
                for s in 0..4usize {
                    if let Some(msg) = crate::bot::choose_bot_action(&engine, s) {
                        match msg {
                            ClientMessage::DoubleStakes => { engine.call_double(s).unwrap(); }
                            ClientMessage::RedoubleStakes => { engine.call_redouble(s).unwrap(); }
                            ClientMessage::PassDoubleWindow => { engine.pass_double_window(s).unwrap(); }
                            _ => panic!("unexpected double msg"),
                        }
                        acted = true;
                        break;
                    }
                }
                assert!(acted, "stuck in DoubleWindow");
            }
            _ => {
                let seat = engine.current_turn;
                let msg = crate::bot::choose_bot_action(&engine, seat)
                    .expect("bot must return action on its turn");
                match msg {
                    ClientMessage::PlaceBid { amount } => { engine.place_bid(seat, amount).unwrap(); }
                    ClientMessage::PassBid => { engine.pass_bid(seat, &mut rng).unwrap(); }
                    ClientMessage::ChooseSeventhCard => { engine.choose_seventh_card(seat).unwrap(); }
                    ClientMessage::SelectTrump { suit, reverse_enabled, mode } => {
                        engine.select_trump_with_mode(seat, suit, reverse_enabled, mode).unwrap();
                    }
                    ClientMessage::RequestTrumpShow => {
                        let trick_pts: usize = engine.current_trick.iter().map(|p| p.card.points() as usize).sum();
                        show_trump_pts_sum += trick_pts;
                        if trick_pts == 0 {
                            show_trump_zero_pts += 1;
                        }
                        exposure_trick_sum += engine.completed_tricks.len() + 1;
                        engine.request_trump_show(seat).unwrap();
                    }
                    ClientMessage::DeclareMarriage { card_id } => {
                        marriages += 1;
                        engine.declare_marriage(seat, Card::from_id(&card_id).unwrap()).unwrap();
                    }
                    ClientMessage::PlayCard { card_id } => {
                        let card = Card::from_id(&card_id).unwrap();
                        // Blunder check: 4th seat losing trick while dumping points when a 0-pt legal card existed
                        if engine.current_trick.len() == 3 && card.points() > 0 {
                            let view = engine.view_for_seat(seat, None);
                            let has_zero = view.legal_cards.iter().any(|c| c.points() == 0);
                            if has_zero {
                                let before_len = engine.completed_tricks.len();
                                engine.play_card(seat, card).unwrap();
                                if engine.completed_tricks.len() > before_len {
                                    let winner = engine.completed_tricks.last().unwrap().winner;
                                    if Team::of_seat(winner) != Team::of_seat(seat) {
                                        smear_to_opp_blunders += 1;
                                    }
                                }
                                continue;
                            }
                        }
                        engine.play_card(seat, card).unwrap();
                    }
                    other => panic!("unexpected bot action: {:?}", other),
                }
            }
        }
    }

    assert_eq!(hands, 500);
    println!("\n========== 500-HAND AI SIMULATION TELEMETRY ==========");
    println!("Hands Simulated: {} | Full Matches Completed: {} (Team A: {}, Team B: {})",
        hands, matches_completed, team_a_wins, team_b_wins);
    println!("Overall Bidder Make Rate: {}/{} ({:.1}%)", total_made, hands, (total_made as f64 / hands as f64) * 100.0);
    println!("Avg Winning Effective Bid: {:.2} | Avg Bidder Pts: {:.2} | Avg Defender Pts: {:.2}",
        total_bid_sum as f64 / hands as f64,
        total_bidder_pts as f64 / hands as f64,
        total_def_pts as f64 / hands as f64);
    println!("Doubles: {} (Defenders won: {}) | Redoubles: {} | Marriages: {}",
        doubles, doubles_def_won, redoubles, marriages);
    println!("Trump Exposed: {}/{} ({:.1}%) | Avg Trick of Show-Trump: {:.2} | Avg Trick Pts on Show: {:.2} (0-pt shows: {})",
        trump_exposures, hands, (trump_exposures as f64 / hands as f64) * 100.0,
        if trump_exposures > 0 { exposure_trick_sum as f64 / trump_exposures as f64 } else { 0.0 },
        if trump_exposures > 0 { show_trump_pts_sum as f64 / trump_exposures as f64 } else { 0.0 },
        show_trump_zero_pts);
    println!("4th-Seat Point-Dump-to-Opponent Blunders: {}", smear_to_opp_blunders);
    println!("\n--- By Trump Mode ---");
    for (mode, (tot, made)) in &mode_counts {
        println!("  {:22}: {:3} hands ({:4.1}%) | Make rate: {:5.1}%",
            mode, tot, (*tot as f64 / hands as f64) * 100.0, (*made as f64 / (*tot).max(1) as f64) * 100.0);
    }
    println!("\n--- By Effective Bid ---");
    for (bid, (tot, made)) in &bid_counts {
        println!("  Bid {:2}: {:3} hands ({:4.1}%) | Make rate: {:5.1}%",
            bid, tot, (*tot as f64 / hands as f64) * 100.0, (*made as f64 / (*tot).max(1) as f64) * 100.0);
    }
    println!("=====================================================\n");
}

#[test]
fn arena_head_to_head_tournament() {
    fn run_matchup(
        label_a: &str,
        policy_a: fn(&GameEngine, usize) -> Option<ClientMessage>,
        label_b: &str,
        policy_b: fn(&GameEngine, usize) -> Option<ClientMessage>,
        mirrored_deals: usize,
        seed_base: u64,
    ) {
        let mut a_hand_wins = 0usize;
        let mut b_hand_wins = 0usize;
        let mut a_set_pts = 0i64;
        let mut b_set_pts = 0i64;
        let mut a_bids = 0usize;
        let mut a_bids_made = 0usize;
        let mut b_bids = 0usize;
        let mut b_bids_made = 0usize;
        let mut a_matches = 0usize;
        let mut b_matches = 0usize;

        for swap in [false, true] {
            let mut rng = StdRng::seed_from_u64(seed_base);
            let mut engine = GameEngine::new("ARENA", GameConfig::default());
            engine.start_hand(&mut rng);
            let mut done = 0usize;
            let mut steps = 0usize;
            while done < mirrored_deals && steps < 300_000 {
                steps += 1;
                match engine.phase {
                    GamePhase::HandComplete | GamePhase::MatchComplete => {
                        done += 1;
                        if let Some(sum) = engine.hand_history.last() {
                            let a_is_team_a = !swap;
                            let a_won_hand = if a_is_team_a {
                                sum.winning_team == Team::TeamA
                            } else {
                                sum.winning_team == Team::TeamB
                            };
                            if a_won_hand {
                                a_hand_wins += 1;
                            } else {
                                b_hand_wins += 1;
                            }
                            let a_bid_this = if a_is_team_a {
                                sum.bidding_team == Team::TeamA
                            } else {
                                sum.bidding_team == Team::TeamB
                            };
                            let made = sum.winning_team == sum.bidding_team;
                            let delta = sum.set_points_awarded as i64;
                            if a_bid_this {
                                a_bids += 1;
                                if made { a_bids_made += 1; }
                                a_set_pts += delta;
                            } else {
                                b_bids += 1;
                                if made { b_bids_made += 1; }
                                b_set_pts += delta;
                            }
                        }
                        if engine.phase == GamePhase::MatchComplete {
                            let team_a_won_match = engine.match_score_team_a >= engine.config.target_set_points_to_win_match
                                || engine.match_score_team_b <= -engine.config.target_set_points_to_win_match;
                            if (!swap && team_a_won_match) || (swap && !team_a_won_match) {
                                a_matches += 1;
                            } else {
                                b_matches += 1;
                            }
                            engine = GameEngine::new("ARENA", GameConfig::default());
                        }
                        engine.start_hand(&mut rng);
                    }
                    GamePhase::DoubleWindow => {
                        let mut acted = false;
                        for s in 0..4usize {
                            let is_a_seat = (Team::of_seat(s) == Team::TeamA) ^ swap;
                            let act = if is_a_seat { policy_a(&engine, s) } else { policy_b(&engine, s) };
                            if let Some(msg) = act {
                                match msg {
                                    ClientMessage::DoubleStakes => { engine.call_double(s).unwrap(); }
                                    ClientMessage::RedoubleStakes => { engine.call_redouble(s).unwrap(); }
                                    ClientMessage::PassDoubleWindow => { engine.pass_double_window(s).unwrap(); }
                                    _ => panic!("unexpected double msg"),
                                }
                                acted = true;
                                break;
                            }
                        }
                        assert!(acted, "stuck in DoubleWindow");
                    }
                    _ => {
                        let seat = engine.current_turn;
                        let is_a_seat = (Team::of_seat(seat) == Team::TeamA) ^ swap;
                        let msg = if is_a_seat { policy_a(&engine, seat) } else { policy_b(&engine, seat) }
                            .expect("bot must act");
                        match msg {
                            ClientMessage::PlaceBid { amount } => { engine.place_bid(seat, amount).unwrap(); }
                            ClientMessage::PassBid => { engine.pass_bid(seat, &mut rng).unwrap(); }
                            ClientMessage::ChooseSeventhCard => { engine.choose_seventh_card(seat).unwrap(); }
                            ClientMessage::SelectTrump { suit, reverse_enabled, mode } => {
                                engine.select_trump_with_mode(seat, suit, reverse_enabled, mode).unwrap();
                            }
                            ClientMessage::RequestTrumpShow => { engine.request_trump_show(seat).unwrap(); }
                            ClientMessage::DeclareMarriage { card_id } => {
                                engine.declare_marriage(seat, Card::from_id(&card_id).unwrap()).unwrap();
                            }
                            ClientMessage::PlayCard { card_id } => {
                                engine.play_card(seat, Card::from_id(&card_id).unwrap()).unwrap();
                            }
                            other => panic!("unexpected: {:?}", other),
                        }
                    }
                }
            }
        }

        let total = a_hand_wins + b_hand_wins;
        println!("\n===== HEAD-TO-HEAD ARENA: {} vs {} ({} mirrored hands) =====", label_a, label_b, total);
        println!("  {} : {}/{} hands won ({:.1}%) | Net Set Pts: {:+} | Full Matches: {} | Bids Made: {}/{} ({:.1}%)",
            label_a, a_hand_wins, total, (a_hand_wins as f64 / total as f64) * 100.0,
            a_set_pts, a_matches, a_bids_made, a_bids, (a_bids_made as f64 / a_bids.max(1) as f64) * 100.0);
        println!("  {} : {}/{} hands won ({:.1}%) | Net Set Pts: {:+} | Full Matches: {} | Bids Made: {}/{} ({:.1}%)",
            label_b, b_hand_wins, total, (b_hand_wins as f64 / total as f64) * 100.0,
            b_set_pts, b_matches, b_bids_made, b_bids, (b_bids_made as f64 / b_bids.max(1) as f64) * 100.0);
        println!("=========================================================================");
    }

    run_matchup(
        "Hybrid (Calibrated+PIMC)",
        crate::bot::choose_bot_action,
        "Legacy Baseline AI",
        crate::bot::choose_legacy_baseline_action,
        200,
        777001,
    );

    run_matchup(
        "Hybrid (Calibrated+PIMC)",
        crate::bot::choose_bot_action,
        "Calibrated Heuristic-Only",
        crate::bot::choose_calibrated_heuristic_only_action,
        150,
        888002,
    );
}

#[test]
#[ignore]
fn train_20k_hands_bidding_weights() {
    // Solve (X^T X + lambda * I) w = X^T y via Gaussian elimination
    fn ridge_ols(xs: &[Vec<f64>], ys: &[f64], lambda: f64) -> Vec<f64> {
        let d = xs[0].len();
        let mut a = vec![vec![0.0_f64; d + 1]; d];
        for (x, &y) in xs.iter().zip(ys.iter()) {
            for i in 0..d {
                a[i][d] += x[i] * y;
                for j in 0..d {
                    a[i][j] += x[i] * x[j];
                }
            }
        }
        for i in 1..d {
            a[i][i] += lambda;
        }
        // Gaussian elimination with partial pivoting
        for col in 0..d {
            let mut piv = col;
            for r in (col + 1)..d {
                if a[r][col].abs() > a[piv][col].abs() {
                    piv = r;
                }
            }
            a.swap(col, piv);
            let div = a[col][col];
            if div.abs() < 1e-12 { continue; }
            for j in col..=d { a[col][j] /= div; }
            for r in 0..d {
                if r == col { continue; }
                let f = a[r][col];
                for j in col..=d {
                    a[r][j] -= f * a[col][j];
                }
            }
        }
        (0..d).map(|i| a[i][d]).collect()
    }

    let mut rng = StdRng::seed_from_u64(20_000_29);
    let mut straight_x: Vec<Vec<f64>> = Vec::with_capacity(18000);
    let mut straight_y: Vec<f64> = Vec::with_capacity(18000);
    let mut rev_x: Vec<Vec<f64>> = Vec::with_capacity(3000);
    let mut rev_y: Vec<f64> = Vec::with_capacity(3000);
    let mut joker_x: Vec<Vec<f64>> = Vec::with_capacity(2000);
    let mut joker_y: Vec<f64> = Vec::with_capacity(2000);

    let mut hands = 0usize;
    let mut engine = GameEngine::new("TR20K", GameConfig::default());
    engine.start_hand(&mut rng);
    let mut opening_4: [Vec<Card>; 4] = Default::default();
    let mut captured_opening = false;

    while hands < 20_000 {
        if engine.phase == GamePhase::Bidding && !captured_opening {
            for s in 0..4usize {
                opening_4[s] = engine.hands[s].clone();
            }
            captured_opening = true;
        }
        match engine.phase {
            GamePhase::HandComplete | GamePhase::MatchComplete => {
                hands += 1;
                if let Some(sum) = engine.hand_history.last() {
                    let h4 = &opening_4[sum.bidder];
                    let pts = sum.bidding_team_points as f64;
                    match (sum.trump_mode, sum.reverse_enabled, sum.trump_suit) {
                        (crate::protocol::TrumpMode::Suit, false, Some(ts)) => {
                            let sc: Vec<Card> = h4.iter().copied().filter(|c| c.suit == ts).collect();
                            let len = sc.len() as f64;
                            let has_j = if sc.iter().any(|c| c.rank == Rank::Jack) { 1.0 } else { 0.0 };
                            let has_9 = if sc.iter().any(|c| c.rank == Rank::Nine) { 1.0 } else { 0.0 };
                            let has_j9 = has_j * has_9;
                            let has_a = if sc.iter().any(|c| c.rank == Rank::Ace) { 1.0 } else { 0.0 };
                            let has_10 = if sc.iter().any(|c| c.rank == Rank::Ten) { 1.0 } else { 0.0 };
                            let has_kq = if sc.iter().any(|c| c.rank == Rank::King) && sc.iter().any(|c| c.rank == Rank::Queen) { 1.0 } else { 0.0 };
                            let side_j = h4.iter().filter(|c| c.suit != ts && c.rank == Rank::Jack).count() as f64;
                            let side_9 = h4.iter().filter(|c| c.suit != ts && c.rank == Rank::Nine).count() as f64;
                            let side_a = h4.iter().filter(|c| c.suit != ts && c.rank == Rank::Ace).count() as f64;
                            straight_x.push(vec![1.0, (len - 1.0).max(0.0), has_j, has_9, has_j9, has_a, has_10, has_kq, side_j, side_9, side_a]);
                            straight_y.push(pts);
                        }
                        (crate::protocol::TrumpMode::Suit, true, Some(ts)) => {
                            let sc: Vec<Card> = h4.iter().copied().filter(|c| c.suit == ts).collect();
                            let len = sc.len() as f64;
                            let has_7 = if sc.iter().any(|c| c.rank == Rank::Seven) { 1.0 } else { 0.0 };
                            let has_8 = if sc.iter().any(|c| c.rank == Rank::Eight) { 1.0 } else { 0.0 };
                            let has_78 = has_7 * has_8;
                            let has_kq = if sc.iter().any(|c| c.rank == Rank::King) && sc.iter().any(|c| c.rank == Rank::Queen) { 1.0 } else { 0.0 };
                            let side_7 = h4.iter().filter(|c| c.suit != ts && c.rank == Rank::Seven).count() as f64;
                            let side_8 = h4.iter().filter(|c| c.suit != ts && c.rank == Rank::Eight).count() as f64;
                            rev_x.push(vec![1.0, (len - 1.0).max(0.0), has_7, has_8, has_78, has_kq, side_7, side_8]);
                            rev_y.push(pts);
                        }
                        (crate::protocol::TrumpMode::NoTrump, false, _) => {
                            let tj = h4.iter().filter(|c| c.rank == Rank::Jack).count() as f64;
                            let t9 = h4.iter().filter(|c| c.rank == Rank::Nine).count() as f64;
                            let ta = h4.iter().filter(|c| c.rank == Rank::Ace).count() as f64;
                            joker_x.push(vec![1.0, tj, t9, ta]);
                            joker_y.push(pts);
                        }
                        _ => {}
                    }
                }
                if engine.phase == GamePhase::MatchComplete {
                    engine = GameEngine::new("TR20K", GameConfig::default());
                }
                engine.start_hand(&mut rng);
                captured_opening = false;
            }
            GamePhase::DoubleWindow => {
                for s in 0..4usize {
                    if let Some(msg) = crate::bot::choose_calibrated_heuristic_only_action(&engine, s) {
                        match msg {
                            ClientMessage::DoubleStakes => { engine.call_double(s).unwrap(); }
                            ClientMessage::RedoubleStakes => { engine.call_redouble(s).unwrap(); }
                            ClientMessage::PassDoubleWindow => { engine.pass_double_window(s).unwrap(); }
                            _ => {}
                        }
                        break;
                    }
                }
            }
            _ => {
                let seat = engine.current_turn;
                let msg = crate::bot::choose_calibrated_heuristic_only_action(&engine, seat).unwrap();
                match msg {
                    ClientMessage::PlaceBid { amount } => { engine.place_bid(seat, amount).unwrap(); }
                    ClientMessage::PassBid => { engine.pass_bid(seat, &mut rng).unwrap(); }
                    ClientMessage::ChooseSeventhCard => { engine.choose_seventh_card(seat).unwrap(); }
                    ClientMessage::SelectTrump { suit, reverse_enabled, mode } => {
                        engine.select_trump_with_mode(seat, suit, reverse_enabled, mode).unwrap();
                    }
                    ClientMessage::RequestTrumpShow => { engine.request_trump_show(seat).unwrap(); }
                    ClientMessage::DeclareMarriage { card_id } => {
                        engine.declare_marriage(seat, Card::from_id(&card_id).unwrap()).unwrap();
                    }
                    ClientMessage::PlayCard { card_id } => {
                        engine.play_card(seat, Card::from_id(&card_id).unwrap()).unwrap();
                    }
                    _ => {}
                }
            }
        }
    }

    let ws = ridge_ols(&straight_x, &straight_y, 20.0);
    let wr = ridge_ols(&rev_x, &rev_y, 20.0);
    let wj = ridge_ols(&joker_x, &joker_y, 20.0);

    let avg = |v: &[f64]| v.iter().sum::<f64>() / v.len().max(1) as f64;
    println!("\n========== 20,000-HAND SELF-PLAY OLS REGRESSION ==========");
    println!("Straight Suit samples: {} (avg pts: {:.2})", straight_y.len(), avg(&straight_y));
    println!("  [base={:.3}, extra_len={:.3}, J={:.3}, 9={:.3}, J+9={:.3}, A={:.3}, 10={:.3}, K+Q={:.3}, side_J={:.3}, side_9={:.3}, side_A={:.3}]",
        ws[0], ws[1], ws[2], ws[3], ws[4], ws[5], ws[6], ws[7], ws[8], ws[9], ws[10]);
    println!("Reverse Suit samples : {} (avg pts: {:.2})", rev_y.len(), avg(&rev_y));
    println!("  [base={:.3}, extra_len={:.3}, 7={:.3}, 8={:.3}, 7+8={:.3}, K+Q={:.3}, side_7={:.3}, side_8={:.3}]",
        wr[0], wr[1], wr[2], wr[3], wr[4], wr[5], wr[6], wr[7]);
    println!("Joker NT samples     : {} (avg pts: {:.2})", joker_y.len(), avg(&joker_y));
    println!("  [base={:.3}, total_J={:.3}, total_9={:.3}, total_A={:.3}]",
        wj[0], wj[1], wj[2], wj[3]);
    println!("==========================================================\n");
}

#[test]
#[ignore]
fn arena_pro_rl_benchmark() {
    use std::time::Instant;

    fn run_matchup(
        label_a: &str,
        policy_a: fn(&GameEngine, usize) -> Option<ClientMessage>,
        label_b: &str,
        policy_b: fn(&GameEngine, usize) -> Option<ClientMessage>,
        mirrored_deals: usize,
        seed_base: u64,
    ) {
        let t0 = Instant::now();
        let mut a_hand_wins = 0usize;
        let mut b_hand_wins = 0usize;
        let mut a_set_pts = 0i64;
        let mut b_set_pts = 0i64;
        let mut a_bids = 0usize;
        let mut a_bids_made = 0usize;
        let mut b_bids = 0usize;
        let mut b_bids_made = 0usize;
        let mut a_matches = 0usize;
        let mut b_matches = 0usize;
        let mut a_moves = 0usize;

        for swap in [false, true] {
            let mut rng = StdRng::seed_from_u64(seed_base);
            let mut engine = GameEngine::new("PRORL", GameConfig::default());
            engine.start_hand(&mut rng);
            let mut done = 0usize;
            let mut steps = 0usize;
            while done < mirrored_deals && steps < 300_000 {
                steps += 1;
                match engine.phase {
                    GamePhase::HandComplete | GamePhase::MatchComplete => {
                        done += 1;
                        if let Some(sum) = engine.hand_history.last() {
                            let a_is_team_a = !swap;
                            let a_won_hand = if a_is_team_a {
                                sum.winning_team == Team::TeamA
                            } else {
                                sum.winning_team == Team::TeamB
                            };
                            if a_won_hand { a_hand_wins += 1; } else { b_hand_wins += 1; }
                            let a_bid_this = if a_is_team_a {
                                sum.bidding_team == Team::TeamA
                            } else {
                                sum.bidding_team == Team::TeamB
                            };
                            let made = sum.winning_team == sum.bidding_team;
                            let delta = sum.set_points_awarded as i64;
                            if a_bid_this {
                                a_bids += 1;
                                if made { a_bids_made += 1; }
                                a_set_pts += delta;
                            } else {
                                b_bids += 1;
                                if made { b_bids_made += 1; }
                                b_set_pts += delta;
                            }
                        }
                        if engine.phase == GamePhase::MatchComplete {
                            let team_a_won = engine.match_score_team_a >= engine.config.target_set_points_to_win_match
                                || engine.match_score_team_b <= -engine.config.target_set_points_to_win_match;
                            if (!swap && team_a_won) || (swap && !team_a_won) { a_matches += 1; } else { b_matches += 1; }
                            engine = GameEngine::new("PRORL", GameConfig::default());
                        }
                        engine.start_hand(&mut rng);
                    }
                    GamePhase::DoubleWindow => {
                        for s in 0..4usize {
                            let is_a_seat = (Team::of_seat(s) == Team::TeamA) ^ swap;
                            let act = if is_a_seat { policy_a(&engine, s) } else { policy_b(&engine, s) };
                            if let Some(msg) = act {
                                match msg {
                                    ClientMessage::DoubleStakes => { engine.call_double(s).unwrap(); }
                                    ClientMessage::RedoubleStakes => { engine.call_redouble(s).unwrap(); }
                                    ClientMessage::PassDoubleWindow => { engine.pass_double_window(s).unwrap(); }
                                    _ => panic!("unexpected double msg"),
                                }
                                break;
                            }
                        }
                    }
                    _ => {
                        let seat = engine.current_turn;
                        let is_a_seat = (Team::of_seat(seat) == Team::TeamA) ^ swap;
                        if is_a_seat && engine.phase == GamePhase::Playing { a_moves += 1; }
                        let msg = if is_a_seat { policy_a(&engine, seat) } else { policy_b(&engine, seat) }
                            .expect("bot must act");
                        match msg {
                            ClientMessage::PlaceBid { amount } => { engine.place_bid(seat, amount).unwrap(); }
                            ClientMessage::PassBid => { engine.pass_bid(seat, &mut rng).unwrap(); }
                            ClientMessage::ChooseSeventhCard => { engine.choose_seventh_card(seat).unwrap(); }
                            ClientMessage::SelectTrump { suit, reverse_enabled, mode } => {
                                engine.select_trump_with_mode(seat, suit, reverse_enabled, mode).unwrap();
                            }
                            ClientMessage::RequestTrumpShow => { engine.request_trump_show(seat).unwrap(); }
                            ClientMessage::DeclareMarriage { card_id } => {
                                engine.declare_marriage(seat, Card::from_id(&card_id).unwrap()).unwrap();
                            }
                            ClientMessage::PlayCard { card_id } => {
                                engine.play_card(seat, Card::from_id(&card_id).unwrap()).unwrap();
                            }
                            other => panic!("unexpected: {:?}", other),
                        }
                    }
                }
            }
        }
        let elapsed = t0.elapsed().as_secs_f64();
        let total = a_hand_wins + b_hand_wins;
        println!("\n===== PRO RL ARENA: {} vs {} ({} mirrored hands in {:.2}s, ~{:.2} ms/move) =====",
            label_a, label_b, total, elapsed, (elapsed * 1000.0) / a_moves.max(1) as f64);
        println!("  {} : {}/{} hands won ({:.1}%) | Net Set Pts: {:+} | Full Matches: {} | Bids Made: {}/{} ({:.1}%)",
            label_a, a_hand_wins, total, (a_hand_wins as f64 / total as f64) * 100.0,
            a_set_pts, a_matches, a_bids_made, a_bids, (a_bids_made as f64 / a_bids.max(1) as f64) * 100.0);
        println!("  {} : {}/{} hands won ({:.1}%) | Net Set Pts: {:+} | Full Matches: {} | Bids Made: {}/{} ({:.1}%)",
            label_b, b_hand_wins, total, (b_hand_wins as f64 / total as f64) * 100.0,
            b_set_pts, b_matches, b_bids_made, b_bids, (b_bids_made as f64 / b_bids.max(1) as f64) * 100.0);
        println!("=========================================================================");
    }

    run_matchup(
        "Pro RL (Neural+PIMC)",
        crate::rl_pro::choose_pro_rl_action,
        "Current Normal (20k+PIMC)",
        crate::bot::choose_bot_action,
        150,
        555001,
    );

    run_matchup(
        "Pro RL (Neural+48-PIMC)",
        crate::rl_pro::choose_pro_rl_action,
        "Normal (20k Heuristic)",
        crate::bot::choose_calibrated_heuristic_only_action,
        150,
        555003,
    );

    run_matchup(
        "Pro RL (Neural+PIMC)",
        crate::rl_pro::choose_pro_rl_action,
        "Legacy Baseline AI",
        crate::bot::choose_legacy_baseline_action,
        100,
        555002,
    );
}

#[test]
fn clockwise_rotation_first_bidder_leads_trick_one() {
    let mut rng = StdRng::seed_from_u64(4242);
    let mut cfg = GameConfig::default();
    cfg.allow_doubling = false;
    let mut engine = GameEngine::new("ROTN", cfg);

    for hand_idx in 0..4usize {
        engine.start_hand(&mut rng);
        assert_eq!(engine.dealer, hand_idx);
        let first_bidder = (hand_idx + 1) % 4;
        assert_eq!(engine.current_turn, first_bidder);

        // Have a DIFFERENT seat (two seats clockwise from first_bidder) win the bid
        let bid_winner = (first_bidder + 2) % 4;
        engine.pass_bid(first_bidder, &mut rng).unwrap();
        engine.pass_bid((first_bidder + 1) % 4, &mut rng).unwrap();
        engine.place_bid(bid_winner, 17).unwrap();
        engine.pass_bid((first_bidder + 3) % 4, &mut rng).unwrap();

        assert_eq!(engine.phase, GamePhase::SelectTrump);
        assert_eq!(engine.current_turn, bid_winner);
        engine.select_trump(bid_winner, Suit::Spades, false).unwrap();

        // First card of Trick 1 MUST be led by first_bidder (not bid_winner + 1!)
        assert_eq!(engine.phase, GamePhase::Playing);
        assert_eq!(engine.current_trick_leader, Some(first_bidder));
        assert_eq!(engine.current_turn, first_bidder);
    }
}

#[test]
#[ignore]
fn simulate_reverse_opening_lead_calibration() {
    use crate::bot::choose_bot_action;
    use crate::cards::{shuffled_deck, Suit, Rank};

    let mut rng = StdRng::seed_from_u64(20261126);
    let n_deals = 6000usize; // 6,000 deals x 4 paired playouts = 24,000 full 8-trick hands!

    // Helper: play a single 32-card deal from SelectTrump with fixed bidder=1, given dealer (0 => seat 1 leads; 3 => seat 0 opponent leads),
    // given trump suit and reverse flag, returning bidder team's points (0..28).
    let play_one = |deck: &[Card], dealer: usize, suit: Suit, rev: bool, r: &mut StdRng| -> f64 {
        let mut cfg = GameConfig::default();
        cfg.allow_doubling = false;
        cfg.force_last_bidder_min_bid = false;
        let mut e = GameEngine::new("RSIM", cfg);
        e.dealer = dealer;
        e.start_hand_with_deck(deck.to_vec());
        // Force seat 1 to win bid at 16 cleanly regardless of dealer
        let start = (dealer + 1) % 4;
        for step in 0..4 {
            let s = (start + step) % 4;
            if s == 1 {
                e.place_bid(1, 16).unwrap();
            } else {
                e.pass_bid(s, r).unwrap();
            }
        }
        if e.phase == GamePhase::Bidding {
            // Remaining seats pass
            for _ in 0..4 {
                if e.phase != GamePhase::Bidding { break; }
                let t = e.current_turn;
                if t != 1 { e.pass_bid(t, r).unwrap(); }
            }
        }
        e.select_trump(1, suit, rev).unwrap();
        let mut guard = 0;
        while e.phase == GamePhase::Playing && guard < 80 {
            guard += 1;
            let s = e.current_turn;
            if let Some(msg) = choose_bot_action(&e, s) {
                match msg {
                    ClientMessage::RequestTrumpShow => { let _ = e.request_trump_show(s); }
                    ClientMessage::DeclareMarriage { card_id } => {
                        if let Some(c) = e.authoritative_hand(s).iter().copied().find(|c| c.id() == card_id) {
                            let _ = e.declare_marriage(s, c);
                        }
                    }
                    ClientMessage::PlayCard { card_id } => {
                        if let Some(c) = e.authoritative_hand(s).iter().copied().find(|c| c.id() == card_id) {
                            let _ = e.play_card(s, c);
                        }
                    }
                    _ => {}
                }
            } else {
                break;
            }
        }
        e.hand_points_team_b as f64 // seat 1 is TeamB
    };

    // Buckets by (is_opening_leader, high_total, has_78_pair, trump_len >= 3)
    // Plus collect OLS features to predict (pts_rev - pts_str):
    // x = [1.0, is_lead, trump_len, has_7, has_8, has_78, side_78, j_cnt, n9_cnt, non_trump_j9]
    const D: usize = 10;
    let mut xtx = [[0.0_f64; D]; D];
    let mut xty = [0.0_f64; D];
    let mut n_samples = 0usize;

    let mut sum_str_lead = 0.0; let mut sum_rev_lead = 0.0;
    let mut sum_str_nolead = 0.0; let mut sum_rev_nolead = 0.0;
    let mut n_cand = 0usize;

    // Detailed buckets: [0]=0 J/9 & 7+8 pair, [1]=0 J/9 & len>=3 (no 7+8), [2]=1 non-trump J/9 & 7+8 pair, [3]=1+ J/9 general
    let mut b_cnt = [0usize; 4];
    let mut b_diff_lead = [0.0_f64; 4];
    let mut b_diff_nolead = [0.0_f64; 4];
    let mut b_rev_lead = [0.0_f64; 4];
    let mut b_rev_nolead = [0.0_f64; 4];

    for _ in 0..n_deals {
        let deck = shuffled_deck(&mut rng);
        // Seat 1's first 4 cards are indices 4..8 in deck
        let h4 = &deck[4..8];

        // Pick best Reverse candidate suit from h4 (must have a 7 or 8)
        let mut best_suit = None;
        let mut best_r = -1i32;
        for &s in &Suit::ALL {
            let cnt = h4.iter().filter(|c| c.suit == s).count() as i32;
            let h7 = h4.iter().any(|c| c.suit == s && c.rank == Rank::Seven);
            let h8 = h4.iter().any(|c| c.suit == s && c.rank == Rank::Eight);
            if !h7 && !h8 { continue; }
            let sc = cnt * 10 + if h7 { 5 } else { 0 } + if h8 { 3 } else { 0 };
            if sc > best_r {
                best_r = sc;
                best_suit = Some(s);
            }
        }
        let Some(suit) = best_suit else { continue; };

        let t_len = h4.iter().filter(|c| c.suit == suit).count() as f64;
        let has_7 = if h4.iter().any(|c| c.suit == suit && c.rank == Rank::Seven) { 1.0 } else { 0.0 };
        let has_8 = if h4.iter().any(|c| c.suit == suit && c.rank == Rank::Eight) { 1.0 } else { 0.0 };
        let has_78 = if has_7 > 0.5 && has_8 > 0.5 { 1.0 } else { 0.0 };
        let side_78 = h4.iter().filter(|c| c.suit != suit && matches!(c.rank, Rank::Seven | Rank::Eight)).count() as f64;
        let j_cnt = h4.iter().filter(|c| c.rank == Rank::Jack).count() as f64;
        let n9_cnt = h4.iter().filter(|c| c.rank == Rank::Nine).count() as f64;
        let nt_j9 = h4.iter().filter(|c| c.suit != suit && matches!(c.rank, Rank::Jack | Rank::Nine)).count() as f64;

        // Play all 4 paired scenarios on the EXACT same 32-card deal!
        let p_str_lead   = play_one(&deck, 0, suit, false, &mut rng); // dealer=0 => seat 1 leads!
        let p_rev_lead   = play_one(&deck, 0, suit, true,  &mut rng);
        let p_str_nolead = play_one(&deck, 3, suit, false, &mut rng); // dealer=3 => seat 0 (opponent) leads!
        let p_rev_nolead = play_one(&deck, 3, suit, true,  &mut rng);

        n_cand += 1;
        sum_str_lead += p_str_lead;
        sum_rev_lead += p_rev_lead;
        sum_str_nolead += p_str_nolead;
        sum_rev_nolead += p_rev_nolead;

        let high_tot = (j_cnt + n9_cnt) as usize;
        let b = if high_tot == 0 && has_78 > 0.5 {
            0
        } else if high_tot == 0 && t_len >= 3.0 {
            1
        } else if high_tot == 1 && nt_j9 >= 1.0 && has_78 > 0.5 {
            2
        } else {
            3
        };
        b_cnt[b] += 1;
        b_diff_lead[b] += p_rev_lead - p_str_lead;
        b_diff_nolead[b] += p_rev_nolead - p_str_nolead;
        b_rev_lead[b] += p_rev_lead;
        b_rev_nolead[b] += p_rev_nolead;

        for &(is_lead, diff) in &[(1.0, p_rev_lead - p_str_lead), (0.0, p_rev_nolead - p_str_nolead)] {
            let x = [1.0, is_lead, t_len, has_7, has_8, has_78, side_78, j_cnt, n9_cnt, nt_j9];
            for i in 0..D {
                xty[i] += x[i] * diff;
                for j in 0..D {
                    xtx[i][j] += x[i] * x[j];
                }
            }
            n_samples += 1;
        }
    }

    // Solve Ridge OLS (lambda = 10.0 on non-intercept)
    for i in 1..D { xtx[i][i] += 10.0; }
    let mut aug = [[0.0_f64; D + 1]; D];
    for i in 0..D {
        for j in 0..D { aug[i][j] = xtx[i][j]; }
        aug[i][D] = xty[i];
    }
    for i in 0..D {
        let mut piv = i;
        for r in (i + 1)..D {
            if aug[r][i].abs() > aug[piv][i].abs() { piv = r; }
        }
        aug.swap(i, piv);
        let div = aug[i][i];
        for c in i..=D { aug[i][c] /= div; }
        for r in 0..D {
            if r == i { continue; }
            let f = aug[r][i];
            for c in i..=D { aug[r][c] -= f * aug[i][c]; }
        }
    }
    let w: Vec<f64> = (0..D).map(|i| aug[i][D]).collect();

    println!("\n=== PAIRED REVERSE vs STRAIGHT SIMULATION ({} deals, {} total hands) ===", n_cand, n_cand * 4);
    println!("Overall (Opening Leader):     Straight={:.2} pts, Reverse={:.2} pts, Diff(Rev-Str)={:+.2} pts",
        sum_str_lead / n_cand as f64, sum_rev_lead / n_cand as f64, (sum_rev_lead - sum_str_lead) / n_cand as f64);
    println!("Overall (Opponent Leads):     Straight={:.2} pts, Reverse={:.2} pts, Diff(Rev-Str)={:+.2} pts",
        sum_str_nolead / n_cand as f64, sum_rev_nolead / n_cand as f64, (sum_rev_nolead - sum_str_nolead) / n_cand as f64);

    let names = [
        "0 J/9 + 7&8 trump pair",
        "0 J/9 + 3+ trump (no 7&8)",
        "1 non-trump J/9 + 7&8 pair",
        "Other (1+ J/9 or weak rev)",
    ];
    println!("\n--- By Hand Bucket (Rev - Str expected points) ---");
    for b in 0..4 {
        if b_cnt[b] == 0 { continue; }
        let n = b_cnt[b] as f64;
        println!("  {:28} (n={:4}): Lead Diff={:+.2} (Rev={:.2}) | OppLead Diff={:+.2} (Rev={:.2}) | LeadEdge={:+.2}",
            names[b], b_cnt[b],
            b_diff_lead[b] / n, b_rev_lead[b] / n,
            b_diff_nolead[b] / n, b_rev_nolead[b] / n,
            (b_diff_lead[b] - b_diff_nolead[b]) / n);
    }

    let fnames = ["intercept", "is_opening_leader", "trump_len", "has_7", "has_8", "has_78", "side_78", "j_cnt", "n9_cnt", "non_trump_j9"];
    println!("\n--- Ridge OLS Weights Predicting E[pts_Reverse - pts_Straight] (n={}) ---", n_samples);
    for (name, val) in fnames.iter().zip(w.iter()) {
        println!("  {:18}: {:+.4}", name, val);
    }
}

#[test]
fn deal_never_gives_single_player_all_four_jacks() {
    let mut rng = StdRng::seed_from_u64(20261126);
    let mut cfg = GameConfig::default();
    assert!(cfg.no_four_jacks_deal);
    cfg.allow_doubling = false;
    let mut engine = GameEngine::new("NO4J", cfg);

    for _ in 0..5000 {
        engine.start_hand(&mut rng);
        // Check all 4 players' complete 8-card hands (4 dealt + 4 in deck_remainder)
        for s in 0..4usize {
            let j1 = engine.authoritative_hand(s).iter().filter(|c| c.rank == Rank::Jack).count();
            let j2 = engine.deck_remainder()[s * 4..s * 4 + 4].iter().filter(|c| c.rank == Rank::Jack).count();
            assert!(j1 + j2 < 4, "Seat {} was dealt all 4 Jacks!", s);
        }
    }
}
