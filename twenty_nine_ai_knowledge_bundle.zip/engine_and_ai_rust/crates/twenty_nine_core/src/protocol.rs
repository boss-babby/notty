use crate::cards::{Card, Rank, Suit};
use crate::config::{GameConfig, TrumpExposeTrigger};
use serde::{Deserialize, Serialize};

/// Seat index around the table (0..3).
/// Team A = seats 0 & 2 (1-indexed: seats 1 & 3).
/// Team B = seats 1 & 3 (1-indexed: seats 2 & 4).
pub type SeatIndex = usize;

/// Partnership team.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Team {
    TeamA,
    TeamB,
}

impl Team {
    pub const fn of_seat(seat: SeatIndex) -> Self {
        if seat % 2 == 0 {
            Team::TeamA
        } else {
            Team::TeamB
        }
    }

    pub const fn opponent(self) -> Self {
        match self {
            Team::TeamA => Team::TeamB,
            Team::TeamB => Team::TeamA,
        }
    }

    pub const fn label(self) -> &'static str {
        match self {
            Team::TeamA => "Team A",
            Team::TeamB => "Team B",
        }
    }
}

/// High-level phase of a room / hand.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum GamePhase {
    Lobby,
    Bidding,
    SelectTrump,
    /// Strictly between trump selection and the 2nd 4-card deal (Section 2.3.5).
    DoubleWindow,
    Playing,
    HandComplete,
    MatchComplete,
}

/// How the bidder chose trump for the current hand.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub enum TrumpMode {
    /// Standard single-suit trump chosen from the 4 suits.
    #[default]
    Suit,
    /// No Trump ("Joker") - no suit can cut; tricks are won strictly by the led suit.
    NoTrump,
    /// 7th Card Trump - bidder commits to their 7th dealt card's suit; the 7th card stays
    /// face-down beside their hand until trump is exposed, then returns privately to their hand.
    SeventhCard,
}

/// Stakes multiplier for the current hand.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum StakesLevel {
    Normal,
    Doubled,
    Redoubled,
}

impl StakesLevel {
    pub const fn multiplier(self) -> i32 {
        match self {
            StakesLevel::Normal => 1,
            StakesLevel::Doubled => 2,
            StakesLevel::Redoubled => 4,
        }
    }
}

/// Public seat information visible to all clients.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PublicSeatInfo {
    pub seat: SeatIndex,
    pub player_id: Option<String>,
    pub name: String,
    pub team: Team,
    pub is_bot: bool,
    pub connected: bool,
    pub ready: bool,
    pub card_count: usize,
}

/// A single bid or pass action in the current hand's bid log.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BidEntry {
    pub seat: SeatIndex,
    pub amount: Option<u8>, // None = Pass
}

/// A single card played in a trick.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TrickPlay {
    pub seat: SeatIndex,
    pub card: Card,
}

/// Record of a completed trick.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CompletedTrick {
    pub trick_number: u8,
    pub leader: SeatIndex,
    pub plays: Vec<TrickPlay>,
    pub winner: SeatIndex,
    pub points: u8,
}

/// Summary of a completed hand for match history and persistence.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct HandSummary {
    pub hand_number: u32,
    pub dealer: SeatIndex,
    pub bidder: SeatIndex,
    pub bidding_team: Team,
    pub bid: u8,
    pub trump_suit: Option<Suit>,
    #[serde(default)]
    pub trump_mode: TrumpMode,
    pub reverse_enabled: bool,
    pub trump_exposed: bool,
    pub exposure_trigger: Option<TrumpExposeTrigger>,
    pub reverse_activated: bool,
    pub marriage_declared_by: Option<SeatIndex>,
    pub stakes: StakesLevel,
    pub bidding_team_points: u8,
    pub opposing_team_points: u8,
    pub last_trick_winner_team: Team,
    pub clean_sweep: bool,
    pub winning_team: Team,
    pub set_points_awarded: i32,
    pub match_score_team_a: i32,
    pub match_score_team_b: i32,
}

/// Full authorized state snapshot sent to a specific player (never leaks hidden cards or hidden trump).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PlayerView {
    pub room_id: String,
    pub config: GameConfig,
    pub phase: GamePhase,
    pub your_seat: SeatIndex,
    pub your_hand: Vec<Card>,
    pub legal_cards: Vec<Card>,
    pub can_request_trump_show: bool,
    pub must_play_trump: bool,
    pub can_declare_no_points_reshuffle: bool,
    pub marriage_cards: Vec<Card>,
    pub seats: [PublicSeatInfo; 4],
    pub dealer: SeatIndex,
    pub hand_number: u32,
    pub current_turn: SeatIndex,
    pub bid_history: Vec<BidEntry>,
    pub current_high_bid: Option<u8>,
    /// Bid adjusted by Marriage (-4 if bidding team declared, +4 if opposing team declared).
    pub effective_bid: Option<u8>,
    pub current_high_bidder: Option<SeatIndex>,
    pub passed_bidding: [bool; 4],
    /// Only populated if trump is publicly exposed, OR if this player is the Bidder!
    pub visible_trump: Option<Suit>,
    /// Visible trump mode (Suit, NoTrump/Joker, SeventhCard) to bidder or once exposed.
    #[serde(default)]
    pub visible_trump_mode: Option<TrumpMode>,
    /// True during SelectTrump after the bidder has clicked "7th Card" and peeked at it.
    #[serde(default)]
    pub seventh_card_committed: bool,
    /// The bidder's 7th card shown ONLY to the bidder during SelectTrump after committing to 7th Card.
    #[serde(default)]
    pub seventh_card_preview: Option<Card>,
    /// True for the bidder while their 7th card is set aside face-down beside their hand.
    #[serde(default)]
    pub seventh_card_held_face_down: bool,
    /// True only once trump is publicly exposed to all players.
    pub trump_exposed: bool,
    pub exposure_trigger: Option<TrumpExposeTrigger>,
    /// Only visible to the Bidder before exposure, or to all once exposed.
    pub reverse_choice_visible: Option<bool>,
    /// True ONLY when both gates are satisfied (reverse_enabled && trump_exposed).
    pub reverse_active: bool,
    pub current_rank_order: [Rank; 8],
    pub stakes: StakesLevel,
    pub can_double: bool,
    pub can_redouble: bool,
    pub can_pass_double: bool,
    pub current_trick_leader: Option<SeatIndex>,
    pub current_trick: Vec<TrickPlay>,
    pub last_completed_trick: Option<CompletedTrick>,
    pub tricks_won_team_a: u8,
    pub tricks_won_team_b: u8,
    pub hand_points_team_a: u8,
    pub hand_points_team_b: u8,
    pub marriage_declared_by: Option<SeatIndex>,
    pub match_score_team_a: i32,
    pub match_score_team_b: i32,
    pub last_hand_summary: Option<HandSummary>,
    pub hand_history: Vec<HandSummary>,
    pub match_winner: Option<Team>,
    pub turn_seconds_remaining: Option<u32>,
}

/// Client -> Server WebSocket messages (Section 3.4).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ClientMessage {
    JoinRoom {
        #[serde(rename = "roomId")]
        room_id: String,
        #[serde(rename = "playerId")]
        player_id: String,
        #[serde(rename = "playerName")]
        player_name: String,
    },
    SetReady {
        ready: bool,
    },
    AddBotsAndStart,
    PlaceBid {
        amount: u8,
    },
    PassBid,
    /// Bidder commits to 7th-card trump during SelectTrump to peek at their 7th card.
    ChooseSeventhCard,
    SelectTrump {
        #[serde(default)]
        suit: Option<Suit>,
        #[serde(rename = "reverseEnabled", default)]
        reverse_enabled: bool,
        #[serde(default)]
        mode: TrumpMode,
    },
    DoubleStakes,
    RedoubleStakes,
    PassDoubleWindow,
    PlayCard {
        #[serde(rename = "cardId")]
        card_id: String,
    },
    RequestTrumpShow,
    DeclareMarriage {
        #[serde(rename = "cardId")]
        card_id: String,
    },
    DeclareNoPointsReshuffle,
    NextHand,
    Chat {
        text: String,
    },
}

/// Server -> Client WebSocket messages (Section 3.4).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ServerMessage {
    /// Complete resync / initial state snapshot (authorized per player).
    StateSync {
        view: Box<PlayerView>,
    },
    RoomState {
        seats: [PublicSeatInfo; 4],
        dealer: SeatIndex,
        phase: GamePhase,
    },
    YourHand {
        cards: Vec<Card>,
    },
    BidUpdate {
        seat: SeatIndex,
        amount: Option<u8>,
        #[serde(rename = "currentHighBid")]
        current_high_bid: Option<u8>,
    },
    BiddingComplete {
        bidder: SeatIndex,
        bid: u8,
    },
    StakesUpdated {
        stakes: StakesLevel,
        #[serde(rename = "bySeat")]
        by_seat: SeatIndex,
    },
    TrumpExposed {
        suit: Option<Suit>,
        #[serde(default)]
        mode: TrumpMode,
        trigger: TrumpExposeTrigger,
        #[serde(rename = "reverseActivated")]
        reverse_activated: bool,
    },
    MarriageDeclared {
        seat: SeatIndex,
        team: Team,
        #[serde(rename = "bonusPoints")]
        bonus_points: u8,
    },
    TrickUpdate {
        plays: Vec<TrickPlay>,
        leader: SeatIndex,
    },
    TrickResolved {
        #[serde(rename = "winnerSeat")]
        winner_seat: SeatIndex,
        points: u8,
    },
    HandComplete {
        summary: HandSummary,
    },
    MatchComplete {
        #[serde(rename = "winningTeam")]
        winning_team: Team,
        #[serde(rename = "matchScoreTeamA")]
        match_score_team_a: i32,
        #[serde(rename = "matchScoreTeamB")]
        match_score_team_b: i32,
    },
    ChatBroadcast {
        seat: SeatIndex,
        sender: String,
        text: String,
    },
    NoPointsReshuffle {
        seat: SeatIndex,
        #[serde(rename = "playerName")]
        player_name: String,
    },
    Error {
        code: String,
        message: String,
    },
}
