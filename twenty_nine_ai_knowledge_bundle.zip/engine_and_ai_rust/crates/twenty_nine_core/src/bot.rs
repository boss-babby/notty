use crate::cards::{Card, Rank, Suit, NORMAL_RANK_ORDER, REVERSED_RANK_ORDER};
use crate::engine::GameEngine;
use crate::protocol::{
    ClientMessage, GamePhase, SeatIndex, StakesLevel, Team, TrickPlay, TrumpMode,
};
use std::collections::HashSet;

/// Human-like Hybrid AI for 29:
/// 1) Calibrated expected-points bidding & realistic Suit / Joker / 7th-Card / Reverse selection
/// 2) Card-counting, void-tracking, partnership-aware heuristics
/// 3) Fast Imperfect-Information Monte Carlo Lookahead (PIMC) for multi-trick endgames (tricks 3..8)
/// Primary bot entry point: automatically dispatches to Pro RL v2 when `engine.config.pro_bot_ai` is true,
/// or Normal (20k-trained human heuristic) when false.
pub fn choose_bot_action(engine: &GameEngine, seat: SeatIndex) -> Option<ClientMessage> {
    if engine.config.pro_bot_ai {
        crate::rl_pro::choose_pro_rl_action(engine, seat)
    } else {
        choose_normal_bot_action(engine, seat)
    }
}

/// Normal difficulty bot: 20k-trained bidding/trump + void-aware human heuristics (~0.05 ms/move).
pub(crate) fn choose_normal_bot_action(engine: &GameEngine, seat: SeatIndex) -> Option<ClientMessage> {
    let view = engine.view_for_seat(seat, None);
    match view.phase {
        GamePhase::Bidding if view.current_turn == seat => Some(decide_bid(engine, seat)),
        GamePhase::SelectTrump if view.current_turn == seat => Some(decide_trump(engine, seat)),
        GamePhase::DoubleWindow => decide_double(engine, seat),
        GamePhase::Playing if view.current_turn == seat => decide_play_heuristic(engine, seat),
        _ => None,
    }
}

/// Hybrid bot (20k-trained bidding + 24-world PIMC) kept for internal benchmarks.
#[allow(dead_code)]
pub fn choose_hybrid_bot_action(engine: &GameEngine, seat: SeatIndex) -> Option<ClientMessage> {
    let view = engine.view_for_seat(seat, None);
    match view.phase {
        GamePhase::Bidding if view.current_turn == seat => Some(decide_bid(engine, seat)),
        GamePhase::SelectTrump if view.current_turn == seat => Some(decide_trump(engine, seat)),
        GamePhase::DoubleWindow => decide_double(engine, seat),
        GamePhase::Playing if view.current_turn == seat => decide_play_pimc(engine, seat),
        _ => None,
    }
}

/// Fast heuristic-only policy (also used inside PIMC rollouts).
fn choose_fast_play_action(engine: &GameEngine, seat: SeatIndex) -> Option<ClientMessage> {
    let view = engine.view_for_seat(seat, None);
    if view.phase == GamePhase::Playing && view.current_turn == seat {
        decide_play_heuristic(engine, seat)
    } else {
        None
    }
}

/// Tiny zero-allocation deterministic SplitMix64 PRNG for PIMC world sampling.
struct FastRng(u64);
impl FastRng {
    fn new(seed: u64) -> Self {
        Self(seed.wrapping_add(0x9E37_79B9_7F4A_7C15))
    }
    #[inline]
    fn next_u64(&mut self) -> u64 {
        self.0 = self.0.wrapping_add(0x9E37_79B9_7F4A_7C15);
        let mut z = self.0;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        z ^ (z >> 31)
    }
    #[inline]
    fn shuffle<T>(&mut self, slice: &mut [T]) {
        let len = slice.len();
        for i in (1..len).rev() {
            let j = (self.next_u64() as usize) % (i + 1);
            slice.swap(i, j);
        }
    }
}

/// Empirically trained 4-card expected-points model fitted via Ridge OLS on 20,000 self-play hands:
/// - Straight Suit (n=16,001): base=13.19, extra_len=+1.30, J=+1.77, 9=+1.03, J+9=+0.23, A=+0.69, 10=+0.31, side_J=+1.71, side_9=+0.33
/// - Reverse Suit  (n=2,020) : base=11.86, extra_len=+2.29, 7=+1.09, 7+8=+0.93, side_7=+0.89, side_8=+0.71
/// - Joker NoTrump (n=1,357) : base=13.65, total_J=+2.01, total_9=+0.75
/// Plus effective Marriage (-4 target, floored at 16) bonus when holding K+Q of trump.
fn evaluate_4card_bidding_strength(hand: &[Card], allow_reverse: bool) -> f32 {
    let mut best_est = 13.5_f32;

    for suit in Suit::ALL {
        let suit_cards: Vec<Card> = hand.iter().copied().filter(|c| c.suit == suit).collect();
        let count = suit_cards.len() as f32;
        if count == 0.0 {
            continue;
        }
        let extra_len = (count - 1.0).max(0.0);
        let has_j = suit_cards.iter().any(|c| c.rank == Rank::Jack);
        let has_9 = suit_cards.iter().any(|c| c.rank == Rank::Nine);
        let has_a = suit_cards.iter().any(|c| c.rank == Rank::Ace);
        let has_10 = suit_cards.iter().any(|c| c.rank == Rank::Ten);
        let has_k = suit_cards.iter().any(|c| c.rank == Rank::King);
        let has_q = suit_cards.iter().any(|c| c.rank == Rank::Queen);

        let side_j = hand
            .iter()
            .filter(|c| c.suit != suit && c.rank == Rank::Jack)
            .count() as f32;
        let side_9 = hand
            .iter()
            .filter(|c| c.suit != suit && c.rank == Rank::Nine)
            .count() as f32;

        // 20k-trained Straight expected points (minus 0.35 safety margin for ~58-62% make rate)
        let mut straight = 12.85 + extra_len * 1.30;
        if has_j { straight += 1.77; }
        if has_9 { straight += 1.03; }
        if has_j && has_9 { straight += 0.23; }
        if has_a { straight += 0.69; }
        if has_10 { straight += 0.31; }
        straight += side_j * 1.71 + side_9 * 0.33;
        // Marriage lowers effective bid by up to 4 (clamped at 16), adding ~1.6 effective bid value
        if has_k && has_q {
            straight += 1.60;
        }

        // 20k-trained Reverse expected points (only viable with 0 J/9 and real Reverse trump length)
        let mut reverse = 0.0_f32;
        if allow_reverse {
            let has_7 = suit_cards.iter().any(|c| c.rank == Rank::Seven);
            let has_8 = suit_cards.iter().any(|c| c.rank == Rank::Eight);
            let high_total = hand
                .iter()
                .filter(|c| matches!(c.rank, Rank::Jack | Rank::Nine))
                .count();
            if (has_7 || has_8) && high_total == 0 && (count >= 3.0 || (has_7 && has_8)) {
                let side_7 = hand
                    .iter()
                    .filter(|c| c.suit != suit && c.rank == Rank::Seven)
                    .count() as f32;
                let side_8 = hand
                    .iter()
                    .filter(|c| c.suit != suit && c.rank == Rank::Eight)
                    .count() as f32;
                reverse = 11.55 + extra_len * 2.29;
                if has_7 { reverse += 1.09; }
                if has_7 && has_8 { reverse += 0.93; }
                reverse += side_7 * 0.89 + side_8 * 0.71;
                if has_k && has_q {
                    reverse += 1.60;
                }
            }
        }

        let total = straight.max(reverse);
        if total > best_est {
            best_est = total;
        }
    }

    // 20k-trained Joker (No-Trump) expected points (minus 0.45 margin for variance)
    let total_j = hand.iter().filter(|c| c.rank == Rank::Jack).count() as f32;
    let total_9 = hand.iter().filter(|c| c.rank == Rank::Nine).count() as f32;
    if total_j >= 2.0 || (total_j >= 1.0 && total_9 >= 2.0) {
        let nt_est = 13.20 + total_j * 2.01 + total_9 * 0.75;
        best_est = best_est.max(nt_est);
    }

    best_est.clamp(14.5, 23.0)
}

fn decide_bid(engine: &GameEngine, seat: SeatIndex) -> ClientMessage {
    let view = engine.view_for_seat(seat, None);
    let est = evaluate_4card_bidding_strength(
        &view.your_hand,
        view.config.allow_reverse_rule_option,
    );

    // Slight natural human feel: small deterministic +/-0.35 variance per hand/seat so bots aren't robotic
    let mut rng = FastRng::new((view.hand_number as u64) * 31 + (seat as u64) * 997);
    let jitter = (((rng.next_u64() % 71) as f32) / 100.0) - 0.35;
    let max_willing = ((est + jitter).round() as u8).clamp(15, view.config.max_bid);

    let next_bid = match view.current_high_bid {
        None => view.config.starting_bid,
        Some(h) => h + 1,
    };

    let partner_winning = view
        .current_high_bidder
        .map(|b| Team::of_seat(b) == Team::of_seat(seat))
        .unwrap_or(false);

    // Respect partner's bid unless we hold a genuinely superior hand (+2 higher)
    if partner_winning && max_willing < next_bid + 2 {
        return ClientMessage::PassBid;
    }

    if next_bid <= max_willing {
        ClientMessage::PlaceBid { amount: next_bid }
    } else {
        ClientMessage::PassBid
    }
}

fn decide_trump(engine: &GameEngine, seat: SeatIndex) -> ClientMessage {
    let view = engine.view_for_seat(seat, None);
    let hand = &view.your_hand;
    let allow_rev = view.config.allow_reverse_rule_option;
    // Since first bidder ((dealer + 1) % 4) also leads Trick 1, opening lead control makes Reverse much safer
    let is_opening_leader = seat == (engine.dealer + 1) % 4;

    // Step 2 of 7th-card trump flow: decide Straight vs Reverse after seeing the 7th card
    if view.seventh_card_committed {
        let mut all_cards = hand.clone();
        if let Some(c7) = view.seventh_card_preview {
            all_cards.push(c7);
        }
        let rev = if allow_rev {
            let low_cnt = all_cards
                .iter()
                .filter(|c| matches!(c.rank, Rank::Seven | Rank::Eight | Rank::Queen | Rank::King))
                .count();
            let high_cnt = all_cards
                .iter()
                .filter(|c| matches!(c.rank, Rank::Jack | Rank::Nine))
                .count();
            low_cnt >= 3 && high_cnt == 0
        } else {
            false
        };
        return ClientMessage::SelectTrump {
            suit: None,
            reverse_enabled: rev,
            mode: TrumpMode::SeventhCard,
        };
    }

    let max_suit_len = Suit::ALL
        .iter()
        .map(|&s| hand.iter().filter(|c| c.suit == s).count())
        .max()
        .unwrap_or(0);
    let hand_pts: u8 = hand.iter().map(|c| c.points()).sum();
    let jacks = hand.iter().filter(|c| c.rank == Rank::Jack).count();
    let nines = hand.iter().filter(|c| c.rank == Rank::Nine).count();
    let sevens = hand.iter().filter(|c| c.rank == Rank::Seven).count();

    // 7th Card Trump: humans gamble on 7th card when stuck on a weak 16 bid with no real trump suit!
    let bid_is_min = view.current_high_bid.unwrap_or(16) <= view.config.starting_bid;
    let has_any_rev_pair = Suit::ALL.iter().any(|&s| {
        hand.iter().any(|c| c.suit == s && c.rank == Rank::Seven)
            && hand.iter().any(|c| c.suit == s && c.rank == Rank::Eight)
    });
    if bid_is_min && max_suit_len <= 2 && jacks == 0 && nines == 0 && hand_pts <= 2 && !has_any_rev_pair {
        return ClientMessage::ChooseSeventhCard;
    }

    // Joker (No Trump): only when enabled and on genuine balanced high-card hands (~4..7% of hands)
    let allow_joker = view.config.allow_joker_rule_option;
    if allow_joker && max_suit_len <= 2 && ((jacks >= 3) || (jacks >= 2 && (nines >= 1 || hand_pts >= 8))) {
        return ClientMessage::SelectTrump {
            suit: None,
            reverse_enabled: false,
            mode: TrumpMode::NoTrump,
        };
    }
    if allow_joker && allow_rev && max_suit_len <= 2 && sevens >= 3 && jacks == 0 && nines == 0 {
        return ClientMessage::SelectTrump {
            suit: None,
            reverse_enabled: true,
            mode: TrumpMode::NoTrump,
        };
    }

    let mut best_suit = Suit::Spades;
    let mut best_reverse = false;
    let mut best_score = -100.0_f32;

    for suit in Suit::ALL {
        let sc: Vec<Card> = hand.iter().copied().filter(|c| c.suit == suit).collect();
        let len = sc.len() as f32;
        if len == 0.0 {
            continue;
        }

        let s_str: f32 = sc
            .iter()
            .map(|c| c.rank.strength(&NORMAL_RANK_ORDER) as f32)
            .sum();
        let has_marriage = sc.iter().any(|c| c.rank == Rank::King)
            && sc.iter().any(|c| c.rank == Rank::Queen);
        let straight_score = len * 5.0 + s_str * 1.4 + if has_marriage { 6.0 } else { 0.0 };
        if straight_score > best_score {
            best_score = straight_score;
            best_suit = suit;
            best_reverse = false;
        }

        // Simulation-calibrated Suit Reverse decision (Ridge OLS trained on 16,928 paired 8-trick hands):
        // Predicts exact E[pts_Reverse - pts_Straight] incorporating opening-lead control (+1.519 pts)
        // and distinguishing trump J/9 (-1.51/-1.46) vs non-trump J/9 (+1.27 offset when cashable pre-exposure).
        if allow_rev {
            let has_7 = sc.iter().any(|c| c.rank == Rank::Seven);
            let has_8 = sc.iter().any(|c| c.rank == Rank::Eight);
            if (has_7 || has_8) && (len >= 2.0 || (has_7 && hand.iter().filter(|c| matches!(c.rank, Rank::Seven | Rank::Eight)).count() >= 2)) {
                let has_78 = has_7 && has_8;
                let side_78 = hand
                    .iter()
                    .filter(|c| c.suit != suit && matches!(c.rank, Rank::Seven | Rank::Eight))
                    .count() as f32;
                let j_cnt = hand.iter().filter(|c| c.rank == Rank::Jack).count() as f32;
                let n9_cnt = hand.iter().filter(|c| c.rank == Rank::Nine).count() as f32;
                let non_trump_j9 = hand
                    .iter()
                    .filter(|c| c.suit != suit && matches!(c.rank, Rank::Jack | Rank::Nine))
                    .count() as f32;

                let pred_rev_edge = -1.6387
                    + if is_opening_leader { 1.5190 } else { 0.0 }
                    + len * 0.8454
                    + if has_7 { 0.5625 } else { 0.0 }
                    + if has_8 { 0.1186 } else { 0.0 }
                    + if has_78 { 0.6811 } else { 0.0 }
                    + side_78 * 0.7265
                    - j_cnt * 1.5052
                    - n9_cnt * 1.4561
                    + non_trump_j9 * 1.2706;

                // Convert expected-point advantage over Straight into the shared trump-comparison scale
                if pred_rev_edge > 0.75 {
                    let rev_score = straight_score + pred_rev_edge * 3.5;
                    if rev_score > best_score {
                        best_score = rev_score;
                        best_suit = suit;
                        best_reverse = true;
                    }
                }
            }
        }
    }

    ClientMessage::SelectTrump {
        suit: Some(best_suit),
        reverse_enabled: best_reverse,
        mode: TrumpMode::Suit,
    }
}

fn decide_double(engine: &GameEngine, seat: SeatIndex) -> Option<ClientMessage> {
    let view = engine.view_for_seat(seat, None);
    let hand = &view.your_hand;
    let pts: u8 = hand.iter().map(|c| c.points()).sum();
    let jacks = hand.iter().filter(|c| c.rank == Rank::Jack).count();
    let high_bid = view.current_high_bid.unwrap_or(16);

    if view.can_double && view.stakes == StakesLevel::Normal {
        if (pts >= 6 && high_bid >= 19) || (jacks >= 2 && high_bid >= 18) || (pts >= 8 && high_bid >= 17) {
            Some(ClientMessage::DoubleStakes)
        } else {
            Some(ClientMessage::PassDoubleWindow)
        }
    } else if view.can_redouble && view.stakes == StakesLevel::Doubled {
        if pts >= 7 && jacks >= 2 {
            Some(ClientMessage::RedoubleStakes)
        } else {
            Some(ClientMessage::PassDoubleWindow)
        }
    } else {
        None
    }
}

/// Collect all cards already played in previous tricks + current trick (card counting!).
fn played_cards_set(engine: &GameEngine) -> HashSet<Card> {
    let mut seen = HashSet::with_capacity(32);
    for t in &engine.completed_tricks {
        for p in &t.plays {
            seen.insert(p.card);
        }
    }
    for p in &engine.current_trick {
        seen.insert(p.card);
    }
    seen
}

/// Track which seats have already shown a void in which suit (purely from public trick history!).
fn track_known_voids(engine: &GameEngine) -> [[bool; 4]; 4] {
    let mut voids = [[false; 4]; 4];
    for t in &engine.completed_tricks {
        if let Some(first) = t.plays.first() {
            let led = first.card.suit;
            for p in &t.plays[1..] {
                if p.card.suit != led {
                    voids[p.seat][suit_to_idx(led)] = true;
                }
            }
        }
    }
    if let Some(first) = engine.current_trick.first() {
        let led = first.card.suit;
        for p in &engine.current_trick[1..] {
            if p.card.suit != led {
                voids[p.seat][suit_to_idx(led)] = true;
            }
        }
    }
    voids
}

#[inline]
fn suit_to_idx(s: Suit) -> usize {
    match s {
        Suit::Spades => 0,
        Suit::Hearts => 1,
        Suit::Diamonds => 2,
        Suit::Clubs => 3,
    }
}

/// Count how many trumps are still unaccounted for outside `seen` and `my_hand`.
fn unseen_trumps_count(trump: Option<Suit>, seen: &HashSet<Card>, my_hand: &[Card]) -> usize {
    let Some(t) = trump else { return 0 };
    let mut remaining = 0;
    for r in NORMAL_RANK_ORDER {
        let c = Card::new(r, t);
        if !seen.contains(&c) && !my_hand.contains(&c) {
            remaining += 1;
        }
    }
    remaining
}

/// Returns true if `card` is the highest remaining unplayed card in its suit under `rank_order`.
fn is_boss_in_suit(card: Card, seen: &HashSet<Card>, my_hand: &[Card], rank_order: &[Rank; 8]) -> bool {
    let my_str = card.rank.strength(rank_order);
    for &r in rank_order {
        if r.strength(rank_order) > my_str {
            let higher = Card::new(r, card.suit);
            if !seen.contains(&higher) && !my_hand.contains(&higher) {
                return false;
            }
        }
    }
    true
}

/// Simulate who wins `plays` respecting mid-trick trump/reverse exposure cutoffs identically to engine.rs!
fn simulated_winner(
    plays: &[TrickPlay],
    active_trump: Option<Suit>,
    reverse_active: bool,
    exposed_at_idx: Option<usize>,
) -> SeatIndex {
    let led_suit = plays[0].card.suit;

    if let Some(cutoff) = exposed_at_idx {
        let post_trumps: Vec<&TrickPlay> = plays
            .iter()
            .enumerate()
            .filter(|&(idx, p)| idx >= cutoff && Some(p.card.suit) == active_trump)
            .map(|(_, p)| p)
            .collect();
        if !post_trumps.is_empty() {
            let order = if reverse_active { &REVERSED_RANK_ORDER } else { &NORMAL_RANK_ORDER };
            return post_trumps
                .into_iter()
                .max_by_key(|p| p.card.rank.strength(order))
                .unwrap()
                .seat;
        }
        if reverse_active {
            let post_led: Vec<&TrickPlay> = plays
                .iter()
                .enumerate()
                .filter(|&(idx, p)| idx >= cutoff && p.card.suit == led_suit)
                .map(|(_, p)| p)
                .collect();
            if !post_led.is_empty() {
                return post_led
                    .into_iter()
                    .max_by_key(|p| p.card.rank.strength(&REVERSED_RANK_ORDER))
                    .unwrap()
                    .seat;
            }
        }
        return plays
            .iter()
            .filter(|p| p.card.suit == led_suit)
            .max_by_key(|p| p.card.rank.strength(&NORMAL_RANK_ORDER))
            .unwrap()
            .seat;
    }

    let order = if reverse_active { &REVERSED_RANK_ORDER } else { &NORMAL_RANK_ORDER };
    let mut best = plays[0];
    for &p in &plays[1..] {
        let p_t = Some(p.card.suit) == active_trump;
        let b_t = Some(best.card.suit) == active_trump;
        let beats = match (p_t, b_t) {
            (true, false) => true,
            (false, true) => false,
            (true, true) => p.card.rank.strength(order) > best.card.rank.strength(order),
            (false, false) => {
                p.card.suit == led_suit
                    && p.card.rank.strength(order) > best.card.rank.strength(order)
            }
        };
        if beats {
            best = p;
        }
    }
    best.seat
}

/// Fast Imperfect-Information Monte Carlo Lookahead (PIMC) for multi-trick endgames.
/// Strictly fair: reconstructs unseen cards ONLY from `view` + public trick history (never peeks!).
fn decide_play_pimc(engine: &GameEngine, seat: SeatIndex) -> Option<ClientMessage> {
    let view = engine.view_for_seat(seat, None);
    let legal = &view.legal_cards;
    if legal.is_empty() {
        return None;
    }

    // 1. Always declare Marriage immediately when holding K+Q of trump
    if let Some(&mcard) = view.marriage_cards.first() {
        return Some(ClientMessage::DeclareMarriage { card_id: mcard.id() });
    }

    // 2. If only 1 legal card and cannot show trump, no search needed
    if legal.len() == 1 && !view.can_request_trump_show {
        return Some(ClientMessage::PlayCard {
            card_id: legal[0].id(),
        });
    }

    // 3. Activate PIMC on tricks 4..8 (when <= 5 cards remain in hand) where endgames & trump traps dominate!
    // Skip PIMC in 4th seat when we can't win (just dump 0-pt trash via heuristic) or before trump exposure.
    if view.your_hand.len() > 5 || !view.trump_exposed {
        return decide_play_heuristic(engine, seat);
    }
    if view.current_trick.len() == 3 {
        let active_t = if view.trump_exposed { view.visible_trump } else { None };
        let any_win = legal.iter().any(|&c| {
            let mut sim = view.current_trick.clone();
            sim.push(TrickPlay { seat, card: c });
            simulated_winner(&sim, active_t, view.reverse_active, engine.trump_exposed_at_play_index) == seat
        });
        if !any_win {
            return decide_play_heuristic(engine, seat);
        }
    }

    let seen = played_cards_set(engine);
    let voids = track_known_voids(engine);

    // Build pool of all unseen cards (32 - seen - my_hand)
    let mut unseen: Vec<Card> = Vec::with_capacity(24);
    for suit in Suit::ALL {
        for rank in NORMAL_RANK_ORDER {
            let c = Card::new(rank, suit);
            if !seen.contains(&c) && !view.your_hand.contains(&c) {
                unseen.push(c);
            }
        }
    }

    let other_sizes: [usize; 4] = [
        view.seats[0].card_count,
        view.seats[1].card_count,
        view.seats[2].card_count,
        view.seats[3].card_count,
    ];
    let expected_unseen: usize = (0..4usize)
        .filter(|&s| s != seat)
        .map(|s| other_sizes[s])
        .sum();
    if unseen.len() != expected_unseen {
        // Fallback safely if 7th-card face-down hidden state causes count mismatch
        return decide_play_heuristic(engine, seat);
    }

    let my_team = Team::of_seat(seat);
    let samples = if view.your_hand.len() <= 3 { 24 } else { 18 };
    let heur_card = match decide_play_heuristic(engine, seat) {
        Some(ClientMessage::PlayCard { card_id }) => Card::from_id(&card_id),
        _ => None,
    };
    let mut rng = FastRng::new(
        (view.hand_number as u64) * 1009
            + (engine.completed_tricks.len() as u64) * 97
            + (seat as u64) * 13
            + (engine.current_trick.len() as u64),
    );

    let mut scores: Vec<f32> = legal
        .iter()
        .map(|&c| if Some(c) == heur_card { 0.15 } else { 0.0 })
        .collect();

    for _ in 0..samples {
        // Sample a valid determinized world consistent with known voids
        let world_hands = sample_consistent_hands(&unseen, seat, &other_sizes, &voids, &mut rng);

        for (ci, &cand_card) in legal.iter().enumerate() {
            let mut sim = engine.clone();
            for s in 0..4usize {
                if s != seat {
                    sim.hands[s] = world_hands[s].clone();
                }
            }
            if sim.play_card(seat, cand_card).is_err() {
                scores[ci] -= 100.0;
                continue;
            }
            // Fast rollout to end of hand using heuristic policy
            let mut guard = 0usize;
            while sim.phase == GamePhase::Playing && guard < 40 {
                guard += 1;
                let turn = sim.current_turn;
                let Some(act) = choose_fast_play_action(&sim, turn) else {
                    break;
                };
                let ok = match act {
                    ClientMessage::RequestTrumpShow => sim.request_trump_show(turn).is_ok(),
                    ClientMessage::DeclareMarriage { card_id } => Card::from_id(&card_id)
                        .and_then(|c| sim.declare_marriage(turn, c).ok())
                        .is_some(),
                    ClientMessage::PlayCard { card_id } => Card::from_id(&card_id)
                        .and_then(|c| sim.play_card(turn, c).ok())
                        .is_some(),
                    _ => false,
                };
                if !ok {
                    break;
                }
            }

            if let Some(sum) = sim.hand_history.last() {
                let won = sum.winning_team == my_team;
                let my_pts = if sum.bidding_team == my_team {
                    sum.bidding_team_points as f32
                } else {
                    sum.opposing_team_points as f32
                };
                scores[ci] += if won { 10.0 } else { 0.0 } + my_pts * 0.05;
            }
        }
    }

    let best_idx = scores
        .iter()
        .enumerate()
        .max_by(|a, b| a.1.partial_cmp(b.1).unwrap_or(std::cmp::Ordering::Equal))
        .map(|(i, _)| i)
        .unwrap_or(0);

    Some(ClientMessage::PlayCard {
        card_id: legal[best_idx].id(),
    })
}

/// Deal `unseen` cards to the 3 other seats respecting exact card counts and known suit voids.
fn sample_consistent_hands(
    unseen: &[Card],
    self_seat: SeatIndex,
    sizes: &[usize; 4],
    voids: &[[bool; 4]; 4],
    rng: &mut FastRng,
) -> [Vec<Card>; 4] {
    let mut pool = unseen.to_vec();
    let mut best_hands: [Vec<Card>; 4] = Default::default();

    for _attempt in 0..8 {
        rng.shuffle(&mut pool);
        let mut hands: [Vec<Card>; 4] = Default::default();
        let mut used = vec![false; pool.len()];
        let mut valid = true;

        // Fill seats with more voids first (most constrained first)
        let mut order: Vec<usize> = (0..4usize).filter(|&s| s != self_seat).collect();
        order.sort_by_key(|&s| std::cmp::Reverse(voids[s].iter().filter(|&&v| v).count()));

        for s in order {
            let need = sizes[s];
            for (idx, &c) in pool.iter().enumerate() {
                if hands[s].len() == need {
                    break;
                }
                if !used[idx] && !voids[s][suit_to_idx(c.suit)] {
                    hands[s].push(c);
                    used[idx] = true;
                }
            }
            if hands[s].len() != need {
                valid = false;
                break;
            }
        }

        if valid {
            return hands;
        }
        best_hands = hands;
    }

    // Fallback: simple deal without void constraints if rare dead-end
    rng.shuffle(&mut pool);
    let mut cursor = 0;
    for s in 0..4usize {
        if s == self_seat {
            best_hands[s].clear();
        } else {
            let need = sizes[s];
            best_hands[s] = pool[cursor..cursor + need].to_vec();
            cursor += need;
        }
    }
    best_hands
}

fn decide_play_heuristic(engine: &GameEngine, seat: SeatIndex) -> Option<ClientMessage> {
    let view = engine.view_for_seat(seat, None);
    let legal = &view.legal_cards;
    if legal.is_empty() {
        return None;
    }

    if let Some(&mcard) = view.marriage_cards.first() {
        return Some(ClientMessage::DeclareMarriage { card_id: mcard.id() });
    }

    let seen = played_cards_set(engine);
    let voids = track_known_voids(engine);
    let rank_order = &view.current_rank_order;
    let known_trump = view.visible_trump;
    let active_trump = if view.trump_exposed { view.visible_trump } else { None };
    let is_no_trump = view.visible_trump_mode == Some(TrumpMode::NoTrump);
    let unseen_trumps = if is_no_trump {
        0
    } else {
        unseen_trumps_count(known_trump, &seen, &view.your_hand)
    };
    let my_team = Team::of_seat(seat);
    let on_bidding_team = view
        .current_high_bidder
        .map(|b| Team::of_seat(b) == my_team)
        .unwrap_or(false);

    let target_bid = view.effective_bid.unwrap_or(view.current_high_bid.unwrap_or(16)) as i32;
    let (my_pts, _opp_pts) = if my_team == Team::TeamA {
        (view.hand_points_team_a as i32, view.hand_points_team_b as i32)
    } else {
        (view.hand_points_team_b as i32, view.hand_points_team_a as i32)
    };
    let max_total = if view.config.last_trick_bonus_point { 29 } else { 28 };
    let pts_needed = if on_bidding_team {
        (target_bid - my_pts).max(0)
    } else {
        ((max_total - target_bid + 1) - my_pts).max(0)
    };
    let urgent_for_pts = pts_needed > 0 && pts_needed <= 3;

    let reverse_planned_unexposed = !view.trump_exposed
        && view.current_high_bidder == Some(seat)
        && view.reverse_choice_visible == Some(true);

    if view.current_trick.is_empty() {
        let card = choose_smart_lead(
            legal,
            &view.your_hand,
            &seen,
            &voids,
            known_trump,
            unseen_trumps,
            rank_order,
            view.trump_exposed,
            view.current_high_bidder,
            seat,
            urgent_for_pts,
            reverse_planned_unexposed,
        );
        return Some(ClientMessage::PlayCard { card_id: card.id() });
    }

    let trick = &view.current_trick;
    let trick_pts: u8 = trick.iter().map(|p| p.card.points()).sum();
    let exposed_idx = engine.trump_exposed_at_play_index;
    let current_winner = simulated_winner(trick, active_trump, view.reverse_active, exposed_idx);
    let partner_winning = Team::of_seat(current_winner) == my_team;
    let is_last_to_play = trick.len() == 3;
    let is_second_to_play = trick.len() == 1;
    let partner_card = trick.iter().find(|p| p.seat == current_winner).map(|p| p.card);

    let led_suit = trick[0].card.suit;
    let opp_behind_void = !is_last_to_play
        && unseen_trumps > 0
        && Some(led_suit) != active_trump
        && (0..4usize).any(|s| {
            Team::of_seat(s) != my_team
                && !trick.iter().any(|p| p.seat == s)
                && s != seat
                && voids[s][suit_to_idx(led_suit)]
        });

    let partner_has_boss = partner_winning
        && (is_last_to_play
            || (!opp_behind_void
                && partner_card
                    .map(|pc| {
                        (Some(pc.suit) == active_trump && unseen_trumps == 0)
                            || is_boss_in_suit(pc, &seen, &view.your_hand, rank_order)
                    })
                    .unwrap_or(false)));

    if view.can_request_trump_show && !partner_has_boss {
        let worth_showing = trick_pts >= 2
            || (trick_pts >= 1 && (is_last_to_play || urgent_for_pts))
            || (view.current_high_bidder == Some(seat) && trick_pts >= 1);
        if worth_showing {
            return Some(ClientMessage::RequestTrumpShow);
        }
    }

    let mut winning_cards: Vec<Card> = Vec::new();
    for &c in legal {
        let mut sim = trick.clone();
        sim.push(TrickPlay { seat, card: c });
        if simulated_winner(&sim, active_trump, view.reverse_active, exposed_idx) == seat {
            winning_cards.push(c);
        }
    }

    let chosen = if partner_has_boss {
        *legal
            .iter()
            .max_by_key(|c| {
                let is_trump = Some(c.suit) == known_trump;
                let avoid_trump = if is_trump { 0i32 } else { 10i32 };
                let boss_pen = if is_boss_in_suit(**c, &seen, &view.your_hand, rank_order) {
                    -5
                } else {
                    0
                };
                (
                    avoid_trump,
                    c.points() as i32 * 4 + boss_pen,
                    -(c.rank.strength(rank_order) as i32),
                )
            })
            .unwrap()
    } else if !winning_cards.is_empty() {
        if is_last_to_play {
            *winning_cards
                .iter()
                .max_by_key(|c| {
                    let is_trump = Some(c.suit) == known_trump;
                    let avoid_trump = if is_trump { -20i32 } else { 0i32 };
                    let is_boss = is_boss_in_suit(**c, &seen, &view.your_hand, rank_order);
                    let boss_pen = if is_boss { -6 } else { 0 };
                    (
                        avoid_trump,
                        boss_pen + c.points() as i32 * 3,
                        -(c.rank.strength(rank_order) as i32),
                    )
                })
                .unwrap()
        } else if is_second_to_play && trick_pts == 0 && !urgent_for_pts {
            if let Some(&boss_win) = winning_cards.iter().find(|c| {
                Some(c.suit) != known_trump
                    && is_boss_in_suit(**c, &seen, &view.your_hand, rank_order)
                    && !opp_behind_void
            }) {
                boss_win
            } else {
                *legal
                    .iter()
                    .min_by_key(|c| {
                        let is_trump = Some(c.suit) == known_trump;
                        (c.points(), if is_trump { 1 } else { 0 }, c.rank.strength(rank_order))
                    })
                    .unwrap()
            }
        } else if trick_pts >= 2 || urgent_for_pts {
            *winning_cards
                .iter()
                .max_by_key(|c| {
                    let boss = if is_boss_in_suit(**c, &seen, &view.your_hand, rank_order) {
                        15
                    } else {
                        0
                    };
                    boss + c.rank.strength(rank_order) as i32
                })
                .unwrap()
        } else {
            *winning_cards
                .iter()
                .min_by_key(|c| {
                    let is_trump = Some(c.suit) == known_trump;
                    (if is_trump { 1 } else { 0 }, c.rank.strength(rank_order))
                })
                .unwrap()
        }
    } else {
        *legal
            .iter()
            .min_by_key(|c| {
                let is_trump = Some(c.suit) == known_trump;
                (c.points(), if is_trump { 1 } else { 0 }, c.rank.strength(rank_order))
            })
            .unwrap()
    };

    Some(ClientMessage::PlayCard {
        card_id: chosen.id(),
    })
}

#[allow(clippy::too_many_arguments)]
fn choose_smart_lead(
    legal: &[Card],
    hand: &[Card],
    seen: &HashSet<Card>,
    voids: &[[bool; 4]; 4],
    known_trump: Option<Suit>,
    unseen_trumps: usize,
    rank_order: &[Rank; 8],
    trump_exposed: bool,
    bidder: Option<SeatIndex>,
    seat: SeatIndex,
    urgent_for_pts: bool,
    reverse_planned_unexposed: bool,
) -> Card {
    let my_team = Team::of_seat(seat);
    let partner = (seat + 2) % 4;
    let on_bidding_team = bidder
        .map(|b| Team::of_seat(b) == my_team)
        .unwrap_or(false);

    let opp_is_void = |s: Suit| -> bool {
        (0..4usize).any(|o| Team::of_seat(o) != my_team && voids[o][suit_to_idx(s)])
    };

    if trump_exposed && on_bidding_team && unseen_trumps > 0 {
        if let Some(t) = known_trump {
            if let Some(&boss_t) = legal
                .iter()
                .find(|c| c.suit == t && is_boss_in_suit(**c, seen, hand, rank_order))
            {
                return boss_t;
            }
        }
    }

    // Pre-exposure Reverse strategy (bidder set Reverse and holds the lead):
    // 1) Cash any non-trump Normal-order boss (J / promoted 9) BEFORE Reverse weakens it.
    // 2) Otherwise, deliberately lead a repeated or long non-trump suit using non-7/8 cards
    //    to force someone void and trigger Show Trump while preserving our 7/8 Reverse winners!
    if reverse_planned_unexposed {
        if let Some(&boss) = legal
            .iter()
            .filter(|c| {
                Some(c.suit) != known_trump
                    && matches!(c.rank, Rank::Jack | Rank::Nine | Rank::Ace)
                    && is_boss_in_suit(**c, seen, hand, rank_order)
            })
            .max_by_key(|c| c.points())
        {
            return boss;
        }
        if let Some(&probe) = legal
            .iter()
            .filter(|c| Some(c.suit) != known_trump && !matches!(c.rank, Rank::Seven | Rank::Eight))
            .max_by_key(|c| {
                let suit_seen = seen.iter().filter(|s| s.suit == c.suit).count();
                let suit_held = hand.iter().filter(|h| h.suit == c.suit).count();
                // Prefer suits already played (repeat suit to trigger a void/Show Trump) or longest non-trump suit,
                // and prefer shedding K/Q (0 pts) or Ace/10 over risking 7/8.
                let trigger_pressure = suit_seen * 3 + suit_held * 2;
                let low_pt_pref = if c.points() == 0 { 2 } else { 0 };
                (trigger_pressure, low_pt_pref, c.rank.strength(&NORMAL_RANK_ORDER))
            })
        {
            return probe;
        }
    }

    // Only cash a non-trump boss when trumps are gone, OR it is a fresh 1st-round suit
    // with plenty of cards left in other hands (never blindly lead 9 right after J into a trump cut!).
    let trumps_still_out = unseen_trumps > 0 || !trump_exposed;
    if let Some(&boss) = legal
        .iter()
        .filter(|c| {
            if Some(c.suit) == known_trump || !is_boss_in_suit(**c, seen, hand, rank_order) {
                return false;
            }
            if !trumps_still_out {
                return true;
            }
            if opp_is_void(c.suit) {
                return false;
            }
            let seen_s = seen.iter().filter(|s| s.suit == c.suit).count();
            let held_s = hand.iter().filter(|h| h.suit == c.suit).count();
            let others_rem = 8usize.saturating_sub(seen_s + held_s);
            // Safe to cash J/9/A/10 only on a fresh suit (seen_s == 0) with >= 5 cards left among others
            seen_s == 0 && others_rem >= 5
        })
        .max_by_key(|c| c.points())
    {
        return boss;
    }

    if trump_exposed && unseen_trumps > 0 {
        if let Some(&feed) = legal
            .iter()
            .filter(|c| {
                Some(c.suit) != known_trump
                    && voids[partner][suit_to_idx(c.suit)]
                    && c.points() == 0
            })
            .min_by_key(|c| c.rank.strength(rank_order))
        {
            return feed;
        }
    }

    if urgent_for_pts && trump_exposed {
        if let Some(t) = known_trump {
            if let Some(&boss_t) = legal
                .iter()
                .find(|c| c.suit == t && is_boss_in_suit(**c, seen, hand, rank_order))
            {
                return boss_t;
            }
        }
    }

    *legal
        .iter()
        .min_by_key(|c| {
            let is_trump = Some(c.suit) == known_trump;
            let avoid_trump = if is_trump { 2 } else { 0 };
            let avoid_opp_void = if unseen_trumps > 0 && opp_is_void(c.suit) && c.points() > 0 {
                1
            } else {
                0
            };
            (c.points(), avoid_trump, avoid_opp_void, c.rank.strength(rank_order))
        })
        .unwrap()
}

/// Legacy baseline AI (pre-calibration, no PIMC, no void tracking) kept for head-to-head benchmarking.
#[cfg(test)]
pub(crate) fn choose_legacy_baseline_action(engine: &GameEngine, seat: SeatIndex) -> Option<ClientMessage> {
    let view = engine.view_for_seat(seat, None);
    match view.phase {
        GamePhase::Bidding if view.current_turn == seat => {
            let hand = &view.your_hand;
            let mut best = 0.0_f32;
            for suit in Suit::ALL {
                let sc: Vec<Card> = hand.iter().copied().filter(|c| c.suit == suit).collect();
                if sc.is_empty() { continue; }
                let count = sc.len() as f32;
                let mut st = count * 2.2;
                let has_j = sc.iter().any(|c| c.rank == Rank::Jack);
                let has_9 = sc.iter().any(|c| c.rank == Rank::Nine);
                if has_j { st += 3.5; }
                if has_9 { st += 2.4; }
                if has_j && has_9 { st += 2.2; }
                if sc.iter().any(|c| c.rank == Rank::Ace) { st += 1.0; }
                if sc.iter().any(|c| c.rank == Rank::King) && sc.iter().any(|c| c.rank == Rank::Queen) { st += 2.5; }
                let side_j = hand.iter().filter(|c| c.suit != suit && c.rank == Rank::Jack).count() as f32;
                let side_9 = hand.iter().filter(|c| c.suit != suit && c.rank == Rank::Nine).count() as f32;
                best = best.max(st + side_j * 1.6 + side_9 * 0.8);
            }
            let max_w = ((12.5 + best * 0.82).round() as u8).clamp(15, 24).min(view.config.max_bid);
            let next_bid = view.current_high_bid.map(|h| h + 1).unwrap_or(view.config.starting_bid);
            let pw = view.current_high_bidder.map(|b| Team::of_seat(b) == Team::of_seat(seat)).unwrap_or(false);
            if pw && max_w < next_bid + 2 { return Some(ClientMessage::PassBid); }
            if next_bid <= max_w { Some(ClientMessage::PlaceBid { amount: next_bid }) } else { Some(ClientMessage::PassBid) }
        }
        GamePhase::SelectTrump if view.current_turn == seat => {
            let hand = &view.your_hand;
            let mut best_suit = Suit::Spades;
            let mut best_score = -100.0_f32;
            for suit in Suit::ALL {
                let sc: Vec<Card> = hand.iter().copied().filter(|c| c.suit == suit).collect();
                if sc.is_empty() { continue; }
                let s_str: f32 = sc.iter().map(|c| c.rank.strength(&NORMAL_RANK_ORDER) as f32).sum();
                let score = sc.len() as f32 * 5.0 + s_str * 1.4;
                if score > best_score { best_score = score; best_suit = suit; }
            }
            Some(ClientMessage::SelectTrump { suit: Some(best_suit), reverse_enabled: false, mode: TrumpMode::Suit })
        }
        GamePhase::DoubleWindow => decide_double(engine, seat),
        GamePhase::Playing if view.current_turn == seat => {
            let legal = &view.legal_cards;
            if legal.is_empty() { return None; }
            if let Some(&m) = view.marriage_cards.first() {
                return Some(ClientMessage::DeclareMarriage { card_id: m.id() });
            }
            let seen = played_cards_set(engine);
            let rank_order = &view.current_rank_order;
            let known_trump = view.visible_trump;
            let active_trump = if view.trump_exposed { view.visible_trump } else { None };
            if view.current_trick.is_empty() {
                let c = *legal.iter().min_by_key(|c| (c.points(), if Some(c.suit) == known_trump { 1 } else { 0 })).unwrap();
                return Some(ClientMessage::PlayCard { card_id: c.id() });
            }
            let trick = &view.current_trick;
            let trick_pts: u8 = trick.iter().map(|p| p.card.points()).sum();
            let cw = simulated_winner(trick, active_trump, view.reverse_active, None);
            let pw = Team::of_seat(cw) == Team::of_seat(seat);
            if view.can_request_trump_show && !pw && trick_pts >= 2 {
                return Some(ClientMessage::RequestTrumpShow);
            }
            let mut wins = Vec::new();
            for &c in legal {
                let mut sim = trick.clone();
                sim.push(TrickPlay { seat, card: c });
                if simulated_winner(&sim, active_trump, view.reverse_active, None) == seat {
                    wins.push(c);
                }
            }
            let chosen = if pw && trick.len() == 3 {
                *legal.iter().max_by_key(|c| c.points()).unwrap()
            } else if !wins.is_empty() {
                *wins.iter().min_by_key(|c| (if Some(c.suit) == known_trump { 1 } else { 0 }, c.rank.strength(rank_order))).unwrap()
            } else {
                *legal.iter().min_by_key(|c| (c.points(), if Some(c.suit) == known_trump { 1 } else { 0 }, c.rank.strength(rank_order))).unwrap()
            };
            let _ = seen;
            Some(ClientMessage::PlayCard { card_id: chosen.id() })
        }
        _ => None,
    }
}

#[cfg(test)]
pub(crate) fn choose_calibrated_heuristic_only_action(engine: &GameEngine, seat: SeatIndex) -> Option<ClientMessage> {
    let view = engine.view_for_seat(seat, None);
    match view.phase {
        GamePhase::Bidding if view.current_turn == seat => Some(decide_bid(engine, seat)),
        GamePhase::SelectTrump if view.current_turn == seat => Some(decide_trump(engine, seat)),
        GamePhase::DoubleWindow => decide_double(engine, seat),
        GamePhase::Playing if view.current_turn == seat => decide_play_heuristic(engine, seat),
        _ => None,
    }
}

// Crate-internal helpers shared with `rl_pro`
pub(crate) struct FastRngPub(FastRng);
impl FastRngPub {
    pub(crate) fn new(seed: u64) -> Self { Self(FastRng::new(seed)) }
    pub(crate) fn next_u64(&mut self) -> u64 { self.0.next_u64() }
    pub(crate) fn shuffle<T>(&mut self, slice: &mut [T]) { self.0.shuffle(slice) }
}
pub(crate) fn played_cards_set_pub(engine: &GameEngine) -> HashSet<Card> { played_cards_set(engine) }
pub(crate) fn track_known_voids_pub(engine: &GameEngine) -> [[bool; 4]; 4] { track_known_voids(engine) }
pub(crate) fn suit_to_idx_pub(s: Suit) -> usize { suit_to_idx(s) }
pub(crate) fn unseen_trumps_count_pub(trump: Option<Suit>, seen: &HashSet<Card>, my_hand: &[Card]) -> usize {
    unseen_trumps_count(trump, seen, my_hand)
}
pub(crate) fn is_boss_in_suit_pub(card: Card, seen: &HashSet<Card>, my_hand: &[Card], rank_order: &[Rank; 8]) -> bool {
    is_boss_in_suit(card, seen, my_hand, rank_order)
}
pub(crate) fn simulated_winner_pub(
    plays: &[TrickPlay],
    active_trump: Option<Suit>,
    reverse_active: bool,
    exposed_at_idx: Option<usize>,
) -> SeatIndex {
    simulated_winner(plays, active_trump, reverse_active, exposed_at_idx)
}
pub(crate) fn decide_play_heuristic_pub(engine: &GameEngine, seat: SeatIndex) -> Option<ClientMessage> {
    decide_play_heuristic(engine, seat)
}
#[allow(dead_code)]
pub(crate) fn sample_consistent_hands_pub(
    unseen: &[Card],
    self_seat: SeatIndex,
    sizes: &[usize; 4],
    voids: &[[bool; 4]; 4],
    rng: &mut FastRngPub,
) -> [Vec<Card>; 4] {
    sample_consistent_hands(unseen, self_seat, sizes, voids, &mut rng.0)
}
