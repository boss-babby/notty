use serde::{Deserialize, Serialize};

/// Events that can expose the hidden trump suit.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum TrumpExposeTrigger {
    ShowTrump,
    Marriage,
}

/// Configurable set-point scoring rules for a completed hand.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ScoringTable {
    /// Standard set points awarded for winning a hand by meeting the bid.
    pub base_win_set_points: i32,
    /// Set points awarded for winning all 8 tricks / all 29 points ("Kappu" / clean sweep).
    pub clean_sweep_bonus_set_points: i32,
    /// Set points conceded to the defending team when the bidding team fails their bid.
    pub base_fail_set_points: i32,
    /// Extra set points conceded if the bidding team misses their bid by a wide margin (>= heavy_fail_margin).
    pub heavy_fail_margin: u8,
    pub heavy_fail_set_points: i32,
}

impl Default for ScoringTable {
    fn default() -> Self {
        Self {
            base_win_set_points: 1,
            clean_sweep_bonus_set_points: 3,
            base_fail_set_points: 1,
            heavy_fail_margin: 8,
            heavy_fail_set_points: 2,
        }
    }
}

/// Table-level configurable rule flags (Section 3.5 of the specification).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GameConfig {
    pub starting_bid: u8,
    pub max_bid: u8,
    /// If true (default), when the first 3 players pass, the last bidder (dealer) must take starting_bid (16).
    #[serde(default = "default_true")]
    pub force_last_bidder_min_bid: bool,
    /// If true, an 8-card hand with 0 points automatically reshuffles; if false (default), the player may choose to reshuffle.
    #[serde(default)]
    pub auto_reshuffle_zero_point_hand: bool,
    /// If true, winning the 8th (last) trick awards +1 bonus point (total 29 pts). Default: false (28 pts).
    #[serde(default)]
    pub last_trick_bonus_point: bool,
    /// If true, bots use Offline-RL Pro AI. Default: false (Normal).
    #[serde(default)]
    pub pro_bot_ai: bool,
    /// If true (default), re-shuffles the deal if any single player's 8-card hand contains all 4 Jacks.
    #[serde(default = "default_true")]
    pub no_four_jacks_deal: bool,
    pub marriage_bonus_points: u8,
    /// Table-level switch controlling whether Bidders are offered the Reverse toggle at trump selection.
    pub allow_reverse_rule_option: bool,
    /// Table-level switch controlling whether Bidders are offered Joker (No Trump).
    #[serde(default = "default_true")]
    pub allow_joker_rule_option: bool,
    pub reverse_trigger_on: Vec<TrumpExposeTrigger>,
    pub clean_sweep_bonus_set_points: i32,
    pub target_set_points_to_win_match: i32,
    pub allow_doubling: bool,
    pub allow_redoubling: bool,
    pub turn_timeout_seconds: u32,
    #[serde(default)]
    pub scoring_table: ScoringTable,
}

impl Default for GameConfig {
    fn default() -> Self {
        Self {
            starting_bid: 16,
            max_bid: 28,
            force_last_bidder_min_bid: true,
            auto_reshuffle_zero_point_hand: false,
            last_trick_bonus_point: false,
            pro_bot_ai: false,
            no_four_jacks_deal: true,
            marriage_bonus_points: 4,
            allow_reverse_rule_option: true,
            allow_joker_rule_option: true,
            reverse_trigger_on: vec![TrumpExposeTrigger::ShowTrump, TrumpExposeTrigger::Marriage],
            clean_sweep_bonus_set_points: 3,
            target_set_points_to_win_match: 6,
            allow_doubling: true,
            allow_redoubling: true,
            turn_timeout_seconds: 30,
            scoring_table: ScoringTable::default(),
        }
    }
}

fn default_true() -> bool { true }
