use rand::seq::SliceRandom;
use rand::Rng;
use serde::{Deserialize, Serialize};
use std::fmt;

/// The four standard French suits.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Suit {
    Spades,
    Hearts,
    Diamonds,
    Clubs,
}

impl Suit {
    pub const ALL: [Suit; 4] = [Suit::Spades, Suit::Hearts, Suit::Diamonds, Suit::Clubs];

    pub fn symbol(self) -> &'static str {
        match self {
            Suit::Spades => "♠",
            Suit::Hearts => "♥",
            Suit::Diamonds => "♦",
            Suit::Clubs => "♣",
        }
    }

    pub fn code(self) -> &'static str {
        match self {
            Suit::Spades => "S",
            Suit::Hearts => "H",
            Suit::Diamonds => "D",
            Suit::Clubs => "C",
        }
    }

    pub fn name(self) -> &'static str {
        match self {
            Suit::Spades => "Spades",
            Suit::Hearts => "Hearts",
            Suit::Diamonds => "Diamonds",
            Suit::Clubs => "Clubs",
        }
    }

    pub fn is_red(self) -> bool {
        matches!(self, Suit::Hearts | Suit::Diamonds)
    }

    pub fn from_code(s: &str) -> Option<Self> {
        match s.to_ascii_uppercase().as_str() {
            "S" | "SPADES" => Some(Suit::Spades),
            "H" | "HEARTS" => Some(Suit::Hearts),
            "D" | "DIAMONDS" => Some(Suit::Diamonds),
            "C" | "CLUBS" => Some(Suit::Clubs),
            _ => None,
        }
    }
}

impl fmt::Display for Suit {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.symbol())
    }
}

/// The 8 ranks used in the 32-card deck for 29 (7 through Ace).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Rank {
    #[serde(rename = "7")]
    Seven,
    #[serde(rename = "8")]
    Eight,
    #[serde(rename = "9")]
    Nine,
    #[serde(rename = "10")]
    Ten,
    #[serde(rename = "J")]
    Jack,
    #[serde(rename = "Q")]
    Queen,
    #[serde(rename = "K")]
    King,
    #[serde(rename = "A")]
    Ace,
}

/// Normal ranking order, high -> low: J > 9 > A > 10 > K > Q > 8 > 7
pub const NORMAL_RANK_ORDER: [Rank; 8] = [
    Rank::Jack,
    Rank::Nine,
    Rank::Ace,
    Rank::Ten,
    Rank::King,
    Rank::Queen,
    Rank::Eight,
    Rank::Seven,
];

/// Reversed ranking order (high -> low) when Reverse is enabled AND trump is exposed:
/// 7 > 8 > Q > K > 10 > A > 9 > J
pub const REVERSED_RANK_ORDER: [Rank; 8] = [
    Rank::Seven,
    Rank::Eight,
    Rank::Queen,
    Rank::King,
    Rank::Ten,
    Rank::Ace,
    Rank::Nine,
    Rank::Jack,
];

impl Rank {
    pub const ALL: [Rank; 8] = NORMAL_RANK_ORDER;

    /// Point value of a card rank (never changes under Reverse rule).
    /// J=3, 9=2, A=1, 10=1, K/Q/8/7=0. Total per suit = 7, ×4 = 28 (+1 last trick = 29).
    pub const fn points(self) -> u8 {
        match self {
            Rank::Jack => 3,
            Rank::Nine => 2,
            Rank::Ace => 1,
            Rank::Ten => 1,
            Rank::King | Rank::Queen | Rank::Eight | Rank::Seven => 0,
        }
    }

    pub const fn code(self) -> &'static str {
        match self {
            Rank::Seven => "7",
            Rank::Eight => "8",
            Rank::Nine => "9",
            Rank::Ten => "10",
            Rank::Jack => "J",
            Rank::Queen => "Q",
            Rank::King => "K",
            Rank::Ace => "A",
        }
    }

    pub fn from_code(s: &str) -> Option<Self> {
        match s.to_ascii_uppercase().as_str() {
            "7" => Some(Rank::Seven),
            "8" => Some(Rank::Eight),
            "9" => Some(Rank::Nine),
            "10" => Some(Rank::Ten),
            "J" => Some(Rank::Jack),
            "Q" => Some(Rank::Queen),
            "K" => Some(Rank::King),
            "A" => Some(Rank::Ace),
            _ => None,
        }
    }

    /// Returns strength index where higher number = stronger card, given a high->low rank order array.
    pub fn strength(self, rank_order: &[Rank; 8]) -> usize {
        let pos = rank_order
            .iter()
            .position(|&r| r == self)
            .expect("all 8 ranks exist in rank_order");
        7 - pos
    }
}

impl fmt::Display for Rank {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.code())
    }
}

/// A single playing card in the 32-card deck.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct Card {
    pub rank: Rank,
    pub suit: Suit,
}

impl Card {
    pub const fn new(rank: Rank, suit: Suit) -> Self {
        Self { rank, suit }
    }

    pub const fn points(self) -> u8 {
        self.rank.points()
    }

    /// Canonical card ID, e.g. "JS", "9H", "10D", "7C" (matches asset filenames).
    pub fn id(self) -> String {
        format!("{}{}", self.rank.code(), self.suit.code())
    }

    pub fn from_id(id: &str) -> Option<Self> {
        if id.len() < 2 {
            return None;
        }
        let (rank_str, suit_str) = id.split_at(id.len() - 1);
        let rank = Rank::from_code(rank_str)?;
        let suit = Suit::from_code(suit_str)?;
        Some(Card { rank, suit })
    }
}

impl fmt::Display for Card {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}{}", self.rank, self.suit)
    }
}

/// Generates a fresh 32-card deck (unshuffled).
pub fn standard_32_deck() -> Vec<Card> {
    let mut deck = Vec::with_capacity(32);
    for suit in Suit::ALL {
        for rank in Rank::ALL {
            deck.push(Card::new(rank, suit));
        }
    }
    deck
}

/// Generates a shuffled 32-card deck using the provided RNG.
pub fn shuffled_deck<R: Rng + ?Sized>(rng: &mut R) -> Vec<Card> {
    let mut deck = standard_32_deck();
    deck.shuffle(rng);
    deck
}

/// Sort a hand by suit then descending strength according to `rank_order`.
pub fn sort_hand(hand: &mut [Card], rank_order: &[Rank; 8]) {
    hand.sort_by(|a, b| {
        a.suit
            .cmp(&b.suit)
            .then_with(|| b.rank.strength(rank_order).cmp(&a.rank.strength(rank_order)))
    });
}
