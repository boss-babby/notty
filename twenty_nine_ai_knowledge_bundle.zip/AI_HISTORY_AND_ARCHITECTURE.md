# Twenty-Nine (29) Card Game — AI History, Architecture & Codebase Stats

This document captures the full engineering history of the Twenty-Nine AI, every model generation, bugs found and fixed, benchmark results, current codebase statistics, and the roadmap for Stage 3 and Rust production integration.

---

## 1. Where It Started → Where It Is Now

### Phase A: Heuristic & Early Neural Bots (`v1` → `v2` → `v3` / `v3.2` / `v3.5`)
- **Rule Engine (`twenty_nine_core/src/engine.rs`, `cards.rs`, `bot.rs`)**:
  - Built a complete, deterministic Rust 29 engine supporting 4-player partnership play, 32-card deck (`J=3, 9=2, A=1, 10=1, K/Q/8/7=0`), `±6` set scoring, hidden trump, Marriage (`K+Q` of trump), Straight & Reverse play, Joker/No-Trump, 7th-Card trump, and full 4-player `DoubleWindow` (`1x → 2x → 4x`).
- **Pro RL `v1` & `v2` (`rl_pro.rs`, `rl_weights.rs`, `rl_weights_v2.rs`)**:
  - Initial small MLP value/bid networks trained in Rust.
- **Pro RL `v3` / `v3.2` / `v3.5` (`rl_v3.rs`, `rl_weights_v3.rs`, `rl_v4.rs`, `rl_weights_v4.rs`)**:
  - Introduced `FastState` bitmask simulator (`u32` hands, `failed_beat` deduction, canonical suit-shifted 128-dim features), `ProBidNetV3` (32-dim MLP predicting `expected_pts`), `choose_trump_fast`, `ProValueNetV3`, PIMC determinization, and a **4-trick exact Alpha-Beta endgame solver**.
  - Limitation: Bidding was static (`next_bid <= max_willing`, no bluffing, no auction-history memory, no match-score awareness) and card play relied on static board features without full trick-by-trick sequence memory.

### Phase B: High-Speed Rust-to-Python FFI (`twenty_nine_sim_ffi`)
- Built `crates/twenty_nine_sim_ffi/src/lib.rs` compiled as `libtwenty_nine_sim_ffi.so` (`~424 KB`, `GLIBC <= 2.34`) for Kaggle Dual-GPU (`GPU T4 x2`) training at **2,000–2,300+ hands/sec**.
- Extended with 3 Stage 2 C-ABI hooks:
  - `sim_load_contracts`: loads pre-decided auctions, all 11 trump styles, 7th-card trump, and `1x/2x/4x` stakes into `FastState`.
  - `sim_step_playout`: runs exact 8-trick playouts via frozen Stage 1 GPU workers without auto-resetting.
  - `sim_v3_baseline_actions`: exposes exact rule-aware `ProBidNetV3` + `choose_trump_fast` as a fast anchor opponent.

### Phase C: Stage 1 Grandmaster Card-Play (`ProQNetV55` / `rl_weights_v55.rs`)
- **Architecture**: `nn.GRU(16 → 96)` over `(32, 16)` trick-by-trick card history + `128`-dim canonical board → `224 → 384 → 192` Residual LayerNorm + SiLU → legal-masked Dueling Q (`33` actions: `0..31` canonical shifted cards + `32 = ShowTrump`).
- **Trained Weights**: `best_pro_rl_v55.pt` (`958 KB`) / `rl_weights_v55.rs` (`899 KB`).
- **Verified Benchmarks**:
  - vs Production `v3.2`: **`Win = 56.70% | SetPts/100 = +14.88`**
  - vs Normal Bot: **`Win = 60.96% | SetPts/100 = +25.21`**

### Phase D: Stage 2 Joint Bidding, 11-Style Trump & Double/Redouble (`v6.0` → `v6.4`)
Evaluated end-to-end by **frozen Stage 1 `ProQNetV55`** on paired duplicate deals (seat-swapped fairness).

| Version | Hands Trained | Key Changes / Findings | Final Duplicate Eval vs `ProBidNetV3` |
| :--- | :--- | :--- | :--- |
| **`v6.0`** | 2.56M (19.3 min) | Cold-start PPO; discovered NT-Reverse exploit (`Rev=92.3%, NT=68.9%`) | Full: `Win=46.76% \| SetPts/100=+0.29` (discarded) |
| **`v6.1`** | 2.56M (24.8 min) | Added 15s `ProBidNetV3` warm-start, `allow_reverse`/`allow_joker` rule bits, 11-action trump mask, KL anchor | **Full (40k)**: `Win=51.45% \| SetPts/100=+4.85` (`Bid=16.91, Rev=45.3%, NT=1.5%, 7th=1.3%, Dbl=5.9%`)<br>**Classic (20k)**: `Win=50.38% \| SetPts/100=+7.58` (`Bid=16.60, Dbl=8.4%`) |
| **`v6.2`** | 10.24M ready | Fixed `pair_skill` reward cross-contamination, unified 3 PPO loops into 1 single-pass loss, added 25-upd Critic-only warmup | Superseded by `v6.3` / `v6.4` |
| **`v6.3`** | 10.24M ready | Fixed 6 deep bugs: full 4-player DoubleWindow + League Redouble + doubler-seat signal; fixed 7th-card leak in Rust FFI & Python; 4-bit phase one-hot; `auc_gru` + Redouble warm-start; rule-aware `allow_reverse` FFI; 15% `TrickyV3` bluff/jump opponents; 4,096-hand evals | Upgraded into `v6.4` |
| **`v6.4`** (Current) | 10.24M ready (~75–85 min on 2x T4) | **Match-Score-Aware (`87-dim`)**: adds `my_score`, `opp_score`, `danger_zone`, `match_point` + **Set-Win-Probability Delta reward** (`±6` set rules) + Clutch Score Adaptation Audit (`-5`, `0`, `+5`) | Ready to train on Kaggle `GPU T4 x2` |

---

## 2. Current `v6.4` Architecture (`ProBidTrumpNetV64`)

- **Size**: `~125,000` parameters (`~125 KB` when quantized to `int8` in Rust).
- **Inputs**:
  - `auc_seq`: `(20, 12)` auction history sequence → `nn.GRU(12 → 48)`
  - `board`: `87`-dim vector:
    - `[0..32]`: 4-card hand one-hot (`suit << 3 | rank`, rank `0=J, 1=9, 2=A, 3=10, 4=K, 5=Q, 6=8, 7=7`)
    - `[32..60]`: 4 suits × 7 features (`len, pts, has_J, has_9, has_7, has_8, has_KQ`)
    - `[60..75]`: `cur_bid`, `no_bid`, relative seat from dealer (4), `no_bidder`, relative bidder seat (4), `is_first_leader`, `passed_cnt`, `tot_pts`, `tot_J`
    - `[75..79]`: 4-bit phase one-hot (`[is_bid, is_trump, is_dbl, is_rdbl]`)
    - `[79..81]`: 2-bit doubler relative seat (`[doubler_is_LHO, doubler_is_RHO]`, active in Redouble)
    - `[81..83]`: 2-bit room rule toggles (`allow_reverse`, `allow_joker`)
    - `[83..87]`: 4-dim match score (`my_score/6`, `opp_score/6`, `danger_zone`, `match_point`)
- **Trunk**: `135 → 256 (LN+SiLU) → 192 (LN+SiLU + skip)`
- **Heads**: `bid_head(14)` (`Pass`, `16..28`), `trump_head(11)` (`0..3` Suit Straight, `4..7` Suit Rev, `8` NT Straight, `9` NT Rev, `10` 7th-Card), `dbl_head(2)` (`Pass`, `Double/Redouble`), `val_head(1)`.

---

## 3. Whole-Codebase Statistics (`twenty_nine_rust`)

### Source Code Summary (excluding `target/`, `Cargo.lock`, and binary media/WASM assets)
- **Total Source Files**: `54` files
- **Total Source Lines**: `37,571` lines (`2072.3 KB`)
- **Binary / Media / WASM / Lock Assets**: `307` files (`26087.5 KB`, including `.wasm` builds, 250 `.png` card/avatar assets, 44 `.svg`, 10 `.ttf` fonts)

#### By Crate / Directory (Source Code Only)
| Crate / Folder | Files | Lines | Size |
| :--- | ---: | ---: | ---: |
| `crates/twenty_nine_core` | 15 | 18,840 | 1316.4 KB |
| `crates/twenty_nine_slint` | 7 | 8,753 | 370.5 KB |
| `cf_deploy` | 8 | 4,988 | 189.5 KB |
| `crates/twenty_nine_client` | 9 | 2,886 | 121.1 KB |
| `crates/twenty_nine_server` | 7 | 779 | 26.2 KB |
| `crates/twenty_nine_sim_ffi` | 2 | 642 | 24.0 KB |
| `crates/twenty_nine_cf_wasm` | 2 | 550 | 19.2 KB |
| `README.md` | 1 | 68 | 4.1 KB |
| `Cargo.toml` | 1 | 31 | 0.7 KB |
| `index.html` | 1 | 27 | 0.6 KB |
| `Trunk.toml` | 1 | 7 | 0.1 KB |

#### By File Extension (Source Code Only)
| Extension | Files | Lines | Size |
| :--- | ---: | ---: | ---: |
| `.rs` | 35 | 28,336 | 1690.0 KB |
| `.slint` | 1 | 3,991 | 183.4 KB |
| `.js` | 3 | 3,454 | 138.9 KB |
| `.json` | 3 | 1,411 | 47.3 KB |
| `.toml` | 9 | 181 | 5.0 KB |
| `.html` | 2 | 130 | 3.6 KB |
| `.md` | 1 | 68 | 4.1 KB |

---

## 4. Next Steps After `v6.4` Finishes Training

1. **Inspect `v6.4` Final Evals**: Check `40k Full (0-0)`, `20k Classic (0-0)`, and the `Clutch Score Adaptation Audit` (`-5`, `0`, `+5`) to confirm both raw Elo gain and dynamic style shifting.
2. **Stage 3 Card-Play Co-Adaptation (~2–3M hands, ~15–20 min on Dual T4)**: Freeze `v6.4` and fine-tune `ProQNetV55` on `v6.4`'s actual contracts (Reverse, 7th-Card, Doubled/Redoubled, bluffs) to close `v5.5`'s Reverse-defense blind spot.
3. **Production Integration in `twenty_nine_core`**:
   - Wire `rl_weights_v64_bid_trump.rs` into `GamePhase::Bidding`, `SelectTrump`, and `DoubleWindow` (with optional `T ≈ 0.35–0.45` soft top-2 sampling on close moves for human-like variety).
   - Wire `rl_weights_v55.rs` (or Stage 3 weights) into `GamePhase::Playing` for Tricks 1–4, paired with the existing **4-trick exact Alpha-Beta endgame solver** for Tricks 5–8.
