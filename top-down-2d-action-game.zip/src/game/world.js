// ===== world.js — seeded procedural city: tiles, districts, buildings, props, collision, A* =====
import { mulberry32, SpatialHash, clamp, hash2 } from './util.js';
import { STREET_V, STREET_H } from './data.js';

export const TS = 32, CT = 16, NB = 11, NT = 192, WS = NT * TS;
export const T = { WATER: 0, GRASS: 1, ROAD: 2, SIDEWALK: 3, SAND: 4, BUILDING: 5, PLAZA: 6, PARKING: 7, WOOD: 8, BRIDGE: 9, DIRT: 10, PATH: 11, QUAY: 12, BRIDGEW: 13 };
export const M = { V: 1, H: 2, XW: 4, HWY: 8 };
export const PROPDEF = {
  lamp: { r: 5, hp: 80, solid: 1 }, crate: { r: 12, hp: 35, solid: 1, low: 1 }, barrel: { r: 9, hp: 22, solid: 1, expl: 1 }, sign: { r: 4, hp: 20, solid: 1 },
  fence: { r: 6, hp: 24, solid: 1, low: 1 }, tree: { r: 7, hp: 1e9, solid: 1 }, palm: { r: 6, hp: 1e9, solid: 1 }, bench: { r: 10, hp: 60, solid: 1, low: 1 },
  bin: { r: 8, hp: 40, solid: 1, low: 1 }, hydrant: { r: 6, hp: 45, solid: 1 }, cone: { r: 6, hp: 4, solid: 0 }, umbrella: { r: 0, hp: 1e9, solid: 0 },
  fountain: { r: 30, hp: 1e9, solid: 1 }, pump: { r: 10, hp: 90, solid: 1, expl: 1 }, hay: { r: 14, hp: 40, solid: 1, low: 1 }, shard: { r: 0, hp: 1e9, solid: 0 },
  ramp: { r: 0, hp: 1e9, solid: 0 }, spike: { r: 0, hp: 1e9, solid: 0 }, rock: { r: 10, hp: 1e9, solid: 1, low: 1 },
};
const SPECIAL = { '1,4': 'safe', '5,5': 'bank', '6,5': 'police', '4,4': 'news', '2,9': 'garage', '4,9': 'kess', '5,9': 'viper', '7,6': 'hospital', '8,3': 'casino', '6,4': 'gunblock', '10,4': 'hotel', '10,6': 'club', '5,10': 'wh', '2,5': 'apts', '7,5': 'shops', '1,10': 'cranes', '10,1': 'light', '6,9': 'arena', '7,4': 'park' };
const DT_COL = ['#3a4a63', '#4b3f66', '#2f5b6b', '#5a4a4a', '#33415c', '#2c6a6a', '#63406b', '#4c5563'];
const HOUSE = ['#c9b79c', '#a7b8c9', '#c9a7a7', '#b5c9a7', '#d9d0b0'];
const ROOFS = ['#7a4b3a', '#4a5a6a', '#5a3f3a', '#3f4a3a'];
const IND = ['#6b6f73', '#7a6f5c', '#5f6b73', '#70655a'];
const CONT = ['#b5442d', '#2d6fb5', '#d49b2a', '#3a8a5a', '#7a3ab5', '#c2c2c2'];
const SHOPS = {
  shop_burger: ['BURGER BARN', 'TIDE DINER', 'LUCKY NOODLE'], shop_mart: ['CORNER MART', '24/7 MINI', 'QUICKSTOP'], shop_clothes: ['THREADS', 'NEON WEAR', 'STITCH & CO'],
  shop_gun: ['GUN DEN', 'BIG IRON'], bar: ['NIGHT OWL', 'THE ANCHOR', 'LAST CALL'],
};
const NEONS = ['#ff4fd8', '#4fe0ff', '#ffe14a', '#7cff4f', '#ff6a3d', '#b36bff'];

export class World {
  constructor(seed = 1337) {
    this.seed = seed;
    this.tiles = new Uint8Array(NT * NT); this.meta = new Uint8Array(NT * NT); this.bid = new Int16Array(NT * NT).fill(-1);
    this.buildings = []; this.props = []; this.propHash = new SpatialHash(64); this.pois = {}; this.parkSpots = []; this.chunks = new Map();
    this.turf = []; this.heat = new Float32Array(NB * NB); this.res = { x: 0, y: 0, nx: 0, ny: 0, hit: 0, prop: null }; this._q = [];
    this.generate();
    this.doorList = this.buildings.filter((b) => b.door).map((b) => b.door);
  }

  districtOf(bx, by) {
    if (bx >= 10) return 'beach';
    if (by <= 1) return 'outskirts';
    if (by >= 8 && bx <= 6) return 'docks';
    if (bx >= 4 && bx <= 8 && by >= 3 && by <= 7) return 'downtown';
    return 'suburbs';
  }
  districtAt(x, y) {
    const tx = clamp(Math.floor(x / TS), 0, NT - 1), ty = clamp(Math.floor(y / TS), 0, NT - 1);
    if (this.tiles[ty * NT + tx] === T.WATER && (tx >= 184 || ty >= 184)) return 'ocean';
    return this.districtOf(clamp(tx >> 4, 0, 10), clamp(ty >> 4, 0, 10));
  }
  blockAt(x, y) { return clamp(Math.floor(x / TS) >> 4, 0, 10) * NB + clamp(Math.floor(y / TS) >> 4, 0, 10); }
  streetAt(x, y) {
    const tx = clamp(Math.floor(x / TS), 0, NT - 1), ty = clamp(Math.floor(y / TS), 0, NT - 1), m = this.meta[ty * NT + tx], t = this.tiles[ty * NT + tx];
    if (t === T.ROAD || t === T.BRIDGE) { if (m & M.V && !(m & M.H)) return STREET_V[tx >> 4]; if (m & M.H && !(m & M.V)) return STREET_H[ty >> 4]; return STREET_V[tx >> 4] + ' / ' + STREET_H[ty >> 4]; }
    return STREET_V[clamp((tx - 2) >> 4, 0, 11)];
  }

  // ---------- generation ----------
  poi(key, x, y, name) { this.pois[key] = { x, y, name: name || key, key }; }
  fill(x, y, w, h, t) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const k = (y + j) * NT + x + i; if (x + i < NT && y + j < NT && this.tiles[k] !== T.WATER && this.tiles[k] !== T.BUILDING) this.tiles[k] = t; } }
  free(tx, ty) { if (tx < 0 || ty < 0 || tx >= NT || ty >= NT) return false; const t = this.tiles[ty * NT + tx]; return t === T.GRASS || t === T.SAND || t === T.PLAZA || t === T.PARKING || t === T.DIRT || t === T.SIDEWALK || t === T.PATH; }
  addProp(type, x, y, o) {
    const d = PROPDEF[type]; const p = { t: type, x, y, r: d.r, hp: d.hp, a: 0, dead: false, solid: d.solid, low: d.low, id: this.props.length, v: Math.floor(Math.random() * 4) };
    if (o) Object.assign(p, o); this.props.push(p); this.propHash.insert(p, x, y); return p;
  }
  propAtTile(type, tx, ty, o) { return this.addProp(type, tx * TS + TS / 2, ty * TS + TS / 2, o); }
  addBuilding(x, y, w, h, o = {}) {
    const b = { id: this.buildings.length, x, y, w, h, hgt: o.hgt || 20, color: o.color || '#555', roof: o.roof || null, kind: o.kind || 'shop', interior: o.interior || null, name: o.name || '', neon: o.neon || null, door: null, seed: Math.floor(Math.random() * 1e6), windows: o.windows !== false, rt: o.rt || null };
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const k = (y + j) * NT + x + i; this.tiles[k] = T.BUILDING; this.bid[k] = b.id; }
    if (b.interior || o.door) b.door = { x: (x + (w >> 1)) * TS + TS / 2, y: (y + h) * TS + TS / 2 };
    this.buildings.push(b); return b;
  }
  parking(x, y, w, h, spots = true) {
    this.fill(x, y, w, h, T.PARKING);
    if (spots) for (let j = 0; j < h; j += 3) for (let i = 0; i < w - 1; i += 2) this.parkSpots.push({ x: (x + i + 1) * TS, y: (y + j + 1.2) * TS, a: Math.PI / 2 });
  }
  scatter(type, n, x, y, w, h, rng, ok) {
    for (let k = 0; k < n; k++) for (let tries = 0; tries < 8; tries++) {
      const tx = x + Math.floor(rng() * w), ty = y + Math.floor(rng() * h);
      if (this.free(tx, ty) && (!ok || ok(this.tiles[ty * NT + tx]))) { this.addProp(type, tx * TS + 6 + rng() * 20, ty * TS + 6 + rng() * 20); break; }
    }
  }
  fenceLine(x0, y0, x1, y1, gap) {
    const n = Math.floor(Math.hypot(x1 - x0, y1 - y0) / 22);
    for (let i = 0; i <= n; i++) { const x = x0 + ((x1 - x0) * i) / n, y = y0 + ((y1 - y0) * i) / n; if (gap && gap(x, y)) continue; this.addProp('fence', x, y); }
  }
  pickShop(rng, d) {
    const l = d === 'downtown' ? ['shop_burger', 'shop_mart', 'shop_clothes', 'bar', 'shop_gun', 'shop_burger'] : d === 'beach' ? ['bar', 'shop_burger', 'shop_clothes'] : ['shop_mart', 'shop_burger', 'bar'];
    return l[Math.floor(rng() * l.length)];
  }
  shop(x, y, w, h, rng, d, o = {}) {
    const it = o.interior || this.pickShop(rng, d), nm = SHOPS[it][Math.floor(rng() * SHOPS[it].length)];
    return this.addBuilding(x, y, w, h, { kind: 'shop', hgt: o.hgt || 22, color: o.color || DT_COL[Math.floor(rng() * DT_COL.length)], interior: it, name: nm, neon: NEONS[Math.floor(rng() * NEONS.length)] });
  }

  generate() {
    const { tiles, meta } = this;
    // 1. base classification
    for (let y = 0; y < NT; y++) for (let x = 0; x < NT; x++) {
      const cx = x >> 4, cy = y >> 4, lx = x & 15, ly = y & 15, k = y * NT + x;
      const inV = lx < 4 && y < 180, inH = ly < 4 && x < 180;
      let t = T.GRASS, m = 0;
      if (inV || inH) { t = T.ROAD; if (inV) m |= M.V; if (inH) { m |= M.H; if (cy === 0) m |= M.HWY; } }
      else if (x >= 180 || y >= 180) {
        if (x >= 184 || y >= 184) t = T.WATER;
        else if (y >= 180 && x < 180) t = x < 112 ? T.QUAY : T.SAND;
        else t = x === 180 ? T.SIDEWALK : T.SAND;
        if (x >= 180 && y >= 180) t = T.WATER;
      } else {
        const bx = cx, by = cy;
        if (lx === 4 || lx === 15 || ly === 4 || ly === 15) t = by <= 1 ? T.GRASS : T.SIDEWALK; else t = T.GRASS;
      }
      tiles[k] = t; meta[k] = m;
    }
    // 2. canal (block column 3) with bridges
    for (let y = 36; y < 184; y++) for (let x = 55; x <= 57; x++) {
      const k = y * NT + x, ly = y & 15, cy = y >> 4;
      if (y >= 180) { tiles[k] = T.WATER; continue; }
      const isRoad = ly < 4, ring = ly === 4 || ly === 15, line = ly === 15 ? cy + 1 : cy;
      if (isRoad) tiles[k] = line >= 3 ? T.BRIDGE : T.ROAD; else if (ring) tiles[k] = line >= 3 && (ly === 4 ? cy >= 3 : cy + 1 >= 3) ? T.BRIDGEW : T.WATER; else tiles[k] = T.WATER;
    }
    // 3. piers & quay docks
    for (const by of [3, 6, 9]) for (let x = 180; x < 192; x++) for (let j = 0; j < 2; j++) tiles[(by * 16 + 8 + j) * NT + x] = T.WOOD;
    for (const bx of [1, 3, 5]) for (let y = 180; y < 190; y++) for (let i = 0; i < 2; i++) { if (bx === 3 && i === 0) continue; tiles[y * NT + bx * 16 + 8 + i] = T.WOOD; }
    // 4. blocks
    for (let by = 0; by < NB; by++) for (let bx = 0; bx < NB; bx++) { this.genBlock(bx, by); this.turf[bx * NB + by] = { downtown: 'vel', docks: 'vip', beach: 'sun' }[this.districtOf(bx, by)] || ''; }
    // 5. crosswalks
    for (let cy = 0; cy < 12; cy++) for (let cx = 0; cx < 12; cx++) {
      const x0 = cx * 16, y0 = cy * 16;
      for (let i = 0; i < 4; i++) {
        this.xw(x0 + i, y0 + 4, M.V); this.xw(x0 + i, y0 - 1, M.V); this.xw(x0 + 4, y0 + i, M.H); this.xw(x0 - 1, y0 + i, M.H);
      }
    }
    // 6. lamps, street furniture
    const rng = mulberry32(this.seed + 99);
    for (let by = 0; by < NB; by++) for (let bx = 0; bx < NB; bx++) {
      const L = (tx, ty) => { if (tx < NT && ty < NT && tiles[ty * NT + tx] === T.SIDEWALK) this.propAtTile('lamp', tx, ty); };
      const a = bx * 16 + 4, b = bx * 16 + 15, c = by * 16 + 4, d = by * 16 + 15;
      L(a, c); L(b, c); L(a, d); L(b, d); L(a + 5, c); L(a + 5, d); L(a, c + 5); L(b, c + 5);
      if (rng() < 0.6) { const tx = a + 2 + Math.floor(rng() * 8); if (tiles[c * NT + tx] === T.SIDEWALK) this.propAtTile(rng() < 0.5 ? 'hydrant' : 'bin', tx, c); }
      if (rng() < 0.4) { const ty = c + 2 + Math.floor(rng() * 8); if (tiles[ty * NT + a] === T.SIDEWALK) this.propAtTile('bench', a, ty); }
    }
    // 7. stunt ramps, shards, POIs
    [[40 * TS, 3 * TS, 0], [120 * TS, TS, Math.PI], [160 * TS + TS, 70 * TS, Math.PI / 2], [30 * TS, 176 * TS + 96, 0], [6 * 512 + 96, 70 * TS, -Math.PI / 2]].forEach(([x, y, a]) => this.addProp('ramp', x, y, { a }));
    let n = 0, guard = 0;
    while (n < 24 && guard++ < 4000) {
      const tx = 6 + Math.floor(rng() * 176), ty = 6 + Math.floor(rng() * 174), t = tiles[ty * NT + tx];
      if ((t === T.SAND || t === T.PLAZA || t === T.GRASS || t === T.WOOD || t === T.DIRT || t === T.QUAY) && (this.free(tx, ty) || t === T.WOOD || t === T.QUAY) && this.nearSolid(tx, ty) < 1) { this.propAtTile('shard', tx, ty); n++; }
    }
    this.poi('start', 4 * 512 + 256, 176 * TS + 96, 'Harbor Road');
    this.poi('pier', 189 * TS, 105 * TS, 'Sunset Pier');
    this.poi('raceStart', 6 * 512 + 96, 4 * 512 + 256, 'Race Start');
  }
  xw(x, y, bit) { if (x < 0 || y < 0 || x >= NT || y >= NT) return; const k = y * NT + x; if (this.tiles[k] === T.ROAD && (this.meta[k] & (M.V | M.H)) === bit) this.meta[k] |= M.XW; }
  nearSolid(tx, ty) { for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) { const t = this.tiles[(ty + j) * NT + tx + i]; if (t === T.BUILDING || t === T.WATER) return 1; } return 0; }

  genBlock(bx, by) {
    const d = this.districtOf(bx, by), rng = mulberry32(this.seed * 7919 + bx * 131 + by * 977);
    const R = (a, b) => a + Math.floor(rng() * (b - a + 1)), P = (a) => a[Math.floor(rng() * a.length)];
    let x0 = bx * CT + 5, y0 = by * CT + 5, w = 10;
    const sp = SPECIAL[bx + ',' + by];
    this.fill(x0, y0, 10, 10, { downtown: T.PLAZA, suburbs: T.GRASS, docks: T.PARKING, beach: T.SAND, outskirts: T.GRASS }[d]);
    if (bx === 3 && by >= 2) { for (let j = 0; j < 10; j++) this.fill(x0, y0 + j, 2, 1, T.GRASS); this.scatter('tree', 3, x0, y0, 2, 10, rng); x0 += 5; w = 5; }
    const O = { x0, y0, w, rng, R, P, d, bx, by };
    if (sp) { this.special(sp, O); return; }
    if (d === 'downtown') this.genDowntown(O);
    else if (d === 'suburbs') this.genSuburbs(O);
    else if (d === 'docks') this.genDocks(O);
    else if (d === 'beach') this.genBeach(O);
    else this.genOutskirts(O);
  }
  park(x0, y0, w, h, rng) {
    this.fill(x0, y0, w, h, T.GRASS);
    for (let i = 0; i < w; i++) this.fill(x0 + i, y0 + (h >> 1), 1, 1, T.PATH);
    for (let j = 0; j < h; j++) this.fill(x0 + (w >> 1), y0 + j, 1, 1, T.PATH);
    this.addProp('fountain', (x0 + (w >> 1) + 0.5) * TS, (y0 + (h >> 1) + 0.5) * TS);
    this.scatter('tree', 14, x0, y0, w, h, rng); this.scatter('bench', 4, x0, y0, w, h, rng);
  }
  genDowntown({ x0, y0, rng, R, P }) {
    const r = rng();
    if (r < 0.14) { this.park(x0, y0, 10, 10, rng); return; }
    if (r < 0.52) {
      const b = this.addBuilding(x0 + 1, y0 + 1, 8, 8, { kind: 'tower', hgt: R(44, 64), color: P(DT_COL), name: '', neon: P(NEONS) });
      if (rng() < 0.5) { b.interior = null; } return;
    }
    this.shop(x0, y0, 5, 4, rng, 'downtown'); this.shop(x0 + 5, y0, 5, 4, rng, 'downtown');
    this.addBuilding(x0, y0 + 5, 6, 5, { kind: 'tower', hgt: R(36, 52), color: P(DT_COL), neon: P(NEONS) });
    this.shop(x0 + 6, y0 + 5, 4, 5, rng, 'downtown', { hgt: 26 });
    this.scatter('crate', 2, x0, y0 + 4, 10, 1, rng);
  }
  genSuburbs({ x0, y0, w, rng, R, P }) {
    if (w === 10 && rng() < 0.2) {
      this.addBuilding(x0 + 1, y0 + 1, 8, 4, { kind: 'apt', hgt: 30, color: '#8c7f8f', interior: 'apartment', name: 'RESIDENCES', neon: null });
      this.parking(x0 + 1, y0 + 6, 8, 3); this.scatter('tree', 5, x0, y0, 10, 10, rng); return;
    }
    for (let j = 0; j < 2; j++) for (let i = 0; i < w / 5; i++) {
      const lx = x0 + i * 5, ly = y0 + j * 5, hw = R(3, 4);
      this.addBuilding(lx + 1, ly + 1, hw, 3, { kind: 'house', hgt: R(12, 18), color: P(HOUSE), roof: P(ROOFS), door: true, windows: true });
      this.fill(lx + 1, ly + 4, 2, 1, T.PARKING); this.parkSpots.push({ x: (lx + 2) * TS, y: (ly + 4.5) * TS, a: Math.PI / 2 });
      this.scatter('tree', 2, lx, ly, 5, 5, rng, (t) => t === T.GRASS);
      if (rng() < 0.45) this.fenceLine(lx * TS + 4, (ly + 5) * TS - 4, (lx + 5) * TS - 4, (ly + 5) * TS - 4, (x) => x > (lx + 1) * TS && x < (lx + 3) * TS);
    }
  }
  genDocks({ x0, y0, w, rng, R, P }) {
    const v = rng();
    if (v < 0.4 && w === 10) {
      this.addBuilding(x0, y0, 10, 4, { kind: 'warehouse', hgt: 24, color: P(IND), door: true }); this.addBuilding(x0, y0 + 6, 10, 4, { kind: 'warehouse', hgt: 22, color: P(IND), door: true });
      this.scatter('barrel', 4, x0, y0 + 4, 10, 2, rng); this.scatter('crate', 3, x0, y0 + 4, 10, 2, rng);
    } else if (v < 0.75) {
      for (let j = 0; j < 4; j++) for (let i = 0; i < Math.floor(w / 3); i++) if (rng() < 0.75) this.addBuilding(x0 + i * 3 + (j % 2), y0 + 1 + j * 2 + (rng() < 0.3 ? 1 : 0) * 0, 2, 1, { kind: 'container', hgt: 14, color: P(CONT), windows: false });
      this.scatter('barrel', 3, x0, y0, w, 10, rng);
    } else { this.parking(x0, y0, w, 10); this.scatter('crate', 3, x0, y0, w, 10, rng); this.fenceLine(x0 * TS, y0 * TS, (x0 + w) * TS, y0 * TS); }
  }
  genBeach({ x0, y0, rng, R, P, d }) {
    for (let j = 0; j < 10; j++) this.fill(x0 + 8, y0 + j, 2, 1, T.WOOD);
    if (rng() < 0.7) this.shop(x0 + 1, y0 + 1, 5, 3, rng, d, { hgt: 18 });
    if (rng() < 0.6) this.shop(x0 + 1, y0 + 6, 5, 3, rng, d, { hgt: 18 });
    this.scatter('umbrella', 6, x0, y0, 8, 10, rng, (t) => t === T.SAND); this.scatter('palm', 5, x0, y0, 8, 10, rng, (t) => t === T.SAND);
  }
  genOutskirts({ x0, y0, w, rng, R, P, bx, by }) {
    const v = rng();
    if (v < 0.35) {
      this.fill(x0, y0, 10, 10, T.DIRT); this.fill(x0 + 5, y0 + 3, 4, 2, T.GRASS);
      this.addBuilding(x0 + 1, y0 + 1, 5, 4, { kind: 'barn', hgt: 24, color: '#9b3a2a', roof: '#6b2a20', door: true, windows: false });
      this.addBuilding(x0 + 7, y0 + 1, 3, 3, { kind: 'house', hgt: 16, color: P(HOUSE), roof: P(ROOFS), door: true });
      this.addBuilding(x0 + 7, y0 + 5, 2, 2, { kind: 'silo', hgt: 42, color: '#9aa0a6', windows: false });
      this.scatter('hay', 5, x0, y0 + 5, 7, 5, rng); this.scatter('tree', 5, x0, y0, 10, 10, rng);
    } else if (v < 0.55 && by === 1) {
      this.parking(x0 + 1, y0 + 4, 8, 5, false); this.fill(x0 + 1, y0 + 4, 8, 5, T.PARKING);
      const b = this.addBuilding(x0 + 2, y0 + 1, 5, 3, { kind: 'shop', hgt: 16, color: '#cfd8dc', interior: 'shop_mart', name: 'GAS-N-GO', neon: '#ffe14a' });
      this.propAtTile('pump', x0 + 2, y0 + 6); this.propAtTile('pump', x0 + 4, y0 + 6); this.propAtTile('pump', x0 + 6, y0 + 6);
      this.parkSpots.push({ x: (x0 + 3) * TS, y: (y0 + 8) * TS, a: Math.PI / 2 }); void b;
    } else { this.scatter('tree', 30, x0, y0, 10, 10, rng); this.scatter('rock', 4, x0, y0, 10, 10, rng); }
  }

  // ----- hand-placed story blocks -----
  special(k, { x0, y0, rng, R, P, d }) {
    const B = (x, y, w, h, o) => this.addBuilding(x0 + x, y0 + y, w, h, o);
    const door = (key, b, name) => this.poi(key, b.door.x, b.door.y, name);
    switch (k) {
      case 'safe': {
        this.fill(x0, y0, 10, 10, T.GRASS);
        const b = B(1, 1, 8, 5, { kind: 'apt', hgt: 32, color: '#8a7f9a', interior: 'safehouse', name: 'HARBOR VIEW APTS', neon: '#4fe0ff' }); door('safe', b, 'Safehouse');
        this.parking(x0 + 1, y0 + 7, 8, 3, false); [0, 2, 4, 6].forEach((i) => this.parkSpots.push({ x: (x0 + 2 + i) * TS, y: (y0 + 8) * TS, a: Math.PI / 2 }));
        this.poi('safe_park', (x0 + 2) * TS, (y0 + 8) * TS, 'Garage'); this.scatter('tree', 6, x0, y0, 10, 10, rng, (t) => t === T.GRASS); break;
      }
      case 'bank': { const b = B(1, 1, 8, 6, { kind: 'civic', hgt: 44, color: '#586b8a', interior: 'bank', name: 'MERIDIAN SAVINGS', neon: '#4fe0ff' }); door('bank', b, 'Meridian Savings'); this.scatter('bin', 2, x0, y0 + 8, 10, 2, rng); break; }
      case 'police': { const b = B(1, 1, 8, 6, { kind: 'civic', hgt: 36, color: '#2a3f6b', interior: 'police', name: 'PMPD HEADQUARTERS', neon: '#4aa8ff' }); door('police', b, 'Police HQ'); this.parkSpots.push({ x: (x0 + 2) * TS, y: (y0 + 8.5) * TS, a: 0, cop: 1 }, { x: (x0 + 7) * TS, y: (y0 + 8.5) * TS, a: 0, cop: 1 }); break; }
      case 'news': { const b = B(2, 1, 6, 8, { kind: 'tower', hgt: 62, color: '#2f5b6b', interior: 'office', name: 'MERIDIAN LEDGER', neon: '#ffe14a' }); door('nina', b, 'Ledger Tower'); break; }
      case 'garage': {
        this.fill(x0, y0, 10, 10, T.PARKING);
        const b = B(1, 2, 7, 4, { kind: 'warehouse', hgt: 22, color: '#7a5d44', interior: 'garage', name: "GUS'S GARAGE", neon: '#ff6a3d' }); door('gus', b, "Gus's Garage");
        this.scatter('barrel', 3, x0, y0 + 6, 10, 3, rng); this.scatter('crate', 3, x0 + 8, y0, 2, 8, rng);
        this.parkSpots.push({ x: (x0 + 2) * TS, y: (y0 + 8) * TS, a: Math.PI / 2 }); break;
      }
      case 'kess': {
        this.fill(x0, y0, 10, 10, T.PARKING);
        B(2, 1, 6, 3, { kind: 'warehouse', hgt: 26, color: '#4a4f55', name: 'KESSLER FREIGHT', neon: '#ff3b5c' });
        B(0, 5, 2, 1, { kind: 'container', hgt: 14, color: '#b5442d', windows: false }); B(7, 6, 3, 1, { kind: 'container', hgt: 14, color: '#2d6fb5', windows: false }); B(3, 6, 2, 1, { kind: 'container', hgt: 14, color: '#d49b2a', windows: false });
        B(8, 4, 2, 1, { kind: 'container', hgt: 14, color: '#3a8a5a', windows: false });
        const px0 = x0 * TS - 6, py0 = y0 * TS - 6, px1 = (x0 + 10) * TS + 6, py1 = (y0 + 10) * TS + 6, gate = (x, y) => y > py1 - 10 && x > px0 + 4.2 * TS && x < px0 + 6.2 * TS;
        this.fenceLine(px0, py0, px1, py0); this.fenceLine(px0, py0, px0, py1); this.fenceLine(px1, py0, px1, py1); this.fenceLine(px0, py1, px1, py1, gate);
        this.scatter('barrel', 4, x0, y0 + 4, 10, 5, rng); this.scatter('crate', 3, x0, y0 + 4, 10, 5, rng);
        this.poi('kess', (x0 + 5) * TS, (y0 + 6.5) * TS, 'Kessler Freight'); this.poi('kess_gate', (x0 + 5) * TS, (y0 + 10.4) * TS, 'Freight Gate'); this.poi('ledger', (x0 + 9) * TS, (y0 + 2) * TS, 'Ledger'); break;
      }
      case 'viper': {
        this.fill(x0, y0, 10, 10, T.PARKING);
        const b = B(2, 2, 5, 4, { kind: 'shop', hgt: 18, color: '#3a5a3a', interior: 'bar', name: 'THE RUSTED EEL', neon: '#7cff4f' }); door('viper', b, 'The Rusted Eel');
        this.scatter('barrel', 3, x0, y0 + 6, 10, 3, rng); this.parkSpots.push({ x: (x0 + 8) * TS, y: (y0 + 3) * TS, a: 0 }); break;
      }
      case 'hospital': { const b = B(1, 1, 8, 6, { kind: 'civic', hgt: 34, color: '#d3d9e2', roof: '#eef2f7', interior: 'hospital', name: 'MERIDIAN GENERAL', neon: '#ff4f6a' }); door('hosp', b, 'Meridian General'); break; }
      case 'casino': { const b = B(1, 1, 8, 7, { kind: 'tower', hgt: 52, color: '#5b2f6b', interior: 'casino', name: 'GOLD COAST CASINO', neon: '#ffd24a' }); door('casino', b, 'Gold Coast Casino'); break; }
      case 'gunblock': {
        const a = B(0, 0, 4, 4, { kind: 'shop', hgt: 24, color: '#4c5563', interior: 'shop_gun', name: 'GUN DEN', neon: '#ff3b5c' }); door('gun', a, 'Gun Den');
        const c = B(5, 0, 5, 4, { kind: 'shop', hgt: 24, color: '#63406b', interior: 'shop_clothes', name: 'THREADS', neon: '#ff4fd8' }); door('clothes', c, 'Threads');
        B(0, 5, 10, 5, { kind: 'tower', hgt: 42, color: '#33415c', neon: '#4fe0ff' }); break;
      }
      case 'hotel': { this.fill(x0, y0, 8, 10, T.SAND); const b = B(1, 1, 6, 6, { kind: 'tower', hgt: 72, color: '#d9cdb8', roof: '#bfae92', name: 'SUNSET HOTEL', neon: '#ff9a3c', door: true }); door('hotel', b, 'Sunset Hotel'); for (let j = 0; j < 10; j++) this.fill(x0 + 8, y0 + j, 2, 1, T.WOOD); this.scatter('palm', 4, x0, y0 + 7, 8, 3, rng); break; }
      case 'club': {
        for (let j = 0; j < 10; j++) this.fill(x0 + 8, y0 + j, 2, 1, T.WOOD);
        const b = B(1, 2, 6, 4, { kind: 'shop', hgt: 20, color: '#4a2f6b', interior: 'bar', name: 'CLUB TIDE', neon: '#ff4fd8' }); door('p_club', b, 'Club Tide'); this.poi('club', (x0 + 9) * TS, (y0 + 5) * TS, 'Boardwalk'); this.scatter('umbrella', 6, x0, y0 + 6, 8, 4, rng); this.scatter('palm', 3, x0, y0, 8, 10, rng); break;
      }
      case 'wh': { this.fill(x0, y0, 10, 10, T.PARKING); const b = B(1, 1, 8, 5, { kind: 'warehouse', hgt: 24, color: '#5f6b73', name: 'TIDEWATER STORAGE', door: true }); door('p_wh', b, 'Dockside Warehouse'); this.scatter('crate', 5, x0, y0 + 6, 10, 4, rng); break; }
      case 'apts': { const b = B(1, 1, 8, 4, { kind: 'apt', hgt: 30, color: '#9a8a8a', interior: 'apartment', name: 'HARBORLINE APTS', neon: null }); door('p_apt', b, 'Harborline Apartments'); this.parking(x0 + 1, y0 + 6, 8, 3); this.scatter('tree', 5, x0, y0, 10, 10, rng); break; }
      case 'shops': {
        const a = B(0, 0, 4, 4, { kind: 'shop', hgt: 24, color: '#4b3f66', interior: 'shop_burger', name: 'LUCKY NOODLE', neon: '#ffe14a' }); door('p_shop', a, 'Lucky Noodle');
        this.shop(x0 + 4, y0, 3, 4, rng, d); this.shop(x0 + 7, y0, 3, 4, rng, d); B(0, 5, 10, 5, { kind: 'tower', hgt: 48, color: '#2f5b6b', neon: '#7cff4f' }); break;
      }
      case 'cranes': {
        this.fill(x0, y0, 10, 10, T.PARKING); B(0, 0, 2, 2, { kind: 'crane', hgt: 80, color: '#e0a526', windows: false }); B(8, 0, 2, 2, { kind: 'crane', hgt: 80, color: '#e0a526', windows: false });
        B(2, 0, 3, 1, { kind: 'container', hgt: 14, color: '#2d6fb5', windows: false }); B(6, 0, 2, 1, { kind: 'container', hgt: 14, color: '#b5442d', windows: false });
        this.scatter('barrel', 6, x0, y0 + 3, 10, 7, rng); this.scatter('crate', 5, x0, y0 + 3, 10, 7, rng);
        this.poi('cranes', (x0 + 5) * TS, (y0 + 6) * TS, 'The Cranes'); break;
      }
      case 'light': {
        this.fill(x0, y0, 10, 10, T.SAND); this.scatter('rock', 8, x0, y0, 10, 10, rng); this.scatter('palm', 3, x0, y0, 10, 10, rng);
        const b = B(4, 3, 2, 2, { kind: 'light', hgt: 96, color: '#ece7e0', roof: '#c0392b', windows: false, door: true }); door('light', b, 'Lighthouse'); this.fill(x0 + 4, y0 + 5, 2, 5, T.PATH); break;
      }
      case 'arena': { this.fill(x0, y0, 10, 10, T.PARKING); const b = B(1, 1, 8, 5, { kind: 'warehouse', hgt: 24, color: '#5a2a2a', interior: 'arena', name: 'THE PIT', neon: '#ff3b3b' }); door('arena', b, 'The Pit'); this.scatter('barrel', 3, x0, y0 + 7, 10, 3, rng); break; }
      case 'park': this.park(x0, y0, 10, 10, rng); this.poi('park', (x0 + 5) * TS, (y0 + 6) * TS, 'Central Park'); break;
      default: break;
    }
  }

  // ---------- queries & collision ----------
  tileAt(x, y) { const tx = Math.floor(x / TS), ty = Math.floor(y / TS); if (tx < 0 || ty < 0 || tx >= NT || ty >= NT) return T.BUILDING; return this.tiles[ty * NT + tx]; }
  metaAt(x, y) { const tx = Math.floor(x / TS), ty = Math.floor(y / TS); if (tx < 0 || ty < 0 || tx >= NT || ty >= NT) return 0; return this.meta[ty * NT + tx]; }
  solid(x, y) { return this.tileAt(x, y) === T.BUILDING; }
  isRoad(x, y) { const t = this.tileAt(x, y); return t === T.ROAD || t === T.BRIDGE; }
  solidTile(tx, ty) { return tx < 0 || ty < 0 || tx >= NT || ty >= NT || this.tiles[ty * NT + tx] === T.BUILDING; }
  buildingAt(x, y) { const tx = Math.floor(x / TS), ty = Math.floor(y / TS); if (tx < 0 || ty < 0 || tx >= NT || ty >= NT) return null; const i = this.bid[ty * NT + tx]; return i >= 0 && this.tiles[ty * NT + tx] === T.BUILDING ? this.buildings[i] : null; }
  /** push a circle out of solid tiles (and solid props). Result in this.res */
  pushCircle(x, y, r, props = true, vault = false) {
    const res = this.res; res.hit = 0; res.nx = 0; res.ny = 0; res.prop = null;
    const tx0 = Math.floor((x - r) / TS), tx1 = Math.floor((x + r) / TS), ty0 = Math.floor((y - r) / TS), ty1 = Math.floor((y + r) / TS);
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      if (!this.solidTile(tx, ty)) continue;
      const cx = clamp(x, tx * TS, tx * TS + TS), cy = clamp(y, ty * TS, ty * TS + TS), dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy;
      if (d2 >= r * r) continue;
      let nx, ny, pen;
      if (d2 > 1e-6) { const d = Math.sqrt(d2); nx = dx / d; ny = dy / d; pen = r - d; }
      else { const l = x - tx * TS, rr = tx * TS + TS - x, t = y - ty * TS, b = ty * TS + TS - y, m = Math.min(l, rr, t, b); if (m === l) { nx = -1; ny = 0; } else if (m === rr) { nx = 1; ny = 0; } else if (m === t) { nx = 0; ny = -1; } else { nx = 0; ny = 1; } pen = r + m; }
      x += nx * pen; y += ny * pen; res.hit++; res.nx = nx; res.ny = ny;
    }
    if (props) {
      const q = this._q; q.length = 0; this.propHash.query(x, y, r + 34, q);
      for (let i = 0; i < q.length; i++) {
        const p = q[i]; if (p.dead || !p.solid || (vault && p.low)) continue;
        const dx = x - p.x, dy = y - p.y, rr = r + p.r, d2 = dx * dx + dy * dy;
        if (d2 >= rr * rr) continue;
        const d = Math.sqrt(d2) || 0.01, nx = dx / d, ny = dy / d; x += nx * (rr - d); y += ny * (rr - d); res.hit++; res.nx = nx; res.ny = ny; res.prop = p;
      }
    }
    res.x = x; res.y = y; return res;
  }
  /** is the straight segment free of solid tiles? */
  lineClear(x0, y0, x1, y1) {
    const d = Math.hypot(x1 - x0, y1 - y0), n = Math.ceil(d / 14);
    for (let i = 1; i < n; i++) { const t = i / n; if (this.solid(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)) return false; }
    return true;
  }
  /** first solid hit along a ray; returns distance or max */
  raycast(x, y, dx, dy, max) { for (let d = 8; d < max; d += 8) if (this.solid(x + dx * d, y + dy * d)) return d; return max; }
  trafficLight(cx, cy, t, vertical) {
    const p = (t + ((cx * 7 + cy * 13) % 24)) % 24;
    if (vertical) return p < 9 ? 0 : p < 11 ? 1 : 2;
    return p >= 12 && p < 21 ? 0 : p >= 21 && p < 23 ? 1 : 2;
  }
  randomWalkable(x, y, r, types) {
    for (let k = 0; k < 14; k++) {
      const a = Math.random() * 6.283, d = Math.random() * r, px = x + Math.cos(a) * d, py = y + Math.sin(a) * d;
      if (px < 40 || py < 40 || px > WS - 40 || py > WS - 40) continue;
      const t = this.tileAt(px, py);
      if (types ? types.includes(t) : (t === T.SIDEWALK || t === T.PLAZA || t === T.PARKING || t === T.GRASS || t === T.SAND || t === T.PATH || t === T.DIRT || t === T.WOOD || t === T.QUAY)) return { x: px, y: py };
    }
    return null;
  }

  // ---------- A* ----------
  _cost(i, opt) {
    const t = this.tiles[i];
    switch (t) {
      case T.BUILDING: return Infinity;
      case T.WATER: return opt.swim ? 4 : Infinity;
      case T.ROAD: case T.BRIDGE: return this.meta[i] & M.XW ? 2 : (opt.road ? 2.2 : 6);
      case T.GRASS: return 1.15;
      default: return 1;
    }
  }
  nearestWalk(tx, ty, opt) {
    for (let r = 0; r <= 4; r++) for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) {
      const x = tx + i, y = ty + j; if (x < 0 || y < 0 || x >= NT || y >= NT) continue;
      if (this._cost(y * NT + x, opt) < Infinity) return y * NT + x;
    }
    return -1;
  }
  walkPx(x, y, opt) { const tx = Math.floor(x / TS), ty = Math.floor(y / TS); if (tx < 0 || ty < 0 || tx >= NT || ty >= NT) return false; return this._cost(ty * NT + tx, opt) < Infinity; }
  path(sx, sy, tx, ty, opt = {}) {
    const N = NT * NT;
    if (!this._g) { this._g = new Float32Array(N); this._cf = new Int32Array(N); this._st = new Uint32Array(N); this._cl = new Uint32Array(N); this._stamp = 0; this._hf = []; this._hi = []; }
    const stamp = ++this._stamp, g = this._g, cf = this._cf, st = this._st, cl = this._cl, hf = this._hf, hi = this._hi;
    hf.length = 0; hi.length = 0;
    let s = clamp(Math.floor(sy / TS), 0, NT - 1) * NT + clamp(Math.floor(sx / TS), 0, NT - 1), e = clamp(Math.floor(ty / TS), 0, NT - 1) * NT + clamp(Math.floor(tx / TS), 0, NT - 1);
    if (this._cost(e, opt) === Infinity) { e = this.nearestWalk(e % NT, Math.floor(e / NT), opt); if (e < 0) return null; }
    if (this._cost(s, opt) === Infinity) { s = this.nearestWalk(s % NT, Math.floor(s / NT), opt); if (s < 0) return null; }
    const ex = e % NT, ey = (e / NT) | 0;
    const push = (f, i) => { let k = hf.length; hf.push(f); hi.push(i); while (k > 0) { const p = (k - 1) >> 1; if (hf[p] <= f) break; hf[k] = hf[p]; hi[k] = hi[p]; k = p; } hf[k] = f; hi[k] = i; };
    const pop = () => {
      const top = hi[0], lf = hf.pop(), li = hi.pop(), n = hf.length;
      if (n > 0) { let k = 0; for (;;) { let c = 2 * k + 1; if (c >= n) break; if (c + 1 < n && hf[c + 1] < hf[c]) c++; if (hf[c] >= lf) break; hf[k] = hf[c]; hi[k] = hi[c]; k = c; } hf[k] = lf; hi[k] = li; }
      return top;
    };
    const H = (i) => { const dx = Math.abs((i % NT) - ex), dy = Math.abs(((i / NT) | 0) - ey); return Math.max(dx, dy) + 0.41 * Math.min(dx, dy); };
    g[s] = 0; st[s] = stamp; cf[s] = -1; push(H(s), s);
    let best = s, bestH = H(s), exp = 0; const max = opt.max || 700; let found = false;
    while (hf.length && exp < max) {
      const cur = pop(); if (cl[cur] === stamp) continue; cl[cur] = stamp; exp++;
      if (cur === e) { found = true; break; }
      const cx = cur % NT, cy = (cur / NT) | 0, h = H(cur); if (h < bestH) { bestH = h; best = cur; }
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue; const nx = cx + dx, ny = cy + dy; if (nx < 0 || ny < 0 || nx >= NT || ny >= NT) continue;
        const ni = ny * NT + nx, c = this._cost(ni, opt); if (c === Infinity || cl[ni] === stamp) continue;
        if (dx && dy && (this._cost(cy * NT + nx, opt) === Infinity || this._cost(ny * NT + cx, opt) === Infinity)) continue;
        const ng = g[cur] + c * (dx && dy ? 1.41 : 1);
        if (st[ni] !== stamp || ng < g[ni]) { st[ni] = stamp; g[ni] = ng; cf[ni] = cur; push(ng + H(ni), ni); }
      }
    }
    let n = found ? e : best; const out = [];
    while (n >= 0 && n !== s) { out.push({ x: (n % NT) * TS + TS / 2, y: ((n / NT) | 0) * TS + TS / 2 }); n = cf[n]; }
    out.reverse();
    // string-pull smoothing
    const sm = []; let ax = sx, ay = sy, i = 0;
    while (i < out.length) {
      let j = out.length - 1; while (j > i && !this._segWalk(ax, ay, out[j].x, out[j].y, opt)) j--;
      sm.push(out[j]); ax = out[j].x; ay = out[j].y; i = j + 1;
    }
    return sm;
  }
  _segWalk(x0, y0, x1, y1, opt) {
    const d = Math.hypot(x1 - x0, y1 - y0), n = Math.ceil(d / 10);
    for (let i = 1; i <= n; i++) { const t = i / n, x = x0 + (x1 - x0) * t, y = y0 + (y1 - y0) * t; if (!this.walkPx(x, y, opt) || !this.walkPx(x + 5, y + 5, opt) || !this.walkPx(x - 5, y - 5, opt) || !this.walkPx(x + 5, y - 5, opt) || !this.walkPx(x - 5, y + 5, opt)) return false; if (!opt.road && this.isRoad(x, y) && !(this.metaAt(x, y) & M.XW)) return false; }
    return true;
  }
  /** lane position helpers for traffic: returns centre of road line and lane offsets */
  hash(x, y) { return hash2(x, y, this.seed); }
}
