// ===== gfx.js — procedural art: chunk ground canvases, building/prop/vehicle sprites, character drawing =====
import { T, M, TS, CT, NT } from './world.js';
import { hash2, shade, clamp } from './util.js';

const PAL = {
  [T.GRASS]: ['#3d6a3a', '#41703d', '#386335', '#44733f'], [T.ROAD]: ['#3a3d45', '#3c3f47', '#383b43', '#3e4149'], [T.SIDEWALK]: ['#8c8e94', '#90929a', '#888a90', '#94969c'],
  [T.SAND]: ['#d6c288', '#dac78f', '#d1bd82', '#ddca94'], [T.PLAZA]: ['#74767f', '#787a83', '#70727b', '#7c7e87'], [T.PARKING]: ['#4a4d54', '#4d5057', '#474a51', '#50535a'],
  [T.WOOD]: ['#8a6038', '#926639', '#82592f', '#8e6338'], [T.DIRT]: ['#7a5c3c', '#7e6040', '#755838', '#82643f'], [T.PATH]: ['#a89a7a', '#ac9e7e', '#a4967a', '#b0a282'],
  [T.QUAY]: ['#6c7076', '#70747a', '#686c72', '#74787e'], [T.WATER]: ['#1b4a74', '#1d4f78', '#1a4670', '#205580'], [T.BUILDING]: ['#1c1d22', '#1c1d22', '#1c1d22', '#1c1d22'],
  [T.BRIDGE]: ['#454952', '#474b54', '#43474f', '#4a4e57'], [T.BRIDGEW]: ['#9a9ca2', '#9ea0a6', '#96989e', '#a2a4aa'],
};
export function rr(c, x, y, w, h, r) {
  c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r); c.lineTo(x + w, y + h - r); c.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  c.lineTo(x + r, y + h); c.quadraticCurveTo(x, y + h, x, y + h - r); c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath();
}
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h)); return c; };
export { mk as makeCanvas };

// ---------- ground chunks ----------
export function renderChunk(world, cx, cy, sc) {
  const S = CT * TS, cv = mk(S * sc, S * sc), c = cv.getContext('2d');
  c.setTransform(sc, 0, 0, sc, 0, 0);
  const T0 = (x, y) => (x < 0 || y < 0 || x >= NT || y >= NT ? T.WATER : world.tiles[y * NT + x]);
  const isRoad = (t) => t === T.ROAD || t === T.BRIDGE;
  for (let j = 0; j < CT; j++) for (let i = 0; i < CT; i++) {
    const tx = cx * CT + i, ty = cy * CT + j; if (tx >= NT || ty >= NT) continue;
    const t = world.tiles[ty * NT + tx], m = world.meta[ty * NT + tx], px = i * TS, py = j * TS, h = hash2(tx, ty, 5);
    c.fillStyle = PAL[t][Math.floor(h * 4)]; c.fillRect(px, py, TS, TS);
    switch (t) {
      case T.GRASS: for (let k = 0; k < 4; k++) { const hh = hash2(tx * 4 + k, ty, 9); c.fillStyle = hh > 0.5 ? 'rgba(130,190,100,.25)' : 'rgba(20,50,20,.25)'; c.fillRect(px + hh * 28, py + hash2(tx, ty * 4 + k, 3) * 28, 2, 3); } break;
      case T.SAND: c.fillStyle = 'rgba(150,120,70,.18)'; c.fillRect(px + h * 18, py + hash2(tx, ty, 2) * 26, 12, 1); c.fillRect(px + hash2(tx, ty, 4) * 18, py + hash2(tx, ty, 6) * 26, 8, 1); break;
      case T.SIDEWALK: case T.PLAZA: case T.BRIDGEW: case T.QUAY: case T.PATH:
        c.fillStyle = 'rgba(0,0,0,.13)'; c.fillRect(px, py, TS, 1); c.fillRect(px, py, 1, TS);
        c.fillStyle = '#4a4c53';
        if (isRoad(T0(tx, ty - 1))) c.fillRect(px, py, TS, 3); if (isRoad(T0(tx, ty + 1))) c.fillRect(px, py + TS - 3, TS, 3);
        if (isRoad(T0(tx - 1, ty))) c.fillRect(px, py, 3, TS); if (isRoad(T0(tx + 1, ty))) c.fillRect(px + TS - 3, py, 3, TS);
        if (t === T.QUAY) { c.fillStyle = '#d4b02a'; if (T0(tx, ty + 1) === T.WATER) c.fillRect(px, py + TS - 4, TS, 3); if (T0(tx + 1, ty) === T.WATER) c.fillRect(px + TS - 4, py, 3, TS); }
        if (t === T.BRIDGEW) bridgeRails(c, px, py, tx, ty, T0);
        break;
      case T.PARKING: c.fillStyle = 'rgba(230,230,230,.35)'; if ((tx & 1) === 0 && ty % 3 !== 2) c.fillRect(px, py + 3, 2, TS - 6); break;
      case T.WOOD: c.fillStyle = 'rgba(0,0,0,.25)'; for (let k = 0; k < 4; k++) c.fillRect(px, py + k * 8, TS, 1); break;
      case T.WATER: {
        c.fillStyle = 'rgba(180,225,255,.5)';
        if (T0(tx, ty - 1) !== T.WATER && T0(tx, ty - 1) !== T.WOOD) c.fillRect(px, py, TS, 3); if (T0(tx, ty + 1) !== T.WATER && T0(tx, ty + 1) !== T.WOOD) c.fillRect(px, py + TS - 3, TS, 3);
        if (T0(tx - 1, ty) !== T.WATER && T0(tx - 1, ty) !== T.WOOD) c.fillRect(px, py, 3, TS); if (T0(tx + 1, ty) !== T.WATER && T0(tx + 1, ty) !== T.WOOD) c.fillRect(px + TS - 3, py, 3, TS);
        break;
      }
      case T.ROAD: case T.BRIDGE: {
        const V = m & M.V, H = m & M.H;
        if (t === T.BRIDGE) bridgeRails(c, px, py, tx, ty, T0);
        if (V && H) break;
        const hw = m & M.HWY, lx = tx & 15, ly = ty & 15;
        if (m & M.XW) {
          c.fillStyle = 'rgba(235,235,235,.8)';
          if (V) for (let k = 0; k < 4; k++) c.fillRect(px + 3 + k * 7.5, py + 5, 5, TS - 10); else for (let k = 0; k < 4; k++) c.fillRect(px + 5, py + 3 + k * 7.5, TS - 10, 5);
          break;
        }
        if (V) {
          c.fillStyle = 'rgba(240,240,240,.45)'; if (lx === 0) c.fillRect(px + 4, py, 2, TS); if (lx === 3) c.fillRect(px + TS - 6, py, 2, TS);
          c.fillStyle = '#e7b923'; if (lx === 1 && ((ty & 1) === 0 || hw)) c.fillRect(px + TS - 3, py, 2, TS); if (lx === 2 && ((ty & 1) === 0 || hw)) c.fillRect(px + 1, py, 2, TS);
        } else if (H) {
          c.fillStyle = 'rgba(240,240,240,.45)'; if (ly === 0) c.fillRect(px, py + 4, TS, 2); if (ly === 3) c.fillRect(px, py + TS - 6, TS, 2);
          c.fillStyle = '#e7b923'; if (ly === 1 && ((tx & 1) === 0 || hw)) c.fillRect(px, py + TS - 3, TS, 2); if (ly === 2 && ((tx & 1) === 0 || hw)) c.fillRect(px, py + 1, TS, 2);
        }
        if (h > 0.9) { c.fillStyle = 'rgba(0,0,0,.18)'; c.fillRect(px + h * 20, py + h * 14, 6, 2); }
        break;
      }
      default: break;
    }
  }
  return { cx, cy, cv, ctx: c, sc, wet: null, last: 0 };
}
function bridgeRails(c, px, py, tx, ty, T0) {
  c.fillStyle = '#2a2c30';
  if (T0(tx, ty - 1) === T.WATER) { c.fillRect(px, py, TS, 4); c.fillStyle = '#9aa'; c.fillRect(px, py + 1, TS, 1); }
  if (T0(tx, ty + 1) === T.WATER) { c.fillStyle = '#2a2c30'; c.fillRect(px, py + TS - 4, TS, 4); c.fillStyle = '#9aa'; c.fillRect(px, py + TS - 3, TS, 1); }
}
/** road-only overlay used for wet-road effect, built lazily */
export function wetLayer(world, ch) {
  if (ch.wet) return ch.wet;
  const S = CT * TS, cv = mk(S * ch.sc, S * ch.sc), c = cv.getContext('2d'); c.setTransform(ch.sc, 0, 0, ch.sc, 0, 0);
  for (let j = 0; j < CT; j++) for (let i = 0; i < CT; i++) {
    const tx = ch.cx * CT + i, ty = ch.cy * CT + j; if (tx >= NT || ty >= NT) continue;
    const t = world.tiles[ty * NT + tx];
    if (t === T.ROAD || t === T.BRIDGE || t === T.PARKING) { c.fillStyle = '#0b1a2e'; c.fillRect(i * TS, j * TS, TS, TS); if (hash2(tx, ty, 1) > 0.7) { c.fillStyle = 'rgba(120,170,220,.5)'; c.beginPath(); c.ellipse(i * TS + 16, j * TS + 16, 10 + hash2(tx, ty, 2) * 6, 5, 0, 0, 6.3); c.fill(); } }
  }
  ch.wet = cv; return cv;
}
export function paintOnChunks(world, x0, y0, x1, y1, fn) {
  const a = world.chunks.get(Math.floor(x0 / 512) * 64 + Math.floor(y0 / 512)), b = world.chunks.get(Math.floor(x1 / 512) * 64 + Math.floor(y1 / 512));
  for (const ch of a === b ? [a] : [a, b]) if (ch) { ch.ctx.save(); ch.ctx.translate(-ch.cx * 512, -ch.cy * 512); fn(ch.ctx); ch.ctx.restore(); }
}

// ---------- minimap overview (1 px per tile) ----------
export function buildOverview(world) {
  const cv = mk(NT, NT), c = cv.getContext('2d'), im = c.createImageData(NT, NT), d = im.data;
  const col = { [T.WATER]: [24, 66, 95], [T.GRASS]: [47, 90, 51], [T.ROAD]: [92, 97, 112], [T.SIDEWALK]: [122, 125, 134], [T.SAND]: [185, 165, 111], [T.PLAZA]: [105, 107, 117], [T.PARKING]: [75, 78, 88], [T.WOOD]: [122, 86, 52], [T.BRIDGE]: [110, 114, 128], [T.DIRT]: [110, 84, 56], [T.PATH]: [150, 140, 110], [T.QUAY]: [100, 104, 110], [T.BRIDGEW]: [130, 132, 140] };
  for (let i = 0; i < NT * NT; i++) {
    const t = world.tiles[i]; let r, g, b;
    if (t === T.BUILDING) { const bd = world.buildings[world.bid[i]]; const f = bd && bd.kind === 'civic' ? [140, 150, 190] : [64, 69, 84]; [r, g, b] = f; } else [r, g, b] = col[t];
    d[i * 4] = r; d[i * 4 + 1] = g; d[i * 4 + 2] = b; d[i * 4 + 3] = 255;
  }
  c.putImageData(im, 0, 0); return cv;
}

// ---------- buildings ----------
const spriteCache = new Map();
export function buildingSprite(b) {
  let s = spriteCache.get(b.id); if (s) return s;
  const w = b.w * TS, h = b.h * TS, H = b.hgt, base = mk(w, h + H), glow = mk(w, h + H), c = base.getContext('2d'), g = glow.getContext('2d');
  let seed = b.seed; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const wall = shade(b.color, -0.38), roof = b.roof || shade(b.color, 0.14);
  // wall (south face)
  const gr = c.createLinearGradient(0, h, 0, h + H); gr.addColorStop(0, shade(b.color, -0.2)); gr.addColorStop(1, shade(b.color, -0.5));
  c.fillStyle = gr; c.fillRect(0, h, w, H);
  if (b.kind === 'container') { c.fillStyle = 'rgba(0,0,0,.25)'; for (let x = 4; x < w; x += 6) c.fillRect(x, h, 1.5, H); }
  else if (b.windows !== false && H >= 12) {
    const cols = Math.max(1, Math.floor((w - 6) / 14)), rows = Math.max(1, Math.floor((H - 10) / 12)), dx = (w - cols * 14) / 2 + 3;
    for (let r = 0; r < rows; r++) for (let k = 0; k < cols; k++) {
      const x = dx + k * 14, y = h + 4 + r * 12, lit = rnd() < 0.5;
      if (b.door && r === rows - 1 && Math.abs(x + 4 - w / 2) < 14) continue;
      c.fillStyle = '#25384a'; c.fillRect(x, y, 8, 8); c.fillStyle = 'rgba(140,190,220,.25)'; c.fillRect(x, y, 8, 3);
      if (lit) { g.fillStyle = rnd() < 0.8 ? '#ffd98a' : '#9fe3ff'; g.globalAlpha = 0.85; g.fillRect(x, y, 8, 8); g.globalAlpha = 1; }
    }
  }
  // door + awning
  if (b.door) {
    const dx = (b.w >> 1) * TS + 16, dh = Math.min(H - 2, 22);
    c.fillStyle = '#111419'; c.fillRect(dx - 8, h + H - dh, 16, dh); c.fillStyle = 'rgba(255,220,150,.5)'; c.fillRect(dx - 6, h + H - dh + 2, 5, dh - 4);
    if (b.interior) { c.fillStyle = b.neon || '#c0392b'; c.fillRect(dx - 15, h + H - dh - 5, 30, 5); c.fillStyle = 'rgba(255,255,255,.3)'; for (let i = 0; i < 6; i++) c.fillRect(dx - 15 + i * 6, h + H - dh - 5, 3, 5); }
  }
  // sign
  if (b.name && H >= 16) {
    c.font = 'bold 11px sans-serif'; c.textAlign = 'center'; const tw = Math.min(w - 4, c.measureText(b.name).width + 10), sy = h + 3;
    c.fillStyle = '#0b0c10'; rr(c, w / 2 - tw / 2, sy, tw, 14, 3); c.fill();
    c.fillStyle = b.neon || '#fff'; c.fillText(b.name, w / 2, sy + 11, w - 8);
    g.font = c.font; g.textAlign = 'center'; g.shadowColor = b.neon || '#fff'; g.shadowBlur = 8; g.fillStyle = b.neon || '#fff'; g.fillText(b.name, w / 2, sy + 11, w - 8); g.shadowBlur = 0;
    b.neonY = sy + 7;
  }
  // roof
  c.fillStyle = roof; c.fillRect(0, 0, w, h);
  c.strokeStyle = shade(b.color, -0.5); c.lineWidth = 2; c.strokeRect(1, 1, w - 2, h - 2);
  c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(0, h - 3, w, 3);
  const inset = (col, m) => { c.fillStyle = col; c.fillRect(m, m, w - m * 2, h - m * 2); };
  switch (b.kind) {
    case 'tower': case 'civic': inset(shade(b.color, 0.28), 6); for (let i = 0; i < Math.floor(w * h / 1200) + 2; i++) { const x = 10 + rnd() * (w - 34), y = 10 + rnd() * (h - 34); c.fillStyle = '#9aa3ad'; c.fillRect(x, y, 14, 10); c.fillStyle = '#6b737c'; c.fillRect(x + 3, y + 3, 8, 4); }
      if (b.kind === 'tower' && w >= 150) { c.strokeStyle = '#ddd'; c.lineWidth = 2; c.beginPath(); c.arc(w / 2, h / 2, 22, 0, 6.3); c.stroke(); c.fillStyle = '#ddd'; c.font = 'bold 22px sans-serif'; c.textAlign = 'center'; c.fillText('H', w / 2, h / 2 + 8); }
      if (b.interior === 'hospital') { c.fillStyle = '#e53935'; c.fillRect(w / 2 - 6, h / 2 - 20, 12, 40); c.fillRect(w / 2 - 20, h / 2 - 6, 40, 12); }
      if (b.interior === 'police') { c.fillStyle = '#4aa8ff'; c.font = 'bold 18px sans-serif'; c.textAlign = 'center'; c.fillText('PMPD', w / 2, h / 2 + 6); }
      break;
    case 'warehouse': c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = 1; for (let x = 10; x < w; x += 10) { c.beginPath(); c.moveTo(x, 3); c.lineTo(x, h - 3); c.stroke(); } c.fillStyle = '#5b6168'; c.fillRect(w * 0.3, h * 0.3, 14, 14); break;
    case 'house': case 'apt': c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.moveTo(0, h / 2); c.lineTo(w, h / 2); c.lineTo(w, h); c.lineTo(0, h); c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.beginPath(); c.moveTo(0, h / 2); c.lineTo(w, h / 2); c.stroke(); if (b.kind === 'apt') { c.fillStyle = '#9aa3ad'; c.fillRect(10, 10, 14, 10); c.fillRect(w - 30, 12, 14, 10); } break;
    case 'barn': c.strokeStyle = 'rgba(0,0,0,.35)'; c.beginPath(); c.moveTo(w / 2, 0); c.lineTo(w / 2, h); c.stroke(); break;
    case 'silo': case 'light': c.fillStyle = b.kind === 'light' ? '#c0392b' : '#b0b6bc'; c.beginPath(); c.arc(w / 2, h / 2, Math.min(w, h) / 2 - 3, 0, 6.3); c.fill(); c.fillStyle = 'rgba(255,255,255,.35)'; c.beginPath(); c.arc(w / 2 - 4, h / 2 - 4, Math.min(w, h) / 4, 0, 6.3); c.fill(); if (b.kind === 'light') { g.fillStyle = '#fff6b0'; g.beginPath(); g.arc(w / 2, h / 2, 6, 0, 6.3); g.fill(); } break;
    case 'crane': c.strokeStyle = '#7a5a10'; c.lineWidth = 2; for (let i = 0; i < 6; i++) { c.beginPath(); c.moveTo(0, i * 12); c.lineTo(w, i * 12 + 12); c.stroke(); } c.fillStyle = '#c0392b'; c.fillRect(w / 2 - 6, h / 2 - 6, 12, 12); break;
    case 'container': c.fillStyle = 'rgba(0,0,0,.2)'; for (let x = 4; x < w; x += 6) c.fillRect(x, 2, 1.5, h - 4); break;
    default: inset(shade(b.color, 0.2), 4); c.fillStyle = '#9aa3ad'; c.fillRect(8, 8, 12, 8); break;
  }
  if (b.neon && b.interior) { g.fillStyle = b.neon; g.globalAlpha = 0.9; g.fillRect((b.w >> 1) * TS + 1, h + H - 27, 30, 5); g.globalAlpha = 1; }
  s = { base, glow }; spriteCache.set(b.id, s); return s;
}
export function clearSprites() { spriteCache.clear(); }

// ---------- props ----------
const propCache = new Map();
export function propSprite(t, v = 0) {
  const k = t + (t === 'barrel' || t === 'umbrella' || t === 'crate' ? v : 0); let s = propCache.get(k); if (s) return s;
  const S = t === 'tree' || t === 'palm' ? 64 : t === 'umbrella' ? 44 : t === 'fountain' ? 72 : 36, cv = mk(S, S), c = cv.getContext('2d'); c.translate(S / 2, S / 2);
  const dark = 'rgba(0,0,0,.45)';
  switch (t) {
    case 'lamp': c.fillStyle = '#2c2f36'; c.beginPath(); c.arc(0, 0, 4, 0, 6.3); c.fill(); c.fillStyle = '#ffe9a8'; c.beginPath(); c.arc(0, 0, 2, 0, 6.3); c.fill(); break;
    case 'crate': c.fillStyle = v % 2 ? '#a77b45' : '#b88a50'; c.fillRect(-12, -12, 24, 24); c.strokeStyle = '#6b4a22'; c.lineWidth = 2; c.strokeRect(-11, -11, 22, 22); c.beginPath(); c.moveTo(-11, -11); c.lineTo(11, 11); c.moveTo(11, -11); c.lineTo(-11, 11); c.stroke(); break;
    case 'barrel': c.fillStyle = ['#c0392b', '#2471a3', '#7d8a2e', '#555'][v % 4]; c.beginPath(); c.arc(0, 0, 9, 0, 6.3); c.fill(); c.strokeStyle = dark; c.lineWidth = 1.5; c.beginPath(); c.arc(0, 0, 6, 0, 6.3); c.stroke(); c.fillStyle = 'rgba(255,255,255,.3)'; c.beginPath(); c.arc(-3, -3, 3, 0, 6.3); c.fill(); break;
    case 'sign': c.fillStyle = '#555'; c.fillRect(-1.5, -1.5, 3, 3); c.fillStyle = '#2e7d32'; c.fillRect(-9, -7, 18, 5); break;
    case 'fence': c.fillStyle = '#7b7f86'; c.fillRect(-6, -2, 12, 4); c.fillStyle = '#555a61'; c.fillRect(-1, -4, 2, 8); break;
    case 'bench': c.fillStyle = '#6d4c2f'; c.fillRect(-10, -5, 20, 10); c.fillStyle = '#4a321e'; c.fillRect(-10, -5, 20, 2); break;
    case 'bin': c.fillStyle = '#3b6b4a'; c.beginPath(); c.arc(0, 0, 7, 0, 6.3); c.fill(); c.fillStyle = '#2a4d35'; c.beginPath(); c.arc(0, 0, 4.5, 0, 6.3); c.fill(); break;
    case 'hydrant': c.fillStyle = '#c62828'; c.beginPath(); c.arc(0, 0, 5, 0, 6.3); c.fill(); c.fillStyle = '#eee'; c.fillRect(-7, -1.5, 14, 3); break;
    case 'cone': c.fillStyle = '#ff6d00'; c.beginPath(); c.arc(0, 0, 6, 0, 6.3); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.arc(0, 0, 3, 0, 6.3); c.fill(); c.fillStyle = '#ff6d00'; c.beginPath(); c.arc(0, 0, 1.5, 0, 6.3); c.fill(); break;
    case 'pump': c.fillStyle = '#d32f2f'; c.fillRect(-7, -9, 14, 18); c.fillStyle = '#222'; c.fillRect(-5, -6, 10, 6); break;
    case 'hay': c.fillStyle = '#d4b04a'; c.beginPath(); c.arc(0, 0, 13, 0, 6.3); c.fill(); c.strokeStyle = '#9b7f2a'; c.lineWidth = 1.5; for (let r = 4; r < 13; r += 4) { c.beginPath(); c.arc(0, 0, r, 0, 6.3); c.stroke(); } break;
    case 'rock': c.fillStyle = '#7d8187'; c.beginPath(); c.moveTo(-9, 2); c.lineTo(-4, -8); c.lineTo(6, -7); c.lineTo(10, 3); c.lineTo(2, 9); c.lineTo(-6, 8); c.closePath(); c.fill(); c.fillStyle = 'rgba(255,255,255,.2)'; c.fillRect(-3, -6, 6, 3); break;
    case 'umbrella': { const col = ['#ff4f6a', '#ffd24a', '#4fe0ff', '#7cff4f'][v % 4]; for (let i = 0; i < 8; i++) { c.fillStyle = i % 2 ? col : '#fff'; c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, 18, (i * 6.283) / 8, ((i + 1) * 6.283) / 8); c.fill(); } c.fillStyle = '#333'; c.beginPath(); c.arc(0, 0, 1.5, 0, 6.3); c.fill(); break; }
    case 'fountain': c.fillStyle = '#9aa0a8'; c.beginPath(); c.arc(0, 0, 30, 0, 6.3); c.fill(); c.fillStyle = '#3fa0d0'; c.beginPath(); c.arc(0, 0, 25, 0, 6.3); c.fill(); c.fillStyle = '#9aa0a8'; c.beginPath(); c.arc(0, 0, 8, 0, 6.3); c.fill(); c.fillStyle = '#bfe8ff'; c.beginPath(); c.arc(0, 0, 4, 0, 6.3); c.fill(); break;
    case 'tree': for (let i = 0; i < 3; i++) { c.fillStyle = ['#2d5a2b', '#38702f', '#4a8a3a'][i]; c.beginPath(); c.arc(-3 + i * 2, -3 + i * 2, 26 - i * 6, 0, 6.3); c.fill(); } c.fillStyle = 'rgba(0,0,0,.2)'; c.beginPath(); c.arc(8, 8, 14, 0, 6.3); c.fill(); break;
    case 'palm': for (let i = 0; i < 7; i++) { const a = (i * 6.283) / 7; c.strokeStyle = i % 2 ? '#2f7a3a' : '#3d9447'; c.lineWidth = 6; c.lineCap = 'round'; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(a) * 26, Math.sin(a) * 26); c.stroke(); } c.fillStyle = '#6d4c2f'; c.beginPath(); c.arc(0, 0, 4, 0, 6.3); c.fill(); break;
    default: break;
  }
  propCache.set(k, cv); return cv;
}

// ---------- vehicle sprites (drawn facing +x at 2x resolution) ----------
const vehCache = new Map();
export function vehicleSprite(def, color) {
  const key = def.shape + color + def.len; let s = vehCache.get(key); if (s) return s;
  const L = def.len, W = def.wid, SC = 2, cv = mk((L + 10) * SC, (W + 10) * SC), c = cv.getContext('2d');
  c.scale(SC, SC); c.translate((L + 10) / 2, (W + 10) / 2);
  const sh = def.shape, dk = shade(color, -0.45), lt = shade(color, 0.3);
  const wheels = () => { c.fillStyle = '#0c0c0e'; for (const sx of [-0.3, 0.3]) for (const sy of [-1, 1]) { rr(c, L * sx - 5, sy * (W / 2) - (sy > 0 ? 1.5 : 2.5), 10, 4, 1.5); c.fill(); } };
  const lights = () => { c.fillStyle = '#fff3c0'; c.fillRect(L / 2 - 3, -W / 2 + 2, 3, 4); c.fillRect(L / 2 - 3, W / 2 - 6, 3, 4); c.fillStyle = '#c62828'; c.fillRect(-L / 2, -W / 2 + 2, 2.5, 4); c.fillRect(-L / 2, W / 2 - 6, 2.5, 4); };
  const body = (r = 6) => { const g = c.createLinearGradient(0, -W / 2, 0, W / 2); g.addColorStop(0, lt); g.addColorStop(0.5, color); g.addColorStop(1, dk); c.fillStyle = g; rr(c, -L / 2, -W / 2, L, W, r); c.fill(); c.strokeStyle = 'rgba(0,0,0,.55)'; c.lineWidth = 1; c.stroke(); };
  const glass = (x, w, inset = 3) => { c.fillStyle = '#16222e'; rr(c, x, -W / 2 + inset, w, W - inset * 2, 3); c.fill(); c.fillStyle = 'rgba(150,200,230,.25)'; c.fillRect(x + 1, -W / 2 + inset + 1, w - 2, 2); };
  const roofP = (x, w, inset = 4) => { c.fillStyle = shade(color, 0.12); rr(c, x, -W / 2 + inset, w, W - inset * 2, 3); c.fill(); };
  if (sh === 'moto') {
    c.fillStyle = '#0c0c0e'; rr(c, -L / 2, -2.5, 10, 5, 2); c.fill(); rr(c, L / 2 - 10, -2.5, 10, 5, 2); c.fill();
    c.fillStyle = color; rr(c, -L / 2 + 6, -3.5, L - 14, 7, 3); c.fill(); c.fillStyle = dk; c.fillRect(L / 2 - 12, -W / 2, 2.5, W); c.fillStyle = '#ddd'; c.fillRect(L / 2 - 2, -2, 2, 4);
  } else if (sh === 'bus' || sh === 'fire') {
    wheels(); body(5); c.fillStyle = sh === 'bus' ? '#cfd8dc' : '#eee'; c.fillRect(-L / 2 + 4, -W / 2 + 2, L - 14, 2); c.fillRect(-L / 2 + 4, W / 2 - 4, L - 14, 2);
    if (sh === 'bus') { c.fillStyle = '#16222e'; for (let x = -L / 2 + 8; x < L / 2 - 22; x += 12) { c.fillRect(x, -W / 2 + 4, 9, 4); c.fillRect(x, W / 2 - 8, 9, 4); } roofP(-L / 2 + 6, L - 28, 8); c.fillStyle = '#b0bec5'; c.fillRect(-10, -5, 12, 10); glass(L / 2 - 14, 11, 3); }
    else { c.fillStyle = '#bbb'; c.fillRect(-L / 2 + 6, -3, L - 36, 6); c.fillStyle = '#888'; for (let x = -L / 2 + 8; x < L / 2 - 30; x += 5) c.fillRect(x, -3, 1, 6); glass(L / 2 - 20, 12, 3); }
    lights();
  } else if (sh === 'van' || sh === 'swat' || sh === 'ambulance') {
    wheels(); body(5); roofP(-L / 2 + 5, L - 24, 4); c.fillStyle = 'rgba(0,0,0,.18)'; for (let x = -L / 2 + 10; x < L / 2 - 20; x += 8) c.fillRect(x, -W / 2 + 4, 1.5, W - 8);
    glass(L / 2 - 17, 10, 3);
    if (sh === 'ambulance') { c.fillStyle = '#d32f2f'; c.fillRect(-8, -2, 14, 4); c.fillRect(-3, -7, 4, 14); c.fillRect(-L / 2 + 4, -W / 2 + 1, L - 30, 2); }
    if (sh === 'swat') { c.fillStyle = '#d9dde3'; c.font = 'bold 9px sans-serif'; c.textAlign = 'center'; c.save(); c.rotate(-Math.PI / 2); c.fillText('SWAT', 0, -6); c.restore(); }
    lights();
  } else if (sh === 'army') {
    wheels(); body(4); c.fillStyle = shade(color, -0.2); c.fillRect(-L / 2 + 4, -W / 2 + 4, L - 20, W - 8); c.fillStyle = '#2d3a1c'; c.beginPath(); c.arc(-6, 0, 11, 0, 6.3); c.fill(); c.fillStyle = '#1a2310'; c.fillRect(-6, -2, 24, 4); glass(L / 2 - 12, 8, 4); lights();
  } else {
    wheels(); body(sh === 'compact' ? 9 : sh === 'sports' ? 10 : 6);
    if (sh === 'compact') { glass(-L * 0.12, L * 0.28, 4); roofP(-L * 0.3, L * 0.3, 4); glass(-L * 0.38, 5, 5); }
    else if (sh === 'sports') { c.fillStyle = shade(color, -0.2); c.fillRect(-L / 2 + 1, -W / 2 + 1, 5, W - 2); glass(-L * 0.02, L * 0.2, 4); roofP(-L * 0.3, L * 0.26, 5); c.fillStyle = '#fff'; c.globalAlpha = 0.5; c.fillRect(-L / 2 + 8, -2, L - 14, 1.5); c.fillRect(-L / 2 + 8, 1, L - 14, 1.5); c.globalAlpha = 1; }
    else if (sh === 'muscle') { c.fillStyle = '#eee'; c.globalAlpha = 0.55; c.fillRect(-L / 2 + 3, -4, L - 6, 3); c.fillRect(-L / 2 + 3, 1, L - 6, 3); c.globalAlpha = 1; glass(-L * 0.06, L * 0.2, 4); roofP(-L * 0.28, L * 0.24, 5); c.fillStyle = '#111'; c.fillRect(L * 0.28, -4, 8, 8); }
    else if (sh === 'pickup') { glass(L * 0.02, L * 0.18, 3); roofP(-L * 0.1, L * 0.14, 4); c.fillStyle = '#1b1c20'; c.fillRect(-L / 2 + 3, -W / 2 + 3, L * 0.38, W - 6); c.fillStyle = shade(color, -0.3); c.fillRect(-L / 2 + 3, -W / 2 + 3, 2, W - 6); }
    else { glass(-L * 0.08, L * 0.22, 3); roofP(-L * 0.3, L * 0.24, 4); glass(-L * 0.36, 4, 4); }
    if (def.taxi) { c.fillStyle = '#fff'; c.fillRect(-3, -4, 6, 8); c.fillStyle = '#111'; c.fillRect(-2, -3, 4, 6); c.fillStyle = '#111'; for (let i = 0; i < 4; i++) c.fillRect(-10 + i * 5, -W / 2 + 2, 2.5, 2.5); }
    if (sh === 'police') { c.fillStyle = '#f2f2f2'; c.fillRect(-L * 0.25, -W / 2 + 1, L * 0.3, 3); c.fillRect(-L * 0.25, W / 2 - 4, L * 0.3, 3); c.fillStyle = '#222'; c.fillRect(-2, -W / 2 + 6, 4, W - 12); }
    lights();
  }
  s = cv; vehCache.set(key, s); return s;
}

// ---------- characters ----------
export function drawActor(c, a, x, y, ang, time) {
  const L = a.look, wd = a.wdef;
  if (a.dead) {
    c.save(); c.translate(x, y);
    c.fillStyle = 'rgba(120,10,16,.65)'; c.beginPath(); c.ellipse(0, 0, 10 + Math.min(8, a.deadT * 3), 7 + Math.min(5, a.deadT * 2), 0, 0, 6.3); c.fill();
    c.rotate(a.deadA); c.fillStyle = L.pants; c.fillRect(-9, -4, 8, 3); c.fillRect(-9, 1.5, 8, 3);
    c.fillStyle = L.shirt; c.beginPath(); c.ellipse(0, 0, 5, 7.5, 0, 0, 6.3); c.fill(); c.fillStyle = L.skin; c.beginPath(); c.arc(5, 1, 4.2, 0, 6.3); c.fill(); c.fillRect(1, -8, 6, 2); c.fillRect(1, 6, 6, 2);
    c.restore(); return;
  }
  c.save(); c.translate(x, y);
  c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(1, 3, 9, 6, 0, 0, 6.3); c.fill();
  if (a.swim) { c.strokeStyle = 'rgba(255,255,255,.5)'; c.lineWidth = 1.5; c.beginPath(); c.ellipse(0, 0, 11 + Math.sin(time * 6) * 1.5, 8, 0, 0, 6.3); c.stroke(); }
  c.rotate(ang + (a.roll > 0 ? a.rollA : 0));
  const mv = a.moveAmt || 0, ph = a.anim, sw = Math.sin(ph) * 5 * mv, sc = a.crouch ? 0.88 : 1;
  c.scale(sc, sc);
  if (a.roll > 0) { c.fillStyle = L.shirt; c.beginPath(); c.arc(0, 0, 7, 0, 6.3); c.fill(); c.fillStyle = L.skin; c.beginPath(); c.arc(4, 0, 3.5, 0, 6.3); c.fill(); c.restore(); return; }
  if (!a.swim) { c.fillStyle = L.pants; c.beginPath(); c.ellipse(sw, -3.2, 4.5, 2.7, 0, 0, 6.3); c.fill(); c.beginPath(); c.ellipse(-sw, 3.2, 4.5, 2.7, 0, 0, 6.3); c.fill(); c.fillStyle = '#16161a'; c.fillRect(sw + 2, -4.5, 3, 2.5); c.fillRect(-sw + 2, 2, 3, 2.5); }
  // arms + weapon
  const gun = wd && (wd.type === 'gun' || wd.type === 'rocket') && !a.swim;
  c.fillStyle = L.skin;
  if (gun) {
    c.fillRect(2, -5.5, 9, 3); c.fillRect(2, 2.5, 9, 3);
    const big = wd.type === 'rocket' ? 16 : wd.n === 'Longshot .308' ? 20 : wd.rate > 6 ? 13 : 9;
    c.fillStyle = '#17181c'; c.fillRect(8, -1.6, big, 3.2); if (wd.type === 'rocket') { c.fillStyle = '#3b4a2a'; c.fillRect(6, -3, 14, 6); }
  } else if (wd && wd.type === 'melee' && a.wid !== 'fists') {
    const s = a.swing > 0 ? -1.2 + (1 - a.swing) * 2.4 : -0.4; c.save(); c.translate(3, 5); c.rotate(s); c.fillRect(0, -1.5, 8, 3);
    c.fillStyle = a.wid === 'bat' ? '#a2703a' : '#cfd4da'; c.fillRect(7, -1.5, a.wid === 'bat' ? 15 : 8, a.wid === 'bat' ? 3 : 2); c.restore(); c.fillRect(2, -5.5, 6, 3);
  } else if (wd && wd.type === 'throw') { c.fillRect(2, -5.5, 6, 3); c.fillRect(2, 2.5, 6, 3); c.fillStyle = a.wid === 'molotov' ? '#7b4' : '#3a4'; c.beginPath(); c.arc(9, 4, 3, 0, 6.3); c.fill(); }
  else { const p = a.swing > 0 ? (1 - a.swing) * 8 : 0; c.fillRect(1 + sw * 0.6 + (a.swing > 0 ? p : 0), -6, 6, 3); c.fillRect(1 - sw * 0.6, 3, 6, 3); }
  // torso
  c.fillStyle = L.shirt; c.beginPath(); c.ellipse(0, 0, 4.8, 7.5, 0, 0, 6.3); c.fill();
  c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 1; c.stroke();
  if (L.vest) { c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(-3, -5, 6, 10); }
  // head
  c.fillStyle = L.skin; c.beginPath(); c.arc(1, 0, 4.6, 0, 6.3); c.fill();
  const hs = L.style; c.fillStyle = L.hair;
  if (hs === 1) { c.beginPath(); c.arc(0.4, 0, 4.7, 1.2, 5.1); c.fill(); }
  else if (hs === 2) { c.beginPath(); c.arc(0.2, 0, 5, 1, 5.3); c.fill(); c.fillRect(-9, -2.5, 8, 5); }
  else if (hs === 3) { c.fillRect(-3, -1.3, 8, 2.6); }
  else if (hs === 4) { c.beginPath(); c.arc(1, 0, 5, 0, 6.3); c.fill(); c.fillStyle = shade(L.hair, -0.3); c.fillRect(4, -3.5, 4, 7); }
  if (L.shades) { c.fillStyle = '#05060a'; c.fillRect(3.2, -3.4, 2.2, 6.8); }
  c.restore();
  if (a.flash > 0 && wd) { c.save(); c.translate(x, y); c.rotate(ang); c.globalCompositeOperation = 'lighter'; const len = (wd.rate > 6 ? 13 : 9) + 8; c.fillStyle = '#ffd36a'; c.beginPath(); c.arc(len + 5, 0, 6 + Math.random() * 3, 0, 6.3); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.arc(len + 3, 0, 3, 0, 6.3); c.fill(); c.restore(); }
}
export function drawPreview(cv, look) {
  const c = cv.getContext('2d'); c.clearRect(0, 0, cv.width, cv.height); c.save(); c.translate(cv.width / 2, cv.height / 2); c.scale(cv.width / 40, cv.width / 40);
  c.fillStyle = 'rgba(255,255,255,.07)'; c.beginPath(); c.arc(0, 0, 18, 0, 6.3); c.fill();
  drawActor(c, { look, dead: false, anim: 0, moveAmt: 0, roll: 0, swing: 0, crouch: false, swim: false, wdef: null, flash: 0 }, 0, 0, -Math.PI / 2, 0); c.restore();
}
export { clamp };
