// ===== data.js — weapons, vehicles, factions, radio, shops, missions, story =====
export const TITLE = 'NEON TIDE';

export const WEAPONS = {
  fists:   { n: 'Fists', type: 'melee', dmg: 12, rate: 2.6, range: 34, arc: 1.2, knock: 90, sfx: 'punch', price: 0 },
  bat:     { n: 'Baseball Bat', type: 'melee', dmg: 34, rate: 1.4, range: 48, arc: 1.6, knock: 280, sfx: 'bat', price: 80 },
  knife:   { n: 'Combat Knife', type: 'melee', dmg: 28, rate: 3.2, range: 34, arc: 0.9, knock: 40, sfx: 'knife', price: 60 },
  pistol:  { n: 'M9 Sidearm', type: 'gun', dmg: 22, rate: 4.5, mag: 12, ammo: '9mm', spread: 0.03, bloom: 0.03, recoil: 0.5, speed: 1500, range: 720, reload: 1.1, price: 250, auto: false, sfx: 'pistol', pack: 24 },
  smg:     { n: 'Vandal SMG', type: 'gun', dmg: 13, rate: 12, mag: 30, ammo: '9mm', spread: 0.06, bloom: 0.014, recoil: 0.35, speed: 1500, range: 600, reload: 1.6, price: 900, auto: true, sfx: 'smg', pack: 60 },
  shotgun: { n: 'Breacher 12g', type: 'gun', dmg: 11, pellets: 8, rate: 1.25, mag: 6, ammo: 'shell', spread: 0.17, bloom: 0.0, recoil: 1.4, speed: 1300, range: 380, reload: 2.2, price: 700, auto: false, sfx: 'shotgun', pack: 12 },
  rifle:   { n: 'AR-7 Rifle', type: 'gun', dmg: 24, rate: 8.5, mag: 30, ammo: 'rifle', spread: 0.03, bloom: 0.01, recoil: 0.6, speed: 1800, range: 1000, reload: 2.0, price: 1800, auto: true, sfx: 'rifle', pack: 60 },
  sniper:  { n: 'Longshot .308', type: 'gun', dmg: 140, rate: 0.9, mag: 5, ammo: 'sniper', spread: 0.002, bloom: 0.0, recoil: 2.0, speed: 3400, range: 2400, reload: 2.6, price: 3000, auto: false, sfx: 'sniper', zoom: 0.55, pack: 10 },
  grenade: { n: 'Frag Grenade', type: 'throw', dmg: 170, radius: 130, fuse: 2.2, rate: 1, ammo: 'grenade', price: 150, sfx: 'throw', pack: 3 },
  molotov: { n: 'Molotov', type: 'throw', dmg: 0, radius: 90, fuse: 99, rate: 1, ammo: 'molotov', price: 90, sfx: 'throw', fire: true, pack: 3 },
  rocket:  { n: 'Hammer RPG', type: 'rocket', dmg: 260, radius: 180, rate: 0.6, mag: 1, ammo: 'rocket', spread: 0.01, recoil: 2.5, speed: 700, range: 1500, reload: 2.6, price: 4000, sfx: 'rocket', pack: 2 },
};
export const WEAPON_ORDER = ['fists', 'bat', 'knife', 'pistol', 'smg', 'shotgun', 'rifle', 'sniper', 'grenade', 'molotov', 'rocket'];
export const AMMO_MAX = { '9mm': 400, shell: 80, rifle: 300, sniper: 40, grenade: 15, molotov: 15, rocket: 10 };

// len/wid in px, vmax px/s, acc px/s², steer rad/s, grip (lateral decay), hp
export const VEHICLES = {
  compact:   { n: 'Pico Compact', len: 48, wid: 24, mass: 0.8, vmax: 370, acc: 520, brk: 900, steer: 2.7, grip: 7.5, hp: 220, shape: 'compact', colors: ['#e4572e', '#29b6f6', '#fdd835', '#9ccc65', '#ececec'], price: 6000 },
  sedan:     { n: 'Meridian Sedan', len: 58, wid: 26, mass: 1.0, vmax: 410, acc: 500, brk: 880, steer: 2.4, grip: 7, hp: 260, shape: 'sedan', colors: ['#546e7a', '#8d6e63', '#37474f', '#b0bec5', '#7b1fa2', '#1565c0'], price: 9000 },
  sports:    { n: 'Vortex GT', len: 58, wid: 25, mass: 0.95, vmax: 580, acc: 760, brk: 1100, steer: 2.5, grip: 6.2, hp: 230, shape: 'sports', colors: ['#d50000', '#ff6d00', '#00e5ff', '#f5f5f5', '#aa00ff'], price: 38000 },
  muscle:    { n: 'Brawler V8', len: 62, wid: 27, mass: 1.25, vmax: 530, acc: 700, brk: 950, steer: 2.2, grip: 5.4, hp: 320, shape: 'muscle', colors: ['#212121', '#b71c1c', '#1b5e20', '#ff8f00'], price: 24000 },
  van:       { n: 'Hauler Van', len: 66, wid: 30, mass: 1.7, vmax: 330, acc: 380, brk: 700, steer: 1.9, grip: 6.5, hp: 380, shape: 'van', colors: ['#eceff1', '#90a4ae', '#455a64', '#c62828'], price: 12000 },
  pickup:    { n: 'Ridge Pickup', len: 64, wid: 29, mass: 1.5, vmax: 380, acc: 440, brk: 760, steer: 2.0, grip: 6.5, hp: 360, shape: 'pickup', colors: ['#6d4c41', '#2e7d32', '#e0e0e0', '#1a237e'], price: 15000 },
  moto:      { n: 'Zip 250', len: 36, wid: 13, mass: 0.35, vmax: 560, acc: 820, brk: 900, steer: 3.4, grip: 6, hp: 110, shape: 'moto', colors: ['#ff1744', '#00e676', '#2979ff', '#212121'], price: 7500 },
  bus:       { n: 'Metro Bus', len: 118, wid: 34, mass: 4.0, vmax: 270, acc: 240, brk: 520, steer: 1.2, grip: 6, hp: 700, shape: 'bus', colors: ['#1976d2', '#00897b'], price: 0 },
  taxi:      { n: 'Yellow Cab', len: 58, wid: 26, mass: 1.0, vmax: 420, acc: 520, brk: 880, steer: 2.4, grip: 7, hp: 260, shape: 'sedan', colors: ['#ffc400'], price: 0, taxi: true },
  police:    { n: 'PMPD Cruiser', len: 60, wid: 27, mass: 1.15, vmax: 520, acc: 680, brk: 1000, steer: 2.5, grip: 6.8, hp: 320, shape: 'police', colors: ['#1b2a49'], price: 0, siren: true },
  ambulance: { n: 'Ambulance', len: 70, wid: 30, mass: 1.8, vmax: 420, acc: 480, brk: 800, steer: 2.0, grip: 6.5, hp: 400, shape: 'ambulance', colors: ['#f5f5f5'], price: 0, siren: true },
  swat:      { n: 'SWAT Van', len: 70, wid: 31, mass: 2.2, vmax: 440, acc: 520, brk: 850, steer: 1.9, grip: 6.5, hp: 600, shape: 'swat', colors: ['#14181f'], price: 0, siren: true },
  army:      { n: 'Bulwark APC', len: 92, wid: 38, mass: 5, vmax: 330, acc: 400, brk: 700, steer: 1.5, grip: 6.5, hp: 1400, shape: 'army', colors: ['#4b5a2f'], price: 0, turret: true },
  fire:      { n: 'Fire Engine', len: 104, wid: 34, mass: 4, vmax: 330, acc: 300, brk: 600, steer: 1.4, grip: 6, hp: 800, shape: 'fire', colors: ['#d32f2f'], price: 0, siren: true },
};
export const BUYABLE = ['compact', 'sedan', 'sports', 'muscle', 'van', 'pickup', 'moto'];
export const TRAFFIC_TYPES = ['compact', 'sedan', 'sedan', 'compact', 'pickup', 'van', 'muscle', 'sports', 'moto', 'taxi', 'taxi', 'bus'];

export const GANGS = [
  { id: 'vip', name: 'Chrome Vipers', color: '#7cff4f', home: 'docks' },
  { id: 'sun', name: 'Sunset Kings', color: '#ff9a3c', home: 'beach' },
  { id: 'vel', name: 'Velvet Hand', color: '#c86bff', home: 'downtown' },
];
export const FACTION_COLORS = { kes: '#ff3b5c', pd: '#4aa8ff', vip: '#7cff4f', sun: '#ff9a3c', vel: '#c86bff', pl: '#ffe14a', civ: '#bbbbbb' };

// ----- Character customisation -----
export const SKINS = ['#f1c9a5', '#e0ac80', '#c68642', '#8d5524', '#5c3a21'];
export const HAIR_COLORS = ['#1b1b1b', '#4a2f1b', '#a0522d', '#d9b36c', '#c8c8c8', '#ff4fd8', '#2fd0ff'];
export const SHIRTS = ['#d32f2f', '#1976d2', '#388e3c', '#fbc02d', '#eeeeee', '#212121', '#8e24aa', '#ef6c00'];
export const PANTS = ['#263238', '#37474f', '#1a237e', '#4e342e', '#616161', '#bdbdbd'];
export const HAIR_STYLES = ['Bald', 'Buzz', 'Long', 'Mohawk', 'Cap'];

// ----- Shops -----
export const SHOP_ITEMS = {
  shop_gun: { title: 'GUN DEN', items: [
    ...['bat', 'knife', 'pistol', 'smg', 'shotgun', 'rifle', 'sniper', 'grenade', 'molotov', 'rocket'].map((w) => ({ k: 'weapon', id: w, n: WEAPONS[w].n, price: WEAPONS[w].price, d: WEAPONS[w].type === 'melee' ? 'Melee' : 'Includes ' + WEAPONS[w].pack + ' rounds' })),
    { k: 'ammo', id: '9mm', n: '9mm Ammo ×60', price: 60, q: 60 }, { k: 'ammo', id: 'shell', n: 'Shells ×16', price: 70, q: 16 },
    { k: 'ammo', id: 'rifle', n: 'Rifle Ammo ×60', price: 110, q: 60 }, { k: 'ammo', id: 'sniper', n: '.308 Rounds ×10', price: 100, q: 10 }, { k: 'ammo', id: 'rocket', n: 'Rocket ×2', price: 400, q: 2 },
    { k: 'armor', n: 'Body Armor', price: 200, d: 'Restores armor to 100' },
  ] },
  shop_mart: { title: 'CORNER MART', items: [
    { k: 'heal', n: 'Candy Bar', price: 6, v: 12 }, { k: 'heal', n: 'Hot Sandwich', price: 18, v: 35 },
    { k: 'heal', n: 'First-Aid Kit', price: 90, v: 100 }, { k: 'armor', n: 'Flak Vest', price: 220, d: 'Restores armor to 100' },
    { k: 'ammo', id: '9mm', n: '9mm Ammo ×30', price: 40, q: 30 },
  ] },
  shop_burger: { title: 'BURGER BARN', items: [
    { k: 'heal', n: 'Plain Burger', price: 12, v: 28 }, { k: 'heal', n: 'Double Tide Burger', price: 24, v: 55 }, { k: 'heal', n: 'Family Bucket', price: 55, v: 100 },
  ] },
  bar: { title: 'THE BAR', items: [
    { k: 'drink', n: 'Neon Lager', price: 8, v: 6 }, { k: 'drink', n: 'Tidal Whiskey', price: 20, v: 12 }, { k: 'heal', n: 'Bar Snacks', price: 10, v: 15 },
  ] },
};
export const PROPERTIES = [
  { id: 'p_apt', n: 'Harborline Apartments', price: 15000, income: 220 },
  { id: 'p_shop', n: 'Lucky Noodle Franchise', price: 25000, income: 380 },
  { id: 'p_club', n: 'Club Tide', price: 60000, income: 900 },
  { id: 'p_wh', n: 'Dockside Warehouse', price: 90000, income: 1400 },
];
export const SKILLS = {
  driving: { n: 'Driving', d: 'Grip, top speed and drift control' },
  shooting: { n: 'Shooting', d: 'Tighter spread, faster reloads' },
  stamina: { n: 'Stamina', d: 'Bigger stamina bar, faster recovery' },
  stealth: { n: 'Stealth', d: 'Enemies notice you more slowly' },
};
export const SKILL_XP = [0, 100, 300, 650, 1100, 1800]; // xp thresholds → level 0..5
export const ABILITIES = [
  { lvl: 3, n: 'Tidal Focus', d: 'Press F to slow time. Charge it with stylish play.' },
  { lvl: 8, n: 'Dead Eye', d: 'Tidal Focus lasts longer and tightens aim.' },
  { lvl: 12, n: 'Ghost Driver', d: 'Police lose you faster while driving.' },
];

// ----- Radio -----
export const STATIONS = [
  { id: 'neon', n: 'NEON 98.3', genre: 'Synthwave', color: '#ff4fd8', bpm: 104, root: 45, dj: 'DJ Halcyon' },
  { id: 'dub', n: 'LOW TIDE 91.1', genre: 'Boom-Bap Lo-Fi', color: '#4fe0ff', bpm: 84, root: 48, dj: 'MC Driftwood' },
  { id: 'rust', n: 'RUSTWIRE 104.7', genre: 'Garage Rock', color: '#ffb347', bpm: 140, root: 40, dj: 'Big Rita' },
  { id: 'club', n: 'VORTEX 126', genre: 'Techno', color: '#7cff4f', bpm: 126, root: 43, dj: 'Voltage' },
];
export const ADS = [
  'Burger Barn: it is not a burger, it is a decision.',
  'Gold Coast Casino — the house always wins, but the lights are gorgeous.',
  'Gus\'s Garage: we fix what you broke, no questions, cash only.',
  'Meridian Savings: your money is safe. Mostly. Probably.',
  'Lucky Noodle: slurp now, regret nothing.',
  'Tide Insurance — covering everything except what actually happens.',
  'The Pit: bare-knuckle fights nightly. Bring a friend, or a dentist.',
  'Vortex Energy: drink it before it drinks you.',
];
export const DJ_LINES = [
  'Rain on the neon, folks. Perfect night to keep your windows up.',
  'Remember: if you hear sirens behind you, it is probably for you.',
  'This one goes out to everyone driving too fast with nowhere to be.',
  'Port Meridian: the city that never sleeps because it cannot afford the bed.',
  'Traffic on Harbor Road is a parking lot. Take the highway. Or do not. I am a radio.',
  'Weather says wet. Weather is always right about wet.',
];

// ----- Procedural news headlines (see phone.js) -----
export const STREET_V = ['Cannery Row', 'Ash St', 'Maple Ave', 'Canal St', 'Lantern Way', 'Central Ave', 'Pike St', 'Orchid Ave', 'Foundry Rd', 'Vine St', 'Ocean Drive', 'Seaside Drive'];
export const STREET_H = ['Highway 9', 'North Loop', 'Tulip Rd', 'Bishop St', 'Market St', 'Grand Blvd', 'Lexington', 'Dock St', 'Brass Rd', 'Anchor Rd', 'Foundry Way', 'Harbor Road'];
export const DISTRICT_NAMES = { downtown: 'Downtown', docks: 'Industrial Docks', suburbs: 'Greenfield Suburbs', beach: 'Sunset Beach', outskirts: 'The Outskirts', ocean: 'Open Water' };

export const TIPS = [
  'Hold E on a parked car to hotwire it. Stolen cars from drivers need no hotwire.',
  'Rain makes roads slick — brake early and use the handbrake to drift corners.',
  'Press F to enter Tidal Focus — drifts, near misses and kills charge your Style meter.',
  'Cops lose sight of you at night. Break line of sight, then change paint at Gus\'s Garage.',
  'Press C near a wall or crate to take cover. Right-click to aim, left-click to fire.',
  'Hold Q for the weapon wheel. Mouse wheel cycles weapons.',
  'Properties earn income every game day. Check the phone for listings.',
  'Gangs remember. Your reputation changes who shoots first and who sells to you.',
  'Collect all 24 Tide Shards scattered through the city for a special reward.',
  'Stunt jump ramps pay well. Hit them fast.',
  'F3 toggles the debug overlay. ` (backquote) opens the cheat menu.',
];

// ----- Story missions -----
// Step types: say, veh, goto, give, enemies, pickup, wanted, chase, stealth, escortcar, choice, enter, exit, hold,
// survive, race, boss, target, cash, ending, set. Positions: POI keys from world.pois, or '@name' for interior points.
export const MISSIONS = [
  { id: 'm1', title: 'Fresh Air', giver: 'Gus', at: 'start', auto: true, reward: { cash: 300 }, steps: [
    { t: 'say', cam: 'start', lines: [['Rook', 'Three years in Larkhaven. Port Meridian still smells like rain and gasoline.'], ['Gus (phone)', 'Rook! You are out. Get over to my garage on the docks. Do not walk it — find yourself a ride.'], ['Rook', 'Right. Somebody is about to lose a car.']] },
    { t: 'veh', veh: 'sedan', at: 'start', dx: 170, dy: -34, text: 'Find a car — hold E on it to hotwire' },
    { t: 'goto', at: 'gus', veh: true, text: 'Drive to Gus\'s Garage' },
    { t: 'say', cam: 'gus', lines: [['Gus', 'Look at you. Thin as a rail. Port Meridian changed, kid — Vance Kessler runs the docks now.'], ['Gus', 'His Vipers squeeze every bar on the strip. Take this. You will need it.']] },
    { t: 'give', w: 'pistol', ammo: 48 },
  ] },
  { id: 'm2', title: 'Old Debts', giver: 'Gus', at: 'gus', after: 'm1', reward: { cash: 600, rep: { vip: -15 } }, steps: [
    { t: 'say', lines: [['Gus', 'The Rusted Eel, down the street. Marco is behind on his vig and the Vipers are camped on him.'], ['Gus', 'Persuade them. Loudly.']] },
    { t: 'goto', at: 'viper', text: 'Head to The Rusted Eel' },
    { t: 'enemies', at: 'viper', n: 4, fac: 'vip', w: ['bat', 'pistol', 'pistol'], r: 150, text: 'Clear out the Vipers' },
    { t: 'pickup', at: 'viper', dx: 0, dy: 70, text: 'Grab the payoff bag' },
    { t: 'wanted', stars: 2, text: 'A witness called it in — lose the cops' },
    { t: 'goto', at: 'gus', text: 'Return to Gus' },
    { t: 'say', lines: [['Gus', 'Clean work. The kid still has it.']] },
  ] },
  { id: 'm3', title: 'Tail Light', giver: 'Gus', at: 'gus', after: 'm2', reward: { cash: 900 }, steps: [
    { t: 'say', lines: [['Gus', 'Kessler\'s courier ferries ledgers across town in a black Vortex GT. I want what is in the trunk.'], ['Gus', 'Take the Brawler out back. Do not let him reach the highway.']] },
    { t: 'veh', veh: 'muscle', at: 'gus', dx: 110, dy: 96, text: 'Take the muscle car', color: '#b71c1c' },
    { t: 'chase', veh: 'sports', at: 'cranes', color: '#111111', text: 'Run down the courier\'s Vortex GT' },
    { t: 'pickup', at: '@last', text: 'Grab the briefcase' },
    { t: 'goto', at: 'nina', text: 'Take the case to Nina Zhao at Ledger Tower' },
    { t: 'say', cam: 'nina', lines: [['Nina', 'Rook? Gus said you would come. Nina Zhao, Ledger crime desk. This is half a cipher — I need the other half from Kessler\'s own office.'], ['Nina', 'His freight yard on the docks. Guards, cameras. Be quiet.']] },
  ] },
  { id: 'm4', title: 'Quiet Hands', giver: 'Nina', at: 'nina', after: 'm3', reward: { cash: 1200 }, steps: [
    { t: 'goto', at: 'kess_gate', text: 'Go to Kessler Freight — stay unseen' },
    { t: 'stealth', at: 'kess', n: 5, pick: 'ledger', text: 'Reach the ledger without being seen' },
    { t: 'goto', at: 'kess_gate', text: 'Slip out through the gate' },
    { t: 'goto', at: 'nina', text: 'Deliver the ledger to Nina' },
    { t: 'say', lines: [['Nina', 'These account codes... payments to a "G.P." That cannot be Kessler. Someone sits above him.'], ['Rook', 'Find out who.']] },
  ] },
  { id: 'm5', title: 'Paper Trail', giver: 'Nina', at: 'nina', after: 'm4', reward: { cash: 1000 }, steps: [
    { t: 'say', lines: [['Nina', 'Somebody leaked that I am digging. Kessler\'s cars are circling the block — get me out of here!']] },
    { t: 'veh', veh: 'sedan', at: 'nina', dx: 60, dy: 90, text: 'Take the getaway car', color: '#37474f' },
    { t: 'escortcar', to: 'safe', chasers: 3, text: 'Drive Nina to the safehouse' },
    { t: 'say', cam: 'safe', lines: [['Nina', 'We make a decent team. Kessler\'s informant on the Sunset pier — a man called Tiny — can place the bank job on Kessler\'s books.']] },
  ] },
  { id: 'm6', title: 'The Informant', giver: 'Nina', at: 'safe', after: 'm5', reward: { cash: 800 }, steps: [
    { t: 'goto', at: 'pier', text: 'Meet Tiny at the end of the pier' },
    { t: 'say', cam: 'pier', lines: [['Tiny', 'You are Rook? Heh. Heard you were dead. Listen — Kessler never hit Meridian Savings. It was inside work. It was Gus, he —'], ['Tiny', 'Get down!']] },
    { t: 'enemies', at: 'pier', n: 5, fac: 'kes', w: ['smg', 'pistol'], r: 180, ring: true, text: 'Survive the ambush' },
    { t: 'say', lines: [['Tiny', 'They found me... I was about to tell you everything. Look — you can let me go, or you can make sure I never talk.']] },
    { t: 'choice', key: 'tiny', prompt: 'What do you do with Tiny?', options: [{ label: 'Spare Tiny — let him walk.', val: 'spared', rep: { vip: 5 } }, { label: 'Silence him — loose ends cost lives.', val: 'killed', cash: 2000 }] },
  ] },
  { id: 'm7', title: 'Meridian Savings', giver: 'Gus', at: 'gus', after: 'm6', reward: { cash: 5000 }, steps: [
    { t: 'say', lines: [['Gus', 'The bank, kid. The vault you took the fall for. Kessler\'s money sits in there. One clean job and we are even with him.'], ['Gus', 'Van is out back. In, out, thirty seconds.']] },
    { t: 'veh', veh: 'van', at: 'gus', dx: -110, dy: 100, text: 'Take the getaway van', color: '#455a64' },
    { t: 'goto', at: 'bank', veh: true, text: 'Drive to Meridian Savings' },
    { t: 'enter', poi: 'bank', text: 'Go inside the bank (E at the door)' },
    { t: 'enemies', at: '@floor', n: 3, fac: 'pd', w: ['pistol'], r: 90, guard: true, text: 'Neutralize the guards' },
    { t: 'hold', at: '@vault', secs: 4, text: 'Plant the charge on the vault' },
    { t: 'survive', secs: 24, at: '@floor', fac: 'pd', perWave: 2, every: 8, w: ['smg'], text: 'The alarm is tripping — hold the line' },
    { t: 'pickup', at: '@vault', dx: 0, dy: 40, text: 'Grab the cash' },
    { t: 'exit', text: 'Get out of the bank' },
    { t: 'wanted', stars: 3, text: 'Escape the police in the van' },
    { t: 'goto', at: 'gus', text: 'Return to the garage' },
    { t: 'say', lines: [['Gus', 'Beautiful. Dead beautiful.'], ['Rook', 'You knew the vault code, Gus. Without asking me.'], ['Gus', 'Old habits, kid. Old habits.']] },
  ] },
  { id: 'm8', title: 'Street Kings', giver: 'Juno', at: 'viper', after: 'm7', reward: { cash: 1500, rep: { vip: 40 } }, steps: [
    { t: 'say', cam: 'viper', lines: [['Juno', 'Kessler\'s dog. Heh. Word is you hit Meridian Savings. Race me and I might not put you in the harbor.'], ['Juno', 'Downtown loop. Lose, and you lose a lot more than a car.']] },
    { t: 'veh', veh: 'sports', at: 'viper', dx: 110, dy: 80, text: 'Take the Vortex GT to the start line', color: '#ff6d00' },
    { t: 'race', time: 95, text: 'Win the downtown street race' },
    { t: 'say', lines: [['Juno', 'You drive like a ghost. The Vipers are done with Kessler. We ride with you.']] },
  ] },
  { id: 'm9', title: 'Siege', giver: 'Nina', at: 'safe', after: 'm8', reward: { cash: 2000 }, steps: [
    { t: 'say', lines: [['Nina (phone)', 'Rook! Kessler\'s men are coming up the street. I am barricaded in the safehouse. Hold them off!']] },
    { t: 'goto', at: 'safe', text: 'Get to the safehouse' },
    { t: 'survive', secs: 55, at: 'safe', fac: 'kes', perWave: 3, every: 9, w: ['smg', 'pistol', 'shotgun'], allies: 2, text: 'Defend the safehouse' },
    { t: 'say', lines: [['Nina', 'Gus is coming with backup... which is odd. I never called him.']] },
  ] },
  { id: 'm10', title: 'Long Shot', giver: 'Gus', at: 'gus', after: 'm9', reward: { cash: 2500 }, steps: [
    { t: 'say', lines: [['Gus', 'Marlowe, Kessler\'s right hand, walks the boardwalk every night. Take him from the Sunset Hotel. Use the Longshot — right click to scope.']] },
    { t: 'give', w: 'sniper', ammo: 15 },
    { t: 'goto', at: 'hotel', text: 'Get to the Sunset Hotel' },
    { t: 'target', at: 'club', name: 'Marlowe', guards: 3, text: 'Take out Marlowe (stay at range!)' },
    { t: 'say', lines: [['Gus', 'One more thorn gone. Now Kessler is boxed in.'], ['Rook', 'You sound pleased.']] },
  ] },
  { id: 'm11', title: 'Ink and Tide', giver: 'Nina', at: 'nina', after: 'm10', reward: { cash: 3000 }, steps: [
    { t: 'say', cam: 'nina', lines: [['Nina', 'I cracked it. "G.P." is Augustine Prieto. Payments, the bank plans, even the vault code.'], ['Rook', 'Gus.'], ['Nina', 'He built Kessler up. He used you as the fall guy and now he is cleaning house.'], ['Rook', 'Then I start with the man who pulled the trigger.']] },
    { t: 'goto', at: 'cranes', veh: false, text: 'Confront Kessler at the Cranes' },
    { t: 'boss', at: 'cranes', name: 'Vance Kessler', hp: 380, armor: 100, minions: 4, text: 'Defeat Vance Kessler' },
    { t: 'say', lines: [['Kessler', 'You think I wanted this? Gus signs the checks. Lighthouse... he keeps the cash there. He will cut you loose like he cut me.']] },
  ] },
  { id: 'm12', title: 'Final Tide', giver: 'Gus', at: 'light', after: 'm11', reward: { cash: 10000 }, steps: [
    { t: 'goto', at: 'light', text: 'Drive to the lighthouse' },
    { t: 'say', cam: 'light', lines: [['Gus', 'Rook. You always were the one who got away clean.'], ['Rook', 'Clean? You sold me for a bank vault.'], ['Gus', 'I sold you for a city. Kessler, the Vipers, the whole waterfront — mine. Take the money, take the crown. Or take the gun.']] },
    { t: 'choice', key: 'ending', prompt: 'How does it end?', options: [{ label: 'Shoot him.', val: 'kill' }, { label: 'Turn him in to the police.', val: 'law' }, { label: 'Take the crown.', val: 'crown' }] },
    { t: 'ending' },
  ] },
];

export const ENDINGS = {
  kill: { t: 'THE TIDE TURNS', x: 'One shot. The sea takes the echo. Port Meridian wakes to find the Kessler Syndicate headless and its patron gone. Rook walks the boardwalk at dawn, richer in enemies than friends — but free of the only man who ever owned him.' },
  law: { t: 'CLEAN SLATE', x: 'Nina\'s story runs front page: "THE MENTOR OF MERIDIAN". Gus is led out in cuffs while the rain falls on camera flashes. Rook\'s record is wiped. For the first time in years, nobody is hunting him.' },
  crown: { t: 'NEON CROWN', x: 'The ledgers, the docks, the Vipers, the money. Rook inherits it all. The city glows brighter every night — and so does the target on his back. Somebody, somewhere, is already learning the vault codes.' },
};

// side-activity configuration
export const THEFT_LIST = ['sports', 'muscle', 'pickup', 'moto', 'van', 'compact'];
export const STUNT_RAMPS = 5;
export const SHARD_COUNT = 24;
