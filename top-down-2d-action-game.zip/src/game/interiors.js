// ===== interiors.js — enterable building interiors (separate small scenes with fade transition) =====
import { clamp } from './util.js';
import { makeCanvas, rr } from './gfx.js';
const TS = 32;

class Interior {
  constructor(type, w, h, theme) {
    this.id = type; this.type = type; this.w = w; this.h = h; this.theme = theme; this.t = new Uint8Array(w * h); this.decor = []; this.objs = []; this.npcs = []; this.pts = {};
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (y < 2 || y === h - 1 || x === 0 || x === w - 1) this.t[y * w + x] = 1;
    this.exitDoor = { x: (w >> 1) * TS + 16, y: (h - 1) * TS + 8 };
    this.pts.entry = { x: this.exitDoor.x, y: (h - 2) * TS + 8 };
    this.objs.push({ x: this.exitDoor.x, y: (h - 0.55) * TS, r: 40, label: 'Leave', act: 'exit' });
    this.res = { x: 0, y: 0, nx: 0, ny: 0, hit: 0, prop: null };
  }
  box(x, y, w, h, col, solid = true, label) {
    this.decor.push({ x, y, w, h, col, label });
    if (solid) for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.t[(y + j) * this.w + x + i] = 2;
  }
  npc(x, y, o) { this.npcs.push({ x: x * TS, y: y * TS, ...o }); }
  obj(x, y, label, act, data, r = 40) { this.objs.push({ x: x * TS, y: y * TS, r, label, act, data }); }
  solidTile(tx, ty) { return tx < 0 || ty < 0 || tx >= this.w || ty >= this.h || this.t[ty * this.w + tx] !== 0; }
  solidAt(x, y) { return this.solidTile(Math.floor(x / TS), Math.floor(y / TS)); }
  lineClear(x0, y0, x1, y1) { const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 12); for (let i = 1; i < n; i++) { const t = i / n; if (this.solidAt(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)) return false; } return true; }
  pushCircle(x, y, r) {
    const res = this.res; res.hit = 0; res.nx = 0; res.ny = 0; res.prop = null;
    for (let ty = Math.floor((y - r) / TS); ty <= Math.floor((y + r) / TS); ty++) for (let tx = Math.floor((x - r) / TS); tx <= Math.floor((x + r) / TS); tx++) {
      if (!this.solidTile(tx, ty)) continue;
      const cx = clamp(x, tx * TS, tx * TS + TS), cy = clamp(y, ty * TS, ty * TS + TS), dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy;
      if (d2 >= r * r) continue;
      if (d2 > 1e-6) { const d = Math.sqrt(d2); x += (dx / d) * (r - d); y += (dy / d) * (r - d); res.nx = dx / d; res.ny = dy / d; } else { y += r; }
      res.hit++;
    }
    res.x = x; res.y = y; return res;
  }
  render() {
    const W = this.w * TS, H = this.h * TS, cv = makeCanvas(W, H), c = cv.getContext('2d'), th = this.theme;
    for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
      const k = this.t[y * this.w + x];
      if (k === 1) { c.fillStyle = y < 2 ? th.wallTop : th.wall; c.fillRect(x * TS, y * TS, TS, TS); if (y === 1) { c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(x * TS, y * TS + TS - 6, TS, 6); c.fillStyle = th.trim; c.fillRect(x * TS, y * TS + TS - 8, TS, 2); } }
      else { c.fillStyle = (x + y) % 2 ? th.floorA : th.floorB; c.fillRect(x * TS, y * TS, TS, TS); if (th.rug) { c.fillStyle = 'rgba(0,0,0,.05)'; c.fillRect(x * TS, y * TS, TS, 1); } }
    }
    // door mat
    c.fillStyle = '#222'; c.fillRect(this.exitDoor.x - 20, (this.h - 1) * TS, 40, TS); c.fillStyle = th.accent; c.fillRect(this.exitDoor.x - 20, (this.h - 1) * TS, 40, 3);
    for (const d of this.decor) {
      const x = d.x * TS, y = d.y * TS, w = d.w * TS, h = d.h * TS;
      c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(x + 3, y + 5, w, h);
      const g = c.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, shadeCol(d.col, 0.25)); g.addColorStop(1, d.col); c.fillStyle = g; rr(c, x, y, w, h, 4); c.fill();
      c.strokeStyle = 'rgba(0,0,0,.45)'; c.lineWidth = 1.5; c.stroke();
      if (d.label) { c.fillStyle = 'rgba(255,255,255,.85)'; c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillText(d.label, x + w / 2, y + h / 2 + 3); }
    }
    this.cv = cv; return cv;
  }
}
function shadeCol(hex, f) { const n = parseInt(hex.slice(1), 16), c = (v) => Math.min(255, Math.round(v + (255 - v) * f)); return `rgb(${c(n >> 16)},${c((n >> 8) & 255)},${c(n & 255)})`; }

const THEMES = {
  shop: { floorA: '#6c6f78', floorB: '#62656e', wall: '#2a2c36', wallTop: '#3a3d4a', trim: '#ff4fd8', accent: '#ffd24a' },
  bar: { floorA: '#4a3326', floorB: '#422d21', wall: '#1d1418', wallTop: '#2b1d24', trim: '#ff4fd8', accent: '#ff4fd8', rug: 1 },
  bank: { floorA: '#8a8f9c', floorB: '#7f8492', wall: '#2d3345', wallTop: '#3a4258', trim: '#4fe0ff', accent: '#4fe0ff' },
  police: { floorA: '#6d7584', floorB: '#646c7b', wall: '#1d2640', wallTop: '#26325a', trim: '#4aa8ff', accent: '#4aa8ff' },
  home: { floorA: '#7a6a58', floorB: '#705f4e', wall: '#34303c', wallTop: '#454052', trim: '#4fe0ff', accent: '#4fe0ff', rug: 1 },
  hospital: { floorA: '#d4dde6', floorB: '#c8d2dd', wall: '#6c7a8a', wallTop: '#8794a3', trim: '#ff4f6a', accent: '#ff4f6a' },
  casino: { floorA: '#4a1f4f', floorB: '#3e1a43', wall: '#1a0f1f', wallTop: '#2b1733', trim: '#ffd24a', accent: '#ffd24a', rug: 1 },
  garage: { floorA: '#5b5e66', floorB: '#54575f', wall: '#2a2724', wallTop: '#3a3530', trim: '#ff6a3d', accent: '#ff6a3d' },
  arena: { floorA: '#4a4040', floorB: '#433838', wall: '#241818', wallTop: '#3a2222', trim: '#ff3b3b', accent: '#ff3b3b' },
};

export function buildInterior(type, b) {
  let I;
  const shop = (title, th = 'shop') => {
    I = new Interior(type, 12, 9, THEMES[th]);
    I.box(1, 2, 10, 1, '#4a3a2a', true); I.box(2, 4, 8, 1, '#6b4a2f', true, title);
    I.npc(6, 3.6, { role: 'clerk' }); I.obj(6, 5.6, 'Browse — ' + title, 'shop:' + type, null, 46);
    if (type === 'shop_clothes') { I.box(9, 6, 1, 2, '#7ac', true, 'mirror'); I.obj(8.3, 7, 'Try clothes ($40)', 'wardrobe', 40, 44); }
    if (type === 'shop_gun') { I.decor.push({ x: 1, y: 1.1, w: 10, h: 0.6, col: '#222' }); }
    I.pts.floor = { x: 6 * TS, y: 6.5 * TS };
  };
  switch (type) {
    case 'shop_gun': shop('GUN DEN'); break;
    case 'shop_mart': shop('MART'); break;
    case 'shop_clothes': shop('THREADS'); break;
    case 'shop_burger': shop('BURGER'); break;
    case 'bar': {
      I = new Interior(type, 14, 10, THEMES.bar); I.box(2, 3, 9, 1, '#5a3a22', true, 'BAR'); I.box(3, 6, 2, 2, '#6a4a30', true); I.box(9, 6, 2, 2, '#6a4a30', true); I.box(12, 2, 1, 2, '#2a2a5a', true, 'JUKE');
      I.npc(6, 2.5, { role: 'clerk' }); I.npc(4, 5.2, { role: 'patron' }); I.obj(6, 4.7, 'Order a drink', 'shop:bar', null, 46); I.obj(11.6, 4.3, 'Jukebox', 'jukebox', null, 40); I.pts.floor = { x: 7 * TS, y: 6 * TS }; break;
    }
    case 'bank': {
      I = new Interior(type, 16, 12, THEMES.bank); I.box(9, 1, 6, 3, '#3a3f4a', true, 'VAULT'); I.box(2, 5, 12, 1, '#6b6b78', true, 'TELLERS');
      [4, 7.5, 11].forEach((x) => I.npc(x, 4.4, { role: 'teller' })); I.npc(3, 8.5, { role: 'customer' }); I.npc(12, 8, { role: 'customer' });
      I.npc(3, 9.5, { role: 'guard' }); I.npc(13, 9.5, { role: 'guard' }); I.npc(8, 7.8, { role: 'guard' });
      I.obj(1.6, 7.2, 'ATM', 'atm', null, 40); I.pts.vault = { x: 12 * TS, y: 4.4 * TS }; I.pts.floor = { x: 8 * TS, y: 8 * TS }; break;
    }
    case 'police': {
      I = new Interior(type, 16, 11, THEMES.police); I.box(5, 3, 6, 1, '#555d6c', true, 'DESK'); I.box(1, 2, 3, 4, '#2b2f3a', true, 'CELLS'); I.box(13, 2, 2, 2, '#3a4252', true);
      I.npc(8, 2.5, { role: 'sergeant' }); I.npc(12, 6, { role: 'officer' }); I.npc(4, 8, { role: 'officer' }); I.obj(8, 4.7, 'Desk Sergeant — Bribe / Fine', 'police', null, 46); I.pts.floor = { x: 8 * TS, y: 7 * TS }; break;
    }
    case 'safehouse': case 'apartment': {
      const own = type === 'safehouse'; I = new Interior(type, own ? 14 : 10, own ? 9 : 8, THEMES.home);
      I.box(1, 2, 3, 2, '#3a5a8a', true, 'BED'); I.obj(2.5, 4.6, own ? 'Sleep until morning' : 'Rent a bed ($25)', 'sleep', own ? 0 : 25, 44);
      I.box(own ? 11 : 7, 2, 2, 1, '#222', true, 'TV'); I.obj(own ? 12 : 8, 3.7, 'Watch the news', 'news', null, 42);
      if (own) { I.box(6, 2, 2, 1, '#5a4630', true, 'CLOTHES'); I.obj(7, 3.6, 'Change clothes', 'wardrobe', 0, 42); I.box(11, 5, 2, 1, '#6b5a40', true, 'DESK'); I.obj(12, 6.5, 'Save game', 'save', null, 44); I.box(7, 5, 3, 1, '#4a3a5a', true); I.box(1, 6, 2, 1, '#444', true, 'CACHE'); I.obj(2, 7.3, 'Weapon cache (free ammo, once a day)', 'cache', null, 44); }
      I.pts.floor = { x: 6 * TS, y: 5.5 * TS }; break;
    }
    case 'hospital': {
      I = new Interior(type, 16, 10, THEMES.hospital); I.box(6, 3, 4, 1, '#9ab', true, 'RECEPTION'); I.box(1, 2, 2, 2, '#bcd', true); I.box(13, 2, 2, 2, '#bcd', true);
      I.npc(8, 2.5, { role: 'nurse' }); I.npc(3, 6, { role: 'patient' }); I.obj(8, 4.8, 'Full treatment ($60)', 'heal', 60, 46); I.pts.floor = { x: 8 * TS, y: 6 * TS }; break;
    }
    case 'office': {
      I = new Interior(type, 14, 10, THEMES.home); I.box(2, 3, 3, 2, '#5a4630', true, 'DESK'); I.box(8, 3, 3, 2, '#5a4630', true, 'DESK'); I.box(11, 6, 2, 1, '#333', true, 'PRESS');
      I.npc(3.5, 5.6, { role: 'patron' }); I.obj(10, 6.2, 'Read the Ledger', 'news', null, 50); I.pts.floor = { x: 7 * TS, y: 6 * TS }; break;
    }
    case 'casino': {
      I = new Interior(type, 18, 12, THEMES.casino); for (let i = 0; i < 6; i++) { I.box(2 + i * 2, 3, 1, 1, '#c0a020', true, '7'); I.obj(2.5 + i * 2, 4.5, 'Slot machine ($20)', 'slots', 20, 36); }
      I.box(12, 7, 4, 2, '#1b5e20', true, 'FLIP'); I.obj(14, 9.5, 'Double or nothing ($100)', 'coinflip', 100, 46); I.box(2, 8, 5, 1, '#5a3a22', true, 'BAR'); I.npc(4, 7.6, { role: 'clerk' }); I.npc(9, 6, { role: 'patron' });
      I.pts.floor = { x: 9 * TS, y: 7 * TS }; break;
    }
    case 'garage': {
      I = new Interior(type, 16, 11, THEMES.garage); I.box(1, 2, 3, 3, '#444', true, 'LIFT'); I.box(12, 2, 3, 1, '#6a4a30', true, 'PARTS'); I.box(6, 6, 3, 2, '#3a3a40', true, 'TOOLS');
      I.npc(8, 3.6, { role: 'gus' }); I.obj(8, 5.2, 'Gus — "Drive up to my door to customise a ride."', 'info', 'Park a car at the garage door and press E from the driver seat to paint, upgrade and plate it.', 50); I.pts.floor = { x: 8 * TS, y: 7 * TS }; break;
    }
    case 'arena': {
      I = new Interior(type, 16, 12, THEMES.arena); I.decor.push({ x: 4, y: 4, w: 8, h: 5, col: '#6a2a2a' });
      for (let i = 0; i < 6; i++) I.npc(2 + i * 2.4, 3.2, { role: 'crowd' }); I.obj(8, 9.9, 'Enter the ring ($50)', 'fight', 50, 50); I.pts.floor = { x: 8 * TS, y: 6.5 * TS }; I.pts.ring = { x: 8 * TS, y: 6.5 * TS }; break;
    }
    default: shop('SHOP'); break;
  }
  I.render(); I.building = b; return I;
}
