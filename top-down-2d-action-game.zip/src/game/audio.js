// ===== audio.js — fully synthesized Web Audio: SFX, engines, sirens, ambience, procedural radio & adaptive score =====
import { clamp, rnd } from './util.js';
import { STATIONS } from './data.js';

const mtof = (n) => 440 * Math.pow(2, (n - 69) / 12);
const MIN = [0, 2, 3, 5, 7, 8, 10];
const PENT = [0, 3, 5, 7, 10];

export class AudioEngine {
  constructor() {
    this.ctx = null; this.ok = false;
    this.vol = { master: 0.8, music: 0.55, sfx: 0.8 };
    this.lx = 0; this.ly = 0; this.budget = 30;
    this.mode = 'score'; this.station = 0; this.intensity = 0; this.radioOn = true;
    this.nextT = 0; this.step = 0; this.bar = 0; this.seed = 1;
    this.engines = []; this.siren = null; this.tire = null; this.horn = null; this.amb = null;
  }

  init() {
    if (this.ctx) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      const c = (this.ctx = new AC());
      this.master = c.createGain();
      const comp = c.createDynamicsCompressor();
      comp.threshold.value = -14; comp.ratio.value = 6;
      this.master.connect(comp); comp.connect(c.destination);
      this.sfxBus = c.createGain(); this.musBus = c.createGain(); this.ambBus = c.createGain();
      this.sfxBus.connect(this.master); this.musBus.connect(this.master); this.ambBus.connect(this.master);
      // noise buffer
      const nb = c.createBuffer(1, c.sampleRate * 2, c.sampleRate), d = nb.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      this.noise = nb;
      // reverb impulse
      const len = c.sampleRate * 1.4, ib = c.createBuffer(2, len, c.sampleRate);
      for (let ch = 0; ch < 2; ch++) { const dd = ib.getChannelData(ch); for (let i = 0; i < len; i++) dd[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3); }
      this.rev = c.createConvolver(); this.rev.buffer = ib;
      this.revGain = c.createGain(); this.revGain.gain.value = 0.35;
      this.rev.connect(this.revGain); this.revGain.connect(this.sfxBus);
      this.applyVol();
      this._buildContinuous();
      this.ok = true;
    } catch (e) { this.ok = false; }
  }
  resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(() => {}); }
  applyVol() {
    if (!this.ctx) return;
    this.master.gain.value = this.vol.master; this.sfxBus.gain.value = this.vol.sfx;
    this.ambBus.gain.value = this.vol.sfx * 0.8; this.musBus.gain.value = this.vol.music * 0.5;
  }
  setVol(k, v) { this.vol[k] = v; this.applyVol(); }

  // ---------- helpers ----------
  _out(x, y, vol = 1, rng = 1400) {
    if (!this.ok || this.budget <= 0) return null;
    let g = vol;
    let pan = 0;
    if (x !== undefined) {
      const dx = x - this.lx, dy = y - this.ly, d = Math.hypot(dx, dy);
      g *= Math.pow(clamp(1 - d / rng, 0, 1), 1.5);
      if (g < 0.01) return null;
      pan = clamp(dx / 650, -1, 1);
    }
    this.budget--;
    const c = this.ctx, n = c.createGain(); n.gain.value = g;
    if (c.createStereoPanner) { const p = c.createStereoPanner(); p.pan.value = pan; n.connect(p); p.connect(this.sfxBus); } else n.connect(this.sfxBus);
    return n;
  }
  _noise(t, dur, type, f0, f1, q, gain, dest, send = 0) {
    const c = this.ctx, s = c.createBufferSource(); s.buffer = this.noise;
    const f = c.createBiquadFilter(); f.type = type; f.Q.value = q;
    f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(gain, t + 0.003); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(dest);
    if (send > 0 && this.rev) { const sg = c.createGain(); sg.gain.value = send; g.connect(sg); sg.connect(this.rev); }
    s.start(t, Math.random()); s.stop(t + dur + 0.05);
  }
  _tone(t, type, f0, f1, dur, gain, dest, send = 0) {
    const c = this.ctx, o = c.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(10, f1), t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(gain, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(dest);
    if (send > 0 && this.rev) { const sg = c.createGain(); sg.gain.value = send; g.connect(sg); sg.connect(this.rev); }
    o.start(t); o.stop(t + dur + 0.05);
  }

  // ---------- one-shot SFX ----------
  sfx(name, x, y, vol = 1) {
    if (!this.ok) return;
    const o = this._out(x, y, vol, name === 'explosion' || name === 'thunder' ? 2600 : 1500);
    if (!o) return;
    const t = this.ctx.currentTime;
    switch (name) {
      case 'pistol': this._noise(t, 0.12, 'bandpass', 2200, 500, 0.8, 0.9, o, 0.5); this._tone(t, 'sine', 180, 50, 0.1, 0.8, o); break;
      case 'smg': this._noise(t, 0.08, 'bandpass', 2600, 700, 0.9, 0.7, o, 0.3); this._tone(t, 'sine', 200, 70, 0.06, 0.5, o); break;
      case 'shotgun': this._noise(t, 0.3, 'lowpass', 3000, 200, 0.5, 1.2, o, 0.7); this._tone(t, 'sine', 120, 35, 0.2, 1, o); break;
      case 'rifle': this._noise(t, 0.14, 'bandpass', 1800, 380, 0.7, 1, o, 0.55); this._tone(t, 'sine', 150, 40, 0.14, 0.9, o); break;
      case 'sniper': this._noise(t, 0.5, 'bandpass', 1500, 120, 0.6, 1.3, o, 0.9); this._tone(t, 'sine', 110, 28, 0.35, 1.2, o); break;
      case 'rocket': this._noise(t, 0.7, 'bandpass', 600, 2400, 0.6, 0.9, o, 0.4); this._tone(t, 'sawtooth', 90, 40, 0.4, 0.4, o); break;
      case 'explosion': this._noise(t, 1.5, 'lowpass', 1400, 50, 0.6, 1.6, o, 0.9); this._tone(t, 'sine', 70, 24, 1.0, 1.4, o); this._noise(t + 0.08, 0.6, 'bandpass', 500, 90, 0.5, 0.8, o); break;
      case 'punch': this._noise(t, 0.07, 'lowpass', 900, 200, 0.7, 0.9, o); this._tone(t, 'sine', 120, 55, 0.08, 0.7, o); break;
      case 'bat': this._noise(t, 0.09, 'bandpass', 600, 300, 1, 0.8, o); this._tone(t, 'triangle', 220, 90, 0.12, 0.7, o); break;
      case 'knife': this._noise(t, 0.12, 'highpass', 4000, 7000, 0.7, 0.4, o); break;
      case 'swing': this._noise(t, 0.12, 'bandpass', 1500, 500, 1.2, 0.25, o); break;
      case 'throw': this._noise(t, 0.15, 'bandpass', 900, 400, 1.5, 0.3, o); break;
      case 'flesh': this._noise(t, 0.06, 'lowpass', 700, 200, 0.7, 0.6, o); break;
      case 'hit': this._noise(t, 0.05, 'bandpass', 3000, 1500, 2, 0.35, o); this._tone(t, 'triangle', 1800, 900, 0.05, 0.15, o); break;
      case 'glass': this._noise(t, 0.4, 'highpass', 5000, 8000, 0.8, 0.5, o); [3100, 4200, 5200].forEach((f, i) => this._tone(t + i * 0.03, 'sine', f, f * 0.9, 0.2, 0.12, o)); break;
      case 'crash': this._noise(t, 0.35, 'lowpass', 1800, 150, 0.7, 1.1, o, 0.3); this._tone(t, 'triangle', 320, 120, 0.25, 0.4, o); this._noise(t, 0.2, 'highpass', 3000, 5000, 1, 0.3, o); break;
      case 'thud': this._noise(t, 0.12, 'lowpass', 500, 120, 0.7, 0.7, o); this._tone(t, 'sine', 90, 40, 0.12, 0.6, o); break;
      case 'honk': this._tone(t, 'square', 392, 392, 0.28, 0.22, o); this._tone(t, 'square', 466, 466, 0.28, 0.2, o); break;
      case 'beep': this._tone(t, 'square', 880, 880, 0.1, 0.12, o); break;
      case 'click': this._tone(t, 'square', 1200, 800, 0.03, 0.12, o); break;
      case 'empty': this._tone(t, 'square', 600, 400, 0.04, 0.18, o); break;
      case 'reload': this._noise(t, 0.04, 'bandpass', 2500, 1500, 3, 0.4, o); this._noise(t + 0.3, 0.05, 'bandpass', 1800, 900, 3, 0.5, o); this._tone(t + 0.55, 'square', 500, 300, 0.04, 0.2, o); break;
      case 'pickup': [660, 880, 1320].forEach((f, i) => this._tone(t + i * 0.06, 'sine', f, f, 0.12, 0.25, o)); break;
      case 'cash': [1568, 2093].forEach((f, i) => this._tone(t + i * 0.07, 'triangle', f, f, 0.18, 0.25, o)); break;
      case 'ui': this._tone(t, 'triangle', 660, 990, 0.06, 0.2, o); break;
      case 'error': this._tone(t, 'sawtooth', 200, 140, 0.18, 0.25, o); break;
      case 'door': this._noise(t, 0.2, 'lowpass', 600, 150, 0.8, 0.6, o); this._tone(t + 0.12, 'sine', 140, 80, 0.08, 0.5, o); break;
      case 'splash': this._noise(t, 0.3, 'bandpass', 1200, 400, 0.6, 0.6, o); break;
      case 'caralarm': for (let i = 0; i < 6; i++) this._tone(t + i * 0.2, 'square', i % 2 ? 900 : 1300, i % 2 ? 900 : 1300, 0.18, 0.15, o); break;
      case 'thunder': this._noise(t, 3.2, 'lowpass', 500, 40, 0.5, 1.5, o, 0.6); this._noise(t + 0.4, 2, 'lowpass', 300, 40, 0.5, 1, o); break;
      case 'levelup': [523, 659, 784, 1047].forEach((f, i) => this._tone(t + i * 0.09, 'triangle', f, f, 0.25, 0.3, o)); break;
      case 'complete': [392, 523, 659, 784, 1047].forEach((f, i) => this._tone(t + i * 0.12, 'triangle', f, f, 0.5, 0.3, o, 0.3)); break;
      case 'fail': [330, 262, 196].forEach((f, i) => this._tone(t + i * 0.2, 'sawtooth', f, f * 0.95, 0.5, 0.25, o, 0.3)); break;
      case 'wasted': this._tone(t, 'sawtooth', 220, 40, 1.6, 0.5, o, 0.6); this._noise(t, 1.2, 'lowpass', 1200, 60, 0.6, 0.5, o); break;
      case 'slowmo': this._tone(t, 'sine', 800, 100, 0.6, 0.4, o, 0.5); break;
      case 'engineStart': this._tone(t, 'sawtooth', 50, 110, 0.4, 0.35, o); this._noise(t, 0.4, 'lowpass', 500, 300, 0.6, 0.2, o); break;
      default: break;
    }
  }
  footstep(surface, x, y, vol = 0.5) {
    if (!this.ok) return;
    const o = this._out(x, y, vol * 0.5, 500); if (!o) return;
    const t = this.ctx.currentTime;
    if (surface === 'grass') this._noise(t, 0.07, 'lowpass', 700, 300, 0.5, 0.35, o);
    else if (surface === 'sand') this._noise(t, 0.09, 'lowpass', 900, 400, 0.5, 0.3, o);
    else if (surface === 'wood') { this._noise(t, 0.05, 'bandpass', 500, 300, 2, 0.3, o); this._tone(t, 'triangle', 190, 120, 0.06, 0.2, o); }
    else if (surface === 'water') this._noise(t, 0.2, 'bandpass', 900, 500, 0.6, 0.4, o);
    else this._noise(t, 0.05, 'bandpass', 1600, 900, 1.5, 0.35, o);
  }

  // ---------- continuous voices ----------
  _loopNoise(type, freq, q, gain, dest) {
    const c = this.ctx, s = c.createBufferSource(); s.buffer = this.noise; s.loop = true;
    const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = c.createGain(); g.gain.value = gain;
    s.connect(f); f.connect(g); g.connect(dest); s.start();
    return { s, f, g };
  }
  _buildContinuous() {
    const c = this.ctx;
    this.amb = {
      rain: this._loopNoise('highpass', 1200, 0.3, 0, this.ambBus),
      rain2: this._loopNoise('bandpass', 400, 0.4, 0, this.ambBus),
      wind: this._loopNoise('lowpass', 350, 0.8, 0, this.ambBus),
      crowd: this._loopNoise('bandpass', 550, 0.9, 0, this.ambBus),
      city: this._loopNoise('lowpass', 140, 0.5, 0.02, this.ambBus),
    };
    this.tire = this._loopNoise('bandpass', 1500, 4, 0, this.sfxBus);
    // engines: [player, nearest AI]
    for (let i = 0; i < 2; i++) {
      const o1 = c.createOscillator(), o2 = c.createOscillator(), o3 = c.createOscillator();
      o1.type = 'sawtooth'; o2.type = 'square'; o3.type = 'sine';
      const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 600; f.Q.value = 2;
      const g = c.createGain(); g.gain.value = 0;
      const p = c.createStereoPanner ? c.createStereoPanner() : null;
      const m1 = c.createGain(), m2 = c.createGain(), m3 = c.createGain(); m1.gain.value = 0.5; m2.gain.value = 0.25; m3.gain.value = 0.5;
      o1.connect(m1); o2.connect(m2); o3.connect(m3); m1.connect(f); m2.connect(f); m3.connect(f); f.connect(g);
      if (p) { g.connect(p); p.connect(this.sfxBus); } else g.connect(this.sfxBus);
      o1.start(); o2.start(); o3.start();
      this.engines.push({ o1, o2, o3, f, g, p });
    }
    // siren
    const so = c.createOscillator(); so.type = 'sawtooth';
    const sf = c.createBiquadFilter(); sf.type = 'bandpass'; sf.frequency.value = 1000; sf.Q.value = 1.2;
    const sg = c.createGain(); sg.gain.value = 0; const sp = c.createStereoPanner ? c.createStereoPanner() : null;
    so.connect(sf); sf.connect(sg); if (sp) { sg.connect(sp); sp.connect(this.sfxBus); } else sg.connect(this.sfxBus);
    so.start(); this.siren = { o: so, g: sg, p: sp, lastD: 0 };
    // horn
    const h1 = c.createOscillator(), h2 = c.createOscillator(); h1.type = 'square'; h2.type = 'square'; h1.frequency.value = 392; h2.frequency.value = 466;
    const hg = c.createGain(); hg.gain.value = 0; h1.connect(hg); h2.connect(hg); hg.connect(this.sfxBus); h1.start(); h2.start();
    this.horn = hg;
  }
  /** idx 0 = player's vehicle, 1 = nearest AI vehicle */
  engine(idx, rpm, load, x, y, vol = 1) {
    if (!this.ok) return;
    const e = this.engines[idx], t = this.ctx.currentTime;
    let g = rpm < 0 ? 0 : vol * (0.12 + load * 0.2);
    if (x !== undefined) { const d = Math.hypot(x - this.lx, y - this.ly); g *= Math.pow(clamp(1 - d / 900, 0, 1), 1.6); if (e.p) e.p.pan.setTargetAtTime(clamp((x - this.lx) / 600, -1, 1), t, 0.05); }
    const f = 38 + Math.max(0, rpm) * 150;
    e.o1.frequency.setTargetAtTime(f, t, 0.04); e.o2.frequency.setTargetAtTime(f * 0.5, t, 0.04); e.o3.frequency.setTargetAtTime(f * 0.25, t, 0.04);
    e.f.frequency.setTargetAtTime(300 + Math.max(0, rpm) * 900 + load * 700, t, 0.05);
    e.g.gain.setTargetAtTime(g, t, 0.05);
  }
  setTire(level, x, y) {
    if (!this.ok) return;
    let g = level * 0.18;
    if (x !== undefined) g *= clamp(1 - Math.hypot(x - this.lx, y - this.ly) / 900, 0, 1);
    this.tire.g.gain.setTargetAtTime(g, this.ctx.currentTime, 0.05);
    this.tire.f.frequency.setTargetAtTime(1200 + level * 900, this.ctx.currentTime, 0.1);
  }
  setHorn(on) { if (this.ok) this.horn.gain.setTargetAtTime(on ? 0.14 : 0, this.ctx.currentTime, 0.01); }
  /** sirens with Doppler: pass nearest siren source and its closing speed */
  setSiren(on, x, y, closing, time) {
    if (!this.ok) return;
    const s = this.siren, t = this.ctx.currentTime;
    if (!on) { s.g.gain.setTargetAtTime(0, t, 0.1); return; }
    const d = Math.hypot(x - this.lx, y - this.ly);
    const g = 0.09 * Math.pow(clamp(1 - d / 1700, 0, 1), 1.4);
    const wail = 0.5 + 0.5 * Math.sin(time * 5.5);
    const dop = 1 + clamp(-closing / 2200, -0.25, 0.25);
    s.o.frequency.setTargetAtTime((650 + wail * 650) * dop, t, 0.03);
    s.g.gain.setTargetAtTime(g, t, 0.08);
    if (s.p) s.p.pan.setTargetAtTime(clamp((x - this.lx) / 700, -1, 1), t, 0.05);
  }
  setAmbience(rain, wind, crowd, night) {
    if (!this.ok) return;
    const t = this.ctx.currentTime, a = this.amb;
    a.rain.g.gain.setTargetAtTime(rain * 0.1, t, 0.5); a.rain2.g.gain.setTargetAtTime(rain * 0.25, t, 0.5);
    a.wind.g.gain.setTargetAtTime(wind * 0.25, t, 0.8); a.crowd.g.gain.setTargetAtTime(crowd * (night ? 0.05 : 0.09), t, 1);
  }

  // ---------- music: radio stations + adaptive score ----------
  update(dt, g) {
    if (!this.ok) return;
    this.budget = Math.min(30, this.budget + dt * 150);
    this.lx = g.cam.x; this.ly = g.cam.y;
    const c = this.ctx;
    const inCar = !!g.player.veh;
    const wantRadio = inCar && this.radioOn && this.station >= 0 && g.state === 'play' && g.player.veh.hp > 0;
    this.mode = wantRadio ? 'radio' : 'score';
    if (this.mode !== this._lastMode) { this._lastMode = this.mode; this.step = 0; this.bar = 0; this.nextT = c.currentTime + 0.05; }
    if (g.state === 'menu') this.mode = 'score';
    const intens = g.wanted.stars > 0 ? (g.wanted.seen ? 2 : 1) : (g.combatT > 0 ? 1 : 0);
    this.intensity += (intens - this.intensity) * Math.min(1, dt * 0.5);
    if (this.mode === 'radio' && !inCar) return;
    const bpm = this.mode === 'radio' ? STATIONS[this.station].bpm : 78 + this.intensity * 28;
    const sd = 60 / bpm / 4;
    if (this.nextT < c.currentTime - 0.3) this.nextT = c.currentTime + 0.05;
    let guard = 0;
    while (this.nextT < c.currentTime + 0.25 && guard++ < 8) {
      const swing = this.mode === 'radio' && this.station === 1 && this.step % 2 === 1 ? sd * 0.18 : 0;
      this._musicStep(this.nextT + swing, this.step, this.bar);
      this.nextT += sd; this.step++;
      if (this.step >= 16) { this.step = 0; this.bar++; }
    }
  }
  jingle() {
    if (!this.ok) return; const t = this.ctx.currentTime + 0.05;
    [0, 4, 7, 12, 7, 12].forEach((n, i) => this._tone(t + i * 0.1, 'square', mtof(72 + n), mtof(72 + n), 0.14, 0.12, this.musBus));
  }
  _kick(t, v = 1) { this._tone(t, 'sine', 160, 42, 0.16, 0.9 * v, this.musBus); }
  _snare(t, v = 1) { this._noise(t, 0.15, 'bandpass', 1900, 1200, 0.8, 0.55 * v, this.musBus); this._tone(t, 'triangle', 200, 120, 0.08, 0.3 * v, this.musBus); }
  _hat(t, v = 1, open = false) { this._noise(t, open ? 0.2 : 0.04, 'highpass', 7500, 9000, 0.7, 0.22 * v, this.musBus); }
  _bass(t, f, dur, type = 'sawtooth', cut = 500, v = 0.5) {
    const c = this.ctx, o = c.createOscillator(); o.type = type; o.frequency.value = f;
    const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.Q.value = 4; fl.frequency.setValueAtTime(cut * 3, t); fl.frequency.exponentialRampToValueAtTime(cut, t + dur * 0.8);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(fl); fl.connect(g); g.connect(this.musBus); o.start(t); o.stop(t + dur + 0.05);
  }
  _pad(t, notes, dur, v = 0.12, type = 'sawtooth', cut = 900) {
    const c = this.ctx;
    const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = cut;
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + dur * 0.35); g.gain.linearRampToValueAtTime(0.0001, t + dur);
    fl.connect(g); g.connect(this.musBus);
    notes.forEach((n) => { for (const dt of [-6, 6]) { const o = c.createOscillator(); o.type = type; o.frequency.value = mtof(n); o.detune.value = dt; o.connect(fl); o.start(t); o.stop(t + dur + 0.05); } });
  }
  _pluck(t, n, dur, v = 0.18, type = 'sawtooth', cut = 2500) {
    const c = this.ctx, o = c.createOscillator(); o.type = type; o.frequency.value = mtof(n);
    const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.Q.value = 3; fl.frequency.setValueAtTime(cut, t); fl.frequency.exponentialRampToValueAtTime(300, t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(fl); fl.connect(g); g.connect(this.musBus); o.start(t); o.stop(t + dur + 0.05);
  }
  _chord(off, i) { return [0, off === 0 || off === 5 || off === 7 ? 3 : 4, 7].map((x) => x + off)[i % 3]; }
  _musicStep(t, s, bar) {
    const mb = this.musBus;
    const h = (a, b) => ((a * 73856093) ^ (b * 19349663)) >>> 0;
    if (this.mode === 'radio') {
      const st = STATIONS[this.station], root = st.root;
      if (st.id === 'neon') {
        const off = [0, 8, 3, 10][bar % 4], r = root + off;
        if (s % 4 === 0) this._kick(t, 0.8);
        if (s === 4 || s === 12) { this._snare(t, 0.8); }
        if (s % 2 === 1) this._hat(t, 0.6); if (s === 14) this._hat(t, 0.8, true);
        if (s % 2 === 0) this._bass(t, mtof(r), 0.2, 'sawtooth', 600, 0.38);
        if (s === 0) this._pad(t, [r + 24, r + 27, r + 31, r + 36].map((n) => n - (off === 0 || off === 5 ? 0 : 1)), 60 / st.bpm * 4, 0.05);
        const arp = [0, 7, 12, 7, 3, 7, 12, 15][s % 8];
        if (bar % 8 >= 2) this._pluck(t, r + 24 + arp, 0.18, 0.1, 'sawtooth', 3200);
        if (bar % 4 === 3 && s % 2 === 0) this._pluck(t, r + 36 + MIN[h(bar, s) % 7], 0.22, 0.07, 'square', 2200);
      } else if (st.id === 'dub') {
        const off = [0, 8, 5, 10][bar % 4], r = root + off;
        if (s === 0 || s === 7 || s === 10) this._kick(t, 0.85);
        if (s === 4 || s === 12) this._snare(t, 0.7);
        if (s % 2 === 0) this._hat(t, 0.5, s === 14);
        if (s === 0 || s === 6 || s === 8) this._bass(t, mtof(r), 0.45, 'sine', 400, 0.6);
        if (s === 0 || s === 10) this._pluck(t, r + 24, 1.1, 0.07, 'triangle', 1400), this._pluck(t, r + 27, 1.1, 0.07, 'triangle', 1400), this._pluck(t, r + 31, 1.1, 0.07, 'triangle', 1400), this._pluck(t, r + 34, 1.1, 0.06, 'triangle', 1400);
        if (h(bar, s) % 11 === 0) this._noise(t, 0.02, 'highpass', 5000, 6000, 1, 0.12, mb);
      } else if (st.id === 'rust') {
        const off = [0, 3, 5, 7][bar % 4], r = root + off;
        if (s % 2 === 0) { this._bass(t, mtof(r + 12), 0.22, 'sawtooth', 1400, 0.3); this._bass(t, mtof(r + 19), 0.22, 'sawtooth', 1400, 0.2); }
        if (s === 0 || s === 6 || s === 8 || s === 10) this._kick(t, 1);
        if (s === 4 || s === 12) this._snare(t, 1.1);
        if (s % 2 === 0) this._hat(t, 0.5);
        if (s === 0 && bar % 4 === 0) this._hat(t, 1.2, true);
        if (bar % 4 >= 2 && s % 2 === 0 && h(bar, s) % 3 !== 0) this._pluck(t, r + 36 + PENT[h(bar, s + 5) % 5], 0.25, 0.1, 'square', 2800);
      } else {
        const off = [0, 0, 8, 10][bar % 4], r = root + off;
        this._kick(t, s % 4 === 0 ? 1 : 0); if (s % 4 === 2) this._hat(t, 0.8, true); if (s % 2 === 1) this._hat(t, 0.4);
        if (s === 4 || s === 12) this._snare(t, 0.5);
        if (s % 4 === 2) this._bass(t, mtof(r), 0.18, 'sawtooth', 700, 0.45);
        if (s === 3 || s === 7 || s === 11) this._pluck(t, r + 36 + [0, 3, 7][(s >> 2) % 3], 0.14, 0.09, 'square', 3000);
        if (bar % 8 === 7 && s % 2 === 0) this._noise(t, 0.12, 'highpass', 800 + s * 400, 6000, 0.8, 0.12, mb);
      }
      return;
    }
    // adaptive score: calm -> danger -> chase
    const I = this.intensity, r = 38 + [0, 8, 3, 5][bar % 4];
    if (s === 0) this._pad(t, [r + 12, r + 15, r + 19], 60 / (78 + I * 28) * 4, 0.09, 'sawtooth', 500 + I * 300);
    if (I > 0.4 && s % 2 === 0) this._bass(t, mtof(r), 0.16, 'sawtooth', 350 + I * 200, 0.28 * Math.min(1, I));
    if (I > 0.4 && (s === 0 || s === 8)) this._kick(t, 0.7);
    if (I > 1.2) { if (s % 4 === 0) this._kick(t, 0.8); if (s === 4 || s === 12) this._snare(t, 0.7); if (s % 2 === 1) this._hat(t, 0.5); if (s % 2 === 0) this._pluck(t, r + 36 + PENT[h(bar, s) % 5], 0.12, 0.07, 'square', 2200); }
    if (I < 0.4 && s % 8 === 0 && h(bar, s) % 3 === 0) this._pluck(t, r + 24 + PENT[h(bar, s + 1) % 5], 1.2, 0.05, 'sine', 1500);
  }
}
