// ===== zombie.js — v8 ZOMBIE MODE: infected AI (walker / runner / brute / spitter / bloater / tyrant), police + army + civilians that fight, flee or hide,
// infection, reanimation, safe zones, supply drops, horde surges, blackout / fog / fires, and the glue to the campaign (zcampaign.js). =====
import { T } from './world.js';
import { WEAPONS, AMMO_MAX, VEHICLES } from './data.js';
import { clamp, rnd, pick, chance, rotToward, TAU } from './util.js';
import { P } from './fx.js';
import { stepActor, spawnActor, spawnVehicle, randomLook } from './actors.js';
import { fireWeapon, damageActor, damageVehicle, inVehicleBox, ZMF } from './combat.js';
import { paintOnChunks } from './gfx.js';
import { randomLaneSpawn } from './ai.js';
import { npcTurret } from './vehicles2.js';
import { campaignStep, hudUpdate, startCampaign, hudDestroy, setChapter } from './zcampaign.js';

const hyp = Math.hypot;
export const ZT = {
  walker: { hp: 70, spd: 54, dmg: 11, rate: 1.1, inf: 10, sz: 1, vis: 360, skin: '#8fae7a' },
  runner: { hp: 42, spd: 160, dmg: 8, rate: 0.7, inf: 8, sz: 0.95, vis: 440, skin: '#a3b86c' },
  brute: { hp: 430, spd: 76, dmg: 30, rate: 1.5, inf: 22, sz: 1.6, vis: 380, skin: '#6f8f63' },
  spitter: { hp: 58, spd: 60, dmg: 9, rate: 1.2, inf: 10, sz: 1, vis: 440, skin: '#a8d65a' },
  bloater: { hp: 150, spd: 44, dmg: 14, rate: 1.4, inf: 14, sz: 1.4, vis: 320, skin: '#b9c47c' },
  tyrant: { hp: 4200, spd: 92, dmg: 46, rate: 1.3, inf: 30, sz: 2.7, vis: 1000, skin: '#5a7a52' },
};
const WALKZ = [T.SIDEWALK, T.PLAZA, T.PATH, T.SAND, T.WOOD, T.QUAY, T.DESERT, T.GRAVEL, T.TURF, T.CONCRETE, T.TARMAC, T.FOREST, T.FARM, T.ROAD, T.GRASS, T.DIRT, T.PARKING];
const inView = (g, x, y, pad = 80) => Math.abs(x - g.cam.x) < g.viewW / 2 + pad && Math.abs(y - g.cam.y) < g.viewH / 2 + pad;
const night = (g) => g.env.dark > 0.55;
const unit = (x, y) => { const l = hyp(x, y) || 1; return [x / l, y / l]; };

// ---------------------------------------------------------------- HUD helpers
export function radio(g, from, text, t = 8) { const z = g.zm; if (!z) return; z.radioQ = z.radioQ || []; z.radioQ.push({ from, text, t }); }
export function banner(g, text, color = '#ff5a5a', sub = '') { const z = g.zm; if (!z) return; z.banner = { text, sub, color, t: 4.2 }; }
export function addSafe(g, s) { const z = g.zm; if (z.safe.some((q) => q.id === s.id)) return; z.safe.push({ r: 240, n: 4, kind: 'pd', ...s, def: 0, ammoT: 0 }); }
export function ringPoint(g, cx, cy, rmin, rmax, tries = 12) {
  for (let i = 0; i < tries; i++) { const s = g.world.randomWalkable(cx, cy, rmax, WALKZ); if (s && hyp(s.x - cx, s.y - cy) >= rmin) return s; }
  const a = Math.random() * TAU, r = (rmin + rmax) / 2; return { x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r };
}
export function playerAt(g, x, y, r) { const p = g.player; return !g.scene && hyp(p.x - x, p.y - y) < r; }

// ---------------------------------------------------------------- factories
function zLook(kind) {
  const s = ZT[kind], L = randomLook('civ', 'civ'); L.skin = s.skin; L.sz = s.sz; L.hair = chance(0.3) ? '#2a2a22' : L.hair; L.shades = false; L.zed = kind; L.vest = false;
  if (kind === 'brute') { L.shirt = '#4b3b34'; L.pants = '#2a2a2e'; L.build = 1.25; } else if (kind === 'spitter') { L.shirt = '#5d7a2f'; } else if (kind === 'bloater') { L.shirt = '#7a8a4a'; L.build = 1.3; } else if (kind === 'tyrant') { L.shirt = '#3a2a3f'; L.pants = '#1d1d22'; L.build = 1.2; L.hair = '#111'; }
  return L;
}
export function makeZombie(g, kind, x, y, o = {}) {
  const s = ZT[kind]; const a = spawnActor(g, 'zombie', x, y, { fac: 'zed', hp: s.hp * (o.hpMul || 1), w: 'fists', look: zLook(kind), speed: s.spd }); if (!a) return null;
  a.zed = true; a.zk = kind; a.noLoot = true; a.st = 'zed'; a.zt = Math.random() * 0.3; a.cool = Math.random(); a.a = a.aim = Math.random() * TAU; a.tg = null; a.inv = o.hunt ? { x: o.hunt.x, y: o.hunt.y, t: 40 } : null; a.charge = 0; a.chargeCD = rnd(1, 3); a.boss = kind === 'tyrant'; a.r = 8 * Math.min(1.6, s.sz);
  return a;
}
export function makeSurvivor(g, x, y, o = {}) {
  const a = spawnActor(g, 'civ', x, y, { fac: 'civ', hp: 85, w: chance(0.55) ? 'pistol' : 'bat' }); if (!a) return null;
  a.survivor = true; a.hide = !!o.hide; a.noLoot = true; a.speed = 108; a.dmgMul = 0.9; a.crouch = !!o.hide; a.st = 'stay'; a.noTurn = false; a.ally = true; a.zt = 0; return a;
}
export function makeSoldier(g, x, y, o = {}) {
  const swat = o.swat, a = spawnActor(g, swat ? 'swat' : o.army ? 'army' : 'cop', x, y, { fac: 'pd', hp: swat || o.army ? 130 : 100, armor: swat || o.army ? 30 : 0, w: o.w || (o.army ? pick(['rifle', 'rifle', 'smg']) : swat ? 'rifle' : pick(['pistol', 'pistol', 'smg', 'shotgun'])) }); if (!a) return null;
  a.dmgMul = o.army || swat ? 1.15 : 0.95; a.speed = 92 + Math.random() * 20; a.noLoot = true; a.st = 'idle'; a.post = o.post || null; a.soldier = !!o.army; a.zt = Math.random() * 0.3; return a;
}
export function spawnHorde(g, x, y, n, o = {}) {
  const lvl = g.zm.ch, out = [];
  for (let i = 0; i < n; i++) {
    const s = o.near ? { x: x + rnd(-o.near, o.near), y: y + rnd(-o.near, o.near) } : ringPoint(g, x, y, o.rmin || 300, o.rmax || 600); if (!s) continue;
    if (g.world.tileAt(s.x, s.y) === T.BUILDING || g.world.tileAt(s.x, s.y) === T.WATER) continue;
    const r = Math.random(); let k = o.kind || 'walker';
    if (!o.kind) { const rr = night(g) ? 1.25 : 1; if (lvl >= 1 && r < 0.05) k = 'brute'; else if (lvl >= 2 && r < 0.12) k = 'spitter'; else if (lvl >= 2 && r < 0.17) k = 'bloater'; else if (r < 0.2 + 0.1 * rr) k = 'runner'; }
    const a = makeZombie(g, k, s.x, s.y, { hunt: o.hunt }); if (a) out.push(a);
  }
  return out;
}
export function findWater(g, cx, cy, def, rmin, rmax, pad = 12) {
  const w = g.world;
  for (let i = 0; i < 300; i++) { const a = Math.random() * TAU, r = rmin + Math.random() * (rmax - rmin), x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r; if (w.tileAt(x, y) !== T.WATER) continue; const h = Math.random() * TAU; if (hullFreeLazy(g, x, y, h, def, pad)) return { x, y, a: h }; }
  return null;
}
import { hullFree as hullFreeLazy } from './vehicles2.js';

// ---------------------------------------------------------------- audio (synthesised)
let lastGroan = 0;
export function groan(g, x, y, kind = 'z') {
  const A = g.audio; if (!A.ok || !A.ctx || A.ctx.state !== 'running') return; const now = A.ctx.currentTime; if (now - lastGroan < 0.18) return;
  const d = hyp(x - g.cam.x, y - g.cam.y), v = clamp(1 - d / 950, 0, 1); if (v < 0.06) return; lastGroan = now;
  try {
    const c = A.ctx, o = c.createOscillator(), f = c.createBiquadFilter(), gn = c.createGain(), lfo = c.createOscillator(), lg = c.createGain();
    const base = kind === 'scream' ? 560 + Math.random() * 300 : kind === 'boss' ? 38 + Math.random() * 12 : 70 + Math.random() * 50, dur = kind === 'scream' ? 0.55 : kind === 'boss' ? 1.6 : 0.7 + Math.random() * 0.5;
    o.type = kind === 'scream' ? 'triangle' : 'sawtooth'; o.frequency.setValueAtTime(base, now); o.frequency.exponentialRampToValueAtTime(base * (kind === 'scream' ? 1.5 : 0.62), now + dur);
    lfo.frequency.value = kind === 'scream' ? 9 : 6 + Math.random() * 4; lg.gain.value = base * 0.12; lfo.connect(lg); lg.connect(o.frequency);
    f.type = 'lowpass'; f.frequency.value = kind === 'scream' ? 2400 : 480; f.Q.value = 4;
    gn.gain.setValueAtTime(0.0001, now); gn.gain.exponentialRampToValueAtTime(0.32 * v * (kind === 'boss' ? 2 : 1), now + 0.08); gn.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    o.connect(f); f.connect(gn); gn.connect(A.sfxBus || c.destination); o.start(now); lfo.start(now); o.stop(now + dur + 0.05); lfo.stop(now + dur + 0.05);
  } catch (e) { /* ignore */ }
}

// ---------------------------------------------------------------- movement helper (straight when clear, A* otherwise)
function steerTo(g, a, dt, tx, ty) {
  const d = hyp(tx - a.x, ty - a.y); if (g.scene || d < 70) return unit(tx - a.x, ty - a.y);
  a.pathT = (a.pathT || 0) - dt; a.losT = (a.losT || 0) - dt;
  if (a.losT <= 0) { a.losT = 0.3 + Math.random() * 0.25; a.losV = g.lineClear(a.x, a.y, tx, ty); }
  if (a.losV) { a.path = null; return unit(tx - a.x, ty - a.y); }
  if (!a.path || a.pi >= a.path.length || a.pathT <= 0) { a.path = g.world.path(a.x, a.y, tx, ty, { max: 460 }); a.pi = 0; a.pathT = 1.2 + Math.random() * 0.9; }
  if (a.path && a.pi < a.path.length) { const n = a.path[a.pi]; if (hyp(n.x - a.x, n.y - a.y) < 15) a.pi++; return unit(n.x - a.x, n.y - a.y); }
  return unit(tx - a.x, ty - a.y);
}
function sep(g, a) {
  let sx = 0, sy = 0; const q = (g._zs = g._zs || []); q.length = 0; g.hashA.query(a.x, a.y, 26, q);
  for (const b of q) { if (b === a || !b.on || b.dead || b.veh) continue; const dx = a.x - b.x, dy = a.y - b.y, d2 = dx * dx + dy * dy; if (d2 < 400 && d2 > 0.01) { const d = Math.sqrt(d2); sx += dx / d * (20 - d) / 20; sy += dy / d * (20 - d) / 20; } }
  return [sx, sy];
}

// ---------------------------------------------------------------- the infected
function pickTarget(g, a, s) {
  const q = (g._zq = g._zq || []); q.length = 0; g.hashA.query(a.x, a.y, s.vis * (night(g) ? 0.85 : 1), q); let best = null, bs = 1e9;
  for (const b of q) {
    if (b === a || !b.on || b.dead || b.zed || b.hide || b.inside !== a.inside) continue; const d = hyp(b.x - a.x, b.y - a.y); if (d > s.vis) continue; let sc = d;
    if (d > 110 && !g.lineClear(a.x, a.y, b.x, b.y)) { if (d > 240) continue; sc += 150; } if (sc < bs) { bs = sc; best = b; }
  }
  return best;
}
function bite(g, a, t, s) {
  const z = g.zm; a.cool = s.rate * (0.85 + Math.random() * 0.3); a.swing = 1; const pv = t === g.player ? g.player.veh : null;
  if (pv) { damageVehicle(g, pv, s.dmg * (a.zk === 'brute' || a.zk === 'tyrant' ? 2.2 : 1), { by: a }); g.audio.sfx('thud', a.x, a.y, 0.45); if (Math.random() < 0.25) g.cam.shake = Math.max(g.cam.shake, 3); return; }
  const dx = t.x - a.x, dy = t.y - a.y, m = a.charge > 0 ? 1.6 : 1; damageActor(g, t, s.dmg * m, { by: a, kind: 'melee', dx, dy }); const [ux, uy] = unit(dx, dy); const kn = a.zk === 'tyrant' ? 420 : a.zk === 'brute' ? 260 : 40; t.kx += ux * kn; t.ky += uy * kn; if (kn > 100) t.stun = Math.max(t.stun, 0.5);
  g.audio.sfx('flesh', t.x, t.y, 0.55);
  if (t === g.player && !g.cheats.god) { z.inf = Math.min(100, z.inf + s.inf); z.bitT = 2.5; if (Math.random() < 0.5) groan(g, a.x, a.y); }
}
function zedThink(g, a, dt) {
  const s = ZT[a.zk] || ZT.walker, z = g.zm, nt = night(g);
  if (a.zk === 'tyrant') g.zm.boss = a;
  for (const n of g.noises) { if (a.tg) break; const d = hyp(a.x - n.x, a.y - n.y); if (d < n.r * 0.9) a.inv = { x: n.x, y: n.y, t: 16 }; }
  if (a.stun > 0.25) { stepActor(g, a, dt, 0, 0, 0); return; }
  a.zt -= dt; if (a.zt <= 0) { a.zt = 0.28 + Math.random() * 0.18; a.tg = pickTarget(g, a, s); if (a.tg && Math.random() < 0.12) groan(g, a.x, a.y, a.boss ? 'boss' : 'z'); }
  let t = a.tg; if (t && (!t.on || t.dead || t.inside !== a.inside)) t = a.tg = null;
  let spd = s.spd * (nt ? 1.15 : 1) * (z.enraged && a.boss ? 1.3 : 1), mx = 0, my = 0, sp = 0;
  a.chargeCD -= dt;
  if (t) {
    const pv = t === g.player ? g.player.veh : null, tx = pv ? pv.x : t.x, ty = pv ? pv.y : t.y, d = hyp(tx - a.x, ty - a.y), ang = Math.atan2(ty - a.y, tx - a.x), los = d < 80 || g.lineClear(a.x, a.y, tx, ty);
    const reach = pv ? inVehicleBox(pv, a.x, a.y, 10) : d < a.r + (t.r || 8) + 9 + (a.zk === 'tyrant' ? 12 : 0);
    a.a = rotToward(a.a, ang, (a.charge > 0 ? 3 : 10) * dt); a.aim = a.a;
    if (a.zk === 'spitter' && d < 380 && d > 120 && los) { if (a.cool <= 0) { a.cool = 2.1; a.swing = 1; const aa = ang + rnd(-0.06, 0.06); g.bullets.spawn({ x: a.x + Math.cos(aa) * 12, y: a.y + Math.sin(aa) * 12, vx: Math.cos(aa) * 520, vy: Math.sin(aa) * 520, dmg: 9, owner: a, ownerV: null, fac: 'zed', life: 440, kind: 'b', rad: 0 }); g.parts.burst(P.SMOKE, a.x + Math.cos(aa) * 12, a.y + Math.sin(aa) * 12, 4, 40, 0.5, 5, '#9fe04a'); groan(g, a.x, a.y); } }
    else if (reach) { if (a.cool <= 0) bite(g, a, t, s); }
    else {
      if ((a.zk === 'brute' || a.zk === 'tyrant') && a.chargeCD <= 0 && d < (a.boss ? 560 : 300) && d > 110 && los) { a.charge = a.boss ? 1.1 : 0.8; a.chargeCD = a.boss ? 4.5 : 3.6; if (a.boss) groan(g, a.x, a.y, 'boss'); }
      if (a.charge > 0) { a.charge -= dt; [mx, my] = [Math.cos(a.a), Math.sin(a.a)]; sp = spd * (a.boss ? 3.4 : 2.5); g.parts.emit(P.SMOKE, a.x, a.y, 0, 0, 0.5, 5, '#998'); }
      else { [mx, my] = steerTo(g, a, dt, tx, ty); sp = spd; a.a = rotToward(a.a, Math.atan2(my, mx), 8 * dt); }
    }
    if (a.boss) bossThink(g, a, dt, t, d);
  } else if (a.inv) {
    a.inv.t -= dt; const d = hyp(a.inv.x - a.x, a.inv.y - a.y); if (d < 50 || a.inv.t <= 0) a.inv = null; else { [mx, my] = steerTo(g, a, dt, a.inv.x, a.inv.y); sp = spd * 0.8; a.a = rotToward(a.a, Math.atan2(my, mx), 6 * dt); }
  } else {
    a.wt = (a.wt || 0) - dt; if (a.wt <= 0) { a.wt = 2 + Math.random() * 4; a.wd = Math.random() < 0.3 ? null : Math.random() * TAU; }
    if (a.wd !== null && a.wd !== undefined) { mx = Math.cos(a.wd); my = Math.sin(a.wd); sp = spd * 0.3; a.a = rotToward(a.a, a.wd, 3 * dt); }
    if (Math.random() < dt * 0.04) groan(g, a.x, a.y);
  }
  const [sx, sy] = sep(g, a); mx += sx * 0.6; my += sy * 0.6; const l = hyp(mx, my); if (l > 1) { mx /= l; my /= l; }
  stepActor(g, a, dt, mx, my, sp);
}
function bossThink(g, a, dt, t, d) {
  const z = g.zm; a.slamCD = (a.slamCD === undefined ? 3 : a.slamCD) - dt; const hp = a.hp / a.max;
  if (!z.p2 && hp < 0.66) { z.p2 = true; banner(g, 'THE TYRANT ROARS', '#ff5a5a', 'The horde answers…'); groan(g, a.x, a.y, 'boss'); g.cam.shake = 18; spawnHorde(g, a.x, a.y, 9, { near: 280, hunt: g.player }); radio(g, 'Okafor', 'It is calling them! Keep moving, keep shooting!'); }
  if (!z.p3 && hp < 0.33) { z.p3 = true; z.enraged = true; banner(g, 'TYRANT ENRAGED', '#ff2a2a'); groan(g, a.x, a.y, 'boss'); g.cam.shake = 22; spawnHorde(g, a.x, a.y, 10, { near: 300, hunt: g.player, kind: 'runner' }); }
  if (a.slamTele > 0) { a.slamTele -= dt; a.stun = 0; if (a.slamTele <= 0) { g.parts.emit(P.RING, a.x, a.y, 0, 0, 0.6, 150, '#ffb070'); g.parts.burst(P.DEBRIS, a.x, a.y, 24, 320, 0.8, 5, '#777'); g.cam.shake = Math.max(g.cam.shake, 20); g.audio.sfx('explosion', a.x, a.y, 0.7);
    for (const b of g.actors) { if (!b.on || b.dead || b.zed || b.inside !== a.inside) continue; const dd = hyp(b.x - a.x, b.y - a.y); if (dd < 150) { damageActor(g, b, 38 * (1 - dd / 220), { by: a, kind: 'melee', dx: b.x - a.x, dy: b.y - a.y }); const [ux, uy] = unit(b.x - a.x, b.y - a.y); b.kx += ux * 520; b.ky += uy * 520; b.stun = 0.8; if (b === g.player) z.inf = Math.min(100, z.inf + 12); } }
    for (const v of g.vehicles) if (v.on && hyp(v.x - a.x, v.y - a.y) < 150 + v.def.len / 2) { damageVehicle(g, v, 140, { by: a }); const [ux, uy] = unit(v.x - a.x, v.y - a.y); v.vx += ux * 300 / v.def.mass; v.vy += uy * 300 / v.def.mass; } } }
  else if (a.slamCD <= 0 && d < 140) { a.slamCD = 3.6; a.slamTele = 0.55; a.cool = 1; }
}

// ---------------------------------------------------------------- humans: police, soldiers, survivors, armed civilians
function pickFoe(g, a, rng = 520) {
  const q = (g._zf = g._zf || []); q.length = 0; g.hashA.query(a.x, a.y, rng, q); let best = null, bd = rng;
  for (const b of q) { if (!b.on || b.dead || !b.zed || b.inside !== a.inside) continue; const d = hyp(b.x - a.x, b.y - a.y); if (d < bd && (d < 130 || g.lineClear(a.x, a.y, b.x, b.y))) { bd = d; best = b; } }
  return best;
}
function humanThink(g, a, dt) {
  const z = g.zm, p = g.player;
  if (a.stun > 0.25) { stepActor(g, a, dt, 0, 0, 0); return; }
  a.wdef = WEAPONS[a.wid] || WEAPONS.fists; a.zt -= dt;
  if (a.zt <= 0) { a.zt = 0.25 + Math.random() * 0.15; a.tg = pickFoe(g, a, a.hide ? 260 : 520); a.los = a.tg ? g.lineClear(a.x, a.y, a.tg.x, a.tg.y) : false; }
  let t = a.tg; if (t && (!t.on || t.dead || t.inside !== a.inside)) t = a.tg = null;
  let mx = 0, my = 0, sp = 0; const melee = a.wdef.type === 'melee', spd = a.speed * (a.soldier ? 1.15 : 1.25);
  if (a.hide) {
    a.crouch = true; if (!g.scene && hyp(p.x - a.x, p.y - a.y) < 150 && !p.dead) { a.hide = false; a.crouch = false; a.follow = true; z.joined = (z.joined || 0) + 1; g.toast('Survivor joined you — keep them alive!', '#7cff4f'); g.audio.sfx('pickup'); radio(g, 'Survivor', pick(['Thank God — please, get us out of here!', 'I thought nobody was coming!', 'Stay close, I’ll cover you!']), 5); }
  }
  if (t) {
    const dx = t.x - a.x, dy = t.y - a.y, d = hyp(dx, dy), ang = Math.atan2(dy, dx); a.aim = ang; a.a = rotToward(a.a, ang, 12 * dt);
    const range = melee ? 38 : Math.min(a.wdef.range * 0.62, 400), close = melee ? null : pickFoe(g, a, 85);
    if (a.hide) { /* stay low */ }
    else if (close && !melee) { const [ux, uy] = unit(a.x - close.x, a.y - close.y); mx = ux; my = uy; sp = spd * 1.05; }
    else if (melee ? d > 34 : d > range * 0.95 || !a.los) { [mx, my] = steerTo(g, a, dt, t.x, t.y); sp = a.post && hyp(a.x - a.post.x, a.y - a.post.y) > a.post.r ? 0 : spd * 0.8; }
    else { const [ux, uy] = unit(-dy, dx); mx = ux * a.strafe * 0.4; my = uy * a.strafe * 0.4; sp = spd * 0.3; if (Math.random() < dt * 0.4) a.strafe *= -1; }
    if (a.cool <= 0 && (a.los || melee) && (melee ? d < 44 : d < range * 1.3)) { a.aim = ang + rnd(-0.05, 0.05); fireWeapon(g, a); }
  } else if (!a.hide) {
    if (a.post) { const d = hyp(a.x - a.post.x, a.y - a.post.y); if (d > a.post.r * 0.6) { [mx, my] = steerTo(g, a, dt, a.post.x + rnd(-40, 40), a.post.y + rnd(-40, 40)); sp = spd * 0.7; a.a = rotToward(a.a, Math.atan2(my, mx), 6 * dt); } else a.a += Math.sin(g.time * 0.7 + a.i) * dt * 0.4; }
    else if (a.follow || a.survivor) { const d = hyp(p.x - a.x, p.y - a.y), v = p.veh; if (d > (a.follow ? 90 : 700)) { [mx, my] = steerTo(g, a, dt, p.x + rnd(-30, 30), p.y + rnd(-30, 30)); sp = spd * (d > 280 ? 1.35 : 0.85); a.a = rotToward(a.a, Math.atan2(my, mx), 8 * dt); }
      if (a.follow && v && d < 150 && hyp(v.vx, v.vy) < 90 && z.cargo < 4 && !g.scene) { z.cargo++; a.on = false; g.toast(`Survivor boarded (${z.cargo}) — drive them to a safe zone`, '#7cff4f'); } }
    else if (a.st !== 'stay') {
      const d = hyp(p.x - a.x, p.y - a.y); a.wt = (a.wt || 0) - dt;
      if (d > 480 && d < 1400 && !p.dead) { [mx, my] = steerTo(g, a, dt, p.x + rnd(-120, 120), p.y + rnd(-120, 120)); sp = spd * 0.65; a.a = rotToward(a.a, Math.atan2(my, mx), 6 * dt); }
      else if (a.wt <= 0) { a.wt = 2 + Math.random() * 3; a.wd = Math.random() < 0.4 ? null : Math.random() * TAU; } else if (a.wd !== null && a.wd !== undefined) { mx = Math.cos(a.wd); my = Math.sin(a.wd); sp = spd * 0.25; a.a = rotToward(a.a, a.wd, 3 * dt); }
    }
  }
  const [sx, sy] = sep(g, a); mx += sx * 0.7; my += sy * 0.7; const l = hyp(mx, my); if (l > 1) { mx /= l; my /= l; }
  stepActor(g, a, dt, mx, my, sp);
  if (a.reload > 0) a.reload -= dt;
}
function nearestSafe(g, x, y) { let b = null, bd = 2200; for (const s of g.zm.safe) { const d = hyp(s.x - x, s.y - y); if (d < bd) { bd = d; b = s; } } return b; }
function civThink(g, a, dt) {
  const z = g.zm; if (a.mis) return false;
  if (a.armedCiv) { a.zt -= dt; if (a.zt <= 0) { a.zt = 0.3; a.tg = pickFoe(g, a, 380); } if (a.tg && a.tg.on && !a.tg.dead) { humanThink(g, a, dt); return true; } }
  a.ct = (a.ct || 0) - dt;
  if (a.ct <= 0) { a.ct = 0.35 + Math.random() * 0.2; a.thr = null; const q = (g._zc = g._zc || []); q.length = 0; g.hashA.query(a.x, a.y, 300, q); let bd = 300; for (const b of q) { if (!b.on || b.dead || !b.zed || b.inside !== a.inside) continue; const d = hyp(b.x - a.x, b.y - a.y); if (d < bd && (d < 140 || g.lineClear(a.x, a.y, b.x, b.y))) { bd = d; a.thr = b; } } if (a.thr) { if (!(a.zfear > 0) && Math.random() < 0.5) groan(g, a.x, a.y, 'scream'); a.zfear = 4; a.fear = 1; } }
  if (!(a.zfear > 0)) { if (a.fleeing) { a.fleeing = false; a.path = null; a.st = 'idle'; a.t = 1; } return false; }
  a.zfear -= dt; a.fleeing = true; a.st = 'flee';
  let mx = 0, my = 0; const th = a.thr && a.thr.on && !a.thr.dead ? a.thr : null; if (th) { const [ux, uy] = unit(a.x - th.x, a.y - th.y); mx = ux; my = uy; }
  const sf = nearestSafe(g, a.x, a.y); if (sf) { const [ux, uy] = steerTo(g, a, dt, sf.x, sf.y); mx += ux * 0.9; my += uy * 0.9; if (hyp(a.x - sf.x, a.y - sf.y) < sf.r * 0.55) { a.on = false; z.evac++; z.evacT = 3; return true; } }
  if (!g.scene && a.zfear < 3.3) { const door = g.world.nearestEnterable(a.x, a.y, 80); if (door && Math.random() < dt * 1.5) { a.on = false; z.hid = (z.hid || 0) + 1; return true; } }
  const [sx, sy] = sep(g, a); mx += sx; my += sy; const l = hyp(mx, my) || 1; mx /= l; my /= l; a.a = rotToward(a.a, Math.atan2(my, mx), 10 * dt);
  stepActor(g, a, dt, mx, my, 150); return true;
}
export function zmThink(g, a, dt) {
  if (a.zed) { zedThink(g, a, dt); return true; }
  if (a.fac === 'pd' || a.survivor) { humanThink(g, a, dt); return true; }
  if (a.fac === 'civ') return civThink(g, a, dt);
  return false;
}

// ---------------------------------------------------------------- kills, drops, reanimation
function turnZombie(g, a) {
  if (!a.on || !a.dead || !a.turning) return; const s = ZT.walker;
  a.dead = false; a.deadT = 0; a.zed = true; a.zk = 'walker'; a.fac = 'zed'; a.hp = a.max = s.hp * 0.85; a.look = { ...a.look, skin: s.skin, sz: 1, zed: 'walker' }; a.wid = 'fists'; a.wdef = WEAPONS.fists; a.survivor = false; a.ally = false; a.post = null; a.armedCiv = false; a.turning = false; a.hide = false; a.follow = false;
  a.noLoot = true; a.stun = 1.1; a.cool = 1; a.tg = null; a.inv = null; a.speed = s.spd; a.st = 'zed'; a.fire = 0; a.veh = null; a.r = 8; g.zm.turned++; a.kx = a.ky = 0;
  g.parts.burst(P.BLOOD, a.x, a.y, 8, 90, 0.5, 2.4, '#4a6b2a'); groan(g, a.x, a.y);
}
export function zmOnKill(g, a, src) {
  const z = g.zm; if (!z) return; const by = src && src.by;
  if (a.zed) {
    z.kills++; z.chKills++; if (by === g.player) z.pKills++; z.combo = (z.combo || 0) + 1; z.comboT = 4;
    paintOnChunks(g.world, a.x, a.y, a.x, a.y, (c) => { c.fillStyle = 'rgba(40,70,20,.55)'; c.beginPath(); c.ellipse(a.x, a.y, 15 + (a.zk === 'brute' ? 8 : 0), 10, Math.random() * 3, 0, 6.3); c.fill(); });
    if (a.zk !== 'walker' || Math.random() < 0.9) { const r = Math.random(); const dr = a.zk === 'tyrant' ? 0 : r < 0.1 ? 'med' : r < 0.25 ? 'ammo' : r < 0.29 ? 'cure' : r < 0.33 ? 'armor' : null; if (dr) g.pickups.push({ type: dr, x: a.x + rnd(-8, 8), y: a.y + rnd(-8, 8), v: 20, life: 70, inside: a.inside }); }
    if (a.zk === 'bloater') { g.parts.burst(P.SMOKE, a.x, a.y, 24, 110, 1.6, 14, '#9acb3a'); g.parts.burst(P.BLOOD, a.x, a.y, 16, 160, 0.8, 4, '#7aa832'); g.audio.sfx('splash', a.x, a.y, 0.9); g.fires.push({ x: a.x, y: a.y, r: 40, life: 3, by: null });
      for (const b of g.actors) { if (!b.on || b.dead || b.zed || b.inside !== a.inside) continue; const d = hyp(b.x - a.x, b.y - a.y); if (d < 105) { damageActor(g, b, 30 * (1 - d / 140), { by: a, kind: 'explosion', dx: b.x - a.x, dy: b.y - a.y }); if (b === g.player) z.inf = Math.min(100, z.inf + 20); } } }
    if (a.zk === 'tyrant') { z.bossDead = true; banner(g, 'THE TYRANT HAS FALLEN', '#7cff4f'); g.cam.shake = 24; g.parts.burst(P.FIRE, a.x, a.y, 30, 200, 1, 12, '#9f6'); }
    if (by === g.player && z.combo >= 5 && z.combo % 5 === 0) { g.cash += z.combo * 10; g.toast(`KILLING SPREE x${z.combo}  +$${z.combo * 10}`, '#ffe14a'); }
    else if (by === g.player && Math.random() < 0.5) { g.cash += 8; }
    return;
  }
  if (a.survivor) { z.lost++; g.toast('A survivor was lost…', '#ff7788'); }
  if (a.fac === 'pd') { z.officersDown = (z.officersDown || 0) + 1; if (Math.random() < 0.4) radio(g, 'Dispatch', 'Officer down! We are losing the line!', 4); }
  if (a.fac === 'civ' && by === g.player) z.civKilled = (z.civKilled || 0) + 1;
  if ((a.fac === 'civ' || a.fac === 'pd') && by && by.zed && !a.noTurn) { a.turning = true; g.later(3 + Math.random() * 3.5, () => turnZombie(g, a)); }
}

// ---------------------------------------------------------------- population, events, environment
function population(g, dt) {
  const z = g.zm, p = g.player; z.popT -= dt; if (z.popT > 0) return; z.popT = 0.5;
  const q = g.settings.quality, lvl = z.dens * (night(g) ? 1.25 : 1), cap = Math.round((11 + 24 * lvl) * (q === 'low' ? 0.65 : q === 'medium' ? 0.85 : 1)), dist = g.world.districtAt(p.x, p.y);
  let n = 0, nPd = 0; for (const a of g.actors) if (a.on && !a.dead && a !== p) { const d = hyp(a.x - p.x, a.y - p.y); if (a.zed && d < 1500) n++; else if (a.fac === 'pd' && d < 1300 && !a.inside) nPd++; if (a.fac === 'civ' && !a.zchecked && !a.mis) { a.zchecked = true; if (!a.survivor && chance(0.1)) { a.armedCiv = true; a.wid = 'pistol'; a.wdef = WEAPONS.pistol; a.dmgMul = 0.8; a.brave = true; } } }
  z.nZ = n;
  if (n < cap && !z.noSpawn) for (let k = 0; k < 2; k++) {
    const s = g.world.randomWalkable(p.x, p.y, 1050, WALKZ); if (!s || hyp(s.x - p.x, s.y - p.y) < 560 || inView(g, s.x, s.y, 70) || g.world.tileAt(s.x, s.y) === T.WATER) continue;
    const grp = chance(0.4) ? 2 + Math.floor(Math.random() * 3) : 1; spawnHorde(g, s.x, s.y, grp, { near: 40, hunt: chance(0.45) ? p : null });
  }
  if (z.helpers !== false && nPd < z.pdWant && dist !== 'ocean' && chance(0.45)) {
    const s = g.world.randomWalkable(p.x, p.y, 1000, WALKZ); if (s && hyp(s.x - p.x, s.y - p.y) > 560 && !inView(g, s.x, s.y, 70)) { const army = dist === 'fort' || dist === 'fortbase' || z.ch >= 5 && chance(0.35); for (let i = 0; i < 2; i++) makeSoldier(g, s.x + rnd(-24, 24), s.y + rnd(-24, 24), { army }); }
  }
}
export function dropSupplies(g, x, y, big) {
  const L = [['ammo', 3], ['med', 2], ['cure', 1], ['armor', 1]]; if (big) L.push(['ammo', 2], ['med', 1]);
  for (const [t, c] of L) for (let i = 0; i < c; i++) g.pickups.push({ type: t, x: x + rnd(-34, 34), y: y + rnd(-34, 34), v: 30, life: 120 });
  g.audio.sfx('pickup'); g.noise(x, y, 800, { by: null });
}
function events(g, dt) {
  const z = g.zm, p = g.player; if (z.ch < 1 || g.scene) return;
  if (z.surgeOK !== false && (z.surgeT -= dt) <= 0) {
    z.surgeT = rnd(95, 165); const a0 = Math.random() * TAU, dirs = ['EAST', 'SOUTH', 'WEST', 'NORTH']; const name = dirs[Math.round(((a0 % TAU) / (TAU / 4))) % 4];
    banner(g, 'HORDE INCOMING', '#ff7a3a', 'from the ' + name); let c = 0; const n = Math.min(24, 10 + z.ch * 2);
    for (let i = 0; i < n; i++) { const a = a0 + rnd(-0.55, 0.55), r = rnd(780, 980), x = p.x + Math.cos(a) * r, y = p.y + Math.sin(a) * r; const t = g.world.tileAt(x, y); if (t === T.BUILDING || t === T.WATER || t === T.MARSH) continue; if (makeZombie(g, Math.random() < 0.3 ? 'runner' : Math.random() < 0.06 && z.ch > 1 ? 'brute' : 'walker', x, y, { hunt: p })) c++; }
    groan(g, p.x, p.y, 'boss'); g.audio.sfx('beep'); z.surges++; void c;
  }
  if ((z.dropT -= dt) <= 0 && !z.drop) { z.dropT = rnd(110, 170); const s = ringPoint(g, p.x, p.y, 380, 700); z.drop = { x: s.x, y: s.y, t: 7, landed: false, life: 90 }; banner(g, 'SUPPLY DROP', '#4fe0ff', 'a crate is coming down — marked on your map'); radio(g, 'Dispatch', 'Supply drop inbound. Flare will draw them too — be ready.', 5); }
  if (z.drop) { const d = z.drop; if (!d.landed) { d.t -= dt; if (d.t <= 0) { d.landed = true; dropSupplies(g, d.x, d.y, true); g.parts.burst(P.SMOKE, d.x, d.y, 24, 60, 4, 14, '#ff4a3a'); g.cam.shake = Math.max(g.cam.shake, hyp(d.x - p.x, d.y - p.y) < 500 ? 8 : 0); spawnHorde(g, d.x, d.y, 4 + Math.floor(z.ch / 2), { rmin: 220, rmax: 420, hunt: { x: d.x, y: d.y } }); } } else { d.life -= dt; if (Math.random() < dt * 8) g.parts.emit(P.SMOKE, d.x + rnd(-4, 4), d.y, rnd(-6, 6), -40, 3, 10, '#ff5a44'); if (d.life <= 0 || !g.pickups.some((k) => hyp(k.x - d.x, k.y - d.y) < 80)) z.drop = null; } }
  if (z.ch >= 2 && (z.distressT -= dt) <= 0) { z.distressT = rnd(140, 210); const s = ringPoint(g, p.x, p.y, 480, 850); if (s) { const grp = []; for (let i = 0; i < 2; i++) { const a = makeSurvivor(g, s.x + rnd(-24, 24), s.y + rnd(-24, 24), { hide: true }); if (a) grp.push(a); } spawnHorde(g, s.x, s.y, 5, { near: 130 }); z.distress = { x: s.x, y: s.y, grp, t: 120 }; banner(g, 'SURVIVORS IN TROUBLE', '#7cff4f', 'cornered nearby — marked on your map'); radio(g, 'Dispatch', 'Civilians pinned down — any unit in range, respond!', 5); } }
  if (z.distress) { z.distress.t -= dt; if (z.distress.t <= 0 || !z.distress.grp.some((a) => a.on && !a.dead && a.hide)) z.distress = null; }
  if ((z.fireT -= dt) <= 0 && !g.scene) { z.fireT = rnd(18, 34); const s = ringPoint(g, p.x, p.y, 300, 700); if (s && g.world.tileAt(s.x, s.y) !== T.WATER) g.fires.push({ x: s.x, y: s.y, r: 50, life: rnd(30, 70), by: null }); }
}
function environment(g, dt) {
  const z = g.zm, e = g.env; e.fogT = Math.max(e.fogT || 0, z.fogBase); e.wtimer = Math.max(e.wtimer, 30);
  const a = e.amb; e.amb = [Math.round(a[0] * 0.9), Math.round(a[1] * 0.98), Math.round(a[2] * 0.88)];
  const fl = Math.sin(g.time * 17) + Math.sin(g.time * 5.3 + 1) + Math.sin(g.time * 31); const flick = z.blackout > 0 && fl > 1.7 ? 0.1 : 1;
  e.lamp = clamp((e.lamp || 0) * (1 - z.blackout) * flick, 0, 1);
  for (const s of z.safe) g.tmpLights.push({ x: s.x, y: s.y, r: s.r * 1.4, col: '#ffd9a0', life: 0.03, max: 0.03, i: 0.9 });
  for (const v of g.vehicles) if (v.on && v.alarm > 0 && Math.random() < dt * 0.9) g.noise(v.x, v.y, 520, { by: null });
  z.wreckT -= dt; if (z.wreckT <= 0 && !g.scene) { z.wreckT = 7; let nw = 0; for (const v of g.vehicles) if (v.on && v.zwreck) nw++; if (nw < 9 && chance(0.6)) { const s = randomLaneSpawn(g, 420, 900); if (s) { const v = spawnVehicle(g, pick(['sedan', 'compact', 'van', 'pickup', 'taxi', 'suv', 'bus']), s.x, s.y, s.dir * Math.PI / 2 + rnd(-0.9, 0.9), { ai: 'none', hot: false }); if (v) { v.zwreck = true; if (chance(0.3)) { v.burning = true; v.hp *= 0.55; } if (chance(0.5)) v.alarm = rnd(8, 20); } } } }
  z.vT = (z.vT || 0) - dt; if (z.vT <= 0) { z.vT = 0.5; for (const v of g.vehicles) { if (!v.on || v.ai !== 'traffic' || v.driver) continue; const q = (g._zv = g._zv || []); q.length = 0; g.hashA.query(v.x, v.y, 110, q); if (q.some((b) => b.zed && b.on && !b.dead)) v.panic = Math.max(v.panic, 4); } }
  for (const v of g.vehicles) if (v.zturret && v.on && !v.driver && !v.wreck) npcTurret(g, v, dt);
}
function infection(g, dt) {
  const z = g.zm, p = g.player; z.bitT = Math.max(0, z.bitT - dt); z.comboT = Math.max(0, (z.comboT || 0) - dt); if (z.comboT <= 0) z.combo = 0;
  if (p.dead || g.deathT > 0) return;
  if (z.inf > 0) { z.inf = Math.max(0, z.inf - (z.bitT > 0 ? 0 : 0.5) * dt); if (z.inf > 30 && Math.random() < dt * 3) g.parts.emit(P.BLOOD, p.x, p.y, rnd(-10, 10), rnd(-10, 10), 0.4, 2, '#5a8a2a'); if (z.inf > 35) damageActor(g, p, (z.inf / 100) * 2.4 * dt, { kind: 'fire', by: null }); if (z.inf >= 100 && !g.cheats.god) { z.turnedDeath = true; damageActor(g, p, 9999, { kind: 'infection' }); } }
  g.fx.ab = Math.max(g.fx.ab, clamp((z.inf - 40) / 120, 0, 0.5));
}
function safeZones(g, dt) {
  const z = g.zm, p = g.player; z.inSafe = null;
  for (const s of z.safe) {
    if (!g.scene && hyp(p.x - s.x, p.y - s.y) < s.r && !p.dead) { z.inSafe = s; p.hp = Math.min(p.max, p.hp + 7 * dt); z.inf = Math.max(0, z.inf - 14 * dt); s.ammoT -= dt; if (s.ammoT <= 0) { s.ammoT = 12; let any = false; for (const k in WEAPONS) { const w = WEAPONS[k]; if (g.inv.have[k] && w.ammo && w.type === 'gun' && (g.inv.ammo[w.ammo] | 0) < AMMO_MAX[w.ammo] * 0.6) { g.inv.ammo[w.ammo] = Math.min(AMMO_MAX[w.ammo], (g.inv.ammo[w.ammo] | 0) + Math.ceil((w.pack || 12) / 2)); any = true; } } if (any) g.toast(`${s.name}: quartermaster restocked your ammo`, '#d9b34a'); }
      if (z.cargo > 0) { g.cash += 120 * z.cargo; z.saved += z.cargo; z.chSaved = (z.chSaved || 0) + z.cargo; g.toast(`${z.cargo} survivor(s) delivered to ${s.name}! +$${120 * z.cargo}`, '#7cff4f'); g.audio.sfx('levelup'); z.cargo = 0; } }
    if (!g.scene) for (const a of g.actors) if (a.on && !a.dead && a.survivor && a.follow && hyp(a.x - s.x, a.y - s.y) < s.r * 0.7) { a.on = false; z.saved++; z.chSaved = (z.chSaved || 0) + 1; g.cash += 120; g.toast(`Survivor delivered to ${s.name}! +$120`, '#7cff4f'); g.audio.sfx('levelup'); }
    s.chk = (s.chk || 0) - dt;
    if (s.chk <= 0 && !g.scene && hyp(p.x - s.x, p.y - s.y) < 1500) { s.chk = 6; let n = 0; for (const a of g.actors) if (a.on && !a.dead && a.post === s.post) n++; if (n < s.n) { const army = s.kind === 'army'; for (let i = 0; i < Math.min(2, s.n - n); i++) { const sp = ringPoint(g, s.x, s.y, s.r * 0.7, s.r * 1.1); if (!inView(g, sp.x, sp.y, 10)) makeSoldier(g, sp.x, sp.y, { army, swat: !army && chance(0.25), post: s.post }); } } }
  }
  if (!z.p0) { z.p0 = true; }
  if (!p.veh && z.cargo > 0) { const n = z.cargo; z.cargo = 0; for (let i = 0; i < n; i++) { const a = makeSurvivor(g, p.x + rnd(-30, 30), p.y + rnd(-30, 30), {}); if (a) a.follow = true; } g.toast('Survivors climb out of the vehicle', '#7cff4f'); }
}
export function zmPickup(g, k) {
  const z = g.zm, p = g.player;
  if (k.type === 'med') { p.hp = Math.min(p.max, p.hp + 55); g.toast('Medkit  +55 health', '#7cff4f'); g.audio.sfx('pickup'); }
  else if (k.type === 'cure') { if (z.inf > 0) g.toast('Antidote — infection cleared', '#9cff6f'); else { g.toast('Antidote  (immunity for 20 s)', '#9cff6f'); z.immune = 20; } z.inf = 0; g.audio.sfx('pickup'); }
  else if (k.type === 'zserum') { z.serum = (z.serum || 0) + 1; g.toast(`Antiviral crate recovered ${z.serum}/3`, '#4fe0ff'); g.audio.sfx('levelup'); }
}

// ---------------------------------------------------------------- per-step entry points
export function zmStep(g, dt) {
  const z = g.zm; if (!z) return; z.t += dt;
  if (z.immune > 0) { z.immune -= dt; z.inf = 0; }
  if (!g.scene) { population(g, dt); events(g, dt); environment(g, dt); }
  else environment(g, 0);
  infection(g, dt); safeZones(g, dt); campaignStep(g, dt); hudUpdate(g, dt);
  if (g.deathT > 0 && z.turnedDeath && g.deathCard) g.deathCard.text = 'You turned. The infection took you.';
  if (g.deathT <= 0 && !g.player.dead) z.turnedDeath = false;
  if (z.drop) { g.markers.push({ x: z.drop.x, y: z.drop.y, kind: 'wp', color: '#4fe0ff', label: 'Supply drop' }); }
  if (z.distress) g.markers.push({ x: z.distress.x, y: z.distress.y, kind: 'wp', color: '#7cff4f', label: 'Survivors' });
}
export function zmRespawn(g) {
  const z = g.zm, p = g.player; z.deaths++; z.inf = 0; z.immune = 6; p.armor = 0; z.combo = 0;
  if (z.cp) { p.x = p.px = z.cp.x; p.y = p.py = z.cp.y + 30; g.cam.x = g.cam.px = p.x; g.cam.y = g.cam.py = p.y; }
  for (const k in g.inv.ammo) g.inv.ammo[k] = Math.max(g.inv.ammo[k], 12); z.cargo = 0;
  for (const a of g.actors) if (a.on && a.zed && hyp(a.x - p.x, a.y - p.y) < 520) a.on = false; // no spawn-camping after a revive
  banner(g, 'YOU WERE REVIVED', '#4fe0ff', 'checkpoint — hold on, Rook');
}
export function zmOnEnterBuilding(g, I) {
  const z = g.zm; if (!z) return;
  const infested = z.ch >= 0 && chance(0.55 + Math.min(0.2, z.ch * 0.03));
  let n = 0; for (const a of g.actors) if (a.on && a !== g.player && a.inside === I.id) { a.noTurn = false; if (a.fac === 'civ' && infested && chance(0.5)) { a.zed = true; a.zk = 'walker'; a.fac = 'zed'; a.hp = a.max = 60; a.look = { ...a.look, skin: ZT.walker.skin }; a.st = 'zed'; a.zt = 0; a.noLoot = true; a.speed = 52; a.stay = false; a.tg = null; n++; } else if (a.fac === 'civ') { a.st = 'stay'; } }
  if (infested) { const pts = I.npcs && I.npcs.length ? I.npcs : [{ x: I.pts.entry.x, y: I.pts.entry.y - 120 }]; for (let i = 0; i < 2 + Math.floor(Math.random() * 3); i++) { const b = pick(pts), x = b.x + rnd(-60, 60), y = b.y + rnd(-60, 60); if (!g.scene.solidAt(x, y) && hyp(x - I.pts.entry.x, y - I.pts.entry.y) > 110) { const a = makeZombie(g, chance(0.15) ? 'runner' : 'walker', x, y, {}); if (a) { a.inside = I.id; n++; } } } }
  if (infested) g.toast('You hear groaning inside…', '#9ccf5a');
  if (chance(0.6)) for (let i = 0; i < 2; i++) { const b = I.npcs && I.npcs.length ? pick(I.npcs) : { x: I.pts.entry.x, y: I.pts.entry.y - 100 }; g.pickups.push({ type: pick(['ammo', 'med', 'ammo', 'cure', 'armor']), x: b.x + rnd(-50, 50), y: b.y + rnd(-50, 50), v: 20, life: 400, inside: I.id }); }
  void n;
}

// ---------------------------------------------------------------- lifecycle
export function beginZombie(g) {
  const z = g.zm = { on: true, t: 0, ch: -1, chT: 0, kills: 0, chKills: 0, pKills: 0, saved: 0, lost: 0, evac: 0, cargo: 0, inf: 0, bitT: 0, deaths: 0, turned: 0, dens: 0.85, blackout: 0, fogBase: 0.22, safe: [], cp: null, popT: 0, wreckT: 4, surgeT: 80, dropT: 100, distressT: 140, fireT: 25, surges: 0, pdWant: 3, done: false, endless: false, hid: 0, joined: 0 };
  ZMF.on = true; if (g.world.turf && g.world.turf.fill) g.world.turf.fill(0);
  z.origKill = g.onKill; g.onKill = (a, s) => { z.origKill && z.origKill(a, s); zmOnKill(g, a, s); }; g.zmPickup = (k) => zmPickup(g, k);
  g.env.hour = 17.6; g.env.weather = 'fog'; g.env.fogT = 0.3; g.env.wtimer = 200;
  const p = g.player; g.inv.have.bat = true; g.giveWeapon('pistol', 36); g.switchWeapon('bat'); p.hp = p.max;
  g.zmCheat = (k) => { const z2 = g.zm, p2 = g.player; if (!z2) return; if (k === 'skip') setChapter(g, z2.ch + 1); else if (k === 'horde') spawnHorde(g, p2.x, p2.y, 16, { rmin: 300, rmax: 520, hunt: p2 }); else if (k === 'drop') { z2.dropT = 0; z2.drop = null; if (z2.ch < 1) z2.ch = 1; } else if (k === 'boss') { const b = makeZombie(g, 'tyrant', p2.x + 300, p2.y, { hunt: p2 }); if (b) z2.boss = b; } else if (k === 'safe') { p2.hp = p2.max; z2.inf = 0; } };
  startCampaign(g);
}
export function endZombie(g) {
  const z = g.zm; if (!z) return; hudDestroy(g); ZMF.on = false; if (z.origKill) g.onKill = z.origKill; g.zm = null; g.zmPickup = null; g.zmCheat = null;
  for (const a of g.actors) if (a.on && (a.zed || a.survivor)) a.on = false;
}
// ---------------------------------------------------------------- world-space overlay (drawn after actors / particles)
export function zmDraw(g, c, alpha, x0, y0, x1, y1) {
  const z = g.zm, t = g.time; if (!z) return;
  for (const s of z.safe) { if (s.x < x0 - s.r || s.x > x1 + s.r || s.y < y0 - s.r || s.y > y1 + s.r) continue; c.save(); c.strokeStyle = 'rgba(255,220,150,.55)'; c.lineWidth = 3; c.setLineDash([14, 10]); c.lineDashOffset = -t * 18; c.beginPath(); c.arc(s.x, s.y, s.r, 0, TAU); c.stroke(); c.fillStyle = 'rgba(255,214,140,.05)'; c.fill(); c.restore(); }
  for (const a of g.actors) {
    if (!a.on || a.inside !== null || a.x < x0 - 60 || a.x > x1 + 60 || a.y < y0 - 60 || a.y > y1 + 60) continue;
    const x = a.px + (a.x - a.px) * alpha, y = a.py + (a.y - a.py) * alpha;
    if (a.zed && !a.dead) {
      const ang = a.pa + (a.a - a.pa) * alpha, sz = ZT[a.zk] ? ZT[a.zk].sz : 1, ex = Math.cos(ang) * 4.5 * sz, ey = Math.sin(ang) * 4.5 * sz, nx = -Math.sin(ang) * 2.2 * sz, ny = Math.cos(ang) * 2.2 * sz;
      c.fillStyle = a.zk === 'spitter' ? '#b6ff3a' : a.zk === 'tyrant' ? '#ff2a2a' : '#ff5a3a'; c.shadowColor = c.fillStyle; c.shadowBlur = 6; c.beginPath(); c.arc(x + ex + nx, y + ey + ny, 1.2 * sz, 0, TAU); c.arc(x + ex - nx, y + ey - ny, 1.2 * sz, 0, TAU); c.fill(); c.shadowBlur = 0;
      if (a.zk === 'bloater') { c.fillStyle = `rgba(150,210,60,${0.18 + 0.12 * Math.sin(t * 5 + a.i)})`; c.beginPath(); c.arc(x, y, 18, 0, TAU); c.fill(); }
      if (a.zk === 'brute' || a.zk === 'bloater') { const w = 24 * sz * 0.8; c.fillStyle = 'rgba(0,0,0,.55)'; c.fillRect(x - w / 2, y - 20 * sz, w, 3); c.fillStyle = '#c33'; c.fillRect(x - w / 2, y - 20 * sz, w * Math.max(0, a.hp / a.max), 3); }
      if (a.slamTele > 0) { c.strokeStyle = `rgba(255,120,60,${0.4 + 0.4 * Math.sin(t * 30)})`; c.lineWidth = 4; c.beginPath(); c.arc(x, y, 150 * (1 - a.slamTele / 0.55) + 20, 0, TAU); c.stroke(); c.fillStyle = 'rgba(255,90,40,.12)'; c.beginPath(); c.arc(x, y, 150, 0, TAU); c.fill(); }
    } else if (a.dead && a.turning) { c.fillStyle = `rgba(120,255,80,${0.25 + 0.25 * Math.sin(t * 12)})`; c.beginPath(); c.arc(x, y, 12 + Math.sin(t * 9) * 2, 0, TAU); c.fill(); }
    else if (a.survivor && !a.dead) { c.fillStyle = a.hide ? '#ffe14a' : '#7cff4f'; c.beginPath(); c.moveTo(x, y - 17); c.lineTo(x + 5, y - 25); c.lineTo(x - 5, y - 25); c.fill(); if (a.hide) { c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillText('HELP!', x, y - 28); } }
    else if (a.fac === 'pd' && !a.dead && a.post) { c.fillStyle = 'rgba(80,160,255,.9)'; c.beginPath(); c.arc(x, y - 18, 2.2, 0, TAU); c.fill(); }
  }
  const d = z.drop; if (d && !d.landed) { const k = Math.max(0, d.t / 7), y = d.y - k * 520; c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(d.x, d.y, 22, 11, 0, 0, TAU); c.fill(); c.fillStyle = '#e8eef5'; c.beginPath(); c.arc(d.x, y - 34, 30, Math.PI, 0); c.fill(); c.strokeStyle = 'rgba(255,255,255,.6)'; c.lineWidth = 1; for (const q of [-28, -10, 10, 28]) { c.beginPath(); c.moveTo(d.x + q, y - 34); c.lineTo(d.x, y); c.stroke(); } c.fillStyle = '#c0392b'; c.fillRect(d.x - 12, y, 24, 18); c.strokeStyle = '#fff'; c.strokeRect(d.x - 12, y, 24, 18); c.fillStyle = '#fff'; c.fillRect(d.x - 2, y + 3, 4, 12); c.fillRect(d.x - 6, y + 7, 12, 4); }
  if (d && d.landed) { c.strokeStyle = `rgba(79,224,255,${0.4 + 0.3 * Math.sin(t * 5)})`; c.lineWidth = 2; c.beginPath(); c.arc(d.x, d.y, 60 + Math.sin(t * 5) * 6, 0, TAU); c.stroke(); }
}
export { VEHICLES };
