// ===== zcampaign.js — v8 "DEAD TIDE" campaign (8 chapters + endless survival) and the zombie-mode HUD =====
import { spawnActor, spawnVehicle } from './actors.js';
import { VEHICLES } from './data.js';
import { rnd, pick, chance } from './util.js';
import { makeZombie, makeSoldier, spawnHorde, ringPoint, playerAt, radio, banner, addSafe, findWater, dropSupplies } from './zombie.js';

const hyp = Math.hypot, POI = (g, k) => g.world.pois[k];
const zedsNear = (g, x, y, r) => { let n = 0; for (const a of g.actors) if (a.on && !a.dead && a.zed && hyp(a.x - x, a.y - y) < r) n++; return n; };
const alive = (g, f) => { let n = 0; for (const a of g.actors) if (a.on && !a.dead && f(a)) n++; return n; };

function finish(g, z, text, cp) {
  if (z.chDone) return; z.chDone = true; if (cp) z.cp = { x: cp.x, y: cp.y }; banner(g, 'CHAPTER COMPLETE', '#7cff4f', text); g.audio.sfx('levelup');
  g.later(3.2, () => { if (g.zm === z) setChapter(g, z.ch + 1); });
}
const CH = [
  { title: 'OUTBREAK', dens: 0.5, black: 0, fog: 0.22,
    start(g, z) { const p = g.player; z.cp = { x: p.x, y: p.y }; spawnVehicle(g, 'sedan', p.x + 80, p.y - 10, -Math.PI / 2, { hot: true, ai: 'none', force: true, color: '#546e7a' });
      spawnHorde(g, p.x, p.y, 6, { rmin: 380, rmax: 620, hunt: p, kind: 'walker' });
      for (let i = 0; i < 5; i++) { const s = ringPoint(g, p.x, p.y, 260, 560), a = spawnActor(g, 'civ', s.x, s.y, { fac: 'civ' }); if (a) { a.zfear = 6; a.fear = 1; } }
      radio(g, 'Dispatch', 'All units — code black across Port Meridian. People are… biting people. Rook, if you can hear this: Dutch at the Gun Den is still holding. Grab the sedan and move!', 11);
      g.waypoint = { ...POI(g, 'gun') }; },
    obj: () => 'Reach the Gun Den and get armed', marks: (g) => [{ ...POI(g, 'gun'), label: 'Gun Den' }],
    step(g, z) { if (playerAt(g, POI(g, 'gun').x, POI(g, 'gun').y, 170)) { g.giveWeapon('shotgun', 18); g.giveWeapon('smg', 90); g.giveWeapon('pistol', 24); g.cash += 300; radio(g, 'Dutch', 'Took you long enough. Shotgun for the close ones, SMG for crowds. Noise draws them, so mix in the bat. Police HQ is still standing — go!', 10); finish(g, z, 'Armed and dangerous', POI(g, 'gun')); } } },
  { title: 'HOLD THE LINE', dens: 1.0, black: 0.12, fog: 0.26,
    start(g, z) { z.ph = 0; g.waypoint = { ...POI(g, 'police') }; radio(g, 'Sgt. Reyes', 'Rook! Get to Police HQ — we are setting up a perimeter. Every barrel we have is pointed at that street.', 8); },
    obj: (g, z) => z.ph === 0 ? 'Fight your way to Police HQ' : `DEFEND POLICE HQ — wave ${Math.min(3, z.wv)}/3 · ${zedsNear(g, POI(g, 'police').x, POI(g, 'police').y, 800)} infected near`, marks: (g) => [{ ...POI(g, 'police'), label: 'Police HQ' }],
    step(g, z, dt) { const hq = POI(g, 'police');
      if (z.ph === 0) { if (playerAt(g, hq.x, hq.y, 340)) { z.ph = 1; z.siege = 0; z.wv = 0; const post = { x: hq.x, y: hq.y + 60, r: 210 }; addSafe(g, { id: 'pd', x: hq.x, y: hq.y + 40, r: 270, name: 'Police HQ', kind: 'pd', n: 7, post });
          for (let i = 0; i < 6; i++) { const s = ringPoint(g, hq.x, hq.y, 80, 220); makeSoldier(g, s.x, s.y, { post, swat: i < 2 }); }
          for (let i = 0; i < 2; i++) { const v = spawnVehicle(g, 'police', hq.x - 120 + i * 240, hq.y + 150, Math.PI / 2 + i, { ai: 'none', hot: true, force: true, cop: true }); if (v) { v.siren = true; v.npc = null; } }
          banner(g, 'DEFEND POLICE HQ', '#ff5a5a', 'hold the line for three waves'); radio(g, 'Sgt. Reyes', 'Here they come! Stay inside the perimeter — my boys will cover you. Aim for the head, conserve ammo!', 8); } return; }
      z.siege += dt; const T = [3, 32, 66];
      if (z.wv < 3 && z.siege >= T[z.wv]) { const w = z.wv++, h = { x: hq.x, y: hq.y }; banner(g, `WAVE ${w + 1}/3`, '#ff7a3a');
        spawnHorde(g, hq.x, hq.y, 8 + w * 3, { rmin: 560, rmax: 780, hunt: h, kind: 'walker' }); spawnHorde(g, hq.x, hq.y, 2 + w * 2, { rmin: 560, rmax: 780, hunt: h, kind: 'runner' });
        if (w >= 1) spawnHorde(g, hq.x, hq.y, w, { rmin: 600, rmax: 800, hunt: h, kind: 'brute' }); if (w >= 2) spawnHorde(g, hq.x, hq.y, 3, { rmin: 600, rmax: 800, hunt: h, kind: 'spitter' });
        radio(g, 'Sgt. Reyes', ['Contact north! Light them up!', 'Second wave — they brought something big!', 'Last push! Everything we have!'][w], 5); }
      if (z.wv >= 3 && (z.siege > 72 && zedsNear(g, hq.x, hq.y, 760) <= 1 || z.siege > 190)) { g.cash += 1500; g.player.armor = 100; g.giveWeapon('rifle', 120); const v = spawnVehicle(g, 'swat', hq.x + 60, hq.y + 170, 0, { ai: 'none', hot: true, force: true }); if (v) v.npc = null; radio(g, 'Sgt. Reyes', 'Line held. You earned this — take the AR-7. Hospital reports a serum prototype. Go get it!', 9); finish(g, z, 'Police HQ is a safe zone — heal, rearm, repeat', hq); } } },
  { title: 'THE CURE', dens: 1.15, black: 0.3, fog: 0.3,
    start(g, z) { const h = POI(g, 'hosp'); z.serum = 0; g.pickups = g.pickups.filter((k) => k.type !== 'zserum'); for (let i = 0; i < 3; i++) { const s = ringPoint(g, h.x, h.y, 110, 330); g.pickups.push({ type: 'zserum', x: s.x, y: s.y, v: 1, life: 99999 }); }
      spawnHorde(g, h.x, h.y, 14, { rmin: 240, rmax: 520, hunt: h }); spawnHorde(g, h.x, h.y, 2, { rmin: 300, rmax: 520, kind: 'brute' }); spawnHorde(g, h.x, h.y, 3, { rmin: 260, rmax: 520, kind: 'spitter' }); spawnHorde(g, h.x, h.y, 1, { rmin: 300, rmax: 520, kind: 'bloater' });
      g.waypoint = { ...h }; radio(g, 'Dr. Okoye', 'Meridian General here — I can synthesise a cure but the antiviral crates are scattered around the grounds. The wards are overrun. Please hurry!', 10); },
    obj: (g, z) => `Recover antiviral crates (${z.serum || 0}/3) around Meridian General`, marks: (g) => { const h = POI(g, 'hosp'), m = [{ ...h, label: 'Meridian General' }]; for (const k of g.pickups) if (k.type === 'zserum') m.push({ x: k.x, y: k.y, label: 'Crate' }); return m; },
    step(g, z) { if ((z.serum || 0) >= 3) { const h = POI(g, 'hosp'); z.inf = 0; z.immune = 60; g.cash += 1200; addSafe(g, { id: 'hosp', x: h.x, y: h.y + 20, r: 230, name: 'Meridian General', kind: 'pd', n: 3, post: { x: h.x, y: h.y + 40, r: 180 } }); radio(g, 'Dr. Okoye', 'Serum synthesised! It will protect you for a minute and the army wants the rest. Hospital is now a safe zone.', 9); finish(g, z, 'Serum secured', h); } } },
  { title: 'LOST SOULS', dens: 1.1, black: 0.4, fog: 0.3,
    start(g, z) { z.groups = []; z.chSaved = 0; for (let i = 0; i < 4; i++) newGroup(g, z); radio(g, 'Sgt. Reyes', 'We have civilians barricaded across the district. Find them, shoot a path out, and bring at least four back to HQ. Park near them and they will climb aboard!', 11); },
    obj: (g, z) => `Rescue survivors and bring them to Police HQ — ${z.chSaved || 0}/4 delivered${z.cargo ? ` · ${z.cargo} on board` : ''}`,
    marks(g, z) { const m = []; for (const gr of z.groups) if (gr.s.some((a) => a.on && !a.dead && a.hide)) m.push({ x: gr.x, y: gr.y, label: 'Survivors' }); if (z.cargo || alive(g, (a) => a.survivor && a.follow)) m.push({ ...POI(g, 'police'), label: 'Police HQ' }); return m; },
    step(g, z, dt) { z.gT = (z.gT || 0) - dt; if (z.gT <= 0) { z.gT = 3; const pot = alive(g, (a) => a.survivor) + z.cargo; if ((z.chSaved || 0) + pot < 4) newGroup(g, z); }
      if ((z.chSaved || 0) >= 4) { g.cash += 1500; radio(g, 'Sgt. Reyes', `Good work. ${z.saved} people are alive because of you. Fort Granite has the only working lab — they want you and that serum. Take a car, or take the Skylark!`, 10); finish(g, z, 'Survivors saved', POI(g, 'police')); } } },
  { title: 'WINGS & WHEELS', dens: 1.3, black: 0.5, fog: 0.32,
    start(g, z) { z.surgeT = 18; g.summonVehicle('hummer'); g.summonVehicle('sports'); if (!g.player.heli) g.summonHeli('skylark'); const f = POI(g, 'fort'); g.waypoint = { ...f };
      radio(g, 'Gen. Okafor', 'Fort Granite is the last organised position — far to the east. Roads are choked with infected. Take wheels or wings, Rook. Watch the sky: the Skylark outflies any horde.', 11); },
    obj: (g) => `Reach Fort Granite — ${Math.round(hyp(g.player.x - POI(g, 'fort').x, g.player.y - POI(g, 'fort').y) / 10)} m`, marks: (g) => [{ ...POI(g, 'fort'), label: 'Fort Granite' }],
    step(g, z) { const f = POI(g, 'fort'); if (playerAt(g, f.x, f.y, 520) || (g.player.heli && hyp(g.player.x - f.x, g.player.y - f.y) < 650)) {
        const post = { x: f.x, y: f.y - 160, r: 260 }; addSafe(g, { id: 'fort', x: f.x, y: f.y - 130, r: 360, name: 'Fort Granite', kind: 'army', n: 9, post });
        for (let i = 0; i < 8; i++) { const s = ringPoint(g, f.x, f.y - 140, 60, 260); makeSoldier(g, s.x, s.y, { army: true, post }); }
        for (let i = 0; i < 2; i++) { const v = spawnVehicle(g, 'tank', f.x - 190 + i * 380, f.y - 60, -Math.PI / 2, { ai: 'none', hot: true, force: true, color: '#4b5a2f' }); if (v) { v.zturret = true; v.mis = true; } }
        g.cash += 800; radio(g, 'Gen. Okafor', 'You made it! Serum is in the lab. Now the bad news — the source is a hive at Kessler Freight, back in Port Meridian. We have two Titan tanks for you.', 11); finish(g, z, 'Fort Granite secured', { x: f.x, y: f.y - 100 }); } } },
  { title: 'HAMMER TIME', dens: 1.5, black: 0.6, fog: 0.34,
    start(g, z) { z.ph = 0; z.surgeT = 40; g.summonVehicle('tank'); const k = POI(g, 'kess_gate') || POI(g, 'kess'); g.waypoint = { ...k };
      radio(g, 'Gen. Okafor', 'Mount up in the Titan — mouse aims the turret, left click fires the cannon, right click the coax gun. Tanks crush cars and walk through fences. Drive it to Kessler Freight. Burn the hive out.', 12); },
    obj: (g, z) => z.ph === 0 ? 'Board the Titan battle tank (E)' : `Drive to Kessler Freight — ${Math.round(hyp(g.player.x - POI(g, 'kess_gate').x, g.player.y - POI(g, 'kess_gate').y) / 10)} m${g.player.veh && g.player.veh.def.tank ? '' : ' · a tank is recommended'}`,
    marks: (g) => [{ ...POI(g, 'kess_gate'), label: 'Kessler Freight' }],
    step(g, z) { const f = POI(g, 'fort'), k = POI(g, 'kess_gate'); const p = g.player; if (z.ph === 0 && ((p.veh && p.veh.def.tank) || hyp(p.x - f.x, p.y - f.y) > 900)) { z.ph = 1; z.surgeT = 20; }
      if (z.ph === 1 && playerAt(g, k.x, k.y, 950)) finish(g, z, 'The hive is ahead', { x: k.x, y: k.y - 400 }); } },
  { title: 'THE HIVE', dens: 1.4, black: 0.7, fog: 0.36,
    start(g, z) { const k = POI(g, 'kess_gate'), p = g.player; z.surgeOK = false; z.bossDead = false; z.p2 = z.p3 = z.enraged = false; const s = ringPoint(g, k.x, k.y - 200, 120, 420), b = makeZombie(g, 'tyrant', s.x, s.y, { hunt: p }); if (b) { z.boss = b; b.mis = true; }
      spawnHorde(g, k.x, k.y - 200, 12, { rmin: 300, rmax: 640, hunt: p }); dropSupplies(g, p.x + 90, p.y, true); dropSupplies(g, p.x - 90, p.y, true);
      banner(g, 'THE TYRANT', '#ff3a3a', 'patient zero has mutated'); radio(g, 'Gen. Okafor', 'That is no zombie — that is the source. Hit it with everything, keep moving, and do not let it grab you!', 9); },
    obj: (g, z) => `Kill the Tyrant${z.boss && z.boss.on ? ` — ${Math.max(0, Math.round(z.boss.hp / z.boss.max * 100))}%` : ''}`, marks: (g, z) => z.boss && z.boss.on && !z.boss.dead ? [{ x: z.boss.x, y: z.boss.y, label: 'Tyrant' }] : [{ ...POI(g, 'kess_gate'), label: 'Hive' }],
    step(g, z) { if (z.bossDead) { z.surgeOK = true; g.cash += 5000; radio(g, 'Gen. Okafor', 'The signal has stopped… the horde is collapsing. Navy destroyer D-71 is standing off the harbour. Get to the water — take a boat from the pier!', 11); finish(g, z, 'The hive is dead', POI(g, 'kess_gate')); } } },
  { title: 'LAST BOAT OUT', dens: 1.2, black: 0.7, fog: 0.36,
    start(g, z) { const k = POI(g, 'kess_gate'), p = g.player; const w1 = findWater(g, p.x, p.y, VEHICLES.speedboat, 140, 1500, 14) || findWater(g, k.x, k.y + 600, VEHICLES.speedboat, 100, 2400, 14);
      if (w1) { const v = spawnVehicle(g, 'speedboat', w1.x, w1.y, w1.a, { hot: true, ai: 'none', force: true, owned: true, color: '#ffffff' }); const j = findWater(g, w1.x, w1.y, VEHICLES.jetski, 60, 280, 10); if (j) spawnVehicle(g, 'jetski', j.x, j.y, j.a, { hot: true, ai: 'none', force: true, owned: true }); z.boat = w1;
        const dw = findWater(g, w1.x, w1.y, VEHICLES.destroyer, 900, 2900, 60) || findWater(g, w1.x, w1.y, VEHICLES.destroyer, 500, 3600, 30); if (dw) { const d = spawnVehicle(g, 'destroyer', dw.x, dw.y, dw.a, { hot: true, ai: 'none', force: true, owned: true }); if (d) { d.mis = true; d.zturret = true; z.ship = d; z.shipPos = { x: dw.x, y: dw.y }; } } }
      z.sx = z.shipPos ? z.shipPos.x : p.x; z.sy = z.shipPos ? z.shipPos.y : p.y; g.waypoint = z.boat ? { x: z.boat.x, y: z.boat.y } : null; spawnHorde(g, p.x, p.y, 10, { rmin: 420, rmax: 700, hunt: p });
      radio(g, 'Navy D-71', 'Rook, this is Aegis D-71, we have your beacon. A speedboat and a jet-ski are moored near you — the marker shows them. Reach us and we are out of here!', 11); },
    obj: (g, z) => z.ship ? `Reach the Aegis Destroyer — ${Math.round(hyp(g.player.x - z.sx, g.player.y - z.sy) / 10)} m` : 'Escape by sea', marks: (g, z) => z.shipPos ? [{ x: z.sx, y: z.sy, label: 'Aegis D-71' }, ...(z.boat && !(g.player.veh && g.player.veh.def.boat) ? [{ x: z.boat.x, y: z.boat.y, label: 'Boat' }] : [])] : [],
    step(g, z) { if (!z.shipPos || hyp(g.player.x - z.sx, g.player.y - z.sy) < 340) victory(g, z); } },
  { title: 'DEAD TIDE — SURVIVE', dens: 1.3, black: 0.6, fog: 0.3, endless: true, start(g, z) { z.endless = true; z.dens = 1.3; radio(g, 'Dispatch', 'Survivors report the dead are still walking. Hold out as long as you can — every kill and every rescue counts.', 8); },
    obj: (g, z) => `SURVIVE — day ${g.env.day} · ${z.kills} infected down · ${z.saved} rescued`, marks: () => [],
    step(g, z, dt) { z.dens = Math.min(2.1, 1.3 + z.t / 900); z.endT = (z.endT || 0) - dt; if (z.endT <= 0) { z.endT = 150; banner(g, 'THE DEAD GROW BOLDER', '#ff7a3a', 'density rising'); z.pdWant = Math.min(6, z.pdWant + 1); } } },
];
function newGroup(g, z) {
  const hq = POI(g, 'police'), s = ringPoint(g, hq.x, hq.y, 650, 1700), grp = { x: s.x, y: s.y, s: [] };
  for (let i = 0; i < 2; i++) { const a = require_survivor(g, s.x + rnd(-26, 26), s.y + rnd(-26, 26)); if (a) grp.s.push(a); } spawnHorde(g, s.x, s.y, 4, { near: 150 }); z.groups.push(grp);
}
import { makeSurvivor } from './zombie.js';
const require_survivor = (g, x, y) => makeSurvivor(g, x, y, { hide: true });
function victory(g, z) {
  if (z.done) return; z.done = true; banner(g, 'ESCAPED', '#7cff4f', 'the dead tide recedes'); g.audio.sfx('levelup'); z.endCard = true; g.cash += 10000;
  g.later(2.5, () => { showEnd(g, z); }); z.chDone = true;
}

// ---------------------------------------------------------------- chapter control
export function setChapter(g, i) {
  const z = g.zm; if (!z) return; i = Math.min(i, CH.length - 1); const c = CH[i]; z.ch = i; z.chT = 0; z.chKills = 0; z.chDone = false; z.ph = 0; z.dens = c.dens; z.blackout = c.black; z.fogBase = c.fog;
  if (!c.endless) banner(g, `CHAPTER ${i + 1}`, '#ff5a5a', c.title); c.start(g, z);
}
export function startCampaign(g) { const z = g.zm; ensureHud(g); const st = g.world.pois.start; z.chDone = false; setChapter(g, 0); void st; }
export function campaignStep(g, dt) {
  const z = g.zm, c = CH[z.ch]; if (!c) return; z.chT += dt;
  if (!z.chDone || z.done) { if (!z.done || z.endless) c.step(g, z, dt); }
  const ms = c.marks ? c.marks(g, z) : []; for (const m of ms) if (m && m.x !== undefined) g.markers.push({ x: m.x, y: m.y, kind: 'wp', color: '#ff5a5a', label: m.label || 'Objective' });
  if (z.ch < CH.length - 1 || z.endless) z.objText = c.obj(g, z);
}

// ---------------------------------------------------------------- HUD (DOM overlay)
const CSS = `#zmhud{position:absolute;inset:0;pointer-events:none;z-index:6;font-family:system-ui,sans-serif;color:#e8f0e0}
#zmhud .p{position:absolute;background:rgba(8,14,8,.62);border:1px solid rgba(150,220,110,.28);border-radius:10px;padding:8px 12px;backdrop-filter:blur(3px)}
#zmhud .ttl{font-size:11px;letter-spacing:.18em;color:#9ccf5a;font-weight:700}#zmhud .obj{font-size:15px;font-weight:700;margin-top:3px;max-width:340px;line-height:1.25}#zmhud .sub{font-size:12px;opacity:.8;margin-top:3px}
#zmhud .tl{left:12px;top:12px}#zmhud .tr{right:12px;top:12px;text-align:right;min-width:150px;font-size:13px;line-height:1.55}#zmhud .tr b{color:#ffe14a}
#zmhud .inf{left:50%;top:12px;transform:translateX(-50%);width:230px;padding:6px 10px;display:none}#zmhud .bar{height:9px;border-radius:5px;background:rgba(255,255,255,.12);overflow:hidden;margin-top:4px}#zmhud .bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#6fcf3a,#d6ff5a)}
#zmhud .boss{left:50%;top:62px;transform:translateX(-50%);width:min(520px,70vw);display:none;text-align:center}#zmhud .boss .bar{height:13px}#zmhud .boss .bar i{background:linear-gradient(90deg,#8a0f1f,#ff3a4a)}
#zmhud .rad{left:50%;bottom:92px;transform:translateX(-50%);max-width:min(620px,92vw);display:none;font-size:14px;border-color:rgba(90,200,255,.4)}#zmhud .rad b{color:#6fd6ff}
#zmhud .ban{left:0;right:0;top:27%;text-align:center;display:none}#zmhud .ban div{font-size:min(8vw,52px);font-weight:900;letter-spacing:.12em;text-shadow:0 0 22px currentColor,0 3px 0 #000}#zmhud .ban small{font-size:min(3.4vw,17px);letter-spacing:.16em;text-shadow:0 2px 0 #000;color:#e8f0e0}
#zmhud .vig{inset:0;border:0;border-radius:0;padding:0;background:none;backdrop-filter:none}
#zmhud .end{inset:0;background:rgba(2,6,2,.88);border:0;border-radius:0;display:none;pointer-events:auto;text-align:center;padding-top:9vh}#zmhud .end h1{font-size:min(9vw,64px);letter-spacing:.14em;color:#9cff6f;margin:0}#zmhud .end table{margin:18px auto;font-size:16px;border-collapse:collapse}#zmhud .end td{padding:4px 18px;border-bottom:1px solid rgba(255,255,255,.1)}#zmhud .end button{pointer-events:auto;margin:6px;padding:10px 22px;font-size:15px;border-radius:8px;border:1px solid #9ccf5a;background:#14240f;color:#e8f0e0;cursor:pointer}
@media (max-width:700px){#zmhud .obj{font-size:12px;max-width:200px}#zmhud .tr{font-size:11px;min-width:100px}#zmhud .rad{bottom:150px;font-size:12px}#zmhud .inf{top:68px}}`;
function ensureHud(g) {
  const z = g.zm; if (z.hud) return; if (!document.getElementById('zmcss')) { const s = document.createElement('style'); s.id = 'zmcss'; s.textContent = CSS; document.head.appendChild(s); }
  const el = document.createElement('div'); el.id = 'zmhud';
  el.innerHTML = `<div class="p vig" data-k="vig"></div><div class="p tl"><div class="ttl" data-k="ttl"></div><div class="obj" data-k="obj"></div><div class="sub" data-k="sub"></div></div><div class="p tr" data-k="stats"></div><div class="p inf" data-k="inf"><div class="ttl" style="color:#d6ff5a">INFECTION</div><div class="bar"><i data-k="infb"></i></div></div><div class="p boss" data-k="boss"><div class="ttl" style="color:#ff6a7a">THE TYRANT</div><div class="bar"><i data-k="bossb"></i></div></div><div class="p rad" data-k="rad"></div><div class="ban" data-k="ban"><div></div><small></small></div><div class="p end" data-k="end"></div>`;
  g.root.appendChild(el); const q = {}; el.querySelectorAll('[data-k]').forEach((n) => { q[n.dataset.k] = n; }); z.hud = { el, q, last: {}, t: 0 };
}
const setT = (h, k, v, html) => { if (h.last[k] === v) return; h.last[k] = v; if (html) h.q[k].innerHTML = v; else h.q[k].textContent = v; };
export function hudUpdate(g, dt) {
  const z = g.zm, h = z.hud; if (!h) return; h.t -= dt; const show = g.state === 'play' && !g.cut; h.el.style.display = show ? 'block' : 'none'; if (!show) return;
  // banner + radio queues tick every step
  if (z.banner) { z.banner.t -= dt; if (z.banner.t <= 0) z.banner = null; }
  if (!z.radioNow && z.radioQ && z.radioQ.length) z.radioNow = z.radioQ.shift(); if (z.radioNow) { z.radioNow.t -= dt; if (z.radioNow.t <= 0) z.radioNow = null; }
  if (h.t > 0) return; h.t = 0.12; const c = CH[z.ch] || CH[0], p = g.player;
  setT(h, 'ttl', c.endless ? 'ENDLESS · ' + c.title : `CHAPTER ${z.ch + 1}/${CH.length - 1} · ${c.title}`); setT(h, 'obj', z.objText || ''); setT(h, 'sub', z.inSafe ? `✚ SAFE ZONE — ${z.inSafe.name}: healing & restocking` : z.drop ? 'Supply drop inbound — marked' : z.surges ? '' : '');
  setT(h, 'stats', `Infected down <b>${z.kills}</b><br>Rescued <b>${z.saved}</b>${z.cargo ? ` (+${z.cargo} aboard)` : ''}<br>Nearby infected <b>${z.nZ || 0}</b>${z.combo > 1 ? `<br>Streak <b>x${z.combo}</b>` : ''}`, true);
  h.q.inf.style.display = z.inf > 1 || z.immune > 0 ? 'block' : 'none'; if (z.inf > 1 || z.immune > 0) { h.q.infb.style.width = (z.immune > 0 ? 100 : z.inf) + '%'; h.q.infb.style.background = z.immune > 0 ? 'linear-gradient(90deg,#4fe0ff,#9cffff)' : ''; h.q.inf.firstChild.textContent = z.immune > 0 ? 'IMMUNE' : 'INFECTION'; }
  const b = z.boss; const bs = b && b.on && !b.dead && z.ch === 6; h.q.boss.style.display = bs ? 'block' : 'none'; if (bs) h.q.bossb.style.width = Math.max(0, b.hp / b.max * 100) + '%';
  const r = z.radioNow; h.q.rad.style.display = r ? 'block' : 'none'; if (r) setT(h, 'rad', `<b>${r.from}:</b> ${r.text}`, true);
  const bn = z.banner; h.q.ban.style.display = bn ? 'block' : 'none'; if (bn) { h.q.ban.firstChild.textContent = bn.text; h.q.ban.firstChild.style.color = bn.color; h.q.ban.lastChild.textContent = bn.sub || ''; h.q.ban.style.opacity = Math.min(1, bn.t); }
  const hurt = Math.max(0, 1 - p.hp / p.max) * 0.7, inf = Math.min(1, z.inf / 100) * 0.55; h.q.vig.style.background = `radial-gradient(ellipse at center, rgba(0,0,0,0) 45%, rgba(${Math.round(150 * hurt)},${Math.round(180 * inf)},0,${Math.min(0.75, hurt + inf)}) 100%)`;
  if (z.bitT > 2.2) g.cam.shake = Math.max(g.cam.shake, 3);
}
function showEnd(g, z) {
  const h = z.hud; if (!h) return; const t = Math.floor(z.t / 60);
  h.q.end.innerHTML = `<h1>ESCAPED</h1><div style="letter-spacing:.2em;color:#9ccf5a">THE DEAD TIDE RECEDES — PORT MERIDIAN WILL REMEMBER YOU</div><table><tr><td>Infected destroyed</td><td><b>${z.kills}</b></td></tr><tr><td>Survivors rescued</td><td><b>${z.saved}</b></td></tr><tr><td>Civilians evacuated by police</td><td><b>${z.evac}</b></td></tr><tr><td>Survivors lost</td><td><b>${z.lost}</b></td></tr><tr><td>People who turned</td><td><b>${z.turned}</b></td></tr><tr><td>Deaths</td><td><b>${z.deaths}</b></td></tr><tr><td>Time</td><td><b>${t} min</b></td></tr></table><div><button data-a="go">Keep surviving (endless)</button><button data-a="menu">Main menu</button></div>`;
  h.q.end.style.display = 'block'; g.uiOpen = true;
  h.q.end.onclick = (e) => { const a = e.target.dataset && e.target.dataset.a; if (!a) return; g.uiOpen = false; h.q.end.style.display = 'none'; if (a === 'go') { z.done = false; z.chDone = false; setChapter(g, CH.length - 1); g.player.hp = g.player.max; } else g.toMenu(); };
}
export function hudDestroy(g) { const z = g.zm; if (z && z.hud) { z.hud.el.remove(); z.hud = null; } g.uiOpen = false; }
