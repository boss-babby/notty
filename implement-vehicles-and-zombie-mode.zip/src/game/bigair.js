// ===== bigair.js — v8: large flyable aircraft (airliner, business jet, heavy cargo carrier) =====
// They plug into plane.js (same flight model, HUD, boarding, audio). The static airliners / jets parked at airports are converted
// into boardable aircraft by vehicles2.js (see convertProps) so every plane you can see on an apron can now be flown.
import { TAU } from './util.js';

export const BIG_PLANES = {
  atlas: { n: 'Atlas A-900 Airliner', plane: true, liner: true, engines: 4, hp: 3000, vmax: 520, vstall: 175, vrot: 255, turn: 0.62, accK: 0.42, R: 118, rockets: 0, guns: false, dmgK: 0.28, colors: ['#d32f2f', '#1565c0', '#2e7d32', '#f9a825'] },
  stratos: { n: 'Stratos Business Jet', plane: true, liner: true, engines: 2, rear: true, hp: 520, vmax: 610, vstall: 185, vrot: 225, turn: 1.25, accK: 0.9, jet: false, R: 44, rockets: 0, guns: false, dmgK: 0.4, colors: ['#f4f4f6', '#1f2937', '#b91c1c', '#0f766e'] },
  titan: { n: 'Titan C-9 Heavy Carrier', plane: true, liner: true, cargo: true, engines: 4, hp: 4800, vmax: 440, vstall: 150, vrot: 215, turn: 0.5, accK: 0.36, R: 140, rockets: 0, guns: false, dmgK: 0.22, colors: ['#6b7a56', '#8a8f98', '#4a5568'] },
};

const shade = (hex, k) => { const n = parseInt(hex.slice(1), 16), f = (v) => Math.max(0, Math.min(255, Math.round(v + (k < 0 ? v * k : (255 - v) * k)))); return '#' + [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => f(v).toString(16).padStart(2, '0')).join(''); };

export function linerShadow(c, h) {
  const d = h.def, R = d.R, a = h.alt, s = 1 - a * 0.18, L = R * 0.98;
  c.save(); c.translate(h.x + 10 + a * 46, h.y + 12 + a * 74); c.rotate(h.a); c.scale(s, s); c.fillStyle = `rgba(0,0,0,${0.3 - a * 0.12})`;
  c.beginPath(); c.ellipse(0, 0, L, R * 0.1, 0, 0, TAU); c.fill();
  c.beginPath(); c.moveTo(R * 0.15, -R * 0.08); c.lineTo(-R * 0.45, -R); c.lineTo(-R * 0.62, -R); c.lineTo(-R * 0.3, -R * 0.08); c.lineTo(-R * 0.3, R * 0.08); c.lineTo(-R * 0.62, R); c.lineTo(-R * 0.45, R); c.lineTo(R * 0.15, R * 0.08); c.fill();
  c.fillRect(-L, -R * 0.32, R * 0.3, R * 0.64); c.restore();
}

export function drawLiner(g, c, h) {
  const d = h.def, R = d.R, lift = h.alt * 70, sc = 1 + h.alt * 0.18, bank = Math.cos(h.bank * 0.7), body = h.color, cargo = !!d.cargo, biz = d.rear;
  const hull = cargo ? shade(body, 0.12) : '#f3f4f7', belly = shade(hull, -0.16), L = R * 0.98, fw = R * (cargo ? 0.12 : biz ? 0.13 : 0.1);
  c.save(); c.translate(h.x, h.y - lift); c.rotate(h.a); c.scale(sc, sc * bank);
  // tailplane
  c.fillStyle = shade(hull, -0.22); c.beginPath(); c.moveTo(-L * 0.78, -fw * 0.4); c.lineTo(-L * 0.98, -R * 0.36); c.lineTo(-L * 1.04, -R * 0.36); c.lineTo(-L * 0.93, -fw * 0.3); c.lineTo(-L * 0.93, fw * 0.3); c.lineTo(-L * 1.04, R * 0.36); c.lineTo(-L * 0.98, R * 0.36); c.lineTo(-L * 0.78, fw * 0.4); c.closePath(); c.fill();
  // wings (swept)
  const wr = R, w0 = biz ? -R * 0.05 : cargo ? R * 0.05 : R * 0.12;
  c.fillStyle = shade(hull, -0.1); for (const s of [-1, 1]) {
    c.beginPath(); c.moveTo(w0 + R * 0.26, s * fw * 0.6); c.lineTo(w0 - R * 0.34, s * wr); c.lineTo(w0 - R * 0.5, s * wr); c.lineTo(w0 - R * 0.28, s * fw * 0.6); c.closePath(); c.fill(); c.strokeStyle = 'rgba(0,0,0,.28)'; c.lineWidth = 1; c.stroke();
    c.fillStyle = body; c.beginPath(); c.moveTo(w0 - R * 0.3, s * wr * 0.93); c.lineTo(w0 - R * 0.34, s * wr); c.lineTo(w0 - R * 0.5, s * wr); c.lineTo(w0 - R * 0.46, s * wr * 0.93); c.fill(); c.fillStyle = shade(hull, -0.1);
  }
  // engines
  const ne = d.engines, spin = h.rot * 8, ex = [];
  if (biz) ex.push([-L * 0.62, -fw * 1.7], [-L * 0.62, fw * 1.7]); else if (ne === 2) ex.push([w0 - R * 0.05, -R * 0.36], [w0 - R * 0.05, R * 0.36]); else ex.push([w0 + R * 0.02, -R * 0.62], [w0 - R * 0.1, -R * 0.3], [w0 - R * 0.1, R * 0.3], [w0 + R * 0.02, R * 0.62]);
  const er = R * (biz ? 0.07 : 0.06);
  for (const [x, y] of ex) {
    c.fillStyle = '#8b929c'; c.beginPath(); c.ellipse(x, y, er * 2.2, er, 0, 0, TAU); c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 1; c.stroke();
    c.fillStyle = '#16181d'; c.beginPath(); c.ellipse(x + er * 1.6, y, er * 0.55, er * 0.8, 0, 0, TAU); c.fill();
    if (h.rpm > 0.25) { c.strokeStyle = `rgba(210,215,225,${0.25 + 0.3 * h.rpm})`; c.lineWidth = 1.4; c.beginPath(); c.moveTo(x + er * 1.6, y + Math.sin(spin) * er * 0.8); c.lineTo(x + er * 1.6, y - Math.sin(spin) * er * 0.8); c.stroke(); }
    if (h.thr > 0.55 && d.engines) { c.fillStyle = 'rgba(255,170,70,.55)'; c.beginPath(); c.moveTo(x - er * 2.2, y - er * 0.5); c.lineTo(x - er * 2.2 - er * 2.4 * h.thr, y); c.lineTo(x - er * 2.2, y + er * 0.5); c.fill(); }
  }
  // fuselage
  const g1 = c.createLinearGradient(0, -fw, 0, fw); g1.addColorStop(0, shade(hull, 0.2)); g1.addColorStop(0.55, hull); g1.addColorStop(1, belly);
  c.fillStyle = g1; c.beginPath(); c.moveTo(L, 0); c.bezierCurveTo(L * 0.96, -fw * 0.95, L * 0.8, -fw, L * 0.55, -fw); c.lineTo(-L * 0.6, -fw * 0.92); c.lineTo(-L * 0.98, -fw * 0.28); c.lineTo(-L * 0.98, fw * 0.28); c.lineTo(-L * 0.6, fw * 0.92); c.lineTo(L * 0.55, fw); c.bezierCurveTo(L * 0.8, fw, L * 0.96, fw * 0.95, L, 0); c.closePath(); c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 1.2; c.stroke();
  if (cargo) { c.fillStyle = 'rgba(0,0,0,.2)'; c.fillRect(-L * 0.9, -fw * 0.55, R * 0.4, fw * 1.1); c.fillStyle = shade(hull, -0.3); for (let i = 0; i < 9; i++) c.fillRect(-L * 0.4 + i * R * 0.12, -fw, 1.2, fw * 2); c.fillStyle = 'rgba(255,255,255,.55)'; c.font = `bold ${Math.round(R * 0.07)}px sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('AIR FORCE', -R * 0.1, 0); }
  else { c.fillStyle = body; c.fillRect(-L * 0.5, -fw * 0.18, L * 1.25, fw * 0.36); c.fillStyle = 'rgba(30,40,60,.7)'; const nw = biz ? 7 : 22; for (let i = 0; i < nw; i++) { const x = L * 0.62 - i * (L * 1.1 / nw); c.fillRect(x, -fw * 0.62, 1.5, 1.8); c.fillRect(x, fw * 0.62 - 1.8, 1.5, 1.8); } }
  // tail fin (top view: coloured spine) + cockpit
  c.fillStyle = body; c.beginPath(); c.moveTo(-L * 0.62, -2); c.lineTo(-L * 0.98, -1.4); c.lineTo(-L * 0.98, 1.4); c.lineTo(-L * 0.62, 2); c.fill();
  c.fillStyle = '#1b3550'; c.beginPath(); c.moveTo(L * 0.93, 0); c.lineTo(L * 0.8, -fw * 0.5); c.lineTo(L * 0.72, -fw * 0.45); c.lineTo(L * 0.72, fw * 0.45); c.lineTo(L * 0.8, fw * 0.5); c.closePath(); c.fill(); c.fillStyle = 'rgba(170,220,255,.4)'; c.fillRect(L * 0.76, -fw * 0.3, L * 0.07, fw * 0.12);
  if (h.hitT > 0) { c.fillStyle = `rgba(255,80,60,${h.hitT * 2})`; c.beginPath(); c.ellipse(0, 0, L * 0.7, fw, 0, 0, TAU); c.fill(); }
  c.fillStyle = '#ff2a2a'; c.beginPath(); c.arc(w0 - R * 0.46, -wr, 2, 0, TAU); c.fill(); c.fillStyle = '#2aff6a'; c.beginPath(); c.arc(w0 - R * 0.46, wr, 2, 0, TAU); c.fill();
  if (Math.floor(h.strobe * 1.7) % 2 === 0) { c.fillStyle = '#fff'; c.beginPath(); c.arc(-L * 1.0, 0, 2.4, 0, TAU); c.fill(); c.beginPath(); c.arc(w0 - R * 0.3, -wr * 0.5, 1.8, 0, TAU); c.arc(w0 - R * 0.3, wr * 0.5, 1.8, 0, TAU); c.fill(); }
  c.restore();
}
