// ===== vehicles2.js — v8: sea vehicles (speedboat, jet-ski, trawler, yacht, freighter, destroyer), the Titan battle tank, turret / cannon control,
// ambient water traffic, and conversion of the static parked tanks / airliners / jets into things you can drive and fly. =====
import { T } from './world.js';
import { P } from './fx.js';
import { VEHICLES } from './data.js';
import { clamp, rnd, pick, angDiff, TAU } from './util.js';
import { damageVehicle, blow } from './combat.js';
import { spawnVehicle } from './actors.js';

const hyp = Math.hypot;
const wrap = (a) => Math.atan2(Math.sin(a), Math.cos(a));
const shade = (hex, k) => { const n = parseInt(hex.slice(1), 16), f = (v) => Math.max(0, Math.min(255, Math.round(v + (k < 0 ? v * k : (255 - v) * k)))); return '#' + [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => f(v).toString(16).padStart(2, '0')).join(''); };
const rr = (c, x, y, w, h, r) => { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); };
export const SEA_SHAPES = new Set(['tank', 'speedboat', 'jetski', 'fishboat', 'yacht', 'freighter', 'destroyer']);

// ---------------------------------------------------------------- sprites (c is already scaled ×2 and centred on the vehicle)
export function drawSeaArmor(c, def, color) {
  const L = def.len, W = def.wid, sh = def.shape, dk = shade(color, -0.45), lt = shade(color, 0.28);
  const grad = (y0, y1, a = lt, b = color, d = dk) => { const g = c.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, a); g.addColorStop(0.5, b); g.addColorStop(1, d); return g; };
  const hullPath = (k = 1, bow = 0.5, tr = 0.42) => { c.beginPath(); c.moveTo(L / 2 * k, 0); c.bezierCurveTo(L * 0.28 * k, -W * bow * k, L * 0.02, -W / 2 * k, -L * 0.3, -W / 2 * k); c.lineTo(-L / 2 * k, -W * tr * k); c.lineTo(-L / 2 * k, W * tr * k); c.lineTo(-L * 0.3, W / 2 * k); c.bezierCurveTo(L * 0.02, W / 2 * k, L * 0.28 * k, W * bow * k, L / 2 * k, 0); c.closePath(); };
  if (sh === 'tank') {
    for (const s of [-1, 1]) { const y0 = s > 0 ? W / 2 - 12 : -W / 2; c.fillStyle = '#15161a'; rr(c, -L / 2, y0, L, 12, 4); c.fill(); c.fillStyle = '#2b2d33'; for (let x = -L / 2 + 4; x < L / 2 - 4; x += 5) c.fillRect(x, y0 + 1, 2.2, 10); c.fillStyle = '#3d4048'; for (let x = -L / 2 + 10; x < L / 2 - 6; x += 14) { c.beginPath(); c.arc(x, y0 + 6, 4.4, 0, TAU); c.fill(); } c.fillStyle = dk; rr(c, -L / 2 + 6, y0 + (s > 0 ? 0 : 9), L - 18, 3.2, 1.2); c.fill(); }
    c.fillStyle = grad(-W / 2, W / 2); c.beginPath(); c.moveTo(-L / 2 + 3, -W / 2 + 10); c.lineTo(L / 2 - 20, -W / 2 + 10); c.lineTo(L / 2 - 2, -W * 0.2); c.lineTo(L / 2 - 2, W * 0.2); c.lineTo(L / 2 - 20, W / 2 - 10); c.lineTo(-L / 2 + 3, W / 2 - 10); c.closePath(); c.fill(); c.strokeStyle = 'rgba(0,0,0,.6)'; c.lineWidth = 1; c.stroke();
    c.fillStyle = shade(color, -0.2); for (const [x, y, r] of [[-12, -9, 8], [14, 8, 7], [-26, 6, 6], [28, -6, 5]]) { c.beginPath(); c.ellipse(x, y, r, r * 0.6, 0.5, 0, TAU); c.fill(); }
    c.fillStyle = dk; c.fillRect(-L / 2 + 6, -W / 2 + 14, 22, W - 28); c.strokeStyle = 'rgba(0,0,0,.5)'; for (let i = 0; i < 6; i++) { c.beginPath(); c.moveTo(-L / 2 + 8 + i * 3.5, -W / 2 + 15); c.lineTo(-L / 2 + 8 + i * 3.5, W / 2 - 15); c.stroke(); }
    c.fillStyle = '#fff3c0'; c.fillRect(L / 2 - 4, -W * 0.2, 2.5, 4); c.fillRect(L / 2 - 4, W * 0.2 - 4, 2.5, 4); return;
  }
  if (sh === 'speedboat' || sh === 'jetski') {
    const jet = sh === 'jetski'; hullPath(1, jet ? 0.42 : 0.5); c.fillStyle = grad(-W / 2, W / 2); c.fill(); c.strokeStyle = 'rgba(0,0,0,.55)'; c.lineWidth = 1; c.stroke();
    hullPath(0.8, 0.5, 0.4); c.fillStyle = shade(color, 0.35); c.fill(); c.fillStyle = color === '#ffffff' ? '#1565c0' : '#fff'; c.fillRect(-L * 0.42, -1.4, L * 0.9, 2.8);
    if (jet) { c.fillStyle = '#16181c'; rr(c, -L * 0.22, -W * 0.28, L * 0.34, W * 0.56, 3); c.fill(); c.fillStyle = '#d8dde4'; c.fillRect(L * 0.16, -W * 0.38, 3, W * 0.76); c.fillStyle = 'rgba(160,210,255,.6)'; c.fillRect(L * 0.1, -W * 0.2, 4, W * 0.4); }
    else { c.fillStyle = '#16222e'; c.beginPath(); c.moveTo(L * 0.13, -W * 0.3); c.lineTo(L * 0.2, -W * 0.18); c.lineTo(L * 0.2, W * 0.18); c.lineTo(L * 0.13, W * 0.3); c.closePath(); c.fill(); c.fillStyle = 'rgba(160,210,255,.45)'; c.fillRect(L * 0.145, -W * 0.22, 2, W * 0.44); c.fillStyle = '#20242b'; rr(c, -L * 0.3, -W * 0.28, L * 0.2, W * 0.56, 3); c.fill(); rr(c, -L * 0.06, -W * 0.28, L * 0.14, W * 0.56, 3); c.fill(); c.fillStyle = '#2b2f36'; rr(c, -L / 2 - 3, -W * 0.14, 8, W * 0.28, 2); c.fill(); }
    return;
  }
  if (sh === 'fishboat') {
    hullPath(1, 0.55, 0.46); c.fillStyle = grad(-W / 2, W / 2); c.fill(); c.strokeStyle = 'rgba(0,0,0,.55)'; c.lineWidth = 1.2; c.stroke(); hullPath(0.84, 0.55, 0.46); c.fillStyle = '#8d6e4a'; c.fill();
    c.fillStyle = '#eceff1'; rr(c, -L * 0.2, -W * 0.28, L * 0.26, W * 0.56, 3); c.fill(); c.fillStyle = '#16222e'; c.fillRect(L * 0.02, -W * 0.22, 3, W * 0.44); c.fillStyle = shade(color, -0.1); rr(c, -L * 0.2, -W * 0.28, L * 0.26, 4, 2); c.fill();
    c.fillStyle = '#cfa56a'; for (let i = 0; i < 4; i++) c.fillRect(-L * 0.42 + i * 7, -W * 0.2 + (i % 2) * 14, 6, 6); c.strokeStyle = '#2b2b2b'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(L * 0.22, 0); c.lineTo(L * 0.22, 0); c.moveTo(L * 0.32, -W * 0.3); c.lineTo(L * 0.18, 0); c.lineTo(L * 0.32, W * 0.3); c.stroke(); c.fillStyle = '#222'; c.beginPath(); c.arc(L * 0.22, 0, 2.4, 0, TAU); c.fill(); return;
  }
  if (sh === 'yacht') {
    hullPath(1, 0.5, 0.4); c.fillStyle = grad(-W / 2, W / 2, '#ffffff', '#f1f5f9', '#b8c2cc'); c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 1.2; c.stroke(); hullPath(0.8, 0.5, 0.4); c.fillStyle = '#d9b98a'; c.fill();
    c.fillStyle = '#1e3a5f'; c.fillRect(-L * 0.45, -1.6, L * 0.9, 3.2);
    c.fillStyle = '#f8fafc'; rr(c, -L * 0.3, -W * 0.3, L * 0.38, W * 0.6, 6); c.fill(); c.strokeStyle = 'rgba(0,0,0,.3)'; c.stroke(); c.fillStyle = '#1b3550'; rr(c, -L * 0.04, -W * 0.22, L * 0.1, W * 0.44, 3); c.fill(); rr(c, -L * 0.24, -W * 0.22, L * 0.1, W * 0.44, 3); c.fill();
    c.fillStyle = '#e8edf2'; rr(c, -L * 0.2, -W * 0.18, L * 0.18, W * 0.36, 5); c.fill(); c.fillStyle = '#9ec9e8'; c.beginPath(); c.arc(-L * 0.4, 0, W * 0.18, 0, TAU); c.fill(); c.fillStyle = '#fff'; c.font = 'bold 12px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('H', -L * 0.4, 0);
    c.fillStyle = '#fbbf24'; for (let i = 0; i < 4; i++) c.fillRect(L * 0.14 + i * 5, -W * 0.14 + (i % 2) * 14, 4, 8); return;
  }
  if (sh === 'freighter') {
    hullPath(1, 0.42, 0.46); c.fillStyle = grad(-W / 2, W / 2); c.fill(); c.strokeStyle = 'rgba(0,0,0,.6)'; c.lineWidth = 1.4; c.stroke(); hullPath(0.9, 0.42, 0.46); c.fillStyle = '#4b5563'; c.fill();
    const pal = ['#c0392b', '#2471a3', '#d4ac0d', '#27ae60', '#e67e22', '#7f8c8d', '#8e44ad', '#ecf0f1']; let sd = 7;
    for (let x = -L * 0.3; x < L * 0.4; x += 25) for (let r = 0; r < 5; r++) { sd = (sd * 9301 + 49297) % 233280; const cl = pal[Math.floor(sd / 233280 * pal.length)]; const y = -W * 0.38 + r * (W * 0.76 / 5); c.fillStyle = cl; c.fillRect(x, y + 0.6, 23, W * 0.76 / 5 - 1.2); c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(x, y + 0.6, 23, 1.5); c.fillStyle = 'rgba(255,255,255,.15)'; c.fillRect(x + 2, y + 2, 19, 1); }
    c.fillStyle = '#f1f5f9'; rr(c, -L * 0.46, -W * 0.34, L * 0.1, W * 0.68, 3); c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.stroke(); c.fillStyle = '#1b3550'; c.fillRect(-L * 0.375, -W * 0.28, 3, W * 0.56); c.fillStyle = '#111'; c.beginPath(); c.arc(-L * 0.41, W * 0.1, 5, 0, TAU); c.fill(); c.fillStyle = '#c0392b'; c.fillRect(-L * 0.425, W * 0.1 - 5, 4, 3); c.fillStyle = '#d1d5db'; c.beginPath(); c.arc(L * 0.43, 0, 3, 0, TAU); c.fill(); return;
  }
  if (sh === 'destroyer') {
    hullPath(1, 0.34, 0.4); c.fillStyle = grad(-W / 2, W / 2, shade(color, 0.25), color, shade(color, -0.4)); c.fill(); c.strokeStyle = 'rgba(0,0,0,.6)'; c.lineWidth = 1.3; c.stroke(); hullPath(0.84, 0.34, 0.4); c.fillStyle = shade(color, -0.12); c.fill();
    c.fillStyle = shade(color, -0.3); for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) c.fillRect(L * 0.2 + i * 6, -9 + j * 4.6, 5, 3.6);
    c.fillStyle = shade(color, -0.22); rr(c, -L * 0.22, -W * 0.28, L * 0.3, W * 0.56, 4); c.fill(); c.strokeStyle = 'rgba(0,0,0,.5)'; c.stroke(); c.fillStyle = shade(color, 0.1); rr(c, -L * 0.14, -W * 0.2, L * 0.14, W * 0.4, 3); c.fill(); c.fillStyle = '#16222e'; c.fillRect(L * 0.04, -W * 0.18, 2.5, W * 0.36);
    c.fillStyle = '#111'; c.beginPath(); c.arc(-L * 0.18, -W * 0.1, 3.6, 0, TAU); c.arc(-L * 0.18, W * 0.1, 3.6, 0, TAU); c.fill(); c.strokeStyle = '#9aa3ad'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(-L * 0.08, 0); c.lineTo(-L * 0.04, -9); c.moveTo(-L * 0.08, 0); c.lineTo(-L * 0.04, 9); c.stroke();
    c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 1.6; c.beginPath(); c.arc(-L * 0.38, 0, W * 0.24, 0, TAU); c.stroke(); c.fillStyle = 'rgba(255,255,255,.55)'; c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('H', -L * 0.38, 0);
    c.fillStyle = '#dbe2ea'; c.font = 'bold 9px sans-serif'; c.fillText('D-71', L * 0.1, W * 0.36); return;
  }
}

// ---------------------------------------------------------------- dynamic parts drawn each frame by drawVehicle
export function drawTurret(c, v) {
  const d = v.def, cn = d.cannon, a = v.gunA || 0, rec = Math.max(0, (v.recoil || 0));
  c.save(); c.translate(cn.x, 0); c.rotate(a);
  if (d.tank) {
    c.fillStyle = '#1b1d21'; c.fillRect(8 - rec, -3.2, 54, 6.4); c.fillStyle = '#2c2f35'; c.fillRect(50 - rec, -4.4, 14, 8.8); c.fillStyle = '#0c0d0f'; c.fillRect(63 - rec, -2.2, 2, 4.4);
    const g = c.createRadialGradient(-2, -3, 3, 0, 0, 24); g.addColorStop(0, shade(v.color, 0.3)); g.addColorStop(1, shade(v.color, -0.35)); c.fillStyle = g; c.beginPath(); c.moveTo(24, -7); c.lineTo(12, -17); c.lineTo(-14, -18); c.lineTo(-22, -9); c.lineTo(-22, 9); c.lineTo(-14, 18); c.lineTo(12, 17); c.lineTo(24, 7); c.closePath(); c.fill(); c.strokeStyle = 'rgba(0,0,0,.65)'; c.lineWidth = 1.2; c.stroke();
    c.fillStyle = shade(v.color, -0.5); c.beginPath(); c.arc(-4, 6, 5.5, 0, TAU); c.fill(); c.fillStyle = '#0b0c0e'; c.beginPath(); c.arc(-4, 6, 3.6, 0, TAU); c.fill(); c.fillStyle = '#222'; c.fillRect(-2, -12, 12, 3); c.fillRect(-26, -4, 5, 8);
    if (v.muzzle > 0) { c.fillStyle = '#ffe9a0'; c.beginPath(); for (let i = 0; i < 10; i++) { const q = i * Math.PI / 5, r = i % 2 ? 6 : 16; c.lineTo(68 + Math.cos(q) * r, Math.sin(q) * r); } c.closePath(); c.fill(); }
  } else {
    c.fillStyle = '#1b1d21'; c.fillRect(2 - rec, -2, 36, 4); c.fillStyle = '#7c8794'; c.beginPath(); c.moveTo(14, -6); c.lineTo(2, -9); c.lineTo(-8, -7); c.lineTo(-8, 7); c.lineTo(2, 9); c.lineTo(14, 6); c.closePath(); c.fill(); c.strokeStyle = 'rgba(0,0,0,.55)'; c.stroke();
    if (v.muzzle > 0) { c.fillStyle = '#ffe9a0'; c.beginPath(); for (let i = 0; i < 10; i++) { const q = i * Math.PI / 5, r = i % 2 ? 4 : 12; c.lineTo(40 + Math.cos(q) * r, Math.sin(q) * r); } c.closePath(); c.fill(); }
  }
  c.restore();
}
export function boatFx(c, v, time) {
  const d = v.def, sp = hyp(v.vx, v.vy), k = clamp(sp / d.vmax, 0, 1), L = d.len, W = d.wid;
  c.save(); c.globalAlpha = 0.5; c.strokeStyle = 'rgba(255,255,255,.7)'; c.lineWidth = 2; c.beginPath(); c.ellipse(0, 0, L * 0.56, W * 0.62, 0, 0, TAU); c.stroke(); c.globalAlpha = 0.18; c.fillStyle = '#d9f2ff'; c.beginPath(); c.ellipse(0, 0, L * 0.58, W * 0.66, 0, 0, TAU); c.fill();
  if (k > 0.08) { c.globalAlpha = 0.55 * k; c.strokeStyle = '#fff'; c.lineWidth = 2.4; c.beginPath(); c.moveTo(L * 0.5, 0); c.lineTo(L * 0.1, -W * 0.7 - k * 6); c.moveTo(L * 0.5, 0); c.lineTo(L * 0.1, W * 0.7 + k * 6); c.stroke(); c.globalAlpha = 0.4 * k; c.fillStyle = '#fff'; const n = 5; for (let i = 0; i < n; i++) { const x = -L * 0.5 - i * (10 + k * 14), y = Math.sin(time * 8 + i) * (W * 0.12); c.beginPath(); c.arc(x, y, 5 + i * 1.4, 0, TAU); c.fill(); } }
  c.restore();
}

// ---------------------------------------------------------------- boats
export function hullFree(g, x, y, a, d, pad = 0) {
  const w = g.world, c = Math.cos(a), s = Math.sin(a), L = d.len / 2 + pad, W = d.wid / 2 + pad;
  for (const [lx, ly] of [[L, 0], [L * 0.6, W], [L * 0.6, -W], [0, W], [0, -W], [-L * 0.6, W], [-L * 0.6, -W], [-L, 0], [0, 0]]) if (w.tileAt(x + c * lx - s * ly, y + s * lx + c * ly) !== T.WATER) return false;
  return true;
}
export function vehTick(g, v, dt) {
  if (v.cannonCool > 0) v.cannonCool -= dt; if (v.mgCool > 0) v.mgCool -= dt; if (v.muzzle > 0) v.muzzle -= dt; if (v.recoil > 0) v.recoil = Math.max(0, v.recoil - dt * 18);
}
export function updateBoat(g, v, dt) {
  const d = v.def, w = g.world; vehTick(g, v, dt);
  if (v.wreck) { v.wreckT += dt; v.thr = 0; const k = Math.exp(-1.2 * dt); v.vx *= k; v.vy *= k; v.av *= k; v.x += v.vx * dt; v.y += v.vy * dt; v.a += v.av * dt; if (v.wreckT > 45 && hyp(v.x - g.player.x, v.y - g.player.y) > 800 && !v.mis) v.on = false; if (v.burning && Math.random() < dt * 14) g.parts.emit(P.FIRE, v.x + rnd(-d.len / 3, d.len / 3), v.y + rnd(-d.wid / 3, d.wid / 3), 0, -20, 0.5, 7, '#f90'); if (v.wreckT > 20) v.burning = false; return; }
  if (!v.driver) boatAI(g, v, dt);
  const fx = Math.cos(v.a), fy = Math.sin(v.a), lx = -fy, ly = fx; let vF = v.vx * fx + v.vy * fy, vL = v.vx * lx + v.vy * ly;
  const hpf = v.hp / d.hp, acc = d.acc * (hpf < 0.3 ? 0.6 : 1) * v.speedMul, vmax = d.vmax * (hpf < 0.3 ? 0.75 : 1) * v.speedMul;
  if (v.thr > 0) { if (vF < vmax) vF += acc * v.thr * (1 - Math.max(0, vF) / vmax * 0.82) * dt; }
  else if (v.thr < 0) { if (vF > 10) vF -= d.brk * 0.9 * dt; else if (vF > -vmax * 0.28) vF -= acc * 0.45 * -v.thr * dt; }
  if (v.brk > 0) vF *= Math.exp(-v.brk * 1.6 * dt);
  vF -= vF * 0.16 * dt; if (!v.thr) vF *= Math.exp(-0.35 * dt);
  vL *= Math.exp(-d.grip * (v.hb ? 0.35 : 1) * dt);
  const sp = Math.abs(vF); let rate = v.str * d.steer * clamp(sp / 70, 0, 1) * (vF < -4 ? -1 : 1) / (1 + (sp / vmax) * 0.8) * (v.hb ? 1.5 : 1);
  v.av += (rate - v.av) * (1 - Math.exp(-5 * dt)); v.a += v.av * dt;
  v.vx = fx * vF + lx * vL; v.vy = fy * vF + ly * vL; v.rpm += (clamp(sp / vmax, 0, 1) * 0.8 + (v.thr > 0 ? 0.2 : 0) - v.rpm) * Math.min(1, dt * 5);
  // move with land collisions (anything that is not water is a shore)
  const nx = v.x + v.vx * dt, ny = v.y + v.vy * dt;
  if (hullFree(g, nx, ny, v.a, d)) { v.x = nx; v.y = ny; }
  else {
    const imp = hyp(v.vx, v.vy);
    if (hullFree(g, nx, v.y, v.a, d)) { v.x = nx; v.vy *= -0.2; } else if (hullFree(g, v.x, ny, v.a, d)) { v.y = ny; v.vx *= -0.2; } else { v.vx *= -0.35; v.vy *= -0.35; v.x -= fx * 3 * Math.sign(vF || 1); v.y -= fy * 3 * Math.sign(vF || 1); }
    v.av += (Math.random() - 0.5) * 1.5;
    if (imp > 90 && (v.hitCool || 0) <= 0) { v.hitCool = 0.4; damageVehicle(g, v, Math.max(0, imp - 80) * 0.25 * (d.mass > 20 ? 0.2 : 1), { by: v.driver }); g.audio.sfx('crash', v.x, v.y, Math.min(1, imp / 300)); g.parts.burst(P.WATER, v.x + fx * d.len * 0.4, v.y + fy * d.len * 0.4, 8, 120, 0.5, 4, '#cfe6ff'); if (v.driver === g.player) g.cam.shake = Math.max(g.cam.shake, Math.min(14, imp / 25)); }
    if (!hullFree(g, v.x, v.y, v.a, d) && !v.driver) { v.a += 0.05; }
  }
  if (v.hitCool > 0) v.hitCool -= dt;
  // wake / spray
  if (sp > 40 && Math.random() < Math.min(0.9, dt * (sp / 40))) { g.parts.emit(P.WATER, v.x - fx * d.len * 0.45 + rnd(-6, 6), v.y - fy * d.len * 0.45 + rnd(-6, 6), -fx * 30 + rnd(-30, 30), -fy * 30 + rnd(-30, 30), 0.6, 3 + sp / 120, '#e8f6ff'); if (Math.random() < 0.3) g.parts.emit(P.RING, v.x - fx * d.len * 0.5, v.y - fy * d.len * 0.5, 0, 0, 0.9, 7 + d.len / 20, '#cfe8ff'); }
  if (hpf < 0.4 && Math.random() < dt * 7) g.parts.emit(P.SMOKE, v.x + fx * d.len * 0.2, v.y + fy * d.len * 0.2, rnd(-10, 10), rnd(-20, -5), 1, 6, hpf < 0.2 ? '#222' : '#777');
  if (v.burning) { v.hp -= 9 * dt; if (v.hp <= 0) blow(g, v, {}); if (Math.random() < dt * 20) g.parts.emit(P.FIRE, v.x + rnd(-d.len / 3, d.len / 3), v.y + rnd(-d.wid / 3, d.wid / 3), rnd(-8, 8), rnd(-30, -10), 0.5, 7, '#f90'); g.lights.add(v.x, v.y, 130, '#ff8a2a', 0.7); }
  if (v.driver === g.player) { g.xp('driving', sp * dt * 0.0012); g.stats.distance += sp * dt * 0.05; }
  if (v.panic > 0) v.panic -= dt;
}
function boatAI(g, v, dt) {
  const d = v.def; v.thr = 0; v.str = 0; v.hb = false;
  if (v.ai !== 'boat') { v.brk = 0.4; return; }
  const p = g.player; if (hyp(v.x - p.x, v.y - p.y) > 2400 && !v.mis) { v.on = false; return; }
  v.t -= dt; if (v.t <= 0 || v.hdg === undefined) { v.t = 5 + Math.random() * 8; v.hdg = v.a + rnd(-0.8, 0.8); }
  const look = d.len * 0.7 + 60 + hyp(v.vx, v.vy) * 0.7, ca = Math.cos(v.a), sa = Math.sin(v.a);
  const free = (da, k = 1) => hullFree(g, v.x + Math.cos(v.a + da) * look * k, v.y + Math.sin(v.a + da) * look * k, v.a + da, d, 4);
  const cruise = d.mass > 20 ? 0.8 : v.panic > 0 ? 1 : 0.55 + (v.i % 4) * 0.08;
  if (!free(0) || !free(0, 0.5)) { const l = free(-0.7), r = free(0.7); v.str = l && !r ? -1 : r && !l ? 1 : (v.i & 1 ? 1 : -1); v.thr = 0.3; v.hdg = v.a + v.str * 0.8; if (!free(0, 0.3)) { v.thr = -0.5; v.str = -v.str; } }
  else { v.str = clamp(angDiff(v.a, v.hdg) * 2.2, -1, 1); v.thr = cruise; }
  void ca; void sa;
}
export function summonBoat(g, type, quiet) {
  const p = g.player, d = VEHICLES[type]; if (!d) return null;
  if (g.scene) { g.toast('Step outside first to summon a vessel', '#ff7788'); return null; }
  const base = p.veh ? p.veh.a : p.a; let pos = null;
  outer: for (const r of [70, 110, 160, 230, 320, 440, 600, 800, 1050, 1400, 1900]) for (let k = 0; k < 28; k++) { const ang = base + (k % 2 ? 1 : -1) * Math.ceil(k / 2) * TAU / 28, x = p.x + Math.cos(ang) * (r + d.len * 0.3), y = p.y + Math.sin(ang) * (r + d.len * 0.3); for (let h = 0; h < 8; h++) { const hd = h * TAU / 8; if (hullFree(g, x, y, hd, d, 8)) { pos = { x, y, a: hd }; break outer; } } }
  if (!pos) { g.toast('No open water within range of here', '#ff7788'); return null; }
  const v = spawnVehicle(g, type, pos.x, pos.y, pos.a, { hot: true, ai: 'none', force: true, owned: !!quiet }); if (!v) return null; v.owned = !!quiet;
  if (!quiet) { g.toast(`${d.n} moored ${Math.round(hyp(pos.x - p.x, pos.y - p.y) / 10)} m away — marked on your map, swim or walk to it and press E`, '#7cff4f'); g.waypoint = { x: pos.x, y: pos.y }; g.audio.sfx('pickup'); }
  return v;
}
export function boatExitSpot(g, v) {
  const w = g.world, d = v.def;
  for (let r = d.wid / 2 + 14; r < d.wid / 2 + 190; r += 14) for (let k = 0; k < 24; k++) { const ang = v.a + Math.PI / 2 + (k % 2 ? 1 : -1) * Math.ceil(k / 2) * TAU / 24, x = v.x + Math.cos(ang) * (r + (d.len > 150 ? d.len * 0.25 : 0) * Math.abs(Math.cos(ang - v.a))), y = v.y + Math.sin(ang) * (r + (d.len > 150 ? d.len * 0.25 : 0) * Math.abs(Math.cos(ang - v.a))); const t = w.tileAt(x, y); if (t !== T.WATER && t !== T.BUILDING && !g.solidAt(x, y) && !g.propSolidAt(x, y)) return { x, y }; }
  return null;
}

// ---------------------------------------------------------------- cannon / turret
export function fireCannon(g, v, owner, shell) {
  const d = v.def, cn = d.cannon; if (!cn) return false; const ang = v.a + (v.gunA || 0), fac = owner ? owner.fac : 'pd';
  const px = v.x + Math.cos(v.a) * cn.x, py = v.y + Math.sin(v.a) * cn.x, mz = d.tank ? 64 : 40;
  if (shell) {
    if (v.cannonCool > 0) return false; v.cannonCool = 1 / cn.rate; v.muzzle = 0.09; v.recoil = 6;
    g.bullets.spawn({ x: px + Math.cos(ang) * mz, y: py + Math.sin(ang) * mz, vx: Math.cos(ang) * cn.speed, vy: Math.sin(ang) * cn.speed, dmg: cn.dmg, owner, ownerV: v, fac, life: 1500, kind: 'rk', rad: cn.rad });
    g.parts.burst(P.FIRE, px + Math.cos(ang) * (mz + 6), py + Math.sin(ang) * (mz + 6), 8, 150, 0.35, 8, '#ffb040'); g.parts.burst(P.SMOKE, px + Math.cos(ang) * mz, py + Math.sin(ang) * mz, 8, 60, 1.2, 9, '#bbb');
    g.tmpLights.push({ x: px + Math.cos(ang) * mz, y: py + Math.sin(ang) * mz, r: 220, col: '#ffcf80', life: 0.12, max: 0.12, i: 1 });
    g.audio.sfx('rocket', v.x, v.y, 1); g.noise(v.x, v.y, 1300, { by: owner }); g.combatT = 8; v.vx -= Math.cos(ang) * 28 / d.mass; v.vy -= Math.sin(ang) * 28 / d.mass;
    if (owner === g.player) { g.cam.shake = Math.max(g.cam.shake, 9); g.cam.kx -= Math.cos(ang) * 10; g.cam.ky -= Math.sin(ang) * 10; g.stats.shots++; }
    return true;
  }
  if (!cn.mg || v.mgCool > 0) return false; v.mgCool = 0.075; const aa = ang + (Math.random() - 0.5) * 0.06; v.mgN = (v.mgN || 0) + 1;
  g.bullets.spawn({ x: px + Math.cos(ang) * 30 + Math.cos(ang + 1.57) * 6, y: py + Math.sin(ang) * 30 + Math.sin(ang + 1.57) * 6, vx: Math.cos(aa) * 2300, vy: Math.sin(aa) * 2300, dmg: 17, owner, ownerV: v, fac, life: 950, kind: 'b', rad: 0 });
  if (v.mgN % 2 === 0) { g.audio.sfx('smg', v.x, v.y, 0.55); g.noise(v.x, v.y, 800, { by: owner }); g.combatT = 6; } if (owner === g.player) g.stats.shots++;
  g.parts.emit(P.SHELL, px, py, Math.cos(ang + 1.6) * 90, Math.sin(ang + 1.6) * 90, 0.6, 3, '#d9b34a'); return true;
}
function nearestHostile(g, x, y, range) {
  let best = null, bd = range; for (const a of g.actors) { if (!a.on || a.dead || a.inside !== g.insideId) continue; if (!(a.fac === 'zed' || (a.fac === 'kes' && !g.zm) || (!g.zm && a.st === 'combat' && a.fac !== 'civ' && a.fac !== 'pl'))) continue; const dd = hyp(a.x - x, a.y - y); if (dd < bd) { bd = dd; best = a; } } return best;
}
export function cannonControl(g, v, dt) {
  const inp = g.input, pad = inp.pad, d = v.def, p = g.player; let aim = null, fireAuto = false;
  if (pad.aimActive) aim = Math.atan2(pad.ay, pad.ax);
  else if (inp.touch) { const t = nearestHostile(g, v.x, v.y, 800); if (t) { aim = Math.atan2(t.y - v.y, t.x - v.x); fireAuto = inp.down('fire'); } }
  else { const m = g.mouseWorld(); aim = Math.atan2(m.y - v.y, m.x - v.x); }
  const rel = aim === null ? 0 : wrap(aim - v.a), rate = d.tank ? 2.8 : 1.4; v.gunA = wrap((v.gunA || 0) + clamp(wrap(rel - (v.gunA || 0)), -rate * dt, rate * dt));
  p.aim = v.a + v.gunA; const onT = Math.abs(wrap(rel - v.gunA)) < 0.3;
  if (!v.hint) { v.hint = 1; g.toast(inp.touch ? 'Turret auto-targets · FIRE = cannon' : 'Mouse aims the turret · LMB cannon · RMB machine-gun', '#4fe0ff'); }
  if (!g.uiOpen && onT) { if (inp.down('fire') || fireAuto) fireCannon(g, v, p, true); if (inp.down('aim') || (inp.touch && inp.down('rocket'))) fireCannon(g, v, p, false); }
}
export function npcTurret(g, v, dt, range = 640) {
  vehTick(g, v, dt); const t = nearestHostile(g, v.x, v.y, range);
  if (!t || !g.world.lineClear(v.x, v.y, t.x, t.y)) { v.gunA = wrap((v.gunA || 0) * (1 - Math.min(1, dt))); return; }
  const rel = wrap(Math.atan2(t.y - v.y, t.x - v.x) - v.a); v.gunA = wrap((v.gunA || 0) + clamp(wrap(rel - (v.gunA || 0)), -1.6 * dt, 1.6 * dt));
  if (Math.abs(wrap(rel - v.gunA)) < 0.12) { const near = hyp(t.x - v.x, t.y - v.y); if (near > 150 && (v.shellT = (v.shellT || 0) - dt) <= 0) { v.shellT = 2.6 + Math.random() * 1.2; fireCannon(g, v, { fac: 'pd' }, true); } fireCannon(g, v, { fac: 'pd' }, false); }
}

// ---------------------------------------------------------------- world integration: water traffic, parked-prop conversion, vehicle spots
const CONV = { tank: { r: 52 }, airliner: { r: 150 }, jet: { r: 60 } };
const WATER_MIX = ['speedboat', 'speedboat', 'fishboat', 'fishboat', 'jetski', 'jetski', 'yacht', 'freighter'];
export function updateVehicles2(g, dt) {
  const p = g.player, w = g.world; if (g.scene || g.state === 'menu') return;
  g._v2T = (g._v2T || 0) - dt; if (g._v2T > 0) return; g._v2T = 0.6;
  // 1) parked props → boardable things
  const q = (g._cq = g._cq || []); q.length = 0; w.propHash.query(p.x, p.y, 1350, q); const cv = (w._conv = w._conv || new Set());
  for (const pr of q.slice()) {
    const cf = CONV[pr.t]; if (!cf || pr.dead) continue; if (hyp(pr.x - p.x, pr.y - p.y) > 1350) continue;
    const key = pr.t + ':' + Math.round(pr.x) + ':' + Math.round(pr.y);
    if (!cv.has(key)) {
      cv.add(key);
      if (pr.t === 'tank') (w.vehSpots || (w.vehSpots = [])).push({ type: 'tank', x: pr.x, y: pr.y, a: pr.a || 0, cd: 0, v: null });
      else { const kind = pr.t === 'airliner' ? 'atlas' : 'stratos', cols = pr.t === 'airliner' ? ['#d32f2f', '#1565c0', '#2e7d32', '#f9a825'] : ['#f4f4f6', '#1f2937', '#b91c1c', '#0f766e']; (w.aircraftSpots || (w.aircraftSpots = [])).push({ kind, x: pr.x, y: pr.y, a: pr.a || 0, col: cols[(pr.v | 0) % 4], home: 'Parked ' + (pr.t === 'airliner' ? 'airliner' : 'jet'), cd: 0 }); }
    }
    pr.dead = true; const bq = []; w.propHash.query(pr.x, pr.y, cf.r + 20, bq); for (const b of bq) if (b.t === 'blocker' && !b.dead && hyp(b.x - pr.x, b.y - pr.y) < cf.r) b.dead = true;
  }
  // 2) vehicle spots (tanks parked at Fort Granite etc.): re-stock after being driven away
  for (const s of w.vehSpots || []) {
    const d = hyp(p.x - s.x, p.y - s.y); s.cd = Math.max(0, s.cd - 0.6);
    if (s.v) { if (!s.v.on || s.v.vspot !== s) s.v = null; else if (hyp(s.v.x - s.x, s.v.y - s.y) > 140) { s.v.vspot = null; s.v = null; s.cd = 180; } else if (d > 2800 && !s.v.driver) { s.v.on = false; s.v = null; } }
    if (!s.v && d < 1300 && s.cd <= 0) { const v = spawnVehicle(g, s.type, s.x, s.y, s.a, { hot: true, ai: 'none' }); if (v) { v.vspot = s; s.v = v; } }
  }
  // 3) ambient sea traffic
  g._wT = (g._wT || 0) - 0.6; if (g._wT > 0) return; g._wT = 3.2;
  let n = 0; for (const v of g.vehicles) if (v.on && v.def.boat && v.ai === 'boat') n++;
  if (n >= (g.zm ? 3 : 5)) return;
  for (let k = 0; k < 10; k++) {
    const ang = Math.random() * TAU, r = 650 + Math.random() * 700, x = p.x + Math.cos(ang) * r, y = p.y + Math.sin(ang) * r;
    if (w.tileAt(x, y) !== T.WATER) continue; const type = pick(WATER_MIX), d = VEHICLES[type], a = Math.random() * TAU;
    if (!hullFree(g, x, y, a, d, 14) || Math.abs(x - g.cam.x) < g.viewW / 2 + 80 && Math.abs(y - g.cam.y) < g.viewH / 2 + 80) continue;
    if (g.vehicles.some((o) => o.on && hyp(o.x - x, o.y - y) < 160 + d.len)) continue;
    const v = spawnVehicle(g, type, x, y, a, { hot: true, ai: 'boat' }); if (v) { v.t = 0; v.hdg = a; v.vx = Math.cos(a) * 80; v.vy = Math.sin(a) * 80; } break;
  }
}
