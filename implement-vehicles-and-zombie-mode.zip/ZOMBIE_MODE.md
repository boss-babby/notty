# v8 update — Zombie Mode, armour, sea vehicles, big aircraft

**Menu → ☣ Zombie Mode** starts the *DEAD TIDE* campaign (8 chapters + endless survival; it never touches your normal save).
Outbreak → Hold the Line (police HQ siege) → The Cure (hospital) → Lost Souls (rescue, drive survivors home) → Wings & Wheels (fly/drive to Fort Granite)
→ Hammer Time (Titan tank run) → The Hive (Tyrant boss) → Last Boat Out (speedboat to the Aegis destroyer) → endless.

* **Infected** (walker, runner, brute, spitter, bloater, Tyrant) hunt *everyone*: civilians, police, soldiers, survivors and you. Gunfire/explosions/car alarms attract them. Anyone they kill rises again.
* **Police & army** fight the infected, hold posts around safe zones, retreat from melee range, and help you; **civilians** flee to the nearest safe zone, dive into buildings, or (10 %) shoot back. Survivors follow you or board your vehicle.
* **Environment**: sickly fog, creeping blackout (lights flicker and die), burning wrecks with car alarms, fires, infested building interiors with loot, supply drops, horde surges, distress calls, safe zones that heal/cure/restock.
* **Infection** meter (bites), antidotes/medkits drop from the dead; death revives you at the last checkpoint.
* Cheat menu (`\`) has zombie-mode helpers (skip chapter, spawn horde, supply drop, Tyrant).

**Vehicles**: Titan M1 tank (mouse-aimed turret, LMB cannon, RMB coax; crushes props), Marlin speedboat, Wave Runner jet-ski, Gull trawler, Costa yacht, Meridian freighter, Aegis destroyer (cannon). Boats summon on the nearest water and ambient sea traffic spawns.
**Aircraft**: every parked airliner / jet on an airport apron is now boardable (Atlas A-900, Stratos business jet) plus the new Titan C-9 heavy carrier (cheat menu).
Code: `zombie.js`, `zcampaign.js`, `vehicles2.js`, `bigair.js`.
