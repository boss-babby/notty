import { useCallback, useRef, useState } from "react";
import RustViewer, { type ViewerHandle } from "./components/RustViewer";
import artifacts from "./artifacts.json";
// @ts-ignore – inlined as data: URLs by vite-plugin-singlefile so the links work even when only index.html is served
import winZip from "./assets/pdf-studio-windows-x64.zip?url";
// @ts-ignore
import srcZip from "./assets/pdf-studio-rust-source.zip?url";

const mb = (b: number) => (b / 1048576).toFixed(2) + " MB";

const PREVIEWS = [
  { id: "desktop", label: "Desktop  >1024", width: "100%" },
  { id: "tablet", label: "Tablet  600–1024", width: "820px" },
  { id: "mobile", label: "Mobile  <600", width: "390px" },
] as const;

const TREE = `rust/
├─ Cargo.toml                workspace · pure-Rust dependency policy · wasm size profile
├─ crates/
│  ├─ pdf-core               ByteSource (mmap / Vec / chunked) · lexer · lazy XRef (table, stream, hybrid, rebuild)
│  │                         object streams · filters (Flate/LZW/A85/AHx/RL + predictors) · incremental writer
│  ├─ pdf-render             content-stream interpreter (bumpalo arena) → DisplayList → tiny-skia tiles
│  │                         fonts (ttf-parser: TrueType/OpenType/CFF) · images (zune-jpeg) · shadings · LRU caches
│  ├─ pdf-edit               annotations + appearance streams · AcroForm · text-run edit · true redaction
│  │                         page rotate/delete/move · split/merge · undo/redo snapshots · sample doc (pdf-writer)
│  ├─ ui-shell               adaptive layout state machine · gestures · tile service · palette · reflow reading mode
│  └─ platform-targets       winit+softbuffer host (Windows/macOS/Android) · wasm-bindgen host (Web)
├─ scripts/                  build-windows.sh · build-wasm.sh · build-android.sh · check-pure-rust.sh
└─ android/                  NativeActivity manifest + Gradle packaging`;

const STATES = [
  { bp: "Desktop > 1024", items: ["Collapsible left rail: virtualized thumbnails · outline · bookmarks", "Floating glass tool pill (top) + status pill (bottom)", "Contextual inspector, only while editing a selection / field / text", "Keyboard-first Ctrl/⌘ + K command palette"] },
  { bp: "Tablet 600–1024", items: ["Full-bleed canvas", "Draggable magnetic tool dock — snaps to the nearest edge and re-orients", "Two-finger tap = undo · three-finger tap = redo", "Pinch zoom with kinetic pan, stylus-friendly ink"] },
  { bp: "Mobile < 600", items: ["Edge-to-edge canvas", "Thumb-zone bottom action pill", "Swipe-up bottom sheets: tools · search · pages (drag to snap / dismiss)", "Smart text-reflow reading mode"] },
];

const BUDGETS = [
  ["Raster tiles (RGBA8, 512 px)", "256 MiB", "160 MiB", "96 MiB (384 px)", "128 MiB"],
  ["Display lists (per page)", "96 MiB", "64 MiB", "40 MiB", "48 MiB"],
  ["In-flight tile jobs", "4 (rayon)", "3", "2", "1 (cooperative)"],
];

function Badge({ children, tone = "ok" }: { children: React.ReactNode; tone?: "ok" | "warn" | "todo" }) {
  const c = tone === "ok" ? "bg-emerald-500/15 text-emerald-300 ring-emerald-400/30" : tone === "warn" ? "bg-amber-500/15 text-amber-300 ring-amber-400/30" : "bg-zinc-500/15 text-zinc-300 ring-zinc-400/30";
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${c}`}>{children}</span>;
}

export default function App() {
  const handle = useRef<ViewerHandle | null>(null);
  const [preview, setPreview] = useState<(typeof PREVIEWS)[number]["id"]>("desktop");
  const [info, setInfo] = useState("");
  const onHandle = useCallback((h: ViewerHandle) => { handle.current = h; }, []);
  const width = PREVIEWS.find((p) => p.id === preview)!.width;

  return (
    <div className="min-h-screen bg-[#0b0c0e] text-zinc-200 antialiased selection:bg-indigo-500/40">
      <header className="sticky top-0 z-30 border-b border-white/5 bg-[#0b0c0e]/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-6 px-5 py-3">
          <div className="flex items-center gap-2 font-semibold tracking-tight text-white">
            <span className="grid h-7 w-7 place-items-center rounded-lg bg-gradient-to-br from-indigo-500 to-fuchsia-500 text-[13px]">Pr</span>
            PDF Studio
          </div>
          <nav className="ml-auto hidden gap-5 text-sm text-zinc-400 sm:flex">
            <a className="hover:text-white" href="#app">Live app</a>
            <a className="hover:text-white" href="#downloads">Downloads</a>
            <a className="hover:text-white" href="#architecture">Architecture</a>
            <a className="hover:text-white" href="#status">Status</a>
          </nav>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-5 pb-10 pt-14">
        <div className="mb-4 flex flex-wrap gap-2"><Badge>100% Rust</Badge><Badge>WebAssembly</Badge><Badge>Windows .exe</Badge><Badge tone="warn">Android: build scripts + CI</Badge></div>
        <h1 className="max-w-3xl text-4xl font-semibold leading-tight tracking-tight text-white sm:text-5xl">A fast PDF reader &amp; editor written entirely in Rust — running right here in your browser.</h1>
        <p className="mt-5 max-w-2xl text-lg text-zinc-400">
          The viewer below is not JavaScript: parsing, font outlines, rasterisation, the editor <em>and the whole adaptive interface</em> are Rust compiled to WebAssembly.
          The page only forwards pointer and keyboard events and blits pixels. The same <code className="rounded bg-white/10 px-1.5 py-0.5 text-sm">ui-shell</code> crate drives the Windows build.
        </p>
        <div className="mt-7 flex flex-wrap gap-3">
          <a href="#app" className="rounded-xl bg-indigo-500 px-5 py-2.5 font-medium text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-400">Launch the app</a>
          <a href="#downloads" className="rounded-xl border border-white/10 px-5 py-2.5 font-medium text-zinc-200 hover:bg-white/5">Download Windows build</a>
        </div>
      </section>

      <section id="app" className="mx-auto max-w-6xl px-5 pb-16">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <div className="flex rounded-xl border border-white/10 bg-white/[0.03] p-1">
            {PREVIEWS.map((p) => (
              <button key={p.id} onClick={() => setPreview(p.id)} className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${preview === p.id ? "bg-indigo-500 text-white" : "text-zinc-400 hover:text-white"}`}>
                {p.label}
              </button>
            ))}
          </div>
          <div className="ml-auto flex gap-2">
            <button onClick={() => handle.current?.openFile()} className="rounded-lg border border-white/10 px-3 py-1.5 text-xs font-medium hover:bg-white/5">Open PDF…</button>
            <button onClick={() => handle.current?.openSample()} className="rounded-lg border border-white/10 px-3 py-1.5 text-xs font-medium hover:bg-white/5">Load sample</button>
            <button onClick={() => handle.current?.fullscreen()} className="rounded-lg border border-white/10 px-3 py-1.5 text-xs font-medium hover:bg-white/5">Fullscreen</button>
          </div>
        </div>
        <div className="mx-auto rounded-2xl border border-white/10 bg-black p-1.5 shadow-2xl shadow-indigo-950/40 transition-all duration-300" style={{ width, maxWidth: "100%" }}>
          <div className="overflow-hidden rounded-xl" style={{ height: preview === "mobile" ? "min(780px, 80vh)" : preview === "tablet" ? "min(760px, 80vh)" : "min(720px, 78vh)", minHeight: 460 }}>
            <RustViewer onReady={setInfo} onHandle={onHandle} />
          </div>
        </div>
        <p className="mx-auto mt-3 max-w-3xl text-center text-xs text-zinc-500">
          Drop any (unencrypted) PDF on the canvas · <kbd className="rounded bg-white/10 px-1">Ctrl</kbd>+<kbd className="rounded bg-white/10 px-1">K</kbd> command palette · <kbd className="rounded bg-white/10 px-1">Ctrl</kbd>+<kbd className="rounded bg-white/10 px-1">F</kbd> search · pinch / wheel to zoom · tool hotkeys H V L P N X G R E.
          Narrow the preview to see the layout switch breakpoints live. {info && <span className="text-zinc-600">({info})</span>}
        </p>
      </section>

      <section id="downloads" className="border-t border-white/5 bg-white/[0.02]">
        <div className="mx-auto max-w-6xl px-5 py-16">
          <h2 className="text-2xl font-semibold text-white">Downloads</h2>
          <p className="mt-2 text-zinc-400">Artifacts built in this project. Each file is embedded in this page, so the buttons work offline too.</p>
          <div className="mt-8 grid gap-5 md:grid-cols-3">
            <div className="flex flex-col rounded-2xl border border-white/10 bg-[#101114] p-6">
              <div className="flex items-center justify-between"><h3 className="font-semibold text-white">Windows (x64)</h3><Badge>built</Badge></div>
              <p className="mt-2 flex-1 text-sm text-zinc-400">Native <code>pdf-studio.exe</code> (PE32+, GUI subsystem). winit + softbuffer, memory-mapped files, drag-and-drop, open/save dialogs. Cross-compiled with zig as linker — no MSVC needed.</p>
              <dl className="mt-4 space-y-1 text-xs text-zinc-500"><div>zip: {mb(artifacts.windowsZip.bytes)} · exe: {mb(artifacts.exe.bytes)}</div><div className="break-all">sha256(exe) {artifacts.exe.sha256}</div></dl>
              <a href={winZip} download="pdf-studio-windows-x64.zip" className="mt-5 rounded-xl bg-indigo-500 px-4 py-2.5 text-center text-sm font-medium text-white hover:bg-indigo-400">Download .zip</a>
              <p className="mt-2 text-[11px] text-zinc-500">Compiled and linked here; I could not execute a Windows binary in this Linux sandbox, so it is untested on real Windows.</p>
            </div>
            <div className="flex flex-col rounded-2xl border border-white/10 bg-[#101114] p-6">
              <div className="flex items-center justify-between"><h3 className="font-semibold text-white">WebAssembly</h3><Badge>live above</Badge></div>
              <p className="mt-2 flex-1 text-sm text-zinc-400">The <code>pdf_studio_bg.wasm</code> module is linked into this page (wasm-bindgen, <code>--target web</code>) and runs the viewer you see in the Live app section. Verified under Node and in the page build.</p>
              <dl className="mt-4 space-y-1 text-xs text-zinc-500"><div>wasm: {mb(artifacts.wasm.bytes)} (opt-level s, LTO)</div><div className="break-all">sha256 {artifacts.wasm.sha256}</div></dl>
              <a href="#app" className="mt-5 rounded-xl border border-white/10 px-4 py-2.5 text-center text-sm font-medium hover:bg-white/5">Open the live app</a>
            </div>
            <div className="flex flex-col rounded-2xl border border-white/10 bg-[#101114] p-6">
              <div className="flex items-center justify-between"><h3 className="font-semibold text-white">Android</h3><Badge tone="warn">not built here</Badge></div>
              <p className="mt-2 flex-1 text-sm text-zinc-400">
                The Android entry point (<code>android_main</code>, NativeActivity, shared winit host), manifest, Gradle project and <code>scripts/build-android.sh</code> are in the source.
                This sandbox has no Android NDK / JDK / SDK, so <strong className="text-zinc-200">no APK was produced</strong>. Run the script on a machine with the NDK to get one.
              </p>
              <pre className="mt-4 overflow-x-auto rounded-lg bg-black/50 p-3 text-[11px] text-zinc-400">cargo install cargo-ndk{"\n"}sh rust/scripts/build-android.sh</pre>
              <a href={srcZip} download="pdf-studio-rust-source.zip" className="mt-5 rounded-xl border border-white/10 px-4 py-2.5 text-center text-sm font-medium hover:bg-white/5">Download Rust source ({mb(artifacts.source.bytes)})</a>
            </div>
          </div>
        </div>
      </section>

      <section id="architecture" className="mx-auto max-w-6xl px-5 py-16">
        <h2 className="text-2xl font-semibold text-white">Architecture (Phase 1 deliverable)</h2>
        <p className="mt-2 max-w-3xl text-zinc-400">Strict pure-Rust stack: no PDFium / MuPDF / Poppler / Cairo / Skia / FreeType / HarfBuzz / WebView, and no <code>-sys</code> crates in the Windows or Wasm graphs (<code>scripts/check-pure-rust.sh</code> enforces it).</p>
        <pre className="mt-6 overflow-x-auto rounded-2xl border border-white/10 bg-[#101114] p-5 text-[12px] leading-relaxed text-zinc-300">{TREE}</pre>

        <h3 className="mt-12 text-lg font-semibold text-white">Responsive UI state machine</h3>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          {STATES.map((s) => (
            <div key={s.bp} className="rounded-2xl border border-white/10 bg-[#101114] p-5">
              <div className="font-medium text-indigo-300">{s.bp}</div>
              <ul className="mt-3 space-y-2 text-sm text-zinc-400">{s.items.map((i) => <li key={i} className="flex gap-2"><span className="text-indigo-400">›</span>{i}</li>)}</ul>
            </div>
          ))}
        </div>

        <h3 className="mt-12 text-lg font-semibold text-white">Memory / tile-cache budget</h3>
        <div className="mt-4 overflow-x-auto rounded-2xl border border-white/10">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="bg-white/[0.04] text-zinc-400"><tr>{["Cache", "Desktop", "Tablet", "Mobile", "Web"].map((h) => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr></thead>
            <tbody>{BUDGETS.map((r) => <tr key={r[0]} className="border-t border-white/5">{r.map((c, i) => <td key={i} className={`px-4 py-3 ${i === 0 ? "text-zinc-200" : "text-zinc-400"}`}>{c}</td>)}</tr>)}</tbody>
          </table>
        </div>
        <ul className="mt-5 grid gap-3 text-sm text-zinc-400 md:grid-cols-2">
          <li><strong className="text-zinc-200">Zero-copy lazy loading.</strong> Only the XRef index is read on open; objects parse on first touch from a <code>ByteSource</code> (mmap natively, chunk-fetching trait for ranged streaming).</li>
          <li><strong className="text-zinc-200">Tiled virtualization.</strong> Only viewport tiles render; <code>ByteLru</code> evicts to the byte budget. Scale ladder + low-res page proxies keep pinch-zoom smooth.</li>
          <li><strong className="text-zinc-200">Arena allocation.</strong> A per-page <code>bumpalo</code> arena holds content bytes and glyph scratch; dropped as soon as the display list exists.</li>
          <li><strong className="text-zinc-200">Async pipeline.</strong> rayon workers natively; a cooperative one-job-per-frame queue on Wasm — the UI thread never blocks on a tile.</li>
          <li><strong className="text-zinc-200">Incremental saving.</strong> Edits live in an object overlay; save appends only changed objects + a new xref (table or stream) and never rewrites the original bytes.</li>
          <li><strong className="text-zinc-200">Backend seam.</strong> <code>DisplayList</code> is renderer-neutral; the tiny-skia rasteriser is the CPU / Wasm backend and the contract a Vello / wgpu backend plugs into.</li>
        </ul>
      </section>

      <section id="status" className="border-t border-white/5 bg-white/[0.02]">
        <div className="mx-auto max-w-6xl px-5 py-16">
          <h2 className="text-2xl font-semibold text-white">What is real, and what is not (yet)</h2>
          <div className="mt-6 grid gap-5 md:grid-cols-2">
            <div className="rounded-2xl border border-white/10 bg-[#101114] p-6">
              <div className="mb-3"><Badge>implemented &amp; tested</Badge></div>
              <ul className="space-y-2 text-sm text-zinc-400">
                <li>Lazy parser: xref tables / streams / hybrid / damaged-file rebuild, object streams, Flate/LZW/ASCII85/Hex/RunLength + PNG/TIFF predictors</li>
                <li>Rendering: paths, clips, text (TrueType, OpenType, bare CFF, Type0/CID, ToUnicode), images (raw + JPEG), axial/radial shadings, blend modes, annotation appearances</li>
                <li>Reading: continuous / single / two-page, outline, links, named destinations, full-text search, text selection, reflow reading mode</li>
                <li>Editing: ink, highlight, sticky note, text box, visual signature, <em>true</em> redaction, in-place text edit, AcroForm text/checkbox, rotate / delete / reorder / split / merge, undo/redo, incremental save</li>
                <li>Unit + integration tests for core, render and edit; headless UI snapshot tool for all three breakpoints</li>
              </ul>
            </div>
            <div className="rounded-2xl border border-white/10 bg-[#101114] p-6">
              <div className="mb-3"><Badge tone="warn">deliberate limits</Badge></div>
              <ul className="space-y-2 text-sm text-zinc-400">
                <li><strong className="text-zinc-300">Rendering backend is tiny-skia (CPU), not wgpu/Vello/iced.</strong> The build sandbox (1 GB RAM, 2 cores) cannot compile that stack for three targets; the display-list IR is the seam for adding it. Frame rates are CPU-bound.</li>
                <li>Encrypted PDFs are rejected with a message; Type 1 (PFA/PFB) and Type 3 fonts fall back to bundled faces / are skipped; JPX, JBIG2 and CCITT images draw a placeholder.</li>
                <li>Text editing re-encodes with the font already in the file — characters missing from an embedded subset are refused. Full re-flow with font subsetting is not implemented.</li>
                <li>"Digital signature" is a visual ink stamp, not a PKCS#7 cryptographic signature.</li>
                <li>On Wasm the file is held in memory (the browser already has it); the chunked-source trait exists but is not wired to <code>Blob.slice</code> yet.</li>
                <li>Android: code + packaging provided, APK not built or tested here. The Windows exe was cross-linked but not run on Windows.</li>
              </ul>
            </div>
          </div>
          <h3 className="mt-10 text-lg font-semibold text-white">Rebuild everything</h3>
          <pre className="mt-3 overflow-x-auto rounded-2xl border border-white/10 bg-black/50 p-5 text-[12px] leading-relaxed text-zinc-300">{`cd rust
cargo test -p pdf-core -p pdf-render -p pdf-edit      # engine tests
sh scripts/build-wasm.sh                              # → ../src/wasm   (then: npm run build)
sh scripts/build-windows.sh                           # → pdf-studio.exe (zig linker)
sh scripts/build-android.sh                           # needs NDK + JDK (CI workflow included)
sh scripts/check-pure-rust.sh                         # dependency-graph audit`}</pre>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8 text-center text-xs text-zinc-600">PDF Studio · Rust workspace: pdf-core · pdf-render · pdf-edit · ui-shell · platform-targets</footer>
    </div>
  );
}
