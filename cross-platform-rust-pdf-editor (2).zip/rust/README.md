# PDF Studio – pure-Rust PDF reader & editor

Workspace: `pdf-core` (lazy XRef/objects, filters, incremental writer) → `pdf-render` (content-stream interpreter,
display lists, tiny-skia tiles, byte-budgeted LRU) → `pdf-edit` (annotations, forms, text edit, redaction, page ops,
undo/redo, split/merge) → `ui-shell` (adaptive UI state machine, gestures, command palette) → `platform-targets`
(winit+softbuffer host for Windows/macOS/Android, wasm-bindgen host for the web).

Scripts: `build-windows.sh`, `build-wasm.sh`, `build-android.sh`, `check-pure-rust.sh`.
Tests: `cargo test -p pdf-core -p pdf-render -p pdf-edit`. UI snapshots: `cargo run --release --example snapshot -p platform-targets -- /tmp`.
