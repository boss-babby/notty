plugins { id("com.android.application") }
android {
    namespace = "dev.pdfstudio"
    compileSdk = 34
    defaultConfig { applicationId = "dev.pdfstudio"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "0.1.0" }
    buildTypes { release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("debug") } }
    sourceSets["main"].jniLibs.srcDir("src/main/jniLibs")
}
