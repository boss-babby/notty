#!/bin/sh
# Android: builds libpdf_studio.so for arm64-v8a (+armv7) with the NDK, then packages the NativeActivity APK with Gradle.
# Needs: Android NDK r26+ ($ANDROID_NDK_HOME), JDK 17, `cargo install cargo-ndk`, rustup target add aarch64-linux-android armv7-linux-androideabi
set -e
cd "$(dirname "$0")/.."
cargo ndk -t arm64-v8a -t armeabi-v7a -o android/app/src/main/jniLibs rustc --release -p platform-targets --lib --crate-type cdylib
(cd android && ./gradlew assembleRelease 2>/dev/null || gradle assembleRelease)
echo "→ android/app/build/outputs/apk/release/"
