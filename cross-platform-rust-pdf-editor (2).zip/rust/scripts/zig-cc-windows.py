#!/usr/bin/env python3
"""Linker shim for cross-compiling to x86_64-pc-windows-gnu with zig's bundled mingw-w64.
Does what cargo-zigbuild does: drops runtime libs zig provides itself and resolves the
static `windows.*` import libraries from the -L search paths."""
import os, sys, glob
args, libdirs, out, skip_next = sys.argv[1:], [], [], False
for i, a in enumerate(args):
    if a == "-L" and i + 1 < len(args):
        libdirs.append(args[i + 1])
    elif a.startswith("-L") and len(a) > 2:
        libdirs.append(a[2:])
for i, a in enumerate(args):
    if skip_next:
        skip_next = False
        continue
    if a.endswith(".def"):
        continue
    if a in ("-lgcc_eh", "-lgcc", "-lmsvcrt", "-lmingwex", "-lmingw32", "-l:libpthread.a", "-Wl,--high-entropy-va", "-Wl,-Bdynamic", "-Wl,-Bstatic", "-nodefaultlibs", "-fno-use-linker-plugin"):
        continue
    if a.startswith("-lwindows."):
        name = a[2:]
        found = None
        for d in libdirs:
            c = glob.glob(os.path.join(d, f"lib{name}.a"))
            if c:
                found = c[0]
        if found:
            out.append(found)
        continue
    out.append(a)
os.execvp(sys.executable, [sys.executable, "-m", "ziglang", "cc", "-target", "x86_64-windows-gnu"] + out + ["-lunwind"])
