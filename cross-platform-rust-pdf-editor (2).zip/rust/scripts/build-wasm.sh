#!/bin/sh
# WebAssembly build → ../src/wasm (consumed by the Vite site). Needs: rustup target add wasm32-unknown-unknown ; wasm-bindgen-cli 0.2.130
set -e
cd "$(dirname "$0")/.."
cargo rustc -p platform-targets --lib --crate-type cdylib --target wasm32-unknown-unknown --profile wasm
wasm-bindgen target/wasm32-unknown-unknown/wasm/pdf_studio.wasm --out-dir ../src/wasm --target web --no-typescript
