#!/bin/sh
# Cross-compiles the Windows x86_64 executable from Linux/macOS using zig as linker (no MSVC/MinGW install).
# Requires: rustup target add x86_64-pc-windows-gnu ; pip install ziglang
set -e
cd "$(dirname "$0")/.."
SHIM_DIR="$(mktemp -d)"
printf '#!/bin/sh\nexec python3 -m ziglang dlltool "$@"\n' > "$SHIM_DIR/x86_64-w64-mingw32-dlltool"; chmod +x "$SHIM_DIR/x86_64-w64-mingw32-dlltool"
export PATH="$SHIM_DIR:$PATH"
export CARGO_TARGET_X86_64_PC_WINDOWS_GNU_LINKER="$PWD/scripts/zig-cc-windows.py"
cargo build --release -p platform-targets --bin pdf-studio --target x86_64-pc-windows-gnu
echo "→ target/x86_64-pc-windows-gnu/release/pdf-studio.exe"
