#!/bin/sh
# Fails if any C/C++-backed crate (-sys wrappers, cc/cmake/bindgen build helpers) is in the dependency graph
# of the shipped targets. On Android the OS's own API declaration crates (ndk-sys, jni-sys, android_log-sys: Rust FFI
# declarations, no third-party C compiled) are unavoidable and allow-listed; `cc` there is only android-activity's
# build-script helper for its optional GameActivity glue (feature not enabled). `windows-sys`/`linux-raw-sys` are pure-Rust bindings (no C code) and are allowed.
cd "$(dirname "$0")/.."
BAD='(^| )(cc|cmake|bindgen|pkg-config|[a-z0-9_-]+-sys|libc-sys|openssl|freetype|harfbuzz|skia|pdfium|mupdf|poppler|cairo)( v|-)'
for T in x86_64-pc-windows-gnu wasm32-unknown-unknown aarch64-linux-android; do
  OUT=$(cargo tree -p platform-targets --target $T --edges normal,build -f '{p}' 2>/dev/null | grep -E "$BAD" | grep -vE 'windows-sys|linux-raw-sys|android-activity|ndk-sys|jni-sys|android_log-sys|ndk-context|android-properties' | sort -u)
  if [ -n "$OUT" ]; then echo "[$T] NON-PURE:"; echo "$OUT"; FAIL=1; else echo "[$T] pure Rust ✔"; fi
done
exit ${FAIL:-0}
