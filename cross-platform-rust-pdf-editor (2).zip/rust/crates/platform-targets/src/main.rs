#![cfg_attr(all(windows, not(debug_assertions)), windows_subsystem = "windows")]

#[cfg(any(windows, target_os = "macos", feature = "linux-x11"))]
fn main() {
    if let Err(e) = pdf_studio::native::run(std::env::args().nth(1).map(std::path::PathBuf::from)) {
        eprintln!("PDF Studio: {e}");
    }
}

#[cfg(target_arch = "wasm32")]
fn main() {}

#[cfg(all(not(windows), not(target_os = "macos"), not(feature = "linux-x11"), not(target_arch = "wasm32")))]
fn main() {
    eprintln!("Build with `--features linux-x11` for the Linux desktop shell.");
}
