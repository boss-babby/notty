//! Thin per-platform shells around `ui-shell`.
//!
//! * `native`  – winit + softbuffer window loop (Windows, macOS, Linux, Android)
//! * `android` – `android_main` entry for NativeActivity builds
//! * `web`     – wasm-bindgen API driven from a `<canvas>`

#[cfg(any(windows, target_os = "macos", target_os = "android", feature = "linux-x11"))]
pub mod native;

#[cfg(target_os = "android")]
mod android;

#[cfg(target_arch = "wasm32")]
pub mod web;
