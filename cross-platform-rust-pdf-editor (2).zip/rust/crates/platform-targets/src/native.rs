//! winit + softbuffer host shared by Windows, macOS, Linux and Android.

use std::num::NonZeroU32;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tiny_skia::Pixmap;
use ui_shell::*;
use winit::application::ApplicationHandler;
use winit::dpi::LogicalSize;
use winit::event::{ElementState, MouseButton, MouseScrollDelta, TouchPhase, WindowEvent};
use winit::event_loop::{ActiveEventLoop, ControlFlow, EventLoop};
use winit::keyboard::{Key as WKey, ModifiersState, NamedKey};
use winit::window::{Window, WindowId};

type Surface = softbuffer::Surface<Arc<Window>, Arc<Window>>;

struct Shell {
    initial: Option<PathBuf>,
    app: Option<App>,
    window: Option<Arc<Window>>,
    surface: Option<Surface>,
    pm: Option<Pixmap>,
    mods: ModifiersState,
    cursor: (f32, f32),
    start: Instant,
}

pub fn run(initial: Option<PathBuf>) -> Result<(), Box<dyn std::error::Error>> {
    let el = EventLoop::new()?;
    run_with(el, initial)
}

pub fn run_with(el: EventLoop<()>, initial: Option<PathBuf>) -> Result<(), Box<dyn std::error::Error>> {
    el.set_control_flow(ControlFlow::Wait);
    let mut shell = Shell { initial, app: None, window: None, surface: None, pm: None, mods: ModifiersState::empty(), cursor: (0.0, 0.0), start: Instant::now() };
    el.run_app(&mut shell)?;
    Ok(())
}

impl Shell {
    fn now(&self) -> f64 {
        self.start.elapsed().as_secs_f64() * 1000.0 + 1.0
    }

    fn open_path(&mut self, path: &std::path::Path) {
        let name = path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_else(|| "document.pdf".into());
        match pdf_core::MmapSource::open(path) {
            Ok(src) => {
                if let Some(app) = &mut self.app {
                    app.event(Event::OpenDocument { name, source: Arc::new(src), merge: false });
                }
            }
            Err(e) => {
                if let Some(app) = &mut self.app {
                    app.toast(format!("Cannot read file: {e}"));
                }
            }
        }
    }

    fn effects(&mut self) {
        let Some(app) = &mut self.app else { return };
        for e in app.take_effects() {
            match e {
                Effect::OpenUrl(u) => open_url(&u),
                Effect::SaveFile { name, bytes } => {
                    let msg = save_file(&name, &bytes);
                    app.toast(msg);
                }
                Effect::PickFile { merge } => {
                    #[cfg(windows)]
                    {
                        if let Some(p) = rfd::FileDialog::new().add_filter("PDF", &["pdf"]).pick_file() {
                            let name = p.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
                            match pdf_core::MmapSource::open(&p) {
                                Ok(src) => app.event(Event::OpenDocument { name, source: Arc::new(src), merge }),
                                Err(e) => app.toast(format!("Cannot read file: {e}")),
                            }
                        }
                    }
                    #[cfg(not(windows))]
                    {
                        let _ = merge;
                        app.toast("Drop a PDF onto the window to open it");
                    }
                }
                Effect::Copy(s) => {
                    #[cfg(windows)]
                    {
                        if let Ok(mut c) = arboard::Clipboard::new() {
                            let _ = c.set_text(s);
                        }
                    }
                    #[cfg(not(windows))]
                    {
                        let _ = s;
                    }
                }
                Effect::TextFocus(_) => {}
            }
        }
    }

    fn present(&mut self) {
        let (Some(app), Some(surface), Some(pm)) = (&mut self.app, &mut self.surface, &mut self.pm) else { return };
        let (pw, ph) = app.pixel_size();
        if pm.width() != pw || pm.height() != ph {
            if let Some(p) = Pixmap::new(pw, ph) {
                *pm = p;
            }
        }
        let (Some(w), Some(h)) = (NonZeroU32::new(pw), NonZeroU32::new(ph)) else { return };
        if surface.resize(w, h).is_err() {
            return;
        }
        app.render(pm);
        if let Ok(mut buf) = surface.buffer_mut() {
            for (dst, src) in buf.iter_mut().zip(pm.data().chunks_exact(4)) {
                *dst = ((src[0] as u32) << 16) | ((src[1] as u32) << 8) | src[2] as u32;
            }
            let _ = buf.present();
        }
    }

    fn pointer(&mut self, phase: ui_shell::Phase, id: u64, kind: PointerKind, button: u8) {
        let (x, y) = self.cursor;
        if let Some(app) = &mut self.app {
            app.event(Event::Pointer { phase, id, x, y, kind, button });
        }
    }
}

fn open_url(u: &str) {
    if !(u.starts_with("http://") || u.starts_with("https://") || u.starts_with("mailto:")) {
        return;
    }
    #[cfg(windows)]
    let _ = std::process::Command::new("cmd").args(["/C", "start", "", u]).spawn();
    #[cfg(target_os = "macos")]
    let _ = std::process::Command::new("open").arg(u).spawn();
    #[cfg(all(unix, not(target_os = "macos"), not(target_os = "android")))]
    let _ = std::process::Command::new("xdg-open").arg(u).spawn();
}

fn save_file(name: &str, bytes: &[u8]) -> String {
    #[cfg(windows)]
    {
        if let Some(p) = rfd::FileDialog::new().set_file_name(name).add_filter("PDF", &["pdf"]).save_file() {
            return match std::fs::write(&p, bytes) {
                Ok(_) => format!("Saved {}", p.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default()),
                Err(e) => format!("Save failed: {e}"),
            };
        }
        return "Save cancelled".into();
    }
    #[cfg(not(windows))]
    {
        let dir = std::env::var_os("HOME").map(PathBuf::from).map(|h| h.join("Downloads")).filter(|d| d.is_dir()).unwrap_or_else(std::env::temp_dir);
        let p = dir.join(name);
        match std::fs::write(&p, bytes) {
            Ok(_) => format!("Saved to {}", p.display()),
            Err(e) => format!("Save failed: {e}"),
        }
    }
}

impl ApplicationHandler for Shell {
    fn resumed(&mut self, el: &ActiveEventLoop) {
        if self.window.is_some() {
            return;
        }
        let attrs = Window::default_attributes().with_title("PDF Studio").with_inner_size(LogicalSize::new(1280.0, 820.0)).with_min_inner_size(LogicalSize::new(320.0, 480.0));
        let Ok(window) = el.create_window(attrs) else { return };
        let window = Arc::new(window);
        let Ok(ctx) = softbuffer::Context::new(window.clone()) else { return };
        let Ok(surface) = softbuffer::Surface::new(&ctx, window.clone()) else { return };
        let scale = window.scale_factor() as f32;
        let size = window.inner_size().to_logical::<f32>(scale as f64);
        let budget = if cfg!(target_os = "android") { MemoryBudget::mobile() } else { MemoryBudget::desktop() };
        let mut app = App::new(AppConfig { budget, dpr: scale, width: size.width, height: size.height });
        let _ = &mut app;
        self.app = Some(app);
        self.window = Some(window);
        self.surface = Some(surface);
        self.pm = Pixmap::new(1, 1);
        match self.initial.clone() {
            Some(p) => self.open_path(&p),
            None => {
                if let Some(a) = &mut self.app {
                    a.open_sample();
                }
            }
        }
        if let Some(w) = &self.window {
            w.request_redraw();
        }
    }

    fn window_event(&mut self, el: &ActiveEventLoop, _id: WindowId, ev: WindowEvent) {
        let scale = self.window.as_ref().map_or(1.0, |w| w.scale_factor() as f32);
        match ev {
            WindowEvent::CloseRequested => el.exit(),
            WindowEvent::Resized(sz) => {
                let l = sz.to_logical::<f32>(scale as f64);
                if let Some(app) = &mut self.app {
                    app.resize(l.width, l.height, scale);
                }
            }
            WindowEvent::ScaleFactorChanged { .. } => {
                if let (Some(app), Some(w)) = (&mut self.app, &self.window) {
                    let l = w.inner_size().to_logical::<f32>(scale as f64);
                    app.resize(l.width, l.height, scale);
                }
            }
            WindowEvent::RedrawRequested => {
                let now = self.now();
                if let Some(app) = &mut self.app {
                    app.tick(now);
                }
                self.present();
                self.effects();
                if let Some(w) = &self.window {
                    if let Some(app) = &self.app {
                        w.set_title(&app.title());
                    }
                }
            }
            WindowEvent::ModifiersChanged(m) => self.mods = m.state(),
            WindowEvent::CursorMoved { position, .. } => {
                self.cursor = (position.x as f32 / scale, position.y as f32 / scale);
                self.pointer(ui_shell::Phase::Move, 0, PointerKind::Mouse, 0);
            }
            WindowEvent::MouseInput { state, button, .. } => {
                let b = match button {
                    MouseButton::Left => 0,
                    MouseButton::Middle => 1,
                    _ => 2,
                };
                let phase = if state == ElementState::Pressed { ui_shell::Phase::Down } else { ui_shell::Phase::Up };
                self.pointer(phase, 0, PointerKind::Mouse, b);
            }
            WindowEvent::Touch(t) => {
                self.cursor = (t.location.x as f32 / scale, t.location.y as f32 / scale);
                let phase = match t.phase {
                    TouchPhase::Started => ui_shell::Phase::Down,
                    TouchPhase::Moved => ui_shell::Phase::Move,
                    TouchPhase::Ended => ui_shell::Phase::Up,
                    TouchPhase::Cancelled => ui_shell::Phase::Cancel,
                };
                self.pointer(phase, t.id + 1, PointerKind::Touch, 0);
            }
            WindowEvent::MouseWheel { delta, .. } => {
                let (dx, dy) = match delta {
                    MouseScrollDelta::LineDelta(x, y) => (-x * 60.0, -y * 60.0),
                    MouseScrollDelta::PixelDelta(p) => (-(p.x as f32) / scale, -(p.y as f32) / scale),
                };
                let (x, y) = self.cursor;
                let ctrl = self.mods.control_key() || self.mods.super_key();
                if let Some(app) = &mut self.app {
                    app.event(Event::Wheel { x, y, dx, dy, ctrl });
                }
            }
            WindowEvent::DroppedFile(p) => self.open_path(&p),
            WindowEvent::KeyboardInput { event, .. } => {
                if event.state != ElementState::Pressed {
                    return;
                }
                let mods = Mods { ctrl: self.mods.control_key() || self.mods.super_key(), shift: self.mods.shift_key(), alt: self.mods.alt_key() };
                let Some(app) = &mut self.app else { return };
                let named = match &event.logical_key {
                    WKey::Named(n) => match n {
                        NamedKey::Enter => Some(Key::Enter),
                        NamedKey::Escape => Some(Key::Escape),
                        NamedKey::Backspace => Some(Key::Backspace),
                        NamedKey::Delete => Some(Key::Delete),
                        NamedKey::ArrowLeft => Some(Key::Left),
                        NamedKey::ArrowRight => Some(Key::Right),
                        NamedKey::ArrowUp => Some(Key::Up),
                        NamedKey::ArrowDown => Some(Key::Down),
                        NamedKey::PageUp => Some(Key::PageUp),
                        NamedKey::PageDown => Some(Key::PageDown),
                        NamedKey::Home => Some(Key::Home),
                        NamedKey::End => Some(Key::End),
                        NamedKey::Tab => Some(Key::Tab),
                        NamedKey::Space => None,
                        _ => None,
                    },
                    _ => None,
                };
                if let Some(k) = named {
                    app.event(Event::Key { key: k, mods });
                } else if mods.ctrl {
                    if let WKey::Character(s) = &event.logical_key {
                        if let Some(c) = s.chars().next() {
                            app.event(Event::Key { key: Key::Char(c), mods });
                        }
                    }
                } else if let Some(t) = &event.text {
                    app.event(Event::Text(t.to_string()));
                }
            }
            _ => {}
        }
        if let Some(w) = &self.window {
            w.request_redraw();
        }
    }

    fn about_to_wait(&mut self, el: &ActiveEventLoop) {
        let now = self.now();
        let busy = self.app.as_mut().map_or(false, |a| a.tick(now));
        if busy {
            if let Some(w) = &self.window {
                w.request_redraw();
            }
            el.set_control_flow(ControlFlow::WaitUntil(Instant::now() + Duration::from_millis(8)));
        } else {
            el.set_control_flow(ControlFlow::Wait);
        }
    }
}
