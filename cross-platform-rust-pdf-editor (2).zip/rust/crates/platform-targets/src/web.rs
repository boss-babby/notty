//! WebAssembly entry: the whole UI is rendered by Rust into an RGBA buffer
//! that JavaScript blits to a `<canvas>`; JS only forwards input events.

use std::collections::VecDeque;
use tiny_skia::Pixmap;
use ui_shell::*;
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub struct PdfStudio {
    app: App,
    pm: Pixmap,
    effects: VecDeque<Effect>,
    current: Option<Effect>,
}

fn named(code: u8) -> Option<Key> {
    Some(match code {
        1 => Key::Enter,
        2 => Key::Escape,
        3 => Key::Backspace,
        4 => Key::Delete,
        5 => Key::Left,
        6 => Key::Right,
        7 => Key::Up,
        8 => Key::Down,
        9 => Key::PageUp,
        10 => Key::PageDown,
        11 => Key::Home,
        12 => Key::End,
        13 => Key::Tab,
        _ => return None,
    })
}

#[wasm_bindgen]
impl PdfStudio {
    #[wasm_bindgen(constructor)]
    pub fn new(width: f32, height: f32, dpr: f32) -> PdfStudio {
        let app = App::new(AppConfig { budget: MemoryBudget::web(), dpr, width, height });
        let (pw, ph) = app.pixel_size();
        PdfStudio { app, pm: Pixmap::new(pw, ph).unwrap(), effects: VecDeque::new(), current: None }
    }

    pub fn resize(&mut self, width: f32, height: f32, dpr: f32) {
        self.app.resize(width, height, dpr);
        let (pw, ph) = self.app.pixel_size();
        if let Some(p) = Pixmap::new(pw, ph) {
            self.pm = p;
        }
    }

    pub fn open(&mut self, name: &str, bytes: &[u8]) {
        self.app.open_bytes(name, bytes.to_vec());
    }
    pub fn merge(&mut self, name: &str, bytes: &[u8]) {
        self.app.event(Event::OpenDocument { name: name.to_string(), source: std::sync::Arc::new(pdf_core::VecSource(bytes.to_vec())), merge: true });
    }
    pub fn open_sample(&mut self) {
        self.app.open_sample();
    }

    /// phase: 0 down, 1 move, 2 up, 3 cancel · kind: 0 mouse, 1 touch, 2 pen
    pub fn pointer(&mut self, phase: u8, id: u32, x: f32, y: f32, kind: u8, button: u8) {
        let phase = match phase {
            0 => Phase::Down,
            1 => Phase::Move,
            2 => Phase::Up,
            _ => Phase::Cancel,
        };
        let kind = match kind {
            1 => PointerKind::Touch,
            2 => PointerKind::Pen,
            _ => PointerKind::Mouse,
        };
        self.app.event(Event::Pointer { phase, id: id as u64, x, y, kind, button });
    }
    pub fn wheel(&mut self, x: f32, y: f32, dx: f32, dy: f32, ctrl: bool) {
        self.app.event(Event::Wheel { x, y, dx, dy, ctrl });
    }
    /// `code` > 0 selects a named key; otherwise `ch` is the character.
    pub fn key(&mut self, code: u8, ch: &str, ctrl: bool, shift: bool, alt: bool) {
        let key = match named(code) {
            Some(k) => k,
            None => match ch.chars().next() {
                Some(c) => Key::Char(c),
                None => return,
            },
        };
        self.app.event(Event::Key { key, mods: Mods { ctrl, shift, alt } });
    }
    pub fn text(&mut self, s: &str) {
        self.app.event(Event::Text(s.to_string()));
    }

    /// Advance animations / workers; returns true when `pixels_ptr` holds a new frame.
    pub fn frame(&mut self, now_ms: f64) -> bool {
        let busy = self.app.tick(now_ms);
        for e in self.app.take_effects() {
            self.effects.push_back(e);
        }
        if busy || self.app.needs_redraw() {
            self.app.render(&mut self.pm);
            return true;
        }
        false
    }
    pub fn pixels_ptr(&self) -> *const u8 {
        self.pm.data().as_ptr()
    }
    pub fn pixels_len(&self) -> usize {
        self.pm.data().len()
    }
    pub fn pixel_width(&self) -> u32 {
        self.pm.width()
    }
    pub fn pixel_height(&self) -> u32 {
        self.pm.height()
    }
    pub fn title(&self) -> String {
        self.app.title()
    }
    pub fn wants_text(&self) -> bool {
        self.app.wants_text()
    }
    pub fn perform_palette(&mut self) {
        self.app.perform(Action::Palette);
    }
    /// 0 none · 1 open-url · 2 save · 3 pick · 4 pick-merge · 5 copy · 6 text-focus on · 7 off
    pub fn next_effect(&mut self) -> u8 {
        self.current = self.effects.pop_front();
        match &self.current {
            None => 0,
            Some(Effect::OpenUrl(_)) => 1,
            Some(Effect::SaveFile { .. }) => 2,
            Some(Effect::PickFile { merge: false }) => 3,
            Some(Effect::PickFile { merge: true }) => 4,
            Some(Effect::Copy(_)) => 5,
            Some(Effect::TextFocus(true)) => 6,
            Some(Effect::TextFocus(false)) => 7,
        }
    }
    pub fn effect_text(&self) -> String {
        match &self.current {
            Some(Effect::OpenUrl(s)) | Some(Effect::Copy(s)) => s.clone(),
            Some(Effect::SaveFile { name, .. }) => name.clone(),
            _ => String::new(),
        }
    }
    pub fn effect_bytes(&self) -> Vec<u8> {
        match &self.current {
            Some(Effect::SaveFile { bytes, .. }) => bytes.clone(),
            _ => vec![],
        }
    }
    /// Page text of the current document for tests / accessibility (first page).
    pub fn engine_info(&self) -> String {
        format!("pdf-core {} · tiny-skia · pure Rust", env!("CARGO_PKG_VERSION"))
    }
}
