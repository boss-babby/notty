//! Headless UI snapshots: `cargo run --release --example snapshot -- /tmp/out`
use std::time::Duration;
use tiny_skia::Pixmap;
use ui_shell::*;

fn settle(app: &mut App, pm: &mut Pixmap, t: &mut f64) {
    for _ in 0..90 {
        *t += 16.0;
        app.tick(*t);
        app.render(pm);
        std::thread::sleep(Duration::from_millis(8));
    }
}

fn shot(name: &str, w: f32, h: f32, dpr: f32, dir: &str, script: impl FnOnce(&mut App)) {
    let budget = if w < 600.0 { MemoryBudget::mobile() } else { MemoryBudget::desktop() };
    let mut app = App::new(AppConfig { budget, dpr, width: w, height: h });
    app.open_sample();
    let mut pm = Pixmap::new((w * dpr) as u32, (h * dpr) as u32).unwrap();
    let mut t = 0.0;
    settle(&mut app, &mut pm, &mut t);
    script(&mut app);
    settle(&mut app, &mut pm, &mut t);
    pm.save_png(format!("{dir}/{name}.png")).unwrap();
}

fn main() {
    let dir = std::env::args().nth(1).unwrap_or_else(|| "/tmp".into());
    shot("desktop", 1280.0, 800.0, 1.0, &dir, |_| {});
    shot("desktop-palette", 1280.0, 800.0, 1.0, &dir, |a| {
        a.event(Event::Key { key: Key::Char('k'), mods: Mods { ctrl: true, ..Default::default() } });
        a.event(Event::Text("tool".into()));
    });
    shot("desktop-search", 1280.0, 800.0, 1.0, &dir, |a| {
        a.event(Event::Key { key: Key::Char('f'), mods: Mods { ctrl: true, ..Default::default() } });
        a.event(Event::Text("tile".into()));
    });
    shot("tablet", 900.0, 1100.0, 1.0, &dir, |a| a.perform(Action::SetTool(Tool::Ink)));
    shot("mobile", 390.0, 844.0, 2.0, &dir, |_| {});
    shot("mobile-tools", 390.0, 844.0, 2.0, &dir, |a| a.perform(Action::Sheet(SheetKind::Tools)));
    shot("desktop-two", 1280.0, 800.0, 1.0, &dir, |a| a.perform(Action::SetMode(ViewMode::TwoPage)));
    shot("mobile-reading", 390.0, 844.0, 2.0, &dir, |a| {
        a.perform(Action::GoPage(2));
        a.perform(Action::Reading);
    });
}
