//! `pdf-edit` – everything that mutates a document.
//!
//! All edits are expressed as *replacement / new objects in the `Doc`
//! overlay*; the incremental writer appends exactly those objects plus a new
//! XRef section. Undo / redo are O(1) overlay snapshots.

mod editor;
pub mod export;
pub mod sample;

pub use editor::{Affected, Editor, EditError};

#[cfg(test)]
mod tests {
    use super::*;
    use pdf_core::Doc;
    use pdf_render::Renderer;
    use std::sync::Arc;

    fn open(bytes: Vec<u8>) -> (Arc<Doc>, Arc<Renderer>) {
        let d = Arc::new(Doc::from_bytes(bytes).expect("open"));
        let r = Arc::new(Renderer::new(d.clone()));
        (d, r)
    }

    #[test]
    fn sample_renders_and_roundtrips() {
        let bytes = sample::sample_pdf();
        let (doc, r) = open(bytes);
        assert_eq!(doc.page_count(), 3);
        let dl = r.build(0).unwrap();
        assert!(dl.runs.len() > 10, "text runs: {}", dl.runs.len());
        assert!(dl.annots.iter().any(|a| a.field.is_some()), "form fields present");
        assert!(dl.annots.iter().any(|a| a.link.is_some()), "links present");
        let t = dl.page_text().string();
        assert!(t.contains("PDF Studio"), "{t}");
        let pm = pdf_render::render_page(&dl, 1.0).unwrap();
        pm.save_png("/tmp/page1.png").unwrap();
        for i in 1..3 {
            let dl = r.build(i).unwrap();
            pdf_render::render_page(&dl, 1.0).unwrap().save_png(format!("/tmp/page{}.png", i + 1)).unwrap();
        }
        assert!(!pdf_render::outline(&doc).is_empty());
    }

    #[test]
    fn edit_save_reopen() {
        let (doc, r) = open(sample::sample_pdf());
        let mut ed = Editor::new(doc.clone(), r.clone());
        ed.add_highlight(0, &[[48.0, 100.0, 200.0, 120.0]], [1.0, 0.9, 0.2], "").unwrap();
        ed.add_ink(1, &[vec![(100.0, 100.0), (150.0, 130.0), (200.0, 90.0)]], [0.9, 0.1, 0.1], 3.0, false).unwrap();
        ed.add_note(1, (300.0, 300.0), "hello").unwrap();
        ed.add_text_box(1, [100.0, 400.0, 300.0, 440.0], "Typed text", 14.0, [0.0, 0.0, 0.5]).unwrap();
        ed.rotate_page(2, 90).unwrap();
        assert!(ed.is_dirty());
        let out = ed.save_bytes().unwrap();
        let (d2, r2) = open(out);
        assert_eq!(d2.page_count(), 3);
        let dl = r2.build(1).unwrap();
        assert!(dl.annots.iter().any(|a| a.subtype == "Ink"));
        assert!(dl.annots.iter().any(|a| a.subtype == "Text"));
        let dl3 = r2.build(2).unwrap();
        assert!((dl3.width - 842.0).abs() < 1.0, "rotated width {}", dl3.width);
        // undo
        assert!(ed.undo());
    }

    #[test]
    fn text_edit_redact_and_pages() {
        let (doc, r) = open(sample::sample_pdf());
        let mut ed = Editor::new(doc.clone(), r.clone());
        let dl = r.build(2).unwrap();
        let run = dl.runs.iter().find(|x| x.text().contains("Account holder")).expect("run");
        ed.edit_text_run(2, run.op_index.unwrap(), "Account holder: Grace Hopper").unwrap();
        let dl = r.build(2).unwrap();
        assert!(dl.page_text().string().contains("Grace Hopper"));
        let n = ed.redact(2, [40.0, 580.0, 400.0, 620.0]).unwrap();
        let dl = r.build(2).unwrap();
        assert!(!dl.page_text().string().contains("Account number"), "removed {n}: {}", dl.page_text().string());
        ed.move_page(0, 2).unwrap();
        assert!(doc.page_count() == 3);
        ed.delete_page(0).unwrap();
        assert_eq!(doc.page_count(), 2);
        let out = ed.save_bytes().unwrap();
        assert_eq!(open(out).0.page_count(), 2);
    }

    #[test]
    fn forms_and_export() {
        let (doc, r) = open(sample::sample_pdf());
        let mut ed = Editor::new(doc.clone(), r.clone());
        let dl = r.build(0).unwrap();
        let tf = dl.annots.iter().find(|a| a.field.as_ref().map_or(false, |f| f.name == "email")).unwrap();
        let f = tf.field.clone().unwrap();
        ed.set_text_field(0, f.field_id, "ada@example.com").unwrap();
        let cb = dl.annots.iter().find(|a| a.field.as_ref().map_or(false, |f| f.ftype == "Btn")).unwrap();
        let on = ed.toggle_checkbox(0, cb.id, cb.field.as_ref().unwrap().field_id).unwrap();
        assert!(!on, "checkbox started checked");
        let dl = r.build(0).unwrap();
        assert!(dl.annots.iter().any(|a| a.field.as_ref().map_or(false, |f| f.name == "email" && f.value == "ada@example.com")));
        let split = export::split(&doc, &[0, 2]).unwrap();
        let (d2, r2) = open(split);
        assert_eq!(d2.page_count(), 2);
        r2.build(1).unwrap();
        let merged = export::merge(&[&doc, &d2]).unwrap();
        assert_eq!(open(merged).0.page_count(), 5);
    }
}
