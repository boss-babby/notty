//! Built-in demo document, generated with `pdf-writer` (then given AcroForm
//! fields through the editor + incremental writer, exercising the full path).

use crate::Editor;
use pdf_core::Doc;
use pdf_render::Renderer;
use pdf_writer::{Content, Finish, Name, Pdf, Rect, Ref, Str, TextStr};
use std::sync::Arc;

const W: f32 = 595.0;
const H: f32 = 842.0;

fn text(c: &mut Content, font: &[u8], size: f32, x: f32, y: f32, s: &[u8]) {
    c.begin_text().set_font(Name(font), size).next_line(x, y).show(Str(s)).end_text();
}

fn lines(c: &mut Content, font: &[u8], size: f32, x: f32, y: f32, lead: f32, rows: &[&str]) {
    c.begin_text().set_font(Name(font), size).next_line(x, y);
    for (i, r) in rows.iter().enumerate() {
        if i > 0 {
            c.next_line(0.0, -lead);
        }
        c.show(Str(r.as_bytes()));
    }
    c.end_text();
}

fn rounded(c: &mut Content, x: f32, y: f32, w: f32, h: f32, r: f32) {
    let k = 0.5523 * r;
    c.move_to(x + r, y);
    c.line_to(x + w - r, y);
    c.cubic_to(x + w - r + k, y, x + w, y + r - k, x + w, y + r);
    c.line_to(x + w, y + h - r);
    c.cubic_to(x + w, y + h - r + k, x + w - r + k, y + h, x + w - r, y + h);
    c.line_to(x + r, y + h);
    c.cubic_to(x + r - k, y + h, x, y + h - r + k, x, y + h - r);
    c.line_to(x, y + r);
    c.cubic_to(x, y + r - k, x + r - k, y, x + r, y);
    c.close_path();
}

fn axial(pdf: &mut Pdf, id: Ref, coords: [f32; 4], c0: [f32; 3], c1: [f32; 3]) {
    let mut d = pdf.indirect(id).dict();
    d.pair(Name(b"ShadingType"), 2);
    d.pair(Name(b"ColorSpace"), Name(b"DeviceRGB"));
    d.insert(Name(b"Coords")).array().items(coords);
    {
        let mut f = d.insert(Name(b"Function")).dict();
        f.pair(Name(b"FunctionType"), 2);
        f.insert(Name(b"Domain")).array().items([0.0f32, 1.0]);
        f.insert(Name(b"C0")).array().items(c0);
        f.insert(Name(b"C1")).array().items(c1);
        f.pair(Name(b"N"), 1);
    }
    d.insert(Name(b"Extend")).array().items([true, true]);
    d.finish();
}

fn base_font(pdf: &mut Pdf, id: Ref, name: &[u8]) {
    let mut f = pdf.indirect(id).dict();
    f.pair(Name(b"Type"), Name(b"Font"));
    f.pair(Name(b"Subtype"), Name(b"Type1"));
    f.pair(Name(b"BaseFont"), Name(name));
    f.pair(Name(b"Encoding"), Name(b"WinAnsiEncoding"));
    f.finish();
}

fn link_uri(pdf: &mut Pdf, id: Ref, rect: Rect, uri: &[u8]) {
    let mut d = pdf.indirect(id).dict();
    d.pair(Name(b"Type"), Name(b"Annot"));
    d.pair(Name(b"Subtype"), Name(b"Link"));
    d.pair(Name(b"Rect"), rect);
    d.insert(Name(b"Border")).array().items([0, 0, 0]);
    d.insert(Name(b"A")).dict().pair(Name(b"S"), Name(b"URI")).pair(Name(b"URI"), Str(uri));
    d.finish();
}

fn link_goto(pdf: &mut Pdf, id: Ref, rect: Rect, page: Ref) {
    let mut d = pdf.indirect(id).dict();
    d.pair(Name(b"Type"), Name(b"Annot"));
    d.pair(Name(b"Subtype"), Name(b"Link"));
    d.pair(Name(b"Rect"), rect);
    d.insert(Name(b"Border")).array().items([0, 0, 0]);
    d.insert(Name(b"Dest")).array().item(page).item(Name(b"Fit"));
    d.finish();
}

fn outline_item(pdf: &mut Pdf, id: Ref, title: &str, parent: Ref, page: Ref, prev: Option<Ref>, next: Option<Ref>) {
    let mut d = pdf.indirect(id).dict();
    d.pair(Name(b"Title"), TextStr(title));
    d.pair(Name(b"Parent"), parent);
    if let Some(p) = prev {
        d.pair(Name(b"Prev"), p);
    }
    if let Some(n) = next {
        d.pair(Name(b"Next"), n);
    }
    d.insert(Name(b"Dest")).array().item(page).item(Name(b"Fit"));
    d.finish();
}

fn base_pdf() -> Vec<u8> {
    let mut pdf = Pdf::new();
    let (catalog, tree) = (Ref::new(1), Ref::new(2));
    let (f1, f2, f3, f4, f5) = (Ref::new(3), Ref::new(4), Ref::new(5), Ref::new(6), Ref::new(7));
    let pages = [Ref::new(10), Ref::new(11), Ref::new(12)];
    let contents = [Ref::new(20), Ref::new(21), Ref::new(22)];
    let (sh1, sh2, img) = (Ref::new(30), Ref::new(31), Ref::new(32));
    let (ol_root, ol1, ol2, ol3) = (Ref::new(40), Ref::new(41), Ref::new(42), Ref::new(43));
    let (lk1, lk2, lk3) = (Ref::new(50), Ref::new(51), Ref::new(52));

    pdf.catalog(catalog).pages(tree).outlines(ol_root);
    pdf.pages(tree).kids(pages).count(3);
    base_font(&mut pdf, f1, b"Helvetica");
    base_font(&mut pdf, f2, b"Helvetica-Bold");
    base_font(&mut pdf, f3, b"Times-Roman");
    base_font(&mut pdf, f4, b"Times-Italic");
    base_font(&mut pdf, f5, b"Courier");
    axial(&mut pdf, sh1, [0.0, 0.0, W, 0.0], [0.07, 0.10, 0.36], [0.50, 0.22, 0.82]);
    axial(&mut pdf, sh2, [0.0, 0.0, 0.0, 140.0], [0.18, 0.62, 0.95], [0.60, 0.30, 0.95]);

    // gradient image 96x96
    let mut px = Vec::new();
    for y in 0..96u32 {
        for x in 0..96u32 {
            let (fx, fy) = (x as f32 / 95.0, y as f32 / 95.0);
            let d = ((fx - 0.5).powi(2) + (fy - 0.5).powi(2)).sqrt();
            px.push((255.0 * (0.2 + 0.8 * fx)) as u8);
            px.push((255.0 * (0.9 - 0.7 * d * 1.4).clamp(0.0, 1.0)) as u8);
            px.push((255.0 * (0.3 + 0.7 * fy)) as u8);
        }
    }
    {
        let mut im = pdf.image_xobject(img, &px);
        im.width(96);
        im.height(96);
        im.color_space().device_rgb();
        im.bits_per_component(8);
    }

    // outline
    {
        let mut o = pdf.indirect(ol_root).dict();
        o.pair(Name(b"Type"), Name(b"Outlines"));
        o.pair(Name(b"First"), ol1);
        o.pair(Name(b"Last"), ol3);
        o.pair(Name(b"Count"), 3);
        o.finish();
    }
    outline_item(&mut pdf, ol1, "Welcome", ol_root, pages[0], None, Some(ol2));
    outline_item(&mut pdf, ol2, "Typography & vector graphics", ol_root, pages[1], Some(ol1), Some(ol3));
    outline_item(&mut pdf, ol3, "Search, annotate, redact", ol_root, pages[2], Some(ol2), None);

    link_uri(&mut pdf, lk1, Rect::new(48.0, 232.0, 250.0, 250.0), b"https://www.rust-lang.org");
    link_goto(&mut pdf, lk2, Rect::new(48.0, 205.0, 230.0, 223.0), pages[2]);
    link_goto(&mut pdf, lk3, Rect::new(W - 150.0, 30.0, W - 48.0, 46.0), pages[0]);

    // ------------------------------------------------------------- page 1
    let mut c = Content::new();
    c.save_state().rect(0.0, 690.0, W, 152.0).clip_nonzero().end_path();
    c.transform([1.0, 0.0, 0.0, 1.0, 0.0, 690.0]);
    c.shading(Name(b"Sh1"));
    c.restore_state();
    c.set_fill_rgb(1.0, 1.0, 1.0);
    text(&mut c, b"F2", 40.0, 48.0, 770.0, b"PDF Studio");
    text(&mut c, b"F1", 14.0, 48.0, 735.0, b"A pure-Rust PDF reader and editor - one codebase, every screen.");
    text(&mut c, b"F1", 10.0, 48.0, 712.0, b"Open this page in the editor: highlight, draw, add notes, fill the form, redact, search.");
    c.set_fill_rgb(0.1, 0.1, 0.14);
    text(&mut c, b"F2", 18.0, 48.0, 650.0, b"Welcome");
    lines(&mut c, b"F3", 11.0, 48.0, 626.0, 15.0, &[
        "Generated by pdf-writer, rendered by a pure-Rust interpreter.",
        "Pages are parsed lazily from an XRef index, built into a display",
        "list inside a bump arena, then rasterised into byte-budgeted tiles.",
        "Select text to highlight it; press Ctrl+K for the command palette.",
    ]);
    // cards
    let cards: [(&str, &str, [f32; 3]); 3] = [("Read", "Continuous, single, two-page.", [0.90, 0.94, 1.0]), ("Annotate", "Ink, highlights, notes, signatures.", [1.0, 0.95, 0.88]), ("Edit", "Text, redact, forms, pages.", [0.91, 0.98, 0.93])];
    for (i, (t, d, col)) in cards.iter().enumerate() {
        let x = 48.0 + i as f32 * 175.0;
        c.save_state().set_fill_rgb(col[0], col[1], col[2]).set_stroke_rgb(0.75, 0.78, 0.86).set_line_width(0.8);
        rounded(&mut c, x, 468.0, 160.0, 92.0, 12.0);
        c.fill_nonzero_and_stroke().restore_state();
        c.set_fill_rgb(0.1, 0.1, 0.14);
        text(&mut c, b"F2", 14.0, x + 14.0, 536.0, t.as_bytes());
        lines(&mut c, b"F1", 9.0, x + 14.0, 516.0, 12.0, &[d]);
        // little vector glyph
        c.save_state().set_stroke_rgb(0.2, 0.3, 0.9).set_line_width(2.0).set_line_cap(pdf_writer::types::LineCapStyle::RoundCap);
        c.move_to(x + 14.0, 482.0).cubic_to(x + 40.0, 505.0, x + 70.0, 470.0, x + 110.0, 492.0).stroke().restore_state();
    }
    c.set_fill_rgb(0.1, 0.1, 0.14);
    text(&mut c, b"F2", 18.0, 48.0, 450.0, b"Interactive form");
    c.set_fill_rgb(0.3, 0.3, 0.38);
    text(&mut c, b"F1", 10.0, 48.0, 413.0, b"Full name");
    text(&mut c, b"F1", 10.0, 48.0, 378.0, b"E-mail");
    text(&mut c, b"F1", 10.0, 160.0, 335.0, b"Subscribe to product updates");
    c.set_fill_rgb(0.12, 0.28, 0.85);
    text(&mut c, b"F1", 12.0, 48.0, 238.0, b"Visit the Rust project page");
    text(&mut c, b"F1", 12.0, 48.0, 211.0, b"Jump to page 3: search, annotate, redact");
    c.set_stroke_rgb(0.12, 0.28, 0.85).set_line_width(0.6);
    c.move_to(48.0, 236.0).line_to(194.0, 236.0).stroke();
    c.move_to(48.0, 209.0).line_to(264.0, 209.0).stroke();
    c.set_fill_rgb(0.55, 0.55, 0.62);
    text(&mut c, b"F1", 8.0, 48.0, 40.0, b"PDF Studio sample document - page 1 of 3");
    pdf.stream(contents[0], &c.finish());

    // ------------------------------------------------------------- page 2
    let mut c = Content::new();
    c.set_fill_rgb(0.1, 0.1, 0.14);
    text(&mut c, b"F2", 26.0, 48.0, 780.0, b"Typography & vector graphics");
    c.set_fill_rgb(0.35, 0.35, 0.42);
    text(&mut c, b"F4", 13.0, 48.0, 758.0, b"Fonts are decoded with ttf-parser; outlines are filled by tiny-skia.");
    c.set_fill_rgb(0.1, 0.1, 0.14);
    lines(&mut c, b"F3", 10.5, 48.0, 720.0, 15.0, &[
        "Typography is the craft of making written",
        "language legible and beautiful. Every glyph",
        "in a PDF is positioned explicitly: the",
        "interpreter keeps a text matrix, applies",
        "character and word spacing, scaling and rise,",
        "then multiplies by the current matrix before",
        "filling the glyph outline. Kerning arrives via",
        "TJ adjustments in thousandths of an em.",
    ]);
    c.save_state();
    c.transform([170.0, 0.0, 0.0, 170.0, 380.0, 580.0]);
    c.x_object(Name(b"Im1"));
    c.restore_state();
    c.set_stroke_rgb(0.75, 0.78, 0.86).set_line_width(0.8).rect(380.0, 580.0, 170.0, 170.0).stroke();
    c.set_fill_rgb(0.5, 0.5, 0.58);
    text(&mut c, b"F1", 8.0, 380.0, 568.0, b"Figure 1 - 96x96 RGB image, bilinear sampled");
    // chart: bezier + area
    c.set_fill_rgb(0.1, 0.1, 0.14);
    text(&mut c, b"F2", 14.0, 48.0, 560.0, b"Vector paths");
    c.save_state().set_fill_rgb(0.93, 0.95, 1.0).rect(48.0, 380.0, 500.0, 160.0).fill_nonzero().restore_state();
    c.save_state().set_stroke_rgb(0.85, 0.87, 0.93).set_line_width(0.5);
    for i in 0..=5 {
        let y = 380.0 + i as f32 * 32.0;
        c.move_to(48.0, y).line_to(548.0, y).stroke();
    }
    c.restore_state();
    c.save_state().set_fill_rgb(0.30, 0.45, 0.98).set_stroke_rgb(0.12, 0.2, 0.7).set_line_width(2.2);
    c.move_to(48.0, 380.0).cubic_to(120.0, 520.0, 190.0, 420.0, 260.0, 470.0).cubic_to(330.0, 520.0, 400.0, 400.0, 548.0, 500.0).line_to(548.0, 380.0).close_path();
    c.fill_nonzero_and_stroke().restore_state();
    c.save_state().set_stroke_rgb(0.95, 0.35, 0.3).set_line_width(1.6);
    c.move_to(48.0, 400.0).cubic_to(150.0, 380.0, 200.0, 500.0, 300.0, 440.0).cubic_to(400.0, 380.0, 460.0, 470.0, 548.0, 430.0).stroke().restore_state();
    // table
    c.set_fill_rgb(0.1, 0.1, 0.14);
    text(&mut c, b"F2", 14.0, 48.0, 345.0, b"Memory budget (desktop preset)");
    c.set_stroke_rgb(0.7, 0.72, 0.8).set_line_width(0.6);
    let rows = [("Cache", "Budget", "Policy"), ("Raster tiles", "256 MiB", "byte-LRU, 512px"), ("Display lists", "96 MiB", "byte-LRU, per page"), ("Page arena", "transient", "bumpalo, dropped per page"), ("Inflight jobs", "4", "rayon workers")];
    for (i, (a, b, d)) in rows.iter().enumerate() {
        let y = 320.0 - i as f32 * 24.0;
        c.move_to(48.0, y - 7.0).line_to(548.0, y - 7.0).stroke();
        let f: &[u8] = if i == 0 { b"F2" } else { b"F1" };
        text(&mut c, f, 10.0, 56.0, y, a.as_bytes());
        text(&mut c, f, 10.0, 220.0, y, b.as_bytes());
        text(&mut c, f, 10.0, 330.0, y, d.as_bytes());
    }
    c.set_fill_rgb(0.15, 0.15, 0.2);
    lines(&mut c, b"F5", 9.0, 48.0, 190.0, 12.0, &["let doc = Doc::open(Arc::new(MmapSource::open(path)?))?;", "let dl = Renderer::new(doc).build(0)?;   // display list", "let tile = render_tile(&dl, &spec, white);"]);
    c.set_fill_rgb(0.55, 0.55, 0.62);
    text(&mut c, b"F1", 8.0, 48.0, 40.0, b"PDF Studio sample document - page 2 of 3");
    pdf.stream(contents[1], &c.finish());

    // ------------------------------------------------------------- page 3
    let mut c = Content::new();
    c.save_state().rect(0.0, 700.0, W, 142.0).clip_nonzero().end_path();
    c.transform([1.0, 0.0, 0.0, 1.0, 0.0, 700.0]);
    c.shading(Name(b"Sh2"));
    c.restore_state();
    c.set_fill_rgb(1.0, 1.0, 1.0);
    text(&mut c, b"F2", 28.0, 48.0, 770.0, b"Search, annotate, redact");
    text(&mut c, b"F1", 12.0, 48.0, 744.0, b"Try Ctrl+F and search for: document, tile, render.");
    c.set_fill_rgb(0.1, 0.1, 0.14);
    lines(&mut c, b"F3", 11.0, 48.0, 660.0, 16.0, &[
        "Every document keeps its own tile cache. While you scroll, only the",
        "tiles inside the viewport are rendered; tiles that leave the screen",
        "are evicted by a least-recently-used policy under a byte budget.",
        "Rendering happens on worker threads, so the interface never drops a",
        "frame while a dense page is being built.",
        "",
        "Annotations are stored as appearance streams. Saving appends only",
        "the changed objects and a new cross-reference section to the end of",
        "the file - the original document bytes are never rewritten.",
    ]);
    // bar chart
    c.set_fill_rgb(0.1, 0.1, 0.14);
    text(&mut c, b"F2", 14.0, 48.0, 500.0, b"Pipeline stages (illustrative)");
    let vals = [("Open", 0.35), ("Parse", 0.55), ("Tile", 0.82), ("Blit", 0.95), ("Save", 0.4)];
    for (i, (l, v)) in vals.iter().enumerate() {
        let x = 60.0 + i as f32 * 100.0;
        let h = 150.0 * v;
        c.save_state().set_fill_rgb(0.25 + 0.1 * i as f32, 0.45, 0.95 - 0.12 * i as f32);
        rounded(&mut c, x, 320.0, 64.0, h, 6.0);
        c.fill_nonzero().restore_state();
        c.set_fill_rgb(0.3, 0.3, 0.38);
        text(&mut c, b"F1", 9.0, x + 16.0, 305.0, l.as_bytes());
    }
    c.set_fill_rgb(0.1, 0.1, 0.14);
    text(&mut c, b"F2", 14.0, 48.0, 260.0, b"Confidential details (redaction demo)");
    c.set_fill_rgb(0.15, 0.15, 0.2);
    lines(&mut c, b"F1", 11.0, 48.0, 238.0, 16.0, &["Account holder: Ada Lovelace", "Account number: 4417-1234-5678-9010", "Security phrase: analytical engine"]);
    c.set_fill_rgb(0.1, 0.1, 0.14);
    text(&mut c, b"F2", 14.0, 48.0, 160.0, b"Signature");
    c.set_stroke_rgb(0.4, 0.4, 0.5).set_line_width(0.8).move_to(48.0, 100.0).line_to(300.0, 100.0).stroke();
    c.set_fill_rgb(0.5, 0.5, 0.58);
    text(&mut c, b"F1", 8.0, 48.0, 88.0, b"Use the Sign tool to draw your signature on the line above.");
    c.set_fill_rgb(0.12, 0.28, 0.85);
    text(&mut c, b"F1", 10.0, W - 150.0, 34.0, b"Back to page 1");
    c.set_fill_rgb(0.55, 0.55, 0.62);
    text(&mut c, b"F1", 8.0, 48.0, 40.0, b"PDF Studio sample document - page 3 of 3");
    pdf.stream(contents[2], &c.finish());

    // page objects
    let annots: [Vec<Ref>; 3] = [vec![lk1, lk2], vec![], vec![lk3]];
    for i in 0..3 {
        let mut p = pdf.page(pages[i]);
        p.media_box(Rect::new(0.0, 0.0, W, H));
        p.parent(tree);
        p.contents(contents[i]);
        if !annots[i].is_empty() {
            p.annotations(annots[i].iter().copied());
        }
        let mut r = p.resources();
        {
            let mut f = r.fonts();
            f.pair(Name(b"F1"), f1).pair(Name(b"F2"), f2).pair(Name(b"F3"), f3).pair(Name(b"F4"), f4).pair(Name(b"F5"), f5);
        }
        r.shadings().pair(Name(b"Sh1"), sh1).pair(Name(b"Sh2"), sh2);
        r.x_objects().pair(Name(b"Im1"), img);
        r.finish();
        p.finish();
    }
    pdf.document_info(Ref::new(60)).title(TextStr("PDF Studio sample")).creator(TextStr("pdf-writer"));
    pdf.finish()
}

/// The demo document: base PDF + AcroForm fields added via an incremental update.
pub fn sample_pdf() -> Vec<u8> {
    let base = base_pdf();
    let Ok(doc) = Doc::from_bytes(base.clone()) else { return base };
    let doc = Arc::new(doc);
    let renderer = Arc::new(Renderer::new(doc.clone()));
    let mut ed = Editor::new(doc, renderer);
    let v = |x0: f32, y0: f32, x1: f32, y1: f32| [x0, H - y1, x1, H - y0];
    let _ = ed.add_text_field(0, v(130.0, 398.0, 420.0, 422.0), "full_name", "Ada Lovelace");
    let _ = ed.add_text_field(0, v(130.0, 363.0, 420.0, 387.0), "email", "");
    let _ = ed.add_checkbox(0, v(130.0, 322.0, 148.0, 340.0), "subscribe", true);
    ed.save_bytes().unwrap_or(base)
}
