use pdf_core::content::{parse_content, serialize_content, Op};
use pdf_core::write::{flate_stream, plain_stream};
use pdf_core::{dict, encode_text_string, rect_array, Dict, Doc, ObjId, Object, Overlay};
use pdf_render::geom::{page_matrix, Matrix};
use pdf_render::Renderer;
use std::sync::Arc;

#[derive(Debug, Clone)]
pub struct EditError(pub String);
impl std::fmt::Display for EditError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}
impl std::error::Error for EditError {}
type R<T> = Result<T, EditError>;
fn err<T>(s: &str) -> R<T> {
    Err(EditError(s.to_string()))
}

/// Which cached renderings an edit invalidated.
#[derive(Debug, Clone, PartialEq)]
pub enum Affected {
    None,
    Pages(Vec<usize>),
    All,
}

pub struct Editor {
    pub doc: Arc<Doc>,
    pub renderer: Arc<Renderer>,
    undo: Vec<Overlay>,
    redo: Vec<Overlay>,
    saved_rev: u64,
    affected: Affected,
}

fn op(name: &str, a: &[f64]) -> Op {
    Op::new(name, a.iter().map(|v| Object::Real(*v)).collect())
}
fn name_obj(s: &str) -> Object {
    Object::name(s)
}
fn arr(a: &[f64]) -> Object {
    Object::Array(a.iter().map(|v| Object::Real(*v)).collect())
}

fn form_xobject(bbox: [f64; 4], res: Dict, ops: &[Op]) -> Object {
    let d = dict(vec![("Type", name_obj("XObject")), ("Subtype", name_obj("Form")), ("BBox", rect_array(bbox)), ("Resources", Object::Dict(res))]);
    plain_stream(d, serialize_content(ops))
}

fn helv_resources() -> Dict {
    let font = dict(vec![("Type", name_obj("Font")), ("Subtype", name_obj("Type1")), ("BaseFont", name_obj("Helvetica")), ("Encoding", name_obj("WinAnsiEncoding"))]);
    dict(vec![("Font", Object::Dict(dict(vec![("Helv", Object::Dict(font))])))])
}

fn winansi_bytes(s: &str) -> Vec<u8> {
    s.chars()
        .map(|c| match c {
            '€' => 0x80,
            '‘' => 0x91,
            '’' => 0x92,
            '“' => 0x93,
            '”' => 0x94,
            '•' => 0x95,
            '–' => 0x96,
            '—' => 0x97,
            c if (c as u32) < 256 => c as u32 as u8,
            _ => b'?',
        })
        .collect()
}

fn bounds(pts: &[(f64, f64)], pad: f64) -> [f64; 4] {
    let mut r = [f64::MAX, f64::MAX, f64::MIN, f64::MIN];
    for (x, y) in pts {
        r = [r[0].min(*x), r[1].min(*y), r[2].max(*x), r[3].max(*y)];
    }
    [r[0] - pad, r[1] - pad, r[2] + pad, r[3] + pad]
}

/// Smooth polyline → PDF path ops (quadratic midpoints converted to cubics).
fn smooth_path(pts: &[(f64, f64)], out: &mut Vec<Op>) {
    if pts.is_empty() {
        return;
    }
    out.push(op("m", &[pts[0].0, pts[0].1]));
    if pts.len() == 1 {
        out.push(op("l", &[pts[0].0 + 0.01, pts[0].1]));
        return;
    }
    let mut cur = pts[0];
    for i in 1..pts.len() - 1 {
        let mid = ((pts[i].0 + pts[i + 1].0) / 2.0, (pts[i].1 + pts[i + 1].1) / 2.0);
        let c1 = (cur.0 + 2.0 / 3.0 * (pts[i].0 - cur.0), cur.1 + 2.0 / 3.0 * (pts[i].1 - cur.1));
        let c2 = (mid.0 + 2.0 / 3.0 * (pts[i].0 - mid.0), mid.1 + 2.0 / 3.0 * (pts[i].1 - mid.1));
        out.push(op("c", &[c1.0, c1.1, c2.0, c2.1, mid.0, mid.1]));
        cur = mid;
    }
    let last = pts[pts.len() - 1];
    out.push(op("l", &[last.0, last.1]));
}

impl Editor {
    pub fn new(doc: Arc<Doc>, renderer: Arc<Renderer>) -> Editor {
        let saved_rev = doc.revision();
        Editor { doc, renderer, undo: Vec::new(), redo: Vec::new(), saved_rev, affected: Affected::None }
    }

    fn checkpoint(&mut self) {
        self.undo.push(self.doc.snapshot());
        if self.undo.len() > 200 {
            self.undo.remove(0);
        }
        self.redo.clear();
    }

    pub fn take_affected(&mut self) -> Affected {
        std::mem::replace(&mut self.affected, Affected::None)
    }
    fn touch(&mut self, page: usize) {
        match &mut self.affected {
            Affected::Pages(v) => {
                if !v.contains(&page) {
                    v.push(page)
                }
            }
            Affected::None => self.affected = Affected::Pages(vec![page]),
            Affected::All => {}
        }
    }

    pub fn can_undo(&self) -> bool {
        !self.undo.is_empty()
    }
    pub fn can_redo(&self) -> bool {
        !self.redo.is_empty()
    }
    pub fn is_dirty(&self) -> bool {
        self.doc.has_changes() && self.doc.revision() != self.saved_rev
    }
    pub fn mark_saved(&mut self) {
        self.saved_rev = self.doc.revision();
    }

    pub fn undo(&mut self) -> bool {
        match self.undo.pop() {
            Some(s) => {
                self.redo.push(self.doc.snapshot());
                self.doc.restore(s);
                self.affected = Affected::All;
                true
            }
            None => false,
        }
    }
    pub fn redo(&mut self) -> bool {
        match self.redo.pop() {
            Some(s) => {
                self.undo.push(self.doc.snapshot());
                self.doc.restore(s);
                self.affected = Affected::All;
                true
            }
            None => false,
        }
    }

    // ---------------------------------------------------------------- helpers
    fn page_id(&self, page: usize) -> R<ObjId> {
        self.doc.pages().get(page).copied().ok_or_else(|| EditError("no such page".into()))
    }

    /// Matrix mapping default user space to view space for `page`.
    pub fn base_matrix(&self, page: usize) -> R<Matrix> {
        let id = self.page_id(page)?;
        let pd = self.doc.page_dict(id);
        let (b, rot) = self.renderer.page_geometry(&pd);
        Ok(page_matrix(b, rot).0)
    }

    fn to_page_pts(&self, page: usize, pts: &[(f32, f32)]) -> R<Vec<(f64, f64)>> {
        let inv = self.base_matrix(page)?.invert().ok_or_else(|| EditError("degenerate page".into()))?;
        Ok(pts.iter().map(|(x, y)| inv.apply(*x as f64, *y as f64)).collect())
    }

    fn to_page_rect(&self, page: usize, r: [f32; 4]) -> R<[f64; 4]> {
        let inv = self.base_matrix(page)?.invert().ok_or_else(|| EditError("degenerate page".into()))?;
        Ok(inv.transform_rect([r[0] as f64, r[1] as f64, r[2] as f64, r[3] as f64]))
    }

    fn edit_page_dict(&self, page: usize, f: impl FnOnce(&mut Dict)) -> R<()> {
        let id = self.page_id(page)?;
        let obj = self.doc.get(id.0);
        let mut d = obj.as_dict().cloned().ok_or_else(|| EditError("bad page".into()))?;
        f(&mut d);
        self.doc.set_object(id.0, Object::Dict(d));
        Ok(())
    }

    fn append_annot(&mut self, page: usize, annot: ObjId) -> R<()> {
        let id = self.page_id(page)?;
        let obj = self.doc.get(id.0);
        let pd = obj.as_dict().cloned().ok_or_else(|| EditError("bad page".into()))?;
        match pd.get("Annots").cloned() {
            Some(Object::Ref(r)) => {
                let mut v = self.doc.get(r.0).as_array().cloned().unwrap_or_default();
                v.push(Object::Ref(annot));
                self.doc.set_object(r.0, Object::Array(v));
            }
            Some(Object::Array(mut v)) => {
                v.push(Object::Ref(annot));
                self.edit_page_dict(page, |d| {
                    d.insert("Annots".into(), Object::Array(v));
                })?;
            }
            _ => {
                self.edit_page_dict(page, |d| {
                    d.insert("Annots".into(), Object::Array(vec![Object::Ref(annot)]));
                })?;
            }
        }
        self.touch(page);
        Ok(())
    }

    fn base_annot(&self, subtype: &str, rect: [f64; 4], contents: &str, color: [f32; 3], flags: i64) -> Dict {
        dict(vec![
            ("Type", name_obj("Annot")),
            ("Subtype", name_obj(subtype)),
            ("Rect", rect_array(rect)),
            ("C", arr(&[color[0] as f64, color[1] as f64, color[2] as f64])),
            ("F", Object::Int(flags)),
            ("T", Object::Str(encode_text_string("PDF Studio"))),
            ("Contents", Object::Str(encode_text_string(contents))),
            ("M", Object::Str(b"D:20250101000000Z".to_vec())),
        ])
    }

    // ------------------------------------------------------------ annotations
    pub fn add_highlight(&mut self, page: usize, rects_view: &[[f32; 4]], color: [f32; 3], contents: &str) -> R<ObjId> {
        if rects_view.is_empty() {
            return err("nothing selected");
        }
        let rects: Vec<[f64; 4]> = rects_view.iter().map(|r| self.to_page_rect(page, *r)).collect::<R<_>>()?;
        let all = [
            rects.iter().map(|r| r[0]).fold(f64::MAX, f64::min),
            rects.iter().map(|r| r[1]).fold(f64::MAX, f64::min),
            rects.iter().map(|r| r[2]).fold(f64::MIN, f64::max),
            rects.iter().map(|r| r[3]).fold(f64::MIN, f64::max),
        ];
        let mut quads = Vec::new();
        let mut ops = vec![Op::new("gs", vec![name_obj("GS")]), op("rg", &[color[0] as f64, color[1] as f64, color[2] as f64])];
        for r in &rects {
            quads.extend_from_slice(&[r[0], r[3], r[2], r[3], r[0], r[1], r[2], r[1]]);
            ops.push(op("re", &[r[0], r[1], r[2] - r[0], r[3] - r[1]]));
            ops.push(Op::new("f", vec![]));
        }
        let gs = dict(vec![("Type", name_obj("ExtGState")), ("BM", name_obj("Multiply")), ("ca", Object::Real(1.0)), ("CA", Object::Real(1.0))]);
        let res = dict(vec![("ExtGState", Object::Dict(dict(vec![("GS", Object::Dict(gs))])))]);
        let ap = self.doc.new_object(form_xobject(all, res, &ops));
        let mut d = self.base_annot("Highlight", all, contents, color, 4);
        d.insert("QuadPoints".into(), arr(&quads));
        d.insert("AP".into(), Object::Dict(dict(vec![("N", Object::Ref(ap))])));
        self.finish_annot(page, d)
    }

    fn finish_annot(&mut self, page: usize, mut d: Dict) -> R<ObjId> {
        self.checkpoint();
        let id = self.page_id(page)?;
        d.insert("P".into(), Object::Ref(id));
        let aid = self.doc.new_object(Object::Dict(d));
        self.append_annot(page, aid)?;
        Ok(aid)
    }

    pub fn add_ink(&mut self, page: usize, strokes_view: &[Vec<(f32, f32)>], color: [f32; 3], width: f32, subtype_stamp: bool) -> R<ObjId> {
        let strokes: Vec<Vec<(f64, f64)>> = strokes_view.iter().filter(|s| !s.is_empty()).map(|s| self.to_page_pts(page, s)).collect::<R<_>>()?;
        if strokes.is_empty() {
            return err("empty stroke");
        }
        let all_pts: Vec<(f64, f64)> = strokes.iter().flatten().copied().collect();
        let w = width as f64;
        let rect = bounds(&all_pts, w);
        let mut ops = vec![op("w", &[w]), op("J", &[1.0]), op("j", &[1.0]), op("RG", &[color[0] as f64, color[1] as f64, color[2] as f64])];
        let mut ink_list = Vec::new();
        for s in &strokes {
            smooth_path(s, &mut ops);
            ops.push(Op::new("S", vec![]));
            ink_list.push(Object::Array(s.iter().flat_map(|(x, y)| [Object::Real(*x), Object::Real(*y)]).collect()));
        }
        let ap = self.doc.new_object(form_xobject(rect, Dict::new(), &ops));
        let mut d = self.base_annot(if subtype_stamp { "Stamp" } else { "Ink" }, rect, if subtype_stamp { "Signature" } else { "" }, color, 4);
        if subtype_stamp {
            d.insert("Name".into(), name_obj("Signature"));
        } else {
            d.insert("InkList".into(), Object::Array(ink_list));
            d.insert("BS".into(), Object::Dict(dict(vec![("W", Object::Real(w))])));
        }
        d.insert("AP".into(), Object::Dict(dict(vec![("N", Object::Ref(ap))])));
        self.finish_annot(page, d)
    }

    /// Visual signature stamp (ink + label). Not a cryptographic PKCS#7 signature.
    pub fn add_signature(&mut self, page: usize, strokes_view: &[Vec<(f32, f32)>], color: [f32; 3]) -> R<ObjId> {
        self.add_ink(page, strokes_view, color, 1.8, true)
    }

    pub fn add_note(&mut self, page: usize, at_view: (f32, f32), text: &str) -> R<ObjId> {
        let p = self.to_page_pts(page, &[at_view])?[0];
        let rect = [p.0, p.1 - 22.0, p.0 + 22.0, p.1];
        let ops = vec![
            op("rg", &[1.0, 0.86, 0.25]),
            op("re", &[1.0, 1.0, 20.0, 20.0]),
            Op::new("f", vec![]),
            op("RG", &[0.55, 0.42, 0.0]),
            op("w", &[1.0]),
            op("re", &[1.0, 1.0, 20.0, 20.0]),
            Op::new("S", vec![]),
            op("m", &[5.0, 14.0]),
            op("l", &[17.0, 14.0]),
            op("m", &[5.0, 10.0]),
            op("l", &[17.0, 10.0]),
            op("m", &[5.0, 6.0]),
            op("l", &[12.0, 6.0]),
            Op::new("S", vec![]),
        ];
        let ap = self.doc.new_object(form_xobject([0.0, 0.0, 22.0, 22.0], Dict::new(), &ops));
        let mut d = self.base_annot("Text", rect, text, [1.0, 0.86, 0.25], 28);
        d.insert("Name".into(), name_obj("Note"));
        d.insert("AP".into(), Object::Dict(dict(vec![("N", Object::Ref(ap))])));
        self.finish_annot(page, d)
    }

    pub fn add_text_box(&mut self, page: usize, rect_view: [f32; 4], text: &str, size: f32, color: [f32; 3]) -> R<ObjId> {
        let rect = self.to_page_rect(page, rect_view)?;
        let (w, h) = (rect[2] - rect[0], rect[3] - rect[1]);
        let fs = size as f64;
        let mut ops = vec![Op::new("BT", vec![]), Op::new("Tf", vec![name_obj("Helv"), Object::Real(fs)]), op("rg", &[color[0] as f64, color[1] as f64, color[2] as f64]), op("TL", &[fs * 1.2])];
        ops.push(op("Td", &[2.0, h - fs]));
        for line in text.lines() {
            ops.push(Op::new("Tj", vec![Object::Str(winansi_bytes(line))]));
            ops.push(Op::new("T*", vec![]));
        }
        ops.push(Op::new("ET", vec![]));
        let ap = self.doc.new_object(form_xobject([0.0, 0.0, w, h], helv_resources(), &ops));
        let mut d = self.base_annot("FreeText", rect, text, color, 4);
        d.insert("DA".into(), Object::string(&format!("/Helv {} Tf {} {} {} rg", size, color[0], color[1], color[2])));
        d.insert("AP".into(), Object::Dict(dict(vec![("N", Object::Ref(ap))])));
        self.finish_annot(page, d)
    }

    pub fn delete_annot(&mut self, page: usize, annot: ObjId) -> R<()> {
        self.checkpoint();
        let id = self.page_id(page)?;
        let pd = self.doc.get(id.0).as_dict().cloned().ok_or_else(|| EditError("bad page".into()))?;
        let strip = |v: &mut Vec<Object>| v.retain(|o| o.as_ref_id().map(|r| r.0) != Some(annot.0));
        match pd.get("Annots").cloned() {
            Some(Object::Ref(r)) => {
                let mut v = self.doc.get(r.0).as_array().cloned().unwrap_or_default();
                strip(&mut v);
                self.doc.set_object(r.0, Object::Array(v));
            }
            Some(Object::Array(mut v)) => {
                strip(&mut v);
                self.edit_page_dict(page, |d| {
                    d.insert("Annots".into(), Object::Array(v));
                })?;
            }
            _ => {}
        }
        self.touch(page);
        Ok(())
    }

    // -------------------------------------------------------- content editing
    fn load_content_ops(&self, page: usize) -> R<(Vec<Op>, Dict)> {
        let id = self.page_id(page)?;
        let full = self.doc.page_dict(id);
        let ops = parse_content(&self.renderer.page_content(&full));
        let res = self.doc.dget_dict(&full, "Resources").unwrap_or_default();
        Ok((ops, res))
    }

    fn store_content_ops(&mut self, page: usize, ops: &[Op]) -> R<()> {
        let data = serialize_content(ops);
        let id = self.doc.new_object(flate_stream(Dict::new(), &data));
        self.edit_page_dict(page, |d| {
            d.insert("Contents".into(), Object::Ref(id));
        })?;
        self.touch(page);
        Ok(())
    }

    /// Replace the text of one show-text operator (identified by
    /// `TextRun::op_index`). Fails if the font cannot encode a character.
    pub fn edit_text_run(&mut self, page: usize, op_index: usize, new_text: &str) -> R<()> {
        let (mut ops, res) = self.load_content_ops(page)?;
        if op_index >= ops.len() {
            return err("text run is out of date");
        }
        // font in effect at that operator
        let mut stack: Vec<Option<String>> = Vec::new();
        let mut cur: Option<String> = None;
        for o in &ops[..op_index] {
            match o.name.as_str() {
                "q" => stack.push(cur.clone()),
                "Q" => cur = stack.pop().unwrap_or(None),
                "Tf" => cur = o.args.first().and_then(|a| a.as_name()).map(|s| s.to_string()),
                _ => {}
            }
        }
        let fname = cur.ok_or_else(|| EditError("no font selected for this text".into()))?;
        let font = self.renderer.font_by_name(&res, &fname).ok_or_else(|| EditError("font not found".into()))?;
        let encoded = font.encode(new_text).ok_or_else(|| EditError(format!("`{}` cannot render some of these characters (embedded subset)", font.base_name)))?;
        let target = &mut ops[op_index];
        match target.name.as_str() {
            "Tj" => target.args = vec![Object::Str(encoded)],
            "TJ" => target.args = vec![Object::Array(vec![Object::Str(encoded)])],
            "'" => target.args = vec![Object::Str(encoded)],
            "\"" => {
                if target.args.len() >= 3 {
                    target.args[2] = Object::Str(encoded)
                } else {
                    return err("malformed operator");
                }
            }
            _ => return err("not a text operator"),
        }
        self.checkpoint();
        self.store_content_ops(page, &ops)?;
        Ok(())
    }

    /// True redaction: removes text operators under `rect_view` from the
    /// content stream and paints an opaque box. Returns removed run count.
    pub fn redact(&mut self, page: usize, rect_view: [f32; 4]) -> R<usize> {
        let dl = self.renderer.build(page).map_err(|e| EditError(e.to_string()))?;
        let (mut ops, _) = self.load_content_ops(page)?;
        let hit = |r: &[f32; 4]| r[0] < rect_view[2] && r[2] > rect_view[0] && r[1] < rect_view[3] && r[3] > rect_view[1];
        let mut removed = 0;
        for run in dl.runs.iter().filter(|r| hit(&r.rect)) {
            if let Some(i) = run.op_index {
                if i < ops.len() {
                    match ops[i].name.as_str() {
                        "Tj" | "TJ" => {
                            ops[i].name = "Tj".into();
                            ops[i].args = vec![Object::Str(vec![])];
                            removed += 1;
                        }
                        "'" | "\"" => {
                            ops[i].name = "T*".into();
                            ops[i].args = vec![];
                            removed += 1;
                        }
                        _ => {}
                    }
                }
            }
        }
        let pr = self.to_page_rect(page, rect_view)?;
        let mut out = vec![Op::new("q", vec![])];
        out.extend(ops);
        out.push(Op::new("Q", vec![]));
        out.extend([Op::new("q", vec![]), op("rg", &[0.0, 0.0, 0.0]), op("re", &[pr[0], pr[1], pr[2] - pr[0], pr[3] - pr[1]]), Op::new("f", vec![]), Op::new("Q", vec![])]);
        self.checkpoint();
        self.store_content_ops(page, &out)?;
        Ok(removed)
    }

    // ------------------------------------------------------------------ forms
    fn acroform_da_font_size(&self, d: &Dict) -> f64 {
        let da = self.doc.dget_text(d, "DA").or_else(|| {
            let cat = self.doc.catalog().ok()?;
            let af = self.doc.dget_dict(&cat, "AcroForm")?;
            self.doc.dget_text(&af, "DA")
        });
        if let Some(da) = da {
            for o in parse_content(da.as_bytes()) {
                if o.name == "Tf" {
                    if let Some(s) = o.args.get(1).and_then(|a| a.as_f64()) {
                        return s;
                    }
                }
            }
        }
        0.0
    }

    fn mk_ops(&self, wd: &Dict, w: f64, h: f64) -> Vec<Op> {
        let mut ops = Vec::new();
        if let Some(mk) = self.doc.dget_dict(wd, "MK") {
            let col = |k: &str| self.doc.dget_nums(&mk, k).filter(|v| !v.is_empty());
            if let Some(bg) = col("BG") {
                ops.push(color_op(false, &bg));
                ops.push(op("re", &[0.0, 0.0, w, h]));
                ops.push(Op::new("f", vec![]));
            }
            if let Some(bc) = col("BC") {
                ops.push(color_op(true, &bc));
                ops.push(op("w", &[1.0]));
                ops.push(op("re", &[0.5, 0.5, w - 1.0, h - 1.0]));
                ops.push(Op::new("S", vec![]));
            }
        }
        ops
    }

    fn text_field_ap(&self, wd: &Dict, value: &str) -> Option<Object> {
        let r = self.doc.dget_nums(wd, "Rect")?;
        let r = pdf_render::geom::normalize_rect(&r);
        let (w, h) = (r[2] - r[0], r[3] - r[1]);
        let mut fs = self.acroform_da_font_size(wd);
        if fs <= 0.0 {
            fs = (h - 6.0).clamp(7.0, 12.0);
        }
        let mut ops = self.mk_ops(wd, w, h);
        ops.push(Op::new("BMC", vec![name_obj("Tx")]));
        ops.push(Op::new("q", vec![]));
        ops.push(op("re", &[1.0, 1.0, w - 2.0, h - 2.0]));
        ops.push(Op::new("W", vec![]));
        ops.push(Op::new("n", vec![]));
        ops.push(Op::new("BT", vec![]));
        ops.push(Op::new("Tf", vec![name_obj("Helv"), Object::Real(fs)]));
        ops.push(op("g", &[0.05]));
        ops.push(op("Td", &[3.0, (h - fs) / 2.0 + fs * 0.22]));
        ops.push(Op::new("Tj", vec![Object::Str(winansi_bytes(value))]));
        ops.push(Op::new("ET", vec![]));
        ops.push(Op::new("Q", vec![]));
        ops.push(Op::new("EMC", vec![]));
        Some(form_xobject([0.0, 0.0, w, h], helv_resources(), &ops))
    }

    fn widgets_of(&self, field: ObjId) -> Vec<ObjId> {
        let fo = self.doc.get(field.0);
        let Some(fd) = fo.as_dict() else { return vec![] };
        if let Some(kids) = self.doc.dget_array(fd, "Kids") {
            kids.iter().filter_map(|k| k.as_ref_id()).collect()
        } else {
            vec![field]
        }
    }

    pub fn set_text_field(&mut self, page: usize, field: ObjId, value: &str) -> R<()> {
        self.checkpoint();
        let fo = self.doc.get(field.0);
        let mut fd = fo.as_dict().cloned().ok_or_else(|| EditError("bad field".into()))?;
        fd.insert("V".into(), Object::Str(encode_text_string(value)));
        self.doc.set_object(field.0, Object::Dict(fd));
        for w in self.widgets_of(field) {
            let wo = self.doc.get(w.0);
            let Some(mut wd) = wo.as_dict().cloned() else { continue };
            if let Some(ap) = self.text_field_ap(&wd, value) {
                let aid = self.doc.new_object(ap);
                wd.insert("AP".into(), Object::Dict(dict(vec![("N", Object::Ref(aid))])));
                self.doc.set_object(w.0, Object::Dict(wd));
            }
        }
        self.touch(page);
        Ok(())
    }

    pub fn toggle_checkbox(&mut self, page: usize, widget: ObjId, field: ObjId) -> R<bool> {
        let wo = self.doc.get(widget.0);
        let mut wd = wo.as_dict().cloned().ok_or_else(|| EditError("bad widget".into()))?;
        let states = self.doc.dget_dict(&wd, "AP").and_then(|ap| self.doc.dget_dict(&ap, "N")).unwrap_or_default();
        let on = states.keys().find(|k| k.as_str() != "Off").cloned().unwrap_or_else(|| "Yes".to_string());
        let cur = self.doc.dget_name(&wd, "AS").unwrap_or_else(|| "Off".into());
        let new = if cur == "Off" { on } else { "Off".to_string() };
        self.checkpoint();
        wd.insert("AS".into(), name_obj(&new));
        if field == widget {
            wd.insert("V".into(), name_obj(&new));
            self.doc.set_object(widget.0, Object::Dict(wd));
        } else {
            self.doc.set_object(widget.0, Object::Dict(wd));
            if let Some(mut fd) = self.doc.get(field.0).as_dict().cloned() {
                fd.insert("V".into(), name_obj(&new));
                self.doc.set_object(field.0, Object::Dict(fd));
            }
        }
        self.touch(page);
        Ok(new != "Off")
    }

    fn register_field(&mut self, field: ObjId) -> R<()> {
        let root = self.doc.trailer.get("Root").and_then(|r| r.as_ref_id()).ok_or_else(|| EditError("no catalog".into()))?;
        let mut cat = self.doc.catalog().map_err(|e| EditError(e.to_string()))?;
        let font = dict(vec![("Type", name_obj("Font")), ("Subtype", name_obj("Type1")), ("BaseFont", name_obj("Helvetica")), ("Encoding", name_obj("WinAnsiEncoding"))]);
        match cat.get("AcroForm").cloned() {
            Some(Object::Ref(r)) => {
                let mut af = self.doc.get(r.0).as_dict().cloned().unwrap_or_default();
                let mut f = self.doc.dget_array(&af, "Fields").unwrap_or_default();
                f.push(Object::Ref(field));
                af.insert("Fields".into(), Object::Array(f));
                self.doc.set_object(r.0, Object::Dict(af));
            }
            other => {
                let mut af = match other {
                    Some(Object::Dict(d)) => d,
                    _ => dict(vec![("DA", Object::string("/Helv 0 Tf 0 g")), ("DR", Object::Dict(dict(vec![("Font", Object::Dict(dict(vec![("Helv", Object::Dict(font))])))])))]),
                };
                let mut f = match af.get("Fields") {
                    Some(Object::Array(a)) => a.clone(),
                    _ => vec![],
                };
                f.push(Object::Ref(field));
                af.insert("Fields".into(), Object::Array(f));
                cat.insert("AcroForm".into(), Object::Dict(af));
                self.doc.set_object(root.0, Object::Dict(cat));
            }
        }
        Ok(())
    }

    pub fn add_text_field(&mut self, page: usize, rect_view: [f32; 4], name: &str, value: &str) -> R<ObjId> {
        let rect = self.to_page_rect(page, rect_view)?;
        let mut d = dict(vec![
            ("Type", name_obj("Annot")),
            ("Subtype", name_obj("Widget")),
            ("FT", name_obj("Tx")),
            ("T", Object::Str(encode_text_string(name))),
            ("V", Object::Str(encode_text_string(value))),
            ("Rect", rect_array(rect)),
            ("F", Object::Int(4)),
            ("DA", Object::string("/Helv 11 Tf 0 g")),
            ("MK", Object::Dict(dict(vec![("BC", arr(&[0.55, 0.58, 0.66])), ("BG", arr(&[0.96, 0.97, 1.0]))]))),
        ]);
        if let Some(ap) = self.text_field_ap(&d, value) {
            let aid = self.doc.new_object(ap);
            d.insert("AP".into(), Object::Dict(dict(vec![("N", Object::Ref(aid))])));
        }
        self.finish_widget(page, d)
    }

    pub fn add_checkbox(&mut self, page: usize, rect_view: [f32; 4], name: &str, checked: bool) -> R<ObjId> {
        let rect = self.to_page_rect(page, rect_view)?;
        let (w, h) = (rect[2] - rect[0], rect[3] - rect[1]);
        let mut base = vec![op("rg", &[0.96, 0.97, 1.0]), op("re", &[0.0, 0.0, w, h]), Op::new("f", vec![]), op("RG", &[0.55, 0.58, 0.66]), op("w", &[1.0]), op("re", &[0.5, 0.5, w - 1.0, h - 1.0]), Op::new("S", vec![])];
        let off = form_xobject([0.0, 0.0, w, h], Dict::new(), &base);
        base.extend([op("RG", &[0.1, 0.1, 0.12]), op("w", &[1.6]), op("m", &[w * 0.2, h * 0.5]), op("l", &[w * 0.42, h * 0.25]), op("l", &[w * 0.8, h * 0.78]), Op::new("S", vec![])]);
        let on = form_xobject([0.0, 0.0, w, h], Dict::new(), &base);
        let (off_id, on_id) = (self.doc.new_object(off), self.doc.new_object(on));
        let state = if checked { "Yes" } else { "Off" };
        let d = dict(vec![
            ("Type", name_obj("Annot")),
            ("Subtype", name_obj("Widget")),
            ("FT", name_obj("Btn")),
            ("T", Object::Str(encode_text_string(name))),
            ("V", name_obj(state)),
            ("AS", name_obj(state)),
            ("Rect", rect_array(rect)),
            ("F", Object::Int(4)),
            ("AP", Object::Dict(dict(vec![("N", Object::Dict(dict(vec![("Yes", Object::Ref(on_id)), ("Off", Object::Ref(off_id))])))]))),
        ]);
        self.finish_widget(page, d)
    }

    fn finish_widget(&mut self, page: usize, mut d: Dict) -> R<ObjId> {
        self.checkpoint();
        d.insert("P".into(), Object::Ref(self.page_id(page)?));
        let id = self.doc.new_object(Object::Dict(d));
        self.append_annot(page, id)?;
        self.register_field(id)?;
        Ok(id)
    }

    // -------------------------------------------------------------- page ops
    pub fn rotate_page(&mut self, page: usize, delta: i32) -> R<()> {
        let id = self.page_id(page)?;
        let cur = self.doc.dget_i64(&self.doc.page_dict(id), "Rotate").unwrap_or(0) as i32;
        let new = (cur + delta).rem_euclid(360);
        self.checkpoint();
        self.edit_page_dict(page, |d| {
            d.insert("Rotate".into(), Object::Int(new as i64));
        })?;
        self.touch(page);
        Ok(())
    }

    fn adjust_counts(&self, mut node: Option<ObjId>, delta: i64) {
        let mut guard = 0;
        while let Some(n) = node {
            guard += 1;
            if guard > 64 {
                break;
            }
            let o = self.doc.get(n.0);
            let Some(mut d) = o.as_dict().cloned() else { break };
            let c = self.doc.dget_i64(&d, "Count").unwrap_or(0) + delta;
            d.insert("Count".into(), Object::Int(c.max(0)));
            node = d.get("Parent").and_then(|p| p.as_ref_id());
            self.doc.set_object(n.0, Object::Dict(d));
        }
    }

    pub fn delete_page(&mut self, page: usize) -> R<()> {
        if self.doc.page_count() <= 1 {
            return err("cannot delete the only page");
        }
        let id = self.page_id(page)?;
        let pd = self.doc.get(id.0).as_dict().cloned().ok_or_else(|| EditError("bad page".into()))?;
        let parent = pd.get("Parent").and_then(|p| p.as_ref_id()).ok_or_else(|| EditError("page has no parent".into()))?;
        self.checkpoint();
        let po = self.doc.get(parent.0);
        let mut parent_d = po.as_dict().cloned().ok_or_else(|| EditError("bad parent".into()))?;
        let mut kids = self.doc.dget_array(&parent_d, "Kids").unwrap_or_default();
        kids.retain(|k| k.as_ref_id().map(|r| r.0) != Some(id.0));
        parent_d.insert("Kids".into(), Object::Array(kids));
        self.doc.set_object(parent.0, Object::Dict(parent_d));
        self.adjust_counts(Some(parent), -1);
        self.affected = Affected::All;
        Ok(())
    }

    /// Move page `from` so that it ends up at index `to` (flattens the page tree).
    pub fn move_page(&mut self, from: usize, to: usize) -> R<()> {
        let pages = self.doc.pages();
        if from >= pages.len() || to >= pages.len() {
            return err("page out of range");
        }
        if from == to {
            return Ok(());
        }
        self.checkpoint();
        let mut order: Vec<ObjId> = pages.to_vec();
        let p = order.remove(from);
        order.insert(to, p);
        let cat = self.doc.catalog().map_err(|e| EditError(e.to_string()))?;
        let root = cat.get("Pages").and_then(|p| p.as_ref_id()).ok_or_else(|| EditError("no page tree".into()))?;
        let ro = self.doc.get(root.0);
        let mut rd = ro.as_dict().cloned().ok_or_else(|| EditError("bad page tree".into()))?;
        rd.insert("Kids".into(), Object::Array(order.iter().map(|p| Object::Ref(*p)).collect()));
        rd.insert("Count".into(), Object::Int(order.len() as i64));
        self.doc.set_object(root.0, Object::Dict(rd));
        for p in &order {
            let po = self.doc.get(p.0);
            if let Some(mut pd) = po.as_dict().cloned() {
                if pd.get("Parent").and_then(|x| x.as_ref_id()).map(|r| r.0) != Some(root.0) {
                    // keep inherited attributes when re-parenting
                    for (k, v) in self.doc.page_dict(*p) {
                        if matches!(k.as_str(), "Resources" | "MediaBox" | "CropBox" | "Rotate") {
                            pd.entry(k).or_insert(v);
                        }
                    }
                    pd.insert("Parent".into(), Object::Ref(root));
                    self.doc.set_object(p.0, Object::Dict(pd));
                }
            }
        }
        self.affected = Affected::All;
        Ok(())
    }

    // ----------------------------------------------------------------- saving
    pub fn save_bytes(&self) -> R<Vec<u8>> {
        let mut out = Vec::with_capacity(self.doc.source().len() as usize + 4096);
        self.doc.save_incremental(&mut out).map_err(|e| EditError(e.to_string()))?;
        Ok(out)
    }

    pub fn save_to(&self, w: &mut dyn std::io::Write) -> R<u64> {
        self.doc.save_incremental(w).map_err(|e| EditError(e.to_string()))
    }
}

fn color_op(stroke: bool, c: &[f64]) -> Op {
    let name = match (c.len(), stroke) {
        (1, false) => "g",
        (1, true) => "G",
        (4, false) => "k",
        (4, true) => "K",
        (_, false) => "rg",
        (_, true) => "RG",
    };
    op(name, c)
}
