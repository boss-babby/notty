//! Structural export: split / merge / extract pages into a fresh PDF by
//! deep-copying only the objects reachable from the selected pages.

use pdf_core::write::PdfBuilder;
use pdf_core::{dict, Dict, Doc, ObjId, Object, Stream, StreamData};
use std::collections::{HashMap, HashSet};
use std::sync::Arc;

struct Copier<'a> {
    srcs: &'a [(&'a Doc, Vec<usize>)],
    map: HashMap<(usize, u32), u32>,
    queue: Vec<(usize, u32, u32)>,
    skip: HashSet<(usize, u32)>,
    next: u32,
}

impl<'a> Copier<'a> {
    fn remap(&mut self, di: usize, o: &Object) -> Object {
        match o {
            Object::Ref((n, _)) => {
                let key = (di, *n);
                if self.skip.contains(&key) {
                    return Object::Null;
                }
                let new = match self.map.get(&key) {
                    Some(x) => *x,
                    None => {
                        let x = self.next;
                        self.next += 1;
                        self.map.insert(key, x);
                        self.queue.push((di, *n, x));
                        x
                    }
                };
                Object::Ref((new, 0))
            }
            Object::Array(a) => Object::Array(a.iter().map(|x| self.remap(di, x)).collect()),
            Object::Dict(d) => Object::Dict(self.remap_dict(di, d)),
            other => other.clone(),
        }
    }
    fn remap_dict(&mut self, di: usize, d: &Dict) -> Dict {
        d.iter().map(|(k, v)| (k.clone(), self.remap(di, v))).collect()
    }
}

/// Build a new PDF from `(document, page indices)` pairs, in order.
pub fn extract_pages(sources: &[(&Doc, Vec<usize>)]) -> Result<Vec<u8>, String> {
    let total: usize = sources.iter().map(|s| s.1.len()).sum();
    if total == 0 {
        return Err("no pages selected".into());
    }
    let mut c = Copier { srcs: sources, map: HashMap::new(), queue: Vec::new(), skip: HashSet::new(), next: 3 };
    // pages of every source doc: unselected ones become Null when referenced
    for (di, (doc, sel)) in sources.iter().enumerate() {
        let pages = doc.pages();
        for (i, p) in pages.iter().enumerate() {
            if !sel.contains(&i) {
                c.skip.insert((di, p.0));
            }
        }
    }
    // allocate selected page numbers
    let mut order: Vec<(usize, ObjId, u32)> = Vec::new();
    for (di, (doc, sel)) in sources.iter().enumerate() {
        let pages = doc.pages();
        for &i in sel {
            let id = *pages.get(i).ok_or("page out of range")?;
            let n = c.next;
            c.next += 1;
            c.map.insert((di, id.0), n);
            order.push((di, id, n));
        }
    }
    let mut b = PdfBuilder::new();
    let mut kids = Vec::new();
    for (di, id, n) in &order {
        let doc = c.srcs[*di].0;
        let pd = doc.page_dict(*id);
        let mut out = Dict::new();
        for (k, v) in &pd {
            if k == "Parent" || k == "StructParents" || k == "B" || k == "Thumb" {
                continue;
            }
            let nv = c.remap(*di, v);
            out.insert(k.clone(), nv);
        }
        out.insert("Parent".into(), Object::Ref((2, 0)));
        b.add(*n, &Object::Dict(out));
        kids.push(Object::Ref((*n, 0)));
    }
    // drain the work queue
    while let Some((di, old, new)) = c.queue.pop() {
        let doc = c.srcs[di].0;
        let obj = doc.get(old);
        match &*obj {
            Object::Stream(s) => {
                let raw = doc.stream_raw(s).into_owned();
                let d = c.remap_dict(di, &s.dict);
                let st = Object::Stream(Box::new(Stream { dict: d, data: StreamData::Mem(Arc::new(raw.clone())) }));
                b.add_with_raw(new, 0, &st, Some(&raw));
            }
            other => {
                let o = c.remap(di, other);
                b.add(new, &o);
            }
        }
    }
    b.add(1, &Object::Dict(dict(vec![("Type", Object::name("Catalog")), ("Pages", Object::Ref((2, 0)))])));
    b.add(2, &Object::Dict(dict(vec![("Type", Object::name("Pages")), ("Kids", Object::Array(kids)), ("Count", Object::Int(total as i64))])));
    Ok(b.finish((1, 0), Dict::new()))
}

pub fn merge(docs: &[&Doc]) -> Result<Vec<u8>, String> {
    let srcs: Vec<(&Doc, Vec<usize>)> = docs.iter().map(|d| (*d, (0..d.page_count()).collect())).collect();
    extract_pages(&srcs)
}

pub fn split(doc: &Doc, pages: &[usize]) -> Result<Vec<u8>, String> {
    extract_pages(&[(doc, pages.to_vec())])
}
