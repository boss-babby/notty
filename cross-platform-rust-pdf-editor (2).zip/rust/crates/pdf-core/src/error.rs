use std::fmt;

#[derive(Debug, Clone, PartialEq)]
pub enum Error {
    /// Ran out of bytes while parsing (caller may retry with a larger window).
    Eof,
    Parse(String),
    Unsupported(String),
    Missing(String),
}

pub type Result<T> = std::result::Result<T, Error>;

impl Error {
    pub fn parse(s: impl Into<String>) -> Self {
        Error::Parse(s.into())
    }
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::Eof => write!(f, "unexpected end of data"),
            Error::Parse(s) => write!(f, "parse error: {s}"),
            Error::Unsupported(s) => write!(f, "unsupported: {s}"),
            Error::Missing(s) => write!(f, "missing: {s}"),
        }
    }
}

impl std::error::Error for Error {}
