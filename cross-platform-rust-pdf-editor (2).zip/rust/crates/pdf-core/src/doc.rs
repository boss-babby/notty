//! `Doc` – lazily parsed document. Only the XRef index is read on open;
//! objects are parsed on first access and cached. All edits live in an
//! `overlay` of replaced / new objects that the incremental writer appends.

use crate::error::{Error, Result};
use crate::filters;
use crate::lexer::{is_regular, is_ws, Lexer, Value};
use crate::object::*;
use crate::source::ByteSource;
use std::borrow::Cow;
use std::collections::{HashMap, HashSet};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex, RwLock};

static NEXT_DOC_ID: AtomicU64 = AtomicU64::new(1);

#[derive(Clone, Copy, Debug)]
pub enum XEntry {
    Free,
    Offset { off: u64, gen: u16 },
    InStream { stm: u32, idx: u32 },
}

struct ObjStm {
    data: Vec<u8>,
    entries: Vec<(u32, usize)>,
}

#[derive(Clone, Default)]
pub struct Overlay {
    pub objects: HashMap<u32, Arc<Object>>,
    pub next_num: u32,
    pub revision: u64,
}

pub struct Decoded {
    pub data: Vec<u8>,
    /// Set when decoding stopped at an image codec (DCT/JPX/CCITT/JBIG2).
    pub image_filter: Option<String>,
    pub parms: Option<Dict>,
}

pub struct Doc {
    pub(crate) src: Arc<dyn ByteSource>,
    pub(crate) xref: HashMap<u32, XEntry>,
    pub trailer: Dict,
    cache: Mutex<HashMap<u32, Arc<Object>>>,
    objstms: Mutex<HashMap<u32, Arc<ObjStm>>>,
    pub(crate) overlay: RwLock<Overlay>,
    pages_cache: RwLock<Option<Arc<Vec<ObjId>>>>,
    pub startxref: u64,
    pub xref_is_stream: bool,
    pub reconstructed: bool,
    pub size: u32,
    pub id: u64,
}

impl Doc {
    fn blank(src: Arc<dyn ByteSource>) -> Doc {
        Doc {
            src,
            xref: HashMap::new(),
            trailer: Dict::new(),
            cache: Mutex::new(HashMap::new()),
            objstms: Mutex::new(HashMap::new()),
            overlay: RwLock::new(Overlay::default()),
            pages_cache: RwLock::new(None),
            startxref: 0,
            xref_is_stream: false,
            reconstructed: false,
            size: 0,
            id: NEXT_DOC_ID.fetch_add(1, Ordering::Relaxed),
        }
    }

    pub fn open(src: Arc<dyn ByteSource>) -> Result<Doc> {
        if src.len() < 20 {
            return Err(Error::parse("file too small to be a PDF"));
        }
        let head = src.read(0, 1024);
        if !head.windows(5).any(|w| w == b"%PDF-") {
            return Err(Error::parse("missing %PDF- header"));
        }
        drop(head);
        let mut doc = Doc::blank(src);
        let ok = doc.load_xref().is_ok() && doc.validate();
        if !ok {
            doc.xref.clear();
            doc.trailer.clear();
            doc.cache.lock().unwrap().clear();
            doc.objstms.lock().unwrap().clear();
            doc.reconstruct()?;
            doc.reconstructed = true;
            if !doc.validate() {
                return Err(Error::parse("could not locate document catalog"));
            }
        }
        if doc.trailer.contains_key("Encrypt") {
            return Err(Error::Unsupported("encrypted documents".into()));
        }
        let max = doc.xref.keys().copied().max().unwrap_or(0) + 1;
        doc.size = doc.trailer.get("Size").and_then(|o| o.as_i64()).unwrap_or(0).max(max as i64) as u32;
        doc.overlay.write().unwrap().next_num = doc.size;
        Ok(doc)
    }

    pub fn from_bytes(bytes: Vec<u8>) -> Result<Doc> {
        Doc::open(Arc::new(crate::source::VecSource(bytes)))
    }

    fn validate(&self) -> bool {
        self.catalog().map_or(false, |c| c.contains_key("Pages"))
    }

    pub fn source(&self) -> &Arc<dyn ByteSource> {
        &self.src
    }

    // ------------------------------------------------------------------ xref
    fn load_xref(&mut self) -> Result<()> {
        let len = self.src.len();
        let tail_start = len.saturating_sub(2048);
        let tail = self.src.read(tail_start, len);
        let p = tail.windows(9).rposition(|w| w == b"startxref").ok_or_else(|| Error::parse("no startxref"))?;
        let mut lx = Lexer::new(&tail, p + 9);
        let start = match lx.object()? {
            Object::Int(i) if i >= 0 => i as u64,
            _ => return Err(Error::parse("bad startxref")),
        };
        drop(tail);
        self.startxref = start;
        let mut visited = HashSet::new();
        let mut next = Some(start);
        let mut first = true;
        while let Some(off) = next.take() {
            if !visited.insert(off) || off >= len {
                break;
            }
            let (trailer, xrefstm) = self.read_xref_section(off, first)?;
            if let Some(x) = xrefstm {
                if visited.insert(x) {
                    let _ = self.read_xref_section(x, false);
                }
            }
            next = trailer.get("Prev").and_then(|o| o.as_i64()).filter(|&p| p >= 0).map(|p| p as u64);
            if first {
                self.trailer = trailer;
                first = false;
            } else {
                for (k, v) in trailer {
                    self.trailer.entry(k).or_insert(v);
                }
            }
        }
        if self.trailer.is_empty() {
            return Err(Error::parse("no trailer"));
        }
        Ok(())
    }

    fn read_xref_section(&mut self, off: u64, first: bool) -> Result<(Dict, Option<u64>)> {
        let len = self.src.len();
        let data = self.src.read(off, len);
        let mut lx = Lexer::new(&data, 0);
        lx.skip_ws();
        if data[lx.pos..].starts_with(b"xref") {
            lx.pos += 4;
            lx.refs = false;
            let mut entries: Vec<(u32, XEntry)> = Vec::new();
            loop {
                lx.skip_ws();
                if data[lx.pos..].starts_with(b"trailer") {
                    lx.pos += 7;
                    break;
                }
                let start = match lx.object()? {
                    Object::Int(i) => i as u32,
                    _ => return Err(Error::parse("bad xref subsection")),
                };
                let count = match lx.object()? {
                    Object::Int(i) => i as u32,
                    _ => return Err(Error::parse("bad xref subsection")),
                };
                for i in 0..count {
                    let o = lx.object()?.as_i64().ok_or_else(|| Error::parse("xref off"))?;
                    let g = lx.object()?.as_i64().ok_or_else(|| Error::parse("xref gen"))?;
                    let Value::Kw(k) = lx.next()? else { return Err(Error::parse("xref kw")) };
                    let e = if k == "n" { XEntry::Offset { off: o as u64, gen: g as u16 } } else { XEntry::Free };
                    entries.push((start + i, e));
                }
            }
            lx.refs = true;
            let trailer = match lx.object()? {
                Object::Dict(d) => d,
                _ => return Err(Error::parse("bad trailer")),
            };
            for (n, e) in entries {
                self.xref.entry(n).or_insert(e);
            }
            if first {
                self.xref_is_stream = false;
            }
            let stm = trailer.get("XRefStm").and_then(|o| o.as_i64()).filter(|&v| v > 0).map(|v| v as u64);
            Ok((trailer, stm))
        } else {
            drop(data);
            let (_, obj, stream_start) = self.parse_indirect_at(off)?;
            let _ = stream_start;
            let Object::Stream(s) = obj else { return Err(Error::parse("xref stream expected")) };
            let dec = self.decode(&s)?;
            let d = &s.dict;
            let w: Vec<usize> = d.get("W").and_then(|o| o.as_array()).map(|a| a.iter().map(|x| x.as_i64().unwrap_or(0) as usize).collect()).unwrap_or_default();
            if w.len() < 3 {
                return Err(Error::parse("bad /W"));
            }
            let size = d.get("Size").and_then(|o| o.as_i64()).unwrap_or(0);
            let index: Vec<i64> = d.get("Index").and_then(|o| o.as_array()).map(|a| a.iter().filter_map(|x| x.as_i64()).collect()).unwrap_or_else(|| vec![0, size]);
            let rec = w[0] + w[1] + w[2];
            let mut p = 0usize;
            let field = |b: &[u8]| b.iter().fold(0u64, |a, &x| (a << 8) | x as u64);
            for pair in index.chunks(2) {
                if pair.len() < 2 {
                    break;
                }
                for i in 0..pair[1] {
                    if p + rec > dec.data.len() {
                        break;
                    }
                    let r = &dec.data[p..p + rec];
                    p += rec;
                    let t = if w[0] == 0 { 1 } else { field(&r[..w[0]]) };
                    let f2 = field(&r[w[0]..w[0] + w[1]]);
                    let f3 = field(&r[w[0] + w[1]..]);
                    let e = match t {
                        0 => XEntry::Free,
                        1 => XEntry::Offset { off: f2, gen: f3 as u16 },
                        2 => XEntry::InStream { stm: f2 as u32, idx: f3 as u32 },
                        _ => continue,
                    };
                    self.xref.entry((pair[0] + i) as u32).or_insert(e);
                }
            }
            if first {
                self.xref_is_stream = true;
            }
            let prev_trailer = s.dict.clone();
            Ok((prev_trailer, None))
        }
    }

    /// Rebuild the xref by scanning the whole file for `N G obj` (damaged PDFs).
    fn reconstruct(&mut self) -> Result<()> {
        let len = self.src.len();
        let data = self.src.read(0, len).into_owned();
        let mut i = 0;
        while let Some(pos) = find(&data, b"obj", i) {
            i = pos + 3;
            if pos >= 3 && &data[pos - 3..pos] == b"end" {
                continue;
            }
            if data.get(pos + 3).map_or(false, |&c| is_regular(c)) {
                continue;
            }
            // walk back: ws gen ws num
            let mut j = pos;
            while j > 0 && is_ws(data[j - 1]) {
                j -= 1;
            }
            let ge = j;
            while j > 0 && data[j - 1].is_ascii_digit() {
                j -= 1;
            }
            if j == ge {
                continue;
            }
            let gs = j;
            while j > 0 && is_ws(data[j - 1]) {
                j -= 1;
            }
            if j == gs {
                continue;
            }
            let ne = j;
            while j > 0 && data[j - 1].is_ascii_digit() {
                j -= 1;
            }
            if j == ne {
                continue;
            }
            let num: u32 = std::str::from_utf8(&data[j..ne]).unwrap().parse().unwrap_or(0);
            let gen: u16 = std::str::from_utf8(&data[gs..ge]).unwrap().parse().unwrap_or(0);
            self.xref.insert(num, XEntry::Offset { off: j as u64, gen });
        }
        // trailers
        let mut t = 0;
        while let Some(pos) = find(&data, b"trailer", t) {
            t = pos + 7;
            let mut lx = Lexer::new(&data, pos + 7);
            if let Ok(Object::Dict(d)) = lx.object() {
                for (k, v) in d {
                    self.trailer.insert(k, v);
                }
            }
        }
        // object streams / xref streams / catalog discovery
        let nums: Vec<u32> = self.xref.keys().copied().collect();
        let mut found_root: Option<ObjId> = None;
        let mut stm_nums = Vec::new();
        for n in &nums {
            let o = self.get(*n);
            if let Some(d) = o.as_dict() {
                match d.get("Type").and_then(|t| t.as_name()) {
                    Some("ObjStm") => stm_nums.push(*n),
                    Some("XRef") => {
                        for (k, v) in d {
                            if matches!(k.as_str(), "Root" | "Info" | "ID" | "Encrypt") {
                                self.trailer.insert(k.clone(), v.clone());
                            }
                        }
                    }
                    Some("Catalog") => found_root = Some((*n, 0)),
                    _ => {}
                }
            }
        }
        for sn in stm_nums {
            if let Ok(stm) = self.load_objstm(sn) {
                for (idx, (num, _)) in stm.entries.iter().enumerate() {
                    self.xref.entry(*num).or_insert(XEntry::InStream { stm: sn, idx: idx as u32 });
                    if found_root.is_none() {
                        let o = self.get(*num);
                        if o.as_dict().and_then(|d| d.get("Type")).and_then(|t| t.as_name()) == Some("Catalog") {
                            found_root = Some((*num, 0));
                        }
                    }
                }
            }
        }
        let root_ok = self.trailer.get("Root").map_or(false, |r| self.resolve(r).as_dict().map_or(false, |d| d.contains_key("Pages")));
        if !root_ok {
            if let Some(r) = found_root {
                self.trailer.insert("Root".into(), Object::Ref(r));
            }
        }
        if self.trailer.is_empty() {
            return Err(Error::parse("unrecoverable document"));
        }
        self.cache.lock().unwrap().clear();
        Ok(())
    }

    // --------------------------------------------------------------- objects
    pub fn resolve(&self, o: &Object) -> Arc<Object> {
        match o {
            Object::Ref((n, _)) => self.get(*n),
            other => Arc::new(other.clone()),
        }
    }

    /// Fetch an object by number (overlay → cache → file). Errors become `Null`.
    pub fn get(&self, num: u32) -> Arc<Object> {
        if let Some(o) = self.overlay.read().unwrap().objects.get(&num) {
            return o.clone();
        }
        if let Some(o) = self.cache.lock().unwrap().get(&num) {
            return o.clone();
        }
        let obj = self.load(num).unwrap_or(Object::Null);
        let a = Arc::new(obj);
        let mut c = self.cache.lock().unwrap();
        if c.len() > 40_000 {
            c.clear();
        }
        c.insert(num, a.clone());
        a
    }

    pub fn generation(&self, num: u32) -> u16 {
        match self.xref.get(&num) {
            Some(XEntry::Offset { gen, .. }) => *gen,
            _ => 0,
        }
    }

    fn load(&self, num: u32) -> Result<Object> {
        match *self.xref.get(&num).ok_or_else(|| Error::Missing(format!("object {num}")))? {
            XEntry::Free => Ok(Object::Null),
            XEntry::Offset { off, .. } => {
                let (id, obj, _) = self.parse_indirect_at(off)?;
                if id.0 != num {
                    return Err(Error::parse("object number mismatch"));
                }
                Ok(obj)
            }
            XEntry::InStream { stm, idx } => {
                let s = self.load_objstm(stm)?;
                let slot = match s.entries.get(idx as usize) {
                    Some((n, _)) if *n == num => idx as usize,
                    _ => s.entries.iter().position(|(n, _)| *n == num).ok_or_else(|| Error::Missing("objstm entry".into()))?,
                };
                let mut lx = Lexer::new(&s.data, s.entries[slot].1);
                lx.object()
            }
        }
    }

    fn load_objstm(&self, stm: u32) -> Result<Arc<ObjStm>> {
        if let Some(s) = self.objstms.lock().unwrap().get(&stm) {
            return Ok(s.clone());
        }
        let o = self.get(stm);
        let s = o.as_stream().ok_or_else(|| Error::parse("object stream missing"))?;
        let dec = self.decode(s)?;
        let n = s.dict.get("N").and_then(|o| o.as_i64()).unwrap_or(0) as usize;
        let first = s.dict.get("First").and_then(|o| o.as_i64()).unwrap_or(0) as usize;
        let mut lx = Lexer::new(&dec.data, 0);
        lx.refs = false;
        let mut entries = Vec::with_capacity(n);
        for _ in 0..n {
            let num = lx.object()?.as_i64().ok_or_else(|| Error::parse("objstm num"))?;
            let off = lx.object()?.as_i64().ok_or_else(|| Error::parse("objstm off"))?;
            entries.push((num as u32, first + off as usize));
        }
        let arc = Arc::new(ObjStm { data: dec.data, entries });
        let mut m = self.objstms.lock().unwrap();
        if m.len() > 64 {
            m.clear();
        }
        m.insert(stm, arc.clone());
        Ok(arc)
    }

    /// Parse `N G obj … endobj` at an absolute file offset, growing the read
    /// window as needed (so a 20-byte dictionary never touches the whole file).
    fn parse_indirect_at(&self, off: u64) -> Result<(ObjId, Object, Option<u64>)> {
        let total = self.src.len();
        if off >= total {
            return Err(Error::parse("offset past EOF"));
        }
        let mut win: u64 = 4096;
        loop {
            let end = (off + win).min(total);
            let buf = self.src.read(off, end);
            let complete = end >= total;
            match self.try_parse(&buf, off, complete) {
                Ok(v) => return Ok(v),
                Err(Error::Eof) if !complete => win *= 8,
                Err(e) => return Err(e),
            }
        }
    }

    fn try_parse(&self, buf: &[u8], base: u64, complete: bool) -> Result<(ObjId, Object, Option<u64>)> {
        let mut lx = Lexer::new(buf, 0);
        lx.refs = false;
        let num = lx.object()?.as_i64().ok_or_else(|| Error::parse("obj num"))?;
        let gen = lx.object()?.as_i64().ok_or_else(|| Error::parse("obj gen"))?;
        match lx.next()? {
            Value::Kw(k) if k == "obj" => {}
            _ => return Err(Error::parse("expected `obj`")),
        }
        lx.refs = true;
        let obj = lx.object()?;
        let id = (num as u32, gen as u16);
        if let Object::Dict(d) = obj {
            let save = lx.pos;
            match lx.next() {
                Ok(Value::Kw(k)) if k == "stream" => {
                    let mut p = lx.pos;
                    if buf.get(p) == Some(&b'\r') {
                        p += 1;
                        if buf.get(p) == Some(&b'\n') {
                            p += 1;
                        }
                    } else if buf.get(p) == Some(&b'\n') {
                        p += 1;
                    }
                    let start = base + p as u64;
                    let len = self.stream_len(&d, start);
                    let st = Stream { dict: d, data: StreamData::Source { offset: start, len } };
                    return Ok((id, Object::Stream(Box::new(st)), Some(start)));
                }
                Err(Error::Eof) if !complete => return Err(Error::Eof),
                _ => {}
            }
            let _ = save;
            return Ok((id, Object::Dict(d), None));
        }
        Ok((id, obj, None))
    }

    fn stream_len(&self, d: &Dict, start: u64) -> u64 {
        let total = self.src.len();
        let declared = match d.get("Length") {
            Some(Object::Int(n)) => Some(*n),
            Some(Object::Ref((n, _))) => self.get(*n).as_i64(),
            _ => None,
        };
        if let Some(n) = declared {
            if n >= 0 && start + n as u64 <= total {
                let tail = self.src.read(start + n as u64, (start + n as u64 + 32).min(total));
                let t: &[u8] = &tail;
                let skip = t.iter().take_while(|&&c| is_ws(c)).count();
                if t[skip..].starts_with(b"endstream") {
                    return n as u64;
                }
            }
        }
        // Fallback: scan for `endstream`.
        let mut pos = start;
        while pos < total {
            let end = (pos + (1 << 20)).min(total);
            let chunk = self.src.read(pos, (end + 9).min(total));
            if let Some(i) = find(&chunk, b"endstream", 0) {
                let mut e = pos + i as u64;
                // strip one EOL
                let back = self.src.read(e.saturating_sub(2).max(start), e);
                if back.ends_with(b"\r\n") {
                    e -= 2;
                } else if back.ends_with(b"\n") || back.ends_with(b"\r") {
                    e -= 1;
                }
                return e.saturating_sub(start);
            }
            pos = end;
        }
        total.saturating_sub(start)
    }

    // --------------------------------------------------------------- streams
    pub fn stream_raw<'a>(&'a self, s: &'a Stream) -> Cow<'a, [u8]> {
        match &s.data {
            StreamData::Source { offset, len } => self.src.read(*offset, *offset + *len),
            StreamData::Mem(m) => Cow::Borrowed(m.as_slice()),
        }
    }

    pub fn decode(&self, s: &Stream) -> Result<Decoded> {
        let filters_obj = s.dict.get("Filter").map(|o| self.resolve(o));
        let names: Vec<String> = match filters_obj.as_deref() {
            Some(Object::Name(n)) => vec![n.clone()],
            Some(Object::Array(a)) => a.iter().filter_map(|o| self.resolve(o).as_name().map(|s| s.to_string())).collect(),
            _ => vec![],
        };
        let parms_obj = s.dict.get("DecodeParms").or_else(|| s.dict.get("DP")).map(|o| self.resolve(o));
        let parms: Vec<Option<Dict>> = match parms_obj.as_deref() {
            Some(Object::Dict(d)) => vec![Some(d.clone())],
            Some(Object::Array(a)) => a.iter().map(|o| self.resolve(o).as_dict().cloned()).collect(),
            _ => vec![],
        };
        let mut cur: Cow<[u8]> = self.stream_raw(s);
        for (i, name) in names.iter().enumerate() {
            let p = parms.get(i).cloned().flatten();
            let geti = |k: &str, d: i64| p.as_ref().and_then(|p| p.get(k)).map(|o| self.resolve(o)).and_then(|o| o.as_i64()).unwrap_or(d);
            match name.as_str() {
                "FlateDecode" | "Fl" => {
                    let out = filters::flate(&cur);
                    let out = filters::predictor(out, geti("Predictor", 1), geti("Colors", 1) as usize, geti("BitsPerComponent", 8) as usize, geti("Columns", 1) as usize);
                    cur = Cow::Owned(out);
                }
                "LZWDecode" | "LZW" => {
                    let out = filters::lzw(&cur, geti("EarlyChange", 1) != 0);
                    let out = filters::predictor(out, geti("Predictor", 1), geti("Colors", 1) as usize, geti("BitsPerComponent", 8) as usize, geti("Columns", 1) as usize);
                    cur = Cow::Owned(out);
                }
                "ASCII85Decode" | "A85" => cur = Cow::Owned(filters::ascii85(&cur)),
                "ASCIIHexDecode" | "AHx" => cur = Cow::Owned(filters::ascii_hex(&cur)),
                "RunLengthDecode" | "RL" => cur = Cow::Owned(filters::run_length(&cur)),
                "Crypt" => {}
                "DCTDecode" | "DCT" | "JPXDecode" | "CCITTFaxDecode" | "CCF" | "JBIG2Decode" => {
                    let canon = match name.as_str() {
                        "DCT" => "DCTDecode",
                        "CCF" => "CCITTFaxDecode",
                        n => n,
                    };
                    return Ok(Decoded { data: cur.into_owned(), image_filter: Some(canon.to_string()), parms: p });
                }
                other => return Err(Error::Unsupported(format!("filter {other}"))),
            }
        }
        Ok(Decoded { data: cur.into_owned(), image_filter: None, parms: None })
    }

    pub fn decode_object(&self, o: &Object) -> Result<Vec<u8>> {
        match o {
            Object::Stream(s) => Ok(self.decode(s)?.data),
            _ => Err(Error::parse("not a stream")),
        }
    }

    // ---------------------------------------------------------------- helpers
    pub fn catalog(&self) -> Result<Dict> {
        let r = self.trailer.get("Root").ok_or_else(|| Error::Missing("Root".into()))?;
        self.resolve(r).as_dict().cloned().ok_or_else(|| Error::parse("Root is not a dictionary"))
    }

    pub fn dget(&self, d: &Dict, k: &str) -> Option<Arc<Object>> {
        d.get(k).map(|o| self.resolve(o)).filter(|o| !o.is_null())
    }
    pub fn dget_f64(&self, d: &Dict, k: &str) -> Option<f64> {
        self.dget(d, k).and_then(|o| o.as_f64())
    }
    pub fn dget_i64(&self, d: &Dict, k: &str) -> Option<i64> {
        self.dget(d, k).and_then(|o| o.as_i64())
    }
    pub fn dget_name(&self, d: &Dict, k: &str) -> Option<String> {
        self.dget(d, k).and_then(|o| o.as_name().map(|s| s.to_string()))
    }
    pub fn dget_dict(&self, d: &Dict, k: &str) -> Option<Dict> {
        self.dget(d, k).and_then(|o| o.as_dict().cloned())
    }
    pub fn dget_array(&self, d: &Dict, k: &str) -> Option<Vec<Object>> {
        self.dget(d, k).and_then(|o| o.as_array().cloned())
    }
    pub fn dget_nums(&self, d: &Dict, k: &str) -> Option<Vec<f64>> {
        self.dget_array(d, k).map(|a| a.iter().filter_map(|o| self.resolve(o).as_f64()).collect())
    }
    pub fn dget_text(&self, d: &Dict, k: &str) -> Option<String> {
        self.dget(d, k).and_then(|o| o.as_str().map(text_string))
    }

    // ------------------------------------------------------------------ pages
    pub fn pages(&self) -> Arc<Vec<ObjId>> {
        if let Some(p) = self.pages_cache.read().unwrap().as_ref() {
            return p.clone();
        }
        let mut out = Vec::new();
        if let Ok(cat) = self.catalog() {
            if let Some(root) = cat.get("Pages") {
                let mut seen = HashSet::new();
                self.collect_pages(root, &mut out, 0, &mut seen);
            }
        }
        let a = Arc::new(out);
        *self.pages_cache.write().unwrap() = Some(a.clone());
        a
    }

    fn collect_pages(&self, o: &Object, out: &mut Vec<ObjId>, depth: u32, seen: &mut HashSet<u32>) {
        if depth > 64 {
            return;
        }
        if let Object::Ref(id) = o {
            if !seen.insert(id.0) {
                return;
            }
            let n = self.get(id.0);
            if let Some(d) = n.as_dict() {
                if let Some(kids) = self.dget_array(d, "Kids") {
                    for k in &kids {
                        self.collect_pages(k, out, depth + 1, seen);
                    }
                } else {
                    out.push(*id);
                }
            }
        }
    }

    pub fn page_count(&self) -> usize {
        self.pages().len()
    }

    /// Page dictionary with inheritable attributes merged in.
    pub fn page_dict(&self, id: ObjId) -> Dict {
        let mut d = self.get(id.0).as_dict().cloned().unwrap_or_default();
        let mut cur = d.get("Parent").cloned();
        let mut n = 0;
        while let Some(Object::Ref(pid)) = cur {
            n += 1;
            if n > 64 {
                break;
            }
            let p = self.get(pid.0);
            match p.as_dict() {
                Some(pd) => {
                    for k in ["Resources", "MediaBox", "CropBox", "Rotate"] {
                        if !d.contains_key(k) {
                            if let Some(v) = pd.get(k) {
                                d.insert(k.to_string(), v.clone());
                            }
                        }
                    }
                    cur = pd.get("Parent").cloned();
                }
                None => break,
            }
        }
        d
    }

    // ---------------------------------------------------------------- overlay
    pub fn revision(&self) -> u64 {
        self.overlay.read().unwrap().revision
    }

    pub fn set_object(&self, num: u32, obj: Object) {
        let mut o = self.overlay.write().unwrap();
        o.objects.insert(num, Arc::new(obj));
        o.revision += 1;
        drop(o);
        *self.pages_cache.write().unwrap() = None;
    }

    pub fn new_object(&self, obj: Object) -> ObjId {
        let mut o = self.overlay.write().unwrap();
        let n = o.next_num;
        o.next_num += 1;
        o.objects.insert(n, Arc::new(obj));
        o.revision += 1;
        drop(o);
        *self.pages_cache.write().unwrap() = None;
        (n, 0)
    }

    pub fn reserve_object(&self) -> ObjId {
        let mut o = self.overlay.write().unwrap();
        let n = o.next_num;
        o.next_num += 1;
        (n, 0)
    }

    pub fn snapshot(&self) -> Overlay {
        self.overlay.read().unwrap().clone()
    }

    pub fn restore(&self, snap: Overlay) {
        let mut o = self.overlay.write().unwrap();
        let rev = o.revision + 1;
        *o = snap;
        o.revision = rev;
        drop(o);
        *self.pages_cache.write().unwrap() = None;
    }

    pub fn has_changes(&self) -> bool {
        !self.overlay.read().unwrap().objects.is_empty()
    }
}

pub(crate) fn find(hay: &[u8], needle: &[u8], from: usize) -> Option<usize> {
    if from >= hay.len() || needle.is_empty() {
        return None;
    }
    hay[from..].windows(needle.len()).position(|w| w == needle).map(|p| p + from)
}
