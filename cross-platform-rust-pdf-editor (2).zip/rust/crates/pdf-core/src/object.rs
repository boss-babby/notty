use std::collections::BTreeMap;
use std::sync::Arc;

pub type ObjId = (u32, u16);
pub type Dict = BTreeMap<String, Object>;

/// Where a stream's *encoded* bytes live.
#[derive(Clone, Debug, PartialEq)]
pub enum StreamData {
    /// Byte range inside the (mmap'd / chunked) source file – zero copy.
    Source { offset: u64, len: u64 },
    /// In-memory bytes (newly created or edited streams).
    Mem(Arc<Vec<u8>>),
}

#[derive(Clone, Debug, PartialEq)]
pub struct Stream {
    pub dict: Dict,
    pub data: StreamData,
}

#[derive(Clone, Debug, PartialEq)]
pub enum Object {
    Null,
    Bool(bool),
    Int(i64),
    Real(f64),
    Str(Vec<u8>),
    Name(String),
    Array(Vec<Object>),
    Dict(Dict),
    Stream(Box<Stream>),
    Ref(ObjId),
}

impl Object {
    pub fn name(s: &str) -> Object {
        Object::Name(s.to_string())
    }
    pub fn string(s: &str) -> Object {
        Object::Str(s.as_bytes().to_vec())
    }
    pub fn real(v: f64) -> Object {
        Object::Real(v)
    }
    pub fn is_null(&self) -> bool {
        matches!(self, Object::Null)
    }
    pub fn as_i64(&self) -> Option<i64> {
        match self {
            Object::Int(i) => Some(*i),
            Object::Real(f) => Some(*f as i64),
            _ => None,
        }
    }
    pub fn as_f64(&self) -> Option<f64> {
        match self {
            Object::Int(i) => Some(*i as f64),
            Object::Real(f) => Some(*f),
            _ => None,
        }
    }
    pub fn as_bool(&self) -> Option<bool> {
        match self {
            Object::Bool(b) => Some(*b),
            _ => None,
        }
    }
    pub fn as_name(&self) -> Option<&str> {
        match self {
            Object::Name(n) => Some(n),
            _ => None,
        }
    }
    pub fn as_str(&self) -> Option<&[u8]> {
        match self {
            Object::Str(s) => Some(s),
            _ => None,
        }
    }
    pub fn as_array(&self) -> Option<&Vec<Object>> {
        match self {
            Object::Array(a) => Some(a),
            _ => None,
        }
    }
    /// Dictionary of a dict *or* of a stream.
    pub fn as_dict(&self) -> Option<&Dict> {
        match self {
            Object::Dict(d) => Some(d),
            Object::Stream(s) => Some(&s.dict),
            _ => None,
        }
    }
    pub fn as_stream(&self) -> Option<&Stream> {
        match self {
            Object::Stream(s) => Some(s),
            _ => None,
        }
    }
    pub fn as_ref_id(&self) -> Option<ObjId> {
        match self {
            Object::Ref(r) => Some(*r),
            _ => None,
        }
    }
}

impl From<f64> for Object {
    fn from(v: f64) -> Self {
        Object::Real(v)
    }
}
impl From<i64> for Object {
    fn from(v: i64) -> Self {
        Object::Int(v)
    }
}

/// Build a dictionary from `(key, value)` pairs.
pub fn dict(pairs: Vec<(&str, Object)>) -> Dict {
    pairs.into_iter().map(|(k, v)| (k.to_string(), v)).collect()
}

pub fn rect_array(r: [f64; 4]) -> Object {
    Object::Array(r.iter().map(|v| Object::Real(*v)).collect())
}

/// Decode a PDF text string (PDFDocEncoding-ish / UTF-16BE) to a Rust string.
pub fn text_string(b: &[u8]) -> String {
    if b.len() >= 2 && b[0] == 0xFE && b[1] == 0xFF {
        let u: Vec<u16> = b[2..].chunks(2).filter(|c| c.len() == 2).map(|c| u16::from_be_bytes([c[0], c[1]])).collect();
        String::from_utf16_lossy(&u)
    } else if b.len() >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF {
        String::from_utf8_lossy(&b[3..]).into_owned()
    } else {
        b.iter().map(|&c| c as char).collect()
    }
}

/// Encode a Rust string as a PDF text string (Latin-1 if possible else UTF-16BE).
pub fn encode_text_string(s: &str) -> Vec<u8> {
    if s.chars().all(|c| (c as u32) < 256) {
        s.chars().map(|c| c as u8).collect()
    } else {
        let mut v = vec![0xFE, 0xFF];
        for u in s.encode_utf16() {
            v.extend_from_slice(&u.to_be_bytes());
        }
        v
    }
}
