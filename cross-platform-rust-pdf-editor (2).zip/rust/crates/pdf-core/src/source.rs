//! Byte sources: memory-mapped files (native), in-memory buffers, and a
//! chunk-fetching source for streaming over HTTP `Range` / JS `Blob.slice`.

use std::borrow::Cow;
use std::collections::{HashMap, VecDeque};
use std::sync::Mutex;

pub trait ByteSource: Send + Sync {
    fn len(&self) -> u64;
    /// Read `[start, end)` (clamped to the file). Memory-backed sources return
    /// a borrowed slice (zero copy).
    fn read(&self, start: u64, end: u64) -> Cow<'_, [u8]>;
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

pub struct VecSource(pub Vec<u8>);

impl ByteSource for VecSource {
    fn len(&self) -> u64 {
        self.0.len() as u64
    }
    fn read(&self, start: u64, end: u64) -> Cow<'_, [u8]> {
        let e = (end as usize).min(self.0.len());
        let s = (start as usize).min(e);
        Cow::Borrowed(&self.0[s..e])
    }
}

#[cfg(not(target_arch = "wasm32"))]
pub struct MmapSource(memmap2::Mmap);

#[cfg(not(target_arch = "wasm32"))]
impl MmapSource {
    pub fn open(path: &std::path::Path) -> std::io::Result<Self> {
        let f = std::fs::File::open(path)?;
        // SAFETY: the map is read-only; concurrent truncation by another
        // process is the usual (accepted) mmap caveat.
        let m = unsafe { memmap2::Mmap::map(&f)? };
        Ok(MmapSource(m))
    }
}

#[cfg(not(target_arch = "wasm32"))]
impl ByteSource for MmapSource {
    fn len(&self) -> u64 {
        self.0.len() as u64
    }
    fn read(&self, start: u64, end: u64) -> Cow<'_, [u8]> {
        let e = (end as usize).min(self.0.len());
        let s = (start as usize).min(e);
        Cow::Borrowed(&self.0[s..e])
    }
}

/// Fetches fixed-size chunks on demand through a user callback
/// (`Range: bytes=a-b` on the web, `File.slice` in a worker, …) and keeps a
/// small LRU of chunks resident.
pub struct ChunkedSource {
    total: u64,
    chunk: u64,
    max_chunks: usize,
    fetch: Box<dyn Fn(u64, usize) -> Vec<u8> + Send + Sync>,
    cache: Mutex<(HashMap<u64, std::sync::Arc<Vec<u8>>>, VecDeque<u64>)>,
}

impl ChunkedSource {
    pub fn new(total: u64, chunk: usize, max_chunks: usize, fetch: Box<dyn Fn(u64, usize) -> Vec<u8> + Send + Sync>) -> Self {
        ChunkedSource { total, chunk: chunk as u64, max_chunks: max_chunks.max(2), fetch, cache: Mutex::new((HashMap::new(), VecDeque::new())) }
    }
    fn chunk_at(&self, idx: u64) -> std::sync::Arc<Vec<u8>> {
        let mut g = self.cache.lock().unwrap();
        if let Some(c) = g.0.get(&idx) {
            let c = c.clone();
            g.1.retain(|&i| i != idx);
            g.1.push_back(idx);
            return c;
        }
        drop(g);
        let start = idx * self.chunk;
        let want = (self.chunk.min(self.total.saturating_sub(start))) as usize;
        let data = std::sync::Arc::new((self.fetch)(start, want));
        let mut g = self.cache.lock().unwrap();
        g.0.insert(idx, data.clone());
        g.1.push_back(idx);
        while g.1.len() > self.max_chunks {
            if let Some(old) = g.1.pop_front() {
                g.0.remove(&old);
            }
        }
        data
    }
}

impl ByteSource for ChunkedSource {
    fn len(&self) -> u64 {
        self.total
    }
    fn read(&self, start: u64, end: u64) -> Cow<'_, [u8]> {
        let end = end.min(self.total);
        if start >= end {
            return Cow::Borrowed(&[]);
        }
        let mut out = Vec::with_capacity((end - start) as usize);
        let mut pos = start;
        while pos < end {
            let idx = pos / self.chunk;
            let c = self.chunk_at(idx);
            let off = (pos - idx * self.chunk) as usize;
            let take = ((end - pos) as usize).min(c.len().saturating_sub(off));
            if take == 0 {
                break;
            }
            out.extend_from_slice(&c[off..off + take]);
            pos += take as u64;
        }
        Cow::Owned(out)
    }
}
