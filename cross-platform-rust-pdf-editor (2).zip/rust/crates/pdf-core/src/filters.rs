//! Pure-Rust stream filters: Flate (miniz_oxide), LZW, ASCII85, ASCIIHex,
//! RunLength and the PNG/TIFF predictors.

pub fn flate(data: &[u8]) -> Vec<u8> {
    match miniz_oxide::inflate::decompress_to_vec_zlib(data) {
        Ok(v) => v,
        Err(e) => {
            if !e.output.is_empty() {
                return e.output;
            }
            // Missing / corrupt zlib header: try raw deflate.
            let skip = if data.len() > 2 { 2 } else { 0 };
            match miniz_oxide::inflate::decompress_to_vec(&data[skip..]) {
                Ok(v) => v,
                Err(e2) => e2.output,
            }
        }
    }
}

pub fn deflate(data: &[u8]) -> Vec<u8> {
    miniz_oxide::deflate::compress_to_vec_zlib(data, 6)
}

pub fn ascii_hex(data: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut hi: Option<u8> = None;
    for &b in data {
        if b == b'>' {
            break;
        }
        let v = match b {
            b'0'..=b'9' => b - b'0',
            b'a'..=b'f' => b - b'a' + 10,
            b'A'..=b'F' => b - b'A' + 10,
            _ => continue,
        };
        match hi.take() {
            Some(h) => out.push(h << 4 | v),
            None => hi = Some(v),
        }
    }
    if let Some(h) = hi {
        out.push(h << 4);
    }
    out
}

pub fn ascii85(data: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut group = [0u32; 5];
    let mut n = 0;
    let mut i = 0;
    while i < data.len() {
        let b = data[i];
        i += 1;
        match b {
            b'~' => break,
            b'z' if n == 0 => out.extend_from_slice(&[0, 0, 0, 0]),
            b'!'..=b'u' => {
                group[n] = (b - b'!') as u32;
                n += 1;
                if n == 5 {
                    let v = group.iter().fold(0u32, |a, &d| a.wrapping_mul(85).wrapping_add(d));
                    out.extend_from_slice(&v.to_be_bytes());
                    n = 0;
                }
            }
            _ => {}
        }
    }
    if n > 1 {
        for g in group.iter_mut().skip(n) {
            *g = 84;
        }
        let v = group.iter().fold(0u32, |a, &d| a.wrapping_mul(85).wrapping_add(d));
        out.extend_from_slice(&v.to_be_bytes()[..n - 1]);
    }
    out
}

pub fn run_length(data: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < data.len() {
        let l = data[i] as usize;
        i += 1;
        if l == 128 {
            break;
        } else if l < 128 {
            let e = (i + l + 1).min(data.len());
            out.extend_from_slice(&data[i..e]);
            i = e;
        } else if i < data.len() {
            out.extend(std::iter::repeat(data[i]).take(257 - l));
            i += 1;
        }
    }
    out
}

pub fn lzw(data: &[u8], early_change: bool) -> Vec<u8> {
    let mut out: Vec<u8> = Vec::new();
    let mut table: Vec<Vec<u8>> = Vec::new();
    let reset = |t: &mut Vec<Vec<u8>>| {
        t.clear();
        for i in 0..256u16 {
            t.push(vec![i as u8]);
        }
        t.push(Vec::new()); // 256 clear
        t.push(Vec::new()); // 257 eod
    };
    reset(&mut table);
    let (mut bits, mut nbits, mut width) = (0u32, 0u32, 9u32);
    let mut prev: Option<Vec<u8>> = None;
    let mut pos = 0;
    loop {
        while nbits < width {
            if pos >= data.len() {
                return out;
            }
            bits = (bits << 8) | data[pos] as u32;
            pos += 1;
            nbits += 8;
        }
        let code = ((bits >> (nbits - width)) & ((1 << width) - 1)) as usize;
        nbits -= width;
        if code == 256 {
            reset(&mut table);
            width = 9;
            prev = None;
            continue;
        }
        if code == 257 {
            return out;
        }
        let entry = if code < table.len() {
            table[code].clone()
        } else if let Some(p) = &prev {
            let mut e = p.clone();
            e.push(p[0]);
            e
        } else {
            return out;
        };
        out.extend_from_slice(&entry);
        if let Some(p) = prev {
            let mut n = p;
            n.push(entry[0]);
            table.push(n);
        }
        prev = Some(entry);
        let sz = table.len() + if early_change { 1 } else { 0 };
        width = if sz >= 2048 {
            12
        } else if sz >= 1024 {
            11
        } else if sz >= 512 {
            10
        } else {
            9
        };
    }
}

pub fn predictor(data: Vec<u8>, pred: i64, colors: usize, bpc: usize, columns: usize) -> Vec<u8> {
    if pred < 2 {
        return data;
    }
    let bpp = ((colors * bpc + 7) / 8).max(1);
    let row = (colors * bpc * columns + 7) / 8;
    if row == 0 {
        return data;
    }
    if pred == 2 {
        // TIFF predictor (8-bit only)
        if bpc != 8 {
            return data;
        }
        let mut out = data;
        for r in out.chunks_mut(row) {
            for i in bpp..r.len() {
                r[i] = r[i].wrapping_add(r[i - bpp]);
            }
        }
        return out;
    }
    let stride = row + 1;
    let rows = (data.len() + stride - 1) / stride;
    let mut out = vec![0u8; rows * row];
    for y in 0..rows {
        let s = y * stride;
        if s >= data.len() {
            break;
        }
        let ft = data[s];
        let src = &data[s + 1..(s + stride).min(data.len())];
        let (before, cur) = out.split_at_mut(y * row);
        let prev: Option<&[u8]> = if y > 0 { Some(&before[(y - 1) * row..]) } else { None };
        let cur = &mut cur[..row];
        for i in 0..src.len() {
            let a = if i >= bpp { cur[i - bpp] as i32 } else { 0 };
            let b = prev.map_or(0, |p| p[i] as i32);
            let c = if i >= bpp { prev.map_or(0, |p| p[i - bpp] as i32) } else { 0 };
            let x = src[i];
            cur[i] = match ft {
                0 => x,
                1 => x.wrapping_add(a as u8),
                2 => x.wrapping_add(b as u8),
                3 => x.wrapping_add(((a + b) / 2) as u8),
                4 => {
                    let p = a + b - c;
                    let (pa, pb, pc) = ((p - a).abs(), (p - b).abs(), (p - c).abs());
                    let pr = if pa <= pb && pa <= pc {
                        a
                    } else if pb <= pc {
                        b
                    } else {
                        c
                    };
                    x.wrapping_add(pr as u8)
                }
                _ => x,
            };
        }
    }
    out
}
