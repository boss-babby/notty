//! Serialisation: objects, incremental updates (append-only) and full rewrites.

use crate::doc::{Doc, XEntry};
use crate::error::{Error, Result};
use crate::filters;
use crate::object::*;
use std::collections::BTreeMap;
use std::io::Write;

pub fn fmt_real(v: f64) -> String {
    if !v.is_finite() {
        return "0".into();
    }
    if (v - v.round()).abs() < 1e-9 {
        return format!("{}", v.round() as i64);
    }
    let s = format!("{:.4}", v);
    let s = s.trim_end_matches('0').trim_end_matches('.');
    s.to_string()
}

pub fn write_name(n: &str, out: &mut Vec<u8>) {
    out.push(b'/');
    for c in n.chars() {
        let b = c as u32 as u8;
        if b.is_ascii_alphanumeric() || matches!(b, b'-' | b'_' | b'.' | b'+' | b'*' | b'@' | b'$' | b'!' | b'&' | b'\'' | b',' | b':' | b';' | b'=' | b'?' | b'^' | b'|' | b'~') {
            out.push(b);
        } else {
            out.extend_from_slice(format!("#{:02X}", b).as_bytes());
        }
    }
}

pub fn write_object(o: &Object, out: &mut Vec<u8>) {
    match o {
        Object::Null => out.extend_from_slice(b"null"),
        Object::Bool(b) => out.extend_from_slice(if *b { b"true" } else { b"false" }),
        Object::Int(i) => out.extend_from_slice(i.to_string().as_bytes()),
        Object::Real(f) => out.extend_from_slice(fmt_real(*f).as_bytes()),
        Object::Str(s) => {
            if s.iter().all(|&c| (32..127).contains(&c) && c != b'(' && c != b')' && c != b'\\') {
                out.push(b'(');
                out.extend_from_slice(s);
                out.push(b')');
            } else {
                out.push(b'<');
                for b in s {
                    out.extend_from_slice(format!("{:02X}", b).as_bytes());
                }
                out.push(b'>');
            }
        }
        Object::Name(n) => write_name(n, out),
        Object::Array(a) => {
            out.push(b'[');
            for (i, x) in a.iter().enumerate() {
                if i > 0 {
                    out.push(b' ');
                }
                write_object(x, out);
            }
            out.push(b']');
        }
        Object::Dict(d) => write_dict(d, out),
        Object::Stream(s) => write_dict(&s.dict, out),
        Object::Ref((n, g)) => out.extend_from_slice(format!("{} {} R", n, g).as_bytes()),
    }
}

pub fn write_dict(d: &Dict, out: &mut Vec<u8>) {
    out.extend_from_slice(b"<<");
    for (k, v) in d {
        write_name(k, out);
        out.push(b' ');
        write_object(v, out);
        out.push(b' ');
    }
    out.extend_from_slice(b">>");
}

/// Write `num gen obj … endobj`; stream payloads come from `raw`.
pub fn write_indirect(num: u32, gen: u16, o: &Object, raw: Option<&[u8]>, out: &mut Vec<u8>) {
    out.extend_from_slice(format!("{} {} obj\n", num, gen).as_bytes());
    match (o, raw) {
        (Object::Stream(s), Some(data)) => {
            let mut d = s.dict.clone();
            d.insert("Length".into(), Object::Int(data.len() as i64));
            write_dict(&d, out);
            out.extend_from_slice(b"\nstream\n");
            out.extend_from_slice(data);
            out.extend_from_slice(b"\nendstream");
        }
        _ => write_object(o, out),
    }
    out.extend_from_slice(b"\nendobj\n");
}

/// Create a stream object with Flate-compressed content.
pub fn flate_stream(mut dict: Dict, data: &[u8]) -> Object {
    let z = filters::deflate(data);
    dict.insert("Filter".into(), Object::name("FlateDecode"));
    dict.insert("Length".into(), Object::Int(z.len() as i64));
    Object::Stream(Box::new(Stream { dict, data: StreamData::Mem(std::sync::Arc::new(z)) }))
}

/// Create an uncompressed in-memory stream.
pub fn plain_stream(mut dict: Dict, data: Vec<u8>) -> Object {
    dict.insert("Length".into(), Object::Int(data.len() as i64));
    Object::Stream(Box::new(Stream { dict, data: StreamData::Mem(std::sync::Arc::new(data)) }))
}

impl Doc {
    fn object_bytes(&self, o: &Object) -> Option<Vec<u8>> {
        o.as_stream().map(|s| self.stream_raw(s).into_owned())
    }

    /// Append-only save: original bytes are copied verbatim (streamed in
    /// 1 MiB slices) followed by changed objects + a new xref section.
    pub fn save_incremental(&self, w: &mut dyn Write) -> Result<u64> {
        if self.reconstructed {
            return self.save_full(w);
        }
        let ov = self.overlay.read().unwrap().clone();
        let total = self.src.len();
        let mut pos = 0u64;
        while pos < total {
            let end = (pos + (1 << 20)).min(total);
            w.write_all(&self.src.read(pos, end)).map_err(|e| Error::parse(e.to_string()))?;
            pos = end;
        }
        if ov.objects.is_empty() {
            return Ok(total);
        }
        let mut tail: Vec<u8> = Vec::new();
        let last = self.src.read(total.saturating_sub(1), total);
        if last.as_ref() != b"\n" {
            tail.push(b'\n');
        }
        let mut nums: Vec<u32> = ov.objects.keys().copied().collect();
        nums.sort_unstable();
        let mut offsets: BTreeMap<u32, (u64, u16)> = BTreeMap::new();
        for n in &nums {
            let o = &ov.objects[n];
            offsets.insert(*n, (total + tail.len() as u64, self.generation(*n)));
            let raw = self.object_bytes(o);
            write_indirect(*n, self.generation(*n), o, raw.as_deref(), &mut tail);
        }
        let mut size = ov.next_num.max(self.size);
        let xref_pos = total + tail.len() as u64;
        let mut trailer = Dict::new();
        for k in ["Root", "Info", "ID"] {
            if let Some(v) = self.trailer.get(k) {
                trailer.insert(k.to_string(), v.clone());
            }
        }
        trailer.insert("Prev".into(), Object::Int(self.startxref as i64));
        if self.xref_is_stream {
            let xnum = size;
            size += 1;
            offsets.insert(xnum, (xref_pos, 0));
            let mut data = Vec::new();
            let mut index = Vec::new();
            let keys: Vec<u32> = offsets.keys().copied().collect();
            let mut i = 0;
            while i < keys.len() {
                let mut j = i;
                while j + 1 < keys.len() && keys[j + 1] == keys[j] + 1 {
                    j += 1;
                }
                index.push(Object::Int(keys[i] as i64));
                index.push(Object::Int((j - i + 1) as i64));
                for k in &keys[i..=j] {
                    let (off, gen) = offsets[k];
                    data.push(1u8);
                    data.extend_from_slice(&off.to_be_bytes());
                    data.extend_from_slice(&gen.to_be_bytes());
                }
                i = j + 1;
            }
            trailer.insert("Type".into(), Object::name("XRef"));
            trailer.insert("Size".into(), Object::Int(size as i64));
            trailer.insert("W".into(), Object::Array(vec![Object::Int(1), Object::Int(8), Object::Int(2)]));
            trailer.insert("Index".into(), Object::Array(index));
            let so = plain_stream(trailer, data.clone());
            write_indirect(xnum, 0, &so, Some(&data), &mut tail);
        } else {
            tail.extend_from_slice(b"xref\n");
            let keys: Vec<u32> = offsets.keys().copied().collect();
            let mut i = 0;
            while i < keys.len() {
                let mut j = i;
                while j + 1 < keys.len() && keys[j + 1] == keys[j] + 1 {
                    j += 1;
                }
                tail.extend_from_slice(format!("{} {}\n", keys[i], j - i + 1).as_bytes());
                for k in &keys[i..=j] {
                    let (off, gen) = offsets[k];
                    tail.extend_from_slice(format!("{:010} {:05} n \n", off, gen).as_bytes());
                }
                i = j + 1;
            }
            trailer.insert("Size".into(), Object::Int(size as i64));
            tail.extend_from_slice(b"trailer\n");
            write_dict(&trailer, &mut tail);
            tail.push(b'\n');
        }
        tail.extend_from_slice(format!("startxref\n{}\n%%EOF\n", xref_pos).as_bytes());
        w.write_all(&tail).map_err(|e| Error::parse(e.to_string()))?;
        Ok(total + tail.len() as u64)
    }

    /// Full rewrite of every reachable object (used for recovered files).
    pub fn save_full(&self, w: &mut dyn Write) -> Result<u64> {
        let mut b = PdfBuilder::new();
        let ov = self.overlay.read().unwrap().clone();
        let mut nums: Vec<u32> = self.xref.keys().copied().collect();
        nums.extend(ov.objects.keys().copied());
        nums.sort_unstable();
        nums.dedup();
        for n in nums {
            let o = self.get(n);
            if o.is_null() {
                continue;
            }
            // object streams / xref streams are expanded away
            if let Some(d) = o.as_dict() {
                if matches!(d.get("Type").and_then(|t| t.as_name()), Some("ObjStm") | Some("XRef")) {
                    continue;
                }
            }
            let raw = self.object_bytes(&o);
            b.add_with_raw(n, 0, &o, raw.as_deref());
        }
        let mut extra = Dict::new();
        if let Some(i) = self.trailer.get("Info") {
            extra.insert("Info".into(), i.clone());
        }
        let root = self.trailer.get("Root").and_then(|r| r.as_ref_id()).ok_or_else(|| Error::Missing("Root".into()))?;
        let bytes = b.finish(root, extra);
        w.write_all(&bytes).map_err(|e| Error::parse(e.to_string()))?;
        Ok(bytes.len() as u64)
    }
}

/// Minimal writer producing a complete PDF with a classic xref table.
pub struct PdfBuilder {
    pub buf: Vec<u8>,
    offsets: BTreeMap<u32, (u64, u16)>,
}

impl PdfBuilder {
    pub fn new() -> Self {
        PdfBuilder { buf: b"%PDF-1.7\n%\xE2\xE3\xCF\xD3\n".to_vec(), offsets: BTreeMap::new() }
    }
    pub fn add(&mut self, num: u32, o: &Object) {
        self.add_with_raw(num, 0, o, None)
    }
    pub fn add_with_raw(&mut self, num: u32, gen: u16, o: &Object, raw: Option<&[u8]>) {
        self.offsets.insert(num, (self.buf.len() as u64, gen));
        write_indirect(num, gen, o, raw, &mut self.buf);
    }
    pub fn finish(mut self, root: ObjId, extra_trailer: Dict) -> Vec<u8> {
        let max = self.offsets.keys().copied().max().unwrap_or(0);
        let xref_pos = self.buf.len();
        self.buf.extend_from_slice(format!("xref\n0 {}\n", max + 1).as_bytes());
        self.buf.extend_from_slice(b"0000000000 65535 f \n");
        for n in 1..=max {
            match self.offsets.get(&n) {
                Some((off, gen)) => self.buf.extend_from_slice(format!("{:010} {:05} n \n", off, gen).as_bytes()),
                None => self.buf.extend_from_slice(b"0000000000 00000 f \n"),
            }
        }
        let mut t = extra_trailer;
        t.insert("Size".into(), Object::Int(max as i64 + 1));
        t.insert("Root".into(), Object::Ref(root));
        self.buf.extend_from_slice(b"trailer\n");
        write_dict(&t, &mut self.buf);
        self.buf.extend_from_slice(format!("\nstartxref\n{}\n%%EOF\n", xref_pos).as_bytes());
        self.buf
    }
}

impl Default for PdfBuilder {
    fn default() -> Self {
        Self::new()
    }
}

#[allow(dead_code)]
fn _unused(_: XEntry) {}
