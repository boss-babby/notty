//! `pdf-core` – the zero-copy PDF object layer.
//!
//! * [`source`]  – mmap / in-memory / chunk-streamed byte sources
//! * [`lexer`]   – tokenizer + object parser
//! * [`doc`]     – lazy XRef (tables, streams, hybrid, reconstruction), object
//!                 streams, page tree, edit overlay
//! * [`write`]   – object serialiser, incremental updates, full rewrite
//! * [`content`] – content-stream operator list (parse ⇄ serialise)

pub mod content;
pub mod doc;
pub mod error;
pub mod filters;
pub mod lexer;
pub mod object;
pub mod source;
pub mod write;

pub use doc::{Decoded, Doc, Overlay};
pub use error::{Error, Result};
pub use object::*;
pub use source::{ByteSource, ChunkedSource, VecSource};
#[cfg(not(target_arch = "wasm32"))]
pub use source::MmapSource;

#[cfg(test)]
mod tests {
    use super::*;
    use write::PdfBuilder;

    pub fn tiny_pdf() -> Vec<u8> {
        let mut b = PdfBuilder::new();
        b.add(1, &Object::Dict(dict(vec![("Type", Object::name("Catalog")), ("Pages", Object::Ref((2, 0)))])));
        b.add(2, &Object::Dict(dict(vec![("Type", Object::name("Pages")), ("Kids", Object::Array(vec![Object::Ref((3, 0))])), ("Count", Object::Int(1))])));
        b.add(
            3,
            &Object::Dict(dict(vec![
                ("Type", Object::name("Page")),
                ("Parent", Object::Ref((2, 0))),
                ("MediaBox", rect_array([0.0, 0.0, 200.0, 100.0])),
            ])),
        );
        b.finish((1, 0), Dict::new())
    }

    #[test]
    fn opens_and_counts_pages() {
        let d = Doc::from_bytes(tiny_pdf()).unwrap();
        assert_eq!(d.page_count(), 1);
        let pd = d.page_dict(d.pages()[0]);
        assert_eq!(d.dget_nums(&pd, "MediaBox").unwrap(), vec![0.0, 0.0, 200.0, 100.0]);
    }

    #[test]
    fn incremental_roundtrip() {
        let d = Doc::from_bytes(tiny_pdf()).unwrap();
        let id = d.new_object(Object::Dict(dict(vec![("Hello", Object::string("world"))])));
        let mut out = Vec::new();
        d.save_incremental(&mut out).unwrap();
        assert!(out.len() > tiny_pdf().len());
        let d2 = Doc::from_bytes(out).unwrap();
        assert_eq!(d2.page_count(), 1);
        let o = d2.get(id.0);
        assert_eq!(o.as_dict().unwrap().get("Hello").unwrap().as_str().unwrap(), b"world");
    }

    #[test]
    fn reconstructs_broken_xref() {
        let mut bytes = tiny_pdf();
        let n = bytes.len();
        // destroy startxref pointer
        let p = bytes.windows(9).rposition(|w| w == b"startxref").unwrap();
        for b in &mut bytes[p + 10..n - 6] {
            *b = b'9';
        }
        let d = Doc::from_bytes(bytes).unwrap();
        assert!(d.reconstructed);
        assert_eq!(d.page_count(), 1);
    }

    #[test]
    fn content_roundtrip() {
        let ops = content::parse_content(b"q 1 0 0 1 10 20 cm BT /F1 12 Tf (Hello \\(x\\)) Tj [(a) -20 (b)] TJ ET Q");
        assert_eq!(ops.len(), 8);
        let s = content::serialize_content(&ops);
        let ops2 = content::parse_content(&s);
        assert_eq!(ops, ops2);
    }
}
