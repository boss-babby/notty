//! Tokenizer / object parser shared by file bodies and content streams.

use crate::error::{Error, Result};
use crate::object::{Dict, Object};

pub fn is_ws(b: u8) -> bool {
    matches!(b, 0 | 9 | 10 | 12 | 13 | 32)
}
pub fn is_delim(b: u8) -> bool {
    matches!(b, b'(' | b')' | b'<' | b'>' | b'[' | b']' | b'{' | b'}' | b'/' | b'%')
}
pub fn is_regular(b: u8) -> bool {
    !is_ws(b) && !is_delim(b)
}

#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    Obj(Object),
    Kw(String),
}

pub struct Lexer<'a> {
    pub data: &'a [u8],
    pub pos: usize,
    /// Recognise `N G R` indirect references (off for content streams).
    pub refs: bool,
}

fn hexval(b: u8) -> Option<u8> {
    match b {
        b'0'..=b'9' => Some(b - b'0'),
        b'a'..=b'f' => Some(b - b'a' + 10),
        b'A'..=b'F' => Some(b - b'A' + 10),
        _ => None,
    }
}

impl<'a> Lexer<'a> {
    pub fn new(data: &'a [u8], pos: usize) -> Self {
        Lexer { data, pos, refs: true }
    }

    pub fn skip_ws(&mut self) {
        loop {
            while self.pos < self.data.len() && is_ws(self.data[self.pos]) {
                self.pos += 1;
            }
            if self.pos < self.data.len() && self.data[self.pos] == b'%' {
                while self.pos < self.data.len() && self.data[self.pos] != 10 && self.data[self.pos] != 13 {
                    self.pos += 1;
                }
            } else {
                break;
            }
        }
    }

    pub fn peek(&self) -> Option<u8> {
        self.data.get(self.pos).copied()
    }

    pub fn at_end(&mut self) -> bool {
        self.skip_ws();
        self.pos >= self.data.len()
    }

    fn token(&mut self) -> &'a [u8] {
        let s = self.pos;
        while self.pos < self.data.len() && is_regular(self.data[self.pos]) {
            self.pos += 1;
        }
        &self.data[s..self.pos]
    }

    fn name(&mut self) -> String {
        let t = self.token();
        let mut out = String::with_capacity(t.len());
        let mut i = 0;
        while i < t.len() {
            if t[i] == b'#' && i + 2 < t.len() {
                if let (Some(h), Some(l)) = (hexval(t[i + 1]), hexval(t[i + 2])) {
                    out.push((h * 16 + l) as char);
                    i += 3;
                    continue;
                }
            }
            out.push(t[i] as char);
            i += 1;
        }
        out
    }

    fn string(&mut self) -> Result<Object> {
        // at '('
        self.pos += 1;
        let mut depth = 1;
        let mut out = Vec::new();
        while self.pos < self.data.len() {
            let b = self.data[self.pos];
            self.pos += 1;
            match b {
                b'(' => {
                    depth += 1;
                    out.push(b);
                }
                b')' => {
                    depth -= 1;
                    if depth == 0 {
                        return Ok(Object::Str(out));
                    }
                    out.push(b);
                }
                b'\\' => {
                    let Some(&e) = self.data.get(self.pos) else { break };
                    self.pos += 1;
                    match e {
                        b'n' => out.push(10),
                        b'r' => out.push(13),
                        b't' => out.push(9),
                        b'b' => out.push(8),
                        b'f' => out.push(12),
                        b'\r' => {
                            if self.peek() == Some(b'\n') {
                                self.pos += 1;
                            }
                        }
                        b'\n' => {}
                        b'0'..=b'7' => {
                            let mut v = (e - b'0') as u32;
                            for _ in 0..2 {
                                match self.peek() {
                                    Some(d @ b'0'..=b'7') => {
                                        v = v * 8 + (d - b'0') as u32;
                                        self.pos += 1;
                                    }
                                    _ => break,
                                }
                            }
                            out.push(v as u8);
                        }
                        other => out.push(other),
                    }
                }
                _ => out.push(b),
            }
        }
        Err(Error::Eof)
    }

    fn hex_string(&mut self) -> Result<Object> {
        self.pos += 1;
        let mut out = Vec::new();
        let mut hi: Option<u8> = None;
        while self.pos < self.data.len() {
            let b = self.data[self.pos];
            self.pos += 1;
            if b == b'>' {
                if let Some(h) = hi {
                    out.push(h << 4);
                }
                return Ok(Object::Str(out));
            }
            if let Some(v) = hexval(b) {
                match hi.take() {
                    Some(h) => out.push((h << 4) | v),
                    None => hi = Some(v),
                }
            }
        }
        Err(Error::Eof)
    }

    fn number(tok: &[u8]) -> Option<Object> {
        let s = std::str::from_utf8(tok).ok()?;
        let c = *tok.first()?;
        if !(c.is_ascii_digit() || c == b'+' || c == b'-' || c == b'.') {
            return None;
        }
        if let Ok(i) = s.parse::<i64>() {
            return Some(Object::Int(i));
        }
        if let Ok(f) = s.parse::<f64>() {
            if f.is_finite() {
                return Some(Object::Real(f));
            }
        }
        // Tolerate junk like "--5", "1.2.3", "5-3"
        let neg = s.starts_with('-');
        let mut cleaned = String::new();
        let mut dot = false;
        for (i, ch) in s.chars().enumerate() {
            if ch.is_ascii_digit() {
                cleaned.push(ch);
            } else if ch == '.' && !dot {
                dot = true;
                cleaned.push(ch);
            } else if (ch == '-' || ch == '+') && i > 0 && !cleaned.is_empty() {
                break;
            }
        }
        if cleaned.is_empty() || cleaned == "." {
            return None;
        }
        let v: f64 = cleaned.parse().ok()?;
        Some(Object::Real(if neg { -v } else { v }))
    }

    /// Parse the next value (object or keyword).
    pub fn next(&mut self) -> Result<Value> {
        self.skip_ws();
        let Some(&b) = self.data.get(self.pos) else { return Err(Error::Eof) };
        match b {
            b'/' => {
                self.pos += 1;
                Ok(Value::Obj(Object::Name(self.name())))
            }
            b'(' => Ok(Value::Obj(self.string()?)),
            b'<' => {
                if self.data.get(self.pos + 1) == Some(&b'<') {
                    self.pos += 2;
                    self.dict_body()
                } else {
                    Ok(Value::Obj(self.hex_string()?))
                }
            }
            b'[' => {
                self.pos += 1;
                let mut arr = Vec::new();
                loop {
                    self.skip_ws();
                    match self.peek() {
                        None => return Err(Error::Eof),
                        Some(b']') => {
                            self.pos += 1;
                            break;
                        }
                        _ => {}
                    }
                    match self.next()? {
                        Value::Obj(o) => arr.push(o),
                        Value::Kw(k) => return Err(Error::parse(format!("keyword `{k}` in array"))),
                    }
                }
                Ok(Value::Obj(Object::Array(arr)))
            }
            b']' | b'>' | b')' | b'{' | b'}' => {
                self.pos += 1;
                Err(Error::parse("stray delimiter"))
            }
            _ => {
                let tok = self.token();
                if tok.is_empty() {
                    self.pos += 1;
                    return Err(Error::parse("empty token"));
                }
                if let Some(num) = Self::number(tok) {
                    if self.refs {
                        if let Object::Int(n) = num {
                            if n >= 0 && n <= u32::MAX as i64 {
                                if let Some(r) = self.try_ref(n as u32) {
                                    return Ok(Value::Obj(r));
                                }
                            }
                        }
                    }
                    return Ok(Value::Obj(num));
                }
                match tok {
                    b"true" => Ok(Value::Obj(Object::Bool(true))),
                    b"false" => Ok(Value::Obj(Object::Bool(false))),
                    b"null" => Ok(Value::Obj(Object::Null)),
                    _ => Ok(Value::Kw(tok.iter().map(|&c| c as char).collect())),
                }
            }
        }
    }

    fn try_ref(&mut self, num: u32) -> Option<Object> {
        let save = self.pos;
        self.skip_ws();
        let s = self.pos;
        while self.pos < self.data.len() && self.data[self.pos].is_ascii_digit() {
            self.pos += 1;
        }
        if self.pos == s || self.pos - s > 5 {
            self.pos = save;
            return None;
        }
        let gen: u32 = std::str::from_utf8(&self.data[s..self.pos]).ok()?.parse().ok()?;
        self.skip_ws();
        if self.peek() == Some(b'R') && self.data.get(self.pos + 1).map_or(true, |&c| !is_regular(c)) {
            self.pos += 1;
            return Some(Object::Ref((num, gen.min(65535) as u16)));
        }
        self.pos = save;
        None
    }

    fn dict_body(&mut self) -> Result<Value> {
        let mut d = Dict::new();
        loop {
            self.skip_ws();
            match self.peek() {
                None => return Err(Error::Eof),
                Some(b'>') => {
                    if self.data.get(self.pos + 1) == Some(&b'>') {
                        self.pos += 2;
                        break;
                    }
                    self.pos += 1;
                    continue;
                }
                _ => {}
            }
            let key = match self.next()? {
                Value::Obj(Object::Name(k)) => k,
                Value::Kw(k) if k == "endobj" || k == "stream" || k == "endstream" => {
                    return Err(Error::parse("unterminated dictionary"))
                }
                _ => continue,
            };
            self.skip_ws();
            if self.peek() == Some(b'>') && self.data.get(self.pos + 1) == Some(&b'>') {
                // key without value
                continue;
            }
            match self.next()? {
                Value::Obj(v) => {
                    d.insert(key, v);
                }
                Value::Kw(k) => return Err(Error::parse(format!("bad dict value `{k}`"))),
            }
        }
        Ok(Value::Obj(Object::Dict(d)))
    }

    /// Parse the next *object* (keywords are an error).
    pub fn object(&mut self) -> Result<Object> {
        match self.next()? {
            Value::Obj(o) => Ok(o),
            Value::Kw(k) => Err(Error::parse(format!("expected object, got `{k}`"))),
        }
    }
}
