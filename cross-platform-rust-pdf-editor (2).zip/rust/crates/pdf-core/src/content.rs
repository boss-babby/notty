//! Content-stream tokenizer → operator list (and back again for editing).

use crate::lexer::{is_ws, Lexer, Value};
use crate::object::*;
use crate::write::write_object;

#[derive(Clone, Debug, PartialEq)]
pub struct InlineImage {
    pub dict: Dict,
    pub data: Vec<u8>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Op {
    pub name: String,
    pub args: Vec<Object>,
    pub inline: Option<InlineImage>,
}

impl Op {
    pub fn new(name: &str, args: Vec<Object>) -> Op {
        Op { name: name.to_string(), args, inline: None }
    }
}

fn expand_key(k: &str) -> &str {
    match k {
        "BPC" => "BitsPerComponent",
        "CS" => "ColorSpace",
        "D" => "Decode",
        "DP" => "DecodeParms",
        "F" => "Filter",
        "H" => "Height",
        "IM" => "ImageMask",
        "I" => "Interpolate",
        "W" => "Width",
        other => other,
    }
}

fn expand_value(o: Object) -> Object {
    match o {
        Object::Name(n) => Object::Name(
            match n.as_str() {
                "G" => "DeviceGray",
                "RGB" => "DeviceRGB",
                "CMYK" => "DeviceCMYK",
                "I" => "Indexed",
                "AHx" => "ASCIIHexDecode",
                "A85" => "ASCII85Decode",
                "LZW" => "LZWDecode",
                "Fl" => "FlateDecode",
                "RL" => "RunLengthDecode",
                "CCF" => "CCITTFaxDecode",
                "DCT" => "DCTDecode",
                other => other,
            }
            .to_string(),
        ),
        Object::Array(a) => Object::Array(a.into_iter().map(expand_value).collect()),
        other => other,
    }
}

pub fn parse_content(data: &[u8]) -> Vec<Op> {
    let mut lx = Lexer::new(data, 0);
    lx.refs = false;
    let mut ops = Vec::new();
    let mut args: Vec<Object> = Vec::new();
    loop {
        let before = lx.pos;
        match lx.next() {
            Ok(Value::Obj(o)) => {
                args.push(o);
                if args.len() > 4096 {
                    args.remove(0);
                }
            }
            Ok(Value::Kw(k)) => {
                if k == "BI" {
                    let mut d = Dict::new();
                    loop {
                        match lx.next() {
                            Ok(Value::Obj(Object::Name(key))) => {
                                if let Ok(Value::Obj(v)) = lx.next() {
                                    d.insert(expand_key(&key).to_string(), expand_value(v));
                                }
                            }
                            Ok(Value::Kw(k2)) if k2 == "ID" => break,
                            Err(crate::Error::Eof) => return ops,
                            _ => {}
                        }
                    }
                    // single whitespace after ID
                    if lx.pos < data.len() && is_ws(data[lx.pos]) {
                        lx.pos += 1;
                    }
                    let start = lx.pos;
                    let mut end = data.len();
                    let mut i = start;
                    while i + 1 < data.len() {
                        if data[i] == b'E' && data[i + 1] == b'I' && (i == start || is_ws(data[i - 1])) && (i + 2 >= data.len() || is_ws(data[i + 2])) {
                            end = if i > start { i - 1 } else { i };
                            lx.pos = i + 2;
                            break;
                        }
                        i += 1;
                    }
                    if end == data.len() {
                        lx.pos = data.len();
                    }
                    ops.push(Op { name: "BI".into(), args: vec![], inline: Some(InlineImage { dict: d, data: data[start..end.max(start)].to_vec() }) });
                    args.clear();
                    continue;
                }
                ops.push(Op { name: k, args: std::mem::take(&mut args), inline: None });
            }
            Err(crate::Error::Eof) => break,
            Err(_) => {
                if lx.pos == before {
                    lx.pos += 1;
                }
            }
        }
    }
    ops
}

pub fn serialize_content(ops: &[Op]) -> Vec<u8> {
    let mut out = Vec::new();
    for op in ops {
        if let Some(img) = &op.inline {
            out.extend_from_slice(b"BI\n");
            for (k, v) in &img.dict {
                crate::write::write_name(k, &mut out);
                out.push(b' ');
                write_object(v, &mut out);
                out.push(b'\n');
            }
            out.extend_from_slice(b"ID\n");
            out.extend_from_slice(&img.data);
            out.extend_from_slice(b"\nEI\n");
            continue;
        }
        for a in &op.args {
            write_object(a, &mut out);
            out.push(b' ');
        }
        out.extend_from_slice(op.name.as_bytes());
        out.push(b'\n');
    }
    out
}
