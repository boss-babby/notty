//! Outlines, destinations and link targets.

use crate::display::LinkTarget;
use pdf_core::{text_string, Dict, Doc, Object};
use std::collections::HashSet;

#[derive(Clone, Debug)]
pub struct OutlineItem {
    pub title: String,
    pub level: u32,
    pub page: Option<usize>,
}

fn page_of_ref(doc: &Doc, o: &Object) -> Option<usize> {
    match o {
        Object::Ref((n, _)) => doc.pages().iter().position(|p| p.0 == *n),
        Object::Int(i) => Some((*i).max(0) as usize),
        _ => None,
    }
}

fn lookup_named(doc: &Doc, name: &[u8]) -> Option<Object> {
    let cat = doc.catalog().ok()?;
    let key = String::from_utf8_lossy(name).to_string();
    if let Some(d) = doc.dget_dict(&cat, "Dests") {
        if let Some(v) = d.get(&key) {
            return Some((*doc.resolve(v)).clone());
        }
    }
    let names = doc.dget_dict(&cat, "Names")?;
    let tree = doc.dget(&names, "Dests")?;
    fn walk(doc: &Doc, node: &Object, name: &[u8], depth: u32) -> Option<Object> {
        if depth > 12 {
            return None;
        }
        let n = doc.resolve(node);
        let d = n.as_dict()?;
        if let Some(arr) = doc.dget_array(d, "Names") {
            for pair in arr.chunks(2) {
                if pair.len() == 2 && doc.resolve(&pair[0]).as_str() == Some(name) {
                    return Some((*doc.resolve(&pair[1])).clone());
                }
            }
        }
        if let Some(kids) = doc.dget_array(d, "Kids") {
            for k in &kids {
                // honour /Limits when present
                let kd = doc.resolve(k);
                if let Some(lim) = kd.as_dict().and_then(|x| doc.dget_array(x, "Limits")) {
                    if lim.len() == 2 {
                        let lo = doc.resolve(&lim[0]);
                        let hi = doc.resolve(&lim[1]);
                        if let (Some(lo), Some(hi)) = (lo.as_str(), hi.as_str()) {
                            if name < lo || name > hi {
                                continue;
                            }
                        }
                    }
                }
                if let Some(r) = walk(doc, k, name, depth + 1) {
                    return Some(r);
                }
            }
        }
        None
    }
    walk(doc, &tree, name, 0)
}

pub fn dest_to_page(doc: &Doc, dest: &Object) -> Option<usize> {
    let d = doc.resolve(dest);
    match &*d {
        Object::Array(a) => a.first().and_then(|f| page_of_ref(doc, f)),
        Object::Dict(dd) => dd.get("D").and_then(|x| dest_to_page(doc, x)),
        Object::Str(s) => lookup_named(doc, s).and_then(|o| dest_to_page(doc, &o)),
        Object::Name(n) => lookup_named(doc, n.as_bytes()).and_then(|o| dest_to_page(doc, &o)),
        _ => None,
    }
}

pub fn link_target(doc: &Doc, d: &Dict) -> Option<LinkTarget> {
    if let Some(dest) = d.get("Dest") {
        return dest_to_page(doc, dest).map(LinkTarget::Page);
    }
    let a = doc.dget_dict(d, "A")?;
    match doc.dget_name(&a, "S")?.as_str() {
        "URI" => {
            let u = doc.dget(&a, "URI")?;
            Some(LinkTarget::Uri(text_string(u.as_str()?)))
        }
        "GoTo" => a.get("D").and_then(|x| dest_to_page(doc, x)).map(LinkTarget::Page),
        _ => None,
    }
}

pub fn outline(doc: &Doc) -> Vec<OutlineItem> {
    let mut out = Vec::new();
    let Ok(cat) = doc.catalog() else { return out };
    let Some(root) = doc.dget_dict(&cat, "Outlines") else { return out };
    let mut seen = HashSet::new();
    fn walk(doc: &Doc, first: Option<Object>, level: u32, out: &mut Vec<OutlineItem>, seen: &mut HashSet<u32>) {
        let mut cur = first;
        while let Some(o) = cur.take() {
            if out.len() > 5000 || level > 12 {
                return;
            }
            if let Object::Ref((n, _)) = &o {
                if !seen.insert(*n) {
                    return;
                }
            }
            let item = doc.resolve(&o);
            let Some(d) = item.as_dict() else { return };
            let title = doc.dget_text(d, "Title").unwrap_or_default();
            let page = d.get("Dest").and_then(|x| dest_to_page(doc, x)).or_else(|| doc.dget_dict(d, "A").and_then(|a| a.get("D").and_then(|x| dest_to_page(doc, x))));
            out.push(OutlineItem { title, level, page });
            if let Some(f) = d.get("First") {
                walk(doc, Some(f.clone()), level + 1, out, seen);
            }
            cur = d.get("Next").cloned();
        }
    }
    walk(doc, root.get("First").cloned(), 0, &mut out, &mut seen);
    out
}
