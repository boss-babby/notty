//! Content-stream interpreter: PDF operators → display list.

use crate::color::{ColorSpace, Function};
use crate::display::*;
use crate::font::PdfFont;
use crate::geom::*;
use crate::image::decode_image;
use bumpalo::Bump;
use pdf_core::content::{parse_content, Op};
use pdf_core::{Dict, Doc, Error, Object, Result, Stream, StreamData};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use tiny_skia::{BlendMode, FillRule, LineCap, LineJoin, Path, PathBuilder, Pixmap, Transform};

/// Shared, thread-safe renderer front-end (font + image caches).
pub struct Renderer {
    pub doc: Arc<Doc>,
    fonts: Mutex<HashMap<u32, Arc<PdfFont>>>,
    images: Mutex<HashMap<u32, Arc<Pixmap>>>,
}

#[derive(Clone)]
struct ColorState {
    cs: ColorSpace,
    comps: Vec<f32>,
    paint: Paint,
}

impl ColorState {
    fn black() -> Self {
        ColorState { cs: ColorSpace::Gray, comps: vec![0.0], paint: Paint::Solid([0.0, 0.0, 0.0, 1.0]) }
    }
    fn rgb(&self) -> [f32; 3] {
        match &self.paint {
            Paint::Solid(c) => [c[0], c[1], c[2]],
            _ => [0.5, 0.5, 0.5],
        }
    }
}

#[derive(Clone)]
struct GState {
    ctm: Matrix,
    fill: ColorState,
    stroke: ColorState,
    fill_alpha: f32,
    stroke_alpha: f32,
    line_width: f32,
    cap: LineCap,
    join: LineJoin,
    miter: f32,
    dash: Option<(Vec<f32>, f32)>,
    clip: Option<Arc<ClipNode>>,
    blend: BlendMode,
    font: Option<Arc<PdfFont>>,
    font_size: f64,
    char_sp: f64,
    word_sp: f64,
    h_scale: f64,
    leading: f64,
    rise: f64,
    render_mode: i64,
}

impl GState {
    fn new(ctm: Matrix) -> Self {
        GState {
            ctm,
            fill: ColorState::black(),
            stroke: ColorState::black(),
            fill_alpha: 1.0,
            stroke_alpha: 1.0,
            line_width: 1.0,
            cap: LineCap::Butt,
            join: LineJoin::Miter,
            miter: 10.0,
            dash: None,
            clip: None,
            blend: BlendMode::SourceOver,
            font: None,
            font_size: 0.0,
            char_sp: 0.0,
            word_sp: 0.0,
            h_scale: 1.0,
            leading: 0.0,
            rise: 0.0,
            render_mode: 0,
        }
    }
}

fn num(args: &[Object], i: usize) -> f64 {
    args.get(i).and_then(|o| o.as_f64()).unwrap_or(0.0)
}

struct Interp<'a> {
    r: &'a Renderer,
    doc: &'a Doc,
    bump: &'a Bump,
    dl: DisplayList,
    gs: GState,
    stack: Vec<GState>,
    pb: PathBuilder,
    cur: (f32, f32),
    start: (f32, f32),
    pending_clip: Option<FillRule>,
    tm: Matrix,
    tlm: Matrix,
    pattern_base: Matrix,
    depth: u32,
    local_fonts: HashMap<String, Arc<PdfFont>>,
    cur_font_name: String,
}

impl Renderer {
    pub fn new(doc: Arc<Doc>) -> Renderer {
        Renderer { doc, fonts: Mutex::new(HashMap::new()), images: Mutex::new(HashMap::new()) }
    }

    pub fn clear_caches(&self) {
        self.images.lock().unwrap().clear();
    }

    /// `([x0,y0,x1,y1], rotate)` of the visible page box.
    pub fn page_geometry(&self, pd: &Dict) -> ([f64; 4], i32) {
        let d = &self.doc;
        let media = d.dget_nums(pd, "MediaBox").filter(|v| v.len() >= 4).map(|v| normalize_rect(&v)).unwrap_or([0.0, 0.0, 612.0, 792.0]);
        let mut b = media;
        if let Some(c) = d.dget_nums(pd, "CropBox").filter(|v| v.len() >= 4) {
            let c = normalize_rect(&c);
            let i = [c[0].max(media[0]), c[1].max(media[1]), c[2].min(media[2]), c[3].min(media[3])];
            if i[2] > i[0] && i[3] > i[1] {
                b = i;
            }
        }
        if b[2] - b[0] < 1.0 || b[3] - b[1] < 1.0 {
            b = [0.0, 0.0, 612.0, 792.0];
        }
        let rot = d.dget_i64(pd, "Rotate").unwrap_or(0) as i32;
        (b, ((rot % 360) + 360) % 360 / 90 * 90)
    }

    /// Cheap page size (points) after rotation, without interpreting content.
    pub fn page_size(&self, index: usize) -> Option<(f32, f32)> {
        let pages = self.doc.pages();
        let id = *pages.get(index)?;
        let pd = self.doc.page_dict(id);
        let (b, rot) = self.page_geometry(&pd);
        let (_, w, h) = page_matrix(b, rot);
        Some((w as f32, h as f32))
    }

    pub fn page_content(&self, pd: &Dict) -> Vec<u8> {
        let mut out = Vec::new();
        let Some(c) = pd.get("Contents") else { return out };
        let c = self.doc.resolve(c);
        let mut push = |o: &Object| {
            let s = self.doc.resolve(o);
            if let Some(st) = s.as_stream() {
                if let Ok(d) = self.doc.decode(st) {
                    out.extend_from_slice(&d.data);
                    out.push(b'\n');
                }
            }
        };
        match &*c {
            Object::Array(a) => a.iter().for_each(|o| push(o)),
            Object::Stream(_) => {
                if let Some(Object::Ref(_)) = pd.get("Contents") {
                    push(pd.get("Contents").unwrap())
                } else {
                    push(&c)
                }
            }
            _ => {}
        }
        out
    }

    pub fn build(&self, page_index: usize) -> Result<DisplayList> {
        let pages = self.doc.pages();
        let id = *pages.get(page_index).ok_or_else(|| Error::Missing("page".into()))?;
        let pd = self.doc.page_dict(id);
        let (b, rot) = self.page_geometry(&pd);
        let (base, w, h) = page_matrix(b, rot);
        let bump = Bump::new();
        let content = bump.alloc_slice_copy(&self.page_content(&pd));
        let ops = parse_content(content);
        let res = self.doc.dget_dict(&pd, "Resources").unwrap_or_default();
        let mut it = Interp {
            r: self,
            doc: &self.doc,
            bump: &bump,
            dl: DisplayList::new(page_index, w as f32, h as f32),
            gs: GState::new(base),
            stack: Vec::new(),
            pb: PathBuilder::new(),
            cur: (0.0, 0.0),
            start: (0.0, 0.0),
            pending_clip: None,
            tm: Matrix::IDENTITY,
            tlm: Matrix::IDENTITY,
            pattern_base: base,
            depth: 0,
            local_fonts: HashMap::new(),
            cur_font_name: String::new(),
        };
        it.run(&ops, &res, true);
        it.annotations(&pd, base);
        Ok(it.dl)
    }

    fn font_for(&self, o: &Object) -> Option<Arc<PdfFont>> {
        if let Object::Ref((n, _)) = o {
            if let Some(f) = self.fonts.lock().unwrap().get(n) {
                return Some(f.clone());
            }
            let obj = self.doc.get(*n);
            let d = obj.as_dict()?;
            let f = Arc::new(PdfFont::load(&self.doc, d));
            self.fonts.lock().unwrap().insert(*n, f.clone());
            return Some(f);
        }
        let d = o.as_dict()?;
        Some(Arc::new(PdfFont::load(&self.doc, d)))
    }

    /// Look up the font that a given resource name resolves to (used by the editor).
    pub fn font_by_name(&self, res: &Dict, name: &str) -> Option<Arc<PdfFont>> {
        let fonts = self.doc.dget_dict(res, "Font")?;
        self.font_for(fonts.get(name)?)
    }
}

fn rect_path(x: f32, y: f32, w: f32, h: f32) -> Option<Path> {
    let mut pb = PathBuilder::new();
    pb.move_to(x, y);
    pb.line_to(x + w, y);
    pb.line_to(x + w, y + h);
    pb.line_to(x, y + h);
    pb.close();
    pb.finish()
}

impl<'a> Interp<'a> {
    fn res_lookup(&self, res: &Dict, cat: &str, name: &str) -> Option<Object> {
        self.doc.dget_dict(res, cat).and_then(|d| d.get(name).cloned())
    }

    fn run(&mut self, ops: &[Op], res: &Dict, top: bool) {
        for (i, op) in ops.iter().enumerate() {
            let a = &op.args;
            let idx = if top { Some(i) } else { None };
            match op.name.as_str() {
                "q" => {
                    if self.stack.len() < 256 {
                        self.stack.push(self.gs.clone())
                    }
                }
                "Q" => {
                    if let Some(g) = self.stack.pop() {
                        self.gs = g;
                    }
                }
                "cm" => {
                    if let Some(m) = Matrix::from_objects(a) {
                        self.gs.ctm = m.mul(&self.gs.ctm);
                    }
                }
                "w" => self.gs.line_width = num(a, 0) as f32,
                "J" => {
                    self.gs.cap = match num(a, 0) as i32 {
                        1 => LineCap::Round,
                        2 => LineCap::Square,
                        _ => LineCap::Butt,
                    }
                }
                "j" => {
                    self.gs.join = match num(a, 0) as i32 {
                        1 => LineJoin::Round,
                        2 => LineJoin::Bevel,
                        _ => LineJoin::Miter,
                    }
                }
                "M" => self.gs.miter = num(a, 0) as f32,
                "d" => {
                    if let Some(Object::Array(arr)) = a.first() {
                        let v: Vec<f32> = arr.iter().filter_map(|o| o.as_f64()).map(|x| x as f32).collect();
                        self.gs.dash = if v.is_empty() || v.iter().all(|x| *x <= 0.0) { None } else { Some((v, num(a, 1) as f32)) };
                    }
                }
                "gs" => {
                    if let Some(n) = a.first().and_then(|o| o.as_name()) {
                        if let Some(Object::Dict(d)) = self.res_lookup(res, "ExtGState", n).map(|o| (*self.doc.resolve(&o)).clone()) {
                            self.ext_gstate(&d);
                        }
                    }
                }
                "m" => {
                    let p = (num(a, 0) as f32, num(a, 1) as f32);
                    self.pb.move_to(p.0, p.1);
                    self.cur = p;
                    self.start = p;
                }
                "l" => {
                    let p = (num(a, 0) as f32, num(a, 1) as f32);
                    self.ensure_start();
                    self.pb.line_to(p.0, p.1);
                    self.cur = p;
                }
                "c" => {
                    let v: Vec<f32> = (0..6).map(|k| num(a, k) as f32).collect();
                    self.ensure_start();
                    self.pb.cubic_to(v[0], v[1], v[2], v[3], v[4], v[5]);
                    self.cur = (v[4], v[5]);
                }
                "v" => {
                    let v: Vec<f32> = (0..4).map(|k| num(a, k) as f32).collect();
                    self.ensure_start();
                    self.pb.cubic_to(self.cur.0, self.cur.1, v[0], v[1], v[2], v[3]);
                    self.cur = (v[2], v[3]);
                }
                "y" => {
                    let v: Vec<f32> = (0..4).map(|k| num(a, k) as f32).collect();
                    self.ensure_start();
                    self.pb.cubic_to(v[0], v[1], v[2], v[3], v[2], v[3]);
                    self.cur = (v[2], v[3]);
                }
                "h" => {
                    self.pb.close();
                    self.cur = self.start;
                }
                "re" => {
                    let (x, y, w, h) = (num(a, 0) as f32, num(a, 1) as f32, num(a, 2) as f32, num(a, 3) as f32);
                    self.pb.move_to(x, y);
                    self.pb.line_to(x + w, y);
                    self.pb.line_to(x + w, y + h);
                    self.pb.line_to(x, y + h);
                    self.pb.close();
                    self.cur = (x, y);
                    self.start = (x, y);
                }
                "S" => self.paint(None, true, false),
                "s" => self.paint(None, true, true),
                "f" | "F" => self.paint(Some(FillRule::Winding), false, false),
                "f*" => self.paint(Some(FillRule::EvenOdd), false, false),
                "B" => self.paint(Some(FillRule::Winding), true, false),
                "B*" => self.paint(Some(FillRule::EvenOdd), true, false),
                "b" => self.paint(Some(FillRule::Winding), true, true),
                "b*" => self.paint(Some(FillRule::EvenOdd), true, true),
                "n" => self.paint(None, false, false),
                "W" => self.pending_clip = Some(FillRule::Winding),
                "W*" => self.pending_clip = Some(FillRule::EvenOdd),
                "BT" => {
                    self.tm = Matrix::IDENTITY;
                    self.tlm = Matrix::IDENTITY;
                }
                "Tc" => self.gs.char_sp = num(a, 0),
                "Tw" => self.gs.word_sp = num(a, 0),
                "Tz" => self.gs.h_scale = num(a, 0) / 100.0,
                "TL" => self.gs.leading = num(a, 0),
                "Tr" => self.gs.render_mode = num(a, 0) as i64,
                "Ts" => self.gs.rise = num(a, 0),
                "Tf" => {
                    if let Some(n) = a.first().and_then(|o| o.as_name()) {
                        self.gs.font_size = num(a, 1);
                        let key = format!("{}@{}", n, self.depth);
                        if let Some(o) = self.res_lookup(res, "Font", n) {
                            let f = if let Object::Ref(_) = o { self.r.font_for(&o) } else { self.local_fonts.get(&key).cloned().or_else(|| self.r.font_for(&o)) };
                            if let Some(f) = f {
                                self.local_fonts.insert(key, f.clone());
                                self.gs.font = Some(f);
                            }
                        }
                        self.cur_font_name = n.to_string();
                    }
                }
                "Td" => self.move_text(num(a, 0), num(a, 1)),
                "TD" => {
                    self.gs.leading = -num(a, 1);
                    self.move_text(num(a, 0), num(a, 1));
                }
                "Tm" => {
                    if let Some(m) = Matrix::from_objects(a) {
                        self.tm = m;
                        self.tlm = m;
                    }
                }
                "T*" => self.move_text(0.0, -self.gs.leading),
                "Tj" => {
                    if let Some(Object::Str(s)) = a.first() {
                        self.show(&[TjItem::Str(s)], idx);
                    }
                }
                "'" => {
                    self.move_text(0.0, -self.gs.leading);
                    if let Some(Object::Str(s)) = a.first() {
                        self.show(&[TjItem::Str(s)], idx);
                    }
                }
                "\"" => {
                    self.gs.word_sp = num(a, 0);
                    self.gs.char_sp = num(a, 1);
                    self.move_text(0.0, -self.gs.leading);
                    if let Some(Object::Str(s)) = a.get(2) {
                        self.show(&[TjItem::Str(s)], idx);
                    }
                }
                "TJ" => {
                    if let Some(Object::Array(arr)) = a.first() {
                        let items: Vec<TjItem> = arr
                            .iter()
                            .filter_map(|o| match o {
                                Object::Str(s) => Some(TjItem::Str(s)),
                                o => o.as_f64().map(TjItem::Adjust),
                            })
                            .collect();
                        self.show(&items, idx);
                    }
                }
                "g" => self.set_color(false, ColorSpace::Gray, vec![num(a, 0) as f32]),
                "G" => self.set_color(true, ColorSpace::Gray, vec![num(a, 0) as f32]),
                "rg" => self.set_color(false, ColorSpace::Rgb, (0..3).map(|k| num(a, k) as f32).collect()),
                "RG" => self.set_color(true, ColorSpace::Rgb, (0..3).map(|k| num(a, k) as f32).collect()),
                "k" => self.set_color(false, ColorSpace::Cmyk, (0..4).map(|k| num(a, k) as f32).collect()),
                "K" => self.set_color(true, ColorSpace::Cmyk, (0..4).map(|k| num(a, k) as f32).collect()),
                "cs" | "CS" => {
                    if let Some(o) = a.first() {
                        let cs = ColorSpace::parse(self.doc, o, Some(res), 0);
                        let c = cs.initial();
                        self.set_color(op.name == "CS", cs, c);
                    }
                }
                "sc" | "scn" | "SC" | "SCN" => {
                    let stroke = op.name.starts_with('S');
                    let cs = if stroke { self.gs.stroke.cs.clone() } else { self.gs.fill.cs.clone() };
                    if let (ColorSpace::Pattern, Some(Object::Name(pn))) = (&cs, a.last()) {
                        self.set_pattern(stroke, pn, res, a);
                    } else {
                        let comps: Vec<f32> = a.iter().filter_map(|o| o.as_f64()).map(|x| x as f32).collect();
                        self.set_color(stroke, cs, comps);
                    }
                }
                "sh" => {
                    if let Some(n) = a.first().and_then(|o| o.as_name()) {
                        if let Some(sh) = self.res_lookup(res, "Shading", n) {
                            if let Some(paint) = self.shading_paint(&sh, self.gs.ctm, res) {
                                self.fill_big_rect(paint);
                            }
                        }
                    }
                }
                "Do" => {
                    if let Some(n) = a.first().and_then(|o| o.as_name()) {
                        if let Some(xo) = self.res_lookup(res, "XObject", n) {
                            self.do_xobject(&xo, res);
                        }
                    }
                }
                "BI" => {
                    if let Some(img) = &op.inline {
                        let s = Stream { dict: img.dict.clone(), data: StreamData::Mem(Arc::new(img.data.clone())) };
                        let rgb = self.gs.fill.rgb();
                        if let Some(pm) = decode_image(self.doc, &s, Some(res), rgb) {
                            self.push_image(Arc::new(pm));
                        }
                    }
                }
                _ => {}
            }
        }
    }

    fn ensure_start(&mut self) {
        if self.pb.is_empty() {
            self.pb.move_to(self.cur.0, self.cur.1);
            self.start = self.cur;
        }
    }

    fn ext_gstate(&mut self, d: &Dict) {
        if let Some(v) = self.doc.dget_f64(d, "LW") {
            self.gs.line_width = v as f32;
        }
        if let Some(v) = self.doc.dget_i64(d, "LC") {
            self.gs.cap = match v {
                1 => LineCap::Round,
                2 => LineCap::Square,
                _ => LineCap::Butt,
            };
        }
        if let Some(v) = self.doc.dget_i64(d, "LJ") {
            self.gs.join = match v {
                1 => LineJoin::Round,
                2 => LineJoin::Bevel,
                _ => LineJoin::Miter,
            };
        }
        if let Some(v) = self.doc.dget_f64(d, "ML") {
            self.gs.miter = v as f32;
        }
        if let Some(v) = self.doc.dget_f64(d, "CA") {
            self.gs.stroke_alpha = v as f32;
        }
        if let Some(v) = self.doc.dget_f64(d, "ca") {
            self.gs.fill_alpha = v as f32;
        }
        if let Some(bm) = self.doc.dget(d, "BM") {
            let name = match &*bm {
                Object::Name(n) => Some(n.clone()),
                Object::Array(a) => a.first().and_then(|x| x.as_name().map(|s| s.to_string())),
                _ => None,
            };
            self.gs.blend = match name.as_deref() {
                Some("Multiply") => BlendMode::Multiply,
                Some("Screen") => BlendMode::Screen,
                Some("Overlay") => BlendMode::Overlay,
                Some("Darken") => BlendMode::Darken,
                Some("Lighten") => BlendMode::Lighten,
                Some("ColorDodge") => BlendMode::ColorDodge,
                Some("ColorBurn") => BlendMode::ColorBurn,
                Some("HardLight") => BlendMode::HardLight,
                Some("SoftLight") => BlendMode::SoftLight,
                Some("Difference") => BlendMode::Difference,
                Some("Exclusion") => BlendMode::Exclusion,
                _ => BlendMode::SourceOver,
            };
        }
        if let Some(Object::Array(f)) = self.doc.dget(d, "Font").as_deref() {
            if f.len() == 2 {
                if let Some(font) = self.r.font_for(&f[0]) {
                    self.gs.font = Some(font);
                    self.gs.font_size = f[1].as_f64().unwrap_or(1.0);
                }
            }
        }
    }

    fn set_color(&mut self, stroke: bool, cs: ColorSpace, comps: Vec<f32>) {
        let rgb = cs.to_rgb(&comps);
        let st = ColorState { cs, comps, paint: Paint::Solid([rgb[0], rgb[1], rgb[2], 1.0]) };
        if stroke {
            self.gs.stroke = st;
        } else {
            self.gs.fill = st;
        }
    }

    fn set_pattern(&mut self, stroke: bool, name: &str, res: &Dict, args: &[Object]) {
        let cs = if stroke { self.gs.stroke.cs.clone() } else { self.gs.fill.cs.clone() };
        let mut paint = Paint::Solid([0.8, 0.8, 0.8, 1.0]);
        if let Some(po) = self.res_lookup(res, "Pattern", name) {
            let p = self.doc.resolve(&po);
            if let Some(pd) = p.as_dict() {
                match self.doc.dget_i64(pd, "PatternType") {
                    Some(2) => {
                        let m = self.doc.dget_nums(pd, "Matrix").and_then(|v| Matrix::from_objects(&v.iter().map(|x| Object::Real(*x)).collect::<Vec<_>>())).unwrap_or(Matrix::IDENTITY);
                        let ts = m.mul(&self.pattern_base);
                        if let Some(sh) = pd.get("Shading") {
                            if let Some(g) = self.shading_paint(sh, ts, res) {
                                paint = g;
                            }
                        }
                    }
                    _ => {
                        let comps: Vec<f32> = args.iter().filter_map(|o| o.as_f64()).map(|x| x as f32).collect();
                        if !comps.is_empty() {
                            let rgb = ColorSpace::Rgb.to_rgb(&comps[..comps.len().min(3)]);
                            paint = Paint::Solid([rgb[0], rgb[1], rgb[2], 1.0]);
                        }
                    }
                }
            }
        }
        let st = ColorState { cs, comps: vec![], paint };
        if stroke {
            self.gs.stroke = st;
        } else {
            self.gs.fill = st;
        }
    }

    fn shading_paint(&mut self, sh: &Object, ts: Matrix, res: &Dict) -> Option<Paint> {
        let so = self.doc.resolve(sh);
        let d = so.as_dict()?;
        let kind = self.doc.dget_i64(d, "ShadingType")?;
        if kind != 2 && kind != 3 {
            return None;
        }
        let coords = self.doc.dget_nums(d, "Coords")?;
        let cs = ColorSpace::parse(self.doc, d.get("ColorSpace")?, Some(res), 0);
        let dom = self.doc.dget_nums(d, "Domain").filter(|v| v.len() >= 2).unwrap_or_else(|| vec![0.0, 1.0]);
        let fobj = self.doc.dget(d, "Function")?;
        let funcs: Vec<Function> = match &*fobj {
            Object::Array(a) => a.iter().filter_map(|f| Function::parse(self.doc, f)).collect(),
            other => Function::parse(self.doc, other).into_iter().collect(),
        };
        if funcs.is_empty() {
            return None;
        }
        let n = 32;
        let mut stops = Vec::new();
        for i in 0..n {
            let f = i as f64 / (n - 1) as f64;
            let t = dom[0] + f * (dom[1] - dom[0]);
            let comps: Vec<f32> = if funcs.len() == 1 { funcs[0].eval(t).iter().map(|x| *x as f32).collect() } else { funcs.iter().map(|g| g.eval(t).first().copied().unwrap_or(0.0) as f32).collect() };
            let rgb = cs.to_rgb(&comps);
            stops.push((f as f32, [rgb[0], rgb[1], rgb[2], 1.0]));
        }
        let (p0, p1, r1) = if kind == 2 {
            if coords.len() < 4 {
                return None;
            }
            ((coords[0] as f32, coords[1] as f32), (coords[2] as f32, coords[3] as f32), 0.0)
        } else {
            if coords.len() < 6 {
                return None;
            }
            ((coords[0] as f32, coords[1] as f32), (coords[3] as f32, coords[4] as f32), coords[5] as f32)
        };
        Some(Paint::Gradient(Arc::new(Gradient { radial: kind == 3, p0, p1, r1, stops, ts: ts.to_ts() })))
    }

    fn fill_big_rect(&mut self, paint: Paint) {
        if let Some(p) = rect_path(-1.0e5, -1.0e5, 2.0e5, 2.0e5) {
            self.dl.ops.push(DrawOp::Path(PathOp { path: Arc::new(p), ts: self.gs.ctm.to_ts(), fill: Some((paint, FillRule::Winding)), stroke: None, clip: self.gs.clip.clone(), blend: self.gs.blend }));
        }
    }

    fn paint(&mut self, fill: Option<FillRule>, stroke: bool, close: bool) {
        if close {
            self.pb.close();
        }
        let pb = std::mem::replace(&mut self.pb, PathBuilder::new());
        let clip_rule = self.pending_clip.take();
        let Some(path) = pb.finish() else { return };
        let path = Arc::new(path);
        let ts = self.gs.ctm.to_ts();
        if fill.is_some() || stroke {
            let f = fill.map(|r| (with_alpha(&self.gs.fill.paint, self.gs.fill_alpha), r));
            let s = if stroke {
                Some((
                    with_alpha(&self.gs.stroke.paint, self.gs.stroke_alpha),
                    StrokeSpec { width: self.gs.line_width, cap: self.gs.cap, join: self.gs.join, miter: self.gs.miter, dash: self.gs.dash.clone() },
                ))
            } else {
                None
            };
            self.dl.ops.push(DrawOp::Path(PathOp { path: path.clone(), ts, fill: f, stroke: s, clip: self.gs.clip.clone(), blend: self.gs.blend }));
        }
        if let Some(rule) = clip_rule {
            let b = path.bounds();
            let is_rect = path.len() <= 6 && is_axis_rect(&path);
            let _ = b;
            self.gs.clip = Some(Arc::new(ClipNode { path, ts, rule, is_rect, parent: self.gs.clip.clone() }));
        }
    }

    fn move_text(&mut self, tx: f64, ty: f64) {
        self.tlm = Matrix::translate(tx, ty).mul(&self.tlm);
        self.tm = self.tlm;
    }

    fn show(&mut self, items: &[TjItem], op_index: Option<usize>) {
        let Some(font) = self.gs.font.clone() else { return };
        let fs = self.gs.font_size;
        let th = self.gs.h_scale;
        let mut chars: Vec<CharBox> = Vec::new();
        let mut rect = [f32::MAX, f32::MAX, f32::MIN, f32::MIN];
        let mut scratch = bumpalo::collections::Vec::new_in(self.bump);
        for item in items {
            match item {
                TjItem::Adjust(n) => {
                    let tx = -n / 1000.0 * fs * th;
                    if *n < -250.0 {
                        let trm = Matrix::new(fs * th, 0.0, 0.0, fs, 0.0, self.gs.rise).mul(&self.tm).mul(&self.gs.ctm);
                        let r = trm.transform_rect([0.0, -0.2, 0.0, 0.8]);
                        chars.push(CharBox { ch: ' ', rect: [r[0] as f32, r[1] as f32, r[2] as f32, r[3] as f32] });
                    }
                    self.tm = Matrix::translate(tx, 0.0).mul(&self.tm);
                }
                TjItem::Str(bytes) => {
                    scratch.clear();
                    scratch.extend(font.decode(bytes));
                    for g in scratch.iter() {
                        let trm = Matrix::new(fs * th, 0.0, 0.0, fs, 0.0, self.gs.rise).mul(&self.tm).mul(&self.gs.ctm);
                        if self.gs.render_mode != 3 && self.gs.render_mode != 7 {
                            if let Some(gp) = font.glyph(g.code) {
                                let m = Matrix::new(gp.xscale as f64, 0.0, 0.0, 1.0, 0.0, 0.0).mul(&trm);
                                let fill = matches!(self.gs.render_mode, 0 | 2 | 4 | 6);
                                let stroke = matches!(self.gs.render_mode, 1 | 2 | 5 | 6);
                                self.dl.ops.push(DrawOp::Path(PathOp {
                                    path: gp.path.clone(),
                                    ts: m.to_ts(),
                                    fill: if fill { Some((with_alpha(&self.gs.fill.paint, self.gs.fill_alpha), FillRule::Winding)) } else { None },
                                    stroke: if stroke {
                                        let sc = (fs * th).abs().max(0.0001) as f32;
                                        Some((with_alpha(&self.gs.stroke.paint, self.gs.stroke_alpha), StrokeSpec { width: self.gs.line_width / sc, cap: self.gs.cap, join: self.gs.join, miter: self.gs.miter, dash: None }))
                                    } else {
                                        None
                                    },
                                    clip: self.gs.clip.clone(),
                                    blend: self.gs.blend,
                                }));
                            }
                        }
                        // text extraction box
                        let w = g.width.max(0.0);
                        let r = trm.transform_rect([0.0, -0.22, w, 0.8]);
                        let rr = [r[0] as f32, r[1] as f32, r[2] as f32, r[3] as f32];
                        rect = [rect[0].min(rr[0]), rect[1].min(rr[1]), rect[2].max(rr[2]), rect[3].max(rr[3])];
                        let mut it = g.text.chars();
                        match (it.next(), it.next()) {
                            (Some(c), None) => chars.push(CharBox { ch: c, rect: rr }),
                            (Some(c), Some(_)) => {
                                // ligature or multi-char mapping: spread evenly
                                let all: Vec<char> = g.text.chars().collect();
                                let n = all.len() as f32;
                                for (k, ch) in all.iter().enumerate() {
                                    let x0 = rr[0] + (rr[2] - rr[0]) * k as f32 / n;
                                    let x1 = rr[0] + (rr[2] - rr[0]) * (k + 1) as f32 / n;
                                    chars.push(CharBox { ch: *ch, rect: [x0, rr[1], x1, rr[3]] });
                                }
                                let _ = c;
                            }
                            _ => {}
                        }
                        let mut tx = g.width * fs + self.gs.char_sp;
                        if g.is_space {
                            tx += self.gs.word_sp;
                        }
                        self.tm = Matrix::translate(tx * th, 0.0).mul(&self.tm);
                    }
                }
            }
        }
        if chars.iter().any(|c| !c.ch.is_whitespace()) && rect[0] <= rect[2] {
            let size = ((self.gs.ctm.a * self.gs.ctm.a + self.gs.ctm.b * self.gs.ctm.b).sqrt() * fs).abs() as f32;
            // size in view space = fs * scale of Tm*CTM
            let m = self.tm.mul(&self.gs.ctm);
            let vs = ((m.a * m.a + m.b * m.b).sqrt() * fs).abs() as f32;
            let _ = size;
            self.dl.runs.push(TextRun { chars, rect, op_index, font_name: self.cur_font_name.clone(), font_size: vs });
        }
    }

    fn do_xobject(&mut self, xo: &Object, res: &Dict) {
        let obj = self.doc.resolve(xo);
        let Some(s) = obj.as_stream() else { return };
        match self.doc.dget_name(&s.dict, "Subtype").as_deref() {
            Some("Form") => {
                let m = self.doc.dget_nums(&s.dict, "Matrix").filter(|v| v.len() >= 6).map(|v| Matrix::new(v[0], v[1], v[2], v[3], v[4], v[5])).unwrap_or(Matrix::IDENTITY);
                let ctm = m.mul(&self.gs.ctm);
                self.exec_form(s, ctm, res);
            }
            Some("Image") => {
                let is_mask = self.doc.dget(&s.dict, "ImageMask").and_then(|o| o.as_bool()).unwrap_or(false);
                let key = xo.as_ref_id().map(|r| r.0);
                if !is_mask {
                    if let Some(k) = key {
                        if let Some(p) = self.r.images.lock().unwrap().get(&k) {
                            let p = p.clone();
                            self.push_image(p);
                            return;
                        }
                    }
                }
                let rgb = self.gs.fill.rgb();
                let pm = decode_image(self.doc, s, Some(res), rgb).map(Arc::new).unwrap_or_else(|| {
                    // unsupported codec: light placeholder
                    let mut p = Pixmap::new(2, 2).unwrap();
                    p.fill(tiny_skia::Color::from_rgba8(225, 225, 228, 255));
                    Arc::new(p)
                });
                if !is_mask {
                    if let Some(k) = key {
                        let mut c = self.r.images.lock().unwrap();
                        let total: usize = c.values().map(|p| p.data().len()).sum();
                        if total > 96 * 1024 * 1024 {
                            c.clear();
                        }
                        c.insert(k, pm.clone());
                    }
                }
                self.push_image(pm);
            }
            _ => {}
        }
    }

    fn push_image(&mut self, img: Arc<Pixmap>) {
        self.dl.ops.push(DrawOp::Image(ImageOp { img, ts: self.gs.ctm.to_ts(), alpha: self.gs.fill_alpha, clip: self.gs.clip.clone(), blend: self.gs.blend }));
    }

    fn exec_form(&mut self, s: &Stream, ctm: Matrix, parent_res: &Dict) {
        if self.depth >= 12 {
            return;
        }
        let Ok(dec) = self.doc.decode(s) else { return };
        let saved = self.gs.clone();
        let saved_stack = std::mem::take(&mut self.stack);
        let saved_pb = std::mem::replace(&mut self.pb, PathBuilder::new());
        let saved_pb_base = self.pattern_base;
        let (saved_tm, saved_tlm) = (self.tm, self.tlm);
        self.gs.ctm = ctm;
        self.pattern_base = ctm;
        if let Some(bb) = self.doc.dget_nums(&s.dict, "BBox").filter(|v| v.len() >= 4) {
            let b = normalize_rect(&bb);
            if let Some(p) = rect_path(b[0] as f32, b[1] as f32, (b[2] - b[0]) as f32, (b[3] - b[1]) as f32) {
                self.gs.clip = Some(Arc::new(ClipNode { path: Arc::new(p), ts: ctm.to_ts(), rule: FillRule::Winding, is_rect: true, parent: self.gs.clip.clone() }));
            }
        }
        let res = self.doc.dget_dict(&s.dict, "Resources").unwrap_or_else(|| parent_res.clone());
        let ops = parse_content(&dec.data);
        self.depth += 1;
        self.run(&ops, &res, false);
        self.depth -= 1;
        self.gs = saved;
        self.stack = saved_stack;
        self.pb = saved_pb;
        self.pattern_base = saved_pb_base;
        self.tm = saved_tm;
        self.tlm = saved_tlm;
    }

    fn annotations(&mut self, pd: &Dict, base: Matrix) {
        let Some(annots) = self.doc.dget_array(pd, "Annots") else { return };
        for ao in annots {
            let Object::Ref(id) = ao else { continue };
            let obj = self.doc.get(id.0);
            let Some(d) = obj.as_dict() else { continue };
            let subtype = self.doc.dget_name(d, "Subtype").unwrap_or_default();
            if subtype == "Popup" {
                continue;
            }
            let Some(rv) = self.doc.dget_nums(d, "Rect").filter(|v| v.len() >= 4) else { continue };
            let rect = normalize_rect(&rv);
            let vr = base.transform_rect(rect);
            let flags = self.doc.dget_i64(d, "F").unwrap_or(0);
            let hidden = flags & 2 != 0 || flags & 32 != 0;
            let mut info = AnnotInfo { id, subtype: subtype.clone(), rect: [vr[0] as f32, vr[1] as f32, vr[2] as f32, vr[3] as f32], contents: self.doc.dget_text(d, "Contents").unwrap_or_default(), link: None, field: None };
            if subtype == "Link" {
                info.link = crate::nav::link_target(self.doc, d);
            }
            if subtype == "Widget" {
                info.field = self.field_info(id, d);
            }
            self.dl.annots.push(info);
            if hidden || subtype == "Link" {
                continue;
            }
            // appearance stream
            let Some(ap) = self.doc.dget_dict(d, "AP") else { continue };
            let Some(n) = self.doc.dget(&ap, "N") else { continue };
            let stream_obj = match &*n {
                Object::Stream(_) => Some(n.clone()),
                Object::Dict(states) => {
                    let st = self.doc.dget_name(d, "AS").unwrap_or_default();
                    states.get(&st).map(|o| self.doc.resolve(o))
                }
                _ => None,
            };
            let Some(so) = stream_obj else { continue };
            let Some(s) = so.as_stream() else { continue };
            let bbox = self.doc.dget_nums(&s.dict, "BBox").filter(|v| v.len() >= 4).map(|v| normalize_rect(&v)).unwrap_or([0.0, 0.0, rect[2] - rect[0], rect[3] - rect[1]]);
            let fm = self.doc.dget_nums(&s.dict, "Matrix").filter(|v| v.len() >= 6).map(|v| Matrix::new(v[0], v[1], v[2], v[3], v[4], v[5])).unwrap_or(Matrix::IDENTITY);
            let tb = fm.transform_rect(bbox);
            let (tw, th) = (tb[2] - tb[0], tb[3] - tb[1]);
            let sx = if tw.abs() < 1e-9 { 1.0 } else { (rect[2] - rect[0]) / tw };
            let sy = if th.abs() < 1e-9 { 1.0 } else { (rect[3] - rect[1]) / th };
            let a = Matrix::new(sx, 0.0, 0.0, sy, rect[0] - tb[0] * sx, rect[1] - tb[1] * sy);
            let ctm = fm.mul(&a).mul(&base);
            let saved = self.gs.clone();
            self.gs = GState::new(base);
            let empty = Dict::new();
            self.exec_form_with_matrix(s, ctm, &empty);
            self.gs = saved;
        }
    }

    // exec_form variant where `ctm` already includes the form matrix
    fn exec_form_with_matrix(&mut self, s: &Stream, ctm: Matrix, res: &Dict) {
        // exec_form expects the final CTM as well (matrix already folded in).
        self.exec_form(s, ctm, res);
    }

    fn field_info(&self, id: pdf_core::ObjId, d: &Dict) -> Option<FieldInfo> {
        let mut ft = self.doc.dget_name(d, "FT");
        let mut flags = self.doc.dget_i64(d, "Ff");
        let mut value = self.doc.dget(d, "V");
        let mut names: Vec<String> = Vec::new();
        if let Some(t) = self.doc.dget_text(d, "T") {
            names.push(t);
        }
        let mut field_id = id;
        let mut parent = d.get("Parent").cloned();
        let mut n = 0;
        while let Some(Object::Ref(pid)) = parent {
            n += 1;
            if n > 16 {
                break;
            }
            let po = self.doc.get(pid.0);
            let Some(pd) = po.as_dict() else { break };
            if ft.is_none() {
                ft = self.doc.dget_name(pd, "FT");
            }
            if flags.is_none() {
                flags = self.doc.dget_i64(pd, "Ff");
            }
            if value.is_none() {
                value = self.doc.dget(pd, "V");
            }
            if let Some(t) = self.doc.dget_text(pd, "T") {
                names.push(t);
            }
            if d.get("T").is_none() && n == 1 {
                field_id = pid;
            }
            parent = pd.get("Parent").cloned();
        }
        names.reverse();
        let ftype = ft?;
        let as_name = self.doc.dget_name(d, "AS").unwrap_or_default();
        let value_s = match value.as_deref() {
            Some(Object::Str(s)) => pdf_core::text_string(s),
            Some(Object::Name(n)) => n.clone(),
            _ => String::new(),
        };
        let checked = ftype == "Btn" && (!as_name.is_empty() && as_name != "Off");
        Some(FieldInfo { name: names.join("."), ftype, value: value_s, checked, flags: flags.unwrap_or(0), field_id })
    }
}

enum TjItem<'b> {
    Str(&'b [u8]),
    Adjust(f64),
}

fn with_alpha(p: &Paint, a: f32) -> Paint {
    match p {
        Paint::Solid(c) => Paint::Solid([c[0], c[1], c[2], c[3] * a]),
        g => g.clone(),
    }
}

fn is_axis_rect(p: &Path) -> bool {
    use tiny_skia::PathSegment::*;
    let mut pts = Vec::new();
    for s in p.segments() {
        match s {
            MoveTo(a) | LineTo(a) => pts.push(a),
            Close => {}
            _ => return false,
        }
    }
    if pts.len() < 4 || pts.len() > 5 {
        return false;
    }
    (pts[0].x == pts[1].x || pts[0].y == pts[1].y) && (pts[1].x == pts[2].x || pts[1].y == pts[2].y) && (pts[2].x == pts[3].x || pts[2].y == pts[3].y)
}

#[allow(dead_code)]
fn _t(_: Transform) {}
