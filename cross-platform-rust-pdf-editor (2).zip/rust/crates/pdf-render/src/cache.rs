//! Strict byte-budgeted LRU caches.

use std::collections::{BTreeMap, HashMap};
use std::hash::Hash;
use std::sync::Arc;
use tiny_skia::Pixmap;

/// RAM budget design (bytes). Every cache enforces its own hard cap; the sum
/// is the worst-case steady-state working set of the render pipeline.
#[derive(Clone, Copy, Debug)]
pub struct MemoryBudget {
    /// Decoded raster tiles (RGBA8, 512×512 ≈ 1 MiB each).
    pub tile_bytes: usize,
    /// Parsed per-page display lists (path/glyph/image ops + text boxes).
    pub display_list_bytes: usize,
    /// Tiles in flight at once (worker pool width).
    pub max_inflight: usize,
    pub tile_px: u32,
}

impl MemoryBudget {
    pub const fn desktop() -> Self {
        MemoryBudget { tile_bytes: 256 << 20, display_list_bytes: 96 << 20, max_inflight: 4, tile_px: 512 }
    }
    pub const fn tablet() -> Self {
        MemoryBudget { tile_bytes: 160 << 20, display_list_bytes: 64 << 20, max_inflight: 3, tile_px: 512 }
    }
    pub const fn mobile() -> Self {
        MemoryBudget { tile_bytes: 96 << 20, display_list_bytes: 40 << 20, max_inflight: 2, tile_px: 384 }
    }
    pub const fn web() -> Self {
        MemoryBudget { tile_bytes: 128 << 20, display_list_bytes: 48 << 20, max_inflight: 1, tile_px: 512 }
    }
    pub fn total(&self) -> usize {
        self.tile_bytes + self.display_list_bytes
    }
}

pub struct ByteLru<K: Hash + Eq + Clone, V: Clone> {
    budget: usize,
    used: usize,
    tick: u64,
    map: HashMap<K, (V, usize, u64)>,
    order: BTreeMap<u64, K>,
}

impl<K: Hash + Eq + Clone, V: Clone> ByteLru<K, V> {
    pub fn new(budget: usize) -> Self {
        ByteLru { budget, used: 0, tick: 0, map: HashMap::new(), order: BTreeMap::new() }
    }
    pub fn set_budget(&mut self, b: usize) {
        self.budget = b;
        self.evict(None);
    }
    pub fn used(&self) -> usize {
        self.used
    }
    pub fn len(&self) -> usize {
        self.map.len()
    }
    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }
    pub fn contains(&self, k: &K) -> bool {
        self.map.contains_key(k)
    }
    pub fn get(&mut self, k: &K) -> Option<V> {
        let t = self.tick + 1;
        let (v, _, old) = self.map.get_mut(k)?;
        let prev = *old;
        *old = t;
        let v = v.clone();
        self.tick = t;
        let key = self.order.remove(&prev)?;
        self.order.insert(t, key);
        Some(v)
    }
    pub fn insert(&mut self, k: K, v: V, size: usize) {
        self.remove(&k);
        self.tick += 1;
        self.order.insert(self.tick, k.clone());
        self.map.insert(k.clone(), (v, size, self.tick));
        self.used += size;
        self.evict(Some(&k));
    }
    pub fn remove(&mut self, k: &K) {
        if let Some((_, size, t)) = self.map.remove(k) {
            self.used -= size;
            self.order.remove(&t);
        }
    }
    pub fn retain(&mut self, mut f: impl FnMut(&K) -> bool) {
        let dead: Vec<K> = self.map.keys().filter(|k| !f(k)).cloned().collect();
        for k in dead {
            self.remove(&k);
        }
    }
    pub fn clear(&mut self) {
        self.map.clear();
        self.order.clear();
        self.used = 0;
    }
    fn evict(&mut self, keep: Option<&K>) {
        while self.used > self.budget {
            let Some((&t, _)) = self.order.iter().next() else { break };
            let k = self.order.get(&t).cloned().unwrap();
            if Some(&k) == keep {
                // never evict the entry we just inserted
                if self.order.len() == 1 {
                    break;
                }
                let second = self.order.iter().nth(1).map(|(t, k)| (*t, k.clone()));
                if let Some((_, k2)) = second {
                    self.remove(&k2);
                    continue;
                }
                break;
            }
            self.remove(&k);
        }
    }
}

#[derive(Hash, PartialEq, Eq, Clone, Copy, Debug)]
pub struct TileKey {
    pub doc: u64,
    pub page: u32,
    /// `scale * 1000` rounded – tiles are quantised to a geometric scale ladder.
    pub scale_q: i32,
    pub tx: i32,
    pub ty: i32,
    /// Per-page revision: bumped when an edit touches the page.
    pub rev: u32,
}

pub type TileCache = ByteLru<TileKey, Arc<Pixmap>>;

pub fn tile_cache(budget: usize) -> TileCache {
    ByteLru::new(budget)
}

pub fn pixmap_bytes(p: &Pixmap) -> usize {
    p.data().len()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn lru_respects_budget() {
        let mut c: ByteLru<u32, u32> = ByteLru::new(100);
        for i in 0..10 {
            c.insert(i, i, 30);
        }
        assert!(c.used() <= 100);
        assert!(c.contains(&9));
        assert!(!c.contains(&0));
        let _ = c.get(&7);
        c.insert(100, 1, 30);
        assert!(c.contains(&7) || c.used() <= 100);
    }
}
