//! Image XObject / inline image decoding into premultiplied RGBA pixmaps.

use crate::color::ColorSpace;
use pdf_core::{Dict, Doc, Stream};
use tiny_skia::Pixmap;

const MAX_PIXELS: usize = 4_000_000;

fn sample(data: &[u8], row_bytes: usize, bpc: usize, n: usize, x: usize, y: usize, c: usize) -> u32 {
    let idx = x * n + c;
    let row = y * row_bytes;
    match bpc {
        8 => data.get(row + idx).copied().unwrap_or(0) as u32,
        16 => ((data.get(row + idx * 2).copied().unwrap_or(0) as u32) << 8) | data.get(row + idx * 2 + 1).copied().unwrap_or(0) as u32,
        b => {
            let bit = idx * b;
            let byte = data.get(row + bit / 8).copied().unwrap_or(0) as u32;
            (byte >> (8 - b - (bit % 8))) & ((1 << b) - 1)
        }
    }
}

fn build(w: usize, h: usize, get: &dyn Fn(usize, usize) -> [u8; 4]) -> Option<Pixmap> {
    let f = ((w * h) as f64 / MAX_PIXELS as f64).sqrt().ceil().max(1.0) as usize;
    let (ow, oh) = ((w / f).max(1), (h / f).max(1));
    let mut pm = Pixmap::new(ow as u32, oh as u32)?;
    let out = pm.data_mut();
    for oy in 0..oh {
        for ox in 0..ow {
            let p = if f == 1 {
                get(ox, oy)
            } else {
                let (mut r, mut g, mut b, mut a, mut n) = (0u32, 0u32, 0u32, 0u32, 0u32);
                for dy in 0..f {
                    for dx in 0..f {
                        let (sx, sy) = ((ox * f + dx).min(w - 1), (oy * f + dy).min(h - 1));
                        let px = get(sx, sy);
                        r += px[0] as u32 * px[3] as u32;
                        g += px[1] as u32 * px[3] as u32;
                        b += px[2] as u32 * px[3] as u32;
                        a += px[3] as u32;
                        n += 1;
                    }
                }
                if a == 0 {
                    [0, 0, 0, 0]
                } else {
                    [(r / a) as u8, (g / a) as u8, (b / a) as u8, (a / n) as u8]
                }
            };
            let i = (oy * ow + ox) * 4;
            let a = p[3] as u32;
            out[i] = ((p[0] as u32 * a + 127) / 255) as u8;
            out[i + 1] = ((p[1] as u32 * a + 127) / 255) as u8;
            out[i + 2] = ((p[2] as u32 * a + 127) / 255) as u8;
            out[i + 3] = p[3];
        }
    }
    Some(pm)
}

fn gray_mask(doc: &Doc, s: &Stream) -> Option<(usize, usize, Vec<u8>)> {
    let d = &s.dict;
    let (w, h) = (doc.dget_i64(d, "Width")? as usize, doc.dget_i64(d, "Height")? as usize);
    let bpc = doc.dget_i64(d, "BitsPerComponent").unwrap_or(if doc.dget(d, "ImageMask").and_then(|o| o.as_bool()).unwrap_or(false) { 1 } else { 8 }) as usize;
    let dec = doc.decode(s).ok()?;
    if dec.image_filter.is_some() {
        return None;
    }
    let rb = (w * bpc + 7) / 8;
    let invert = doc.dget_nums(d, "Decode").map_or(false, |v| v.first().copied() == Some(1.0));
    let is_stencil = doc.dget(d, "ImageMask").and_then(|o| o.as_bool()).unwrap_or(false);
    let maxv = ((1u32 << bpc.min(16)) - 1) as f32;
    let mut out = Vec::with_capacity(w * h);
    for y in 0..h {
        for x in 0..w {
            let v = sample(&dec.data, rb, bpc, 1, x, y, 0) as f32 / maxv;
            let v = if invert { 1.0 - v } else { v };
            // soft mask: value = opacity; stencil mask: 1 = masked-out
            out.push((if is_stencil { 1.0 - v } else { v } * 255.0) as u8);
        }
    }
    Some((w, h, out))
}

pub fn decode_image(doc: &Doc, s: &Stream, res: Option<&Dict>, fill_rgb: [f32; 3]) -> Option<Pixmap> {
    let d = &s.dict;
    let w = doc.dget_i64(d, "Width")? as usize;
    let h = doc.dget_i64(d, "Height")? as usize;
    if w == 0 || h == 0 || w > 100_000 || h > 100_000 {
        return None;
    }
    let is_mask = doc.dget(d, "ImageMask").and_then(|o| o.as_bool()).unwrap_or(false);
    let dec = doc.decode(s).ok()?;
    let decode_arr = doc.dget_nums(d, "Decode");
    let fb = |c: f32| (c.clamp(0.0, 1.0) * 255.0).round() as u8;

    // alpha channel
    let alpha: Option<(usize, usize, Vec<u8>)> = doc.dget(d, "SMask").and_then(|o| o.as_stream().and_then(|st| gray_mask(doc, st))).or_else(|| doc.dget(d, "Mask").and_then(|o| o.as_stream().and_then(|st| gray_mask(doc, st))));
    let alpha_at = |x: usize, y: usize| -> u8 {
        match &alpha {
            Some((aw, ah, a)) => {
                let (ax, ay) = ((x * aw / w).min(aw - 1), (y * ah / h).min(ah - 1));
                a[ay * aw + ax]
            }
            None => 255,
        }
    };

    if is_mask {
        if dec.image_filter.is_some() {
            return None;
        }
        let rb = (w + 7) / 8;
        let invert = decode_arr.as_ref().map_or(false, |v| v.first().copied() == Some(1.0));
        let c = [fb(fill_rgb[0]), fb(fill_rgb[1]), fb(fill_rgb[2])];
        return build(w, h, &|x, y| {
            let bit = sample(&dec.data, rb, 1, 1, x, y, 0) != 0;
            let paint = if invert { bit } else { !bit };
            [c[0], c[1], c[2], if paint { 255 } else { 0 }]
        });
    }

    if let Some(filter) = &dec.image_filter {
        if filter != "DCTDecode" {
            return None;
        }
        let opts = zune_core::options::DecoderOptions::default().jpeg_set_out_colorspace(zune_core::colorspace::ColorSpace::RGB);
        let mut jd = zune_jpeg::JpegDecoder::new_with_options(&dec.data, opts);
        let px = jd.decode().ok()?;
        let info = jd.info()?;
        let (jw, jh) = (info.width as usize, info.height as usize);
        if px.len() < jw * jh * 3 {
            return None;
        }
        return build(jw, jh, &|x, y| {
            let i = (y * jw + x) * 3;
            [px[i], px[i + 1], px[i + 2], alpha_at(x * w / jw, y * h / jh)]
        });
    }

    let cs = d.get("ColorSpace").map(|o| ColorSpace::parse(doc, o, res, 0)).unwrap_or(ColorSpace::Gray);
    let n = cs.ncomps().max(1);
    let bpc = doc.dget_i64(d, "BitsPerComponent").unwrap_or(8) as usize;
    if ![1, 2, 4, 8, 16].contains(&bpc) {
        return None;
    }
    let rb = (w * n * bpc + 7) / 8;
    let maxv = ((1u32 << bpc) - 1) as f32;
    let indexed = matches!(cs, ColorSpace::Indexed { .. });
    let dec_pairs: Vec<(f32, f32)> = (0..n)
        .map(|i| match &decode_arr {
            Some(v) if v.len() >= 2 * n => (v[2 * i] as f32, v[2 * i + 1] as f32),
            _ => {
                if indexed {
                    (0.0, maxv)
                } else if matches!(cs, ColorSpace::Lab) {
                    if i == 0 { (0.0, 100.0) } else { (-128.0, 127.0) }
                } else {
                    (0.0, 1.0)
                }
            }
        })
        .collect();
    // Colour-key mask
    let key: Option<Vec<i64>> = match doc.dget(d, "Mask") {
        Some(m) => m.as_array().map(|a| a.iter().filter_map(|o| doc.resolve(o).as_i64()).collect()),
        None => None,
    };
    let fast_rgb = matches!(cs, ColorSpace::Rgb) && bpc == 8 && decode_arr.is_none();
    let fast_gray = matches!(cs, ColorSpace::Gray) && bpc == 8 && decode_arr.is_none();
    let mut comps = vec![0f32; n];
    let cell = std::cell::RefCell::new(&mut comps);
    build(w, h, &|x, y| {
        let a = alpha_at(x, y);
        if fast_rgb {
            let i = y * rb + x * 3;
            return [dec.data.get(i).copied().unwrap_or(0), dec.data.get(i + 1).copied().unwrap_or(0), dec.data.get(i + 2).copied().unwrap_or(0), a];
        }
        if fast_gray {
            let g = dec.data.get(y * rb + x).copied().unwrap_or(0);
            return [g, g, g, a];
        }
        let mut c = cell.borrow_mut();
        let mut keyed = key.as_ref().map_or(false, |k| k.len() >= 2 * n);
        for i in 0..n {
            let raw = sample(&dec.data, rb, bpc, n, x, y, i);
            if let Some(k) = &key {
                if k.len() >= 2 * n && !((raw as i64) >= k[2 * i] && (raw as i64) <= k[2 * i + 1]) {
                    keyed = false;
                }
            }
            let (d0, d1) = dec_pairs[i];
            c[i] = if indexed { raw as f32 } else { d0 + raw as f32 / maxv * (d1 - d0) };
        }
        let rgb = cs.to_rgb(&c);
        [fb(rgb[0]), fb(rgb[1]), fb(rgb[2]), if keyed { 0 } else { a }]
    })
}
