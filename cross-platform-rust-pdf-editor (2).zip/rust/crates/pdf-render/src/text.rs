//! Per-page text model: reading-order character stream, search, selection.

use crate::display::{CharBox, TextRun};

#[derive(Clone, Debug)]
pub struct PageChar {
    pub ch: char,
    pub rect: [f32; 4],
    pub run: usize,
    /// Synthetic whitespace inserted between runs/lines (no glyph on page).
    pub synthetic: bool,
}

pub struct PageText {
    pub chars: Vec<PageChar>,
}

impl PageText {
    pub fn build(runs: &[TextRun]) -> PageText {
        let mut chars: Vec<PageChar> = Vec::new();
        let mut prev: Option<&TextRun> = None;
        for (ri, run) in runs.iter().enumerate() {
            if run.chars.is_empty() {
                continue;
            }
            if let Some(p) = prev {
                let same_line = (run.rect[1] - p.rect[1]).abs() < p.font_size.max(4.0) * 0.6;
                let gap = run.rect[0] - p.rect[2];
                let sep = if !same_line { Some('\n') } else if gap > p.font_size * 0.15 || gap < -p.font_size { Some(' ') } else { None };
                if let Some(c) = sep {
                    let last = chars.last().map(|c| c.rect).unwrap_or(run.rect);
                    if !chars.last().map_or(false, |l| l.ch == ' ' || l.ch == '\n') {
                        chars.push(PageChar { ch: c, rect: [last[2], last[1], last[2], last[3]], run: ri, synthetic: true });
                    }
                }
            }
            for CharBox { ch, rect } in &run.chars {
                chars.push(PageChar { ch: *ch, rect: *rect, run: ri, synthetic: false });
            }
            prev = Some(run);
        }
        PageText { chars }
    }

    pub fn string(&self) -> String {
        self.chars.iter().map(|c| c.ch).collect()
    }

    /// Case-insensitive search. Returns char index ranges.
    pub fn find(&self, query: &str) -> Vec<(usize, usize)> {
        let q: Vec<char> = query.chars().flat_map(|c| c.to_lowercase()).collect();
        let mut out = Vec::new();
        if q.is_empty() || self.chars.len() < q.len() {
            return out;
        }
        let hay: Vec<char> = self.chars.iter().map(|c| c.ch.to_lowercase().next().unwrap_or(c.ch)).collect();
        let mut i = 0;
        while i + q.len() <= hay.len() {
            let mut ok = true;
            for (k, qc) in q.iter().enumerate() {
                let hc = hay[i + k];
                if hc != *qc && !(hc == '\n' && *qc == ' ') {
                    ok = false;
                    break;
                }
            }
            if ok {
                out.push((i, i + q.len()));
                i += q.len();
            } else {
                i += 1;
            }
        }
        out
    }

    /// Merge a char range into per-line rectangles.
    pub fn rects(&self, range: (usize, usize)) -> Vec<[f32; 4]> {
        let mut out: Vec<[f32; 4]> = Vec::new();
        let mut cur: Option<(usize, [f32; 4])> = None;
        for c in &self.chars[range.0.min(self.chars.len())..range.1.min(self.chars.len())] {
            if c.synthetic || c.ch == '\n' {
                continue;
            }
            match &mut cur {
                Some((run, r)) if *run == c.run => {
                    r[0] = r[0].min(c.rect[0]);
                    r[1] = r[1].min(c.rect[1]);
                    r[2] = r[2].max(c.rect[2]);
                    r[3] = r[3].max(c.rect[3]);
                }
                _ => {
                    if let Some((_, r)) = cur.take() {
                        out.push(r);
                    }
                    cur = Some((c.run, c.rect));
                }
            }
        }
        if let Some((_, r)) = cur {
            out.push(r);
        }
        out
    }

    pub fn slice(&self, range: (usize, usize)) -> String {
        self.chars[range.0.min(self.chars.len())..range.1.min(self.chars.len())].iter().map(|c| c.ch).collect()
    }

    /// Index of the character nearest to a view-space point (None if the page
    /// has no text).
    pub fn hit(&self, x: f32, y: f32) -> Option<usize> {
        let mut best: Option<(usize, f32)> = None;
        for (i, c) in self.chars.iter().enumerate() {
            if c.synthetic {
                continue;
            }
            let r = c.rect;
            let dy = if y < r[1] { r[1] - y } else if y > r[3] { y - r[3] } else { 0.0 };
            let dx = if x < r[0] { r[0] - x } else if x > r[2] { x - r[2] } else { 0.0 };
            // weigh vertical distance more: pick the right line first
            let d = dy * 4.0 + dx;
            if best.map_or(true, |(_, bd)| d < bd) {
                best = Some((i, d));
            }
        }
        best.map(|b| b.0)
    }
}
