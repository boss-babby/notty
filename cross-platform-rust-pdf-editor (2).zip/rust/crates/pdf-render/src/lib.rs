//! `pdf-render` – content streams → display lists → pixels.
//!
//! * [`interp`]  – operator interpreter (bump-arena scratch, fonts, images, shadings, annotations)
//! * [`display`] – backend-neutral display-list IR
//! * [`raster`]  – tiny-skia tile rasteriser
//! * [`cache`]   – byte-budgeted LRU + `MemoryBudget` presets
//! * [`text`]    – page text model (search, selection)
//! * [`nav`]     – outlines, destinations, links

pub mod cache;
pub mod color;
pub mod display;
pub mod font;
pub mod geom;
pub mod image;
pub mod interp;
pub mod nav;
pub mod raster;
pub mod text;

pub use cache::{ByteLru, MemoryBudget, TileCache, TileKey};
pub use display::*;
pub use font::{PdfFont, FONT_SANS, FONT_SANS_BOLD, FONT_SERIF};
pub use geom::Matrix;
pub use interp::Renderer;
pub use nav::{outline, OutlineItem};
pub use raster::{render_page, render_tile, TileSpec};
pub use text::PageText;
