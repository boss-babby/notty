use pdf_core::Object;

/// PDF affine matrix `[a b c d e f]` (row-vector convention).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Matrix {
    pub a: f64,
    pub b: f64,
    pub c: f64,
    pub d: f64,
    pub e: f64,
    pub f: f64,
}

impl Matrix {
    pub const IDENTITY: Matrix = Matrix { a: 1.0, b: 0.0, c: 0.0, d: 1.0, e: 0.0, f: 0.0 };
    pub fn new(a: f64, b: f64, c: f64, d: f64, e: f64, f: f64) -> Matrix {
        Matrix { a, b, c, d, e, f }
    }
    pub fn translate(x: f64, y: f64) -> Matrix {
        Matrix::new(1.0, 0.0, 0.0, 1.0, x, y)
    }
    pub fn scale(x: f64, y: f64) -> Matrix {
        Matrix::new(x, 0.0, 0.0, y, 0.0, 0.0)
    }
    /// Apply `self` first, then `o`.
    pub fn mul(&self, o: &Matrix) -> Matrix {
        Matrix {
            a: self.a * o.a + self.b * o.c,
            b: self.a * o.b + self.b * o.d,
            c: self.c * o.a + self.d * o.c,
            d: self.c * o.b + self.d * o.d,
            e: self.e * o.a + self.f * o.c + o.e,
            f: self.e * o.b + self.f * o.d + o.f,
        }
    }
    pub fn apply(&self, x: f64, y: f64) -> (f64, f64) {
        (self.a * x + self.c * y + self.e, self.b * x + self.d * y + self.f)
    }
    pub fn det(&self) -> f64 {
        self.a * self.d - self.b * self.c
    }
    pub fn invert(&self) -> Option<Matrix> {
        let det = self.det();
        if det.abs() < 1e-12 {
            return None;
        }
        let (a, b, c, d) = (self.d / det, -self.b / det, -self.c / det, self.a / det);
        Some(Matrix { a, b, c, d, e: -(self.e * a + self.f * c), f: -(self.e * b + self.f * d) })
    }
    pub fn from_objects(a: &[Object]) -> Option<Matrix> {
        if a.len() < 6 {
            return None;
        }
        let v: Vec<f64> = a.iter().take(6).filter_map(|o| o.as_f64()).collect();
        if v.len() < 6 {
            return None;
        }
        Some(Matrix::new(v[0], v[1], v[2], v[3], v[4], v[5]))
    }
    pub fn to_ts(&self) -> tiny_skia::Transform {
        tiny_skia::Transform::from_row(self.a as f32, self.b as f32, self.c as f32, self.d as f32, self.e as f32, self.f as f32)
    }
    /// Axis-aligned bounds of a rectangle after transformation.
    pub fn transform_rect(&self, r: [f64; 4]) -> [f64; 4] {
        let pts = [self.apply(r[0], r[1]), self.apply(r[2], r[1]), self.apply(r[2], r[3]), self.apply(r[0], r[3])];
        let xs = pts.iter().map(|p| p.0);
        let ys = pts.iter().map(|p| p.1);
        [xs.clone().fold(f64::MAX, f64::min), ys.clone().fold(f64::MAX, f64::min), xs.fold(f64::MIN, f64::max), ys.fold(f64::MIN, f64::max)]
    }
}

pub fn normalize_rect(r: &[f64]) -> [f64; 4] {
    if r.len() < 4 {
        return [0.0, 0.0, 612.0, 792.0];
    }
    [r[0].min(r[2]), r[1].min(r[3]), r[0].max(r[2]), r[1].max(r[3])]
}

/// Matrix mapping default user space to the upright, top-left-origin "view
/// space" (points, y down) for the given crop box and page rotation.
pub fn page_matrix(b: [f64; 4], rotate: i32) -> (Matrix, f64, f64) {
    let (w, h) = (b[2] - b[0], b[3] - b[1]);
    match rotate.rem_euclid(360) {
        90 => (Matrix::new(0.0, 1.0, 1.0, 0.0, -b[1], -b[0]), h, w),
        180 => (Matrix::new(-1.0, 0.0, 0.0, 1.0, b[2], -b[1]), w, h),
        270 => (Matrix::new(0.0, -1.0, -1.0, 0.0, b[3], b[2]), h, w),
        _ => (Matrix::new(1.0, 0.0, 0.0, -1.0, -b[0], b[3]), w, h),
    }
}
