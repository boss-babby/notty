//! Backend-neutral display list. Both the tiny-skia (CPU / Wasm) rasteriser in
//! this crate and a future Vello / wgpu backend consume exactly this IR.

use crate::text::PageText;
use pdf_core::ObjId;
use std::sync::{Arc, OnceLock};
use tiny_skia::{BlendMode, FillRule, LineCap, LineJoin, Path, Pixmap, Transform};

pub struct ClipNode {
    pub path: Arc<Path>,
    pub ts: Transform,
    pub rule: FillRule,
    pub is_rect: bool,
    pub parent: Option<Arc<ClipNode>>,
}

#[derive(Clone)]
pub struct Gradient {
    pub radial: bool,
    pub p0: (f32, f32),
    pub p1: (f32, f32),
    pub r1: f32,
    pub stops: Vec<(f32, [f32; 4])>,
    /// Shading space → view space.
    pub ts: Transform,
}

#[derive(Clone)]
pub enum Paint {
    Solid([f32; 4]),
    Gradient(Arc<Gradient>),
}

#[derive(Clone)]
pub struct StrokeSpec {
    pub width: f32,
    pub cap: LineCap,
    pub join: LineJoin,
    pub miter: f32,
    pub dash: Option<(Vec<f32>, f32)>,
}

pub struct PathOp {
    pub path: Arc<Path>,
    pub ts: Transform,
    pub fill: Option<(Paint, FillRule)>,
    pub stroke: Option<(Paint, StrokeSpec)>,
    pub clip: Option<Arc<ClipNode>>,
    pub blend: BlendMode,
}

pub struct ImageOp {
    pub img: Arc<Pixmap>,
    /// Unit square (y up) → view space.
    pub ts: Transform,
    pub alpha: f32,
    pub clip: Option<Arc<ClipNode>>,
    pub blend: BlendMode,
}

pub enum DrawOp {
    Path(PathOp),
    Image(ImageOp),
}

#[derive(Clone, Debug)]
pub struct CharBox {
    pub ch: char,
    pub rect: [f32; 4],
}

#[derive(Clone, Debug)]
pub struct TextRun {
    pub chars: Vec<CharBox>,
    pub rect: [f32; 4],
    /// Index of the show-text operator in the page's top-level content ops.
    pub op_index: Option<usize>,
    pub font_name: String,
    pub font_size: f32,
}

impl TextRun {
    pub fn text(&self) -> String {
        self.chars.iter().map(|c| c.ch).collect()
    }
}

#[derive(Clone, Debug, PartialEq)]
pub enum LinkTarget {
    Uri(String),
    Page(usize),
}

#[derive(Clone, Debug)]
pub struct FieldInfo {
    pub name: String,
    pub ftype: String,
    pub value: String,
    pub checked: bool,
    pub flags: i64,
    pub field_id: ObjId,
}

#[derive(Clone, Debug)]
pub struct AnnotInfo {
    pub id: ObjId,
    pub subtype: String,
    /// View-space rectangle `[x0, y0, x1, y1]`.
    pub rect: [f32; 4],
    pub contents: String,
    pub link: Option<LinkTarget>,
    pub field: Option<FieldInfo>,
}

pub struct DisplayList {
    pub page_index: usize,
    pub width: f32,
    pub height: f32,
    pub ops: Vec<DrawOp>,
    pub runs: Vec<TextRun>,
    pub annots: Vec<AnnotInfo>,
    text: OnceLock<Arc<PageText>>,
}

impl DisplayList {
    pub fn new(page_index: usize, width: f32, height: f32) -> Self {
        DisplayList { page_index, width, height, ops: Vec::new(), runs: Vec::new(), annots: Vec::new(), text: OnceLock::new() }
    }
    pub fn page_text(&self) -> Arc<PageText> {
        self.text.get_or_init(|| Arc::new(PageText::build(&self.runs))).clone()
    }
    pub fn approx_bytes(&self) -> usize {
        let mut n = self.ops.len() * 160 + self.annots.len() * 200;
        for o in &self.ops {
            if let DrawOp::Image(i) = o {
                n += i.img.data().len();
            }
        }
        n + self.runs.iter().map(|r| r.chars.len() * 24 + 64).sum::<usize>()
    }
}
