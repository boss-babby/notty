//! tiny-skia CPU rasteriser: display list → tile pixmap. This is the Wasm /
//! low-end fallback backend; a Vello backend implements the same contract.

use crate::display::*;
use std::collections::HashMap;
use std::sync::Arc;
use tiny_skia::{
    Color, FillRule, FilterQuality, GradientStop, LinearGradient, Mask, Paint as SkPaint, Pattern, Pixmap, PixmapPaint, Point, RadialGradient, Rect, Shader, SpreadMode, Stroke, StrokeDash, Transform,
};

#[derive(Clone, Copy, Debug)]
pub struct TileSpec {
    /// Device pixels per view-space point.
    pub scale: f32,
    /// Top-left of the tile in device pixels (page origin = 0,0).
    pub x: i32,
    pub y: i32,
    pub w: u32,
    pub h: u32,
}

fn color(c: [f32; 4]) -> Color {
    Color::from_rgba(c[0].clamp(0.0, 1.0), c[1].clamp(0.0, 1.0), c[2].clamp(0.0, 1.0), c[3].clamp(0.0, 1.0)).unwrap_or(Color::BLACK)
}

fn shader_for(p: &Paint, dev: Transform) -> Option<Shader<'static>> {
    match p {
        Paint::Solid(c) => Some(Shader::SolidColor(color(*c))),
        Paint::Gradient(g) => {
            let stops: Vec<GradientStop> = g.stops.iter().map(|(pos, c)| GradientStop::new(*pos, color(*c))).collect();
            let ts = g.ts.post_concat(dev);
            if g.radial {
                RadialGradient::new(Point::from_xy(g.p0.0, g.p0.1), Point::from_xy(g.p1.0, g.p1.1), g.r1.max(0.001), stops, SpreadMode::Pad, ts)
            } else {
                LinearGradient::new(Point::from_xy(g.p0.0, g.p0.1), Point::from_xy(g.p1.0, g.p1.1), stops, SpreadMode::Pad, ts)
            }
        }
    }
}

fn path_bounds_view(path: &tiny_skia::Path, ts: &Transform) -> [f32; 4] {
    let b = path.bounds();
    let pts = [(b.left(), b.top()), (b.right(), b.top()), (b.right(), b.bottom()), (b.left(), b.bottom())];
    let mut r = [f32::MAX, f32::MAX, f32::MIN, f32::MIN];
    for (x, y) in pts {
        let (tx, ty) = (ts.sx * x + ts.kx * y + ts.tx, ts.ky * x + ts.sy * y + ts.ty);
        r = [r[0].min(tx), r[1].min(ty), r[2].max(tx), r[3].max(ty)];
    }
    r
}

fn build_mask(chain: &[&ClipNode], w: u32, h: u32, dev: Transform) -> Option<Mask> {
    let mut mask = Mask::new(w, h)?;
    let mut first = true;
    for n in chain {
        let ts = n.ts.post_concat(dev);
        if first {
            mask.fill_path(&n.path, n.rule, true, ts);
            first = false;
        } else {
            mask.intersect_path(&n.path, n.rule, true, ts);
        }
    }
    if first {
        None
    } else {
        Some(mask)
    }
}

struct Ctx {
    w: u32,
    h: u32,
    dev: Transform,
    masks: HashMap<usize, Option<Mask>>,
}

impl Ctx {
    fn covers_tile(&self, n: &ClipNode) -> bool {
        if !n.is_rect {
            return false;
        }
        let ts = n.ts.post_concat(self.dev);
        if ts.kx != 0.0 || ts.ky != 0.0 {
            return false;
        }
        let b = path_bounds_view(&n.path, &ts);
        b[0] <= 0.0 && b[1] <= 0.0 && b[2] >= self.w as f32 && b[3] >= self.h as f32
    }

    fn mask(&mut self, clip: &Option<Arc<ClipNode>>) -> Option<*const Mask> {
        let c = clip.as_ref()?;
        let key = Arc::as_ptr(c) as usize;
        if !self.masks.contains_key(&key) {
            if self.masks.len() > 48 {
                self.masks.clear();
            }
            let mut chain: Vec<&ClipNode> = Vec::new();
            let mut cur: Option<&ClipNode> = Some(c);
            while let Some(n) = cur {
                if !self.covers_tile(n) {
                    chain.push(n);
                }
                cur = n.parent.as_deref();
            }
            chain.reverse();
            let m = if chain.is_empty() { None } else { build_mask(&chain, self.w, self.h, self.dev) };
            self.masks.insert(key, m);
        }
        self.masks.get(&key).and_then(|m| m.as_ref()).map(|m| m as *const Mask)
    }
}

pub fn render_tile(dl: &DisplayList, spec: &TileSpec, background: Option<[u8; 4]>) -> Option<Pixmap> {
    let mut pm = Pixmap::new(spec.w, spec.h)?;
    if let Some(bg) = background {
        pm.fill(Color::from_rgba8(bg[0], bg[1], bg[2], bg[3]));
    }
    let dev = Transform::from_row(spec.scale, 0.0, 0.0, spec.scale, -spec.x as f32, -spec.y as f32);
    let mut ctx = Ctx { w: spec.w, h: spec.h, dev, masks: HashMap::new() };
    let tile = [spec.x as f32 / spec.scale, spec.y as f32 / spec.scale, (spec.x + spec.w as i32) as f32 / spec.scale, (spec.y + spec.h as i32) as f32 / spec.scale];

    for op in &dl.ops {
        match op {
            DrawOp::Path(p) => {
                let mut b = path_bounds_view(&p.path, &p.ts);
                let sc = (p.ts.sx * p.ts.sy - p.ts.kx * p.ts.ky).abs().sqrt();
                if let Some((_, s)) = &p.stroke {
                    let grow = (s.width.max(0.0) * sc * s.miter.max(1.0)).max(1.0 / spec.scale) * 0.5 + 1.0;
                    b = [b[0] - grow, b[1] - grow, b[2] + grow, b[3] + grow];
                }
                if b[2] < tile[0] || b[0] > tile[2] || b[3] < tile[1] || b[1] > tile[3] {
                    continue;
                }
                let mask_ptr = ctx.mask(&p.clip);
                // SAFETY: the mask lives in `ctx.masks` which is not mutated until the next op.
                let mask: Option<&Mask> = mask_ptr.map(|m| unsafe { &*m });
                let ts = p.ts.post_concat(dev);
                if let Some((paint, rule)) = &p.fill {
                    draw_fill(&mut pm, &p.path, paint, *rule, ts, dev, p.blend, mask);
                }
                if let Some((paint, spec_s)) = &p.stroke {
                    let dev_scale = (ts.sx * ts.sy - ts.kx * ts.ky).abs().sqrt().max(1e-6);
                    let mut width = spec_s.width;
                    if width * dev_scale < 1.0 {
                        width = 1.0 / dev_scale;
                    }
                    let mut stroke = Stroke { width, miter_limit: spec_s.miter.max(1.0), line_cap: spec_s.cap, line_join: spec_s.join, dash: None };
                    if let Some((arr, phase)) = &spec_s.dash {
                        let mut a = arr.clone();
                        if a.len() % 2 == 1 {
                            a.extend(arr.iter().copied());
                        }
                        stroke.dash = StrokeDash::new(a, *phase);
                    }
                    if let Some(shader) = shader_for(paint, dev) {
                        let mut sp = SkPaint::default();
                        sp.shader = shader;
                        sp.anti_alias = true;
                        sp.blend_mode = p.blend;
                        if matches!(paint, Paint::Gradient(_)) {
                            if let Some(path2) = (*p.path).clone().transform(ts) {
                                // gradient strokes: approximate by stroking in device space
                                let sw = Stroke { width: width * dev_scale, ..stroke.clone() };
                                pm.stroke_path(&path2, &sp, &sw, Transform::identity(), mask);
                            }
                        } else {
                            pm.stroke_path(&p.path, &sp, &stroke, ts, mask);
                        }
                    }
                }
            }
            DrawOp::Image(i) => {
                let r = {
                    let t = i.ts;
                    let pts = [(0.0f32, 0.0f32), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)];
                    let mut r = [f32::MAX, f32::MAX, f32::MIN, f32::MIN];
                    for (x, y) in pts {
                        let (tx, ty) = (t.sx * x + t.kx * y + t.tx, t.ky * x + t.sy * y + t.ty);
                        r = [r[0].min(tx), r[1].min(ty), r[2].max(tx), r[3].max(ty)];
                    }
                    r
                };
                if r[2] < tile[0] || r[0] > tile[2] || r[3] < tile[1] || r[1] > tile[3] {
                    continue;
                }
                let mask_ptr = ctx.mask(&i.clip);
                let mask: Option<&Mask> = mask_ptr.map(|m| unsafe { &*m });
                let (iw, ih) = (i.img.width() as f32, i.img.height() as f32);
                let ts = i.ts.post_concat(dev);
                let dev_w = ((ts.sx * ts.sx + ts.ky * ts.ky).sqrt()).max(1e-6);
                let quality = if dev_w / iw > 2.5 { FilterQuality::Nearest } else { FilterQuality::Bilinear };
                let pattern = Pattern::new(i.img.as_ref().as_ref(), SpreadMode::Pad, quality, i.alpha, Transform::from_row(1.0 / iw, 0.0, 0.0, -1.0 / ih, 0.0, 1.0));
                let mut sp = SkPaint::default();
                sp.shader = pattern;
                sp.blend_mode = i.blend;
                sp.anti_alias = true;
                if let Some(rect) = Rect::from_xywh(0.0, 0.0, 1.0, 1.0) {
                    pm.fill_rect(rect, &sp, ts, mask);
                }
            }
        }
    }
    Some(pm)
}

#[allow(clippy::too_many_arguments)]
fn draw_fill(pm: &mut Pixmap, path: &tiny_skia::Path, paint: &Paint, rule: FillRule, ts: Transform, dev: Transform, blend: tiny_skia::BlendMode, mask: Option<&Mask>) {
    let Some(shader) = shader_for(paint, dev) else { return };
    let mut sp = SkPaint::default();
    sp.shader = shader;
    sp.anti_alias = true;
    sp.blend_mode = blend;
    match paint {
        Paint::Solid(_) => pm.fill_path(path, &sp, rule, ts, mask),
        Paint::Gradient(_) => {
            if let Some(p2) = (*path).clone().transform(ts) {
                pm.fill_path(&p2, &sp, rule, Transform::identity(), mask);
            }
        }
    }
}

/// Convenience: render the whole page at `scale` on white.
pub fn render_page(dl: &DisplayList, scale: f32) -> Option<Pixmap> {
    let w = (dl.width * scale).ceil().max(1.0) as u32;
    let h = (dl.height * scale).ceil().max(1.0) as u32;
    render_tile(dl, &TileSpec { scale, x: 0, y: 0, w, h }, Some([255, 255, 255, 255]))
}

pub fn draw_pixmap(dst: &mut Pixmap, src: &Pixmap, x: f32, y: f32, scale: f32, smooth: bool) {
    let mut pp = PixmapPaint::default();
    pp.quality = if smooth { FilterQuality::Bilinear } else { FilterQuality::Nearest };
    let ts = Transform::from_row(scale, 0.0, 0.0, scale, x, y);
    dst.draw_pixmap(0, 0, src.as_ref(), &pp, ts, None);
}
