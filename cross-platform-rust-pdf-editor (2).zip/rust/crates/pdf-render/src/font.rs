//! PDF fonts → glyph outlines (pure Rust: `ttf-parser` for TrueType /
//! OpenType / bare CFF) with bundled open fallbacks for non-embedded fonts.

use pdf_core::lexer::{Lexer, Value};
use pdf_core::{Dict, Doc, Object};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use tiny_skia::{Path, PathBuilder};
use ttf_parser::{Face, GlyphId, PlatformId};

pub static FONT_SANS: &[u8] = include_bytes!("../assets/Inter-Regular.ttf");
pub static FONT_SANS_BOLD: &[u8] = include_bytes!("../assets/Inter-SemiBold.ttf");
pub static FONT_SERIF: &[u8] = include_bytes!("../assets/DejaVuSerif.ttf");

#[derive(Clone)]
pub struct GlyphPath {
    /// Outline in em units (1.0 == font size), y up.
    pub path: Arc<Path>,
    /// Horizontal squeeze applied when a fallback face replaces the real font.
    pub xscale: f32,
}

#[derive(Clone, Debug)]
pub struct Glyph {
    pub code: u32,
    /// Advance in text space (already divided by 1000).
    pub width: f64,
    pub is_space: bool,
    pub text: String,
}

enum Program {
    Ttf(Arc<Vec<u8>>),
    Cff(Arc<Vec<u8>>),
    None,
}

#[derive(Clone, Copy, PartialEq)]
enum Kind {
    Simple,
    Type0,
}

pub struct PdfFont {
    pub base_name: String,
    kind: Kind,
    program: Program,
    fallback: &'static [u8],
    widths: Vec<Option<f64>>,
    first_char: usize,
    missing_width: Option<f64>,
    cid_widths: HashMap<u32, f64>,
    dw: f64,
    chars: Vec<Option<char>>,
    names: Vec<Option<String>>,
    has_diff: bool,
    explicit_base: bool,
    symbolic: bool,
    to_unicode: HashMap<u32, String>,
    cid_to_gid: Option<Vec<u8>>,
    cache: Mutex<HashMap<u32, Option<GlyphPath>>>,
}

// ---------------------------------------------------------------- encodings
const CP1252_HI: [char; 32] = [
    '€', '\0', '‚', 'ƒ', '„', '…', '†', '‡', 'ˆ', '‰', 'Š', '‹', 'Œ', '\0', 'Ž', '\0', '\0', '‘', '’', '“', '”', '•', '–', '—', '˜', '™', 'š', '›', 'œ', '\0', 'ž', 'Ÿ',
];
const MAC_HI: &str = "ÄÅÇÉÑÖÜáàâäãåçéèêëíìîïñóòôöõúùûü†°¢£§•¶ß®©™´¨≠ÆØ∞±≤≥¥µ∂∑∏π∫ªºΩæø¿¡¬√ƒ≈∆«»… ÀÃÕŒœ–—“”‘’÷◊ÿŸ⁄€‹›ﬁﬂ‡·‚„‰ÂÊÁËÈÍÎÏÌÓÔ\u{F8FF}ÒÚÛÙıˆ˜¯˘˙˚¸˝˛ˇ";
const LATIN1_A1: [&str; 31] = [
    "exclamdown", "cent", "sterling", "currency", "yen", "brokenbar", "section", "dieresis", "copyright", "ordfeminine", "guillemotleft", "logicalnot", "hyphen", "registered", "macron", "degree",
    "plusminus", "twosuperior", "threesuperior", "acute", "mu", "paragraph", "periodcentered", "cedilla", "onesuperior", "ordmasculine", "guillemotright", "onequarter", "onehalf", "threequarters", "questiondown",
];
const LATIN1_C0: [&str; 64] = [
    "Agrave", "Aacute", "Acircumflex", "Atilde", "Adieresis", "Aring", "AE", "Ccedilla", "Egrave", "Eacute", "Ecircumflex", "Edieresis", "Igrave", "Iacute", "Icircumflex", "Idieresis", "Eth", "Ntilde",
    "Ograve", "Oacute", "Ocircumflex", "Otilde", "Odieresis", "multiply", "Oslash", "Ugrave", "Uacute", "Ucircumflex", "Udieresis", "Yacute", "Thorn", "germandbls", "agrave", "aacute", "acircumflex",
    "atilde", "adieresis", "aring", "ae", "ccedilla", "egrave", "eacute", "ecircumflex", "edieresis", "igrave", "iacute", "icircumflex", "idieresis", "eth", "ntilde", "ograve", "oacute", "ocircumflex",
    "otilde", "odieresis", "divide", "oslash", "ugrave", "uacute", "ucircumflex", "udieresis", "yacute", "thorn", "ydieresis",
];
const ASCII_NAMES: [&str; 95] = [
    "space", "exclam", "quotedbl", "numbersign", "dollar", "percent", "ampersand", "quotesingle", "parenleft", "parenright", "asterisk", "plus", "comma", "hyphen", "period", "slash", "zero", "one", "two",
    "three", "four", "five", "six", "seven", "eight", "nine", "colon", "semicolon", "less", "equal", "greater", "question", "at", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O",
    "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "bracketleft", "backslash", "bracketright", "asciicircum", "underscore", "grave", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
    "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "braceleft", "bar", "braceright", "asciitilde",
];
const EXTRA_NAMES: [(&str, char); 36] = [
    ("quoteleft", '‘'), ("quoteright", '’'), ("quotedblleft", '“'), ("quotedblright", '”'), ("quotesinglbase", '‚'), ("quotedblbase", '„'), ("endash", '–'), ("emdash", '—'), ("bullet", '•'),
    ("ellipsis", '…'), ("dagger", '†'), ("daggerdbl", '‡'), ("perthousand", '‰'), ("guilsinglleft", '‹'), ("guilsinglright", '›'), ("fi", 'ﬁ'), ("fl", 'ﬂ'), ("trademark", '™'), ("Euro", '€'),
    ("florin", 'ƒ'), ("circumflex", 'ˆ'), ("tilde", '˜'), ("OE", 'Œ'), ("oe", 'œ'), ("Scaron", 'Š'), ("scaron", 'š'), ("Zcaron", 'Ž'), ("zcaron", 'ž'), ("Ydieresis", 'Ÿ'), ("nbspace", '\u{A0}'),
    ("minus", '−'), ("fraction", '⁄'), ("dotlessi", 'ı'), ("lslash", 'ł'), ("Lslash", 'Ł'), ("sfthyphen", '\u{AD}'),
];

pub fn glyph_name_to_char(name: &str) -> Option<char> {
    if let Some(i) = ASCII_NAMES.iter().position(|n| *n == name) {
        return char::from_u32(0x20 + i as u32);
    }
    if let Some(i) = LATIN1_A1.iter().position(|n| *n == name) {
        return char::from_u32(0xA1 + i as u32);
    }
    if let Some(i) = LATIN1_C0.iter().position(|n| *n == name) {
        return char::from_u32(0xC0 + i as u32);
    }
    if let Some((_, c)) = EXTRA_NAMES.iter().find(|(n, _)| *n == name) {
        return Some(*c);
    }
    if let Some(h) = name.strip_prefix("uni") {
        if h.len() >= 4 {
            return u32::from_str_radix(&h[..4], 16).ok().and_then(char::from_u32);
        }
    }
    if let Some(h) = name.strip_prefix('u') {
        if (4..=6).contains(&h.len()) {
            return u32::from_str_radix(h, 16).ok().and_then(char::from_u32);
        }
    }
    None
}

pub fn char_to_glyph_name(c: char) -> String {
    let u = c as u32;
    if (0x20..0x7F).contains(&u) {
        return ASCII_NAMES[(u - 0x20) as usize].to_string();
    }
    if (0xA1..=0xBF).contains(&u) {
        return LATIN1_A1[(u - 0xA1) as usize].to_string();
    }
    if (0xC0..=0xFF).contains(&u) {
        return LATIN1_C0[(u - 0xC0) as usize].to_string();
    }
    if let Some((n, _)) = EXTRA_NAMES.iter().find(|(_, x)| *x == c) {
        return n.to_string();
    }
    format!("uni{:04X}", u)
}

fn winansi(code: usize) -> Option<char> {
    match code {
        0x20..=0x7E => char::from_u32(code as u32),
        0x80..=0x9F => {
            let c = CP1252_HI[code - 0x80];
            (c != '\0').then_some(c)
        }
        0xA0..=0xFF => char::from_u32(code as u32),
        _ => None,
    }
}
fn macroman(code: usize) -> Option<char> {
    match code {
        0x20..=0x7E => char::from_u32(code as u32),
        0x80..=0xFF => MAC_HI.chars().nth(code - 0x80),
        _ => None,
    }
}

// ----------------------------------------------------------------- outlines
struct Builder {
    pb: PathBuilder,
    sx: f32,
}
impl ttf_parser::OutlineBuilder for Builder {
    fn move_to(&mut self, x: f32, y: f32) {
        self.pb.move_to(x * self.sx, y * self.sx);
    }
    fn line_to(&mut self, x: f32, y: f32) {
        self.pb.line_to(x * self.sx, y * self.sx);
    }
    fn quad_to(&mut self, x1: f32, y1: f32, x: f32, y: f32) {
        self.pb.quad_to(x1 * self.sx, y1 * self.sx, x * self.sx, y * self.sx);
    }
    fn curve_to(&mut self, x1: f32, y1: f32, x2: f32, y2: f32, x: f32, y: f32) {
        self.pb.cubic_to(x1 * self.sx, y1 * self.sx, x2 * self.sx, y2 * self.sx, x * self.sx, y * self.sx);
    }
    fn close(&mut self) {
        self.pb.close();
    }
}

fn face_outline(face: &Face, gid: GlyphId) -> Option<Path> {
    let mut b = Builder { pb: PathBuilder::new(), sx: 1.0 / face.units_per_em() as f32 };
    face.outline_glyph(gid, &mut b)?;
    b.pb.finish()
}

fn is_sfnt(d: &[u8]) -> bool {
    d.len() > 4 && (&d[..4] == b"OTTO" || &d[..4] == b"true" || &d[..4] == b"ttcf" || d[..4] == [0, 1, 0, 0])
}

// -------------------------------------------------------------- ToUnicode
fn parse_tounicode(data: &[u8]) -> HashMap<u32, String> {
    let mut map = HashMap::new();
    let mut lx = Lexer::new(data, 0);
    lx.refs = false;
    let mut toks: Vec<Value> = Vec::new();
    let mut mode = 0; // 1 = bfchar, 2 = bfrange
    let code = |b: &[u8]| b.iter().fold(0u32, |a, &x| (a << 8) | x as u32);
    let utf16 = |b: &[u8]| {
        let u: Vec<u16> = b.chunks(2).map(|c| if c.len() == 2 { u16::from_be_bytes([c[0], c[1]]) } else { c[0] as u16 }).collect();
        String::from_utf16_lossy(&u)
    };
    while let Ok(v) = lx.next() {
        match &v {
            Value::Kw(k) if k == "beginbfchar" => {
                mode = 1;
                toks.clear();
            }
            Value::Kw(k) if k == "beginbfrange" => {
                mode = 2;
                toks.clear();
            }
            Value::Kw(k) if k == "endbfchar" || k == "endbfrange" => {
                mode = 0;
                toks.clear();
            }
            _ if mode == 1 => {
                toks.push(v);
                if toks.len() == 2 {
                    if let (Value::Obj(Object::Str(s)), Value::Obj(Object::Str(d))) = (&toks[0], &toks[1]) {
                        map.insert(code(s), utf16(d));
                    }
                    toks.clear();
                }
            }
            _ if mode == 2 => {
                toks.push(v);
                if toks.len() == 3 {
                    if let (Value::Obj(Object::Str(lo)), Value::Obj(Object::Str(hi))) = (&toks[0], &toks[1]) {
                        let (lo, hi) = (code(lo), code(hi));
                        if hi >= lo && hi - lo < 65536 {
                            match &toks[2] {
                                Value::Obj(Object::Str(d)) => {
                                    let base = utf16(d);
                                    for i in 0..=(hi - lo) {
                                        let mut chars: Vec<char> = base.chars().collect();
                                        if let Some(l) = chars.last_mut() {
                                            *l = char::from_u32(*l as u32 + i).unwrap_or(*l);
                                        }
                                        map.insert(lo + i, chars.into_iter().collect());
                                    }
                                }
                                Value::Obj(Object::Array(a)) => {
                                    for (i, d) in a.iter().enumerate() {
                                        if let Object::Str(d) = d {
                                            map.insert(lo + i as u32, utf16(d));
                                        }
                                    }
                                }
                                _ => {}
                            }
                        }
                    }
                    toks.clear();
                }
            }
            _ => {}
        }
    }
    map
}

impl PdfFont {
    pub fn load(doc: &Doc, d: &Dict) -> PdfFont {
        let subtype = doc.dget_name(d, "Subtype").unwrap_or_default();
        let raw_base = doc.dget_name(d, "BaseFont").unwrap_or_else(|| "Unknown".into());
        let base_name = if raw_base.len() > 7 && raw_base.as_bytes()[6] == b'+' { raw_base[7..].to_string() } else { raw_base };
        let kind = if subtype == "Type0" { Kind::Type0 } else { Kind::Simple };

        let desc_font: Dict = if kind == Kind::Type0 {
            doc.dget_array(d, "DescendantFonts").and_then(|a| a.first().map(|o| doc.resolve(o))).and_then(|o| o.as_dict().cloned()).unwrap_or_default()
        } else {
            d.clone()
        };
        let descriptor = doc.dget_dict(&desc_font, "FontDescriptor").unwrap_or_default();
        let flags = doc.dget_i64(&descriptor, "Flags").unwrap_or(0);
        let symbolic = flags & 4 != 0 && flags & 32 == 0;

        let mut program = Program::None;
        if let Some(o) = doc.dget(&descriptor, "FontFile2") {
            if let Ok(data) = doc.decode_object(&o) {
                program = Program::Ttf(Arc::new(data));
            }
        } else if let Some(o) = doc.dget(&descriptor, "FontFile3") {
            if let Ok(data) = doc.decode_object(&o) {
                program = if is_sfnt(&data) { Program::Ttf(Arc::new(data)) } else { Program::Cff(Arc::new(data)) };
            }
        }
        // Validate the program parses; otherwise fall back.
        program = match program {
            Program::Ttf(data) if Face::parse(&data, 0).is_ok() => Program::Ttf(data),
            Program::Cff(data) if ttf_parser::cff::Table::parse(&data).is_some() => Program::Cff(data),
            _ => Program::None,
        };

        let lname = base_name.to_lowercase();
        let bold = ["bold", "black", "heavy", "semibold", "demi"].iter().any(|k| lname.contains(k)) || flags & 0x40000 != 0;
        let serif = (["times", "georgia", "garamond", "palatino", "bookman", "century", "cambria", "minion", "serif", "roman", "book"].iter().any(|k| lname.contains(k)) && !lname.contains("sans")) || flags & 2 != 0 && !lname.contains("sans");
        let fallback: &'static [u8] = if bold {
            FONT_SANS_BOLD
        } else if serif {
            FONT_SERIF
        } else {
            FONT_SANS
        };

        // widths
        let mut widths = vec![None; 256];
        let first_char = doc.dget_i64(&desc_font, "FirstChar").unwrap_or(0).max(0) as usize;
        if let Some(w) = doc.dget_array(&desc_font, "Widths") {
            for (i, o) in w.iter().enumerate() {
                if let Some(v) = doc.resolve(o).as_f64() {
                    if first_char + i < 256 {
                        widths[first_char + i] = Some(v);
                    }
                }
            }
        }
        let missing_width = doc.dget_f64(&descriptor, "MissingWidth");
        let dw = doc.dget_f64(&desc_font, "DW").unwrap_or(1000.0);
        let mut cid_widths = HashMap::new();
        if kind == Kind::Type0 {
            if let Some(w) = doc.dget_array(&desc_font, "W") {
                let w: Vec<Object> = w.iter().map(|o| (*doc.resolve(o)).clone()).collect();
                let mut i = 0;
                while i < w.len() {
                    let Some(c) = w[i].as_i64() else { break };
                    match w.get(i + 1) {
                        Some(Object::Array(arr)) => {
                            for (k, x) in arr.iter().enumerate() {
                                if let Some(v) = doc.resolve(x).as_f64() {
                                    cid_widths.insert(c as u32 + k as u32, v);
                                }
                            }
                            i += 2;
                        }
                        Some(hi) => {
                            let hi = hi.as_i64().unwrap_or(c);
                            let v = w.get(i + 2).and_then(|x| x.as_f64()).unwrap_or(dw);
                            if hi >= c && hi - c < 70000 {
                                for k in c..=hi {
                                    cid_widths.insert(k as u32, v);
                                }
                            }
                            i += 3;
                        }
                        None => break,
                    }
                }
            }
        }
        let cid_to_gid = if kind == Kind::Type0 {
            doc.dget(&desc_font, "CIDToGIDMap").and_then(|o| if matches!(&*o, Object::Stream(_)) { doc.decode_object(&o).ok() } else { None })
        } else {
            None
        };

        // encoding
        let mut chars: Vec<Option<char>> = (0..256).map(winansi).collect();
        let mut names: Vec<Option<String>> = vec![None; 256];
        let mut has_diff = false;
        let mut explicit_base = false;
        if kind == Kind::Simple {
            let enc = d.get("Encoding").map(|o| doc.resolve(o));
            let apply_base = |n: &str, chars: &mut Vec<Option<char>>| match n {
                "MacRomanEncoding" => {
                    for i in 0..256 {
                        chars[i] = macroman(i);
                    }
                }
                _ => {
                    for i in 0..256 {
                        chars[i] = winansi(i);
                    }
                }
            };
            match enc.as_deref() {
                Some(Object::Name(n)) => {
                    explicit_base = true;
                    apply_base(n, &mut chars);
                }
                Some(Object::Dict(ed)) => {
                    if let Some(b) = doc.dget_name(ed, "BaseEncoding") {
                        explicit_base = true;
                        apply_base(&b, &mut chars);
                    }
                    if let Some(diffs) = doc.dget_array(ed, "Differences") {
                        let mut code = 0usize;
                        for o in diffs {
                            let o = doc.resolve(&o);
                            match &*o {
                                Object::Int(i) => code = (*i).max(0) as usize,
                                Object::Name(n) => {
                                    if code < 256 {
                                        names[code] = Some(n.clone());
                                        chars[code] = glyph_name_to_char(n);
                                        has_diff = true;
                                    }
                                    code += 1;
                                }
                                _ => {}
                            }
                        }
                    }
                }
                _ => {}
            }
        }
        let to_unicode = doc.dget(d, "ToUnicode").and_then(|o| doc.decode_object(&o).ok()).map(|b| parse_tounicode(&b)).unwrap_or_default();

        PdfFont {
            base_name,
            kind,
            program,
            fallback,
            widths,
            first_char,
            missing_width,
            cid_widths,
            dw,
            chars,
            names,
            has_diff,
            explicit_base,
            symbolic,
            to_unicode,
            cid_to_gid,
            cache: Mutex::new(HashMap::new()),
        }
    }

    pub fn is_embedded(&self) -> bool {
        !matches!(self.program, Program::None)
    }

    pub fn decode(&self, bytes: &[u8]) -> Vec<Glyph> {
        let mut out = Vec::with_capacity(bytes.len());
        match self.kind {
            Kind::Simple => {
                for &b in bytes {
                    let code = b as u32;
                    out.push(Glyph { code, width: self.width(code) / 1000.0, is_space: b == 32, text: self.text_of(code) });
                }
            }
            Kind::Type0 => {
                for c in bytes.chunks(2) {
                    let code = if c.len() == 2 { u16::from_be_bytes([c[0], c[1]]) as u32 } else { c[0] as u32 };
                    out.push(Glyph { code, width: self.width(code) / 1000.0, is_space: false, text: self.text_of(code) });
                }
            }
        }
        out
    }

    fn text_of(&self, code: u32) -> String {
        if let Some(t) = self.to_unicode.get(&code) {
            return t.clone();
        }
        if self.kind == Kind::Simple {
            if let Some(Some(c)) = self.chars.get(code as usize) {
                return c.to_string();
            }
        }
        String::new()
    }

    pub fn width(&self, code: u32) -> f64 {
        match self.kind {
            Kind::Type0 => self.cid_widths.get(&code).copied().unwrap_or(self.dw),
            Kind::Simple => {
                if let Some(Some(w)) = self.widths.get(code as usize) {
                    return *w;
                }
                if let Some(w) = self.missing_width {
                    if w > 0.0 || self.widths.iter().any(|w| w.is_some()) {
                        return w;
                    }
                }
                // No width info (standard 14): use the fallback face metrics.
                if let Some(Some(c)) = self.chars.get(code as usize) {
                    if let Ok(face) = Face::parse(self.fallback, 0) {
                        if let Some(g) = face.glyph_index(*c) {
                            if let Some(a) = face.glyph_hor_advance(g) {
                                return a as f64 / face.units_per_em() as f64 * 1000.0;
                            }
                        }
                    }
                }
                let _ = self.first_char;
                500.0
            }
        }
    }

    pub fn glyph(&self, code: u32) -> Option<GlyphPath> {
        if let Some(g) = self.cache.lock().unwrap().get(&code) {
            return g.clone();
        }
        let g = self.make_glyph(code);
        self.cache.lock().unwrap().insert(code, g.clone());
        g
    }

    fn name_for(&self, code: usize) -> Option<String> {
        self.names.get(code).cloned().flatten().or_else(|| self.chars.get(code).copied().flatten().map(char_to_glyph_name))
    }

    fn make_glyph(&self, code: u32) -> Option<GlyphPath> {
        match &self.program {
            Program::Ttf(data) => {
                let face = Face::parse(data, 0).ok()?;
                let gid = if self.kind == Kind::Type0 {
                    match &self.cid_to_gid {
                        Some(m) => {
                            let i = code as usize * 2;
                            if i + 1 < m.len() {
                                GlyphId(u16::from_be_bytes([m[i], m[i + 1]]))
                            } else {
                                return None;
                            }
                        }
                        None => GlyphId(code as u16),
                    }
                } else {
                    self.simple_ttf_gid(&face, code)?
                };
                let p = face_outline(&face, gid)?;
                Some(GlyphPath { path: Arc::new(p), xscale: 1.0 })
            }
            Program::Cff(data) => {
                let t = ttf_parser::cff::Table::parse(data)?;
                let sx = t.matrix().sx.abs();
                let sx = if sx > 0.0 { sx } else { 0.001 };
                let gid = if self.kind == Kind::Type0 {
                    let cid = code as u16;
                    (0..t.number_of_glyphs()).map(GlyphId).find(|g| t.glyph_cid(*g) == Some(cid)).unwrap_or(GlyphId(cid))
                } else if self.has_diff {
                    self.names.get(code as usize).cloned().flatten().and_then(|n| t.glyph_index_by_name(&n)).or_else(|| t.glyph_index(code as u8))?
                } else if self.explicit_base {
                    self.name_for(code as usize).and_then(|n| t.glyph_index_by_name(&n)).or_else(|| t.glyph_index(code as u8))?
                } else {
                    t.glyph_index(code as u8).or_else(|| self.name_for(code as usize).and_then(|n| t.glyph_index_by_name(&n)))?
                };
                let mut b = Builder { pb: PathBuilder::new(), sx: sx as f32 };
                t.outline(gid, &mut b).ok()?;
                Some(GlyphPath { path: Arc::new(b.pb.finish()?), xscale: 1.0 })
            }
            Program::None => {
                let ch = if self.kind == Kind::Type0 { self.to_unicode.get(&code)?.chars().next()? } else { self.chars.get(code as usize).copied().flatten().or_else(|| self.to_unicode.get(&code).and_then(|s| s.chars().next()))? };
                if ch == ' ' || ch == '\u{A0}' {
                    return None;
                }
                let face = Face::parse(self.fallback, 0).ok()?;
                let gid = face.glyph_index(ch)?;
                let p = face_outline(&face, gid)?;
                let adv = face.glyph_hor_advance(gid).unwrap_or(0) as f32 / face.units_per_em() as f32;
                let pdfw = (self.width(code) / 1000.0) as f32;
                let xs = if adv > 0.0 && pdfw > 0.0 { (pdfw / adv).clamp(0.7, 1.3) } else { 1.0 };
                Some(GlyphPath { path: Arc::new(p), xscale: xs })
            }
        }
    }

    fn simple_ttf_gid(&self, face: &Face, code: u32) -> Option<GlyphId> {
        let ch = self.chars.get(code as usize).copied().flatten();
        if self.has_diff {
            if let Some(Some(n)) = self.names.get(code as usize) {
                if let Some(g) = face.glyph_index_by_name(n) {
                    return Some(g);
                }
            }
        }
        if !self.symbolic || self.explicit_base {
            if let Some(c) = ch {
                if let Some(g) = face.glyph_index(c) {
                    return Some(g);
                }
            }
        }
        if let Some(cmap) = face.tables().cmap {
            for st in cmap.subtables {
                if st.platform_id == PlatformId::Windows && st.encoding_id == 0 {
                    for base in [0u32, 0xF000, 0xF100, 0xF200] {
                        if let Some(g) = st.glyph_index(base + code) {
                            return Some(g);
                        }
                    }
                }
            }
            for st in cmap.subtables {
                if st.platform_id == PlatformId::Macintosh && st.encoding_id == 0 {
                    if let Some(g) = st.glyph_index(code) {
                        return Some(g);
                    }
                }
            }
        }
        ch.and_then(|c| face.glyph_index(c)).or_else(|| face.glyph_index_by_name(&self.name_for(code as usize)?))
    }

    /// Encode text for a content stream (only if every char has a glyph here).
    pub fn encode(&self, text: &str) -> Option<Vec<u8>> {
        let mut out = Vec::new();
        for ch in text.chars() {
            match self.kind {
                Kind::Simple => {
                    let code = (0..256usize).find(|&c| self.chars[c] == Some(ch) && (ch == ' ' || self.glyph(c as u32).is_some()))?;
                    out.push(code as u8);
                }
                Kind::Type0 => {
                    let s = ch.to_string();
                    let code = self.to_unicode.iter().filter(|(_, v)| **v == s).map(|(k, _)| *k).min()?;
                    out.extend_from_slice(&(code as u16).to_be_bytes());
                }
            }
        }
        Some(out)
    }
}

/// Measure text with a bundled face (used by the UI and reflow).
pub fn text_width(face_data: &'static [u8], s: &str, size: f32) -> f32 {
    let Ok(face) = Face::parse(face_data, 0) else { return 0.0 };
    let upem = face.units_per_em() as f32;
    s.chars().map(|c| face.glyph_index(c).and_then(|g| face.glyph_hor_advance(g)).unwrap_or(0) as f32 / upem * size).sum()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn tables_are_consistent() {
        assert_eq!(MAC_HI.chars().count(), 128);
        assert_eq!(glyph_name_to_char("A"), Some('A'));
        assert_eq!(glyph_name_to_char("eacute"), Some('é'));
        assert_eq!(char_to_glyph_name('é'), "eacute");
        assert_eq!(glyph_name_to_char("space"), Some(' '));
    }
}
