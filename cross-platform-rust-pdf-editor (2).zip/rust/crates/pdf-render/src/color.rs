//! Colour spaces and PDF functions (types 0, 2, 3; type 4 falls back).

use pdf_core::{Dict, Doc, Object};
use std::sync::Arc;

#[derive(Clone, Debug)]
pub enum Function {
    Sampled { domain: (f64, f64), size: usize, n_out: usize, range: Vec<f64>, samples: Vec<f32>, encode: (f64, f64), decode: Vec<f64> },
    Exp { c0: Vec<f64>, c1: Vec<f64>, n: f64, domain: (f64, f64) },
    Stitch { funcs: Vec<Function>, bounds: Vec<f64>, encode: Vec<f64>, domain: (f64, f64) },
    /// PostScript calculators are not interpreted: treated as "ink amount → gray".
    Unsupported,
}

impl Function {
    pub fn parse(doc: &Doc, o: &Object) -> Option<Function> {
        let o = doc.resolve(o);
        let d = o.as_dict()?;
        let domain = doc.dget_nums(d, "Domain").filter(|v| v.len() >= 2).map(|v| (v[0], v[1])).unwrap_or((0.0, 1.0));
        match doc.dget_i64(d, "FunctionType")? {
            2 => Some(Function::Exp {
                c0: doc.dget_nums(d, "C0").unwrap_or_else(|| vec![0.0]),
                c1: doc.dget_nums(d, "C1").unwrap_or_else(|| vec![1.0]),
                n: doc.dget_f64(d, "N").unwrap_or(1.0),
                domain,
            }),
            3 => {
                let funcs: Vec<Function> = doc.dget_array(d, "Functions")?.iter().filter_map(|f| Function::parse(doc, f)).collect();
                Some(Function::Stitch { funcs, bounds: doc.dget_nums(d, "Bounds").unwrap_or_default(), encode: doc.dget_nums(d, "Encode").unwrap_or_default(), domain })
            }
            0 => {
                let size = doc.dget_nums(d, "Size")?.first().copied()? as usize;
                let range = doc.dget_nums(d, "Range")?;
                let n_out = range.len() / 2;
                let bps = doc.dget_i64(d, "BitsPerSample").unwrap_or(8) as usize;
                let data = doc.decode_object(&o).ok()?;
                let total = size * n_out;
                let maxv = ((1u64 << bps.min(32)) - 1) as f32;
                let mut samples = Vec::with_capacity(total);
                let mut bitpos = 0usize;
                for _ in 0..total {
                    let mut v: u64 = 0;
                    for _ in 0..bps {
                        let byte = data.get(bitpos / 8).copied().unwrap_or(0);
                        v = (v << 1) | ((byte >> (7 - bitpos % 8)) & 1) as u64;
                        bitpos += 1;
                    }
                    samples.push(v as f32 / maxv);
                }
                let encode = doc.dget_nums(d, "Encode").filter(|v| v.len() >= 2).map(|v| (v[0], v[1])).unwrap_or((0.0, (size - 1) as f64));
                let decode = doc.dget_nums(d, "Decode").unwrap_or_else(|| range.clone());
                Some(Function::Sampled { domain, size, n_out, range, samples, encode, decode })
            }
            _ => Some(Function::Unsupported),
        }
    }

    pub fn eval(&self, x: f64) -> Vec<f64> {
        match self {
            Function::Exp { c0, c1, n, domain } => {
                let x = x.clamp(domain.0, domain.1);
                let t = if *n == 1.0 { x } else { x.powf(*n) };
                c0.iter().zip(c1.iter().chain(std::iter::repeat(&1.0))).map(|(a, b)| a + t * (b - a)).collect()
            }
            Function::Stitch { funcs, bounds, encode, domain } => {
                if funcs.is_empty() {
                    return vec![0.0];
                }
                let x = x.clamp(domain.0, domain.1);
                let mut i = 0;
                while i < bounds.len() && x >= bounds[i] {
                    i += 1;
                }
                let i = i.min(funcs.len() - 1);
                let lo = if i == 0 { domain.0 } else { bounds[i - 1] };
                let hi = if i < bounds.len() { bounds[i] } else { domain.1 };
                let (e0, e1) = (encode.get(2 * i).copied().unwrap_or(0.0), encode.get(2 * i + 1).copied().unwrap_or(1.0));
                let t = if (hi - lo).abs() < 1e-12 { e0 } else { e0 + (x - lo) / (hi - lo) * (e1 - e0) };
                funcs[i].eval(t)
            }
            Function::Sampled { domain, size, n_out, samples, encode, decode, .. } => {
                let x = x.clamp(domain.0, domain.1);
                let e = if (domain.1 - domain.0).abs() < 1e-12 { 0.0 } else { encode.0 + (x - domain.0) / (domain.1 - domain.0) * (encode.1 - encode.0) };
                let e = e.clamp(0.0, (*size - 1) as f64);
                let i0 = e.floor() as usize;
                let i1 = (i0 + 1).min(*size - 1);
                let f = (e - i0 as f64) as f32;
                (0..*n_out)
                    .map(|k| {
                        let s = samples[i0 * n_out + k] * (1.0 - f) + samples[i1 * n_out + k] * f;
                        let (d0, d1) = (decode.get(2 * k).copied().unwrap_or(0.0), decode.get(2 * k + 1).copied().unwrap_or(1.0));
                        d0 + s as f64 * (d1 - d0)
                    })
                    .collect()
            }
            Function::Unsupported => vec![1.0 - x],
        }
    }
}

#[derive(Clone, Debug)]
pub enum ColorSpace {
    Gray,
    Rgb,
    Cmyk,
    Lab,
    Indexed { base: Box<ColorSpace>, hival: usize, table: Arc<Vec<u8>> },
    Tint { alt: Box<ColorSpace>, func: Option<Arc<Function>>, n: usize },
    Pattern,
}

impl ColorSpace {
    pub fn ncomps(&self) -> usize {
        match self {
            ColorSpace::Gray | ColorSpace::Indexed { .. } => 1,
            ColorSpace::Rgb | ColorSpace::Lab => 3,
            ColorSpace::Cmyk => 4,
            ColorSpace::Tint { n, .. } => *n,
            ColorSpace::Pattern => 0,
        }
    }

    pub fn initial(&self) -> Vec<f32> {
        match self {
            ColorSpace::Cmyk => vec![0.0, 0.0, 0.0, 1.0],
            ColorSpace::Tint { n, .. } => vec![1.0; *n],
            other => vec![0.0; other.ncomps()],
        }
    }

    pub fn to_rgb(&self, c: &[f32]) -> [f32; 3] {
        let g = |i: usize| c.get(i).copied().unwrap_or(0.0).clamp(0.0, 1.0);
        match self {
            ColorSpace::Gray => [g(0); 3],
            ColorSpace::Rgb => [g(0), g(1), g(2)],
            ColorSpace::Cmyk => {
                let (cc, m, y, k) = (g(0), g(1), g(2), g(3));
                [(1.0 - cc) * (1.0 - k), (1.0 - m) * (1.0 - k), (1.0 - y) * (1.0 - k)]
            }
            ColorSpace::Lab => {
                let l = c.first().copied().unwrap_or(0.0);
                let a = c.get(1).copied().unwrap_or(0.0);
                let b = c.get(2).copied().unwrap_or(0.0);
                let fy = (l + 16.0) / 116.0;
                let (fx, fz) = (fy + a / 500.0, fy - b / 200.0);
                let inv = |t: f32| if t > 0.2069 { t * t * t } else { (t - 16.0 / 116.0) / 7.787 };
                let (x, y, z) = (0.9505 * inv(fx), inv(fy), 1.089 * inv(fz));
                let lin = [3.2406 * x - 1.5372 * y - 0.4986 * z, -0.9689 * x + 1.8758 * y + 0.0415 * z, 0.0557 * x - 0.2040 * y + 1.0570 * z];
                let gm = |v: f32| if v <= 0.0031308 { 12.92 * v } else { 1.055 * v.powf(1.0 / 2.4) - 0.055 };
                [gm(lin[0]).clamp(0.0, 1.0), gm(lin[1]).clamp(0.0, 1.0), gm(lin[2]).clamp(0.0, 1.0)]
            }
            ColorSpace::Indexed { base, hival, table } => {
                let i = (c.first().copied().unwrap_or(0.0).round().max(0.0) as usize).min(*hival);
                let n = base.ncomps();
                let comps: Vec<f32> = (0..n).map(|k| table.get(i * n + k).copied().unwrap_or(0) as f32 / 255.0).collect();
                let comps = if matches!(**base, ColorSpace::Lab) { vec![comps[0] * 100.0, comps[1] * 255.0 - 128.0, comps[2] * 255.0 - 128.0] } else { comps };
                base.to_rgb(&comps)
            }
            ColorSpace::Tint { alt, func, n } => {
                if let Some(f) = func {
                    let out = f.eval(c.first().copied().unwrap_or(0.0) as f64);
                    let v: Vec<f32> = out.iter().map(|x| *x as f32).collect();
                    if v.len() >= alt.ncomps() && !matches!(**f, Function::Unsupported) {
                        return alt.to_rgb(&v);
                    }
                }
                let t = c.iter().take(*n).fold(0.0f32, |a, b| a.max(*b)).clamp(0.0, 1.0);
                [1.0 - t; 3]
            }
            ColorSpace::Pattern => [0.0; 3],
        }
    }

    pub fn parse(doc: &Doc, o: &Object, res: Option<&Dict>, depth: u32) -> ColorSpace {
        if depth > 6 {
            return ColorSpace::Gray;
        }
        let o = doc.resolve(o);
        match &*o {
            Object::Name(n) => match n.as_str() {
                "DeviceGray" | "G" | "CalGray" => ColorSpace::Gray,
                "DeviceRGB" | "RGB" | "CalRGB" => ColorSpace::Rgb,
                "DeviceCMYK" | "CMYK" => ColorSpace::Cmyk,
                "Pattern" => ColorSpace::Pattern,
                other => {
                    if let Some(r) = res {
                        if let Some(cs) = doc.dget_dict(r, "ColorSpace").and_then(|d| d.get(other).cloned()) {
                            if !matches!(&cs, Object::Name(m) if m == other) {
                                return ColorSpace::parse(doc, &cs, res, depth + 1);
                            }
                        }
                    }
                    ColorSpace::Gray
                }
            },
            Object::Array(a) if !a.is_empty() => {
                let kind = doc.resolve(&a[0]);
                match kind.as_name().unwrap_or("") {
                    "ICCBased" => {
                        let s = a.get(1).map(|x| doc.resolve(x));
                        let n = s.as_ref().and_then(|s| s.as_dict()).and_then(|d| doc.dget_i64(d, "N")).unwrap_or(3);
                        match n {
                            1 => ColorSpace::Gray,
                            4 => ColorSpace::Cmyk,
                            _ => ColorSpace::Rgb,
                        }
                    }
                    "CalRGB" => ColorSpace::Rgb,
                    "CalGray" => ColorSpace::Gray,
                    "Lab" => ColorSpace::Lab,
                    "Pattern" => ColorSpace::Pattern,
                    "Indexed" | "I" => {
                        let base = a.get(1).map(|b| ColorSpace::parse(doc, b, res, depth + 1)).unwrap_or(ColorSpace::Rgb);
                        let hival = a.get(2).and_then(|h| doc.resolve(h).as_i64()).unwrap_or(255).clamp(0, 255) as usize;
                        let table = match a.get(3).map(|t| doc.resolve(t)) {
                            Some(t) => match &*t {
                                Object::Str(s) => s.clone(),
                                Object::Stream(_) => doc.decode_object(&t).unwrap_or_default(),
                                _ => vec![],
                            },
                            None => vec![],
                        };
                        ColorSpace::Indexed { base: Box::new(base), hival, table: Arc::new(table) }
                    }
                    "Separation" | "DeviceN" => {
                        let n = if kind.as_name() == Some("Separation") { 1 } else { a.get(1).and_then(|x| doc.resolve(x).as_array().map(|v| v.len())).unwrap_or(1) };
                        let alt = a.get(2).map(|b| ColorSpace::parse(doc, b, res, depth + 1)).unwrap_or(ColorSpace::Gray);
                        let func = a.get(3).and_then(|f| Function::parse(doc, f)).map(Arc::new);
                        ColorSpace::Tint { alt: Box::new(alt), func, n }
                    }
                    "DeviceGray" | "G" => ColorSpace::Gray,
                    "DeviceRGB" | "RGB" => ColorSpace::Rgb,
                    "DeviceCMYK" | "CMYK" => ColorSpace::Cmyk,
                    _ => ColorSpace::Gray,
                }
            }
            _ => ColorSpace::Gray,
        }
    }
}
