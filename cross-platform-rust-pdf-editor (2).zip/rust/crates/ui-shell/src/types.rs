//! Shared vocabulary: geometry, breakpoints, tools, actions, events, effects.

use pdf_core::ByteSource;
use std::sync::Arc;

#[derive(Clone, Copy, Debug, PartialEq, Default)]
pub struct Rect {
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
}
impl Rect {
    pub fn new(x: f32, y: f32, w: f32, h: f32) -> Rect {
        Rect { x, y, w, h }
    }
    pub fn contains(&self, px: f32, py: f32) -> bool {
        px >= self.x && px <= self.x + self.w && py >= self.y && py <= self.y + self.h
    }
    pub fn right(&self) -> f32 {
        self.x + self.w
    }
    pub fn bottom(&self) -> f32 {
        self.y + self.h
    }
    pub fn inset(&self, d: f32) -> Rect {
        Rect::new(self.x + d, self.y + d, (self.w - 2.0 * d).max(0.0), (self.h - 2.0 * d).max(0.0))
    }
    pub fn center(&self) -> (f32, f32) {
        (self.x + self.w / 2.0, self.y + self.h / 2.0)
    }
    pub fn intersects(&self, o: &Rect) -> bool {
        self.x < o.right() && self.right() > o.x && self.y < o.bottom() && self.bottom() > o.y
    }
}

/// Single-codebase responsive breakpoints.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Bp {
    Mobile,
    Tablet,
    Desktop,
}
impl Bp {
    pub fn from_width(w: f32) -> Bp {
        if w < 600.0 {
            Bp::Mobile
        } else if w <= 1024.0 {
            Bp::Tablet
        } else {
            Bp::Desktop
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Tool {
    Hand,
    Select,
    Highlight,
    Ink,
    Note,
    TextBox,
    Sign,
    Redact,
    EditText,
}
impl Tool {
    pub const ALL: [Tool; 9] = [Tool::Hand, Tool::Select, Tool::Highlight, Tool::Ink, Tool::Note, Tool::TextBox, Tool::Sign, Tool::Redact, Tool::EditText];
    pub fn label(&self) -> &'static str {
        match self {
            Tool::Hand => "Hand",
            Tool::Select => "Select text",
            Tool::Highlight => "Highlight",
            Tool::Ink => "Draw",
            Tool::Note => "Sticky note",
            Tool::TextBox => "Text box",
            Tool::Sign => "Sign",
            Tool::Redact => "Redact",
            Tool::EditText => "Edit text",
        }
    }
    pub fn key(&self) -> char {
        match self {
            Tool::Hand => 'h',
            Tool::Select => 'v',
            Tool::Highlight => 'l',
            Tool::Ink => 'p',
            Tool::Note => 'n',
            Tool::TextBox => 'x',
            Tool::Sign => 'g',
            Tool::Redact => 'r',
            Tool::EditText => 'e',
        }
    }
    pub fn has_style(&self) -> bool {
        matches!(self, Tool::Highlight | Tool::Ink | Tool::TextBox | Tool::Sign)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ViewMode {
    Continuous,
    Single,
    TwoPage,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RailTab {
    Pages,
    Outline,
    Marks,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SheetKind {
    Tools,
    Search,
    Pages,
}

#[derive(Clone, Debug, PartialEq)]
pub enum Action {
    Open,
    OpenSample,
    Save,
    Undo,
    Redo,
    ZoomIn,
    ZoomOut,
    FitWidth,
    FitPage,
    SetMode(ViewMode),
    ToggleRail,
    RailTab(RailTab),
    SetTool(Tool),
    Palette,
    ToggleTheme,
    GoPage(usize),
    NextPage,
    PrevPage,
    Color(usize),
    Width(usize),
    Sheet(SheetKind),
    CloseSheet,
    RotatePage,
    DeletePage,
    MovePage(i32),
    ExtractPage,
    Merge,
    Search,
    SearchNext,
    SearchPrev,
    Bookmark,
    Reading,
    DeleteAnnot,
    ApplyEdit,
    CancelEdit,
    CopySel,
    HighlightSel,
    PaletteItem(usize),
    FocusSearch,
    Match(usize),
    DockGrip,
    SheetGrip,
    Noop,
}

#[derive(Clone, Debug)]
pub enum Effect {
    OpenUrl(String),
    SaveFile { name: String, bytes: Vec<u8> },
    PickFile { merge: bool },
    Copy(String),
    /// UI wants / no longer wants text input (soft keyboard hint).
    TextFocus(bool),
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Phase {
    Down,
    Move,
    Up,
    Cancel,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PointerKind {
    Mouse,
    Touch,
    Pen,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Key {
    Char(char),
    Enter,
    Escape,
    Backspace,
    Delete,
    Left,
    Right,
    Up,
    Down,
    PageUp,
    PageDown,
    Home,
    End,
    Tab,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct Mods {
    pub ctrl: bool,
    pub shift: bool,
    pub alt: bool,
}

pub enum Event {
    Pointer { phase: Phase, id: u64, x: f32, y: f32, kind: PointerKind, button: u8 },
    Wheel { x: f32, y: f32, dx: f32, dy: f32, ctrl: bool },
    Key { key: Key, mods: Mods },
    Text(String),
    OpenDocument { name: String, source: Arc<dyn ByteSource>, merge: bool },
}
