//! Immediate-mode 2D painter on top of tiny-skia: rounded rects, hairlines,
//! vector text (ttf-parser outlines) and a small icon set. Logical pixels in,
//! device pixels out (`s` = device pixel ratio).

use crate::types::Rect;
use pdf_render::{FONT_SANS, FONT_SANS_BOLD};
use std::collections::HashMap;
use std::sync::Arc;
use tiny_skia::{Color, FillRule, LineCap, LineJoin, Paint, Path, PathBuilder, Pixmap, Stroke, Transform};
use ttf_parser::Face;

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Rgba(pub u8, pub u8, pub u8, pub u8);
impl Rgba {
    pub fn c(self) -> Color {
        Color::from_rgba8(self.0, self.1, self.2, self.3)
    }
    pub fn alpha(self, a: f32) -> Rgba {
        Rgba(self.0, self.1, self.2, (self.3 as f32 * a).clamp(0.0, 255.0) as u8)
    }
    pub fn mix(self, o: Rgba, t: f32) -> Rgba {
        let m = |a: u8, b: u8| (a as f32 + (b as f32 - a as f32) * t) as u8;
        Rgba(m(self.0, o.0), m(self.1, o.1), m(self.2, o.2), m(self.3, o.3))
    }
}

#[derive(Clone, Copy)]
pub struct Theme {
    pub dark: bool,
    pub canvas: Rgba,
    pub panel: Rgba,
    pub glass: Rgba,
    pub hover: Rgba,
    pub border: Rgba,
    pub text: Rgba,
    pub dim: Rgba,
    pub accent: Rgba,
    pub accent_fg: Rgba,
    pub danger: Rgba,
}

impl Theme {
    pub fn dark() -> Theme {
        Theme {
            dark: true,
            canvas: Rgba(17, 18, 20, 255),
            panel: Rgba(24, 25, 28, 255),
            glass: Rgba(30, 31, 35, 226),
            hover: Rgba(255, 255, 255, 18),
            border: Rgba(255, 255, 255, 30),
            text: Rgba(236, 237, 240, 255),
            dim: Rgba(142, 146, 156, 255),
            accent: Rgba(124, 130, 255, 255),
            accent_fg: Rgba(14, 14, 24, 255),
            danger: Rgba(255, 102, 102, 255),
        }
    }
    pub fn light() -> Theme {
        Theme {
            dark: false,
            canvas: Rgba(232, 233, 237, 255),
            panel: Rgba(250, 250, 252, 255),
            glass: Rgba(255, 255, 255, 226),
            hover: Rgba(0, 0, 0, 14),
            border: Rgba(0, 0, 0, 28),
            text: Rgba(24, 25, 29, 255),
            dim: Rgba(110, 114, 126, 255),
            accent: Rgba(79, 70, 229, 255),
            accent_fg: Rgba(255, 255, 255, 255),
            danger: Rgba(214, 48, 48, 255),
        }
    }
}

struct Outline {
    pb: PathBuilder,
    sx: f32,
}
impl ttf_parser::OutlineBuilder for Outline {
    fn move_to(&mut self, x: f32, y: f32) {
        self.pb.move_to(x * self.sx, y * self.sx)
    }
    fn line_to(&mut self, x: f32, y: f32) {
        self.pb.line_to(x * self.sx, y * self.sx)
    }
    fn quad_to(&mut self, a: f32, b: f32, x: f32, y: f32) {
        self.pb.quad_to(a * self.sx, b * self.sx, x * self.sx, y * self.sx)
    }
    fn curve_to(&mut self, a: f32, b: f32, c: f32, d: f32, x: f32, y: f32) {
        self.pb.cubic_to(a * self.sx, b * self.sx, c * self.sx, d * self.sx, x * self.sx, y * self.sx)
    }
    fn close(&mut self) {
        self.pb.close()
    }
}

#[derive(Default)]
pub struct GlyphCache {
    map: HashMap<(char, bool), (Option<Arc<Path>>, f32)>,
}

impl GlyphCache {
    pub fn get(&mut self, c: char, bold: bool) -> (Option<Arc<Path>>, f32) {
        if let Some(g) = self.map.get(&(c, bold)) {
            return g.clone();
        }
        let data = if bold { FONT_SANS_BOLD } else { FONT_SANS };
        let mut out = (None, 0.5);
        if let Ok(face) = Face::parse(data, 0) {
            let upem = face.units_per_em() as f32;
            let gid = face.glyph_index(c).or_else(|| face.glyph_index('?'));
            if let Some(g) = gid {
                let adv = face.glyph_hor_advance(g).unwrap_or(0) as f32 / upem;
                let mut b = Outline { pb: PathBuilder::new(), sx: 1.0 / upem };
                let ok = face.outline_glyph(g, &mut b).is_some();
                out = (if ok { b.pb.finish().map(Arc::new) } else { None }, adv);
            }
        }
        self.map.insert((c, bold), out.clone());
        out
    }
    pub fn width(&mut self, s: &str, size: f32, bold: bool) -> f32 {
        s.chars().map(|c| self.get(c, bold).1 * size).sum()
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Icon {
    Hand, Select, Highlight, Ink, Note, TextBox, Sign, Redact, EditText, Undo, Redo, Search, Command, Sidebar,
    Plus, Minus, Check, Close, Left, Right, Up, Down, Save, Open, Sun, Moon, Rotate, Trash, Bookmark, Pages,
    Outline, Fit, Continuous, Single, Two, Reading, Merge, Extract, Grip, More,
}

pub struct Painter<'a> {
    pub pm: &'a mut Pixmap,
    pub s: f32,
    pub g: &'a mut GlyphCache,
}

fn paint(c: Rgba) -> Paint<'static> {
    let mut p = Paint::default();
    p.set_color(c.c());
    p.anti_alias = true;
    p
}

pub fn rrect_path(x: f32, y: f32, w: f32, h: f32, r: f32) -> Option<Path> {
    let r = r.min(w / 2.0).min(h / 2.0).max(0.0);
    let mut pb = PathBuilder::new();
    if r < 0.5 {
        pb.push_rect(tiny_skia::Rect::from_xywh(x, y, w, h)?);
        return pb.finish();
    }
    let k = 0.5523 * r;
    pb.move_to(x + r, y);
    pb.line_to(x + w - r, y);
    pb.cubic_to(x + w - r + k, y, x + w, y + r - k, x + w, y + r);
    pb.line_to(x + w, y + h - r);
    pb.cubic_to(x + w, y + h - r + k, x + w - r + k, y + h, x + w - r, y + h);
    pb.line_to(x + r, y + h);
    pb.cubic_to(x + r - k, y + h, x, y + h - r + k, x, y + h - r);
    pb.line_to(x, y + r);
    pb.cubic_to(x, y + r - k, x + r - k, y, x + r, y);
    pb.close();
    pb.finish()
}

impl<'a> Painter<'a> {
    fn ts(&self) -> Transform {
        Transform::from_scale(self.s, self.s)
    }
    pub fn fill_rrect(&mut self, r: Rect, rad: f32, c: Rgba) {
        if let Some(p) = rrect_path(r.x, r.y, r.w, r.h, rad) {
            let ts = self.ts();
            self.pm.fill_path(&p, &paint(c), FillRule::Winding, ts, None);
        }
    }
    pub fn stroke_rrect(&mut self, r: Rect, rad: f32, w: f32, c: Rgba) {
        if let Some(p) = rrect_path(r.x + w / 2.0, r.y + w / 2.0, r.w - w, r.h - w, rad) {
            let ts = self.ts();
            self.pm.stroke_path(&p, &paint(c), &Stroke { width: w, ..Default::default() }, ts, None);
        }
    }
    pub fn shadow(&mut self, r: Rect, rad: f32, spread: f32, alpha: u8) {
        for i in 0..6 {
            let t = i as f32 / 5.0;
            let g = spread * (1.0 - t);
            let rr = Rect::new(r.x - g, r.y - g + spread * 0.35, r.w + 2.0 * g, r.h + 2.0 * g);
            self.fill_rrect(rr, rad + g, Rgba(0, 0, 0, (alpha as f32 * 0.16) as u8));
        }
    }
    pub fn fill_rect(&mut self, r: Rect, c: Rgba) {
        self.fill_rrect(r, 0.0, c)
    }
    pub fn line(&mut self, x0: f32, y0: f32, x1: f32, y1: f32, w: f32, c: Rgba) {
        let mut pb = PathBuilder::new();
        pb.move_to(x0, y0);
        pb.line_to(x1, y1);
        if let Some(p) = pb.finish() {
            let ts = self.ts();
            self.pm.stroke_path(&p, &paint(c), &Stroke { width: w, line_cap: LineCap::Round, ..Default::default() }, ts, None);
        }
    }
    pub fn polyline(&mut self, pts: &[(f32, f32)], w: f32, c: Rgba) {
        if pts.is_empty() {
            return;
        }
        let mut pb = PathBuilder::new();
        pb.move_to(pts[0].0, pts[0].1);
        if pts.len() == 1 {
            pb.line_to(pts[0].0 + 0.01, pts[0].1);
        }
        for p in &pts[1..] {
            pb.line_to(p.0, p.1);
        }
        if let Some(p) = pb.finish() {
            let ts = self.ts();
            self.pm.stroke_path(&p, &paint(c), &Stroke { width: w, line_cap: LineCap::Round, line_join: LineJoin::Round, ..Default::default() }, ts, None);
        }
    }
    pub fn circle(&mut self, cx: f32, cy: f32, r: f32, c: Rgba) {
        if let Some(p) = PathBuilder::from_circle(cx, cy, r) {
            let ts = self.ts();
            self.pm.fill_path(&p, &paint(c), FillRule::Winding, ts, None);
        }
    }
    pub fn ring(&mut self, cx: f32, cy: f32, r: f32, w: f32, c: Rgba) {
        if let Some(p) = PathBuilder::from_circle(cx, cy, r) {
            let ts = self.ts();
            self.pm.stroke_path(&p, &paint(c), &Stroke { width: w, ..Default::default() }, ts, None);
        }
    }

    pub fn text_w(&mut self, s: &str, size: f32, bold: bool) -> f32 {
        self.g.width(s, size, bold)
    }

    /// Draw text with its vertical centre at `yc`; returns the advance width.
    pub fn text(&mut self, x: f32, yc: f32, s: &str, size: f32, c: Rgba, bold: bool) -> f32 {
        let base = yc + size * 0.36;
        let mut cx = x;
        let p = paint(c);
        for ch in s.chars() {
            let (path, adv) = self.g.get(ch, bold);
            if let Some(path) = path {
                let ts = Transform::from_row(size * self.s, 0.0, 0.0, -size * self.s, cx * self.s, base * self.s);
                self.pm.fill_path(&path, &p, FillRule::Winding, ts, None);
            }
            cx += adv * size;
        }
        cx - x
    }

    pub fn text_center(&mut self, r: Rect, s: &str, size: f32, c: Rgba, bold: bool) {
        let w = self.text_w(s, size, bold);
        self.text(r.x + (r.w - w) / 2.0, r.y + r.h / 2.0, s, size, c, bold);
    }

    pub fn fit(&mut self, s: &str, max_w: f32, size: f32, bold: bool) -> String {
        if self.text_w(s, size, bold) <= max_w {
            return s.to_string();
        }
        let mut out = String::new();
        for ch in s.chars() {
            let t = format!("{out}{ch}…");
            if self.text_w(&t, size, bold) > max_w {
                break;
            }
            out.push(ch);
        }
        out.push('…');
        out
    }

    pub fn icon(&mut self, ic: Icon, r: Rect, c: Rgba) {
        let mut pb = PathBuilder::new();
        let mut fill = false;
        let sc = r.w.min(r.h) / 24.0;
        macro_rules! m { ($x:expr,$y:expr) => { pb.move_to($x, $y) }; }
        macro_rules! l { ($x:expr,$y:expr) => { pb.line_to($x, $y) }; }
        macro_rules! cu { ($a:expr,$b:expr,$c:expr,$d:expr,$e:expr,$f:expr) => { pb.cubic_to($a, $b, $c, $d, $e, $f) }; }
        match ic {
            Icon::Hand => {
                m!(7.0, 13.0); l!(7.0, 8.0); m!(10.5, 12.0); l!(10.5, 5.0); m!(14.0, 12.0); l!(14.0, 6.0); m!(17.0, 13.0); l!(17.0, 9.0);
                m!(7.0, 13.0); cu!(7.0, 19.0, 9.0, 20.0, 12.0, 20.0); cu!(15.0, 20.0, 17.0, 18.0, 17.0, 13.0);
            }
            Icon::Select => { m!(9.0, 5.0); l!(15.0, 5.0); m!(12.0, 5.0); l!(12.0, 19.0); m!(9.0, 19.0); l!(15.0, 19.0); }
            Icon::Highlight => { m!(14.0, 4.0); l!(20.0, 10.0); l!(11.0, 19.0); l!(6.0, 19.0); l!(6.0, 14.0); pb.close(); m!(5.0, 22.0); l!(19.0, 22.0); }
            Icon::Ink | Icon::EditText => { m!(4.0, 20.0); l!(5.0, 15.0); l!(16.0, 4.0); l!(20.0, 8.0); l!(9.0, 19.0); pb.close(); m!(14.0, 6.0); l!(18.0, 10.0); }
            Icon::Note => { m!(5.0, 5.0); l!(19.0, 5.0); l!(19.0, 15.0); l!(15.0, 19.0); l!(5.0, 19.0); pb.close(); m!(15.0, 19.0); l!(15.0, 15.0); l!(19.0, 15.0); }
            Icon::TextBox => { m!(5.0, 6.0); l!(19.0, 6.0); m!(12.0, 6.0); l!(12.0, 19.0); m!(9.0, 19.0); l!(15.0, 19.0); }
            Icon::Sign => { m!(4.0, 16.0); cu!(7.0, 6.0, 10.0, 6.0, 9.5, 13.0); cu!(9.0, 19.0, 12.5, 8.0, 14.0, 12.0); cu!(15.0, 15.0, 17.0, 14.0, 20.0, 10.0); m!(4.0, 20.0); l!(20.0, 20.0); }
            Icon::Redact => { fill = true; m!(4.0, 8.0); l!(20.0, 8.0); l!(20.0, 16.0); l!(4.0, 16.0); pb.close(); }
            Icon::Undo => { m!(8.0, 5.0); l!(4.0, 9.0); l!(8.0, 13.0); m!(4.0, 9.0); l!(14.0, 9.0); cu!(18.0, 9.0, 20.0, 11.0, 20.0, 14.0); cu!(20.0, 17.0, 18.0, 19.0, 14.0, 19.0); l!(9.0, 19.0); }
            Icon::Redo => { m!(16.0, 5.0); l!(20.0, 9.0); l!(16.0, 13.0); m!(20.0, 9.0); l!(10.0, 9.0); cu!(6.0, 9.0, 4.0, 11.0, 4.0, 14.0); cu!(4.0, 17.0, 6.0, 19.0, 10.0, 19.0); l!(15.0, 19.0); }
            Icon::Search => { if let Some(cp) = PathBuilder::from_circle(10.5, 10.5, 5.8) { pb.push_path(&cp); } m!(15.0, 15.0); l!(20.0, 20.0); }
            Icon::Command => { m!(8.0, 6.0); l!(8.0, 18.0); m!(17.0, 6.0); l!(9.0, 12.5); m!(11.5, 11.0); l!(17.0, 18.0); }
            Icon::Sidebar => { m!(4.0, 6.0); l!(20.0, 6.0); l!(20.0, 18.0); l!(4.0, 18.0); pb.close(); m!(9.5, 6.0); l!(9.5, 18.0); }
            Icon::Plus => { m!(12.0, 5.0); l!(12.0, 19.0); m!(5.0, 12.0); l!(19.0, 12.0); }
            Icon::Minus => { m!(5.0, 12.0); l!(19.0, 12.0); }
            Icon::Check => { m!(5.0, 12.5); l!(10.0, 17.0); l!(19.0, 7.0); }
            Icon::Close => { m!(6.0, 6.0); l!(18.0, 18.0); m!(18.0, 6.0); l!(6.0, 18.0); }
            Icon::Left => { m!(14.5, 6.0); l!(8.5, 12.0); l!(14.5, 18.0); }
            Icon::Right => { m!(9.5, 6.0); l!(15.5, 12.0); l!(9.5, 18.0); }
            Icon::Up => { m!(6.0, 14.5); l!(12.0, 8.5); l!(18.0, 14.5); }
            Icon::Down => { m!(6.0, 9.5); l!(12.0, 15.5); l!(18.0, 9.5); }
            Icon::Save => { m!(5.0, 4.0); l!(17.0, 4.0); l!(20.0, 7.0); l!(20.0, 20.0); l!(5.0, 20.0); pb.close(); m!(8.0, 4.0); l!(8.0, 9.0); l!(15.0, 9.0); l!(15.0, 4.0); m!(8.0, 20.0); l!(8.0, 14.0); l!(17.0, 14.0); l!(17.0, 20.0); }
            Icon::Open => { m!(4.0, 7.0); l!(10.0, 7.0); l!(12.0, 9.0); l!(20.0, 9.0); l!(20.0, 19.0); l!(4.0, 19.0); pb.close(); }
            Icon::Sun => {
                if let Some(cp) = PathBuilder::from_circle(12.0, 12.0, 3.8) { pb.push_path(&cp); }
                for i in 0..8 { let a = i as f32 * std::f32::consts::FRAC_PI_4; m!(12.0 + a.cos() * 6.8, 12.0 + a.sin() * 6.8); l!(12.0 + a.cos() * 9.0, 12.0 + a.sin() * 9.0); }
            }
            Icon::Moon => { m!(16.0, 4.0); cu!(10.0, 5.0, 7.0, 10.0, 9.0, 15.0); cu!(11.0, 19.0, 16.0, 20.0, 20.0, 17.0); cu!(14.0, 17.0, 11.0, 11.0, 16.0, 4.0); pb.close(); }
            Icon::Rotate => { m!(19.0, 12.0); cu!(19.0, 16.0, 15.5, 19.0, 12.0, 19.0); cu!(8.0, 19.0, 5.0, 16.0, 5.0, 12.0); cu!(5.0, 8.0, 8.0, 5.0, 12.0, 5.0); l!(15.5, 5.0); m!(13.0, 2.5); l!(15.8, 5.0); l!(13.0, 7.5); }
            Icon::Trash => { m!(5.0, 7.0); l!(19.0, 7.0); m!(9.0, 7.0); l!(9.0, 4.0); l!(15.0, 4.0); l!(15.0, 7.0); m!(7.0, 7.0); l!(8.0, 20.0); l!(16.0, 20.0); l!(17.0, 7.0); }
            Icon::Bookmark => { m!(7.0, 4.0); l!(17.0, 4.0); l!(17.0, 20.0); l!(12.0, 16.0); l!(7.0, 20.0); pb.close(); }
            Icon::Pages => { m!(8.0, 4.0); l!(18.0, 4.0); l!(18.0, 16.0); l!(8.0, 16.0); pb.close(); m!(6.0, 8.0); l!(6.0, 20.0); l!(14.0, 20.0); }
            Icon::Outline => { for i in 0..3 { let y = 7.0 + i as f32 * 5.0; m!(9.0, y); l!(20.0, y); m!(4.0, y); l!(5.0, y); } }
            Icon::Fit => { m!(4.0, 9.0); l!(4.0, 4.0); l!(9.0, 4.0); m!(15.0, 4.0); l!(20.0, 4.0); l!(20.0, 9.0); m!(20.0, 15.0); l!(20.0, 20.0); l!(15.0, 20.0); m!(9.0, 20.0); l!(4.0, 20.0); l!(4.0, 15.0); }
            Icon::Continuous => { for i in 0..3 { let y = 3.5 + i as f32 * 6.5; m!(7.0, y); l!(17.0, y); l!(17.0, y + 5.0); l!(7.0, y + 5.0); pb.close(); } }
            Icon::Single => { m!(7.0, 4.0); l!(17.0, 4.0); l!(17.0, 20.0); l!(7.0, 20.0); pb.close(); }
            Icon::Two => { m!(3.5, 6.0); l!(11.0, 6.0); l!(11.0, 18.0); l!(3.5, 18.0); pb.close(); m!(13.0, 6.0); l!(20.5, 6.0); l!(20.5, 18.0); l!(13.0, 18.0); pb.close(); }
            Icon::Reading => { m!(5.0, 7.0); l!(19.0, 7.0); m!(5.0, 11.0); l!(19.0, 11.0); m!(5.0, 15.0); l!(19.0, 15.0); m!(5.0, 19.0); l!(13.0, 19.0); }
            Icon::Merge => { m!(5.0, 5.0); cu!(5.0, 12.0, 12.0, 10.0, 12.0, 15.0); m!(19.0, 5.0); cu!(19.0, 12.0, 12.0, 10.0, 12.0, 15.0); m!(12.0, 15.0); l!(12.0, 20.0); }
            Icon::Extract => { m!(7.0, 4.0); l!(15.0, 4.0); l!(18.0, 7.0); l!(18.0, 20.0); l!(7.0, 20.0); pb.close(); m!(12.5, 17.0); l!(12.5, 10.0); m!(9.5, 13.0); l!(12.5, 10.0); l!(15.5, 13.0); }
            Icon::Grip => { fill = true; for i in 0..3 { for j in 0..2 { if let Some(cp) = PathBuilder::from_circle(9.0 + j as f32 * 6.0, 6.0 + i as f32 * 6.0, 1.3) { pb.push_path(&cp); } } } }
            Icon::More => { fill = true; for i in 0..3 { if let Some(cp) = PathBuilder::from_circle(6.0 + i as f32 * 6.0, 12.0, 1.6) { pb.push_path(&cp); } } }
        }
        let Some(path) = pb.finish() else { return };
        let ox = r.x + (r.w - 24.0 * sc) / 2.0;
        let oy = r.y + (r.h - 24.0 * sc) / 2.0;
        let ts = Transform::from_row(sc * self.s, 0.0, 0.0, sc * self.s, ox * self.s, oy * self.s);
        let p = paint(c);
        if fill {
            self.pm.fill_path(&path, &p, FillRule::Winding, ts, None);
        } else {
            self.pm.stroke_path(&path, &p, &Stroke { width: 1.7, line_cap: LineCap::Round, line_join: LineJoin::Round, ..Default::default() }, ts, None);
        }
    }
}
