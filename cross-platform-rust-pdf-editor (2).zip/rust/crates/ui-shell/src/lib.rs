//! `ui-shell` – platform-independent, adaptive PDF UI.
//!
//! The shell is a pure state machine: platforms feed it [`Event`]s, call
//! [`App::tick`], and ask it to [`App::render`] into a `tiny_skia::Pixmap`
//! (blitted by winit+softbuffer natively, by `<canvas>` on the web).
//! Effects (save file, open URL, pick file, clipboard) are returned to the host.

mod app;
mod chrome;
pub mod paint;
mod reflow;
mod tiles;
pub mod types;
pub mod util;

pub use app::{App, AppConfig, COLORS};
pub use pdf_render::MemoryBudget;
pub use tiles::TileService;
pub use types::*;
