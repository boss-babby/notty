//! Rendering: canvas pages + the adaptive chrome (desktop rail & pills,
//! tablet magnetic dock, mobile bottom pill & sheets), inspector, palette.

use crate::app::*;
use crate::paint::*;
use crate::tiles::{proxy_key, quantize_scale, PROXY_SCALE};
use crate::types::*;
use pdf_render::raster::draw_pixmap;
use pdf_render::{TileKey, TileSpec};
use tiny_skia::Pixmap;

pub(crate) struct Ui<'a> {
    pub p: Painter<'a>,
    pub hits: Vec<(Rect, Action)>,
    pub lists: Vec<(Rect, usize)>,
}

pub fn commands() -> Vec<(&'static str, &'static str, Action)> {
    let mut v: Vec<(&'static str, &'static str, Action)> = vec![
        ("Open PDF…", "Ctrl O", Action::Open),
        ("Open sample document", "", Action::OpenSample),
        ("Save (incremental update)", "Ctrl S", Action::Save),
        ("Undo", "Ctrl Z", Action::Undo),
        ("Redo", "Ctrl Shift Z", Action::Redo),
        ("Find in document", "Ctrl F", Action::Search),
        ("Zoom in", "Ctrl +", Action::ZoomIn),
        ("Zoom out", "Ctrl -", Action::ZoomOut),
        ("Fit width", "Ctrl 0", Action::FitWidth),
        ("Fit page", "", Action::FitPage),
        ("View: continuous", "", Action::SetMode(ViewMode::Continuous)),
        ("View: single page", "", Action::SetMode(ViewMode::Single)),
        ("View: two-page spread", "", Action::SetMode(ViewMode::TwoPage)),
        ("Toggle reading mode (reflow)", "", Action::Reading),
        ("Toggle sidebar / page list", "", Action::ToggleRail),
        ("Toggle dark / light theme", "", Action::ToggleTheme),
        ("Next page", "PgDn", Action::NextPage),
        ("Previous page", "PgUp", Action::PrevPage),
        ("Toggle bookmark on page", "", Action::Bookmark),
        ("Rotate page 90°", "", Action::RotatePage),
        ("Delete page", "", Action::DeletePage),
        ("Move page up", "", Action::MovePage(-1)),
        ("Move page down", "", Action::MovePage(1)),
        ("Extract page to new PDF", "", Action::ExtractPage),
        ("Merge another PDF…", "", Action::Merge),
        ("Copy selected text", "Ctrl C", Action::CopySel),
        ("Highlight selected text", "", Action::HighlightSel),
        ("Delete selected annotation", "Del", Action::DeleteAnnot),
    ];
    for t in Tool::ALL {
        v.push((
            match t {
                Tool::Hand => "Tool: Hand",
                Tool::Select => "Tool: Select text",
                Tool::Highlight => "Tool: Highlight",
                Tool::Ink => "Tool: Draw (ink)",
                Tool::Note => "Tool: Sticky note",
                Tool::TextBox => "Tool: Text box",
                Tool::Sign => "Tool: Sign",
                Tool::Redact => "Tool: Redact",
                Tool::EditText => "Tool: Edit text",
            },
            "",
            Action::SetTool(t),
        ));
    }
    v
}

fn tool_icon(t: Tool) -> Icon {
    match t {
        Tool::Hand => Icon::Hand,
        Tool::Select => Icon::Select,
        Tool::Highlight => Icon::Highlight,
        Tool::Ink => Icon::Ink,
        Tool::Note => Icon::Note,
        Tool::TextBox => Icon::TextBox,
        Tool::Sign => Icon::Sign,
        Tool::Redact => Icon::Redact,
        Tool::EditText => Icon::EditText,
    }
}

fn col(c: [f32; 3]) -> Rgba {
    Rgba((c[0] * 255.0) as u8, (c[1] * 255.0) as u8, (c[2] * 255.0) as u8, 255)
}

impl App {
    pub fn render(&mut self, pm: &mut Pixmap) {
        let mut glyphs = std::mem::take(&mut self.glyphs);
        let th = self.th;
        pm.fill(th.canvas.c());
        let mut ui = Ui { p: Painter { pm, s: self.dpr, g: &mut glyphs }, hits: Vec::new(), lists: Vec::new() };
        if self.loaded.is_none() {
            self.draw_empty(&mut ui);
        } else if self.view.reading {
            self.draw_reading(&mut ui);
        } else {
            self.draw_pages(&mut ui);
        }
        if self.loaded.is_some() {
            self.draw_chrome(&mut ui);
        }
        self.draw_palette(&mut ui);
        self.draw_toast(&mut ui);
        let (hits, lists) = (ui.hits, ui.lists);
        drop(ui.p);
        self.hits = hits;
        self.lists = lists;
        self.glyphs = glyphs;
        self.dirty = false;
    }

    // ------------------------------------------------------------ helpers
    fn glass(&self, ui: &mut Ui, r: Rect, rad: f32) {
        ui.p.shadow(r, rad, 16.0, 90);
        ui.p.fill_rrect(r, rad, self.th.glass);
        ui.p.stroke_rrect(r, rad, 1.0, self.th.border);
        ui.hits.push((r, Action::Noop));
    }

    fn btn(&self, ui: &mut Ui, r: Rect, ic: Icon, active: bool, a: Action) {
        let th = self.th;
        let hov = r.contains(self.hover.0, self.hover.1);
        if active {
            ui.p.fill_rrect(r, 9.0, th.accent.alpha(0.2));
        } else if hov {
            ui.p.fill_rrect(r, 9.0, th.hover);
        }
        ui.p.icon(ic, r.inset(r.w * 0.2), if active { th.accent } else { th.text });
        ui.hits.push((r, a));
    }

    fn pill_btn(&self, ui: &mut Ui, r: Rect, label: &str, primary: bool, a: Action) {
        let th = self.th;
        let hov = r.contains(self.hover.0, self.hover.1);
        if primary {
            ui.p.fill_rrect(r, 9.0, if hov { th.accent.mix(Rgba(255, 255, 255, 255), 0.15) } else { th.accent });
            ui.p.text_center(r, label, 13.0, th.accent_fg, true);
        } else {
            ui.p.fill_rrect(r, 9.0, if hov { th.hover } else { th.hover.alpha(0.6) });
            ui.p.stroke_rrect(r, 9.0, 1.0, th.border);
            ui.p.text_center(r, label, 13.0, th.text, false);
        }
        ui.hits.push((r, a));
    }

    fn sep(&self, ui: &mut Ui, x: f32, y: f32, h: f32) {
        ui.p.line(x, y + 8.0, x, y + h - 8.0, 1.0, self.th.border);
    }

    // ---------------------------------------------------------- empty state
    fn draw_empty(&mut self, ui: &mut Ui) {
        let th = self.th;
        let w = (self.w - 32.0).min(460.0);
        let r = Rect::new((self.w - w) / 2.0, (self.h - 300.0) / 2.0, w, 300.0);
        self.glass(ui, r, 20.0);
        ui.p.text_center(Rect::new(r.x, r.y + 30.0, r.w, 40.0), "PDF Studio", 28.0, th.text, true);
        ui.p.text_center(Rect::new(r.x, r.y + 72.0, r.w, 24.0), "Pure Rust · one codebase · every screen", 13.0, th.dim, false);
        let bw = (r.w - 60.0).min(300.0);
        self.pill_btn(ui, Rect::new(r.x + (r.w - bw) / 2.0, r.y + 120.0, bw, 44.0), "Open PDF…", true, Action::Open);
        self.pill_btn(ui, Rect::new(r.x + (r.w - bw) / 2.0, r.y + 174.0, bw, 44.0), "Open sample document", false, Action::OpenSample);
        ui.p.text_center(Rect::new(r.x, r.y + 240.0, r.w, 20.0), "Drop a PDF anywhere · Ctrl+O to browse · Ctrl+K for commands", 11.0, th.dim, false);
    }

    // --------------------------------------------------------------- pages
    fn draw_pages(&mut self, ui: &mut Ui) {
        let th = self.th;
        let Some(l) = self.loaded.as_ref() else { return };
        let tiles = l.tiles.clone();
        let doc_id = l.doc.id;
        let rects = l.rects.clone();
        let c = self.canvas();
        let z = self.view.zoom;
        let dpr = self.dpr;
        let s_dev = z * dpr;
        let exact = self.now - self.last_zoom_t > 180.0 && self.drag_idle();
        let rs = if exact { ((s_dev * 1000.0).round() / 1000.0).clamp(0.1, 24.0) } else { quantize_scale(s_dev) };
        let tile_px = tiles.budget.tile_px as i32;
        let mut wanted: Vec<(f32, TileKey, TileSpec)> = Vec::new();
        let center = (c.x + c.w / 2.0, c.y + c.h / 2.0);
        let pages = self.visible_pages();
        for &pg in &pages {
            let r = rects[pg];
            let (sx0, sy0) = self.from_doc(r.x, r.y);
            let (ox, oy) = ((sx0 * dpr).round(), (sy0 * dpr).round());
            let pr = Rect::new(ox / dpr, oy / dpr, r.w * z, r.h * z);
            ui.p.shadow(pr, 2.0, 12.0, if th.dark { 150 } else { 70 });
            ui.p.fill_rect(pr, Rgba(255, 255, 255, 255));
            let rev = tiles.rev(pg);
            let pk = proxy_key(doc_id, pg, rev);
            match tiles.tile(&pk) {
                Some(t) => draw_pixmap(ui.p.pm, &t, ox, oy, s_dev / PROXY_SCALE, true),
                None => {
                    let spec = TileSpec { scale: PROXY_SCALE, x: 0, y: 0, w: (r.w * PROXY_SCALE).ceil() as u32, h: (r.h * PROXY_SCALE).ceil() as u32 };
                    wanted.push((-1.0, pk, spec));
                }
            }
            let (pw, ph) = ((r.w * rs).ceil() as i32, (r.h * rs).ceil() as i32);
            let vx0 = ((c.x - sx0) / z).max(0.0);
            let vx1 = ((c.x + c.w - sx0) / z).min(r.w);
            let vy0 = ((c.y - sy0) / z).max(0.0);
            let vy1 = ((c.y + c.h - sy0) / z).min(r.h);
            if vx1 <= vx0 || vy1 <= vy0 {
                continue;
            }
            let (tx0, tx1) = (((vx0 * rs) as i32) / tile_px, (((vx1 * rs) as i32).min(pw - 1)).max(0) / tile_px);
            let (ty0, ty1) = (((vy0 * rs) as i32) / tile_px, (((vy1 * rs) as i32).min(ph - 1)).max(0) / tile_px);
            for ty in ty0..=ty1 {
                for tx in tx0..=tx1 {
                    let (x, y) = (tx * tile_px, ty * tile_px);
                    let (w, h) = (tile_px.min(pw - x), tile_px.min(ph - y));
                    if w <= 0 || h <= 0 {
                        continue;
                    }
                    let key = TileKey { doc: doc_id, page: pg as u32, scale_q: (rs * 1000.0).round() as i32, tx, ty, rev };
                    let ratio = s_dev / rs;
                    if let Some(t) = tiles.tile(&key) {
                        let smooth = (ratio - 1.0).abs() > 0.004;
                        draw_pixmap(ui.p.pm, &t, ox + x as f32 * ratio, oy + y as f32 * ratio, ratio, smooth);
                    }
                    if !tiles.has_exact(&key) {
                        let (cx, cy) = (ox / dpr + (x as f32 + w as f32 / 2.0) / rs * z, oy / dpr + (y as f32 + h as f32 / 2.0) / rs * z);
                        let d = (cx - center.0).powi(2) + (cy - center.1).powi(2);
                        wanted.push((d, key, TileSpec { scale: rs, x, y, w: w as u32, h: h as u32 }));
                    }
                }
            }
        }
        wanted.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
        let cap = tiles.budget.max_inflight * 2;
        for (_, key, spec) in wanted {
            if tiles.inflight() >= cap {
                break;
            }
            tiles.request(key, spec);
        }
        for &pg in &pages {
            self.draw_overlays(ui, pg);
        }
        self.draw_drag_overlay(ui);
    }

    fn drag_idle(&self) -> bool {
        self.touches.count() == 0
    }

    fn draw_overlays(&self, ui: &mut Ui, pg: usize) {
        let th = self.th;
        let Some(l) = self.loaded.as_ref() else { return };
        let z = self.view.zoom;
        let scr = |r: [f32; 4]| -> Rect {
            let (x, y) = self.page_to_screen(pg, r[0], r[1]);
            Rect::new(x, y, (r[2] - r[0]) * z, (r[3] - r[1]) * z)
        };
        // search matches
        if let Some(ms) = self.search.per_page.get(pg) {
            let mut base = 0;
            for p in 0..pg {
                base += self.search.per_page[p].len();
            }
            for (i, m) in ms.iter().enumerate() {
                let cur = base + i == self.search.cur;
                for r in m {
                    ui.p.fill_rrect(scr(*r), 2.0, if cur { Rgba(255, 140, 0, 120) } else { Rgba(255, 214, 10, 105) });
                }
            }
        }
        let Some(dl) = l.tiles.dl_peek(pg) else { return };
        // selection
        if let Selection::Text { page, range } = &self.sel {
            if *page == pg {
                for r in dl.page_text().rects(*range) {
                    ui.p.fill_rect(scr(r), th.accent.alpha(0.3));
                }
            }
        }
        if let Selection::Run { page, run } = &self.sel {
            if *page == pg {
                if let Some(r) = dl.runs.get(*run) {
                    ui.p.stroke_rrect(scr(r.rect), 2.0, 1.5, th.accent);
                }
            }
        }
        if let Selection::Annot { page, id, .. } = &self.sel {
            if *page == pg {
                if let Some(a) = dl.annots.iter().find(|a| a.id == *id) {
                    ui.p.stroke_rrect(scr(a.rect).inset(-3.0), 4.0, 1.5, th.accent);
                }
            }
        }
        if matches!(self.tool, Tool::Hand | Tool::Select) {
            for a in &dl.annots {
                if a.field.is_some() {
                    let r = scr(a.rect);
                    ui.p.fill_rect(r, th.accent.alpha(0.07));
                }
            }
        }
        if self.tool == Tool::EditText {
            for r in dl.runs.iter().filter(|r| r.op_index.is_some()) {
                ui.p.stroke_rrect(scr(r.rect), 1.0, 0.7, th.accent.alpha(0.35));
            }
        }
    }

    fn draw_drag_overlay(&self, ui: &mut Ui) {
        let th = self.th;
        match &self.drag {
            Drag::Stroke { page, pts } => {
                let sc: Vec<(f32, f32)> = pts.iter().map(|(x, y)| self.page_to_screen(*page, *x, *y)).collect();
                let c = if self.tool == Tool::Sign { Rgba(14, 30, 115, 255) } else { col(COLORS[self.color]) };
                ui.p.polyline(&sc, WIDTHS[self.width_i.min(2)] * self.view.zoom, c);
            }
            Drag::Rect { page, a, b } => {
                let (x0, y0) = self.page_to_screen(*page, a.0.min(b.0), a.1.min(b.1));
                let (x1, y1) = self.page_to_screen(*page, a.0.max(b.0), a.1.max(b.1));
                let r = Rect::new(x0, y0, x1 - x0, y1 - y0);
                if self.tool == Tool::Redact {
                    ui.p.fill_rect(r, Rgba(0, 0, 0, 170));
                } else {
                    ui.p.fill_rect(r, th.accent.alpha(0.12));
                }
                ui.p.stroke_rrect(r, 0.0, 1.5, if self.tool == Tool::Redact { Rgba(255, 60, 60, 255) } else { th.accent });
            }
            _ => {}
        }
    }

    // -------------------------------------------------------- reading mode
    fn draw_reading(&mut self, ui: &mut Ui) {
        let th = self.th;
        let colw = (self.w - 40.0).min(680.0);
        let x0 = (self.w - colw) / 2.0;
        let cur = self.view.cur;
        let base = if self.bp() == Bp::Mobile { 17.0 } else { 19.0 };
        let lines = match self.loaded.as_mut() {
            Some(l) => l.reflow_page(cur, colw, base),
            None => return,
        };
        let total: f32 = lines.iter().map(|l| l.gap_before + l.size * 1.55).sum();
        let maxy = (total + self.top_inset() + self.bottom_inset() + 80.0 - self.h).max(0.0);
        self.view.reading_y = self.view.reading_y.min(maxy);
        let mut y = self.top_inset() + 20.0 - self.view.reading_y;
        ui.p.fill_rect(Rect::new(0.0, 0.0, self.w, self.h), th.panel);
        if lines.is_empty() {
            ui.p.text_center(Rect::new(0.0, self.h / 2.0 - 20.0, self.w, 40.0), "No extractable text on this page", 14.0, th.dim, false);
        }
        for ln in lines.iter() {
            y += ln.gap_before;
            if y > -40.0 && y < self.h + 20.0 {
                ui.p.text(x0, y + ln.size * 0.6, &ln.text, ln.size, th.text, ln.bold);
            }
            y += ln.size * 1.55;
        }
        let n = self.page_count();
        if y > -40.0 && y < self.h - 40.0 && cur + 1 < n {
            self.pill_btn(ui, Rect::new((self.w - 160.0) / 2.0, y + 16.0, 160.0, 40.0), "Next page", true, Action::NextPage);
        }
    }

    // --------------------------------------------------------------- chrome
    fn draw_chrome(&mut self, ui: &mut Ui) {
        match self.bp() {
            Bp::Desktop => self.chrome_desktop(ui),
            Bp::Tablet => self.chrome_tablet(ui),
            Bp::Mobile => self.chrome_mobile(ui),
        }
        self.draw_selection_bar(ui);
        self.draw_inspector(ui);
    }

    fn page_label(&self) -> String {
        format!("{} / {}", self.view.cur + 1, self.page_count().max(1))
    }

    fn chrome_desktop(&mut self, ui: &mut Ui) {
        let th = self.th;
        let wv = RAIL_W * self.rail.v;
        if wv > 2.0 {
            let off = wv - RAIL_W;
            let panel = Rect::new(0.0, 0.0, wv, self.h);
            ui.p.fill_rect(panel, th.panel);
            ui.p.line(wv, 0.0, wv, self.h, 1.0, th.border);
            ui.hits.push((panel, Action::Noop));
            self.draw_rail_content(ui, Rect::new(off, 0.0, RAIL_W, self.h));
        }
        // top tool pill
        let c = self.canvas();
        let bw = 38.0;
        let n_tools = Tool::ALL.len() as f32;
        let width = bw * (1.0 + n_tools + 4.0) + 3.0 * 14.0 + 16.0;
        let pill = Rect::new(c.x + (c.w - width) / 2.0, 14.0, width, 46.0);
        self.glass(ui, pill, 23.0);
        let mut x = pill.x + 8.0;
        let y = pill.y + 4.0;
        self.btn(ui, Rect::new(x, y, bw, 38.0), Icon::Sidebar, self.rail.target > 0.5, Action::ToggleRail);
        x += bw + 7.0;
        self.sep(ui, x, pill.y, pill.h);
        x += 7.0;
        for t in Tool::ALL {
            self.btn(ui, Rect::new(x, y, bw, 38.0), tool_icon(t), self.tool == t, Action::SetTool(t));
            x += bw;
        }
        x += 7.0;
        self.sep(ui, x, pill.y, pill.h);
        x += 7.0;
        let (cu, cr) = self.loaded.as_ref().map_or((false, false), |l| (l.editor.can_undo(), l.editor.can_redo()));
        self.btn(ui, Rect::new(x, y, bw, 38.0), Icon::Undo, false, if cu { Action::Undo } else { Action::Noop });
        x += bw;
        self.btn(ui, Rect::new(x, y, bw, 38.0), Icon::Redo, false, if cr { Action::Redo } else { Action::Noop });
        x += bw + 7.0;
        self.sep(ui, x, pill.y, pill.h);
        x += 7.0;
        self.btn(ui, Rect::new(x, y, bw, 38.0), Icon::Search, self.sheet == Some(SheetKind::Search), Action::Search);
        x += bw;
        self.btn(ui, Rect::new(x, y, bw, 38.0), Icon::Command, self.palette, Action::Palette);
        self.style_strip(ui, Rect::new(c.x, pill.bottom() + 10.0, c.w, 40.0));
        // bottom pill
        let items_w = 36.0 * 14.0 + 130.0 + 3.0 * 12.0;
        let bp = Rect::new(c.x + (c.w - items_w) / 2.0, self.h - 62.0, items_w, 46.0);
        self.glass(ui, bp, 23.0);
        let mut x = bp.x + 8.0;
        let y = bp.y + 5.0;
        let b = |x: f32, w: f32| Rect::new(x, y, w, 36.0);
        self.btn(ui, b(x, 36.0), Icon::Left, false, Action::PrevPage);
        x += 36.0;
        let lab = self.page_label();
        ui.p.text_center(b(x, 64.0), &lab, 13.0, th.text, true);
        x += 64.0;
        self.btn(ui, b(x, 36.0), Icon::Right, false, Action::NextPage);
        x += 40.0;
        self.sep(ui, x, bp.y, bp.h);
        x += 6.0;
        self.btn(ui, b(x, 36.0), Icon::Minus, false, Action::ZoomOut);
        x += 36.0;
        let zl = format!("{}%", (self.view.zoom * 100.0).round() as i32);
        ui.p.text_center(b(x, 50.0), &zl, 12.0, th.dim, false);
        x += 50.0;
        self.btn(ui, b(x, 36.0), Icon::Plus, false, Action::ZoomIn);
        x += 36.0;
        self.btn(ui, b(x, 36.0), Icon::Fit, self.view.fit.is_some(), if self.view.fit == Some(true) { Action::FitPage } else { Action::FitWidth });
        x += 42.0;
        self.sep(ui, x, bp.y, bp.h);
        x += 6.0;
        for (ic, m) in [(Icon::Continuous, ViewMode::Continuous), (Icon::Single, ViewMode::Single), (Icon::Two, ViewMode::TwoPage)] {
            self.btn(ui, b(x, 36.0), ic, self.view.mode == m && !self.view.reading, Action::SetMode(m));
            x += 36.0;
        }
        self.btn(ui, b(x, 36.0), Icon::Reading, self.view.reading, Action::Reading);
        x += 36.0;
        let bm = self.loaded.as_ref().map_or(false, |l| l.bookmarks.contains(&self.view.cur));
        self.btn(ui, b(x, 36.0), Icon::Bookmark, bm, Action::Bookmark);
        x += 42.0;
        self.sep(ui, x, bp.y, bp.h);
        x += 6.0;
        self.btn(ui, b(x, 36.0), Icon::Open, false, Action::Open);
        x += 36.0;
        let dirty = self.loaded.as_ref().map_or(false, |l| l.editor.is_dirty());
        self.btn(ui, b(x, 36.0), Icon::Save, dirty, Action::Save);
        x += 36.0;
        self.btn(ui, b(x, 36.0), if th.dark { Icon::Sun } else { Icon::Moon }, false, Action::ToggleTheme);
    }

    fn style_strip(&self, ui: &mut Ui, area: Rect) {
        if !self.tool.has_style() {
            return;
        }
        let th = self.th;
        let w = 6.0 * 30.0 + 3.0 * 34.0 + 30.0;
        let r = Rect::new(area.x + (area.w - w) / 2.0, area.y, w, 38.0);
        self.glass(ui, r, 19.0);
        let mut x = r.x + 12.0;
        for (i, c) in COLORS.iter().enumerate() {
            let cx = x + 12.0;
            let cy = r.y + 19.0;
            if self.color == i {
                ui.p.ring(cx, cy, 12.0, 2.0, th.accent);
            }
            ui.p.circle(cx, cy, 8.5, col(*c));
            ui.hits.push((Rect::new(x, r.y + 4.0, 26.0, 30.0), Action::Color(i)));
            x += 30.0;
        }
        x += 4.0;
        self.sep(ui, x, r.y, r.h);
        x += 8.0;
        if self.tool == Tool::Ink {
            for (i, wd) in WIDTHS.iter().enumerate() {
                let rr = Rect::new(x, r.y + 3.0, 32.0, 32.0);
                if self.width_i == i {
                    ui.p.fill_rrect(rr, 8.0, th.accent.alpha(0.2));
                }
                ui.p.line(x + 7.0, r.y + 19.0, x + 25.0, r.y + 19.0, wd + 0.5, th.text);
                ui.hits.push((rr, Action::Width(i)));
                x += 34.0;
            }
        }
    }

    fn chrome_tablet(&mut self, ui: &mut Ui) {
        let th = self.th;
        // top-right chip
        let chip = Rect::new(self.w - 8.0 - 262.0, 10.0, 262.0, 44.0);
        self.glass(ui, chip, 22.0);
        let mut x = chip.x + 6.0;
        self.btn(ui, Rect::new(x, chip.y + 4.0, 36.0, 36.0), Icon::Pages, self.sheet == Some(SheetKind::Pages), Action::Sheet(SheetKind::Pages));
        x += 38.0;
        let lab = self.page_label();
        ui.p.text_center(Rect::new(x, chip.y + 4.0, 62.0, 36.0), &lab, 12.5, th.text, true);
        x += 62.0;
        self.btn(ui, Rect::new(x, chip.y + 4.0, 36.0, 36.0), Icon::Search, self.sheet == Some(SheetKind::Search), Action::Sheet(SheetKind::Search));
        x += 38.0;
        self.btn(ui, Rect::new(x, chip.y + 4.0, 36.0, 36.0), Icon::Command, self.palette, Action::Palette);
        x += 38.0;
        self.btn(ui, Rect::new(x, chip.y + 4.0, 36.0, 36.0), if th.dark { Icon::Sun } else { Icon::Moon }, false, Action::ToggleTheme);
        // magnetic dock
        let n = Tool::ALL.len() as f32 + 3.0;
        let cell = 40.0;
        let (dw, dh) = if self.dock_vertical { (52.0, n * cell + 34.0) } else { (n * cell + 34.0, 52.0) };
        let dock = Rect::new(self.dock_x.v - dw / 2.0, self.dock_y.v - dh / 2.0, dw, dh);
        self.glass(ui, dock, 26.0);
        let mut pos = if self.dock_vertical { (dock.x + 6.0, dock.y + 4.0) } else { (dock.x + 4.0, dock.y + 6.0) };
        let step = |p: &mut (f32, f32), v: bool, d: f32| {
            if v {
                p.1 += d
            } else {
                p.0 += d
            }
        };
        let grip = Rect::new(pos.0, pos.1, 40.0, 30.0);
        ui.p.icon(Icon::Grip, grip.inset(5.0), th.dim);
        ui.hits.push((grip, Action::DockGrip));
        step(&mut pos, self.dock_vertical, 30.0);
        for t in Tool::ALL {
            self.btn(ui, Rect::new(pos.0, pos.1, 40.0, 40.0), tool_icon(t), self.tool == t, Action::SetTool(t));
            step(&mut pos, self.dock_vertical, cell);
        }
        let (cu, cr) = self.loaded.as_ref().map_or((false, false), |l| (l.editor.can_undo(), l.editor.can_redo()));
        self.btn(ui, Rect::new(pos.0, pos.1, 40.0, 40.0), Icon::Undo, false, if cu { Action::Undo } else { Action::Noop });
        step(&mut pos, self.dock_vertical, cell);
        self.btn(ui, Rect::new(pos.0, pos.1, 40.0, 40.0), Icon::Redo, false, if cr { Action::Redo } else { Action::Noop });
        step(&mut pos, self.dock_vertical, cell);
        self.btn(ui, Rect::new(pos.0, pos.1, 40.0, 40.0), Icon::Save, self.loaded.as_ref().map_or(false, |l| l.editor.is_dirty()), Action::Save);
        self.style_strip(ui, Rect::new(0.0, 62.0, self.w, 40.0));
        self.draw_sheet(ui);
    }

    fn chrome_mobile(&mut self, ui: &mut Ui) {
        let th = self.th;
        let lab = self.page_label();
        let chip = Rect::new((self.w - 96.0) / 2.0, 10.0, 96.0, 34.0);
        self.glass(ui, chip, 17.0);
        ui.p.text_center(chip, &lab, 13.0, th.text, true);
        ui.hits.push((chip, Action::Sheet(SheetKind::Pages)));
        // thumb-zone action pill
        let n = 6.0;
        let w = (self.w - 24.0).min(n * 54.0 + 20.0);
        let bp = Rect::new((self.w - w) / 2.0, self.h - 70.0, w, 56.0);
        self.glass(ui, bp, 28.0);
        let cell = (w - 12.0) / n;
        let items: [(Icon, bool, Action); 6] = [
            (tool_icon(self.tool), self.sheet == Some(SheetKind::Tools), Action::Sheet(SheetKind::Tools)),
            (Icon::Search, self.sheet == Some(SheetKind::Search), Action::Sheet(SheetKind::Search)),
            (Icon::Pages, self.sheet == Some(SheetKind::Pages), Action::Sheet(SheetKind::Pages)),
            (Icon::Reading, self.view.reading, Action::Reading),
            (Icon::Undo, false, Action::Undo),
            (Icon::Command, self.palette, Action::Palette),
        ];
        for (i, (ic, active, a)) in items.into_iter().enumerate() {
            self.btn(ui, Rect::new(bp.x + 6.0 + i as f32 * cell, bp.y + 6.0, cell, 44.0), ic, active, a);
        }
        self.style_strip(ui, Rect::new(0.0, 54.0, self.w, 40.0));
        self.draw_sheet(ui);
    }

    // ---------------------------------------------------------------- sheet
    fn draw_sheet(&mut self, ui: &mut Ui) {
        let Some(kind) = self.sheet else { return };
        let th = self.th;
        let f = self.sheet_f.v.clamp(0.0, 0.95);
        if f < 0.02 {
            return;
        }
        let sw = if self.bp() == Bp::Mobile { self.w } else { 600.0f32.min(self.w - 16.0) };
        let h = f * self.h;
        let r = Rect::new((self.w - sw) / 2.0, self.h - h, sw, h + 20.0);
        ui.p.shadow(r, 22.0, 24.0, 120);
        ui.p.fill_rrect(r, 22.0, th.panel);
        ui.p.stroke_rrect(r, 22.0, 1.0, th.border);
        ui.hits.push((r, Action::Noop));
        let grip = Rect::new(r.x, r.y, r.w, 30.0);
        ui.p.fill_rrect(Rect::new(r.x + r.w / 2.0 - 18.0, r.y + 10.0, 36.0, 4.0), 2.0, th.dim.alpha(0.6));
        ui.hits.push((grip, Action::SheetGrip));
        let body = Rect::new(r.x, r.y + 30.0, r.w, (r.h - 30.0 - 20.0).max(0.0));
        match kind {
            SheetKind::Tools => self.sheet_tools(ui, body),
            SheetKind::Search => self.search_panel(ui, body),
            SheetKind::Pages => {
                let tabs_h = 44.0;
                self.rail_tabs(ui, Rect::new(body.x, body.y, body.w, tabs_h));
                self.rail_list(ui, Rect::new(body.x, body.y + tabs_h, body.w, body.h - tabs_h));
            }
        }
    }

    fn sheet_tools(&mut self, ui: &mut Ui, r: Rect) {
        let th = self.th;
        let pad = 16.0;
        let cols = 3;
        let cw = (r.w - pad * 2.0 - 10.0 * (cols as f32 - 1.0)) / cols as f32;
        for (i, t) in Tool::ALL.iter().enumerate() {
            let (cx, cy) = (i % cols, i / cols);
            let rr = Rect::new(r.x + pad + cx as f32 * (cw + 10.0), r.y + 6.0 + cy as f32 * 70.0, cw, 62.0);
            let active = self.tool == *t;
            ui.p.fill_rrect(rr, 12.0, if active { th.accent.alpha(0.2) } else { th.hover });
            ui.p.icon(tool_icon(*t), Rect::new(rr.x + rr.w / 2.0 - 12.0, rr.y + 8.0, 24.0, 24.0), if active { th.accent } else { th.text });
            ui.p.text_center(Rect::new(rr.x, rr.y + 36.0, rr.w, 20.0), t.label(), 11.5, if active { th.accent } else { th.dim }, false);
            ui.hits.push((rr, Action::SetTool(*t)));
        }
        let mut y = r.y + 6.0 + 3.0 * 70.0 + 6.0;
        let mut x = r.x + pad;
        for (i, c) in COLORS.iter().enumerate() {
            if self.color == i {
                ui.p.ring(x + 14.0, y + 14.0, 14.0, 2.0, th.accent);
            }
            ui.p.circle(x + 14.0, y + 14.0, 10.0, col(*c));
            ui.hits.push((Rect::new(x, y, 30.0, 30.0), Action::Color(i)));
            x += 38.0;
        }
        for (i, wd) in WIDTHS.iter().enumerate() {
            let rr = Rect::new(x + 10.0, y, 34.0, 30.0);
            if self.width_i == i {
                ui.p.fill_rrect(rr, 8.0, th.accent.alpha(0.2));
            }
            ui.p.line(rr.x + 8.0, rr.y + 15.0, rr.x + 26.0, rr.y + 15.0, wd + 0.5, th.text);
            ui.hits.push((rr, Action::Width(i)));
            x += 36.0;
        }
        y += 44.0;
        let bw = (r.w - pad * 2.0 - 8.0 * 2.0) / 3.0;
        let acts: [(&str, Action); 9] = [
            ("Open", Action::Open),
            ("Save", Action::Save),
            ("Theme", Action::ToggleTheme),
            ("Continuous", Action::SetMode(ViewMode::Continuous)),
            ("Single", Action::SetMode(ViewMode::Single)),
            ("Two-page", Action::SetMode(ViewMode::TwoPage)),
            ("Rotate page", Action::RotatePage),
            ("Delete page", Action::DeletePage),
            ("Bookmark", Action::Bookmark),
        ];
        for (i, (label, a)) in acts.into_iter().enumerate() {
            let rr = Rect::new(r.x + pad + (i % 3) as f32 * (bw + 8.0), y + (i / 3) as f32 * 46.0, bw, 38.0);
            if rr.bottom() < r.bottom() {
                self.pill_btn(ui, rr, label, false, a);
            }
        }
    }

    // ----------------------------------------------------------- rail lists
    fn draw_rail_content(&mut self, ui: &mut Ui, r: Rect) {
        if self.sheet == Some(SheetKind::Search) && self.bp() == Bp::Desktop {
            self.search_panel(ui, r);
            return;
        }
        self.rail_tabs(ui, Rect::new(r.x, r.y + 70.0, r.w, 44.0));
        self.rail_list(ui, Rect::new(r.x, r.y + 70.0 + 44.0, r.w, r.h - 114.0));
        // title
        let th = self.th;
        let name = self.loaded.as_ref().map(|l| l.name.clone()).unwrap_or_default();
        let t = ui.p.fit(&name, r.w - 32.0, 14.0, true);
        ui.p.text(r.x + 16.0, 28.0, &t, 14.0, th.text, true);
        let n = self.page_count();
        ui.p.text(r.x + 16.0, 50.0, &format!("{n} page{}", if n == 1 { "" } else { "s" }), 12.0, th.dim, false);
    }

    fn rail_tabs(&mut self, ui: &mut Ui, r: Rect) {
        let th = self.th;
        let tabs = [(RailTab::Pages, "Pages"), (RailTab::Outline, "Outline"), (RailTab::Marks, "Marks")];
        let w = (r.w - 24.0) / 3.0;
        for (i, (t, label)) in tabs.iter().enumerate() {
            let rr = Rect::new(r.x + 12.0 + i as f32 * w, r.y + 4.0, w - 4.0, 34.0);
            let active = self.rail_tab == *t;
            ui.p.fill_rrect(rr, 9.0, if active { th.accent.alpha(0.18) } else { th.hover.alpha(0.0) });
            ui.p.text_center(rr, label, 12.5, if active { th.accent } else { th.dim }, active);
            ui.hits.push((rr, Action::RailTab(*t)));
        }
    }

    fn rail_list(&mut self, ui: &mut Ui, r: Rect) {
        let th = self.th;
        ui.lists.push((r, 0));
        match self.rail_tab {
            RailTab::Pages => {
                let Some(l) = self.loaded.as_ref() else { return };
                let n = l.sizes.len();
                let tiles = l.tiles.clone();
                let doc_id = l.doc.id;
                let ratio = l.sizes.first().map_or(1.4, |s| s.1 / s.0.max(1.0)).clamp(0.5, 2.0);
                let pad = 14.0;
                let cols = (((r.w - pad) / 150.0).floor() as usize).clamp(1, 4);
                let tw = ((r.w - pad * (cols as f32 + 1.0)) / cols as f32).min(150.0);
                let th_ = tw * ratio;
                let row_h = th_ + 34.0;
                let rows = (n + cols - 1) / cols;
                let total = rows as f32 * row_h + pad;
                let max_scroll = (total - r.h).max(0.0);
                self.rail_scroll[0] = self.rail_scroll[0].min(max_scroll);
                let sc = self.rail_scroll[0];
                let first = ((sc / row_h) as usize).saturating_sub(0);
                let last = (((sc + r.h) / row_h) as usize + 1).min(rows);
                let cur = self.view.cur;
                let marks = l.bookmarks.clone();
                let mut reqs = Vec::new();
                for row in first..last {
                    for cx in 0..cols {
                        let i = row * cols + cx;
                        if i >= n {
                            break;
                        }
                        let x = r.x + pad + cx as f32 * (tw + pad) + (r.w - pad - cols as f32 * (tw + pad)) / 2.0;
                        let y = r.y + pad / 2.0 + row as f32 * row_h - sc;
                        let tr = Rect::new(x, y, tw, th_);
                        if tr.bottom() < r.y || tr.y > r.bottom() {
                            continue;
                        }
                        ui.p.fill_rect(tr, Rgba(255, 255, 255, 255));
                        let pk = proxy_key(doc_id, i, tiles.rev(i));
                        if let Some(t) = tiles.tile(&pk) {
                            let sx = tw * self.dpr / t.width() as f32;
                            draw_pixmap(ui.p.pm, &t, tr.x * self.dpr, tr.y * self.dpr, sx, true);
                        } else {
                            let (pw, ph) = l.sizes[i];
                            reqs.push((pk, TileSpec { scale: PROXY_SCALE, x: 0, y: 0, w: (pw * PROXY_SCALE).ceil() as u32, h: (ph * PROXY_SCALE).ceil() as u32 }));
                        }
                        let active = i == cur;
                        ui.p.stroke_rrect(tr.inset(-2.0), 3.0, if active { 2.5 } else { 1.0 }, if active { th.accent } else { th.border });
                        let lab = format!("{}", i + 1);
                        ui.p.text_center(Rect::new(x, tr.bottom() + 3.0, tw, 22.0), &lab, 12.0, if active { th.accent } else { th.dim }, active);
                        if marks.contains(&i) {
                            ui.p.icon(Icon::Bookmark, Rect::new(tr.right() - 22.0, tr.y - 3.0, 22.0, 22.0), th.accent);
                        }
                        ui.hits.push((Rect::new(x, y, tw, th_ + 24.0).intersect_clip(r), Action::GoPage(i)));
                    }
                }
                for (k, s) in reqs.into_iter().take(tiles.budget.max_inflight) {
                    tiles.request(k, s);
                }
            }
            RailTab::Outline => {
                let items = self.loaded.as_ref().map(|l| l.outline.clone()).unwrap_or_default();
                if items.is_empty() {
                    ui.p.text_center(Rect::new(r.x, r.y + 30.0, r.w, 30.0), "No outline in this document", 12.5, th.dim, false);
                }
                let row = 34.0;
                let max_scroll = (items.len() as f32 * row - r.h + 16.0).max(0.0);
                self.rail_scroll[0] = self.rail_scroll[0].min(max_scroll);
                let sc = self.rail_scroll[0];
                for (i, it) in items.iter().enumerate() {
                    let y = r.y + 6.0 + i as f32 * row - sc;
                    if y + row < r.y || y > r.bottom() {
                        continue;
                    }
                    let x = r.x + 14.0 + it.level as f32 * 14.0;
                    let t = ui.p.fit(&it.title, r.w - (x - r.x) - 16.0, 13.0, it.level == 0);
                    ui.p.text(x, y + row / 2.0, &t, 13.0, th.text, it.level == 0);
                    if let Some(p) = it.page {
                        ui.hits.push((Rect::new(r.x, y, r.w, row).intersect_clip(r), Action::GoPage(p)));
                    }
                }
            }
            RailTab::Marks => {
                let marks = self.loaded.as_ref().map(|l| l.bookmarks.clone()).unwrap_or_default();
                if marks.is_empty() {
                    ui.p.text_center(Rect::new(r.x, r.y + 30.0, r.w, 30.0), "No bookmarks yet", 12.5, th.dim, false);
                    ui.p.text_center(Rect::new(r.x, r.y + 52.0, r.w, 30.0), "Ctrl+K → Toggle bookmark", 11.5, th.dim, false);
                }
                for (i, p) in marks.iter().enumerate() {
                    let y = r.y + 6.0 + i as f32 * 40.0;
                    if y > r.bottom() {
                        break;
                    }
                    ui.p.icon(Icon::Bookmark, Rect::new(r.x + 14.0, y + 8.0, 24.0, 24.0), th.accent);
                    ui.p.text(r.x + 46.0, y + 20.0, &format!("Page {}", p + 1), 13.5, th.text, false);
                    ui.hits.push((Rect::new(r.x, y, r.w, 40.0).intersect_clip(r), Action::GoPage(*p)));
                }
            }
        }
    }

    fn search_panel(&mut self, ui: &mut Ui, r: Rect) {
        let th = self.th;
        ui.p.text(r.x + 16.0, r.y + 24.0, "Find in document", 14.0, th.text, true);
        if self.bp() == Bp::Desktop {
            self.btn(ui, Rect::new(r.right() - 48.0, r.y + 8.0, 34.0, 34.0), Icon::Close, false, Action::CloseSheet);
        }
        let ib = Rect::new(r.x + 14.0, r.y + 48.0, r.w - 28.0, 40.0);
        ui.p.fill_rrect(ib, 10.0, th.hover);
        ui.p.stroke_rrect(ib, 10.0, if self.wants_text() { 1.5 } else { 1.0 }, if self.wants_text() { th.accent } else { th.border });
        ui.p.icon(Icon::Search, Rect::new(ib.x + 8.0, ib.y + 8.0, 24.0, 24.0), th.dim);
        let q = self.search.line.text.clone();
        if q.is_empty() {
            ui.p.text(ib.x + 40.0, ib.y + 20.0, "Search text…", 13.5, th.dim, false);
        } else {
            let t = ui.p.fit(&q, ib.w - 56.0, 13.5, false);
            ui.p.text(ib.x + 40.0, ib.y + 20.0, &t, 13.5, th.text, false);
        }
        if self.focus == Focus::Search && ((self.now / 500.0) as i64) % 2 == 0 {
            let pre: String = self.search.line.text.chars().take(self.search.line.caret).collect();
            let cx = ib.x + 40.0 + ui.p.text_w(&pre, 13.5, false);
            ui.p.line(cx, ib.y + 10.0, cx, ib.y + 30.0, 1.5, th.accent);
        }
        ui.hits.push((ib, Action::FocusSearch));
        let total = self.search_total();
        let pages = self.search.per_page.len();
        let status = if q.is_empty() { String::new() } else if self.search.scanned < pages { format!("{total} matches · scanning {}/{}", self.search.scanned, pages) } else { format!("{total} match{}", if total == 1 { "" } else { "es" }) };
        ui.p.text(r.x + 16.0, r.y + 108.0, &status, 12.0, th.dim, false);
        if total > 0 {
            self.btn(ui, Rect::new(r.right() - 84.0, r.y + 92.0, 34.0, 32.0), Icon::Up, false, Action::SearchPrev);
            self.btn(ui, Rect::new(r.right() - 48.0, r.y + 92.0, 34.0, 32.0), Icon::Down, false, Action::SearchNext);
        }
        let list = Rect::new(r.x, r.y + 130.0, r.w, (r.h - 130.0).max(0.0));
        ui.lists.push((list, 1));
        let row = 38.0;
        let max_scroll = (total as f32 * row - list.h + 10.0).max(0.0);
        self.rail_scroll[1] = self.rail_scroll[1].min(max_scroll);
        let sc = self.rail_scroll[1];
        let mut idx = 0usize;
        let per: Vec<usize> = self.search.per_page.iter().map(|p| p.len()).collect();
        for (page, n) in per.iter().enumerate() {
            for k in 0..*n {
                let y = list.y + idx as f32 * row - sc;
                if y + row >= list.y && y <= list.bottom() {
                    let cur = idx == self.search.cur;
                    let rr = Rect::new(list.x + 10.0, y, list.w - 20.0, row - 4.0);
                    ui.p.fill_rrect(rr, 8.0, if cur { th.accent.alpha(0.18) } else { th.hover.alpha(0.6) });
                    ui.p.text(rr.x + 12.0, rr.y + rr.h / 2.0, &format!("Page {} · match {}", page + 1, k + 1), 12.5, if cur { th.accent } else { th.text }, cur);
                    ui.hits.push((rr.intersect_clip(list), Action::Match(idx)));
                }
                idx += 1;
            }
        }
    }

    // ------------------------------------------------------ selection / edit
    fn draw_selection_bar(&mut self, ui: &mut Ui) {
        let Selection::Text { page, range } = &self.sel else { return };
        if self.drag_text_active() {
            return;
        }
        let (page, range) = (*page, *range);
        let Some(dl) = self.loaded.as_ref().and_then(|l| l.tiles.dl_peek(page)) else { return };
        let rects = dl.page_text().rects(range);
        let Some(first) = rects.first() else { return };
        let (x, y) = self.page_to_screen(page, first[0], first[1]);
        let bar = Rect::new(x.clamp(8.0, (self.w - 190.0).max(8.0)), (y - 52.0).max(70.0), 182.0, 42.0);
        self.glass(ui, bar, 14.0);
        self.pill_btn(ui, Rect::new(bar.x + 6.0, bar.y + 6.0, 84.0, 30.0), "Highlight", true, Action::HighlightSel);
        self.pill_btn(ui, Rect::new(bar.x + 96.0, bar.y + 6.0, 80.0, 30.0), "Copy", false, Action::CopySel);
    }

    fn drag_text_active(&self) -> bool {
        matches!(self.drag, Drag::Text { .. })
    }

    fn draw_inspector(&mut self, ui: &mut Ui) {
        let th = self.th;
        let has_edit = self.edit.is_some();
        let annot = matches!(self.sel, Selection::Annot { .. });
        if !has_edit && !annot {
            return;
        }
        let (w, h) = (if self.bp() == Bp::Mobile { self.w - 16.0 } else { 304.0 }, if has_edit { 186.0 } else { 150.0 });
        let r = match self.bp() {
            Bp::Mobile => Rect::new(8.0, 98.0, w, h),
            Bp::Tablet => Rect::new(self.w - w - 12.0, 68.0, w, h),
            Bp::Desktop => Rect::new(self.w - w - 16.0, 74.0, w, h),
        };
        self.glass(ui, r, 16.0);
        if let Some(e) = &self.edit {
            let title = e.title.clone();
            let text = e.line.text.clone();
            let caret = e.line.caret;
            ui.p.text(r.x + 16.0, r.y + 22.0, &title, 14.0, th.text, true);
            ui.p.text(r.x + 16.0, r.y + 42.0, "Press Enter to apply · Esc to cancel", 11.0, th.dim, false);
            let ib = Rect::new(r.x + 14.0, r.y + 58.0, r.w - 28.0, 44.0);
            ui.p.fill_rrect(ib, 10.0, th.hover);
            ui.p.stroke_rrect(ib, 10.0, 1.5, th.accent);
            // scroll the text so the caret stays visible
            let pre: String = text.chars().take(caret).collect();
            let pw = ui.p.text_w(&pre, 14.0, false);
            let max_w = ib.w - 24.0;
            let shown: String = if pw > max_w {
                let mut start = 0usize;
                let chars: Vec<char> = text.chars().collect();
                while start < caret && ui.p.text_w(&chars[start..caret].iter().collect::<String>(), 14.0, false) > max_w {
                    start += 1;
                }
                chars[start..].iter().collect::<String>()
            } else {
                text.clone()
            };
            let shown = ui.p.fit(&shown, max_w + 40.0, 14.0, false);
            ui.p.text(ib.x + 12.0, ib.y + ib.h / 2.0, &shown, 14.0, th.text, false);
            if ((self.now / 500.0) as i64) % 2 == 0 {
                let cx = ib.x + 12.0 + pw.min(max_w);
                ui.p.line(cx, ib.y + 10.0, cx, ib.y + ib.h - 10.0, 1.5, th.accent);
            }
            ui.hits.push((ib, Action::Noop));
            self.pill_btn(ui, Rect::new(r.x + 14.0, r.y + 120.0, (r.w - 36.0) / 2.0, 40.0), "Cancel", false, Action::CancelEdit);
            self.pill_btn(ui, Rect::new(r.x + 22.0 + (r.w - 36.0) / 2.0, r.y + 120.0, (r.w - 36.0) / 2.0, 40.0), "Apply", true, Action::ApplyEdit);
        } else if let Selection::Annot { subtype, .. } = &self.sel {
            let label = match subtype.as_str() {
                "Ink" => "Ink drawing",
                "Highlight" => "Highlight",
                "Text" => "Sticky note",
                "FreeText" => "Text box",
                "Stamp" => "Signature",
                other => other,
            }
            .to_string();
            ui.p.text(r.x + 16.0, r.y + 24.0, &label, 14.0, th.text, true);
            ui.p.text(r.x + 16.0, r.y + 46.0, "Selected annotation", 11.5, th.dim, false);
            self.pill_btn(ui, Rect::new(r.x + 14.0, r.y + 76.0, r.w - 28.0, 44.0), "Delete annotation", false, Action::DeleteAnnot);
        }
    }

    // -------------------------------------------------------------- palette
    fn draw_palette(&mut self, ui: &mut Ui) {
        let a = self.pal_open.v.clamp(0.0, 1.0);
        if a < 0.02 {
            return;
        }
        let th = self.th;
        ui.p.fill_rect(Rect::new(0.0, 0.0, self.w, self.h), Rgba(0, 0, 0, (120.0 * a) as u8));
        let w = (self.w - 24.0).min(580.0);
        let rows = 9usize;
        let h = 58.0 + rows as f32 * 38.0 + 12.0;
        let y0 = (self.h * 0.12).min(self.h - h - 10.0).max(8.0) - (1.0 - a) * 14.0;
        let r = Rect::new((self.w - w) / 2.0, y0, w, h);
        ui.p.shadow(r, 16.0, 30.0, 150);
        ui.p.fill_rrect(r, 16.0, th.panel.alpha(a));
        ui.p.stroke_rrect(r, 16.0, 1.0, th.border);
        ui.hits.push((r, Action::Noop));
        ui.p.icon(Icon::Command, Rect::new(r.x + 12.0, r.y + 12.0, 30.0, 30.0), th.dim);
        let q = self.pal_line.text.clone();
        if q.is_empty() {
            ui.p.text(r.x + 52.0, r.y + 28.0, "Type a command…", 15.0, th.dim, false);
        } else {
            ui.p.text(r.x + 52.0, r.y + 28.0, &q, 15.0, th.text, false);
        }
        let pre: String = self.pal_line.text.chars().take(self.pal_line.caret).collect();
        let cx = r.x + 52.0 + ui.p.text_w(&pre, 15.0, false);
        if ((self.now / 500.0) as i64) % 2 == 0 {
            ui.p.line(cx, r.y + 16.0, cx, r.y + 40.0, 1.5, th.accent);
        }
        ui.p.line(r.x, r.y + 56.0, r.right(), r.y + 56.0, 1.0, th.border);
        let list = self.filtered_commands();
        let cmds = commands();
        let sel = self.pal_sel.min(list.len().saturating_sub(1));
        self.pal_sel = sel;
        let first = sel.saturating_sub(rows - 1);
        for (k, &ci) in list.iter().enumerate().skip(first).take(rows) {
            let rr = Rect::new(r.x + 8.0, r.y + 62.0 + (k - first) as f32 * 38.0, r.w - 16.0, 36.0);
            if k == sel {
                ui.p.fill_rrect(rr, 9.0, th.accent.alpha(0.18));
            }
            let (title, key, _) = &cmds[ci];
            ui.p.text(rr.x + 12.0, rr.y + 18.0, title, 13.5, if k == sel { th.accent } else { th.text }, k == sel);
            if !key.is_empty() {
                let kw = ui.p.text_w(key, 11.5, false);
                ui.p.text(rr.right() - kw - 12.0, rr.y + 18.0, key, 11.5, th.dim, false);
            }
            ui.hits.push((rr, Action::PaletteItem(ci)));
        }
        if list.is_empty() {
            ui.p.text_center(Rect::new(r.x, r.y + 80.0, r.w, 30.0), "No matching commands", 13.0, th.dim, false);
        }
    }

    fn draw_toast(&mut self, ui: &mut Ui) {
        let Some((msg, _)) = &self.toast else { return };
        let th = self.th;
        let msg = msg.clone();
        let w = (ui.p.text_w(&msg, 13.0, false) + 36.0).min(self.w - 24.0);
        let y = match self.bp() {
            Bp::Mobile => self.h - 134.0,
            Bp::Desktop => self.h - 120.0,
            Bp::Tablet => self.h - 70.0,
        };
        let r = Rect::new((self.w - w) / 2.0, y, w, 38.0);
        ui.p.shadow(r, 19.0, 14.0, 110);
        ui.p.fill_rrect(r, 19.0, if th.dark { Rgba(236, 237, 240, 255) } else { Rgba(30, 31, 36, 255) });
        let t = ui.p.fit(&msg, w - 28.0, 13.0, false);
        ui.p.text_center(r, &t, 13.0, if th.dark { Rgba(20, 20, 24, 255) } else { Rgba(245, 245, 248, 255) }, false);
    }
}

impl Rect {
    /// Intersection with `o` (used to keep hit regions inside scroll viewports).
    pub fn intersect_clip(self, o: Rect) -> Rect {
        let x0 = self.x.max(o.x);
        let y0 = self.y.max(o.y);
        let x1 = self.right().min(o.right());
        let y1 = self.bottom().min(o.bottom());
        Rect::new(x0, y0, (x1 - x0).max(0.0), (y1 - y0).max(0.0))
    }
}
