//! Application state machine: documents, viewport, tools, gestures, search.

use crate::paint::{GlyphCache, Theme};
use crate::reflow::{reflow, RLine};
use crate::tiles::TileService;
use crate::types::*;
use crate::util::*;
use pdf_core::{ByteSource, Doc, ObjId, VecSource};
use pdf_edit::{export, sample, Affected, Editor};
use pdf_render::{LinkTarget, MemoryBudget, OutlineItem, Renderer};
use std::collections::VecDeque;
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::Arc;

pub const COLORS: [[f32; 3]; 6] = [[1.0, 0.84, 0.04], [0.19, 0.82, 0.35], [0.04, 0.52, 1.0], [1.0, 0.41, 0.38], [0.75, 0.35, 0.95], [0.08, 0.08, 0.1]];
pub const WIDTHS: [f32; 3] = [1.5, 3.0, 6.0];
pub const RAIL_W: f32 = 268.0;
pub const GAP: f32 = 14.0;
pub const MARGIN: f32 = 24.0;

pub struct AppConfig {
    pub budget: MemoryBudget,
    pub dpr: f32,
    pub width: f32,
    pub height: f32,
}

pub(crate) struct Loaded {
    pub name: String,
    pub doc: Arc<Doc>,
    pub editor: Editor,
    pub tiles: TileService,
    pub sizes: Vec<(f32, f32)>,
    pub outline: Vec<OutlineItem>,
    pub bookmarks: Vec<usize>,
    pub rects: Vec<Rect>,
    pub content: (f32, f32),
    pub max_w: f32,
    pub reflow: Vec<Option<Arc<Vec<RLine>>>>,
    pub reflow_w: f32,
}

pub(crate) enum Drag {
    None,
    Press { action: Action, rect: Rect },
    List { list: usize, y0: f32, s0: f32, moved: bool, action: Option<Action> },
    Pan { last: (f32, f32), moved: f32, down: (f32, f32), kind: PointerKind, hist: Vec<(f64, f32, f32)> },
    Stroke { page: usize, pts: Vec<(f32, f32)> },
    Rect { page: usize, a: (f32, f32), b: (f32, f32) },
    Text { page: usize, anchor: usize },
    Dock { dx: f32, dy: f32 },
    Sheet { y0: f32, f0: f32 },
}

pub(crate) enum Selection {
    None,
    Text { page: usize, range: (usize, usize) },
    Run { page: usize, run: usize },
    Annot { page: usize, id: ObjId, subtype: String },
}

pub(crate) enum EditKind {
    NewNote { page: usize, pos: (f32, f32) },
    NewBox { page: usize, rect: [f32; 4] },
    Run { page: usize, op: usize },
    Field { page: usize, field: ObjId },
}

pub(crate) struct EditState {
    pub kind: EditKind,
    pub line: LineEdit,
    pub title: String,
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum Focus {
    None,
    Edit,
    Search,
    Palette,
}

pub(crate) struct View {
    pub mode: ViewMode,
    pub zoom: f32,
    pub sx: f32,
    pub sy: f32,
    pub cur: usize,
    pub fit: Option<bool>,
    pub vel: (f32, f32),
    pub reading: bool,
    pub reading_y: f32,
}

pub(crate) struct Search {
    pub line: LineEdit,
    pub qid: u32,
    pub per_page: Vec<Vec<Vec<[f32; 4]>>>,
    pub scanned: usize,
    pub dispatched: usize,
    pub cur: usize,
    pub tx: Sender<(u32, usize, Vec<Vec<[f32; 4]>>)>,
    pub rx: Receiver<(u32, usize, Vec<Vec<[f32; 4]>>)>,
}

pub struct App {
    pub(crate) w: f32,
    pub(crate) h: f32,
    pub(crate) dpr: f32,
    pub(crate) budget: MemoryBudget,
    pub(crate) th: Theme,
    pub(crate) glyphs: GlyphCache,
    pub(crate) loaded: Option<Loaded>,
    pub(crate) view: View,
    pub(crate) tool: Tool,
    pub(crate) color: usize,
    pub(crate) width_i: usize,
    pub(crate) rail: Spring,
    pub(crate) rail_tab: RailTab,
    pub(crate) rail_scroll: [f32; 2],
    pub(crate) sheet: Option<SheetKind>,
    pub(crate) sheet_f: Spring,
    pub(crate) dock_x: Spring,
    pub(crate) dock_y: Spring,
    pub(crate) dock_vertical: bool,
    pub(crate) pal_open: Spring,
    pub(crate) palette: bool,
    pub(crate) pal_line: LineEdit,
    pub(crate) pal_sel: usize,
    pub(crate) hits: Vec<(Rect, Action)>,
    pub(crate) lists: Vec<(Rect, usize)>,
    pub(crate) drag: Drag,
    pub(crate) touches: Touches,
    pub(crate) sel: Selection,
    pub(crate) edit: Option<EditState>,
    pub(crate) focus: Focus,
    pub(crate) search: Search,
    pub(crate) effects: Vec<Effect>,
    pub(crate) toast: Option<(String, f64)>,
    pub(crate) now: f64,
    pub(crate) last_tick: f64,
    pub(crate) hover: (f32, f32),
    pub(crate) dirty: bool,
    pub(crate) animating: bool,
    pub(crate) saved_name: Option<String>,
    pub(crate) last_zoom_t: f64,
}

impl App {
    pub fn new(cfg: AppConfig) -> App {
        let (tx, rx) = channel();
        let mut app = App {
            w: cfg.width,
            h: cfg.height,
            dpr: cfg.dpr,
            budget: cfg.budget,
            th: Theme::dark(),
            glyphs: GlyphCache::default(),
            loaded: None,
            view: View { mode: ViewMode::Continuous, zoom: 1.0, sx: 0.0, sy: 0.0, cur: 0, fit: Some(true), vel: (0.0, 0.0), reading: false, reading_y: 0.0 },
            tool: Tool::Hand,
            color: 0,
            width_i: 1,
            rail: Spring::new(0.0),
            rail_tab: RailTab::Pages,
            rail_scroll: [0.0; 2],
            sheet: None,
            sheet_f: Spring::new(0.0),
            dock_x: Spring::new(0.0),
            dock_y: Spring::new(0.0),
            dock_vertical: true,
            pal_open: Spring::new(0.0),
            palette: false,
            pal_line: LineEdit::default(),
            pal_sel: 0,
            hits: Vec::new(),
            lists: Vec::new(),
            drag: Drag::None,
            touches: Touches::default(),
            sel: Selection::None,
            edit: None,
            focus: Focus::None,
            search: Search { line: LineEdit::default(), qid: 0, per_page: vec![], scanned: 0, dispatched: 0, cur: 0, tx, rx },
            effects: Vec::new(),
            toast: None,
            now: 0.0,
            last_tick: 0.0,
            hover: (-1.0, -1.0),
            dirty: true,
            animating: false,
            saved_name: None,
            last_zoom_t: 0.0,
        };
        app.snap_dock();
        if app.bp() == Bp::Desktop {
            app.rail.snap(1.0);
        }
        app
    }

    // ------------------------------------------------------------ basics
    pub fn bp(&self) -> Bp {
        Bp::from_width(self.w)
    }
    pub fn size(&self) -> (f32, f32) {
        (self.w, self.h)
    }
    pub fn pixel_size(&self) -> (u32, u32) {
        ((self.w * self.dpr).round().max(1.0) as u32, (self.h * self.dpr).round().max(1.0) as u32)
    }
    pub fn take_effects(&mut self) -> Vec<Effect> {
        std::mem::take(&mut self.effects)
    }
    pub fn wants_text(&self) -> bool {
        self.focus != Focus::None
    }
    pub fn needs_redraw(&self) -> bool {
        self.dirty || self.animating
    }
    pub fn title(&self) -> String {
        match &self.loaded {
            Some(l) => format!("{}{} - PDF Studio", l.name, if l.editor.is_dirty() { " •" } else { "" }),
            None => "PDF Studio".into(),
        }
    }
    pub fn toast(&mut self, s: impl Into<String>) {
        self.toast = Some((s.into(), self.now + 2600.0));
        self.dirty = true;
    }
    pub(crate) fn top_inset(&self) -> f32 {
        match self.bp() {
            Bp::Desktop => 76.0,
            Bp::Tablet => 64.0,
            Bp::Mobile => 52.0,
        }
    }
    pub(crate) fn bottom_inset(&self) -> f32 {
        match self.bp() {
            Bp::Desktop => 76.0,
            Bp::Tablet => 24.0,
            Bp::Mobile => 96.0,
        }
    }
    pub(crate) fn canvas(&self) -> Rect {
        let rw = if self.bp() == Bp::Desktop { self.rail.v * RAIL_W } else { 0.0 };
        Rect::new(rw, 0.0, (self.w - rw).max(10.0), self.h)
    }
    pub(crate) fn snap_dock(&mut self) {
        let (x, y) = self.dock_target();
        self.dock_x.snap(x);
        self.dock_y.snap(y);
    }
    pub(crate) fn dock_target(&self) -> (f32, f32) {
        if self.dock_vertical {
            (if self.dock_x.target > self.w / 2.0 { self.w - 34.0 } else { 34.0 }, self.h / 2.0)
        } else {
            (self.w / 2.0, if self.dock_y.target > self.h / 2.0 { self.h - 40.0 } else { 40.0 })
        }
    }

    pub fn resize(&mut self, w: f32, h: f32, dpr: f32) {
        let old = self.bp();
        self.w = w.max(100.0);
        self.h = h.max(100.0);
        self.dpr = dpr.max(0.5);
        let bp = self.bp();
        if bp != old {
            self.budget = match bp {
                Bp::Desktop => if cfg!(target_arch = "wasm32") { MemoryBudget::web() } else { MemoryBudget::desktop() },
                Bp::Tablet => MemoryBudget::tablet(),
                Bp::Mobile => MemoryBudget::mobile(),
            };
            if let Some(l) = &mut self.loaded {
                l.tiles.set_budget(self.budget);
            }
            self.rail.snap(if bp == Bp::Desktop { 1.0 } else { 0.0 });
            self.sheet = None;
            self.sheet_f.snap(0.0);
        }
        self.snap_dock();
        self.refit();
        self.dirty = true;
    }

    // ----------------------------------------------------------- documents
    pub fn open_sample(&mut self) {
        self.open_bytes("Sample.pdf", sample::sample_pdf());
    }
    pub fn open_bytes(&mut self, name: &str, bytes: Vec<u8>) {
        self.open_source(name, Arc::new(VecSource(bytes)));
    }
    pub fn open_source(&mut self, name: &str, source: Arc<dyn ByteSource>) {
        match Doc::open(source) {
            Ok(doc) => self.install(name, doc),
            Err(e) => self.toast(format!("Cannot open {name}: {e}")),
        }
    }
    fn install(&mut self, name: &str, doc: Doc) {
        let doc = Arc::new(doc);
        let renderer = Arc::new(Renderer::new(doc.clone()));
        let tiles = TileService::new(renderer.clone(), self.budget);
        let editor = Editor::new(doc.clone(), renderer.clone());
        let outline = pdf_render::outline(&doc);
        let mut l = Loaded { name: name.to_string(), doc, editor, tiles, sizes: vec![], outline, bookmarks: vec![], rects: vec![], content: (0.0, 0.0), max_w: 0.0, reflow: vec![], reflow_w: 0.0 };
        l.refresh_sizes();
        self.loaded = Some(l);
        self.view.cur = 0;
        self.view.fit = Some(true);
        self.sel = Selection::None;
        self.edit = None;
        self.search.per_page.clear();
        self.search.qid += 1;
        self.relayout();
        self.refit();
        self.go_page(0);
        self.dirty = true;
    }

    pub(crate) fn page_count(&self) -> usize {
        self.loaded.as_ref().map_or(0, |l| l.sizes.len())
    }

    pub(crate) fn relayout(&mut self) {
        let cur = self.view.cur;
        let mode = self.view.mode;
        if let Some(l) = &mut self.loaded {
            l.layout(mode, cur);
        }
    }

    pub(crate) fn refit(&mut self) {
        let Some(fit) = self.view.fit else { return };
        let Some(l) = &self.loaded else { return };
        if l.sizes.is_empty() {
            return;
        }
        let c = self.canvas();
        let side = if self.bp() == Bp::Mobile { 8.0 } else { 40.0 };
        let (pw, ph) = l.sizes[self.view.cur.min(l.sizes.len() - 1)];
        let cols = if self.view.mode == ViewMode::TwoPage { 2.0 } else { 1.0 };
        let total_w = l.max_w * cols + if cols > 1.0 { GAP } else { 0.0 };
        let z = if fit { (c.w - side * 2.0) / total_w } else { ((c.w - side * 2.0) / total_w).min((c.h - self.top_inset() - self.bottom_inset()) / ph.max(1.0)) };
        let _ = pw;
        self.view.zoom = z.clamp(0.1, 8.0);
        self.clamp_scroll();
    }

    pub(crate) fn clamp_scroll(&mut self) {
        let Some(l) = &self.loaded else { return };
        let c = self.canvas();
        let z = self.view.zoom;
        let (vw, vh) = (c.w / z, c.h / z);
        let (cw, ch) = l.content;
        let (top, bot) = (self.top_inset() / z, self.bottom_inset() / z);
        self.view.sx = if cw <= vw { -(vw - cw) / 2.0 } else { self.view.sx.clamp(0.0, cw - vw) };
        let (min_y, max_y) = (-top, ch - vh + bot);
        self.view.sy = if max_y <= min_y { (min_y + max_y) / 2.0 } else { self.view.sy.clamp(min_y, max_y) };
    }

    pub(crate) fn zoom_at(&mut self, factor: f32, ax: f32, ay: f32) {
        let c = self.canvas();
        let old = self.view.zoom;
        let nz = (old * factor).clamp(0.1, 8.0);
        let (dx, dy) = ((ax - c.x) / old + self.view.sx, (ay - c.y) / old + self.view.sy);
        self.view.zoom = nz;
        self.view.sx = dx - (ax - c.x) / nz;
        self.view.sy = dy - (ay - c.y) / nz;
        self.view.fit = None;
        self.last_zoom_t = self.now;
        self.clamp_scroll();
        self.update_current();
        self.dirty = true;
    }

    pub(crate) fn scroll_by(&mut self, dx: f32, dy: f32) {
        if self.view.reading {
            self.view.reading_y = (self.view.reading_y + dy).max(0.0);
            self.dirty = true;
            return;
        }
        let z = self.view.zoom;
        let before = self.view.sy;
        self.view.sx += dx / z;
        self.view.sy += dy / z;
        self.clamp_scroll();
        if self.view.mode == ViewMode::Single && dy != 0.0 && (self.view.sy - before).abs() < 0.01 * dy.abs() / z.max(0.1) {
            // at the page edge: flip pages
            let n = self.page_count();
            if dy > 0.0 && self.view.cur + 1 < n {
                self.go_page(self.view.cur + 1);
            } else if dy < 0.0 && self.view.cur > 0 {
                self.go_page(self.view.cur - 1);
                if let Some(l) = &self.loaded {
                    let c = self.canvas();
                    let ph = l.sizes[self.view.cur].1;
                    self.view.sy = ph + MARGIN * 2.0 - c.h / self.view.zoom;
                    self.clamp_scroll();
                }
            }
        }
        self.update_current();
        self.dirty = true;
    }

    pub(crate) fn update_current(&mut self) {
        if self.view.mode == ViewMode::Single {
            return;
        }
        let Some(l) = &self.loaded else { return };
        let c = self.canvas();
        let mid = self.view.sy + (c.h * 0.4) / self.view.zoom;
        let mut best = 0;
        for (i, r) in l.rects.iter().enumerate() {
            if r.bottom() + GAP / 2.0 > mid {
                best = i;
                break;
            }
            best = i;
        }
        self.view.cur = best;
    }

    pub(crate) fn go_page(&mut self, i: usize) {
        let n = self.page_count();
        if n == 0 {
            return;
        }
        let i = i.min(n - 1);
        self.view.cur = i;
        if self.view.mode == ViewMode::Single {
            self.relayout();
            self.refit_if_page_fit();
        }
        if let Some(l) = &self.loaded {
            let r = l.rects[i];
            self.view.sy = r.y - MARGIN / 2.0 - self.top_inset() / self.view.zoom + 8.0 / self.view.zoom;
            if self.view.mode == ViewMode::Single {
                self.view.sy = -self.top_inset() / self.view.zoom;
            }
        }
        self.view.reading_y = 0.0;
        self.clamp_scroll();
        self.dirty = true;
    }

    fn refit_if_page_fit(&mut self) {
        if self.view.fit == Some(false) {
            self.refit();
        }
    }

    pub(crate) fn scroll_to_rect(&mut self, page: usize, r: [f32; 4]) {
        let Some(l) = &self.loaded else { return };
        if page >= l.rects.len() {
            return;
        }
        if self.view.mode == ViewMode::Single && self.view.cur != page {
            self.go_page(page);
        }
        let Some(l) = &self.loaded else { return };
        let pr = l.rects[page];
        let c = self.canvas();
        let z = self.view.zoom;
        let cy = pr.y + (r[1] + r[3]) / 2.0;
        let vis_top = self.view.sy + self.top_inset() / z;
        let vis_bot = self.view.sy + (c.h - self.bottom_inset()) / z;
        if cy < vis_top || cy > vis_bot {
            self.view.sy = cy - c.h * 0.4 / z;
        }
        self.clamp_scroll();
        self.update_current();
    }

    pub(crate) fn to_doc(&self, x: f32, y: f32) -> (f32, f32) {
        let c = self.canvas();
        ((x - c.x) / self.view.zoom + self.view.sx, (y - c.y) / self.view.zoom + self.view.sy)
    }
    pub(crate) fn from_doc(&self, dx: f32, dy: f32) -> (f32, f32) {
        let c = self.canvas();
        (c.x + (dx - self.view.sx) * self.view.zoom, c.y + (dy - self.view.sy) * self.view.zoom)
    }

    pub(crate) fn visible_pages(&self) -> Vec<usize> {
        let Some(l) = &self.loaded else { return vec![] };
        if self.view.mode == ViewMode::Single {
            return vec![self.view.cur.min(l.rects.len().saturating_sub(1))];
        }
        let c = self.canvas();
        let z = self.view.zoom;
        let (y0, y1) = (self.view.sy - 8.0, self.view.sy + c.h / z + 8.0);
        let first = l.rects.partition_point(|r| r.bottom() < y0);
        let mut out = Vec::new();
        for i in first.saturating_sub(2)..l.rects.len() {
            let r = l.rects[i];
            if r.y > y1 && i > first + 2 {
                break;
            }
            if r.bottom() >= y0 && r.y <= y1 {
                out.push(i);
            }
        }
        out
    }

    /// Screen point → (page, view-space point inside that page).
    pub(crate) fn hit_page(&self, x: f32, y: f32) -> Option<(usize, f32, f32)> {
        let l = self.loaded.as_ref()?;
        let (dx, dy) = self.to_doc(x, y);
        for i in self.visible_pages() {
            let r = l.rects[i];
            if dx >= r.x - 2.0 && dx <= r.right() + 2.0 && dy >= r.y - 2.0 && dy <= r.bottom() + 2.0 {
                return Some((i, dx - r.x, dy - r.y));
            }
        }
        None
    }

    /// Nearest page + clamped point (for drags that leave the page).
    pub(crate) fn clamp_to_page(&self, page: usize, x: f32, y: f32) -> (f32, f32) {
        let Some(l) = &self.loaded else { return (0.0, 0.0) };
        let (dx, dy) = self.to_doc(x, y);
        let r = l.rects[page];
        ((dx - r.x).clamp(0.0, r.w), (dy - r.y).clamp(0.0, r.h))
    }

    pub(crate) fn page_to_screen(&self, page: usize, x: f32, y: f32) -> (f32, f32) {
        let r = self.loaded.as_ref().map(|l| l.rects[page]).unwrap_or_default();
        self.from_doc(r.x + x, r.y + y)
    }

    // ---------------------------------------------------------------- edits
    pub(crate) fn after_edit(&mut self) {
        let Some(l) = &mut self.loaded else { return };
        match l.editor.take_affected() {
            Affected::None => {}
            Affected::Pages(p) => l.tiles.invalidate(Some(&p)),
            Affected::All => {
                l.tiles.invalidate(None);
                l.refresh_sizes();
                l.bookmarks.retain(|b| *b < l.sizes.len());
            }
        }
        self.sel = Selection::None;
        self.relayout();
        let n = self.page_count();
        if self.view.cur >= n && n > 0 {
            self.view.cur = n - 1;
        }
        self.clamp_scroll();
        self.dirty = true;
    }

    fn color3(&self) -> [f32; 3] {
        COLORS[self.color.min(COLORS.len() - 1)]
    }

    pub(crate) fn start_edit(&mut self, kind: EditKind, title: &str, text: &str) {
        self.edit = Some(EditState { kind, line: LineEdit::with(text), title: title.to_string() });
        self.focus = Focus::Edit;
        self.effects.push(Effect::TextFocus(true));
        if self.bp() == Bp::Mobile {
            self.sheet = None;
        }
        self.dirty = true;
    }

    pub(crate) fn end_focus(&mut self) {
        if self.focus != Focus::None {
            self.focus = Focus::None;
            self.effects.push(Effect::TextFocus(false));
        }
    }

    fn apply_edit(&mut self) {
        let Some(e) = self.edit.take() else { return };
        self.end_focus();
        let text = e.line.text.clone();
        let color = self.color3();
        let Some(l) = &mut self.loaded else { return };
        let res: Result<String, String> = match e.kind {
            EditKind::NewNote { page, pos } => l.editor.add_note(page, pos, &text).map(|_| "Note added".to_string()).map_err(|e| e.to_string()),
            EditKind::NewBox { page, rect } => {
                if text.trim().is_empty() {
                    Err("Type some text first".into())
                } else {
                    l.editor.add_text_box(page, rect, &text, 12.0, color).map(|_| "Text added".to_string()).map_err(|e| e.to_string())
                }
            }
            EditKind::Run { page, op } => l.editor.edit_text_run(page, op, &text).map(|_| "Text updated".to_string()).map_err(|e| e.to_string()),
            EditKind::Field { page, field } => l.editor.set_text_field(page, field, &text).map(|_| "Field updated".to_string()).map_err(|e| e.to_string()),
        };
        match res {
            Ok(m) => self.toast(m),
            Err(m) => self.toast(m),
        }
        self.after_edit();
    }

    fn cancel_edit(&mut self) {
        self.edit = None;
        self.end_focus();
        self.sel = Selection::None;
        self.dirty = true;
    }

    fn highlight_selection(&mut self) {
        let color = if self.color == 5 { COLORS[0] } else { self.color3() };
        let (page, range) = match self.sel {
            Selection::Text { page, range } => (page, range),
            _ => return,
        };
        let Some(l) = &mut self.loaded else { return };
        let Some(dl) = l.tiles.dl(page) else { return };
        let pt = dl.page_text();
        let rects = pt.rects(range);
        let txt = pt.slice(range);
        match l.editor.add_highlight(page, &rects, color, &txt) {
            Ok(_) => self.toast("Highlighted"),
            Err(e) => self.toast(e.to_string()),
        }
        self.after_edit();
    }

    fn save(&mut self) {
        let Some(l) = &mut self.loaded else { return };
        match l.editor.save_bytes() {
            Ok(bytes) => {
                let name = if l.name.to_lowercase().ends_with(".pdf") { l.name.clone() } else { format!("{}.pdf", l.name) };
                l.editor.mark_saved();
                self.effects.push(Effect::SaveFile { name, bytes });
                self.toast("Saved (incremental update appended)");
            }
            Err(e) => self.toast(e.to_string()),
        }
    }

    // --------------------------------------------------------------- search
    pub(crate) fn start_search(&mut self) {
        self.search.qid += 1;
        let n = self.page_count();
        self.search.per_page = vec![Vec::new(); n];
        self.search.scanned = 0;
        self.search.dispatched = 0;
        self.search.cur = 0;
        self.dirty = true;
    }

    fn dispatch_search(&mut self) {
        let q = self.search.line.text.trim().to_string();
        let n = self.page_count();
        if q.is_empty() || self.search.dispatched >= n {
            return;
        }
        let Some(l) = &self.loaded else { return };
        let mut budget = if cfg!(target_arch = "wasm32") { 1 } else { 6 };
        while budget > 0 && self.search.dispatched < n {
            let page = self.search.dispatched;
            self.search.dispatched += 1;
            budget -= 1;
            let tiles = l.tiles.clone();
            let tx = self.search.tx.clone();
            let qid = self.search.qid;
            let q = q.clone();
            l.tiles.spawn(Box::new(move || {
                let matches = match tiles.dl(page) {
                    Some(dl) => {
                        let pt = dl.page_text();
                        pt.find(&q).into_iter().map(|r| pt.rects(r)).collect()
                    }
                    None => vec![],
                };
                let _ = tx.send((qid, page, matches));
            }));
        }
    }

    pub(crate) fn search_total(&self) -> usize {
        self.search.per_page.iter().map(|p| p.len()).sum()
    }

    pub(crate) fn goto_match(&mut self, idx: usize) {
        let mut k = idx;
        for (page, ms) in self.search.per_page.iter().enumerate() {
            if k < ms.len() {
                let r = ms[k].first().copied().unwrap_or([0.0; 4]);
                self.search.cur = idx;
                self.scroll_to_rect(page, r);
                self.dirty = true;
                return;
            }
            k -= ms.len();
        }
    }

    // ---------------------------------------------------------------- tick
    pub fn tick(&mut self, now_ms: f64) -> bool {
        let dt = if self.last_tick == 0.0 { 0.016 } else { ((now_ms - self.last_tick) / 1000.0) as f32 }.clamp(0.0, 0.05);
        self.last_tick = now_ms;
        self.now = now_ms;
        let mut moving = false;
        for s in [&mut self.rail, &mut self.sheet_f, &mut self.dock_x, &mut self.dock_y, &mut self.pal_open] {
            moving |= s.step(dt);
        }
        if self.rail.v != self.rail.target || moving {
            self.refit();
        }
        // kinetic scrolling
        if let Drag::None = self.drag {
            let (vx, vy) = self.view.vel;
            if vx.abs() > 8.0 || vy.abs() > 8.0 {
                self.scroll_by(-vx * dt, -vy * dt);
                let k = (-3.2 * dt).exp();
                self.view.vel = (vx * k, vy * k);
                moving = true;
            } else {
                self.view.vel = (0.0, 0.0);
            }
        }
        if let Some((_, t)) = &self.toast {
            if now_ms > *t {
                self.toast = None;
                self.dirty = true;
            } else {
                moving = true;
            }
        }
        let mut progressed = false;
        if let Some(l) = &self.loaded {
            progressed |= l.tiles.pump();
            if l.tiles.inflight() > 0 {
                moving = true;
            }
        }
        while let Ok((qid, page, m)) = self.search.rx.try_recv() {
            if qid == self.search.qid && page < self.search.per_page.len() {
                self.search.per_page[page] = m;
                self.search.scanned += 1;
                progressed = true;
                if self.search.scanned == 1 || (self.search.cur == 0 && self.search_total() == 1) {
                    self.goto_match(0);
                }
            }
        }
        if self.search.dispatched < self.search.per_page.len() && self.search.scanned + 12 > self.search.dispatched {
            self.dispatch_search();
            moving = true;
        }
        self.animating = moving || progressed;
        if progressed {
            self.dirty = true;
        }
        self.dirty || self.animating
    }

    // --------------------------------------------------------------- events
    pub fn event(&mut self, ev: Event) {
        self.dirty = true;
        match ev {
            Event::Pointer { phase, id, x, y, kind, button } => self.pointer(phase, id, x, y, kind, button),
            Event::Wheel { x, y, dx, dy, ctrl } => {
                if self.palette {
                    return;
                }
                if ctrl {
                    self.zoom_at((-dy * 0.0018).exp(), x, y);
                } else if self.over_list(x, y).is_some() {
                    let li = self.over_list(x, y).unwrap();
                    self.rail_scroll[li] = (self.rail_scroll[li] + dy).max(0.0);
                } else {
                    self.view.vel = (0.0, 0.0);
                    self.scroll_by(dx, dy);
                }
            }
            Event::Key { key, mods } => self.key(key, mods),
            Event::Text(t) => self.text(&t),
            Event::OpenDocument { name, source, merge } => {
                if merge {
                    self.merge_with(&name, source);
                } else {
                    self.open_source(&name, source);
                }
            }
        }
    }

    fn merge_with(&mut self, name: &str, source: Arc<dyn ByteSource>) {
        let Some(l) = &self.loaded else {
            self.open_source(name, source);
            return;
        };
        match Doc::open(source) {
            Ok(other) => match export::merge(&[&l.doc, &other]) {
                Ok(bytes) => {
                    self.open_bytes("merged.pdf", bytes);
                    self.toast(format!("Merged with {name} - save to keep it"));
                }
                Err(e) => self.toast(e),
            },
            Err(e) => self.toast(format!("Cannot merge {name}: {e}")),
        }
    }

    pub(crate) fn over_list(&self, x: f32, y: f32) -> Option<usize> {
        self.lists.iter().rev().find(|(r, _)| r.contains(x, y)).map(|(_, i)| *i)
    }

    fn text(&mut self, t: &str) {
        match self.focus {
            Focus::Edit => {
                if let Some(e) = &mut self.edit {
                    e.line.insert(t)
                }
            }
            Focus::Search => {
                self.search.line.insert(t);
                self.start_search();
            }
            Focus::Palette => {
                self.pal_line.insert(t);
                self.pal_sel = 0;
            }
            Focus::None => {
                if t.chars().count() == 1 {
                    let c = t.chars().next().unwrap().to_ascii_lowercase();
                    if let Some(tool) = Tool::ALL.iter().find(|x| x.key() == c) {
                        self.perform(Action::SetTool(*tool));
                    }
                }
            }
        }
    }

    fn key(&mut self, key: Key, m: Mods) {
        if m.ctrl {
            if let Key::Char(c) = key {
                match c.to_ascii_lowercase() {
                    'k' => return self.perform(Action::Palette),
                    'f' => return self.perform(Action::Search),
                    'o' => return self.perform(Action::Open),
                    's' => return self.perform(Action::Save),
                    'z' => return self.perform(if m.shift { Action::Redo } else { Action::Undo }),
                    'y' => return self.perform(Action::Redo),
                    '=' | '+' => return self.perform(Action::ZoomIn),
                    '-' => return self.perform(Action::ZoomOut),
                    '0' => return self.perform(Action::FitWidth),
                    'c' => return self.perform(Action::CopySel),
                    _ => {}
                }
            }
        }
        match self.focus {
            Focus::Palette => match key {
                Key::Escape => self.perform(Action::Palette),
                Key::Enter => {
                    let list = self.filtered_commands();
                    if let Some(&i) = list.get(self.pal_sel) {
                        self.perform(Action::PaletteItem(i));
                    }
                }
                Key::Down => self.pal_sel += 1,
                Key::Up => self.pal_sel = self.pal_sel.saturating_sub(1),
                Key::Backspace => {
                    self.pal_line.backspace();
                    self.pal_sel = 0;
                }
                Key::Left => self.pal_line.left(),
                Key::Right => self.pal_line.right(),
                _ => {}
            },
            Focus::Edit | Focus::Search => {
                let is_edit = self.focus == Focus::Edit;
                match key {
                    Key::Escape => {
                        if is_edit {
                            self.cancel_edit()
                        } else {
                            self.end_focus()
                        }
                    }
                    Key::Enter => {
                        if is_edit {
                            self.apply_edit()
                        } else if m.shift {
                            self.perform(Action::SearchPrev)
                        } else {
                            self.perform(Action::SearchNext)
                        }
                    }
                    k => {
                        let line = if is_edit { self.edit.as_mut().map(|e| &mut e.line) } else { Some(&mut self.search.line) };
                        if let Some(line) = line {
                            match k {
                                Key::Backspace => line.backspace(),
                                Key::Delete => line.delete(),
                                Key::Left => line.left(),
                                Key::Right => line.right(),
                                Key::Home => line.home(),
                                Key::End => line.end(),
                                _ => {}
                            }
                        }
                        if !is_edit && matches!(k, Key::Backspace | Key::Delete) {
                            self.start_search();
                        }
                    }
                }
            }
            Focus::None => match key {
                Key::Escape => {
                    self.sel = Selection::None;
                    self.sheet = None;
                    self.sheet_f.set(0.0);
                }
                Key::PageDown | Key::Down if matches!(key, Key::PageDown) => self.perform(Action::NextPage),
                Key::PageUp => self.perform(Action::PrevPage),
                Key::Down => self.scroll_by(0.0, 80.0),
                Key::Up => self.scroll_by(0.0, -80.0),
                Key::Right => self.scroll_by(80.0, 0.0),
                Key::Left => self.scroll_by(-80.0, 0.0),
                Key::Home => self.go_page(0),
                Key::End => self.go_page(self.page_count().saturating_sub(1)),
                Key::Delete | Key::Backspace => self.perform(Action::DeleteAnnot),
                Key::Char(c) if !m.ctrl => self.text(&c.to_string()),
                _ => {}
            },
        }
    }

    // -------------------------------------------------------------- actions
    pub fn perform(&mut self, a: Action) {
        self.dirty = true;
        match a {
            Action::Noop => {}
            Action::Open => self.effects.push(Effect::PickFile { merge: false }),
            Action::OpenSample => self.open_sample(),
            Action::Merge => self.effects.push(Effect::PickFile { merge: true }),
            Action::Save => self.save(),
            Action::Undo => {
                if let Some(l) = &mut self.loaded {
                    if l.editor.undo() {
                        self.toast("Undo");
                    }
                }
                self.after_edit();
            }
            Action::Redo => {
                if let Some(l) = &mut self.loaded {
                    if l.editor.redo() {
                        self.toast("Redo");
                    }
                }
                self.after_edit();
            }
            Action::ZoomIn => {
                let c = self.canvas();
                self.zoom_at(1.25, c.x + c.w / 2.0, c.y + c.h / 2.0)
            }
            Action::ZoomOut => {
                let c = self.canvas();
                self.zoom_at(0.8, c.x + c.w / 2.0, c.y + c.h / 2.0)
            }
            Action::FitWidth => {
                self.view.fit = Some(true);
                self.refit();
                self.go_page(self.view.cur);
            }
            Action::FitPage => {
                self.view.fit = Some(false);
                self.refit();
                self.go_page(self.view.cur);
            }
            Action::SetMode(m) => {
                self.view.mode = m;
                self.view.reading = false;
                self.relayout();
                self.refit();
                self.go_page(self.view.cur);
            }
            Action::ToggleRail => {
                if self.bp() == Bp::Desktop {
                    self.rail.set(if self.rail.target > 0.5 { 0.0 } else { 1.0 });
                } else {
                    self.perform(Action::Sheet(SheetKind::Pages));
                }
            }
            Action::RailTab(t) => self.rail_tab = t,
            Action::SetTool(t) => {
                self.tool = t;
                if t == Tool::Highlight && self.color == 5 {
                    self.color = 0;
                }
                self.sel = Selection::None;
                self.edit = None;
                self.end_focus();
                self.toast(t.label());
            }
            Action::Palette => {
                self.palette = !self.palette;
                self.pal_open.set(if self.palette { 1.0 } else { 0.0 });
                self.pal_line = LineEdit::default();
                self.pal_sel = 0;
                if self.palette {
                    self.focus = Focus::Edit;
                    self.end_focus();
                    self.focus = Focus::Palette;
                    self.effects.push(Effect::TextFocus(true));
                } else {
                    self.end_focus();
                }
            }
            Action::PaletteItem(i) => {
                let cmds = crate::chrome::commands();
                let act = cmds.get(i).map(|c| c.2.clone());
                self.palette = false;
                self.pal_open.set(0.0);
                self.end_focus();
                if let Some(act) = act {
                    self.perform(act);
                }
            }
            Action::ToggleTheme => self.th = if self.th.dark { Theme::light() } else { Theme::dark() },
            Action::GoPage(i) => {
                self.view.reading = false;
                self.go_page(i);
                if self.bp() != Bp::Desktop {
                    self.sheet = None;
                    self.sheet_f.set(0.0);
                }
            }
            Action::NextPage => self.go_page(self.view.cur + 1),
            Action::PrevPage => self.go_page(self.view.cur.saturating_sub(1)),
            Action::Color(i) => self.color = i,
            Action::Width(i) => self.width_i = i,
            Action::Sheet(k) => {
                if self.sheet == Some(k) {
                    self.perform(Action::CloseSheet);
                } else {
                    self.sheet = Some(k);
                    self.sheet_f.set(if k == SheetKind::Search || self.bp() == Bp::Tablet { 0.62 } else { 0.55 });
                    if k == SheetKind::Search {
                        self.focus = Focus::Search;
                        self.effects.push(Effect::TextFocus(true));
                    } else {
                        self.end_focus();
                    }
                }
            }
            Action::CloseSheet => {
                self.sheet = None;
                self.sheet_f.set(0.0);
                if self.focus == Focus::Search {
                    self.end_focus();
                }
            }
            Action::Search => {
                if self.bp() == Bp::Desktop {
                    self.rail.set(1.0);
                    self.rail_tab = RailTab::Pages;
                    self.sheet = Some(SheetKind::Search);
                    self.sheet_f.set(1.0);
                    self.focus = Focus::Search;
                    self.effects.push(Effect::TextFocus(true));
                } else {
                    self.sheet = None;
                    self.perform(Action::Sheet(SheetKind::Search));
                }
            }
            Action::SearchNext | Action::SearchPrev => {
                let n = self.search_total();
                if n > 0 {
                    let c = self.search.cur;
                    let next = if a == Action::SearchNext { (c + 1) % n } else { (c + n - 1) % n };
                    self.goto_match(next);
                }
            }
            Action::Bookmark => {
                let cur = self.view.cur;
                if let Some(l) = &mut self.loaded {
                    if let Some(p) = l.bookmarks.iter().position(|b| *b == cur) {
                        l.bookmarks.remove(p);
                        self.toast("Bookmark removed");
                    } else {
                        l.bookmarks.push(cur);
                        l.bookmarks.sort_unstable();
                        self.toast(format!("Bookmarked page {}", cur + 1));
                    }
                }
            }
            Action::Reading => {
                self.view.reading = !self.view.reading;
                self.view.reading_y = 0.0;
                self.sheet = None;
                self.sheet_f.set(0.0);
            }
            Action::RotatePage => {
                let cur = self.view.cur;
                if let Some(l) = &mut self.loaded {
                    if let Err(e) = l.editor.rotate_page(cur, 90) {
                        self.toast(e.to_string());
                    }
                }
                self.after_edit();
            }
            Action::DeletePage => {
                let cur = self.view.cur;
                if let Some(l) = &mut self.loaded {
                    match l.editor.delete_page(cur) {
                        Ok(_) => self.toast(format!("Deleted page {}", cur + 1)),
                        Err(e) => self.toast(e.to_string()),
                    }
                }
                self.after_edit();
            }
            Action::MovePage(d) => {
                let cur = self.view.cur as i32;
                let to = cur + d;
                if to >= 0 && (to as usize) < self.page_count() {
                    if let Some(l) = &mut self.loaded {
                        if let Err(e) = l.editor.move_page(cur as usize, to as usize) {
                            self.toast(e.to_string());
                        }
                    }
                    self.after_edit();
                    self.go_page(to as usize);
                }
            }
            Action::ExtractPage => {
                let cur = self.view.cur;
                if let Some(l) = &self.loaded {
                    match export::split(&l.doc, &[cur]) {
                        Ok(bytes) => {
                            let base = l.name.trim_end_matches(".pdf").to_string();
                            self.effects.push(Effect::SaveFile { name: format!("{base}-page-{}.pdf", cur + 1), bytes });
                            self.toast("Page extracted");
                        }
                        Err(e) => self.toast(e),
                    }
                }
            }
            Action::DeleteAnnot => {
                if let Selection::Annot { page, id, .. } = &self.sel {
                    let (page, id) = (*page, *id);
                    if let Some(l) = &mut self.loaded {
                        let _ = l.editor.delete_annot(page, id);
                    }
                    self.after_edit();
                    self.toast("Annotation deleted");
                }
            }
            Action::ApplyEdit => self.apply_edit(),
            Action::CancelEdit => self.cancel_edit(),
            Action::CopySel => {
                if let Selection::Text { page, range } = self.sel {
                    if let Some(l) = &self.loaded {
                        if let Some(dl) = l.tiles.dl(page) {
                            let s = dl.page_text().slice(range);
                            self.effects.push(Effect::Copy(s));
                            self.toast("Copied");
                        }
                    }
                }
            }
            Action::HighlightSel => self.highlight_selection(),
            Action::FocusSearch => {
                self.focus = Focus::Search;
                self.effects.push(Effect::TextFocus(true));
            }
            Action::Match(i) => self.goto_match(i),
            Action::DockGrip | Action::SheetGrip => {}
        }
    }

    pub(crate) fn filtered_commands(&self) -> Vec<usize> {
        let q: Vec<char> = self.pal_line.text.to_lowercase().chars().filter(|c| !c.is_whitespace()).collect();
        crate::chrome::commands()
            .iter()
            .enumerate()
            .filter(|(_, c)| {
                let t = c.0.to_lowercase();
                let mut it = t.chars();
                q.iter().all(|qc| it.any(|tc| tc == *qc))
            })
            .map(|(i, _)| i)
            .collect()
    }

    // -------------------------------------------------------------- pointer
    fn pointer(&mut self, phase: Phase, id: u64, x: f32, y: f32, kind: PointerKind, button: u8) {
        self.hover = (x, y);
        let t = self.now;
        if kind == PointerKind::Touch {
            match phase {
                Phase::Down => {
                    self.touches.down(id, (x, y), t);
                    if self.touches.count() >= 2 {
                        self.drag = Drag::None;
                        self.view.vel = (0.0, 0.0);
                    }
                }
                Phase::Move => {
                    if let Some(p) = self.touches.moved(id, (x, y)) {
                        if (p.scale - 1.0).abs() > 0.0005 {
                            self.zoom_at(p.scale, p.center.0, p.center.1);
                        }
                        self.scroll_by(-p.pan.0, -p.pan.1);
                        return;
                    }
                }
                Phase::Up | Phase::Cancel => {
                    let tap = self.touches.up(id, t);
                    let multi = self.touches.multi() || tap.is_some();
                    match tap {
                        Some(Tap::TwoFinger) => self.perform(Action::Undo),
                        Some(Tap::ThreeFinger) => self.perform(Action::Redo),
                        None => {}
                    }
                    if multi || self.touches.count() > 0 {
                        self.drag = Drag::None;
                        return;
                    }
                }
            }
            if self.touches.count() >= 2 {
                return;
            }
        }
        match phase {
            Phase::Down => self.pointer_down(x, y, kind, button),
            Phase::Move => self.pointer_move(x, y),
            Phase::Up | Phase::Cancel => self.pointer_up(x, y, phase == Phase::Cancel),
        }
    }

    fn pointer_down(&mut self, x: f32, y: f32, kind: PointerKind, button: u8) {
        self.view.vel = (0.0, 0.0);
        // chrome first
        if let Some((r, a)) = self.hits.iter().rev().find(|(r, _)| r.contains(x, y)).cloned() {
            match a {
                Action::DockGrip => {
                    self.drag = Drag::Dock { dx: self.dock_x.v - x, dy: self.dock_y.v - y };
                    return;
                }
                Action::SheetGrip => {
                    self.drag = Drag::Sheet { y0: y, f0: self.sheet_f.v };
                    return;
                }
                _ => {}
            }
            let in_list = self.over_list(x, y);
            match (a.clone(), in_list) {
                (Action::Noop, Some(li)) => {
                    self.drag = Drag::List { list: li, y0: y, s0: self.rail_scroll[li], moved: false, action: None }
                }
                (act, Some(li)) => self.drag = Drag::List { list: li, y0: y, s0: self.rail_scroll[li], moved: false, action: Some(act) },
                (act, None) => self.drag = Drag::Press { action: act, rect: r },
            }
            return;
        }
        if self.palette {
            self.perform(Action::Palette);
            return;
        }
        if let Some(li) = self.over_list(x, y) {
            self.drag = Drag::List { list: li, y0: y, s0: self.rail_scroll[li], moved: false, action: None };
            return;
        }
        if self.in_chrome(x, y) {
            return;
        }
        if button == 2 {
            return;
        }
        if self.focus == Focus::Search || self.focus == Focus::Palette {
            self.end_focus();
        }
        if self.view.reading {
            self.drag = Drag::Pan { last: (x, y), moved: 0.0, down: (x, y), kind, hist: vec![(self.now, x, y)] };
            return;
        }
        let pointer_draws = kind != PointerKind::Mouse || self.tool != Tool::Hand;
        let _ = pointer_draws;
        let hit = self.hit_page(x, y);
        match (self.tool, hit) {
            (Tool::Hand, _) | (_, None) => {
                self.drag = Drag::Pan { last: (x, y), moved: 0.0, down: (x, y), kind, hist: vec![(self.now, x, y)] };
            }
            (Tool::Select, Some((page, px, py))) | (Tool::Highlight, Some((page, px, py))) => {
                let anchor = self.loaded.as_ref().and_then(|l| l.tiles.dl(page)).and_then(|dl| dl.page_text().hit(px, py));
                self.sel = Selection::None;
                match anchor {
                    Some(a) => {
                        self.drag = Drag::Text { page, anchor: a };
                        self.sel = Selection::Text { page, range: (a, a) };
                    }
                    None => self.drag = Drag::Pan { last: (x, y), moved: 0.0, down: (x, y), kind, hist: vec![(self.now, x, y)] },
                }
            }
            (Tool::Ink, Some((page, px, py))) | (Tool::Sign, Some((page, px, py))) => {
                self.drag = Drag::Stroke { page, pts: vec![(px, py)] };
            }
            (Tool::Note, Some((page, px, py))) => self.start_edit(EditKind::NewNote { page, pos: (px, py) }, "New note", ""),
            (Tool::TextBox, Some((page, px, py))) | (Tool::Redact, Some((page, px, py))) => {
                self.drag = Drag::Rect { page, a: (px, py), b: (px, py) };
            }
            (Tool::EditText, Some((page, px, py))) => {
                let run = self.loaded.as_ref().and_then(|l| l.tiles.dl(page)).and_then(|dl| {
                    dl.runs.iter().enumerate().find(|(_, r)| r.op_index.is_some() && px >= r.rect[0] && px <= r.rect[2] && py >= r.rect[1] && py <= r.rect[3]).map(|(i, r)| (i, r.op_index.unwrap(), r.text()))
                });
                match run {
                    Some((ri, op, text)) => {
                        self.sel = Selection::Run { page, run: ri };
                        self.start_edit(EditKind::Run { page, op }, "Edit text", &text);
                    }
                    None => self.toast("No editable text here"),
                }
            }
        }
    }

    pub(crate) fn in_chrome(&self, x: f32, y: f32) -> bool {
        self.hits.iter().any(|(r, a)| *a != Action::Noop && r.contains(x, y))
    }

    fn pointer_move(&mut self, x: f32, y: f32) {
        match &mut self.drag {
            Drag::Pan { last, moved, kind, hist, .. } => {
                let (dx, dy) = (x - last.0, y - last.1);
                *moved += dx.abs() + dy.abs();
                *last = (x, y);
                hist.push((self.now, x, y));
                if hist.len() > 6 {
                    hist.remove(0);
                }
                let _ = kind;
                self.scroll_by(-dx, -dy);
            }
            Drag::Stroke { page, .. } => {
                let page = *page;
                let (px, py) = self.clamp_to_page(page, x, y);
                if let Drag::Stroke { pts, .. } = &mut self.drag {
                    if pts.last().map_or(true, |l| (l.0 - px).powi(2) + (l.1 - py).powi(2) > 0.5) {
                        pts.push((px, py));
                    }
                }
            }
            Drag::Rect { page, .. } => {
                let page = *page;
                let p = self.clamp_to_page(page, x, y);
                if let Drag::Rect { b, .. } = &mut self.drag {
                    *b = p;
                }
            }
            Drag::Text { page, anchor } => {
                let (page, anchor) = (*page, *anchor);
                let p = self.clamp_to_page(page, x, y);
                let cur = self.loaded.as_ref().and_then(|l| l.tiles.dl(page)).and_then(|dl| dl.page_text().hit(p.0, p.1));
                if let Some(c) = cur {
                    self.sel = Selection::Text { page, range: (anchor.min(c), anchor.max(c) + 1) };
                }
            }
            Drag::List { list, y0, s0, moved, .. } => {
                if (y - *y0).abs() > 6.0 {
                    *moved = true;
                }
                if *moved {
                    let li = *list;
                    self.rail_scroll[li] = (*s0 - (y - *y0)).max(0.0);
                }
            }
            Drag::Dock { dx, dy } => {
                let (nx, ny) = (x + *dx, y + *dy);
                self.dock_x.snap(nx.clamp(30.0, self.w - 30.0));
                self.dock_y.snap(ny.clamp(30.0, self.h - 30.0));
            }
            Drag::Sheet { y0, f0 } => {
                let f = (*f0 + (*y0 - y) / self.h).clamp(0.0, 0.95);
                self.sheet_f.snap(f);
            }
            _ => {}
        }
    }

    fn pointer_up(&mut self, x: f32, y: f32, cancel: bool) {
        let drag = std::mem::replace(&mut self.drag, Drag::None);
        match drag {
            Drag::Press { action, rect } => {
                if !cancel && rect.contains(x, y) {
                    self.perform(action);
                }
            }
            Drag::List { moved, action, .. } => {
                if !cancel && !moved {
                    if let Some(a) = action {
                        self.perform(a);
                    }
                }
            }
            Drag::Pan { moved, down, kind, hist, .. } => {
                if moved < 6.0 && !cancel {
                    self.canvas_click(down.0, down.1);
                } else if kind != PointerKind::Mouse || self.view.reading {
                    if let (Some(first), Some(last)) = (hist.first(), hist.last()) {
                        let dt = ((last.0 - first.0) / 1000.0) as f32;
                        if dt > 0.0 && (self.now - last.0) < 80.0 {
                            self.view.vel = ((last.1 - first.1) / dt, (last.2 - first.2) / dt);
                        }
                    }
                }
            }
            Drag::Stroke { page, pts } => {
                if cancel || pts.is_empty() {
                    return;
                }
                let color = if self.tool == Tool::Sign { [0.05, 0.12, 0.45] } else { self.color3() };
                let width = WIDTHS[self.width_i.min(2)];
                let is_sign = self.tool == Tool::Sign;
                if let Some(l) = &mut self.loaded {
                    let r = if is_sign { l.editor.add_signature(page, &[pts], color) } else { l.editor.add_ink(page, &[pts], color, width, false) };
                    if let Err(e) = r {
                        self.toast(e.to_string());
                    }
                }
                self.after_edit();
            }
            Drag::Rect { page, a, b } => {
                if cancel {
                    return;
                }
                let mut r = [a.0.min(b.0), a.1.min(b.1), a.0.max(b.0), a.1.max(b.1)];
                if self.tool == Tool::Redact {
                    if r[2] - r[0] < 3.0 || r[3] - r[1] < 3.0 {
                        return;
                    }
                    if let Some(l) = &mut self.loaded {
                        match l.editor.redact(page, r) {
                            Ok(n) => self.toast(format!("Redacted - {n} text run(s) permanently removed")),
                            Err(e) => self.toast(e.to_string()),
                        }
                    }
                    self.after_edit();
                } else {
                    if r[2] - r[0] < 12.0 || r[3] - r[1] < 12.0 {
                        r = [a.0, a.1, a.0 + 190.0, a.1 + 40.0];
                    }
                    self.start_edit(EditKind::NewBox { page, rect: r }, "Text box", "");
                }
            }
            Drag::Text { page, .. } => {
                if let Selection::Text { range, .. } = self.sel {
                    if range.1 <= range.0 + 1 && range.0 == range.1 {
                        self.sel = Selection::None;
                    } else if self.tool == Tool::Highlight {
                        let _ = page;
                        self.highlight_selection();
                    }
                }
            }
            Drag::Dock { .. } => {
                // magnetic snap to the nearest edge; orientation follows the edge
                let (cx, cy) = (self.dock_x.v, self.dock_y.v);
                let (dl, dr, dt, db) = (cx, self.w - cx, cy, self.h - cy);
                let m = dl.min(dr).min(dt).min(db);
                if m == dl || m == dr {
                    self.dock_vertical = true;
                    self.dock_x.set(if m == dl { 30.0 } else { self.w - 30.0 });
                    self.dock_y.set(cy.clamp(160.0, self.h - 160.0));
                } else {
                    self.dock_vertical = false;
                    self.dock_y.set(if m == dt { 36.0 } else { self.h - 36.0 });
                    self.dock_x.set(cx.clamp(260.0, self.w - 260.0));
                }
            }
            Drag::Sheet { .. } => {
                let f = self.sheet_f.v;
                if f < 0.2 {
                    self.perform(Action::CloseSheet);
                } else {
                    let snaps = [0.45f32, 0.9];
                    let t = if (f - snaps[0]).abs() < (f - snaps[1]).abs() { snaps[0] } else { snaps[1] };
                    self.sheet_f.target = t;
                }
            }
            Drag::None => {}
        }
    }

    fn canvas_click(&mut self, x: f32, y: f32) {
        if self.view.reading {
            return;
        }
        let Some((page, px, py)) = self.hit_page(x, y) else {
            self.sel = Selection::None;
            return;
        };
        let Some(dl) = self.loaded.as_ref().and_then(|l| l.tiles.dl(page)) else { return };
        let inside = |r: &[f32; 4]| px >= r[0] && px <= r[2] && py >= r[1] && py <= r[3];
        for a in dl.annots.iter().rev() {
            if !inside(&a.rect) {
                continue;
            }
            if let Some(f) = &a.field {
                match f.ftype.as_str() {
                    "Btn" => {
                        if let Some(l) = &mut self.loaded {
                            match l.editor.toggle_checkbox(page, a.id, f.field_id) {
                                Ok(on) => self.toast(if on { "Checked" } else { "Unchecked" }),
                                Err(e) => self.toast(e.to_string()),
                            }
                        }
                        self.after_edit();
                    }
                    "Tx" => {
                        let title = format!("Field: {}", f.name);
                        self.start_edit(EditKind::Field { page, field: f.field_id }, &title, &f.value.clone());
                    }
                    _ => self.toast("This field type is not supported yet"),
                }
                return;
            }
            if let Some(link) = &a.link {
                match link.clone() {
                    LinkTarget::Uri(u) => self.effects.push(Effect::OpenUrl(u)),
                    LinkTarget::Page(p) => self.go_page(p),
                }
                return;
            }
            if !matches!(a.subtype.as_str(), "Link" | "Widget" | "Popup") {
                self.sel = Selection::Annot { page, id: a.id, subtype: a.subtype.clone() };
                return;
            }
        }
        self.sel = Selection::None;
    }
}

impl Loaded {
    pub(crate) fn refresh_sizes(&mut self) {
        let n = self.doc.page_count();
        self.sizes = (0..n).map(|i| self.tiles.renderer.page_size(i).unwrap_or((595.0, 842.0))).collect();
        self.max_w = self.sizes.iter().map(|s| s.0).fold(0.0, f32::max);
        self.reflow = vec![None; n];
        self.reflow_w = 0.0;
    }

    pub(crate) fn layout(&mut self, mode: ViewMode, cur: usize) {
        let n = self.sizes.len();
        let mut rects = Vec::with_capacity(n);
        let max_w = self.max_w;
        match mode {
            ViewMode::Continuous => {
                let mut y = MARGIN;
                for &(w, h) in &self.sizes {
                    rects.push(Rect::new(MARGIN + (max_w - w) / 2.0, y, w, h));
                    y += h + GAP;
                }
                self.content = (max_w + MARGIN * 2.0, y - GAP + MARGIN);
            }
            ViewMode::Single => {
                for &(w, h) in &self.sizes {
                    rects.push(Rect::new(MARGIN + (max_w - w) / 2.0, MARGIN, w, h));
                }
                let h = self.sizes.get(cur).map_or(100.0, |s| s.1);
                self.content = (max_w + MARGIN * 2.0, h + MARGIN * 2.0);
            }
            ViewMode::TwoPage => {
                let mut y = MARGIN;
                let mut i = 0;
                while i < n {
                    let (w0, h0) = self.sizes[i];
                    let right = self.sizes.get(i + 1).copied();
                    let rh = right.map_or(h0, |r| r.1.max(h0));
                    rects.push(Rect::new(MARGIN + max_w - w0, y, w0, h0));
                    if let Some((w1, h1)) = right {
                        rects.push(Rect::new(MARGIN + max_w + GAP, y, w1, h1));
                    }
                    y += rh + GAP;
                    i += 2;
                }
                self.content = (max_w * 2.0 + GAP + MARGIN * 2.0, y - GAP + MARGIN);
            }
        }
        self.rects = rects;
    }

    pub(crate) fn reflow_page(&mut self, page: usize, width: f32, base: f32) -> Arc<Vec<RLine>> {
        if (self.reflow_w - width).abs() > 1.0 {
            self.reflow = vec![None; self.sizes.len()];
            self.reflow_w = width;
        }
        if let Some(Some(r)) = self.reflow.get(page) {
            return r.clone();
        }
        let lines = self.tiles.dl(page).map(|dl| reflow(&dl, width, base)).unwrap_or_default();
        let a = Arc::new(lines);
        if page < self.reflow.len() {
            self.reflow[page] = Some(a.clone());
        }
        a
    }
}

#[allow(dead_code)]
fn _unused(_: VecDeque<u8>) {}
