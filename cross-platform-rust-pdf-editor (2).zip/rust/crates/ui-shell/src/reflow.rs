//! Smart text-reflow reading mode: rebuilds paragraphs from positioned runs
//! and word-wraps them to the screen width.

use pdf_render::font::text_width;
use pdf_render::{DisplayList, FONT_SANS, FONT_SANS_BOLD};

#[derive(Clone, Debug)]
pub struct RLine {
    pub text: String,
    pub size: f32,
    pub bold: bool,
    pub gap_before: f32,
}

struct L {
    text: String,
    y: f32,
    size: f32,
    x1: f32,
}

pub fn reflow(dl: &DisplayList, width: f32, base: f32) -> Vec<RLine> {
    let mut lines: Vec<L> = Vec::new();
    for r in &dl.runs {
        let t = r.text();
        if t.trim().is_empty() {
            continue;
        }
        match lines.last_mut() {
            Some(l) if (r.rect[1] - l.y).abs() < l.size.max(4.0) * 0.6 => {
                if r.rect[0] - l.x1 > l.size * 0.15 && !l.text.ends_with(' ') && !t.starts_with(' ') {
                    l.text.push(' ');
                }
                l.text.push_str(&t);
                l.x1 = r.rect[2];
            }
            _ => lines.push(L { text: t, y: r.rect[1], size: r.font_size.max(4.0), x1: r.rect[2] }),
        }
    }
    let mut sizes: Vec<f32> = lines.iter().map(|l| l.size).collect();
    sizes.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    let median = sizes.get(sizes.len() / 2).copied().unwrap_or(10.0);
    // paragraphs
    let mut paras: Vec<(String, f32, bool)> = Vec::new();
    let mut prev: Option<(f32, f32)> = None;
    for l in &lines {
        let heading = l.size > median * 1.2;
        let new_para = match prev {
            Some((py, ps)) => (l.y - py).abs() > l.size.max(ps) * 1.55 || (l.size - ps).abs() > ps * 0.15,
            None => true,
        };
        if new_para || paras.is_empty() {
            paras.push((l.text.trim().to_string(), l.size, heading));
        } else {
            let p = paras.last_mut().unwrap();
            if p.0.ends_with('-') {
                p.0.pop();
            } else {
                p.0.push(' ');
            }
            p.0.push_str(l.text.trim());
        }
        prev = Some((l.y, l.size));
    }
    let mut out = Vec::new();
    for (text, _, heading) in paras {
        let size = if heading { base * 1.3 } else { base };
        let font = if heading { FONT_SANS_BOLD } else { FONT_SANS };
        let mut cur = String::new();
        let mut first = true;
        for word in text.split_whitespace() {
            let cand = if cur.is_empty() { word.to_string() } else { format!("{cur} {word}") };
            if !cur.is_empty() && text_width(font, &cand, size) > width {
                out.push(RLine { text: std::mem::take(&mut cur), size, bold: heading, gap_before: if first { size * 0.9 } else { 0.0 } });
                first = false;
                cur = word.to_string();
            } else {
                cur = cand;
            }
        }
        if !cur.is_empty() {
            out.push(RLine { text: cur, size, bold: heading, gap_before: if first { size * 0.9 } else { 0.0 } });
        }
    }
    out
}
