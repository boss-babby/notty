//! Springs, touch gesture recognition (pinch / two- & three-finger taps),
//! and a single-line text editor.

use std::collections::HashMap;

/// Critically-damped-ish spring for micro-animations.
#[derive(Clone, Copy, Debug)]
pub struct Spring {
    pub v: f32,
    pub target: f32,
    pub vel: f32,
}
impl Spring {
    pub fn new(v: f32) -> Spring {
        Spring { v, target: v, vel: 0.0 }
    }
    pub fn set(&mut self, t: f32) {
        self.target = t;
    }
    pub fn snap(&mut self, t: f32) {
        self.v = t;
        self.target = t;
        self.vel = 0.0;
    }
    pub fn settled(&self) -> bool {
        (self.v - self.target).abs() < 0.002 && self.vel.abs() < 0.01
    }
    /// Returns true while still moving.
    pub fn step(&mut self, dt: f32) -> bool {
        if self.settled() {
            self.v = self.target;
            self.vel = 0.0;
            return false;
        }
        let (k, c) = (380.0f32, 2.0 * 380.0f32.sqrt() * 0.82);
        let n = ((dt / 0.004).ceil() as i32).clamp(1, 12);
        let h = dt / n as f32;
        for _ in 0..n {
            let acc = k * (self.target - self.v) - c * self.vel;
            self.vel += acc * h;
            self.v += self.vel * h;
        }
        true
    }
}

#[derive(Clone, Copy, Debug)]
struct Touch {
    start: (f32, f32),
    cur: (f32, f32),
    t0: f64,
    moved: f32,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Tap {
    TwoFinger,
    ThreeFinger,
}

#[derive(Default)]
pub struct Touches {
    pts: HashMap<u64, Touch>,
    max_fingers: usize,
    gesture_t0: f64,
    last: Option<(f32, (f32, f32))>,
    max_moved: f32,
}

pub struct Pinch {
    pub center: (f32, f32),
    pub scale: f32,
    pub pan: (f32, f32),
}

impl Touches {
    pub fn count(&self) -> usize {
        self.pts.len()
    }
    pub fn down(&mut self, id: u64, p: (f32, f32), t: f64) {
        if self.pts.is_empty() {
            self.max_fingers = 0;
            self.gesture_t0 = t;
            self.max_moved = 0.0;
        }
        self.pts.insert(id, Touch { start: p, cur: p, t0: t, moved: 0.0 });
        self.max_fingers = self.max_fingers.max(self.pts.len());
        self.last = None;
    }
    pub fn moved(&mut self, id: u64, p: (f32, f32)) -> Option<Pinch> {
        let before = self.pair();
        if let Some(t) = self.pts.get_mut(&id) {
            t.moved = t.moved.max(((p.0 - t.start.0).powi(2) + (p.1 - t.start.1).powi(2)).sqrt());
            self.max_moved = self.max_moved.max(t.moved);
            t.cur = p;
        }
        if self.pts.len() < 2 {
            return None;
        }
        let now = self.pair()?;
        let r = match before.or(self.last) {
            Some((d0, c0)) if d0 > 1.0 => Some(Pinch { center: now.1, scale: now.0 / d0, pan: (now.1 .0 - c0.0, now.1 .1 - c0.1) }),
            _ => None,
        };
        self.last = Some(now);
        r
    }
    fn pair(&self) -> Option<(f32, (f32, f32))> {
        let mut it = self.pts.values();
        let a = it.next()?;
        let b = it.next()?;
        let d = ((a.cur.0 - b.cur.0).powi(2) + (a.cur.1 - b.cur.1).powi(2)).sqrt();
        Some((d, ((a.cur.0 + b.cur.0) / 2.0, (a.cur.1 + b.cur.1) / 2.0)))
    }
    pub fn up(&mut self, id: u64, t: f64) -> Option<Tap> {
        self.pts.remove(&id);
        self.last = None;
        if self.pts.is_empty() {
            let quick = t - self.gesture_t0 < 320.0 && self.max_moved < 14.0;
            let r = match (quick, self.max_fingers) {
                (true, 2) => Some(Tap::TwoFinger),
                (true, 3) => Some(Tap::ThreeFinger),
                _ => None,
            };
            self.max_fingers = 0;
            return r;
        }
        None
    }
    pub fn clear(&mut self) {
        self.pts.clear();
        self.max_fingers = 0;
        self.last = None;
    }
    pub fn multi(&self) -> bool {
        self.max_fingers >= 2
    }
}

/// Minimal single-line editor.
#[derive(Clone, Debug, Default)]
pub struct LineEdit {
    pub text: String,
    pub caret: usize,
}
impl LineEdit {
    pub fn with(s: &str) -> LineEdit {
        LineEdit { text: s.to_string(), caret: s.chars().count() }
    }
    fn byte(&self, ci: usize) -> usize {
        self.text.char_indices().nth(ci).map(|(i, _)| i).unwrap_or(self.text.len())
    }
    pub fn insert(&mut self, s: &str) {
        let b = self.byte(self.caret);
        let clean: String = s.chars().filter(|c| !c.is_control()).collect();
        self.text.insert_str(b, &clean);
        self.caret += clean.chars().count();
    }
    pub fn backspace(&mut self) {
        if self.caret > 0 {
            let b = self.byte(self.caret - 1);
            self.text.remove(b);
            self.caret -= 1;
        }
    }
    pub fn delete(&mut self) {
        if self.caret < self.text.chars().count() {
            let b = self.byte(self.caret);
            self.text.remove(b);
        }
    }
    pub fn left(&mut self) {
        self.caret = self.caret.saturating_sub(1);
    }
    pub fn right(&mut self) {
        self.caret = (self.caret + 1).min(self.text.chars().count());
    }
    pub fn home(&mut self) {
        self.caret = 0;
    }
    pub fn end(&mut self) {
        self.caret = self.text.chars().count();
    }
}
