//! Async tile pipeline: display-list building and rasterisation run on worker
//! threads (rayon) natively, or cooperatively (one job per frame) on Wasm.

use pdf_render::cache::{pixmap_bytes, tile_cache, ByteLru, MemoryBudget, TileCache, TileKey};
use pdf_render::{render_tile, DisplayList, Renderer, TileSpec};
use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use tiny_skia::Pixmap;

pub type Job = Box<dyn FnOnce() + Send>;

#[derive(Default)]
pub struct Jobs {
    #[allow(dead_code)]
    queue: Mutex<VecDeque<Job>>,
}

impl Jobs {
    pub fn spawn(&self, job: Job) {
        #[cfg(not(target_arch = "wasm32"))]
        rayon::spawn(job);
        #[cfg(target_arch = "wasm32")]
        self.queue.lock().unwrap().push_back(job);
    }
    /// Cooperative executor (Wasm): run at most one queued job per call.
    pub fn pump(&self) {
        #[cfg(target_arch = "wasm32")]
        {
            let j = self.queue.lock().unwrap().pop_front();
            if let Some(j) = j {
                j();
            }
        }
    }
    pub fn pending(&self) -> usize {
        self.queue.lock().unwrap().len()
    }
}

pub const PROXY_SCALE: f32 = 0.4;

#[derive(Clone)]
pub struct TileService {
    pub renderer: Arc<Renderer>,
    pub budget: MemoryBudget,
    jobs: Arc<Jobs>,
    cache: Arc<Mutex<TileCache>>,
    dls: Arc<Mutex<ByteLru<(usize, u32), Arc<DisplayList>>>>,
    inflight: Arc<Mutex<HashSet<TileKey>>>,
    done: Arc<AtomicUsize>,
    seen: Arc<AtomicUsize>,
    revs: Arc<Mutex<(u32, HashMap<usize, u32>)>>,
}

impl TileService {
    pub fn new(renderer: Arc<Renderer>, budget: MemoryBudget) -> Self {
        TileService {
            renderer,
            budget,
            jobs: Arc::new(Jobs::default()),
            cache: Arc::new(Mutex::new(tile_cache(budget.tile_bytes))),
            dls: Arc::new(Mutex::new(ByteLru::new(budget.display_list_bytes))),
            inflight: Arc::new(Mutex::new(HashSet::new())),
            done: Arc::new(AtomicUsize::new(0)),
            seen: Arc::new(AtomicUsize::new(0)),
            revs: Arc::new(Mutex::new((0, HashMap::new()))),
        }
    }

    pub fn set_budget(&mut self, b: MemoryBudget) {
        self.budget = b;
        self.cache.lock().unwrap().set_budget(b.tile_bytes);
        self.dls.lock().unwrap().set_budget(b.display_list_bytes);
    }

    pub fn rev(&self, page: usize) -> u32 {
        let r = self.revs.lock().unwrap();
        r.0 + r.1.get(&page).copied().unwrap_or(0)
    }

    pub fn invalidate(&self, pages: Option<&[usize]>) {
        let mut r = self.revs.lock().unwrap();
        match pages {
            None => r.0 += 1000,
            Some(p) => {
                for i in p {
                    *r.1.entry(*i).or_insert(0) += 1;
                }
            }
        }
        drop(r);
        self.dls.lock().unwrap().clear();
        self.renderer.clear_caches();
    }

    /// Display list for a page (builds synchronously if not cached).
    pub fn dl(&self, page: usize) -> Option<Arc<DisplayList>> {
        let key = (page, self.rev(page));
        if let Some(d) = self.dls.lock().unwrap().get(&key) {
            return Some(d);
        }
        let dl = Arc::new(self.renderer.build(page).ok()?);
        let sz = dl.approx_bytes();
        self.dls.lock().unwrap().insert(key, dl.clone(), sz);
        Some(dl)
    }

    pub fn dl_peek(&self, page: usize) -> Option<Arc<DisplayList>> {
        let key = (page, self.rev(page));
        self.dls.lock().unwrap().get(&key)
    }

    pub fn tile(&self, key: &TileKey) -> Option<Arc<Pixmap>> {
        let mut c = self.cache.lock().unwrap();
        if let Some(t) = c.get(key) {
            return Some(t);
        }
        // stale-while-revalidate: show the previous revision until the new tile lands
        for back in 1..=3u32 {
            if key.rev >= back {
                let mut k = *key;
                k.rev -= back;
                if let Some(t) = c.get(&k) {
                    return Some(t);
                }
            }
        }
        None
    }

    pub fn has_exact(&self, key: &TileKey) -> bool {
        self.cache.lock().unwrap().contains(key)
    }

    pub fn inflight(&self) -> usize {
        self.inflight.lock().unwrap().len()
    }

    pub fn request(&self, key: TileKey, spec: TileSpec) {
        {
            let mut f = self.inflight.lock().unwrap();
            if f.contains(&key) || self.cache.lock().unwrap().contains(&key) {
                return;
            }
            f.insert(key);
        }
        let me = self.clone();
        self.jobs.spawn(Box::new(move || {
            if let Some(dl) = me.dl(key.page as usize) {
                if let Some(pm) = render_tile(&dl, &spec, Some([255, 255, 255, 255])) {
                    let n = pixmap_bytes(&pm);
                    me.cache.lock().unwrap().insert(key, Arc::new(pm), n);
                }
            }
            me.inflight.lock().unwrap().remove(&key);
            me.done.fetch_add(1, Ordering::SeqCst);
        }));
    }

    pub fn spawn(&self, job: Job) {
        self.jobs.spawn(job)
    }

    /// Drive cooperative jobs; true when new results arrived since last call.
    pub fn pump(&self) -> bool {
        self.jobs.pump();
        let d = self.done.load(Ordering::SeqCst);
        d != self.seen.swap(d, Ordering::SeqCst)
    }

    pub fn cache_bytes(&self) -> usize {
        self.cache.lock().unwrap().used()
    }
}

pub fn proxy_key(doc: u64, page: usize, rev: u32) -> TileKey {
    TileKey { doc, page: page as u32, scale_q: (PROXY_SCALE * 1000.0) as i32, tx: -1, ty: -1, rev }
}

pub fn quantize_scale(s: f32) -> f32 {
    let step = 1.25f32;
    let k = (s.max(0.05).ln() / step.ln()).round();
    step.powf(k).clamp(0.25, 12.0)
}
