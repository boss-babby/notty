import { bigint, integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

/** Downloadable build artifacts (Windows exe, source zip, …). Synced from public/downloads on demand. */
export const artifacts = pgTable("artifacts", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  platform: text("platform").notNull(),
  fileName: text("file_name").notNull(),
  sizeBytes: bigint("size_bytes", { mode: "number" }).notNull(),
  sha256: text("sha256").notNull(),
  downloads: integer("downloads").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

/** One row per click on "Open in browser" so the site can show real usage. */
export const viewerSessions = pgTable("viewer_sessions", {
  id: serial("id").primaryKey(),
  userAgent: text("user_agent").notNull().default(""),
  startedAt: timestamp("started_at").notNull().defaultNow(),
});
