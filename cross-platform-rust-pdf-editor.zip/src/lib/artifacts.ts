import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { gzipSync } from "node:zlib";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { artifacts } from "@/db/schema";

export const DOWNLOAD_DIR = path.join(process.cwd(), "public", "downloads");
const WASM_FILE = path.join(process.cwd(), "public", "wasm", "folio_bg.wasm");

const CATALOG = [
  {
    slug: "windows-x64",
    title: "Folio for Windows (x64)",
    description: "Single portable Folio.exe – no installer, no runtime. Built from this repository (Rust, GNU cross-build).",
    platform: "Windows",
    fileName: "Folio-windows-x64.zip",
  },
  {
    slug: "source",
    title: "Complete source code",
    description: "Rust workspace (all crates, platform shells, CI, docs, fuzz harness) plus this Next.js website.",
    platform: "All",
    fileName: "Folio-source.zip",
  },
  {
    slug: "web-bundle",
    title: "WebAssembly bundle",
    description: "The exact wasm + JS glue served at /viewer, for self-hosting on any static host.",
    platform: "Web",
    fileName: "Folio-web-wasm.zip",
  },
] as const;

async function sha256(file: string) {
  return createHash("sha256").update(await readFile(file)).digest("hex");
}

/** Make the artifacts table mirror what is actually on disk (sizes + checksums are never invented). */
export async function syncArtifacts() {
  for (const c of CATALOG) {
    const file = path.join(DOWNLOAD_DIR, c.fileName);
    if (!existsSync(file)) continue;
    const st = await stat(file);
    const hash = await sha256(file);
    await db
      .insert(artifacts)
      .values({ ...c, sizeBytes: st.size, sha256: hash })
      .onConflictDoUpdate({
        target: artifacts.slug,
        set: { sizeBytes: st.size, sha256: hash, title: c.title, description: c.description, fileName: c.fileName, updatedAt: sql`now()` },
      });
  }
  return db.select().from(artifacts).orderBy(artifacts.id);
}

let wasmCache: { mtime: number; raw: number; gz: number } | null = null;

/** Real size of the shipped wasm (raw + gzip) or null if the bundle is not present. */
export async function wasmSize() {
  if (!existsSync(WASM_FILE)) return null;
  const st = await stat(WASM_FILE);
  if (wasmCache && wasmCache.mtime === st.mtimeMs) return wasmCache;
  const buf = await readFile(WASM_FILE);
  wasmCache = { mtime: st.mtimeMs, raw: buf.length, gz: gzipSync(buf, { level: 9 }).length };
  return wasmCache;
}

export function fmtBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 ** 2) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 ** 2).toFixed(2)} MB`;
}
