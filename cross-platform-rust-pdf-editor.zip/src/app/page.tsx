import Link from "next/link";
import { fmtBytes, syncArtifacts, wasmSize } from "@/lib/artifacts";

export const dynamic = "force-dynamic";

const tiers = [
  { t: "T1 · Read", s: "Done", d: "Lazy open, continuous / single / two-page, pinch-zoom, tile rendering, search, selection & copy, outline, thumbnails, links, bookmarks, recents, light · sepia · dark · OLED." },
  { t: "T2 · Annotate", s: "Done", d: "Highlight, underline, strikeout, ink, notes, shapes, stamps, text boxes – real appearance streams other readers display. Fill & flatten text fields." },
  { t: "T3 · Organize", s: "Done", d: "Merge, split, extract, reorder, rotate, delete, insert blank/image pages, compress, metadata, AES-256 protect / unlock. Output is re-parsed before saving." },
  { t: "T4 · Advanced", s: "Partial", d: "Redaction by page rasterisation (true removal), image signatures, text boxes, PNG export. Digital (CMS) signatures: not yet." },
  { t: "T5 · Stretch", s: "Not started", d: "Editing existing text runs, OCR hooks." },
];

const platforms = [
  ["Windows x64", "Built", "Portable Folio.exe, GNU cross-build from this repo"],
  ["WebAssembly", "Built · live below", "Runs in your browser, nothing is uploaded"],
  ["Linux · macOS", "Same crate", "Not built in this environment"],
  ["Android · iOS", "Entry points only", "Written but never built – see STATUS.md"],
];

export default async function HomePage() {
  const [rows, wasm] = await Promise.all([syncArtifacts(), wasmSize()]);
  const win = rows.find((r) => r.slug === "windows-x64");
  return (
    <main>
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <span className="text-lg font-semibold tracking-tight">Folio</span>
        <nav className="flex gap-5 text-sm text-slate-600">
          <Link href="/viewer" className="hover:text-slate-900">Open in browser</Link>
          <Link href="/downloads" className="hover:text-slate-900">Downloads</Link>
          <a href="#status" className="hover:text-slate-900">Status</a>
        </nav>
      </header>

      <section className="mx-auto max-w-6xl px-6 pb-14 pt-10">
        <p className="text-sm font-medium uppercase tracking-[0.12em] text-[#2f5bd6]">Pure Rust · no C libraries</p>
        <h1 className="mt-3 max-w-3xl text-5xl font-semibold leading-[1.05] tracking-tight sm:text-6xl">A calm, fast PDF reader and editor.</h1>
        <p className="mt-5 max-w-2xl text-lg text-slate-600">
          Parsing, rendering, text search, editing, encryption and saving – all written in Rust, compiled once for the desktop and for the web.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="/viewer" className="rounded-xl bg-[#2f5bd6] px-6 py-3 font-medium text-white shadow-sm transition hover:bg-[#2548ad]">Open in your browser</Link>
          <a href="/api/download/windows-x64" className="rounded-xl border border-slate-300 bg-white px-6 py-3 font-medium transition hover:border-slate-400">
            Download for Windows{win ? ` · ${fmtBytes(win.sizeBytes)}` : ""}
          </a>
          <a href="/api/download/source" className="rounded-xl border border-slate-300 bg-white px-6 py-3 font-medium transition hover:border-slate-400">Source (zip)</a>
        </div>
        <dl className="mt-12 grid max-w-3xl grid-cols-2 gap-6 sm:grid-cols-4">
          {[
            ["WebAssembly", wasm ? `${fmtBytes(wasm.gz)} gz` : "–"],
            ["Wasm raw", wasm ? fmtBytes(wasm.raw) : "–"],
            ["Windows zip", win ? fmtBytes(win.sizeBytes) : "–"],
            ["Targets", "6 (2 built)"],
          ].map(([k, v]) => (
            <div key={k}>
              <dt className="text-xs uppercase tracking-wide text-slate-500">{k}</dt>
              <dd className="mt-1 text-2xl font-semibold">{v}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="border-y border-slate-200 bg-white">
        <div className="mx-auto grid max-w-6xl gap-px bg-slate-200 sm:grid-cols-2 lg:grid-cols-3">
          {tiers.map((x) => (
            <article key={x.t} className="bg-white p-6">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">{x.t}</h3>
                <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${x.s === "Done" ? "bg-emerald-100 text-emerald-800" : x.s === "Partial" ? "bg-amber-100 text-amber-900" : "bg-slate-100 text-slate-700"}`}>{x.s}</span>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-slate-600">{x.d}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="status" className="mx-auto max-w-6xl px-6 py-14">
        <h2 className="text-2xl font-semibold tracking-tight">Where it runs today</h2>
        <div className="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white">
          {platforms.map(([p, s, n]) => (
            <div key={p} className="grid grid-cols-[10rem_11rem_1fr] gap-4 border-b border-slate-100 px-5 py-3 text-sm last:border-0">
              <span className="font-medium">{p}</span>
              <span className="text-slate-700">{s}</span>
              <span className="text-slate-500">{n}</span>
            </div>
          ))}
        </div>
        <p className="mt-6 max-w-3xl text-sm text-slate-600">
          Known limits are documented rather than hidden: the web build runs the renderer on the UI thread (one tile per frame), CJK fallback fonts are not embedded, and
          digital signatures are not implemented. The full list lives in <code className="rounded bg-slate-100 px-1.5 py-0.5">STATUS.md</code> inside the source zip.
        </p>
      </section>
      <footer className="mx-auto max-w-6xl px-6 pb-10 text-sm text-slate-500">Folio · MIT OR Apache-2.0 · everything runs locally in your browser or on your machine.</footer>
    </main>
  );
}
