import Link from "next/link";
import { fmtBytes, syncArtifacts } from "@/lib/artifacts";

export const dynamic = "force-dynamic";
export const metadata = { title: "Folio – downloads" };

export default async function DownloadsPage() {
  const rows = await syncArtifacts();
  return (
    <main className="mx-auto max-w-4xl px-6 py-12">
      <Link href="/" className="text-sm text-slate-500 hover:text-slate-900">← Folio</Link>
      <h1 className="mt-4 text-4xl font-semibold tracking-tight">Downloads</h1>
      <p className="mt-2 text-slate-600">Checksums are computed from the files on this server.</p>
      <div className="mt-8 space-y-4">
        {rows.length === 0 && <p className="text-slate-600">No artifacts have been published yet.</p>}
        {rows.map((r) => (
          <article key={r.slug} className="rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <h2 className="text-lg font-semibold">{r.title}</h2>
                <p className="mt-1 max-w-xl text-sm text-slate-600">{r.description}</p>
                <p className="mt-3 break-all font-mono text-xs text-slate-500">sha256 {r.sha256}</p>
                <p className="mt-1 text-xs text-slate-500">{fmtBytes(r.sizeBytes)} · {r.platform} · {r.downloads} downloads</p>
              </div>
              <a href={`/api/download/${r.slug}`} className="rounded-xl bg-[#2f5bd6] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#2548ad]">Download</a>
            </div>
          </article>
        ))}
      </div>
      <section className="mt-12 rounded-2xl bg-slate-900 p-6 text-sm text-slate-200">
        <h2 className="font-semibold text-white">Build it yourself</h2>
        <pre className="mt-3 overflow-x-auto leading-relaxed">{`unzip Folio-source.zip && cd folio
cargo build -p folio-desktop --release            # Windows (msvc) / macOS / Linux
scripts/build-windows.sh                          # Windows .exe cross-built from Linux
scripts/build-web.sh ../public/wasm               # WebAssembly bundle for the website`}</pre>
      </section>
    </main>
  );
}
