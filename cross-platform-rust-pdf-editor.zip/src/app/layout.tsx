import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Folio – a pure-Rust PDF reader & editor",
  description: "Folio reads, annotates and organizes PDFs. One Rust codebase: Windows, WebAssembly (try it in your browser), and more.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#f7f7f9] text-slate-900 antialiased">{children}</body>
    </html>
  );
}
