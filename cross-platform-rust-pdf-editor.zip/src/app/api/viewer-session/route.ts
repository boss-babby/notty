import { count } from "drizzle-orm";
import { db } from "@/db";
import { viewerSessions } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  await db.insert(viewerSessions).values({ userAgent: (req.headers.get("user-agent") ?? "").slice(0, 300) });
  const [{ total }] = await db.select({ total: count() }).from(viewerSessions);
  return Response.json({ ok: true, total });
}
