import { createReadStream, existsSync } from "node:fs";
import { stat } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { artifacts } from "@/db/schema";
import { DOWNLOAD_DIR, syncArtifacts } from "@/lib/artifacts";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  await syncArtifacts();
  const [row] = await db.select().from(artifacts).where(eq(artifacts.slug, slug)).limit(1);
  if (!row) return new Response("Unknown artifact", { status: 404 });
  const file = path.join(DOWNLOAD_DIR, path.basename(row.fileName));
  if (!existsSync(file)) return new Response("File missing on server", { status: 404 });
  await db.update(artifacts).set({ downloads: sql`${artifacts.downloads} + 1` }).where(eq(artifacts.id, row.id));
  const st = await stat(file);
  const body = Readable.toWeb(createReadStream(file)) as ReadableStream;
  return new Response(body, {
    headers: {
      "Content-Type": "application/zip",
      "Content-Length": String(st.size),
      "Content-Disposition": `attachment; filename="${row.fileName}"`,
      "X-Content-SHA256": row.sha256,
      "Cache-Control": "no-store",
    },
  });
}
