"use client";

import { useEffect } from "react";

/** Hosts the wasm app (public/viewer-app/index.html → /wasm/folio.js) and records one session per visit. */
export function ViewerFrame() {
  useEffect(() => {
    void fetch("/api/viewer-session", { method: "POST" }).catch(() => undefined);
  }, []);
  return (
    <iframe
      title="Folio PDF viewer"
      src="/viewer-app/index.html"
      className="w-full flex-1 border-0 bg-[#e9eaee]"
      allow="clipboard-read; clipboard-write; fullscreen"
    />
  );
}
