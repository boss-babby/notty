import Link from "next/link";
import { existsSync } from "node:fs";
import path from "node:path";
import { wasmSize, fmtBytes } from "@/lib/artifacts";
import { ViewerFrame } from "./viewer-frame";

export const dynamic = "force-dynamic";
export const metadata = { title: "Folio – open a PDF in your browser" };

export default async function ViewerPage() {
  const present = existsSync(path.join(process.cwd(), "public", "wasm", "folio_bg.wasm"));
  const size = await wasmSize();
  return (
    <main className="flex h-screen flex-col">
      <header className="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-2.5 text-sm">
        <div className="flex items-center gap-4">
          <Link href="/" className="font-semibold">Folio</Link>
          <span className="text-slate-500">Runs entirely in your browser (WebAssembly{size ? ` · ${fmtBytes(size.gz)} gzipped` : ""}). Files never leave your device.</span>
        </div>
        <div className="flex gap-4 text-slate-600">
          <a href="/api/download/windows-x64" className="hover:text-slate-900">Windows app</a>
          <a href="/viewer-app/index.html" target="_blank" rel="noreferrer" className="hover:text-slate-900">Full window ↗</a>
        </div>
      </header>
      {present ? (
        <ViewerFrame />
      ) : (
        <div className="grid flex-1 place-items-center text-slate-600">The WebAssembly bundle has not been built yet (run scripts/build-web.sh).</div>
      )}
    </main>
  );
}
