use folio_core::sample::sample_pdf;
use folio_edit::*;
use folio_render::{Engine, Filter, Request, Response, TileKey};
use std::sync::Arc;

fn render0(bytes: Vec<u8>, page: u32) -> Vec<u8> {
    let mut e = Engine::new();
    e.push(Request::Open { epoch: 1, bytes: Arc::new(bytes), password: String::new() });
    while e.step().is_some() {}
    e.push(Request::Wanted(vec![TileKey { page, zoom_milli: 1000, col: 0, row: 0, filter: Filter::None, rev: 0 }]));
    match e.step() {
        Some(Response::Tile(t)) => t.rgba,
        _ => panic!("render failed"),
    }
}
fn yellowish(rgba: &[u8]) -> usize {
    rgba.chunks(4).filter(|p| p[0] > 230 && p[1] > 230 && p[2] < 80).count()
}

#[test]
fn annotations_render_and_undo() {
    let src = sample_pdf(2);
    assert_eq!(yellowish(&render0(src.clone(), 0)), 0);
    let mut s = Session::load(&src, "").unwrap();
    s.execute(AddAnnotation::new(0, AnnotSpec::Highlight { quads: vec![[72.0, 640.0, 300.0, 656.0]], color: [1.0, 1.0, 0.0] })).unwrap();
    s.execute(AddAnnotation::new(0, AnnotSpec::Ink { strokes: vec![vec![(100.0, 500.0), (200.0, 520.0), (300.0, 500.0)]], width: 3.0, color: [1.0, 0.0, 0.0] })).unwrap();
    s.execute(AddAnnotation::new(0, AnnotSpec::Note { pos: (400.0, 600.0), text: "hello (note)".into() })).unwrap();
    s.execute(AddAnnotation::new(0, AnnotSpec::Stamp { rect: [300.0, 400.0, 480.0, 450.0], label: "Approved".into(), color: [0.1, 0.6, 0.2] })).unwrap();
    s.execute(AddAnnotation::new(0, AnnotSpec::FreeText { rect: [72.0, 300.0, 300.0, 360.0], text: "A text box with several words to wrap".into(), size: 12.0, color: [0.0, 0.0, 0.0] })).unwrap();
    let bytes = s.to_bytes().unwrap();
    assert!(yellowish(&render0(bytes.clone(), 0)) > 500, "highlight not visible");
    // other readers' view: lopdf sees 5 annotations (+2 links) with subtypes
    let d = lopdf::Document::load_mem(&bytes).unwrap();
    let pid = *d.get_pages().get(&1).unwrap();
    assert_eq!(d.get_page_annotations(pid).unwrap().len(), 7);
    for _ in 0..5 {
        assert!(s.undo().unwrap().is_some());
    }
    assert!(!s.can_undo());
    assert_eq!(yellowish(&render0(s.to_bytes().unwrap(), 0)), 0);
    s.redo().unwrap();
    assert!(yellowish(&render0(s.to_bytes().unwrap(), 0)) > 500);
}

#[test]
fn page_commands_are_reversible() {
    let mut s = Session::load(&sample_pdf(4), "").unwrap();
    s.execute(RotatePage::new(1, 90)).unwrap();
    s.execute(MovePage::new(0, 3)).unwrap();
    s.execute(DeletePage::new(1)).unwrap();
    s.execute(InsertPage::blank(Some(0), (200.0, 300.0))).unwrap();
    assert_eq!(s.page_count(), 4);
    let b = s.to_bytes().unwrap();
    assert_eq!(validate(&b, Some(4)).unwrap(), 4);
    while s.undo().unwrap().is_some() {}
    assert_eq!(s.page_count(), 4);
    let ids = page_ids(&s.doc);
    // original order restored, rotation removed
    let d = &s.doc;
    assert!(d.get_dictionary(ids[1]).unwrap().get(b"Rotate").is_err());
    assert!(DeletePage::new(0).apply_check(&mut Session::load(&sample_pdf(1), "").unwrap()).is_err());
}

trait Check {
    fn apply_check(self: Box<Self>, s: &mut Session) -> Result<()>;
}
impl Check for DeletePage {
    fn apply_check(self: Box<Self>, s: &mut Session) -> Result<()> {
        s.execute(self)
    }
}

#[test]
fn merge_extract_split_ranges() {
    let a = sample_pdf(3);
    let b = sample_pdf(2);
    let m = merge(&[(a.clone(), String::new()), (b, String::new())]).unwrap();
    assert_eq!(validate(&m, None).unwrap(), 5);
    let e = extract_pages(&m, "", &[0, 4]).unwrap();
    assert_eq!(validate(&e, None).unwrap(), 2);
    let parts = split_every(&m, "", 2).unwrap();
    assert_eq!(parts.len(), 3);
    assert_eq!(parse_ranges("1-2, 5", 5).unwrap(), vec![0, 1, 4]);
    assert_eq!(parse_ranges("4-", 5).unwrap(), vec![3, 4]);
    assert!(parse_ranges("0", 5).is_err() && parse_ranges("3-9", 5).is_err() && parse_ranges("x", 5).is_err());
    // merged page text still renders
    assert!(render0(m, 4).iter().filter(|b| **b < 60).count() > 100);
}

#[test]
fn protect_and_unlock() {
    let src = sample_pdf(2);
    let enc = protect(&src, "", "secret", "owner").unwrap();
    assert!(matches!(folio_core::open(Arc::new(enc.clone()), ""), Err(folio_core::OpenError::NeedPassword)));
    assert!(matches!(folio_core::open(Arc::new(enc.clone()), "nope"), Err(folio_core::OpenError::WrongPassword)));
    assert_eq!(folio_core::open(Arc::new(enc.clone()), "secret").unwrap().pages().len(), 2);
    // render of encrypted doc works through hayro
    let mut e = Engine::new();
    e.push(Request::Open { epoch: 1, bytes: Arc::new(enc.clone()), password: "secret".into() });
    assert!(matches!(e.step(), Some(Response::Opened { result: Ok(_), .. })));
    let plain = unlock(&enc, "secret").unwrap();
    assert_eq!(validate(&plain, Some(2)).unwrap(), 2);
    assert!(folio_core::open(Arc::new(plain), "").is_ok());
}

#[test]
fn incremental_save_keeps_original_bytes() {
    // lopdf writes classic xref tables with `save_to` in 1.5? ensure we use a classic-xref original
    let src = sample_pdf(2);
    let mut s = Session::load(&src, "").unwrap();
    s.execute(AddAnnotation::new(1, AnnotSpec::Square { rect: [50.0, 50.0, 150.0, 120.0], color: [0.0, 0.0, 1.0], width: 2.0 })).unwrap();
    let r = folio_edit::save_incremental(&src, &lopdf::Document::load_mem(&src).unwrap(), &s.doc);
    if let Err(e) = &r { eprintln!("INCR ERR: {e}"); }
    if let Ok(b) = &r { eprintln!("INCR validate: {:?}", validate(b, Some(2))); }
    let (out, incremental) = s.to_bytes_incremental_or_full().unwrap();
    assert!(incremental, "expected an incremental update");
    assert_eq!(&out[..src.len()], &src[..], "original bytes must be untouched");
    assert_eq!(validate(&out, Some(2)).unwrap(), 2);
    let d = lopdf::Document::load_mem(&out).unwrap();
    let pid = *d.get_pages().get(&2).unwrap();
    assert_eq!(d.get_page_annotations(pid).unwrap().len(), 1);
}

#[test]
fn compress_never_grows_and_flatten_works() {
    let src = sample_pdf(6);
    let (out, st) = compress(&src, "").unwrap();
    assert!(out.len() <= src.len() && st.after <= st.before);
    assert_eq!(validate(&out, Some(6)).unwrap(), 6);

    let mut s = Session::load(&src, "").unwrap();
    s.execute(AddAnnotation::new(0, AnnotSpec::Highlight { quads: vec![[72.0, 640.0, 300.0, 656.0]], color: [1.0, 1.0, 0.0] })).unwrap();
    s.execute(Snapshot::new("Flatten annotations", |d| forms::flatten_annotations(d, false).map(|_| ()))).unwrap();
    let b = s.to_bytes().unwrap();
    let d = lopdf::Document::load_mem(&b).unwrap();
    let pid = *d.get_pages().get(&1).unwrap();
    let remaining = d.get_page_annotations(pid).unwrap().iter().filter(|a| matches!(a.get(b"Subtype"), Ok(lopdf::Object::Name(n)) if n == b"Highlight")).count();
    assert_eq!(remaining, 0);
    assert!(yellowish(&render0(b, 0)) > 500, "flattened highlight must still be painted");
    s.undo().unwrap();
}

#[test]
fn metadata_image_and_redaction_by_rasterising() {
    let mut s = Session::load(&sample_pdf(1), "").unwrap();
    s.execute(SetMetadata::new("Title", "Ünïcode título")).unwrap();
    let b = s.to_bytes().unwrap();
    let pdf = folio_core::open(Arc::new(b), "").unwrap();
    assert_eq!(folio_core::read_meta(&pdf).title.as_deref(), Some("Ünïcode título"));

    // 2x2 PNG → image page + stamp annotation
    let mut png = Vec::new();
    {
        use image::ImageEncoder;
        image::codecs::png::PngEncoder::new(&mut png).write_image(&[255, 0, 0, 255, 0, 255, 0, 128, 0, 0, 255, 255, 9, 9, 9, 255], 2, 2, image::ExtendedColorType::Rgba8).unwrap();
    }
    s.execute(InsertPage::image(Some(0), png.clone())).unwrap();
    s.execute(AddAnnotation::new(0, AnnotSpec::Image { rect: [10.0, 10.0, 60.0, 60.0], bytes: png })).unwrap();
    assert_eq!(validate(&s.to_bytes().unwrap(), Some(2)).unwrap(), 2);

    // Redaction: render page 0 to PNG through the engine and rasterise → no text remains.
    let bytes = s.to_bytes().unwrap();
    let mut e = Engine::new();
    e.push(Request::Open { epoch: 1, bytes: Arc::new(bytes), password: String::new() });
    while e.step().is_some() {}
    let mut s2 = Session::load(&sample_pdf(1), "").unwrap();
    e.push(Request::Text(vec![0]));
    let Some(Response::Text { text, .. }) = e.step() else { panic!() };
    let _ = text;
    let mut e2 = Engine::new();
    e2.push(Request::Open { epoch: 1, bytes: Arc::new(s2.to_bytes().unwrap()), password: String::new() });
    while e2.step().is_some() {}
    e2.push(Request::Png { page: 0, zoom_milli: 1500, filter: Filter::None });
    let Some(Response::Png { result: Ok(png), .. }) = e2.step() else { panic!("png") };
    s2.execute(Snapshot::new("Apply redactions", move |d| rasterize_pages(d, &[(0, png.clone(), 612.0, 792.0)]))).unwrap();
    let out = s2.to_bytes().unwrap();
    let d = lopdf::Document::load_mem(&out).unwrap();
    let pid = *d.get_pages().get(&1).unwrap();
    let content = String::from_utf8_lossy(&d.get_page_content(pid)).to_string();
    assert!(!content.contains("needle") && !content.contains("Tj"), "text must be gone");
    assert!(d.extract_text(&[1]).unwrap_or_default().trim().is_empty());
}

#[test]
fn savers_never_emit_garbage_on_atomic_write() {
    let dir = std::env::temp_dir().join(format!("folio-test-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let p = dir.join("a.pdf");
    write_atomic(&p, &sample_pdf(1)).unwrap();
    assert!(validate(&std::fs::read(&p).unwrap(), Some(1)).is_ok());
    assert!(!p.with_extension("folio-tmp").exists());
    let _ = std::fs::remove_dir_all(dir);
}
