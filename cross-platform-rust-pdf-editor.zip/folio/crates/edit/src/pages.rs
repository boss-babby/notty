use crate::{EditError, Result};
use lopdf::{Dictionary, Document, Object, ObjectId};

pub fn root_pages_id(doc: &Document) -> Result<ObjectId> {
    let cat = doc.catalog()?;
    cat.get(b"Pages")?.as_reference().map_err(|_| EditError("catalog has no /Pages".into()))
}

/// Page object ids in document order.
pub fn page_ids(doc: &Document) -> Vec<ObjectId> {
    doc.get_pages().into_values().collect()
}

fn inherited(doc: &Document, mut id: ObjectId, key: &[u8]) -> Option<Object> {
    for _ in 0..64 {
        let d = doc.get_dictionary(id).ok()?;
        if let Ok(v) = d.get(key) {
            return Some(v.clone());
        }
        id = d.get(b"Parent").ok()?.as_reference().ok()?;
    }
    None
}

pub(crate) fn set_kids(doc: &mut Document, ids: &[ObjectId]) -> Result<()> {
    let root = root_pages_id(doc)?;
    let d = doc.get_dictionary_mut(root)?;
    d.set("Kids", Object::Array(ids.iter().map(|i| Object::Reference(*i)).collect()));
    d.set("Count", ids.len() as i64);
    for id in ids {
        if let Ok(p) = doc.get_dictionary_mut(*id) {
            p.set("Parent", root);
        }
    }
    Ok(())
}

/// Turn the page tree into a single level: copy inherited attributes onto each page and make the
/// root /Pages node the direct parent of every page. Makes reorder/delete/insert trivial and safe.
pub fn flatten_pages(doc: &mut Document) -> Result<()> {
    let ids = page_ids(doc);
    if ids.is_empty() {
        return Err("document has no pages".into());
    }
    let root = root_pages_id(doc)?;
    let already_flat = {
        let r = doc.get_dictionary(root)?;
        matches!(r.get(b"Kids"), Ok(Object::Array(k)) if k.len() == ids.len())
            && ids.iter().all(|i| doc.get_dictionary(*i).ok().and_then(|d| d.get(b"Parent").ok()).and_then(|p| p.as_reference().ok()) == Some(root))
    };
    if already_flat {
        return Ok(());
    }
    for id in &ids {
        let mut add: Vec<(&[u8], Object)> = Vec::new();
        for key in [&b"MediaBox"[..], b"CropBox", b"Resources", b"Rotate"] {
            let has = doc.get_dictionary(*id).map(|d| d.has(key)).unwrap_or(true);
            if !has {
                if let Some(v) = inherited(doc, *id, key) {
                    add.push((key, v));
                }
            }
        }
        let d: &mut Dictionary = doc.get_dictionary_mut(*id)?;
        for (k, v) in add {
            d.set(k.to_vec(), v);
        }
    }
    set_kids(doc, &ids)
}
