//! Standards-compliant annotations with explicit appearance streams (/AP), so that every viewer
//! – including hayro, which only paints annotations that have an appearance – displays them.
use lopdf::{Dictionary, Document, Object, ObjectId, Stream, StringFormat, dictionary};

pub type Rect = [f32; 4];
pub type Rgb = [f32; 3];

#[derive(Debug, Clone, PartialEq)]
pub enum AnnotSpec {
    Highlight { quads: Vec<Rect>, color: Rgb },
    Underline { quads: Vec<Rect>, color: Rgb },
    StrikeOut { quads: Vec<Rect>, color: Rgb },
    /// Each stroke: points in PDF space. `width` in points.
    Ink { strokes: Vec<Vec<(f32, f32)>>, width: f32, color: Rgb },
    Note { pos: (f32, f32), text: String },
    Square { rect: Rect, color: Rgb, width: f32 },
    Circle { rect: Rect, color: Rgb, width: f32 },
    Stamp { rect: Rect, label: String, color: Rgb },
    FreeText { rect: Rect, text: String, size: f32, color: Rgb },
    /// Black box used by redaction before pages are rasterised.
    Redact { rect: Rect },
    /// Raster image (PNG/JPEG bytes) placed as a stamp – used for image signatures and pictures.
    Image { rect: Rect, bytes: Vec<u8> },
}

fn f(v: f32) -> String {
    let s = format!("{v:.3}");
    let s = s.trim_end_matches('0').trim_end_matches('.');
    if s.is_empty() || s == "-" { "0".into() } else { s.to_owned() }
}

fn rgb(c: Rgb) -> String {
    format!("{} {} {}", f(c[0]), f(c[1]), f(c[2]))
}

fn rect_arr(r: Rect) -> Object {
    Object::Array(r.iter().map(|v| Object::Real(*v)).collect())
}

fn color_arr(c: Rgb) -> Object {
    Object::Array(c.iter().map(|v| Object::Real(*v)).collect())
}

/// PDF literal string body for WinAnsi/Latin-1; other chars become '?'.
fn esc(text: &str) -> Vec<u8> {
    let mut out = Vec::new();
    for ch in text.chars() {
        let b = if (ch as u32) < 256 { ch as u32 as u8 } else { b'?' };
        match b {
            b'(' | b')' | b'\\' => {
                out.push(b'\\');
                out.push(b);
            }
            b'\r' | b'\n' => out.push(b' '),
            _ => out.push(b),
        }
    }
    out
}

fn bbox_of(quads: &[Rect]) -> Rect {
    let mut r = quads.first().copied().unwrap_or([0.0; 4]);
    for q in quads {
        r = [r[0].min(q[0]), r[1].min(q[1]), r[2].max(q[2]), r[3].max(q[3])];
    }
    r
}

fn quadpoints(quads: &[Rect]) -> Object {
    let mut v = Vec::new();
    for q in quads {
        // Order used by Acrobat and everyone else: TL, TR, BL, BR.
        for p in [q[0], q[3], q[2], q[3], q[0], q[1], q[2], q[1]] {
            v.push(Object::Real(p));
        }
    }
    Object::Array(v)
}

fn form(bbox: Rect, resources: Dictionary, content: Vec<u8>) -> Stream {
    let mut d = dictionary! {
        "Type" => "XObject", "Subtype" => "Form",
        "BBox" => rect_arr(bbox),
        "Resources" => Object::Dictionary(resources),
    };
    d.set("FormType", 1);
    Stream::new(d, content)
}

fn gs_resources(multiply: bool) -> Dictionary {
    let mut g = dictionary! {"Type" => "ExtGState", "AIS" => false};
    if multiply {
        g.set("BM", "Multiply");
    }
    dictionary! {"ExtGState" => dictionary!{"GS" => Object::Dictionary(g)}}
}

fn helv_bold() -> Object {
    Object::Dictionary(dictionary! {"Type"=>"Font","Subtype"=>"Type1","BaseFont"=>"Helvetica-Bold","Encoding"=>"WinAnsiEncoding"})
}
fn helv() -> Object {
    Object::Dictionary(dictionary! {"Type"=>"Font","Subtype"=>"Type1","BaseFont"=>"Helvetica","Encoding"=>"WinAnsiEncoding"})
}

fn ellipse_path(r: Rect) -> String {
    let (cx, cy, rx, ry) = ((r[0] + r[2]) / 2.0, (r[1] + r[3]) / 2.0, (r[2] - r[0]) / 2.0, (r[3] - r[1]) / 2.0);
    let k = 0.552_284_75;
    format!(
        "{} {} m {} {} {} {} {} {} c {} {} {} {} {} {} c {} {} {} {} {} {} c {} {} {} {} {} {} c h",
        f(cx + rx), f(cy),
        f(cx + rx), f(cy + k * ry), f(cx + k * rx), f(cy + ry), f(cx), f(cy + ry),
        f(cx - k * rx), f(cy + ry), f(cx - rx), f(cy + k * ry), f(cx - rx), f(cy),
        f(cx - rx), f(cy - k * ry), f(cx - k * rx), f(cy - ry), f(cx), f(cy - ry),
        f(cx + k * rx), f(cy - ry), f(cx + rx), f(cy - k * ry), f(cx + rx), f(cy),
    )
}

/// Create an image XObject (+ SMask for alpha) from PNG/JPEG bytes. Returns (id, width_px, height_px).
pub fn add_image(doc: &mut Document, bytes: &[u8]) -> Result<(ObjectId, u32, u32), String> {
    let img = image::load_from_memory(bytes).map_err(|e| format!("cannot decode image: {e}"))?;
    let (w, h) = (img.width(), img.height());
    if w == 0 || h == 0 || (w as u64) * (h as u64) > 64_000_000 {
        return Err("image dimensions are not supported".into());
    }
    let rgba = img.to_rgba8();
    let mut rgb = Vec::with_capacity((w * h * 3) as usize);
    let mut alpha = Vec::with_capacity((w * h) as usize);
    let mut has_alpha = false;
    for p in rgba.pixels() {
        rgb.extend_from_slice(&p.0[..3]);
        alpha.push(p.0[3]);
        has_alpha |= p.0[3] != 255;
    }
    let mut dict = dictionary! {
        "Type"=>"XObject","Subtype"=>"Image","Width"=>w as i64,"Height"=>h as i64,
        "ColorSpace"=>"DeviceRGB","BitsPerComponent"=>8,
    };
    if has_alpha {
        let mut sm = Stream::new(
            dictionary! {"Type"=>"XObject","Subtype"=>"Image","Width"=>w as i64,"Height"=>h as i64,"ColorSpace"=>"DeviceGray","BitsPerComponent"=>8},
            alpha,
        );
        let _ = sm.compress();
        let sid = doc.add_object(sm);
        dict.set("SMask", sid);
    }
    let mut st = Stream::new(dict, rgb);
    let _ = st.compress();
    Ok((doc.add_object(st), w, h))
}

impl AnnotSpec {
    pub fn kind(&self) -> &'static str {
        match self {
            Self::Highlight { .. } => "Highlight",
            Self::Underline { .. } => "Underline",
            Self::StrikeOut { .. } => "Strikeout",
            Self::Ink { .. } => "Ink",
            Self::Note { .. } => "Note",
            Self::Square { .. } => "Rectangle",
            Self::Circle { .. } => "Ellipse",
            Self::Stamp { .. } => "Stamp",
            Self::FreeText { .. } => "Text box",
            Self::Redact { .. } => "Redaction",
            Self::Image { .. } => "Image",
        }
    }

    /// Build the annotation dictionary (with /AP). Extra objects (images) are added to `doc`.
    pub fn build(&self, doc: &mut Document) -> Result<Dictionary, String> {
        let mut a = dictionary! {"Type"=>"Annot","F"=>4,"T"=>Object::String(b"Folio".to_vec(), StringFormat::Literal)};
        let ap: Stream;
        match self {
            Self::Highlight { quads, color } | Self::Underline { quads, color } | Self::StrikeOut { quads, color } => {
                if quads.is_empty() {
                    return Err("nothing selected".into());
                }
                let bb = bbox_of(quads);
                let mut c = String::from("/GS gs\n");
                let sub = match self {
                    Self::Highlight { .. } => {
                        c += &format!("{} rg\n", rgb(*color));
                        for q in quads {
                            c += &format!("{} {} {} {} re f\n", f(q[0]), f(q[1]), f(q[2] - q[0]), f(q[3] - q[1]));
                        }
                        "Highlight"
                    }
                    other => {
                        c += &format!("{} RG 1 w\n", rgb(*color));
                        let under = matches!(other, Self::Underline { .. });
                        for q in quads {
                            let y = if under { q[1] + (q[3] - q[1]) * 0.12 } else { (q[1] + q[3]) / 2.0 };
                            c += &format!("{} {} m {} {} l S\n", f(q[0]), f(y), f(q[2]), f(y));
                        }
                        if under { "Underline" } else { "StrikeOut" }
                    }
                };
                a.set("Subtype", sub);
                a.set("Rect", rect_arr(bb));
                a.set("QuadPoints", quadpoints(quads));
                a.set("C", color_arr(*color));
                ap = form(bb, gs_resources(sub == "Highlight"), c.into_bytes());
            }
            Self::Ink { strokes, width, color } => {
                let pts: Vec<&(f32, f32)> = strokes.iter().flatten().collect();
                if pts.is_empty() {
                    return Err("empty stroke".into());
                }
                let pad = width.max(1.0);
                let bb = [
                    pts.iter().map(|p| p.0).fold(f32::MAX, f32::min) - pad,
                    pts.iter().map(|p| p.1).fold(f32::MAX, f32::min) - pad,
                    pts.iter().map(|p| p.0).fold(f32::MIN, f32::max) + pad,
                    pts.iter().map(|p| p.1).fold(f32::MIN, f32::max) + pad,
                ];
                let mut c = format!("{} RG {} w 1 J 1 j\n", rgb(*color), f(*width));
                let mut list = Vec::new();
                for s in strokes.iter().filter(|s| !s.is_empty()) {
                    c += &format!("{} {} m ", f(s[0].0), f(s[0].1));
                    for p in &s[1..] {
                        c += &format!("{} {} l ", f(p.0), f(p.1));
                    }
                    if s.len() == 1 {
                        c += &format!("{} {} l ", f(s[0].0 + 0.01), f(s[0].1));
                    }
                    c += "S\n";
                    list.push(Object::Array(s.iter().flat_map(|p| [Object::Real(p.0), Object::Real(p.1)]).collect()));
                }
                a.set("Subtype", "Ink");
                a.set("Rect", rect_arr(bb));
                a.set("InkList", Object::Array(list));
                a.set("C", color_arr(*color));
                a.set("BS", Object::Dictionary(dictionary! {"W"=>Object::Real(*width)}));
                ap = form(bb, Dictionary::new(), c.into_bytes());
            }
            Self::Note { pos, text } => {
                let r = [pos.0, pos.1 - 20.0, pos.0 + 20.0, pos.1];
                let c = format!(
                    "1 0.85 0.2 rg {} {} 20 20 re f 0.4 0.3 0 RG 1 w {} {} 19 19 re S 0.4 0.3 0 RG {} {} m {} {} l S {} {} m {} {} l S {} {} m {} {} l S",
                    f(r[0]), f(r[1]), f(r[0] + 0.5), f(r[1] + 0.5),
                    f(r[0] + 4.0), f(r[1] + 14.0), f(r[0] + 16.0), f(r[1] + 14.0),
                    f(r[0] + 4.0), f(r[1] + 10.0), f(r[0] + 16.0), f(r[1] + 10.0),
                    f(r[0] + 4.0), f(r[1] + 6.0), f(r[0] + 11.0), f(r[1] + 6.0),
                );
                a.set("Subtype", "Text");
                a.set("Rect", rect_arr(r));
                a.set("Name", "Note");
                a.set("Contents", Object::String(esc(text), StringFormat::Literal));
                a.set("C", color_arr([1.0, 0.85, 0.2]));
                a.set("Open", false);
                a.set("F", 28); // print + no-zoom + no-rotate
                ap = form(r, Dictionary::new(), c.into_bytes());
            }
            Self::Square { rect, color, width } | Self::Circle { rect, color, width } => {
                let r = *rect;
                let inset = width / 2.0;
                let ir = [r[0] + inset, r[1] + inset, r[2] - inset, r[3] - inset];
                let path = if matches!(self, Self::Square { .. }) {
                    format!("{} {} {} {} re", f(ir[0]), f(ir[1]), f(ir[2] - ir[0]), f(ir[3] - ir[1]))
                } else {
                    ellipse_path(ir)
                };
                let c = format!("{} RG {} w {} S", rgb(*color), f(*width), path);
                a.set("Subtype", if matches!(self, Self::Square { .. }) { "Square" } else { "Circle" });
                a.set("Rect", rect_arr(r));
                a.set("C", color_arr(*color));
                a.set("BS", Object::Dictionary(dictionary! {"W"=>Object::Real(*width),"S"=>"S"}));
                ap = form(r, Dictionary::new(), c.into_bytes());
            }
            Self::Stamp { rect, label, color } => {
                let r = *rect;
                let (w, h) = (r[2] - r[0], r[3] - r[1]);
                let size = (h * 0.5).min(w / (label.chars().count().max(1) as f32 * 0.62)).max(4.0);
                let tw = label.chars().count() as f32 * size * 0.62;
                let mut c = format!("{} RG {} rg 2 w {} {} {} {} re S\n", rgb(*color), rgb(*color), f(r[0] + 1.0), f(r[1] + 1.0), f(w - 2.0), f(h - 2.0));
                c += "BT /F1 ";
                c += &format!("{} Tf {} {} Td (", f(size), f(r[0] + (w - tw) / 2.0), f(r[1] + (h - size * 0.72) / 2.0));
                let mut bytes = c.into_bytes();
                bytes.extend(esc(&label.to_uppercase()));
                bytes.extend(b") Tj ET");
                a.set("Subtype", "Stamp");
                a.set("Rect", rect_arr(r));
                a.set("Name", Object::Name(label.replace(' ', "").into_bytes()));
                a.set("Contents", Object::String(esc(label), StringFormat::Literal));
                ap = form(r, dictionary! {"Font"=>dictionary!{"F1"=>helv_bold()}}, bytes);
            }
            Self::FreeText { rect, text, size, color } => {
                let r = *rect;
                let mut bytes = format!("{} rg BT /F1 {} Tf {} TL {} {} Td\n", rgb(*color), f(*size), f(size * 1.2), f(r[0] + 2.0), f(r[3] - size - 2.0)).into_bytes();
                let max_chars = (((r[2] - r[0]) - 4.0) / (size * 0.5)).max(1.0) as usize;
                for raw_line in text.lines() {
                    // naive word wrap
                    let mut line = String::new();
                    for word in raw_line.split_whitespace() {
                        if !line.is_empty() && line.chars().count() + 1 + word.chars().count() > max_chars {
                            bytes.push(b'(');
                            bytes.extend(esc(&line));
                            bytes.extend(b") Tj T*\n");
                            line.clear();
                        }
                        if !line.is_empty() {
                            line.push(' ');
                        }
                        line.push_str(word);
                    }
                    bytes.push(b'(');
                    bytes.extend(esc(&line));
                    bytes.extend(b") Tj T*\n");
                }
                bytes.extend(b"ET");
                a.set("Subtype", "FreeText");
                a.set("Rect", rect_arr(r));
                a.set("Contents", Object::String(esc(text), StringFormat::Literal));
                a.set("DA", Object::String(format!("/Helv {} Tf {} rg", f(*size), rgb(*color)).into_bytes(), StringFormat::Literal));
                ap = form(r, dictionary! {"Font"=>dictionary!{"F1"=>helv()}}, bytes);
            }
            Self::Redact { rect } => {
                let r = *rect;
                let c = format!("0 g {} {} {} {} re f", f(r[0]), f(r[1]), f(r[2] - r[0]), f(r[3] - r[1]));
                a.set("Subtype", "Redact");
                a.set("Rect", rect_arr(r));
                a.set("QuadPoints", quadpoints(&[r]));
                a.set("IC", color_arr([0.0, 0.0, 0.0]));
                ap = form(r, Dictionary::new(), c.into_bytes());
            }
            Self::Image { rect, bytes } => {
                let r = *rect;
                let (img, _, _) = add_image(doc, bytes)?;
                let c = format!("q {} 0 0 {} {} {} cm /Im0 Do Q", f(r[2] - r[0]), f(r[3] - r[1]), f(r[0]), f(r[1]));
                a.set("Subtype", "Stamp");
                a.set("Rect", rect_arr(r));
                a.set("Name", "Image");
                ap = form(r, dictionary! {"XObject"=>dictionary!{"Im0"=>img}}, c.into_bytes());
            }
        }
        let ap_id = doc.add_object(ap);
        a.set("AP", Object::Dictionary(dictionary! {"N" => ap_id}));
        Ok(a)
    }
}
