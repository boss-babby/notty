//! AcroForm helpers: list/fill text fields, build simple appearances, flatten annotations.
use crate::{EditError, Result};
use lopdf::{Dictionary, Document, Object, ObjectId, Stream, StringFormat, dictionary};

#[derive(Debug, Clone, PartialEq)]
pub enum FieldKind {
    Text,
    Checkbox,
    Choice,
    Button,
    Other,
}

#[derive(Debug, Clone)]
pub struct Field {
    pub name: String,
    pub id: ObjectId,
    pub kind: FieldKind,
    pub value: String,
}

fn text_of(o: Option<&Object>) -> String {
    match o {
        Some(Object::String(s, _)) => folio_core::decode_pdf_text(s),
        Some(Object::Name(n)) => String::from_utf8_lossy(n).into_owned(),
        _ => String::new(),
    }
}

pub fn list_fields(doc: &Document) -> Vec<Field> {
    let mut out = Vec::new();
    let Ok(cat) = doc.catalog() else { return out };
    let Some(form) = cat.get(b"AcroForm").ok().and_then(|o| deref_dict(doc, o)) else { return out };
    let Ok(Object::Array(fields)) = form.get(b"Fields").map(|o| deref(doc, o)) else { return out };
    for f in fields {
        walk(doc, f, "", None, &mut out, 0);
    }
    out
}

fn deref<'a>(doc: &'a Document, o: &'a Object) -> &'a Object {
    match o {
        Object::Reference(r) => doc.get_object(*r).unwrap_or(&Object::Null),
        o => o,
    }
}
fn deref_dict<'a>(doc: &'a Document, o: &'a Object) -> Option<&'a Dictionary> {
    match deref(doc, o) {
        Object::Dictionary(d) => Some(d),
        _ => None,
    }
}

fn walk(doc: &Document, node: &Object, prefix: &str, ft: Option<Vec<u8>>, out: &mut Vec<Field>, depth: u32) {
    if depth > 16 {
        return;
    }
    let (Object::Reference(id), Some(d)) = (node, deref_dict(doc, node)) else { return };
    let t = text_of(d.get(b"T").ok());
    let name = match (prefix.is_empty(), t.is_empty()) {
        (true, _) => t.clone(),
        (false, true) => prefix.to_owned(),
        (false, false) => format!("{prefix}.{t}"),
    };
    let ft = match d.get(b"FT") {
        Ok(Object::Name(n)) => Some(n.clone()),
        _ => ft,
    };
    if let Ok(Object::Array(kids)) = d.get(b"Kids").map(|o| deref(doc, o)) {
        let has_field_kids = kids.iter().any(|k| deref_dict(doc, k).is_some_and(|kd| kd.has(b"T")));
        if has_field_kids {
            for k in kids {
                walk(doc, k, &name, ft.clone(), out, depth + 1);
            }
            return;
        }
    }
    if name.is_empty() {
        return;
    }
    let flags = match d.get(b"Ff") {
        Ok(Object::Integer(i)) => *i,
        _ => 0,
    };
    let kind = match ft.as_deref() {
        Some(b"Tx") => FieldKind::Text,
        Some(b"Btn") if flags & (1 << 16) != 0 => FieldKind::Button,
        Some(b"Btn") => FieldKind::Checkbox,
        Some(b"Ch") => FieldKind::Choice,
        _ => FieldKind::Other,
    };
    out.push(Field { name, id: *id, kind, value: text_of(d.get(b"V").ok()) });
}

pub fn set_need_appearances(doc: &mut Document) {
    let form = doc.catalog().ok().and_then(|c| c.get(b"AcroForm").ok().cloned());
    match form {
        Some(Object::Reference(r)) => {
            if let Ok(d) = doc.get_dictionary_mut(r) {
                d.set("NeedAppearances", true);
            }
        }
        Some(Object::Dictionary(_)) => {
            if let Some(Object::Dictionary(d)) = doc.catalog_mut().ok().and_then(|c| c.get_mut(b"AcroForm").ok()) {
                d.set("NeedAppearances", true);
            }
        }
        _ => {}
    }
}

/// Give every widget of a text field a simple appearance so viewers (and flatten) show the value.
pub fn build_text_appearance(doc: &mut Document, field: ObjectId, value: &str) -> Result<()> {
    let mut widgets = vec![field];
    if let Ok(d) = doc.get_dictionary(field) {
        if let Ok(Object::Array(k)) = d.get(b"Kids") {
            widgets = k.iter().filter_map(|o| o.as_reference().ok()).collect();
        }
    }
    for w in widgets {
        let rect = match doc.get_dictionary(w).ok().and_then(|d| d.get(b"Rect").ok()).cloned() {
            Some(Object::Array(r)) if r.len() == 4 => {
                let v: Vec<f32> = r.iter().map(|o| match o { Object::Integer(i) => *i as f32, Object::Real(f) => *f, _ => 0.0 }).collect();
                [v[0].min(v[2]), v[1].min(v[3]), v[0].max(v[2]), v[1].max(v[3])]
            }
            _ => continue,
        };
        let (bw, bh) = (rect[2] - rect[0], rect[3] - rect[1]);
        let size = (bh - 4.0).clamp(6.0, 12.0);
        let mut c = format!("/Tx BMC q 1 1 {} {} re W n BT /Helv {size:.2} Tf 0 g 2 {} Td (", bw - 2.0, bh - 2.0, (bh - size) / 2.0 + size * 0.2).into_bytes();
        for ch in value.chars() {
            let b = if (ch as u32) < 256 { ch as u32 as u8 } else { b'?' };
            if matches!(b, b'(' | b')' | b'\\') {
                c.push(b'\\');
            }
            c.push(if b == b'\n' || b == b'\r' { b' ' } else { b });
        }
        c.extend(b") Tj ET Q EMC");
        let st = Stream::new(
            dictionary! {"Type"=>"XObject","Subtype"=>"Form","BBox"=>vec![0.into(),0.into(),Object::Real(bw),Object::Real(bh)],
                "Resources"=>dictionary!{"Font"=>dictionary!{"Helv"=>dictionary!{"Type"=>"Font","Subtype"=>"Type1","BaseFont"=>"Helvetica","Encoding"=>"WinAnsiEncoding"}}}},
            c,
        );
        let sid = doc.add_object(st);
        let d = doc.get_dictionary_mut(w)?;
        d.set("AP", Object::Dictionary(dictionary! {"N"=>sid}));
        if field != w {
            d.set("V", Object::String(value.as_bytes().to_vec(), StringFormat::Literal));
        }
    }
    Ok(())
}

/// Burn every annotation that has a normal appearance stream into the page content and remove it.
/// Used for "flatten forms" and "flatten annotations". Links and popups are left alone.
pub fn flatten_annotations(doc: &mut Document, only_widgets: bool) -> Result<usize> {
    let pages = crate::page_ids(doc);
    let mut flattened = 0;
    for pid in pages {
        let annots: Vec<Object> = match doc.get_dictionary(pid).ok().and_then(|d| d.get(b"Annots").ok()).cloned() {
            Some(Object::Array(a)) => a,
            Some(Object::Reference(r)) => match doc.get_object(r) {
                Ok(Object::Array(a)) => a.clone(),
                _ => continue,
            },
            _ => continue,
        };
        let mut keep = Vec::new();
        let mut ops = String::new();
        let mut xobjs: Vec<(String, ObjectId)> = Vec::new();
        for a in annots {
            let Object::Reference(aid) = a else { keep.push(a); continue };
            let Ok(ad) = doc.get_dictionary(aid) else { keep.push(a); continue };
            let sub = match ad.get(b"Subtype") { Ok(Object::Name(n)) => n.clone(), _ => Vec::new() };
            let is_widget = sub == b"Widget";
            if sub == b"Link" || sub == b"Popup" || (only_widgets && !is_widget) {
                keep.push(a);
                continue;
            }
            let rect = match ad.get(b"Rect") {
                Ok(Object::Array(r)) if r.len() == 4 => r.iter().map(|o| match o { Object::Integer(i) => *i as f32, Object::Real(f) => *f, _ => 0.0 }).collect::<Vec<_>>(),
                _ => { keep.push(a); continue }
            };
            let n = ad.get(b"AP").ok().and_then(|o| deref_dict(doc, o)).and_then(|ap| ap.get(b"N").ok());
            let form_id = match n {
                Some(Object::Reference(r)) => match doc.get_object(*r) {
                    Ok(Object::Stream(_)) => Some(*r),
                    Ok(Object::Dictionary(states)) => {
                        let st = ad.get(b"AS").ok().and_then(|o| o.as_name().ok()).map(|n| n.to_vec());
                        st.and_then(|s| states.get(&s).ok()).and_then(|o| o.as_reference().ok())
                    }
                    _ => None,
                },
                _ => None,
            };
            let Some(fid) = form_id else { keep.push(a); continue };
            let bbox = match doc.get_object(fid).ok().and_then(|o| o.as_stream().ok()).and_then(|s| s.dict.get(b"BBox").ok()) {
                Some(Object::Array(b)) if b.len() == 4 => b.iter().map(|o| match o { Object::Integer(i) => *i as f32, Object::Real(f) => *f, _ => 0.0 }).collect::<Vec<_>>(),
                _ => vec![rect[0], rect[1], rect[2], rect[3]],
            };
            let (bw, bh) = ((bbox[2] - bbox[0]).abs().max(0.001), (bbox[3] - bbox[1]).abs().max(0.001));
            let (sx, sy) = ((rect[2] - rect[0]).abs() / bw, (rect[3] - rect[1]).abs() / bh);
            let (tx, ty) = (rect[0].min(rect[2]) - bbox[0].min(bbox[2]) * sx, rect[1].min(rect[3]) - bbox[1].min(bbox[3]) * sy);
            let name = format!("FlatAnnot{}", fid.0);
            ops += &format!("q {sx:.5} 0 0 {sy:.5} {tx:.4} {ty:.4} cm /{name} Do Q\n");
            xobjs.push((name, fid));
            doc.objects.remove(&aid);
            flattened += 1;
        }
        if xobjs.is_empty() {
            continue;
        }
        // Resources: make an owned dictionary on the page, adding XObjects.
        let res = match doc.get_dictionary(pid)?.get(b"Resources").ok().cloned() {
            Some(Object::Reference(r)) => doc.get_dictionary(r).cloned().unwrap_or_default(),
            Some(Object::Dictionary(d)) => d,
            _ => Dictionary::new(),
        };
        let mut res = res;
        let mut xo = match res.get(b"XObject").ok().cloned() {
            Some(Object::Reference(r)) => doc.get_dictionary(r).cloned().unwrap_or_default(),
            Some(Object::Dictionary(d)) => d,
            _ => Dictionary::new(),
        };
        for (n, id) in &xobjs {
            xo.set(n.as_bytes().to_vec(), *id);
        }
        res.set("XObject", Object::Dictionary(xo));
        // Wrap the original content in q/Q so our appended content starts from a clean state.
        let content_ids = doc.get_page_contents(pid);
        let pre = doc.add_object(Stream::new(Dictionary::new(), b"q\n".to_vec()));
        let post = doc.add_object(Stream::new(Dictionary::new(), format!("Q\n{ops}").into_bytes()));
        let mut arr = vec![Object::Reference(pre)];
        arr.extend(content_ids.into_iter().map(Object::Reference));
        arr.push(Object::Reference(post));
        let pd = doc.get_dictionary_mut(pid)?;
        pd.set("Resources", Object::Dictionary(res));
        pd.set("Contents", Object::Array(arr));
        pd.set("Annots", Object::Array(keep));
    }
    // Widgets are gone: drop the AcroForm so no orphaned fields remain.
    if only_widgets || flattened > 0 {
        if let Ok(cat) = doc.catalog_mut() {
            if only_widgets {
                cat.remove(b"AcroForm");
            }
        }
    }
    if flattened == 0 && !only_widgets {
        return Err(EditError("there are no annotations to flatten".into()));
    }
    Ok(flattened)
}
