//! Stateless document operations (T3/T4): merge, split, extract, compress, protect, unlock,
//! rasterise-redact, incremental save and atomic file writes.
use crate::{EditError, Result, flatten_pages, page_ids, pages, serialize, validate};
use lopdf::encryption::crypt_filters::{Aes256CryptFilter, CryptFilter};
use lopdf::{Dictionary, Document, EncryptionState, EncryptionVersion, Object, ObjectId, Permissions, Stream};
use std::collections::BTreeMap;
use std::sync::Arc;

fn load(bytes: &[u8], pw: &str) -> Result<Document> {
    Ok(Document::load_mem_with_options(bytes, lopdf::LoadOptions::with_password(pw))?)
}

/// Parse "1-3, 5, 9-" (1-based, inclusive) into sorted unique 0-based indices.
pub fn parse_ranges(spec: &str, page_count: usize) -> Result<Vec<usize>> {
    let mut out = Vec::new();
    for part in spec.split([',', ';']).map(str::trim).filter(|p| !p.is_empty()) {
        let (a, b) = match part.split_once('-') {
            Some((a, b)) => {
                let a = if a.trim().is_empty() { 1 } else { a.trim().parse::<usize>().map_err(|_| EditError(format!("bad range '{part}'")))? };
                let b = if b.trim().is_empty() { page_count } else { b.trim().parse::<usize>().map_err(|_| EditError(format!("bad range '{part}'")))? };
                (a, b)
            }
            None => {
                let n = part.parse::<usize>().map_err(|_| EditError(format!("bad page '{part}'")))?;
                (n, n)
            }
        };
        if a == 0 || b == 0 || a > b || b > page_count {
            return Err(EditError(format!("range '{part}' is outside 1–{page_count}")));
        }
        out.extend(a - 1..b);
    }
    out.sort_unstable();
    out.dedup();
    if out.is_empty() {
        return Err("no pages selected".into());
    }
    Ok(out)
}

/// Keep only `keep` (0-based) pages, in document order.
pub fn extract_pages(bytes: &[u8], password: &str, keep: &[usize]) -> Result<Vec<u8>> {
    let mut doc = load(bytes, password)?;
    flatten_pages(&mut doc)?;
    let ids = page_ids(&doc);
    let kept: Vec<ObjectId> = keep.iter().filter_map(|i| ids.get(*i).copied()).collect();
    if kept.is_empty() {
        return Err("no pages selected".into());
    }
    pages::set_kids(&mut doc, &kept)?;
    doc.prune_objects();
    let out = serialize(&mut doc)?;
    validate(&out, Some(kept.len()))?;
    Ok(out)
}

/// Split into consecutive chunks of `every` pages.
pub fn split_every(bytes: &[u8], password: &str, every: usize) -> Result<Vec<Vec<u8>>> {
    let n = validate(bytes, None).or_else(|_| load(bytes, password).map(|d| d.get_pages().len()))?;
    let every = every.max(1);
    let mut out = Vec::new();
    let mut i = 0;
    while i < n {
        let idx: Vec<usize> = (i..(i + every).min(n)).collect();
        out.push(extract_pages(bytes, password, &idx)?);
        i += every;
    }
    Ok(out)
}

/// Merge documents (each `(bytes, password)`), preserving page order.
pub fn merge(inputs: &[(Vec<u8>, String)]) -> Result<Vec<u8>> {
    if inputs.len() < 2 {
        return Err("select at least two documents to merge".into());
    }
    let mut next_id = 1u32;
    let mut objects: BTreeMap<ObjectId, Object> = BTreeMap::new();
    let mut page_list: Vec<ObjectId> = Vec::new();
    for (bytes, pw) in inputs {
        let mut doc = load(bytes, pw)?;
        flatten_pages(&mut doc)?;
        doc.renumber_objects_with(next_id);
        next_id = doc.max_id + 1;
        page_list.extend(page_ids(&doc));
        objects.extend(doc.objects);
    }
    let mut out = Document::with_version("1.7");
    out.objects = objects;
    out.max_id = next_id;
    let pages_id = out.new_object_id();
    let mut dummy = Dictionary::new();
    dummy.set("Type", "Pages");
    out.objects.insert(pages_id, Object::Dictionary(dummy));
    let catalog = out.add_object(lopdf::dictionary! {"Type"=>"Catalog","Pages"=>pages_id});
    out.trailer.set("Root", catalog);
    pages::set_kids(&mut out, &page_list)?;
    // Drop references to the old per-document catalogs/page roots.
    out.prune_objects();
    let bytes = serialize(&mut out)?;
    validate(&bytes, Some(page_list.len()))?;
    Ok(bytes)
}

#[derive(Debug, Clone, Copy)]
pub struct CompressStats {
    pub before: usize,
    pub after: usize,
}

/// Re-compress streams, drop unreferenced objects and write modern object/xref streams.
/// Returns the smaller of {input, output}: a "compress" never makes a file bigger.
pub fn compress(bytes: &[u8], password: &str) -> Result<(Vec<u8>, CompressStats)> {
    let mut doc = load(bytes, password)?;
    let pages = doc.get_pages().len();
    doc.prune_objects();
    doc.compress();
    let mut out = Vec::new();
    doc.save_modern(&mut out)?;
    validate(&out, Some(pages))?;
    let stats = CompressStats { before: bytes.len(), after: out.len().min(bytes.len()) };
    if out.len() < bytes.len() { Ok((out, stats)) } else { Ok((bytes.to_vec(), stats)) }
}

/// AES-256 (PDF 2.0, R6) password protection.
pub fn protect(bytes: &[u8], password: &str, user_pw: &str, owner_pw: &str) -> Result<Vec<u8>> {
    if user_pw.is_empty() {
        return Err("a password is required".into());
    }
    let mut doc = load(bytes, password)?;
    let pages = doc.get_pages().len();
    if doc.is_encrypted() {
        return Err("the document is already encrypted – unlock it first".into());
    }
    let mut key = [0u8; 32];
    getrandom::fill(&mut key).map_err(|e| EditError(format!("no secure random source: {e}")))?;
    let cf: Arc<dyn CryptFilter> = Arc::new(Aes256CryptFilter);
    let owner = if owner_pw.is_empty() { user_pw } else { owner_pw };
    let state = EncryptionState::try_from(EncryptionVersion::V5 {
        encrypt_metadata: true,
        crypt_filters: BTreeMap::from([(b"StdCF".to_vec(), cf)]),
        file_encryption_key: &key,
        stream_filter: b"StdCF".to_vec(),
        string_filter: b"StdCF".to_vec(),
        owner_password: owner,
        user_password: user_pw,
        permissions: Permissions::all(),
    })?;
    doc.encrypt(&state)?;
    let out = serialize(&mut doc)?;
    // Validation: must be unreadable without the password and readable with it.
    match folio_core::open(Arc::new(out.clone()), "") {
        Err(folio_core::OpenError::NeedPassword) => {}
        _ => return Err("encryption self-check failed (document opened without a password)".into()),
    }
    let p = folio_core::open(Arc::new(out.clone()), user_pw).map_err(|e| EditError(format!("encryption self-check failed: {e}")))?;
    if p.pages().len() != pages {
        return Err("encryption self-check failed (page count)".into());
    }
    Ok(out)
}

/// Remove password protection (requires the correct password).
pub fn unlock(bytes: &[u8], password: &str) -> Result<Vec<u8>> {
    let mut doc = load(bytes, password)?;
    let pages = doc.get_pages().len();
    if doc.is_encrypted() {
        doc.decrypt_raw_for_save();
    }
    let out = serialize(&mut doc)?;
    validate(&out, Some(pages))?;
    Ok(out)
}

trait DecryptExt {
    fn decrypt_raw_for_save(&mut self);
}
impl DecryptExt for Document {
    fn decrypt_raw_for_save(&mut self) {
        // `load_mem_with_options(.. password)` already decrypted objects in memory; make sure the
        // writer does not emit a stale /Encrypt entry.
        self.trailer.remove(b"Encrypt");
        self.encryption_state = None;
    }
}

/// True content removal for redaction: every page in `rendered` (index, PNG/JPEG bytes of the page
/// as displayed, width/height in points) is replaced by a single image – text, vectors, links and
/// annotations on that page cease to exist in the file.
pub fn rasterize_pages(doc: &mut Document, rendered: &[(usize, Vec<u8>, f32, f32)]) -> Result<()> {
    let ids = page_ids(doc);
    for (idx, img_bytes, w, h) in rendered {
        let pid = *ids.get(*idx).ok_or("page does not exist")?;
        let (img, _, _) = crate::annot::add_image(doc, img_bytes)?;
        let content = format!("q {w:.3} 0 0 {h:.3} 0 0 cm /Im0 Do Q").into_bytes();
        let cid = doc.add_object(Stream::new(Dictionary::new(), content));
        let d = doc.get_dictionary_mut(pid)?;
        for k in [&b"Annots"[..], b"CropBox", b"Rotate", b"B", b"Group", b"StructParents", b"PieceInfo", b"Thumb", b"AA", b"Metadata"] {
            d.remove(k);
        }
        d.set("MediaBox", vec![0.into(), 0.into(), Object::Real(*w), Object::Real(*h)]);
        d.set("Contents", cid);
        d.set("Resources", Object::Dictionary(lopdf::dictionary! {"XObject"=>lopdf::dictionary!{"Im0"=>img}}));
    }
    Ok(())
}

// ───────────────────────── incremental save ─────────────────────────

fn find_startxref(bytes: &[u8]) -> Option<usize> {
    let tail_start = bytes.len().saturating_sub(2048);
    let tail = &bytes[tail_start..];
    let pos = tail.windows(9).rposition(|w| w == b"startxref")?;
    let rest = std::str::from_utf8(&tail[pos + 9..]).ok()?;
    rest.split_whitespace().next()?.parse().ok()
}

/// Append only the changed objects to the original bytes (classic xref files only).
pub fn save_incremental(orig: &[u8], orig_doc: &Document, new_doc: &Document) -> Result<Vec<u8>> {
    if orig_doc.is_encrypted() || new_doc.is_encrypted() || orig_doc.trailer.has(b"Encrypt") {
        return Err("encrypted documents are rewritten, not appended to".into());
    }
    let prev = find_startxref(orig).ok_or("no startxref")?;
    let at = orig.get(prev..).ok_or("bad startxref")?;
    let classic = at.iter().skip_while(|b| b.is_ascii_whitespace()).take(4).eq(b"xref".iter());
    let mut changed: Vec<ObjectId> = new_doc
        .objects
        .iter()
        .filter(|(id, o)| orig_doc.objects.get(*id) != Some(*o))
        .map(|(id, _)| *id)
        .collect();
    changed.sort();
    if changed.is_empty() {
        return Ok(orig.to_vec());
    }
    let mut out = orig.to_vec();
    if !out.ends_with(b"\n") {
        out.push(b'\n');
    }
    let mut offsets: Vec<(ObjectId, usize)> = Vec::new();
    for id in &changed {
        offsets.push((*id, out.len()));
        out.extend(format!("{} {} obj\n", id.0, id.1).as_bytes());
        let o = new_doc.objects.get(id).ok_or("object vanished")?;
        lopdf::Writer::write_object(&mut out, o)?;
        out.extend(b"\nendobj\n");
    }
    let orig_size = match orig_doc.trailer.get(b"Size") {
        Ok(Object::Integer(s)) => *s as u32,
        _ => 0,
    };
    let size = orig_size.max(new_doc.max_id + 1).max(changed.last().map_or(0, |i| i.0 + 1));
    let mut tr = Dictionary::new();
    for k in [&b"Root"[..], b"Info", b"ID"] {
        if let Ok(v) = new_doc.trailer.get(k).or_else(|_| orig_doc.trailer.get(k)) {
            tr.set(k.to_vec(), v.clone());
        }
    }
    tr.set("Prev", prev as i64);
    let xref_pos = out.len();
    if classic {
        out.extend(b"xref\n");
        let mut i = 0;
        while i < offsets.len() {
            let mut j = i;
            while j + 1 < offsets.len() && offsets[j + 1].0.0 == offsets[j].0.0 + 1 {
                j += 1;
            }
            out.extend(format!("{} {}\n", offsets[i].0.0, j - i + 1).as_bytes());
            for (id, off) in &offsets[i..=j] {
                out.extend(format!("{:010} {:05} n \n", off, id.1).as_bytes());
            }
            i = j + 1;
        }
        tr.set("Size", size as i64);
        out.extend(b"trailer\n");
        lopdf::Writer::write_object(&mut out, &Object::Dictionary(tr))?;
    } else {
        // Cross-reference *stream* update (the original uses xref streams – keep that form).
        let xid = size; // object number of the new xref stream itself
        offsets.push(((xid, 0), xref_pos));
        let mut data = Vec::new();
        let mut index: Vec<Object> = Vec::new();
        let mut i = 0;
        while i < offsets.len() {
            let mut j = i;
            while j + 1 < offsets.len() && offsets[j + 1].0.0 == offsets[j].0.0 + 1 {
                j += 1;
            }
            index.push(Object::Integer(offsets[i].0.0 as i64));
            index.push(Object::Integer((j - i + 1) as i64));
            for (id, off) in &offsets[i..=j] {
                data.push(1u8);
                data.extend((*off as u32).to_be_bytes());
                data.extend((id.1).to_be_bytes());
            }
            i = j + 1;
        }
        tr.set("Type", "XRef");
        tr.set("Size", (xid + 1) as i64);
        tr.set("W", vec![Object::Integer(1), Object::Integer(4), Object::Integer(2)]);
        tr.set("Index", Object::Array(index));
        tr.set("Length", data.len() as i64);
        out.extend(format!("{xid} 0 obj\n").as_bytes());
        lopdf::Writer::write_object(&mut out, &Object::Stream(Stream { dict: tr, content: data, allows_compression: false, start_position: None }))?;
        out.extend(b"\nendobj\n");
    }
    out.extend(format!("\nstartxref\n{xref_pos}\n%%EOF\n").as_bytes());
    Ok(out)
}

// ───────────────────────── files ─────────────────────────

/// Write-to-temp, flush, then rename over the destination. A crash never leaves a half-written file.
#[cfg(not(target_arch = "wasm32"))]
pub fn write_atomic(path: &std::path::Path, bytes: &[u8]) -> Result<()> {
    use std::io::Write;
    let tmp = path.with_extension("folio-tmp");
    let r = (|| -> std::io::Result<()> {
        let mut f = std::fs::File::create(&tmp)?;
        f.write_all(bytes)?;
        f.sync_all()?;
        std::fs::rename(&tmp, path)
    })();
    if r.is_err() {
        let _ = std::fs::remove_file(&tmp);
    }
    r.map_err(|e| EditError(format!("could not write {}: {e}", path.display())))
}

/// Minimal ZIP writer (stored, no compression) – used to deliver split parts as one download.
pub fn zip_store(files: &[(String, Vec<u8>)]) -> Vec<u8> {
    fn crc32(data: &[u8]) -> u32 {
        let mut c = 0xFFFF_FFFFu32;
        for &b in data {
            c ^= b as u32;
            for _ in 0..8 {
                c = if c & 1 != 0 { 0xEDB8_8320 ^ (c >> 1) } else { c >> 1 };
            }
        }
        !c
    }
    let mut out = Vec::new();
    let mut central = Vec::new();
    for (name, data) in files {
        let off = out.len() as u32;
        let crc = crc32(data);
        let nb = name.as_bytes();
        out.extend(0x0403_4b50u32.to_le_bytes());
        out.extend([20, 0, 0, 0, 0, 0, 0, 0, 0x21, 0]);
        out.extend(crc.to_le_bytes());
        out.extend((data.len() as u32).to_le_bytes());
        out.extend((data.len() as u32).to_le_bytes());
        out.extend((nb.len() as u16).to_le_bytes());
        out.extend(0u16.to_le_bytes());
        out.extend(nb);
        out.extend(data);
        central.extend(0x0201_4b50u32.to_le_bytes());
        central.extend([20, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0x21, 0]);
        central.extend(crc.to_le_bytes());
        central.extend((data.len() as u32).to_le_bytes());
        central.extend((data.len() as u32).to_le_bytes());
        central.extend((nb.len() as u16).to_le_bytes());
        central.extend([0u8; 12]);
        central.extend(off.to_le_bytes());
        central.extend(nb);
    }
    let cstart = out.len() as u32;
    out.extend(&central);
    out.extend(0x0605_4b50u32.to_le_bytes());
    out.extend([0, 0, 0, 0]);
    out.extend((files.len() as u16).to_le_bytes());
    out.extend((files.len() as u16).to_le_bytes());
    out.extend((central.len() as u32).to_le_bytes());
    out.extend(cstart.to_le_bytes());
    out.extend(0u16.to_le_bytes());
    out
}
