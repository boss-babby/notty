//! `folio-edit` – every edit is a reversible [`Command`] executed through a [`Session`].
//!
//! Saving never corrupts a file: output is serialised to memory, **re-parsed and validated**
//! (hayro + lopdf, same page count) and only then handed to the caller / written atomically.

pub mod annot;
mod ops;
mod pages;

pub use annot::{AnnotSpec, Rect, Rgb};
pub use ops::*;
pub use pages::{flatten_pages, page_ids};

use lopdf::{Dictionary, Document, Object, ObjectId, dictionary};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EditError(pub String);
impl std::fmt::Display for EditError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.0)
    }
}
impl std::error::Error for EditError {}
impl From<lopdf::Error> for EditError {
    fn from(e: lopdf::Error) -> Self {
        EditError(e.to_string())
    }
}
impl From<std::io::Error> for EditError {
    fn from(e: std::io::Error) -> Self {
        EditError(e.to_string())
    }
}
impl From<String> for EditError {
    fn from(e: String) -> Self {
        EditError(e)
    }
}
impl From<&str> for EditError {
    fn from(e: &str) -> Self {
        EditError(e.to_owned())
    }
}
pub type Result<T> = std::result::Result<T, EditError>;

/// A reversible edit. `apply` may be called again after `undo` (redo).
pub trait Command: Send {
    fn label(&self) -> String;
    fn apply(&mut self, doc: &mut Document) -> Result<()>;
    fn undo(&mut self, doc: &mut Document) -> Result<()>;
}

/// Editing session over a parsed document.
pub struct Session {
    pub doc: Document,
    original: Document,
    original_bytes: Vec<u8>,
    undo: Vec<Box<dyn Command>>,
    redo: Vec<Box<dyn Command>>,
    pub save_count: u32,
}

impl Session {
    pub fn load(bytes: &[u8], password: &str) -> Result<Self> {
        let opts = lopdf::LoadOptions::with_password(password);
        let mut doc = Document::load_mem_with_options(bytes, opts)?;
        let original = doc.clone();
        flatten_pages(&mut doc)?;
        Ok(Self { doc, original, original_bytes: bytes.to_vec(), undo: Vec::new(), redo: Vec::new(), save_count: 0 })
    }

    pub fn page_count(&self) -> usize {
        page_ids(&self.doc).len()
    }

    pub fn execute(&mut self, mut cmd: Box<dyn Command>) -> Result<()> {
        // Work on a scratch copy of the touched state only if the command fails half-way:
        // commands are written to validate before mutating.
        cmd.apply(&mut self.doc)?;
        self.undo.push(cmd);
        self.redo.clear();
        Ok(())
    }
    pub fn can_undo(&self) -> bool {
        !self.undo.is_empty()
    }
    pub fn can_redo(&self) -> bool {
        !self.redo.is_empty()
    }
    pub fn undo_label(&self) -> Option<String> {
        self.undo.last().map(|c| c.label())
    }
    pub fn redo_label(&self) -> Option<String> {
        self.redo.last().map(|c| c.label())
    }
    pub fn undo(&mut self) -> Result<Option<String>> {
        let Some(mut c) = self.undo.pop() else { return Ok(None) };
        c.undo(&mut self.doc)?;
        let l = c.label();
        self.redo.push(c);
        Ok(Some(l))
    }
    pub fn redo(&mut self) -> Result<Option<String>> {
        let Some(mut c) = self.redo.pop() else { return Ok(None) };
        c.apply(&mut self.doc)?;
        let l = c.label();
        self.undo.push(c);
        Ok(Some(l))
    }
    pub fn history_len(&self) -> usize {
        self.undo.len()
    }

    /// Serialise the current state (full rewrite, validated).
    pub fn to_bytes(&mut self) -> Result<Vec<u8>> {
        let expected = self.page_count();
        let mut d = self.doc.clone();
        d.prune_objects();
        let bytes = serialize(&mut d)?;
        validate(&bytes, Some(expected))?;
        Ok(bytes)
    }

    /// Serialise the working copy used by the viewer (no pruning – cheap, validated).
    pub fn to_view_bytes(&mut self) -> Result<Vec<u8>> {
        let expected = self.page_count();
        let mut d = self.doc.clone();
        let bytes = serialize(&mut d)?;
        validate(&bytes, Some(expected))?;
        Ok(bytes)
    }

    /// Prefer an incremental update appended to the original bytes (original bytes stay untouched,
    /// signatures stay valid); fall back to a full validated rewrite when that is not possible.
    pub fn to_bytes_incremental_or_full(&mut self) -> Result<(Vec<u8>, bool)> {
        let expected = self.page_count();
        if let Ok(b) = ops::save_incremental(&self.original_bytes, &self.original, &self.doc) {
            if validate(&b, Some(expected)).is_ok() {
                return Ok((b, true));
            }
        }
        Ok((self.to_bytes()?, false))
    }
}

pub(crate) fn serialize(doc: &mut Document) -> Result<Vec<u8>> {
    let mut out = Vec::new();
    doc.save_to(&mut out)?;
    Ok(out)
}

/// Re-parse `bytes` with both parsers; optionally check the page count.
pub fn validate(bytes: &[u8], expected_pages: Option<usize>) -> Result<usize> {
    let pdf = folio_core::open(std::sync::Arc::new(bytes.to_vec()), "").map_err(|e| EditError(format!("validation (render parser): {e}")))?;
    let n = pdf.pages().len();
    if let Some(e) = expected_pages {
        if e != n {
            return Err(EditError(format!("validation: expected {e} pages, output has {n}")));
        }
    }
    Ok(n)
}

// ───────────────────────────────── commands ─────────────────────────────────

fn page_id(doc: &Document, idx: usize) -> Result<ObjectId> {
    page_ids(doc).get(idx).copied().ok_or_else(|| EditError(format!("page {} does not exist", idx + 1)))
}

fn annots_array_mut(doc: &mut Document, page: ObjectId) -> Result<&mut Vec<Object>> {
    // Normalise to a direct array on the page dictionary.
    let existing = doc.get_dictionary(page)?.get(b"Annots").ok().cloned();
    let arr = match existing {
        Some(Object::Array(a)) => a,
        Some(Object::Reference(r)) => match doc.get_object(r) {
            Ok(Object::Array(a)) => a.clone(),
            _ => Vec::new(),
        },
        _ => Vec::new(),
    };
    let d = doc.get_dictionary_mut(page)?;
    d.set("Annots", Object::Array(arr));
    match d.get_mut(b"Annots")? {
        Object::Array(a) => Ok(a),
        _ => Err("annots".into()),
    }
}

pub struct AddAnnotation {
    pub page: usize,
    pub spec: AnnotSpec,
    created: Option<ObjectId>,
}
impl AddAnnotation {
    pub fn new(page: usize, spec: AnnotSpec) -> Box<Self> {
        Box::new(Self { page, spec, created: None })
    }
}
impl Command for AddAnnotation {
    fn label(&self) -> String {
        format!("Add {}", self.spec.kind().to_lowercase())
    }
    fn apply(&mut self, doc: &mut Document) -> Result<()> {
        let pid = page_id(doc, self.page)?;
        let mut d = self.spec.build(doc)?;
        d.set("P", pid);
        let id = doc.add_object(Object::Dictionary(d));
        annots_array_mut(doc, pid)?.push(Object::Reference(id));
        self.created = Some(id);
        Ok(())
    }
    fn undo(&mut self, doc: &mut Document) -> Result<()> {
        let pid = page_id(doc, self.page)?;
        if let Some(id) = self.created.take() {
            annots_array_mut(doc, pid)?.retain(|o| o.as_reference().ok() != Some(id));
            doc.objects.remove(&id);
        }
        Ok(())
    }
}

pub struct RotatePage {
    pub page: usize,
    pub delta: i64,
    old: Option<Option<Object>>,
}
impl RotatePage {
    pub fn new(page: usize, delta: i64) -> Box<Self> {
        Box::new(Self { page, delta, old: None })
    }
}
impl Command for RotatePage {
    fn label(&self) -> String {
        format!("Rotate page {}", self.page + 1)
    }
    fn apply(&mut self, doc: &mut Document) -> Result<()> {
        let pid = page_id(doc, self.page)?;
        let d = doc.get_dictionary_mut(pid)?;
        let cur = d.get(b"Rotate").ok().cloned();
        let n = match &cur {
            Some(Object::Integer(i)) => *i,
            _ => 0,
        };
        self.old = Some(cur);
        d.set("Rotate", (n + self.delta).rem_euclid(360));
        Ok(())
    }
    fn undo(&mut self, doc: &mut Document) -> Result<()> {
        let pid = page_id(doc, self.page)?;
        let d = doc.get_dictionary_mut(pid)?;
        match self.old.take() {
            Some(Some(o)) => d.set("Rotate", o),
            _ => {
                d.remove(b"Rotate");
            }
        }
        Ok(())
    }
}

pub struct DeletePage {
    pub page: usize,
    removed: Option<ObjectId>,
}
impl DeletePage {
    pub fn new(page: usize) -> Box<Self> {
        Box::new(Self { page, removed: None })
    }
}
impl Command for DeletePage {
    fn label(&self) -> String {
        format!("Delete page {}", self.page + 1)
    }
    fn apply(&mut self, doc: &mut Document) -> Result<()> {
        let mut ids = page_ids(doc);
        if ids.len() <= 1 {
            return Err("a document must keep at least one page".into());
        }
        if self.page >= ids.len() {
            return Err("page does not exist".into());
        }
        self.removed = Some(ids.remove(self.page));
        pages::set_kids(doc, &ids)
    }
    fn undo(&mut self, doc: &mut Document) -> Result<()> {
        let mut ids = page_ids(doc);
        if let Some(id) = self.removed.take() {
            ids.insert(self.page.min(ids.len()), id);
        }
        pages::set_kids(doc, &ids)
    }
}

pub struct MovePage {
    pub from: usize,
    pub to: usize,
}
impl MovePage {
    pub fn new(from: usize, to: usize) -> Box<Self> {
        Box::new(Self { from, to })
    }
}
impl Command for MovePage {
    fn label(&self) -> String {
        format!("Move page {} to {}", self.from + 1, self.to + 1)
    }
    fn apply(&mut self, doc: &mut Document) -> Result<()> {
        let mut ids = page_ids(doc);
        if self.from >= ids.len() || self.to >= ids.len() {
            return Err("page does not exist".into());
        }
        let p = ids.remove(self.from);
        ids.insert(self.to, p);
        pages::set_kids(doc, &ids)
    }
    fn undo(&mut self, doc: &mut Document) -> Result<()> {
        let mut ids = page_ids(doc);
        if self.from >= ids.len() || self.to >= ids.len() {
            return Err("page does not exist".into());
        }
        let p = ids.remove(self.to);
        ids.insert(self.from, p);
        pages::set_kids(doc, &ids)
    }
}

/// Insert a blank page (or an image page) after `after` (use `usize::MAX` for "at start").
pub struct InsertPage {
    pub after: Option<usize>,
    pub size: (f32, f32),
    pub image: Option<Vec<u8>>,
    created: Option<ObjectId>,
    at: usize,
}
impl InsertPage {
    pub fn blank(after: Option<usize>, size: (f32, f32)) -> Box<Self> {
        Box::new(Self { after, size, image: None, created: None, at: 0 })
    }
    pub fn image(after: Option<usize>, bytes: Vec<u8>) -> Box<Self> {
        Box::new(Self { after, size: (612.0, 792.0), image: Some(bytes), created: None, at: 0 })
    }
}
impl Command for InsertPage {
    fn label(&self) -> String {
        if self.image.is_some() { "Insert image page".into() } else { "Insert blank page".into() }
    }
    fn apply(&mut self, doc: &mut Document) -> Result<()> {
        let mut ids = page_ids(doc);
        let root = pages::root_pages_id(doc)?;
        let at = self.after.map_or(0, |a| (a + 1).min(ids.len()));
        let (mut w, mut h) = self.size;
        let mut content = Vec::new();
        let mut res = lopdf::Dictionary::new();
        if let Some(bytes) = &self.image {
            let (img, iw, ih) = annot::add_image(doc, bytes)?;
            // Fit inside Letter keeping aspect; landscape images get a landscape page.
            let (mw, mh) = if iw > ih { (792.0f32, 612.0f32) } else { (612.0, 792.0) };
            let s = (mw / iw as f32).min(mh / ih as f32).min(1.0 * 72.0 / 72.0 * 10.0);
            w = iw as f32 * s;
            h = ih as f32 * s;
            content = format!("q {w:.3} 0 0 {h:.3} 0 0 cm /Im0 Do Q").into_bytes();
            res.set("XObject", Object::Dictionary(dictionary! {"Im0" => img}));
        }
        let cid = doc.add_object(lopdf::Stream::new(Dictionary::new(), content));
        let pid = doc.add_object(dictionary! {
            "Type"=>"Page","Parent"=>root,"Contents"=>cid,"Resources"=>Object::Dictionary(res),
            "MediaBox"=>vec![0.into(),0.into(),Object::Real(w),Object::Real(h)],
        });
        ids.insert(at, pid);
        self.created = Some(pid);
        self.at = at;
        pages::set_kids(doc, &ids)
    }
    fn undo(&mut self, doc: &mut Document) -> Result<()> {
        if let Some(id) = self.created.take() {
            let mut ids = page_ids(doc);
            ids.retain(|p| *p != id);
            pages::set_kids(doc, &ids)?;
        }
        Ok(())
    }
}

pub struct SetMetadata {
    pub key: String,
    pub value: String,
    old: Option<Option<Object>>,
}
impl SetMetadata {
    pub fn new(key: &str, value: &str) -> Box<Self> {
        Box::new(Self { key: key.into(), value: value.into(), old: None })
    }
}
fn info_id(doc: &mut Document) -> ObjectId {
    if let Ok(Object::Reference(r)) = doc.trailer.get(b"Info") {
        return *r;
    }
    let id = doc.add_object(Dictionary::new());
    doc.trailer.set("Info", id);
    id
}
fn utf16_string(s: &str) -> Object {
    if s.is_ascii() {
        Object::String(s.as_bytes().to_vec(), lopdf::StringFormat::Literal)
    } else {
        let mut v = vec![0xFE, 0xFF];
        for u in s.encode_utf16() {
            v.extend(u.to_be_bytes());
        }
        Object::String(v, lopdf::StringFormat::Hexadecimal)
    }
}
impl Command for SetMetadata {
    fn label(&self) -> String {
        format!("Set {}", self.key.to_lowercase())
    }
    fn apply(&mut self, doc: &mut Document) -> Result<()> {
        let id = info_id(doc);
        let d = doc.get_dictionary_mut(id)?;
        self.old = Some(d.get(self.key.as_bytes()).ok().cloned());
        if self.value.is_empty() {
            d.remove(self.key.as_bytes());
        } else {
            d.set(self.key.as_bytes().to_vec(), utf16_string(&self.value));
        }
        Ok(())
    }
    fn undo(&mut self, doc: &mut Document) -> Result<()> {
        let id = info_id(doc);
        let d = doc.get_dictionary_mut(id)?;
        match self.old.take() {
            Some(Some(o)) => d.set(self.key.as_bytes().to_vec(), o),
            _ => {
                d.remove(self.key.as_bytes());
            }
        }
        Ok(())
    }
}

/// Whole-document transform with snapshot undo (flatten, rasterise/redact, …).
pub struct Snapshot<F: Fn(&mut Document) -> Result<()> + Send> {
    name: String,
    f: F,
    before: Option<Document>,
}
impl<F: Fn(&mut Document) -> Result<()> + Send + 'static> Snapshot<F> {
    pub fn new(name: &str, f: F) -> Box<Self> {
        Box::new(Self { name: name.into(), f, before: None })
    }
}
impl<F: Fn(&mut Document) -> Result<()> + Send> Command for Snapshot<F> {
    fn label(&self) -> String {
        self.name.clone()
    }
    fn apply(&mut self, doc: &mut Document) -> Result<()> {
        let backup = doc.clone();
        match (self.f)(doc) {
            Ok(()) => {
                self.before = Some(backup);
                Ok(())
            }
            Err(e) => {
                *doc = backup;
                Err(e)
            }
        }
    }
    fn undo(&mut self, doc: &mut Document) -> Result<()> {
        if let Some(b) = self.before.take() {
            *doc = b;
        }
        Ok(())
    }
}

pub struct SetFormField {
    pub name: String,
    pub value: String,
    old: Option<(ObjectId, Option<Object>, bool)>,
}
impl SetFormField {
    pub fn new(name: &str, value: &str) -> Box<Self> {
        Box::new(Self { name: name.into(), value: value.into(), old: None })
    }
}
impl Command for SetFormField {
    fn label(&self) -> String {
        format!("Fill field {}", self.name)
    }
    fn apply(&mut self, doc: &mut Document) -> Result<()> {
        let f = forms::list_fields(doc).into_iter().find(|f| f.name == self.name).ok_or("form field not found")?;
        let d = doc.get_dictionary_mut(f.id)?;
        self.old = Some((f.id, d.get(b"V").ok().cloned(), f.kind == forms::FieldKind::Text));
        d.set("V", utf16_string(&self.value));
        if f.kind == forms::FieldKind::Text {
            forms::build_text_appearance(doc, f.id, &self.value)?;
        } else {
            forms::set_need_appearances(doc);
        }
        Ok(())
    }
    fn undo(&mut self, doc: &mut Document) -> Result<()> {
        if let Some((id, old, is_text)) = self.old.take() {
            let prev_text = match &old {
                Some(Object::String(s, _)) => folio_core::decode_pdf_text(s),
                _ => String::new(),
            };
            let d = doc.get_dictionary_mut(id)?;
            match old {
                Some(o) => d.set("V", o),
                None => {
                    d.remove(b"V");
                }
            }
            if is_text {
                forms::build_text_appearance(doc, id, &prev_text)?;
            }
        }
        Ok(())
    }
}
pub mod forms;
