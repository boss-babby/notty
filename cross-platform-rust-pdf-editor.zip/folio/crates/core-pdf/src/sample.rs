//! Deterministic sample documents (tests, demo mode, benchmarks).
use lopdf::content::{Content, Operation};
use lopdf::{Dictionary, Document, Object, Stream, dictionary};

/// Build an `n`-page sample PDF with text, an outline, internal links and a URI link.
pub fn sample_pdf(n: usize) -> Vec<u8> {
    let n = n.max(1);
    let mut doc = Document::with_version("1.5");
    let pages_id = doc.new_object_id();
    let font = doc.add_object(dictionary! {"Type"=>"Font","Subtype"=>"Type1","BaseFont"=>"Helvetica"});
    let bold = doc.add_object(dictionary! {"Type"=>"Font","Subtype"=>"Type1","BaseFont"=>"Helvetica-Bold"});
    let res = doc.add_object(dictionary! {"Font"=>dictionary!{"F1"=>font,"F2"=>bold}});
    let mut page_ids = Vec::new();
    for i in 0..n {
        let ops = vec![
            Operation::new("q", vec![]),
            Operation::new("rg", vec![0.93f32.into(), 0.95f32.into(), 1.0f32.into()]),
            Operation::new("re", vec![36.into(), 700.into(), 540.into(), 60.into()]),
            Operation::new("f", vec![]),
            Operation::new("Q", vec![]),
            Operation::new("BT", vec![]),
            Operation::new("Tf", vec!["F2".into(), 22.into()]),
            Operation::new("Td", vec![72.into(), 725.into()]),
            Operation::new("Tj", vec![Object::string_literal(format!("Folio sample - page {}", i + 1))]),
            Operation::new("ET", vec![]),
            Operation::new("BT", vec![]),
            Operation::new("Tf", vec!["F1".into(), 12.into()]),
            Operation::new("Td", vec![72.into(), 660.into()]),
            Operation::new("Tj", vec![Object::string_literal("The quick brown fox jumps over the lazy dog.")]),
            Operation::new("Td", vec![0.into(), (-18).into()]),
            Operation::new("Tj", vec![Object::string_literal("Pure Rust parsing, rendering, editing and saving.")]),
            Operation::new("Td", vec![0.into(), (-18).into()]),
            Operation::new("Tj", vec![Object::string_literal("Search for the word needle on this line.")]),
            Operation::new("ET", vec![]),
        ];
        let content = Content { operations: ops };
        let cid = doc.add_object(Stream::new(dictionary! {}, content.encode().unwrap_or_default()));
        let pid = doc.add_object(dictionary! {
            "Type"=>"Page","Parent"=>pages_id,"Contents"=>cid,"Resources"=>res,
            "MediaBox"=>vec![0.into(),0.into(),612.into(),792.into()],
        });
        page_ids.push(pid);
    }
    // Links on page 1: internal link to page 2 (if any) and a URI link.
    let mut annots: Vec<Object> = Vec::new();
    if n >= 2 {
        let l = doc.add_object(dictionary! {
            "Type"=>"Annot","Subtype"=>"Link","Rect"=>vec![72.into(),640.into(),300.into(),656.into()],
            "Border"=>vec![0.into(),0.into(),0.into()],
            "Dest"=>vec![Object::Reference(page_ids[1]), "XYZ".into(), Object::Null, Object::Null, Object::Null],
        });
        annots.push(l.into());
    }
    let u = doc.add_object(dictionary! {
        "Type"=>"Annot","Subtype"=>"Link","Rect"=>vec![72.into(),600.into(),300.into(),616.into()],
        "Border"=>vec![0.into(),0.into(),0.into()],
        "A"=>dictionary!{"S"=>"URI","URI"=>Object::string_literal("https://www.rust-lang.org")},
    });
    annots.push(u.into());
    if let Ok(p) = doc.get_dictionary_mut(page_ids[0]) {
        p.set("Annots", annots);
    }
    let kids: Vec<Object> = page_ids.iter().map(|&p| p.into()).collect();
    doc.objects.insert(
        pages_id,
        Object::Dictionary(dictionary! {"Type"=>"Pages","Kids"=>kids,"Count"=>n as i64}),
    );
    // Outline.
    let outlines_id = doc.new_object_id();
    let mut items = Vec::new();
    for (i, pid) in page_ids.iter().enumerate() {
        let id = doc.new_object_id();
        items.push(id);
        let mut d = Dictionary::new();
        d.set("Title", Object::string_literal(format!("Chapter {}", i + 1)));
        d.set("Parent", outlines_id);
        d.set("Dest", vec![Object::Reference(*pid), "Fit".into()]);
        doc.objects.insert(id, Object::Dictionary(d));
    }
    for (i, id) in items.iter().enumerate() {
        if let Some(Object::Dictionary(d)) = doc.objects.get_mut(id) {
            if i > 0 {
                d.set("Prev", items[i - 1]);
            }
            if i + 1 < items.len() {
                d.set("Next", items[i + 1]);
            }
        }
    }
    doc.objects.insert(
        outlines_id,
        Object::Dictionary(dictionary! {"Type"=>"Outlines","First"=>items[0],"Last"=>*items.last().unwrap(),"Count"=>items.len() as i64}),
    );
    let info = doc.add_object(dictionary! {"Title"=>Object::string_literal("Folio sample"),"Author"=>Object::string_literal("Folio")});
    let catalog = doc.add_object(dictionary! {"Type"=>"Catalog","Pages"=>pages_id,"Outlines"=>outlines_id});
    doc.trailer.set("Root", catalog);
    doc.trailer.set("Info", info);
    let mut out = Vec::new();
    let _ = doc.save_to(&mut out);
    out
}
