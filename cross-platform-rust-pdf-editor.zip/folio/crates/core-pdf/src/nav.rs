//! Outline + link extraction through `lopdf`. Runs in the background; never on the render path.
use crate::decode_pdf_text;
use lopdf::{Dictionary, Document, Object, ObjectId};
use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct OutlineItem {
    pub level: usize,
    pub title: String,
    /// 0-based page index, if the destination resolved.
    pub page: Option<usize>,
}

#[derive(Debug, Clone, PartialEq)]
pub enum LinkTarget {
    Page { index: usize, y: Option<f32> },
    Uri(String),
}

#[derive(Debug, Clone)]
pub struct Link {
    /// Rect in *PDF user space* `[x0,y0,x1,y1]`; map with `PageGeom::rect_to_page`.
    pub rect: [f32; 4],
    pub target: LinkTarget,
}

#[derive(Debug, Clone, Default)]
pub struct Nav {
    pub outline: Vec<OutlineItem>,
    pub links: Vec<Vec<Link>>,
}

fn num(o: &Object) -> Option<f32> {
    match o {
        Object::Integer(i) => Some(*i as f32),
        Object::Real(r) => Some(*r),
        _ => None,
    }
}

struct Ctx<'d> {
    doc: &'d Document,
    page_index: HashMap<ObjectId, usize>,
}

impl Ctx<'_> {
    fn deref<'o>(&'o self, o: &'o Object) -> &'o Object {
        let mut cur = o;
        for _ in 0..16 {
            match cur {
                Object::Reference(id) => match self.doc.get_object(*id) {
                    Ok(n) => cur = n,
                    Err(_) => return &Object::Null,
                },
                _ => return cur,
            }
        }
        &Object::Null
    }

    fn dest_array(&self, arr: &[Object]) -> Option<LinkTarget> {
        let first = arr.first()?;
        let index = match first {
            Object::Reference(id) => *self.page_index.get(id)?,
            Object::Integer(i) if *i >= 0 => *i as usize, // remote-style 0-based index
            _ => return None,
        };
        let y = match arr.get(1) {
            Some(Object::Name(n)) if n == b"XYZ" => arr.get(3).and_then(num),
            Some(Object::Name(n)) if n == b"FitH" || n == b"FitBH" => arr.get(2).and_then(num),
            _ => None,
        };
        Some(LinkTarget::Page { index, y })
    }

    fn named(&self, name: &[u8]) -> Option<LinkTarget> {
        let cat = self.doc.catalog().ok()?;
        if let Ok(d) = cat.get(b"Dests") {
            if let Object::Dictionary(d) = self.deref(d) {
                if let Ok(v) = d.get(name) {
                    return self.dest_value(v, 0);
                }
            }
        }
        let names = match self.deref(cat.get(b"Names").ok()?) {
            Object::Dictionary(d) => d,
            _ => return None,
        };
        let tree = match self.deref(names.get(b"Dests").ok()?) {
            Object::Dictionary(d) => d,
            _ => return None,
        };
        self.name_tree(tree, name, 0)
    }

    fn name_tree(&self, node: &Dictionary, name: &[u8], depth: u32) -> Option<LinkTarget> {
        if depth > 16 {
            return None;
        }
        if let Ok(Object::Array(kids)) = node.get(b"Kids").map(|o| self.deref(o)) {
            for k in kids {
                if let Object::Dictionary(kd) = self.deref(k) {
                    if let Some(t) = self.name_tree(kd, name, depth + 1) {
                        return Some(t);
                    }
                }
            }
        }
        if let Ok(Object::Array(pairs)) = node.get(b"Names").map(|o| self.deref(o)) {
            for pair in pairs.chunks(2) {
                if let (Some(Object::String(k, _)), Some(v)) = (pair.first().map(|o| self.deref(o)), pair.get(1)) {
                    if k.as_slice() == name {
                        return self.dest_value(v, 0);
                    }
                }
            }
        }
        None
    }

    fn dest_value(&self, v: &Object, depth: u32) -> Option<LinkTarget> {
        if depth > 8 {
            return None;
        }
        match self.deref(v) {
            Object::Array(a) => self.dest_array(a),
            Object::Dictionary(d) => d.get(b"D").ok().and_then(|x| self.dest_value(x, depth + 1)),
            Object::Name(n) => self.named(n),
            Object::String(s, _) => self.named(s),
            _ => None,
        }
    }

    fn link_target(&self, annot: &Dictionary) -> Option<LinkTarget> {
        if let Ok(a) = annot.get(b"A") {
            if let Object::Dictionary(a) = self.deref(a) {
                let s = a.get(b"S").ok().map(|o| self.deref(o));
                match s {
                    Some(Object::Name(n)) if n == b"URI" => {
                        if let Ok(Object::String(u, _)) = a.get(b"URI").map(|o| self.deref(o)) {
                            let u = decode_pdf_text(u);
                            // Only allow web-ish schemes from untrusted documents.
                            let l = u.to_ascii_lowercase();
                            if l.starts_with("http://") || l.starts_with("https://") || l.starts_with("mailto:") {
                                return Some(LinkTarget::Uri(u));
                            }
                        }
                        return None;
                    }
                    Some(Object::Name(n)) if n == b"GoTo" => {
                        return a.get(b"D").ok().and_then(|d| self.dest_value(d, 0));
                    }
                    _ => {}
                }
            }
        }
        annot.get(b"Dest").ok().and_then(|d| self.dest_value(d, 0))
    }

    fn outline(&self) -> Vec<OutlineItem> {
        let mut out = Vec::new();
        let Ok(cat) = self.doc.catalog() else { return out };
        let Some(Object::Dictionary(root)) = cat.get(b"Outlines").ok().map(|o| self.deref(o)) else {
            return out;
        };
        let mut budget = 5000usize;
        if let Ok(first) = root.get(b"First") {
            self.walk(first, 0, &mut out, &mut budget);
        }
        out
    }

    fn walk(&self, first: &Object, level: usize, out: &mut Vec<OutlineItem>, budget: &mut usize) {
        let mut cur = first.clone();
        while *budget > 0 && level < 24 {
            *budget -= 1;
            let Object::Dictionary(d) = self.deref(&cur) else { break };
            let title = match d.get(b"Title").map(|o| self.deref(o)) {
                Ok(Object::String(s, _)) => decode_pdf_text(s),
                _ => String::new(),
            };
            let target = if d.has(b"A") || d.has(b"Dest") { self.link_target(d) } else { None };
            let page = match target {
                Some(LinkTarget::Page { index, .. }) => Some(index),
                _ => None,
            };
            out.push(OutlineItem { level, title, page });
            if let Ok(child) = d.get(b"First") {
                self.walk(child, level + 1, out, budget);
            }
            match d.get(b"Next") {
                Ok(n) => cur = n.clone(),
                Err(_) => break,
            }
        }
    }
}

/// Extract outline + links. Errors only when the document cannot be loaded by `lopdf`.
pub fn extract_nav(bytes: &[u8], password: &str) -> Result<Nav, String> {
    let doc = if password.is_empty() {
        Document::load_mem(bytes)
    } else {
        Document::load_mem_with_options(bytes, lopdf::LoadOptions::with_password(password))
    }
    .map_err(|e| e.to_string())?;
    let pages = doc.get_pages();
    let page_index: HashMap<ObjectId, usize> = pages.iter().map(|(n, id)| (*id, (*n as usize).saturating_sub(1))).collect();
    let ctx = Ctx { doc: &doc, page_index };
    let mut links: Vec<Vec<Link>> = vec![Vec::new(); pages.len()];
    for (n, pid) in &pages {
        let idx = (*n as usize).saturating_sub(1);
        let Ok(annots) = doc.get_page_annotations(*pid) else { continue };
        for a in annots {
            if !matches!(a.get(b"Subtype"), Ok(Object::Name(n)) if n == b"Link") {
                continue;
            }
            let rect = match a.get(b"Rect").map(|o| ctx.deref(o)) {
                Ok(Object::Array(r)) if r.len() >= 4 => {
                    let v: Vec<f32> = r.iter().take(4).filter_map(|o| num(ctx.deref(o))).collect();
                    if v.len() == 4 { [v[0].min(v[2]), v[1].min(v[3]), v[0].max(v[2]), v[1].max(v[3])] } else { continue }
                }
                _ => continue,
            };
            if let Some(target) = ctx.link_target(a) {
                if let Some(slot) = links.get_mut(idx) {
                    slot.push(Link { rect, target });
                }
            }
        }
    }
    Ok(Nav { outline: ctx.outline(), links })
}
