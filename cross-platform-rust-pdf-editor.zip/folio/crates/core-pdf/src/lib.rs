//! `folio-core` – document model shared by every other crate.
//!
//! * Opening is delegated to `hayro-syntax` (lazy xref, no full object parse).
//! * Navigation data (outline, links) is extracted with `lopdf` *off* the hot path.
//! * Nothing in here panics on malformed input: every failure is an [`OpenError`] / `Result`.

use std::sync::Arc;

pub use hayro_syntax::Pdf;
use hayro_syntax::LoadPdfError;

mod nav;
pub mod sample;
mod textenc;

pub use nav::{Link, LinkTarget, Nav, OutlineItem, extract_nav};
pub use textenc::decode_pdf_text;

/// Why a document could not be opened.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OpenError {
    /// Encrypted and no password was supplied.
    NeedPassword,
    /// Encrypted and the supplied password was rejected.
    WrongPassword,
    /// Encrypted with an algorithm we do not support.
    Unsupported(String),
    /// Not a PDF, or too damaged to read.
    Invalid,
}

impl std::fmt::Display for OpenError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::NeedPassword => write!(f, "This document is password protected."),
            Self::WrongPassword => write!(f, "That password is not correct."),
            Self::Unsupported(s) => write!(f, "Unsupported encryption: {s}"),
            Self::Invalid => write!(f, "This file is not a valid PDF or is too damaged to open."),
        }
    }
}
impl std::error::Error for OpenError {}

/// Open a document from shared bytes. Pass `""` when no password is known.
pub fn open(bytes: Arc<Vec<u8>>, password: &str) -> Result<Pdf, OpenError> {
    if bytes.len() < 8 {
        return Err(OpenError::Invalid);
    }
    match Pdf::new_with_password(bytes, password) {
        Ok(p) => Ok(p),
        Err(LoadPdfError::Decryption(e)) => {
            let name = format!("{e:?}");
            if name.contains("PasswordProtected") {
                Err(if password.is_empty() { OpenError::NeedPassword } else { OpenError::WrongPassword })
            } else {
                Err(OpenError::Unsupported(name))
            }
        }
        Err(LoadPdfError::Invalid) => Err(OpenError::Invalid),
    }
}

/// Geometry of one page, in PDF points, *after* /Rotate and crop-box handling.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PageGeom {
    pub width: f32,
    pub height: f32,
    /// Affine mapping PDF user space → top-left-origin page space (a,b,c,d,e,f).
    pub transform: [f64; 6],
}

impl PageGeom {
    /// Map a point from PDF user space to page space (top-left origin, points).
    pub fn to_page(&self, x: f64, y: f64) -> (f32, f32) {
        let t = self.transform;
        ((t[0] * x + t[2] * y + t[4]) as f32, (t[1] * x + t[3] * y + t[5]) as f32)
    }
    /// Inverse of [`PageGeom::to_page`]: page space (top-left, points) → PDF user space.
    pub fn from_page(&self, x: f32, y: f32) -> (f32, f32) {
        let t = self.transform;
        let det = t[0] * t[3] - t[1] * t[2];
        if det.abs() < 1e-12 {
            return (x, y);
        }
        let (px, py) = (x as f64 - t[4], y as f64 - t[5]);
        (((t[3] * px - t[2] * py) / det) as f32, ((-t[1] * px + t[0] * py) / det) as f32)
    }
    /// Map a page-space rect to a normalised PDF-space rect.
    pub fn rect_from_page(&self, r: [f32; 4]) -> [f32; 4] {
        let a = self.from_page(r[0], r[1]);
        let b = self.from_page(r[2], r[3]);
        [a.0.min(b.0), a.1.min(b.1), a.0.max(b.0), a.1.max(b.1)]
    }
    /// Map a PDF-space rect `[x0,y0,x1,y1]` to a normalised page-space rect.
    pub fn rect_to_page(&self, r: [f32; 4]) -> [f32; 4] {
        let a = self.to_page(r[0] as f64, r[1] as f64);
        let b = self.to_page(r[2] as f64, r[3] as f64);
        [a.0.min(b.0), a.1.min(b.1), a.0.max(b.0), a.1.max(b.1)]
    }
}

#[derive(Debug, Clone, Default)]
pub struct Meta {
    pub title: Option<String>,
    pub author: Option<String>,
    pub subject: Option<String>,
    pub keywords: Option<String>,
    pub creator: Option<String>,
    pub producer: Option<String>,
}

/// Everything the UI needs to lay a document out. Cheap to build (page tree only).
#[derive(Debug, Clone, Default)]
pub struct DocInfo {
    pub pages: Vec<PageGeom>,
    pub meta: Meta,
    pub byte_len: usize,
}

pub fn read_meta(pdf: &Pdf) -> Meta {
    let m = pdf.metadata();
    let d = |v: &Option<Box<[u8]>>| v.as_deref().map(decode_pdf_text).filter(|s| !s.trim().is_empty());
    Meta {
        title: d(&m.title),
        author: d(&m.author),
        subject: d(&m.subject),
        keywords: d(&m.keywords),
        creator: d(&m.creator),
        producer: d(&m.producer),
    }
}

/// Sanitise a page size so layout never divides by zero or explodes.
pub fn sane_size(w: f32, h: f32) -> (f32, f32) {
    let ok = |v: f32| if v.is_finite() && v >= 1.0 { v.min(14_400.0) } else { 612.0 };
    (ok(w), ok(h))
}

/// Human readable byte size.
pub fn fmt_bytes(n: usize) -> String {
    const U: [&str; 4] = ["B", "KB", "MB", "GB"];
    let mut v = n as f64;
    let mut i = 0;
    while v >= 1024.0 && i < 3 {
        v /= 1024.0;
        i += 1;
    }
    if i == 0 { format!("{n} B") } else { format!("{v:.1} {}", U[i]) }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn opens_sample_and_rejects_garbage() {
        let bytes = sample::sample_pdf(3);
        let pdf = open(Arc::new(bytes), "").expect("sample opens");
        assert_eq!(pdf.pages().len(), 3);
        assert_eq!(open(Arc::new(b"definitely not a pdf at all".to_vec()), "").err(), Some(OpenError::Invalid));
        assert!(open(Arc::new(vec![]), "").is_err());
    }

    #[test]
    fn geom_roundtrip() {
        let g = PageGeom { width: 612.0, height: 792.0, transform: [1.0, 0.0, 0.0, -1.0, 0.0, 792.0] };
        let (x, y) = g.to_page(100.0, 700.0);
        assert_eq!((x, y), (100.0, 92.0));
        let (bx, by) = g.from_page(x, y);
        assert!((bx - 100.0).abs() < 1e-3 && (by - 700.0).abs() < 1e-3);
    }

    #[test]
    fn truncated_files_never_panic() {
        let bytes = sample::sample_pdf(4);
        for cut in (0..bytes.len()).step_by(37) {
            let _ = open(Arc::new(bytes[..cut].to_vec()), "");
        }
    }

    #[test]
    fn nav_has_outline_and_links() {
        let bytes = sample::sample_pdf(3);
        let nav = extract_nav(&bytes, "").unwrap();
        assert!(!nav.outline.is_empty());
        assert_eq!(nav.links.len(), 3);
        assert!(nav.links[0].iter().any(|l| matches!(l.target, LinkTarget::Page { index: 1, .. })));
        assert!(nav.links[0].iter().any(|l| matches!(l.target, LinkTarget::Uri(_))));
    }
}
