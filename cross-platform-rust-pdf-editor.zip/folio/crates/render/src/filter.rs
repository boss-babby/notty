/// Reading-mode colour filter applied to rendered tiles in the worker.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum Filter {
    #[default]
    None,
    /// Soft dark: inverted, slightly lifted blacks.
    Dark,
    /// Pure black background for OLED panels.
    Oled,
    /// Warm paper tint.
    Sepia,
}

impl Filter {
    pub fn apply(self, rgba: &mut [u8]) {
        match self {
            Filter::None => {}
            Filter::Dark => {
                for p in rgba.chunks_exact_mut(4) {
                    // invert, then map [0,255] → [20,236] so the page is not harshly black/white
                    for c in &mut p[..3] {
                        *c = 20 + ((255 - *c) as u32 * 216 / 255) as u8;
                    }
                }
            }
            Filter::Oled => {
                for p in rgba.chunks_exact_mut(4) {
                    for c in &mut p[..3] {
                        *c = ((255 - *c) as u32 * 235 / 255) as u8;
                    }
                }
            }
            Filter::Sepia => {
                for p in rgba.chunks_exact_mut(4) {
                    p[0] = (p[0] as u32 * 244 / 255) as u8;
                    p[1] = (p[1] as u32 * 232 / 255) as u8;
                    p[2] = (p[2] as u32 * 206 / 255) as u8;
                }
            }
        }
    }
}
