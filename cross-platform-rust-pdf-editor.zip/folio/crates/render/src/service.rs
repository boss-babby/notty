use crate::{Engine, Request, Response};

/// Handle to the render engine. Native: a worker thread. wasm32: cooperative, one job per `poll`.
pub struct Service {
    #[cfg(not(target_arch = "wasm32"))]
    tx: std::sync::mpsc::Sender<Request>,
    #[cfg(not(target_arch = "wasm32"))]
    rx: std::sync::mpsc::Receiver<Response>,
    #[cfg(target_arch = "wasm32")]
    engine: Engine,
    pending: usize,
}

impl Service {
    /// `wake` is called (from the worker) whenever a response is ready, e.g. `ctx.request_repaint()`.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn new(wake: impl Fn() + Send + Sync + 'static) -> Self {
        use std::sync::mpsc::{TryRecvError, channel};
        let (tx, wrx) = channel::<Request>();
        let (rtx, rx) = channel::<Response>();
        let _ = std::thread::Builder::new().name("folio-render".into()).stack_size(16 << 20).spawn(move || {
            let mut engine = Engine::new();
            loop {
                // Block while idle, otherwise drain everything queued so `Wanted` can cancel stale tiles.
                if !engine.has_work() {
                    match wrx.recv() {
                        Ok(r) => engine.push(r),
                        Err(_) => return,
                    }
                }
                loop {
                    match wrx.try_recv() {
                        Ok(r) => engine.push(r),
                        Err(TryRecvError::Empty) => break,
                        Err(TryRecvError::Disconnected) => return,
                    }
                }
                if let Some(resp) = engine.step() {
                    if rtx.send(resp).is_err() {
                        return;
                    }
                    wake();
                }
            }
        });
        Self { tx, rx, pending: 0 }
    }

    #[cfg(target_arch = "wasm32")]
    pub fn new(_wake: impl Fn() + Send + Sync + 'static) -> Self {
        Self { engine: Engine::new(), pending: 0 }
    }

    pub fn send(&mut self, req: Request) {
        #[cfg(not(target_arch = "wasm32"))]
        {
            let _ = self.tx.send(req);
        }
        #[cfg(target_arch = "wasm32")]
        {
            self.engine.push(req);
        }
    }

    /// Collect finished responses. On wasm this runs at most one job (bounded frame cost).
    pub fn poll(&mut self) -> Vec<Response> {
        #[cfg(not(target_arch = "wasm32"))]
        {
            let v: Vec<Response> = self.rx.try_iter().take(64).collect();
            self.pending = v.len();
            v
        }
        #[cfg(target_arch = "wasm32")]
        {
            let v: Vec<Response> = self.engine.step().into_iter().collect();
            self.pending = usize::from(self.engine.has_work());
            v
        }
    }

    /// wasm: true while more jobs are queued (caller should keep repainting).
    pub fn busy(&self) -> bool {
        #[cfg(target_arch = "wasm32")]
        {
            self.engine.has_work()
        }
        #[cfg(not(target_arch = "wasm32"))]
        {
            self.pending > 0
        }
    }

    /// Number of tiles still queued (debug overlay). Only meaningful on wasm32; native reports 0.
    pub fn queue_len(&self) -> usize {
        #[cfg(target_arch = "wasm32")]
        {
            self.engine.queue_len()
        }
        #[cfg(not(target_arch = "wasm32"))]
        {
            0
        }
    }
}
