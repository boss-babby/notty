use crate::{Filter, Request, Response, TILE, Tile, TileKey};
use folio_core::{DocInfo, OpenError, PageGeom, Pdf, sane_size};
use hayro::vello_cpu::color::palette::css::WHITE;
use hayro::vello_cpu::{Pixmap, RasterizerSettings, RenderContext, Resources, TargetInit};
use hayro::{RenderCache, RenderSettings, render_into};
use hayro_interpret::kurbo::Affine;
use hayro_interpret::util::TransformExt;
use hayro_interpret::{InterpreterCache, InterpreterSettings};
use std::collections::VecDeque;
use std::panic::{AssertUnwindSafe, catch_unwind};
use std::sync::Arc;

struct Caches<'a> {
    render: RenderCache<'a>,
    interp: InterpreterCache<'a>,
}

self_cell::self_cell!(
    struct Loaded {
        owner: Pdf,
        #[not_covariant]
        dependent: Caches,
    }
);

/// Synchronous job processor. One `step()` = one unit of work (open / one tile / one page of text).
pub struct Engine {
    epoch: u64,
    doc: Option<Loaded>,
    info: Option<Arc<DocInfo>>,
    open_req: Option<(u64, Arc<Vec<u8>>, String)>,
    wanted: VecDeque<TileKey>,
    text_q: VecDeque<u32>,
    png_q: VecDeque<(u32, u32, Filter)>,
    ctx: RenderContext,
    pixmap: Pixmap,
    resources: Resources,
}

impl Default for Engine {
    fn default() -> Self {
        Self::new()
    }
}

impl Engine {
    pub fn new() -> Self {
        Self {
            epoch: 0,
            doc: None,
            info: None,
            open_req: None,
            wanted: VecDeque::new(),
            text_q: VecDeque::new(),
            png_q: VecDeque::new(),
            ctx: RenderContext::new(1, 1),
            pixmap: Pixmap::new(1, 1),
            resources: Resources::default(),
        }
    }

    pub fn push(&mut self, req: Request) {
        match req {
            Request::Open { epoch, bytes, password } => {
                self.wanted.clear();
                self.text_q.clear();
                self.png_q.clear();
                self.doc = None;
                self.info = None;
                self.open_req = Some((epoch, bytes, password));
            }
            Request::Wanted(keys) => self.wanted = keys.into(),
            Request::Text(pages) => self.text_q = pages.into(),
            Request::Png { page, zoom_milli, filter } => self.png_q.push_back((page, zoom_milli, filter)),
            Request::Close => {
                self.doc = None;
                self.info = None;
                self.open_req = None;
                self.wanted.clear();
                self.text_q.clear();
            }
        }
    }

    pub fn has_work(&self) -> bool {
        self.open_req.is_some() || !self.wanted.is_empty() || !self.text_q.is_empty() || !self.png_q.is_empty()
    }

    pub fn queue_len(&self) -> usize {
        self.wanted.len() + self.text_q.len()
    }

    /// Run one job. Returns its response, if any. Never panics: panics inside PDF code are caught.
    pub fn step(&mut self) -> Option<Response> {
        if let Some((epoch, bytes, pw)) = self.open_req.take() {
            self.epoch = epoch;
            let r = catch_unwind(AssertUnwindSafe(|| Self::open(bytes, &pw))).unwrap_or(Err(OpenError::Invalid));
            return Some(match r {
                Ok((loaded, info)) => {
                    let info = Arc::new(info);
                    self.doc = Some(loaded);
                    self.info = Some(info.clone());
                    Response::Opened { epoch, result: Ok(info) }
                }
                Err(e) => Response::Opened { epoch, result: Err(e) },
            });
        }
        if let Some(key) = self.wanted.pop_front() {
            let r = catch_unwind(AssertUnwindSafe(|| self.render_tile(key))).ok().flatten();
            return Some(match r {
                Some(t) => Response::Tile(t),
                None => Response::TileFailed(key),
            });
        }
        if let Some((page, zoom, filter)) = self.png_q.pop_front() {
            let r = catch_unwind(AssertUnwindSafe(|| self.render_png(page, zoom, filter)))
                .unwrap_or_else(|_| Err("renderer panicked".into()));
            return Some(Response::Png { page, result: r });
        }
        if let Some(page) = self.text_q.pop_front() {
            let t = catch_unwind(AssertUnwindSafe(|| self.extract_text(page))).unwrap_or_default();
            return Some(Response::Text { page, text: Arc::new(t) });
        }
        None
    }

    fn open(bytes: Arc<Vec<u8>>, pw: &str) -> Result<(Loaded, DocInfo), OpenError> {
        let byte_len = bytes.len();
        let pdf = folio_core::open(bytes, pw)?;
        let meta = folio_core::read_meta(&pdf);
        let mut pages = Vec::with_capacity(pdf.pages().len());
        for p in pdf.pages().iter() {
            let (w, h) = p.render_dimensions();
            let (w, h) = sane_size(w, h);
            let c = p.initial_transform(true).to_kurbo().as_coeffs();
            pages.push(PageGeom { width: w, height: h, transform: c });
        }
        if pages.is_empty() {
            return Err(OpenError::Invalid);
        }
        let loaded = Loaded::new(pdf, |_| Caches { render: RenderCache::new(), interp: InterpreterCache::new() });
        Ok((loaded, DocInfo { pages, meta, byte_len }))
    }

    fn render_tile(&mut self, key: TileKey) -> Option<Tile> {
        let info = self.info.clone()?;
        let g = info.pages.get(key.page as usize)?;
        let (pw, ph) = key.page_px(g.width, g.height);
        let (ox, oy) = (key.col as u32 * TILE, key.row as u32 * TILE);
        if ox >= pw || oy >= ph || key.zoom_milli == 0 || key.zoom_milli > 16_000 {
            return None;
        }
        let (tw, th) = ((pw - ox).min(TILE), (ph - oy).min(TILE));
        let zoom = key.zoom() as f64;
        let pixmap = &mut self.pixmap;
        let ctx = &mut self.ctx;
        let resources = &mut self.resources;
        let doc = self.doc.as_ref()?;
        doc.with_dependent(|pdf, caches| {
            let page = pdf.pages().get(key.page as usize)?;
            let transform = Affine::translate((-(ox as f64), -(oy as f64)))
                * Affine::scale(zoom)
                * page.initial_transform(true).to_kurbo();
            ctx.reset_and_resize(tw as u16, th as u16);
            pixmap.resize(tw as u16, th as u16);
            render_into(page, &caches.render, &InterpreterSettings::default(), &RenderSettings::default(), ctx, transform);
            ctx.flush();
            ctx.render_with(
                pixmap,
                resources,
                RasterizerSettings { target_init: TargetInit::Clear(WHITE), ..Default::default() },
            );
            Some(())
        })?;
        let mut rgba = self.pixmap.data_as_u8_slice().to_vec();
        key.filter.apply(&mut rgba);
        Some(Tile { key, w: tw, h: th, rgba })
    }

    fn render_png(&mut self, page: u32, zoom_milli: u32, filter: Filter) -> Result<Vec<u8>, String> {
        let info = self.info.clone().ok_or("no document")?;
        let g = info.pages.get(page as usize).ok_or("page out of range")?;
        let zoom = (zoom_milli as f32 / 1000.0).clamp(0.1, 8.0);
        let (w, h) = ((g.width * zoom).ceil() as u32, (g.height * zoom).ceil() as u32);
        if w > 16_000 || h > 16_000 {
            return Err("page too large to export at this scale".into());
        }
        let doc = self.doc.as_ref().ok_or("no document")?;
        let mut ctx = RenderContext::new(w as u16, h as u16);
        let mut pixmap = Pixmap::new(w as u16, h as u16);
        let ok = doc.with_dependent(|pdf, caches| {
            let page = pdf.pages().get(page as usize)?;
            let transform = Affine::scale(zoom as f64) * page.initial_transform(true).to_kurbo();
            render_into(page, &caches.render, &InterpreterSettings::default(), &RenderSettings::default(), &mut ctx, transform);
            ctx.flush();
            ctx.render_with(
                &mut pixmap,
                &mut Resources::default(),
                RasterizerSettings { target_init: TargetInit::Clear(WHITE), ..Default::default() },
            );
            Some(())
        });
        ok.ok_or("render failed")?;
        if filter != Filter::None {
            // `data_as_u8_slice` is read-only; round-trip through PNG is avoided by encoding a filtered copy.
            let mut rgba = pixmap.data_as_u8_slice().to_vec();
            filter.apply(&mut rgba);
            return encode_png(w, h, &rgba);
        }
        pixmap.into_png().map_err(|e| format!("{e:?}"))
    }

    fn extract_text(&mut self, page: u32) -> folio_text::PageText {
        let Some(doc) = self.doc.as_ref() else { return Default::default() };
        doc.with_dependent(|pdf, caches| match pdf.pages().get(page as usize) {
            Some(p) => folio_text::extract_page(p, &caches.interp, InterpreterSettings::default()),
            None => Default::default(),
        })
    }
}

/// Minimal PNG encoder (stored deflate blocks) – avoids a dependency for the filtered-export path.
fn encode_png(w: u32, h: u32, rgba: &[u8]) -> Result<Vec<u8>, String> {
    fn crc(data: &[u8]) -> u32 {
        let mut c = 0xFFFF_FFFFu32;
        for &b in data {
            c ^= b as u32;
            for _ in 0..8 {
                c = if c & 1 != 0 { 0xEDB8_8320 ^ (c >> 1) } else { c >> 1 };
            }
        }
        !c
    }
    fn adler(data: &[u8]) -> u32 {
        let (mut a, mut b) = (1u32, 0u32);
        for &d in data {
            a = (a + d as u32) % 65521;
            b = (b + a) % 65521;
        }
        (b << 16) | a
    }
    fn chunk(out: &mut Vec<u8>, ty: &[u8; 4], data: &[u8]) {
        out.extend((data.len() as u32).to_be_bytes());
        let mut body = ty.to_vec();
        body.extend(data);
        out.extend(&body);
        out.extend(crc(&body).to_be_bytes());
    }
    let mut raw = Vec::with_capacity((w as usize * 4 + 1) * h as usize);
    for row in rgba.chunks(w as usize * 4) {
        raw.push(0);
        raw.extend(row);
    }
    let mut z = vec![0x78, 0x01];
    let mut chunks = raw.chunks(65535).peekable();
    while let Some(c) = chunks.next() {
        z.push(u8::from(chunks.peek().is_none()));
        z.extend((c.len() as u16).to_le_bytes());
        z.extend((!(c.len() as u16)).to_le_bytes());
        z.extend(c);
    }
    z.extend(adler(&raw).to_be_bytes());
    let mut out = vec![0x89, b'P', b'N', b'G', 0x0D, 0x0A, 0x1A, 0x0A];
    let mut ihdr = Vec::new();
    ihdr.extend(w.to_be_bytes());
    ihdr.extend(h.to_be_bytes());
    ihdr.extend([8, 6, 0, 0, 0]);
    chunk(&mut out, b"IHDR", &ihdr);
    chunk(&mut out, b"IDAT", &z);
    chunk(&mut out, b"IEND", &[]);
    Ok(out)
}
