//! `folio-render` – tile renderer and the off-UI-thread render service.
//!
//! * [`Engine`] is a *synchronous* job processor (open, render tile, extract text, export PNG).
//!   It owns the parsed document and all hayro caches, so nothing here needs to be `Send`.
//! * [`Service`] runs an `Engine` on a dedicated thread (native) or cooperatively, one job per
//!   frame (wasm32 – see ADR-0004 for the Web Worker follow-up). The UI only talks to the
//!   service through [`Request`] / [`Response`] messages and **never blocks on PDF work**.
//! * Stale work is cancelled by construction: `Request::Wanted` *replaces* the pending tile queue.

mod engine;
mod filter;
mod service;

pub use engine::Engine;
pub use filter::Filter;
pub use service::Service;

use folio_core::{DocInfo, OpenError};
use folio_text::PageText;
use std::sync::Arc;

/// Edge length of a render tile in device pixels.
pub const TILE: u32 = 512;

/// Identifies one tile of one page at one zoom level.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct TileKey {
    pub page: u32,
    /// Pixels per PDF point × 1000 (so 1.0 → 1000).
    pub zoom_milli: u32,
    pub col: u16,
    pub row: u16,
    pub filter: Filter,
    /// Document revision (bumped after every edit/re-open) so stale tiles are discarded.
    pub rev: u16,
}

impl TileKey {
    pub fn zoom(&self) -> f32 {
        self.zoom_milli as f32 / 1000.0
    }
    /// Page size in device pixels at this key's zoom.
    pub fn page_px(&self, w_pt: f32, h_pt: f32) -> (u32, u32) {
        (((w_pt * self.zoom()).ceil() as u32).max(1), ((h_pt * self.zoom()).ceil() as u32).max(1))
    }
}

/// A rendered tile: straight RGBA8.
pub struct Tile {
    pub key: TileKey,
    pub w: u32,
    pub h: u32,
    pub rgba: Vec<u8>,
}

pub enum Request {
    /// Open (or re-open) a document. `epoch` is echoed back so stale replies can be dropped.
    Open { epoch: u64, bytes: Arc<Vec<u8>>, password: String },
    /// The tiles the UI currently lacks, **highest priority first**. Replaces the pending queue.
    Wanted(Vec<TileKey>),
    /// Pages whose text layer is wanted, highest priority first. Replaces the pending queue.
    Text(Vec<u32>),
    /// Render a whole page to PNG (export).
    Png { page: u32, zoom_milli: u32, filter: Filter },
    Close,
}

pub enum Response {
    Opened { epoch: u64, result: Result<Arc<DocInfo>, OpenError> },
    Tile(Tile),
    TileFailed(TileKey),
    Text { page: u32, text: Arc<PageText> },
    Png { page: u32, result: Result<Vec<u8>, String> },
}

#[cfg(test)]
mod tests {
    use super::*;

    fn drain(e: &mut Engine) -> Vec<Response> {
        let mut v = Vec::new();
        while let Some(r) = e.step() {
            v.push(r);
        }
        v
    }

    #[test]
    fn open_render_text_png() {
        let bytes = Arc::new(folio_core::sample::sample_pdf(3));
        let mut e = Engine::new();
        e.push(Request::Open { epoch: 7, bytes, password: String::new() });
        let r = drain(&mut e);
        let Some(Response::Opened { epoch: 7, result: Ok(info) }) = r.into_iter().next() else { panic!("open failed") };
        assert_eq!(info.pages.len(), 3);
        assert!((info.pages[0].width - 612.0).abs() < 0.1);

        let key = TileKey { page: 0, zoom_milli: 1000, col: 0, row: 0, filter: Filter::None, rev: 0 };
        e.push(Request::Wanted(vec![key]));
        let r = drain(&mut e);
        let Some(Response::Tile(t)) = r.into_iter().next() else { panic!("no tile") };
        assert_eq!((t.w, t.h), (512, 512));
        // Page is white with dark text + a pale blue banner: must not be a blank tile.
        let dark = t.rgba.chunks(4).filter(|p| p[0] < 100).count();
        assert!(dark > 200, "text pixels missing: {dark}");

        e.push(Request::Text(vec![0]));
        let r = drain(&mut e);
        let Some(Response::Text { text, .. }) = r.into_iter().next() else { panic!("no text") };
        assert!(text.plain().contains("needle"));

        e.push(Request::Png { page: 1, zoom_milli: 500, filter: Filter::Dark });
        let r = drain(&mut e);
        let Some(Response::Png { result: Ok(png), .. }) = r.into_iter().next() else { panic!("no png") };
        assert_eq!(&png[1..4], b"PNG");
    }

    #[test]
    fn wanted_replaces_queue_and_edge_tiles_are_clipped() {
        let bytes = Arc::new(folio_core::sample::sample_pdf(1));
        let mut e = Engine::new();
        e.push(Request::Open { epoch: 1, bytes, password: String::new() });
        drain(&mut e);
        let k = |c, r| TileKey { page: 0, zoom_milli: 1000, col: c, row: r, filter: Filter::None, rev: 0 };
        e.push(Request::Wanted(vec![k(0, 0), k(1, 0), k(1, 1)]));
        e.push(Request::Wanted(vec![k(1, 1)])); // cancels the first two
        let r = drain(&mut e);
        assert_eq!(r.len(), 1);
        let Response::Tile(t) = &r[0] else { panic!() };
        assert_eq!((t.w, t.h), (612 - 512, 792 - 512));
    }

    #[test]
    fn bad_input_is_an_error_not_a_panic() {
        let mut e = Engine::new();
        e.push(Request::Open { epoch: 1, bytes: Arc::new(b"%PDF-1.7\nnot really".to_vec()), password: String::new() });
        let r = drain(&mut e);
        assert!(matches!(r[0], Response::Opened { result: Err(_), .. }));
        // rendering with nothing open is a no-op failure
        e.push(Request::Wanted(vec![TileKey { page: 0, zoom_milli: 1000, col: 0, row: 0, filter: Filter::None, rev: 0 }]));
        let r = drain(&mut e);
        assert!(r.iter().all(|x| matches!(x, Response::TileFailed(_))));
    }
}
