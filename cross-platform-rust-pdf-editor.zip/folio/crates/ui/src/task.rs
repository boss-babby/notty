//! Tiny cross-platform task helper: threads on native, `spawn_local` on wasm32.
use std::future::Future;

#[cfg(not(target_arch = "wasm32"))]
pub fn spawn_async<F: Future<Output = ()> + Send + 'static>(f: F) {
    let _ = std::thread::Builder::new().name("folio-task".into()).stack_size(32 << 20).spawn(move || pollster::block_on(f));
}

#[cfg(target_arch = "wasm32")]
pub fn spawn_async<F: Future<Output = ()> + 'static>(f: F) {
    wasm_bindgen_futures::spawn_local(f);
}

/// Monotonic-ish milliseconds (UTC wall clock where available).
pub fn now_ms() -> u64 {
    #[cfg(not(target_arch = "wasm32"))]
    {
        std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_millis() as u64).unwrap_or(0)
    }
    #[cfg(target_arch = "wasm32")]
    {
        js_sys::Date::now() as u64
    }
}

/// Resident set size in bytes (native only).
pub fn rss_bytes() -> Option<usize> {
    #[cfg(not(target_arch = "wasm32"))]
    {
        memory_stats::memory_stats().map(|m| m.physical_mem)
    }
    #[cfg(target_arch = "wasm32")]
    {
        None
    }
}

/// OS-level "reduce motion" preference (web: `prefers-reduced-motion`).
pub fn system_reduce_motion() -> bool {
    #[cfg(target_arch = "wasm32")]
    {
        web_sys::window()
            .and_then(|w| w.match_media("(prefers-reduced-motion: reduce)").ok().flatten())
            .is_some_and(|m| m.matches())
    }
    #[cfg(not(target_arch = "wasm32"))]
    {
        false
    }
}
