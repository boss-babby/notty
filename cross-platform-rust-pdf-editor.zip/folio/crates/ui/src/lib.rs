//! `folio-ui` – the one shared, responsive UI. Platform crates only construct [`FolioApp`].
mod app;
mod chrome;
mod cmds;
mod layout;
mod task;
mod tokens;
mod viewer;

pub use app::FolioApp;
pub use cmds::{Cmd, Tool};
pub use layout::{SizeClass, ZoomMode};
pub use tokens::Palette;

/// Window title used by all platform shells.
pub const APP_NAME: &str = "Folio";

/// Android `onTrimMemory` / iOS `didReceiveMemoryWarning` hook (called by the platform shells).
pub fn memory_warning(app: &mut FolioApp) {
    app.shrink_caches();
}
