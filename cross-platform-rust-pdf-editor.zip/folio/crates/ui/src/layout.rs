//! Window size classes and the page layout engine (continuous / single / two-page).
use egui::{Rect, Vec2, pos2, vec2};
use folio_core::PageGeom;
use folio_store::ViewMode;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SizeClass {
    /// < 600 dp: full-bleed page, bottom toolbar, bottom sheets.
    Compact,
    /// 600–840 dp: collapsible rail, floating contextual toolbar.
    Medium,
    /// > 840 dp: three panes, menu bar.
    Expanded,
}

impl SizeClass {
    pub fn from_width(dp: f32) -> Self {
        if dp < 600.0 { Self::Compact } else if dp <= 840.0 { Self::Medium } else { Self::Expanded }
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum ZoomMode {
    FitWidth,
    FitPage,
    Custom(f32),
}

pub const PAGE_GAP: f32 = 14.0;
pub const MARGIN: f32 = 16.0;

pub struct PageLayout {
    /// Page rectangles in content space (None = page not part of the current view).
    pub rects: Vec<Option<Rect>>,
    pub content: Vec2,
    /// Egui points per PDF point.
    pub scale: f32,
}

/// Groups of pages that share a row.
pub fn rows(n: usize, view: ViewMode, current: usize) -> Vec<Vec<usize>> {
    match view {
        ViewMode::Continuous => (0..n).map(|i| vec![i]).collect(),
        ViewMode::Single => vec![vec![current.min(n.saturating_sub(1))]],
        ViewMode::TwoPage => {
            let mut r = vec![vec![0]];
            let mut i = 1;
            while i < n {
                r.push((i..(i + 2).min(n)).collect());
                i += 2;
            }
            r
        }
    }
}

pub fn layout(pages: &[PageGeom], view: ViewMode, zoom: ZoomMode, viewport: Vec2, current: usize) -> PageLayout {
    let rows = rows(pages.len(), view, current);
    let row_w = |r: &Vec<usize>| r.iter().map(|&i| pages[i].width).sum::<f32>() + PAGE_GAP / 4.0 * (r.len().saturating_sub(1)) as f32;
    let row_h = |r: &Vec<usize>| r.iter().map(|&i| pages[i].height).fold(0.0, f32::max);
    let avail_w = (viewport.x - 2.0 * MARGIN).max(40.0);
    let avail_h = (viewport.y - 2.0 * MARGIN).max(40.0);
    let widest = rows.iter().map(row_w).fold(1.0, f32::max);
    let scale = match zoom {
        ZoomMode::FitWidth => avail_w / widest,
        ZoomMode::FitPage => {
            let cur = rows.iter().find(|r| r.contains(&current)).or(rows.first());
            cur.map_or(1.0, |r| (avail_w / row_w(r)).min(avail_h / row_h(r).max(1.0)))
        }
        ZoomMode::Custom(z) => z,
    }
    .clamp(0.05, 16.0);
    let mut rects = vec![None; pages.len()];
    let content_w = (widest * scale + 2.0 * MARGIN).max(viewport.x);
    let mut y = MARGIN;
    for r in &rows {
        let h = row_h(r) * scale;
        let w = row_w(r) * scale;
        let mut x = (content_w - w) / 2.0;
        for &i in r {
            let (pw, ph) = (pages[i].width * scale, pages[i].height * scale);
            // vertically centre pages of unequal height inside their row
            rects[i] = Some(Rect::from_min_size(pos2(x, y + (h - ph) / 2.0), vec2(pw, ph)));
            x += pw + PAGE_GAP / 4.0 * scale.max(1.0);
        }
        y += h + PAGE_GAP;
    }
    PageLayout { rects, content: vec2(content_w, (y - PAGE_GAP + MARGIN).max(viewport.y)), scale }
}

impl PageLayout {
    /// Page whose rect contains the vertical centre line `y` (content space), else the nearest.
    pub fn page_at_y(&self, y: f32) -> Option<usize> {
        let mut best = None;
        let mut best_d = f32::MAX;
        for (i, r) in self.rects.iter().enumerate() {
            if let Some(r) = r {
                let d = if y < r.min.y { r.min.y - y } else if y > r.max.y { y - r.max.y } else { 0.0 };
                if d < best_d {
                    best_d = d;
                    best = Some(i);
                }
            }
        }
        best
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pages(n: usize) -> Vec<PageGeom> {
        vec![PageGeom { width: 600.0, height: 800.0, transform: [1.0, 0.0, 0.0, -1.0, 0.0, 800.0] }; n]
    }

    #[test]
    fn size_classes() {
        assert_eq!(SizeClass::from_width(390.0), SizeClass::Compact);
        assert_eq!(SizeClass::from_width(700.0), SizeClass::Medium);
        assert_eq!(SizeClass::from_width(1280.0), SizeClass::Expanded);
    }

    #[test]
    fn fit_width_continuous() {
        let l = layout(&pages(3), ViewMode::Continuous, ZoomMode::FitWidth, vec2(632.0, 700.0), 0);
        assert!((l.scale - 1.0).abs() < 1e-4);
        let r1 = l.rects[1].unwrap();
        assert!((r1.min.y - (MARGIN + 800.0 + PAGE_GAP)).abs() < 1e-3);
        assert_eq!(l.page_at_y(r1.center().y), Some(1));
    }

    #[test]
    fn two_page_and_single() {
        let l = layout(&pages(4), ViewMode::TwoPage, ZoomMode::FitWidth, vec2(1000.0, 700.0), 0);
        // cover page alone, then spread (1,2), then (3)
        assert_eq!(l.rects[1].unwrap().min.y, l.rects[2].unwrap().min.y);
        assert!(l.rects[3].unwrap().min.y > l.rects[2].unwrap().min.y);
        let s = layout(&pages(4), ViewMode::Single, ZoomMode::FitPage, vec2(500.0, 500.0), 2);
        assert!(s.rects[0].is_none() && s.rects[2].is_some());
        assert!(s.rects[2].unwrap().height() <= 500.0);
    }
}
