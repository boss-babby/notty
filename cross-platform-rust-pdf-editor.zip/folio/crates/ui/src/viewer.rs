//! The document canvas: layout, scroll/zoom physics, tile scheduling, painting, gestures, annotation tools.
use crate::app::*;
use crate::cmds::{Cmd, Tool};
use crate::layout::{MARGIN, ZoomMode, layout};
use egui::{Color32, Context, CursorIcon, Painter, Pos2, Rect, Response, Sense, Shape, Stroke, Ui, Vec2, pos2, vec2};
use folio_core::{DocInfo, LinkTarget, PageGeom};
use folio_edit::AnnotSpec;
use folio_render::{Filter, Request, TILE, TileKey};
use folio_store::ViewMode;
use std::collections::HashSet;
use std::sync::Arc;

pub enum Action {
    Annot(usize, AnnotSpec),
    Toast(String),
    Url(String),
    Dialog(Dialog),
    Run(Cmd),
}

struct VisPage {
    i: usize,
    prect: Rect,
    preview: TileKey,
    tiles: Vec<TileKey>,
}

pub fn preview_key(page: usize, g: &PageGeom, filter: Filter, rev: u16) -> TileKey {
    let z = (0.5f32).min(480.0 / g.width.max(g.height));
    TileKey { page: page as u32, zoom_milli: ((z * 1000.0) as u32).max(10), col: 0, row: 0, filter, rev }
}

fn snap(r: Rect, ppp: f32) -> Rect {
    let s = |v: f32| (v * ppp).round() / ppp;
    Rect::from_min_max(pos2(s(r.min.x), s(r.min.y)), pos2(s(r.max.x), s(r.max.y)))
}

fn to_screen(prect: Rect, g: &PageGeom, r: [f32; 4]) -> Rect {
    let s = prect.width() / g.width;
    Rect::from_min_max(prect.min + vec2(r[0], r[1]) * s, prect.min + vec2(r[2], r[3]) * s)
}

fn rgb(c: [f32; 3]) -> Color32 {
    Color32::from_rgb((c[0] * 255.0) as u8, (c[1] * 255.0) as u8, (c[2] * 255.0) as u8)
}

impl FolioApp {
    pub fn viewer(&mut self, ui: &mut Ui) {
        let ctx = ui.ctx().clone();
        let avail = ui.available_size();
        let (resp, painter) = ui.allocate_painter(avail, Sense::click_and_drag());
        let vr = resp.rect;
        painter.rect_filled(vr, 0.0, self.palette.canvas);
        let Some(mut d) = self.doc.take() else { return };
        let mut actions: Vec<Action> = Vec::new();
        match d.info.clone() {
            Some(info) => self.viewer_doc(&ctx, &resp, &painter, vr, &mut d, &info, &mut actions),
            None => {
                painter.text(vr.center(), egui::Align2::CENTER_CENTER, format!("Opening {}…", d.name), egui::FontId::proportional(16.0), self.palette.text_dim);
                ctx.request_repaint();
            }
        }
        self.doc = Some(d);
        for a in actions {
            match a {
                Action::Annot(p, s) => self.add_annotation(p, s),
                Action::Toast(t) => self.toast(&ctx, t),
                Action::Url(u) => ctx.open_url(egui::OpenUrl::new_tab(u)),
                Action::Dialog(dlg) => self.dialog = Some(dlg),
                Action::Run(c) => self.run(&ctx, c),
            }
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn viewer_doc(&mut self, ctx: &Context, resp: &Response, painter: &Painter, vr: Rect, d: &mut DocState, info: &Arc<DocInfo>, actions: &mut Vec<Action>) {
        let view = self.lib.settings.view_mode;
        let ppp = ctx.pixels_per_point();
        let dt = ctx.input(|i| i.stable_dt).clamp(0.001, 0.1);
        let n = info.pages.len();

        // ── layout, jumps ──
        let mut lay = layout(&info.pages, view, d.zoom, vr.size(), d.page);
        if let Some((p, y)) = d.jump.take() {
            d.page = p.min(n - 1);
            lay = layout(&info.pages, view, d.zoom, vr.size(), d.page);
            if let Some(r) = lay.rects[d.page] {
                let off = y.map(|y| (y * lay.scale - 48.0).max(0.0)).unwrap_or(0.0);
                d.scroll = vec2(0.0, r.min.y - MARGIN + off);
            }
            d.velocity = Vec2::ZERO;
        }

        // ── input: scroll, pinch / ctrl-wheel zoom (anchored), keyboard, momentum ──
        let (sd, zd, typing) = ctx.input(|i| (i.smooth_scroll_delta(), i.zoom_delta(), false));
        let typing = typing || ctx.egui_wants_keyboard_input();
        if resp.hovered() {
            d.scroll -= sd;
            if sd.length() > 0.0 {
                d.velocity = Vec2::ZERO;
            }
            if (zd - 1.0).abs() > 1e-3 {
                let old = lay.scale;
                let new = (old * zd).clamp(0.1, 12.0);
                let anchor = ctx.input(|i| i.pointer.hover_pos()).unwrap_or(vr.center()) - vr.min;
                let content_pt = (d.scroll + anchor) / old;
                d.zoom = ZoomMode::Custom(new);
                d.scroll = content_pt * new - anchor;
                lay = layout(&info.pages, view, d.zoom, vr.size(), d.page);
            }
        }
        if !typing && self.dialog.is_none() {
            let step = ctx.input(|i| {
                let mut v = Vec2::ZERO;
                if i.key_pressed(egui::Key::ArrowDown) { v.y += 80.0; }
                if i.key_pressed(egui::Key::ArrowUp) { v.y -= 80.0; }
                if i.key_pressed(egui::Key::ArrowRight) { v.x += 80.0; }
                if i.key_pressed(egui::Key::ArrowLeft) { v.x -= 80.0; }
                if i.key_pressed(egui::Key::Space) { v.y += if i.modifiers.shift { -vr.height() * 0.9 } else { vr.height() * 0.9 }; }
                v
            });
            d.scroll += step;
        }
        if d.drag.is_none() && d.velocity.length() > 12.0 {
            d.scroll += d.velocity * dt;
            d.velocity *= (1.0 - 4.5 * dt).max(0.0);
            ctx.request_repaint();
        } else if d.drag.is_none() {
            d.velocity = Vec2::ZERO;
        }
        let max = (lay.content - vr.size()).max(Vec2::ZERO);
        d.scroll = vec2(d.scroll.x.clamp(0.0, max.x), d.scroll.y.clamp(0.0, max.y));
        d.scale = lay.scale;
        if view != ViewMode::Single {
            if let Some(p) = lay.page_at_y(d.scroll.y + vr.height() * 0.35) {
                d.page = p;
            }
        }

        // ── tile scheduling ──
        let filter = self.filter();
        let rev = (self.epoch & 0xFFFF) as u16;
        let rz = ((lay.scale * ppp * 8.0).round() / 8.0).clamp(0.125, 16.0);
        let zm = (rz * 1000.0).round() as u32;
        let view_c = Rect::from_min_size(d.scroll.to_pos2(), vr.size());
        let ext = TILE as f32 / ppp * 0.6;
        let center = view_c.center();
        let mut vis: Vec<VisPage> = Vec::new();
        let mut sharp: Vec<(f32, TileKey)> = Vec::new();
        let mut previews: Vec<(f32, TileKey)> = Vec::new();
        let mut pinned: HashSet<TileKey> = HashSet::new();
        for (i, r) in lay.rects.iter().enumerate() {
            let Some(r) = *r else { continue };
            if !r.intersects(view_c.expand(ext)) {
                continue;
            }
            let g = &info.pages[i];
            let pk = preview_key(i, g, filter, rev);
            pinned.insert(pk);
            previews.push(((r.center().y - center.y).abs(), pk));
            let (pw, ph) = (((g.width * rz).ceil() as u32).max(1), ((g.height * rz).ceil() as u32).max(1));
            let mut keys = Vec::new();
            let area = r.intersect(view_c.expand(ext));
            if area.is_positive() {
                let fx = |x: f32| (x - r.min.x) / r.width() * pw as f32;
                let fy = |y: f32| (y - r.min.y) / r.height() * ph as f32;
                let c0 = (fx(area.min.x) / TILE as f32).floor().max(0.0) as u32;
                let c1 = ((fx(area.max.x) / TILE as f32).floor().max(0.0) as u32).min((pw - 1) / TILE);
                let r0 = (fy(area.min.y) / TILE as f32).floor().max(0.0) as u32;
                let r1 = ((fy(area.max.y) / TILE as f32).floor().max(0.0) as u32).min((ph - 1) / TILE);
                for row in r0..=r1 {
                    for col in c0..=c1 {
                        let k = TileKey { page: i as u32, zoom_milli: zm, col: col as u16, row: row as u16, filter, rev };
                        let tc = pos2(r.min.x + (col * TILE + TILE / 2) as f32 / pw as f32 * r.width(), r.min.y + (row * TILE + TILE / 2) as f32 / ph as f32 * r.height());
                        sharp.push((tc.distance(center), k));
                        pinned.insert(k);
                        keys.push(k);
                    }
                }
            }
            let prect = snap(r.translate(vr.min.to_vec2() - d.scroll), ppp);
            vis.push(VisPage { i, prect, preview: pk, tiles: keys });
        }
        previews.sort_by(|a, b| a.0.total_cmp(&b.0));
        sharp.sort_by(|a, b| a.0.total_cmp(&b.0));
        let mut wanted: Vec<TileKey> = Vec::new();
        let missing = |d: &DocState, k: &TileKey| d.tiles.peek(k).is_none() && !d.failed.contains(k);
        for (_, k) in previews.iter().chain(sharp.iter()) {
            if missing(d, k) && !wanted.contains(k) {
                wanted.push(*k);
            }
        }
        for p in std::mem::take(&mut d.thumb_want) {
            if let Some(g) = info.pages.get(p as usize) {
                let k = preview_key(p as usize, g, filter, rev);
                pinned.insert(k);
                if missing(d, &k) && !wanted.contains(&k) {
                    wanted.push(k);
                }
            }
        }
        wanted.truncate(48);
        if wanted != d.last_wanted {
            self.service.send(Request::Wanted(wanted.clone()));
            d.last_wanted = wanted;
        }
        d.tiles.enforce(|k| pinned.contains(k));

        // text layer for visible pages (selection, search, copy)
        let mut need_text = false;
        for v in &vis {
            if !d.texts.contains_key(&(v.i as u32)) && d.text_requested.insert(v.i as u32) {
                need_text = true;
            }
        }
        if need_text {
            let mut order: Vec<u32> = vis.iter().map(|v| v.i as u32).filter(|p| !d.texts.contains_key(p)).collect();
            let mut rest: Vec<u32> = d.text_requested.iter().copied().filter(|p| !d.texts.contains_key(p) && !order.contains(p)).collect();
            rest.sort_unstable();
            order.extend(rest);
            self.service.send(Request::Text(order));
        }

        // ── paint pages ──
        for v in &vis {
            painter.rect_filled(v.prect.translate(vec2(0.0, 2.0)).expand(1.0), 2.0, Color32::from_black_alpha(if self.palette.dark { 90 } else { 34 }));
            painter.rect_filled(v.prect, 0.0, self.palette.paper);
            let uv = Rect::from_min_max(pos2(0.0, 0.0), pos2(1.0, 1.0));
            if let Some(t) = d.tiles.get(&v.preview) {
                painter.image(t.id(), v.prect, uv, Color32::WHITE);
            }
            let g = &info.pages[v.i];
            let (pw, ph) = (((g.width * rz).ceil() as f32).max(1.0), ((g.height * rz).ceil() as f32).max(1.0));
            for k in &v.tiles {
                if let Some(t) = d.tiles.get(k) {
                    let (x0, y0) = (k.col as f32 * TILE as f32, k.row as f32 * TILE as f32);
                    let sz = t.size_vec2();
                    let tr = Rect::from_min_max(
                        v.prect.min + vec2(x0 / pw * v.prect.width(), y0 / ph * v.prect.height()),
                        v.prect.min + vec2((x0 + sz.x) / pw * v.prect.width(), (y0 + sz.y) / ph * v.prect.height()),
                    );
                    painter.image(t.id(), snap(tr, ppp), uv, Color32::WHITE);
                }
            }
            if self.lib.is_bookmarked(&d.key, v.i as u32) {
                let p = v.prect.right_top() + vec2(-26.0, 0.0);
                painter.add(Shape::convex_polygon(vec![p, p + vec2(16.0, 0.0), p + vec2(16.0, 26.0), p + vec2(8.0, 20.0), p + vec2(0.0, 26.0)], self.palette.accent, Stroke::NONE));
            }
            // search hits
            if let Some(hits) = d.search.by_page.get(&(v.i as u32)) {
                let before: usize = d.search.by_page.range(..(v.i as u32)).map(|(_, h)| h.len()).sum();
                for (hi, h) in hits.iter().enumerate() {
                    let cur = before + hi == d.search.current;
                    for r in &h.rects {
                        painter.rect_filled(to_screen(v.prect, g, *r).expand(1.0), 2.0, if cur { Color32::from_rgba_unmultiplied(255, 140, 0, 130) } else { Color32::from_rgba_unmultiplied(255, 220, 0, 90) });
                    }
                }
            }
            // selection
            if let (Some(s), Some(t)) = (d.sel, d.texts.get(&(v.i as u32))) {
                if s.page == v.i {
                    for r in t.rects_for(s.a.min(s.b), s.a.max(s.b) + 1) {
                        painter.rect_filled(to_screen(v.prect, g, r), 1.0, self.palette.accent.gamma_multiply(0.35));
                    }
                }
            }
        }

        // ── links (hover + click) ──
        let ptr = ctx.input(|i| i.pointer.hover_pos()).filter(|p| vr.contains(*p));
        let mut hover_link: Option<LinkTarget> = None;
        if let (Some(nav), Some(p)) = (d.nav.clone(), ptr) {
            if matches!(self.tool, Tool::Select | Tool::Hand) {
                for v in &vis {
                    if !v.prect.contains(p) {
                        continue;
                    }
                    let g = &info.pages[v.i];
                    for l in nav.links.get(v.i).into_iter().flatten() {
                        if to_screen(v.prect, g, g.rect_to_page(l.rect)).contains(p) {
                            hover_link = Some(l.target.clone());
                        }
                    }
                }
            }
        }
        if hover_link.is_some() {
            ctx.set_cursor_icon(CursorIcon::PointingHand);
        } else if resp.hovered() {
            ctx.set_cursor_icon(match self.tool {
                Tool::Select => CursorIcon::Text,
                Tool::Hand => if d.drag.is_some() { CursorIcon::Grabbing } else { CursorIcon::Grab },
                _ => CursorIcon::Crosshair,
            });
        }

        // ── gestures ──
        let press = ctx.input(|i| i.pointer.press_origin());
        let page_at = |p: Pos2| vis.iter().find(|v| v.prect.contains(p));
        let to_page = |v: &VisPage, p: Pos2| -> Pos2 {
            let g = &info.pages[v.i];
            let s = g.width / v.prect.width();
            pos2((p.x - v.prect.min.x) * s, (p.y - v.prect.min.y) * s)
        };
        if resp.drag_started() {
            if let Some(p) = press {
                let on = page_at(p);
                let pan = matches!(self.tool, Tool::Hand) || (self.touch_seen && self.tool == Tool::Select) || on.is_none();
                let mode = if pan { DragMode::Pan } else {
                    match self.tool {
                        Tool::Select | Tool::Highlight | Tool::Underline | Tool::Strike => DragMode::Text,
                        Tool::Ink => DragMode::Ink,
                        _ => DragMode::Rubber,
                    }
                };
                let (page, start) = on.map_or((d.page, Pos2::ZERO), |v| (v.i, to_page(v, p)));
                let anchor = if mode == DragMode::Text { d.texts.get(&(page as u32)).and_then(|t| t.char_at(start.x, start.y)) } else { None };
                d.sel = None;
                d.drag = Some(Drag { page, mode, start, cur: start, pts: vec![start], force_sum: 0.0, force_n: 0, anchor_char: anchor });
            }
        }
        if resp.dragged() {
            let cur = ctx.input(|i| i.pointer.interact_pos());
            let force = ctx.input(|i| i.events.iter().rev().find_map(|e| if let egui::Event::Touch { force: Some(f), .. } = e { Some(*f) } else { None }));
            let delta = resp.drag_delta();
            if let Some(dr) = d.drag.as_mut() {
                match dr.mode {
                    DragMode::Pan => {
                        d.scroll -= delta;
                        d.velocity = d.velocity * 0.6 + (-delta / dt) * 0.4;
                    }
                    _ => {
                        if let (Some(c), Some(v)) = (cur, vis.iter().find(|v| v.i == dr.page)) {
                            dr.cur = to_page(v, c);
                            if dr.mode == DragMode::Ink {
                                dr.pts.push(dr.cur);
                                if let Some(f) = force {
                                    dr.force_sum += f;
                                    dr.force_n += 1;
                                }
                            }
                            if dr.mode == DragMode::Text {
                                if let (Some(a), Some(t)) = (dr.anchor_char, d.texts.get(&(dr.page as u32))) {
                                    if let Some(b) = t.char_at(dr.cur.x, dr.cur.y) {
                                        d.sel = Some(Selection { page: dr.page, a, b });
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        // in-progress shapes
        if let Some(dr) = d.drag.as_ref() {
            if let Some(v) = vis.iter().find(|v| v.i == dr.page) {
                let g = &info.pages[v.i];
                let s = v.prect.width() / g.width;
                let col = if self.tool == Tool::Redact { Color32::BLACK } else { rgb(self.ann_color) };
                match dr.mode {
                    DragMode::Ink => {
                        let pts: Vec<Pos2> = dr.pts.iter().map(|p| v.prect.min + p.to_vec2() * s).collect();
                        painter.add(Shape::line(pts, Stroke::new(self.ink_width * s, col)));
                    }
                    DragMode::Rubber => {
                        let r = Rect::from_two_pos(dr.start, dr.cur);
                        let sr = to_screen(v.prect, g, [r.min.x, r.min.y, r.max.x, r.max.y]);
                        match self.tool {
                            Tool::Ellipse => {
                                let (c, rad) = (sr.center(), sr.size() / 2.0);
                                let pts: Vec<Pos2> = (0..48).map(|k| { let a = k as f32 / 48.0 * std::f32::consts::TAU; c + vec2(a.cos() * rad.x, a.sin() * rad.y) }).collect();
                                painter.add(Shape::closed_line(pts, Stroke::new(self.ink_width * s, col)));
                            }
                            Tool::Redact => { painter.rect_filled(sr, 0.0, Color32::BLACK); }
                            _ => { painter.rect_stroke(sr, 0.0, Stroke::new(2.0, if self.tool == Tool::Image || self.tool == Tool::TextBox || self.tool == Tool::Stamp { self.palette.accent } else { col }), egui::StrokeKind::Inside); }
                        }
                    }
                    _ => {}
                }
            }
        }
        if resp.drag_stopped() {
            if let Some(dr) = d.drag.take() {
                self.finish_drag(d, info, dr, actions);
            }
        }
        if resp.clicked() {
            if let Some(p) = ctx.input(|i| i.pointer.interact_pos()) {
                if let Some(t) = hover_link.clone() {
                    match t {
                        LinkTarget::Page { index, y } => d.jump = Some((index.min(n - 1), y.map(|y| { let g = &info.pages[index.min(n - 1)]; g.to_page(0.0, y as f64).1 }))),
                        LinkTarget::Uri(u) => actions.push(Action::Url(u)),
                    }
                } else if let Some(v) = page_at(p) {
                    let pg = to_page(v, p);
                    let g = &info.pages[v.i];
                    match self.tool {
                        Tool::Note => {
                            let (x, y) = g.from_page(pg.x, pg.y);
                            actions.push(Action::Dialog(Dialog::Text { note: true, page: v.i, pos: pos2(x, y), rect: None, input: String::new() }));
                        }
                        Tool::Stamp => {
                            let r = g.rect_from_page([pg.x - 80.0, pg.y - 22.0, pg.x + 80.0, pg.y + 22.0]);
                            actions.push(Action::Annot(v.i, AnnotSpec::Stamp { rect: r, label: self.stamp_label.clone(), color: [0.1, 0.55, 0.25] }));
                        }
                        _ => d.sel = None,
                    }
                }
            }
        }
        if resp.double_clicked() && matches!(self.tool, Tool::Select | Tool::Hand) {
            d.zoom = if matches!(d.zoom, ZoomMode::FitWidth) { ZoomMode::Custom((lay.scale * 2.0).min(8.0)) } else { ZoomMode::FitWidth };
        }

        // selection toolbar
        if let (Some(s), true) = (d.sel, d.drag.is_none() && self.tool == Tool::Select) {
            if let (Some(t), Some(v)) = (d.texts.get(&(s.page as u32)), vis.iter().find(|v| v.i == s.page)) {
                let rects = t.rects_for(s.a.min(s.b), s.a.max(s.b) + 1);
                if let Some(first) = rects.first() {
                    let g = &info.pages[v.i];
                    let anchor = to_screen(v.prect, g, *first);
                    let pos = pos2(anchor.min.x.clamp(vr.min.x + 4.0, (vr.max.x - 300.0).max(vr.min.x)), (anchor.min.y - 52.0).max(vr.min.y + 4.0));
                    let quads: Vec<[f32; 4]> = rects.iter().map(|r| g.rect_from_page(*r)).collect();
                    egui::Area::new(egui::Id::new("selbar")).fixed_pos(pos).order(egui::Order::Foreground).show(ctx, |ui| {
                        egui::Frame::popup(ui.style()).show(ui, |ui| {
                            ui.horizontal(|ui| {
                                if ui.button("Copy").clicked() { actions.push(Action::Run(Cmd::Copy)); }
                                if ui.button("🖍 Highlight").clicked() { actions.push(Action::Annot(s.page, AnnotSpec::Highlight { quads: quads.clone(), color: self.ann_color })); d.sel = None; }
                                if ui.button("Underline").clicked() { actions.push(Action::Annot(s.page, AnnotSpec::Underline { quads: quads.clone(), color: [0.9, 0.1, 0.1] })); d.sel = None; }
                                if ui.button("Strike").clicked() { actions.push(Action::Annot(s.page, AnnotSpec::StrikeOut { quads: quads.clone(), color: [0.9, 0.1, 0.1] })); d.sel = None; }
                            });
                        });
                    });
                }
            }
        }

        // accessibility: expose the page + its text to screen readers
        let label = {
            let t = d.texts.get(&(d.page as u32)).map(|t| t.plain()).unwrap_or_default();
            let t: String = t.chars().take(400).collect();
            format!("{}, page {} of {}. {}", d.name, d.page + 1, n, t)
        };
        resp.widget_info(|| egui::WidgetInfo::labeled(egui::WidgetType::Document, true, label.clone()));

        // floating page pill
        let pill = format!("{} / {}", d.page + 1, n);
        let galley = painter.layout_no_wrap(pill, egui::FontId::proportional(13.0), self.palette.text);
        let pr = Rect::from_min_size(pos2(vr.right() - galley.size().x - 28.0, vr.bottom() - galley.size().y - 24.0), galley.size() + vec2(16.0, 8.0));
        painter.rect_filled(pr, 12.0, self.palette.surface.gamma_multiply(0.92));
        painter.galley(pr.min + vec2(8.0, 4.0), galley, self.palette.text);

        if self.lib.settings.show_debug {
            self.debug_overlay(painter, vr, d, vis.len());
        }
        ctx.request_repaint_after(std::time::Duration::from_millis(250));
    }

    fn finish_drag(&mut self, d: &mut DocState, info: &Arc<DocInfo>, dr: Drag, actions: &mut Vec<Action>) {
        let g = info.pages[dr.page.min(info.pages.len() - 1)];
        match dr.mode {
            DragMode::Pan => {}
            DragMode::Text => {
                if matches!(self.tool, Tool::Highlight | Tool::Underline | Tool::Strike) {
                    if let (Some(s), Some(t)) = (d.sel, d.texts.get(&(dr.page as u32))) {
                        let quads: Vec<[f32; 4]> = t.rects_for(s.a.min(s.b), s.a.max(s.b) + 1).iter().map(|r| g.rect_from_page(*r)).collect();
                        if !quads.is_empty() {
                            let spec = match self.tool {
                                Tool::Highlight => AnnotSpec::Highlight { quads, color: self.ann_color },
                                Tool::Underline => AnnotSpec::Underline { quads, color: [0.9, 0.1, 0.1] },
                                _ => AnnotSpec::StrikeOut { quads, color: [0.9, 0.1, 0.1] },
                            };
                            actions.push(Action::Annot(dr.page, spec));
                            d.sel = None;
                        }
                    }
                }
            }
            DragMode::Ink => {
                let pts: Vec<(f32, f32)> = dr.pts.iter().map(|p| g.from_page(p.x, p.y)).collect();
                let w = if dr.force_n > 0 { self.ink_width * (0.4 + 1.2 * dr.force_sum / dr.force_n as f32) } else { self.ink_width };
                if pts.len() >= 2 {
                    actions.push(Action::Annot(dr.page, AnnotSpec::Ink { strokes: vec![pts], width: w, color: self.ann_color }));
                }
            }
            DragMode::Rubber => {
                let r = Rect::from_two_pos(dr.start, dr.cur);
                if r.width() < 4.0 || r.height() < 4.0 {
                    return;
                }
                let pr = g.rect_from_page([r.min.x, r.min.y, r.max.x, r.max.y]);
                match self.tool {
                    Tool::Rect => actions.push(Action::Annot(dr.page, AnnotSpec::Square { rect: pr, color: self.ann_color, width: self.ink_width })),
                    Tool::Ellipse => actions.push(Action::Annot(dr.page, AnnotSpec::Circle { rect: pr, color: self.ann_color, width: self.ink_width })),
                    Tool::Redact => actions.push(Action::Annot(dr.page, AnnotSpec::Redact { rect: pr })),
                    Tool::Stamp => actions.push(Action::Annot(dr.page, AnnotSpec::Stamp { rect: pr, label: self.stamp_label.clone(), color: [0.1, 0.55, 0.25] })),
                    Tool::TextBox => actions.push(Action::Dialog(Dialog::Text { note: false, page: dr.page, pos: pos2(pr[0], pr[3]), rect: Some(pr), input: String::new() })),
                    Tool::Image => match d.pending_image.clone() {
                        Some(bytes) => actions.push(Action::Annot(dr.page, AnnotSpec::Image { rect: pr, bytes })),
                        None => actions.push(Action::Run(Cmd::PlaceImage)),
                    },
                    _ => {}
                }
            }
        }
    }

    fn debug_overlay(&self, painter: &Painter, vr: Rect, d: &DocState, vis_pages: usize) {
        let mb = |b: usize| format!("{:.1} MB", b as f64 / 1_048_576.0);
        let rss = crate::task::rss_bytes().map_or("n/a (web)".to_owned(), mb);
        let text = format!(
            "fps {:.0}   frame {:.1} ms\nRSS {rss}\ntile cache {} / {}   ({} tiles)\ncache hit rate {:.0}%\nrender queue {} (+{} in flight)\nvisible pages {vis_pages}   zoom ×{:.2}\ntext layers {}",
            self.stats.fps, self.stats.frame_ms, mb(d.tiles.used()), mb(d.tiles.budget()), d.tiles.len(), d.tiles.hit_rate() * 100.0,
            self.service.queue_len(), d.last_wanted.len(), d.scale, d.texts.len(),
        );
        let g = painter.layout(text, egui::FontId::monospace(11.5), Color32::from_rgb(0xC8, 0xFF, 0xC8), 320.0);
        let r = Rect::from_min_size(vr.min + vec2(10.0, 10.0), g.size() + vec2(16.0, 12.0));
        painter.rect_filled(r, 8.0, Color32::from_black_alpha(200));
        painter.galley(r.min + vec2(8.0, 6.0), g, Color32::WHITE);
    }
}
