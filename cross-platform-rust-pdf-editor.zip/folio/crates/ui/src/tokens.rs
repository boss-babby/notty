//! Design tokens – the single source of truth for colour, type, spacing, radius, elevation, motion.
use egui::{Color32, Context, FontId, Stroke, Visuals};
use folio_store::ReadingMode;

// ── spacing: 4/8 grid ─────────────────────────────────────────────────────────
pub const S1: f32 = 4.0;
pub const S2: f32 = 8.0;
pub const S3: f32 = 12.0;
pub const S4: f32 = 16.0;
pub const S6: f32 = 24.0;
pub const S8: f32 = 32.0;
/// Minimum touch target (dp).
pub const TOUCH: f32 = 44.0;

// ── radius ────────────────────────────────────────────────────────────────────
pub const R_SM: u8 = 6;
pub const R_MD: u8 = 10;
pub const R_LG: u8 = 16;

// ── type scale (dp, before the user's font scale) ─────────────────────────────
pub const T_CAPTION: f32 = 11.5;
pub const T_BODY: f32 = 14.0;
pub const T_LABEL: f32 = 13.0;
pub const T_TITLE: f32 = 18.0;
pub const T_HEADLINE: f32 = 26.0;

// ── motion ────────────────────────────────────────────────────────────────────
/// All UI transitions are shorter than 250 ms; 0 when "reduce motion" is on.
pub const MOTION_FAST: f32 = 0.12;
pub const MOTION_BASE: f32 = 0.2;

// ── elevation (shadow alpha) ──────────────────────────────────────────────────
pub const ELEV_1: u8 = 28;
pub const ELEV_2: u8 = 56;

#[derive(Clone, Copy, Debug)]
pub struct Palette {
    pub dark: bool,
    /// App background behind pages.
    pub canvas: Color32,
    /// Panels / toolbars.
    pub surface: Color32,
    pub surface_alt: Color32,
    pub text: Color32,
    pub text_dim: Color32,
    pub accent: Color32,
    pub on_accent: Color32,
    pub border: Color32,
    /// Paper colour used under tiles while they load.
    pub paper: Color32,
    pub danger: Color32,
}

const fn c(r: u8, g: u8, b: u8) -> Color32 {
    Color32::from_rgb(r, g, b)
}

impl Palette {
    pub fn for_mode(m: ReadingMode) -> Self {
        match m {
            ReadingMode::Light => Self {
                dark: false, canvas: c(0xE9, 0xEA, 0xEE), surface: c(0xFA, 0xFA, 0xFB), surface_alt: c(0xF0, 0xF1, 0xF4),
                text: c(0x16, 0x18, 0x1D), text_dim: c(0x55, 0x5B, 0x68), accent: c(0x2F, 0x5B, 0xD6), on_accent: c(0xFF, 0xFF, 0xFF),
                border: c(0xD3, 0xD6, 0xDD), paper: c(0xFF, 0xFF, 0xFF), danger: c(0xB4, 0x23, 0x18),
            },
            ReadingMode::Sepia => Self {
                dark: false, canvas: c(0xD9, 0xCF, 0xB8), surface: c(0xF4, 0xEC, 0xD8), surface_alt: c(0xEB, 0xE0, 0xC6),
                text: c(0x2B, 0x22, 0x14), text_dim: c(0x66, 0x57, 0x3D), accent: c(0x8A, 0x4B, 0x12), on_accent: c(0xFF, 0xFA, 0xEE),
                border: c(0xCF, 0xC2, 0xA2), paper: c(0xF4, 0xE8, 0xCE), danger: c(0xA3, 0x1D, 0x14),
            },
            ReadingMode::Dark => Self {
                dark: true, canvas: c(0x12, 0x13, 0x16), surface: c(0x1C, 0x1E, 0x23), surface_alt: c(0x25, 0x28, 0x2F),
                text: c(0xEC, 0xEE, 0xF2), text_dim: c(0xA3, 0xA9, 0xB6), accent: c(0x8D, 0xAE, 0xFF), on_accent: c(0x0B, 0x13, 0x2B),
                border: c(0x37, 0x3B, 0x45), paper: c(0x14, 0x14, 0x14), danger: c(0xFF, 0x8A, 0x80),
            },
            ReadingMode::Oled => Self {
                dark: true, canvas: c(0, 0, 0), surface: c(0x0A, 0x0A, 0x0B), surface_alt: c(0x15, 0x16, 0x18),
                text: c(0xF2, 0xF3, 0xF5), text_dim: c(0xA8, 0xAE, 0xBA), accent: c(0x8D, 0xAE, 0xFF), on_accent: c(0x0B, 0x13, 0x2B),
                border: c(0x2A, 0x2D, 0x33), paper: c(0, 0, 0), danger: c(0xFF, 0x8A, 0x80),
            },
        }
    }
}

/// WCAG relative luminance contrast ratio.
pub fn contrast(a: Color32, b: Color32) -> f32 {
    fn lin(v: u8) -> f32 {
        let s = v as f32 / 255.0;
        if s <= 0.03928 { s / 12.92 } else { ((s + 0.055) / 1.055).powf(2.4) }
    }
    fn lum(c: Color32) -> f32 {
        0.2126 * lin(c.r()) + 0.7152 * lin(c.g()) + 0.0722 * lin(c.b())
    }
    let (la, lb) = (lum(a), lum(b));
    (la.max(lb) + 0.05) / (la.min(lb) + 0.05)
}

/// Push tokens into egui's style.
pub fn apply(ctx: &Context, p: &Palette, reduce_motion: bool) {
    let mut v = if p.dark { Visuals::dark() } else { Visuals::light() };
    v.panel_fill = p.surface;
    v.window_fill = p.surface;
    v.extreme_bg_color = p.surface_alt;
    v.faint_bg_color = p.surface_alt;
    v.override_text_color = Some(p.text);
    v.hyperlink_color = p.accent;
    v.selection.bg_fill = p.accent.gamma_multiply(0.35);
    v.selection.stroke = Stroke::new(1.0, p.accent);
    v.window_stroke = Stroke::new(1.0, p.border);
    v.window_corner_radius = egui::CornerRadius::same(R_LG);
    v.menu_corner_radius = egui::CornerRadius::same(R_MD);
    v.window_shadow = egui::Shadow { offset: [0, 6], blur: 24, spread: 0, color: Color32::from_black_alpha(ELEV_2) };
    v.popup_shadow = egui::Shadow { offset: [0, 4], blur: 16, spread: 0, color: Color32::from_black_alpha(ELEV_1) };
    let w = &mut v.widgets;
    for (wv, fill) in [
        (&mut w.noninteractive, p.surface),
        (&mut w.inactive, p.surface_alt),
        (&mut w.hovered, p.surface_alt.gamma_multiply(0.92)),
        (&mut w.active, p.accent.gamma_multiply(0.25)),
        (&mut w.open, p.surface_alt),
    ] {
        wv.bg_fill = fill;
        wv.weak_bg_fill = fill;
        wv.corner_radius = egui::CornerRadius::same(R_SM);
        wv.fg_stroke = Stroke::new(1.0, p.text);
        wv.bg_stroke = Stroke::new(1.0, p.border);
    }
    w.hovered.bg_stroke = Stroke::new(1.0, p.accent);
    ctx.set_visuals(v);
    ctx.all_styles_mut(|s| {
        s.animation_time = if reduce_motion { 0.0 } else { MOTION_FAST };
        s.spacing.item_spacing = egui::vec2(S2, S2);
        s.spacing.button_padding = egui::vec2(S3, S2);
        s.spacing.interact_size.y = 32.0;
        s.spacing.icon_width = 20.0;
        use egui::TextStyle::*;
        s.text_styles.insert(Body, FontId::proportional(T_BODY));
        s.text_styles.insert(Button, FontId::proportional(T_LABEL));
        s.text_styles.insert(Small, FontId::proportional(T_CAPTION));
        s.text_styles.insert(Heading, FontId::proportional(T_TITLE));
        s.text_styles.insert(Monospace, FontId::monospace(T_LABEL));
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_theme_meets_wcag_aa() {
        for m in [ReadingMode::Light, ReadingMode::Sepia, ReadingMode::Dark, ReadingMode::Oled] {
            let p = Palette::for_mode(m);
            for (name, fg, bg) in [
                ("text/surface", p.text, p.surface),
                ("text/surface_alt", p.text, p.surface_alt),
                ("text/canvas", p.text, p.canvas),
                ("dim/surface", p.text_dim, p.surface),
                ("dim/surface_alt", p.text_dim, p.surface_alt),
                ("accent/surface", p.accent, p.surface),
                ("on_accent/accent", p.on_accent, p.accent),
                ("danger/surface", p.danger, p.surface),
            ] {
                let r = contrast(fg, bg);
                assert!(r >= 4.5, "{m:?} {name}: contrast {r:.2} < 4.5");
            }
        }
    }
}
