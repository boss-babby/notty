//! Commands: one enum drives menus, the command palette, toolbars and keyboard shortcuts.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Cmd {
    Open, OpenSample, Save, SaveAs, CloseDoc, Undo, Redo, Copy,
    Find, FindNext, FindPrev, GoToPage, Palette,
    ZoomIn, ZoomOut, FitWidth, FitPage, Zoom100,
    ViewContinuous, ViewSingle, ViewTwoPage,
    ModeLight, ModeSepia, ModeDark, ModeOled,
    ToggleSidebar, ToggleInspector, Bookmark, Debug, ReduceMotion, FontBigger, FontSmaller,
    NextPage, PrevPage, FirstPage, LastPage,
    RotateCw, RotateCcw, DeletePage, InsertBlank, InsertImagePage, MovePageUp, MovePageDown,
    Merge, ExtractPages, SplitDoc, Compress, Protect, Unlock, ExportPng, Flatten, ApplyRedactions,
    Properties, FillForms, PlaceImage, About,
}

impl Cmd {
    pub const ALL: &'static [Cmd] = &[
        Cmd::Open, Cmd::OpenSample, Cmd::Save, Cmd::SaveAs, Cmd::CloseDoc, Cmd::Undo, Cmd::Redo, Cmd::Copy,
        Cmd::Find, Cmd::FindNext, Cmd::FindPrev, Cmd::GoToPage,
        Cmd::ZoomIn, Cmd::ZoomOut, Cmd::FitWidth, Cmd::FitPage, Cmd::Zoom100,
        Cmd::ViewContinuous, Cmd::ViewSingle, Cmd::ViewTwoPage,
        Cmd::ModeLight, Cmd::ModeSepia, Cmd::ModeDark, Cmd::ModeOled,
        Cmd::ToggleSidebar, Cmd::ToggleInspector, Cmd::Bookmark, Cmd::Debug, Cmd::ReduceMotion, Cmd::FontBigger, Cmd::FontSmaller,
        Cmd::NextPage, Cmd::PrevPage, Cmd::FirstPage, Cmd::LastPage,
        Cmd::RotateCw, Cmd::RotateCcw, Cmd::DeletePage, Cmd::InsertBlank, Cmd::InsertImagePage, Cmd::MovePageUp, Cmd::MovePageDown,
        Cmd::Merge, Cmd::ExtractPages, Cmd::SplitDoc, Cmd::Compress, Cmd::Protect, Cmd::Unlock, Cmd::ExportPng,
        Cmd::Flatten, Cmd::ApplyRedactions, Cmd::Properties, Cmd::FillForms, Cmd::PlaceImage, Cmd::About,
    ];

    pub fn label(self) -> &'static str {
        use Cmd::*;
        match self {
            Open => "Open PDF…", OpenSample => "Open sample document", Save => "Save", SaveAs => "Save a copy…", CloseDoc => "Close document",
            Undo => "Undo", Redo => "Redo", Copy => "Copy selected text",
            Find => "Find in document", FindNext => "Find next", FindPrev => "Find previous", GoToPage => "Go to page…", Palette => "Command palette",
            ZoomIn => "Zoom in", ZoomOut => "Zoom out", FitWidth => "Fit width", FitPage => "Fit page", Zoom100 => "Actual size (100%)",
            ViewContinuous => "View: continuous scroll", ViewSingle => "View: single page", ViewTwoPage => "View: two pages",
            ModeLight => "Reading mode: light", ModeSepia => "Reading mode: sepia", ModeDark => "Reading mode: dark", ModeOled => "Reading mode: OLED black",
            ToggleSidebar => "Toggle sidebar", ToggleInspector => "Toggle inspector", Bookmark => "Toggle bookmark on this page", Debug => "Toggle debug overlay",
            ReduceMotion => "Toggle reduce motion", FontBigger => "Larger interface text", FontSmaller => "Smaller interface text",
            NextPage => "Next page", PrevPage => "Previous page", FirstPage => "First page", LastPage => "Last page",
            RotateCw => "Rotate page clockwise", RotateCcw => "Rotate page counter-clockwise", DeletePage => "Delete this page",
            InsertBlank => "Insert blank page after this one", InsertImagePage => "Insert image as new page…",
            MovePageUp => "Move page up", MovePageDown => "Move page down",
            Merge => "Merge with another PDF…", ExtractPages => "Extract pages…", SplitDoc => "Split document…", Compress => "Compress and save a copy…",
            Protect => "Protect with password…", Unlock => "Remove password and save a copy…", ExportPng => "Export this page as PNG…",
            Flatten => "Flatten annotations and forms", ApplyRedactions => "Apply redactions (remove content permanently)",
            Properties => "Document properties…", FillForms => "Fill form fields…", PlaceImage => "Place image / signature…", About => "About Folio",
        }
    }

    /// Shortcut hint; `cmd` is "⌘" on macOS and "Ctrl+" elsewhere.
    pub fn shortcut(self, cmd: &str) -> Option<String> {
        use Cmd::*;
        let s = match self {
            Open => "O", Save => "S", Undo => "Z", Copy => "C", Find => "F", GoToPage => "G", Palette => "K", Bookmark => "D",
            ZoomIn => "+", ZoomOut => "−", Zoom100 => "0", FindNext => "G", ToggleSidebar => "B",
            _ => return None,
        };
        Some(format!("{cmd}{s}"))
    }

    pub fn needs_doc(self) -> bool {
        !matches!(self, Cmd::Open | Cmd::OpenSample | Cmd::Palette | Cmd::About | Cmd::Debug | Cmd::ReduceMotion | Cmd::FontBigger | Cmd::FontSmaller
            | Cmd::ModeLight | Cmd::ModeSepia | Cmd::ModeDark | Cmd::ModeOled | Cmd::ViewContinuous | Cmd::ViewSingle | Cmd::ViewTwoPage)
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Tool {
    Select, Hand, Highlight, Underline, Strike, Ink, Note, Rect, Ellipse, Stamp, TextBox, Image, Redact,
}

impl Tool {
    pub const ALL: &'static [Tool] = &[
        Tool::Select, Tool::Hand, Tool::Highlight, Tool::Underline, Tool::Strike, Tool::Ink, Tool::Note,
        Tool::Rect, Tool::Ellipse, Tool::Stamp, Tool::TextBox, Tool::Image, Tool::Redact,
    ];
    pub fn label(self) -> &'static str {
        match self {
            Tool::Select => "Select", Tool::Hand => "Pan", Tool::Highlight => "Highlight", Tool::Underline => "Underline", Tool::Strike => "Strikeout",
            Tool::Ink => "Draw", Tool::Note => "Note", Tool::Rect => "Rectangle", Tool::Ellipse => "Ellipse", Tool::Stamp => "Stamp",
            Tool::TextBox => "Text box", Tool::Image => "Image", Tool::Redact => "Redact",
        }
    }
    pub fn glyph(self) -> &'static str {
        match self {
            Tool::Select => "↖", Tool::Hand => "✋", Tool::Highlight => "🖍", Tool::Underline => "U̲", Tool::Strike => "S̶",
            Tool::Ink => "✏", Tool::Note => "🗒", Tool::Rect => "▭", Tool::Ellipse => "◯", Tool::Stamp => "✔",
            Tool::TextBox => "T", Tool::Image => "🖼", Tool::Redact => "▇",
        }
    }
    pub fn edits(self) -> bool {
        !matches!(self, Tool::Select | Tool::Hand)
    }
}
