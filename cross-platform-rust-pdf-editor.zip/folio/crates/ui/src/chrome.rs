//! Chrome: adaptive panels by window size class, menus, toolbars, sidebar, inspector, dialogs, palette.
use crate::app::*;
use crate::cmds::{Cmd, Tool};
use crate::layout::SizeClass;
use crate::tokens::{self, TOUCH};
use egui::{Align, Align2, Color32, Context, Frame, Layout, RichText, Sense, Ui, vec2};
use folio_edit::AnnotSpec;
use folio_store::{ReadingMode, ViewMode};
use std::sync::Arc;

const SWATCHES: [([f32; 3], &str); 7] = [
    ([1.0, 0.92, 0.0], "Yellow"),
    ([0.45, 0.9, 0.35], "Green"),
    ([0.35, 0.8, 1.0], "Cyan"),
    ([1.0, 0.5, 0.75], "Pink"),
    ([1.0, 0.6, 0.1], "Orange"),
    ([0.9, 0.1, 0.1], "Red"),
    ([0.1, 0.2, 0.9], "Blue"),
];
const STAMPS: [&str; 5] = ["Approved", "Draft", "Confidential", "Reviewed", "Void"];

type BarAction = Box<dyn Fn(&mut FolioApp, &Context)>;

impl eframe::App for FolioApp {
    fn ui(&mut self, ui: &mut Ui, _frame: &mut eframe::Frame) {
        let ctx = ui.ctx().clone();
        self.begin_frame(&ctx);
        self.draw(ui, &ctx);
    }

    fn save(&mut self, storage: &mut dyn eframe::Storage) {
        if let Some(d) = &self.doc {
            let (n, s, p) = (d.name.clone(), d.bytes.len() as u64, d.page as u32);
            self.lib.set_last_page(&n, s, p);
        }
        storage.set_string(STORAGE_KEY, self.lib.to_json());
    }

    fn clear_color(&self, _v: &egui::Visuals) -> [f32; 4] {
        self.palette.canvas.to_normalized_gamma_f32()
    }
}

impl FolioApp {
    fn touch_h(&self) -> f32 {
        if self.class == SizeClass::Expanded && !self.touch_seen { 30.0 } else { TOUCH }
    }

    fn btn(&self, ui: &mut Ui, text: impl Into<String>, enabled: bool) -> bool {
        let b = egui::Button::new(text.into()).min_size(vec2(0.0, self.touch_h()));
        ui.add_enabled(enabled, b).clicked()
    }

    fn draw(&mut self, ui: &mut Ui, ctx: &Context) {
        let t = ctx.input(|i| i.time);
        let has_doc = self.doc.is_some();
        let auto_hide = self.class != SizeClass::Expanded && has_doc;
        let visible = !auto_hide || self.sheet.is_some() || t - self.last_active < 3.0 || self.dialog.is_some() || self.palette_open;
        if auto_hide {
            ctx.request_repaint_after(std::time::Duration::from_millis(500));
        }
        if !has_doc {
            if self.class == SizeClass::Expanded {
                egui::Panel::top("menu").show_inside(ui, |ui| self.menu_bar(ui, ctx));
            }
            egui::CentralPanel::default().show_inside(ui, |ui| self.welcome(ui, ctx));
        } else {
            match self.class {
                SizeClass::Expanded => {
                    egui::Panel::top("menu").show_inside(ui, |ui| self.menu_bar(ui, ctx));
                    egui::Panel::top("toolbar").show_inside(ui, |ui| self.toolbar(ui, ctx, true));
                    egui::Panel::bottom("status").show_inside(ui, |ui| self.status_bar(ui));
                    if self.sidebar_open {
                        egui::Panel::left("sidebar").default_size(264.0).size_range(200.0..=420.0).resizable(true).show_inside(ui, |ui| self.sidebar(ui));
                    }
                    if self.inspector_open {
                        egui::Panel::right("inspector").default_size(284.0).size_range(220.0..=420.0).resizable(true).show_inside(ui, |ui| {
                            egui::ScrollArea::vertical().show(ui, |ui| self.inspector(ui, ctx));
                        });
                    }
                }
                SizeClass::Medium => {
                    egui::Panel::top("toolbar").show_animated_inside(ui, visible, |ui| {
                        egui::ScrollArea::horizontal().show(ui, |ui| self.toolbar(ui, ctx, false));
                    });
                    if self.sidebar_open {
                        egui::Panel::left("sidebar").default_size(232.0).size_range(180.0..=320.0).resizable(true).show_inside(ui, |ui| self.sidebar(ui));
                    }
                }
                SizeClass::Compact => {
                    egui::Panel::top("title").show_animated_inside(ui, visible, |ui| {
                        ui.horizontal(|ui| {
                            let name = self.doc.as_ref().map(|d| d.name.clone()).unwrap_or_default();
                            ui.label(RichText::new(name).strong());
                            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                                let (cu, cr) = self.doc.as_ref().map_or((false, false), |d| (d.can_undo, d.can_redo));
                                if self.btn(ui, "↷", cr) {
                                    self.run(ctx, Cmd::Redo);
                                }
                                if self.btn(ui, "↶", cu) {
                                    self.run(ctx, Cmd::Undo);
                                }
                            });
                        });
                    });
                    egui::Panel::bottom("bottombar").show_animated_inside(ui, visible, |ui| self.bottom_bar(ui, ctx));
                    if let Some(sheet) = self.sheet {
                        let h = ctx.content_rect().height() * 0.45;
                        egui::Panel::bottom("sheet").default_size(h).size_range(160.0..=h * 1.6).resizable(true).show_inside(ui, |ui| {
                            ui.horizontal(|ui| {
                                ui.label(RichText::new(match sheet {
                                    Sheet::Nav => "Navigate",
                                    Sheet::Tools => "Tools",
                                    Sheet::View => "View",
                                }).strong());
                                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                                    if self.btn(ui, "✖ Close", true) {
                                        self.sheet = None;
                                    }
                                });
                            });
                            egui::ScrollArea::vertical().show(ui, |ui| match sheet {
                                Sheet::Nav => self.sidebar(ui),
                                Sheet::Tools => {
                                    self.tool_grid(ui);
                                    self.inspector(ui, ctx);
                                }
                                Sheet::View => self.view_options(ui, ctx),
                            });
                        });
                    }
                }
            }
            egui::CentralPanel::default().frame(Frame::NONE).show_inside(ui, |ui| self.viewer(ui));
        }
        self.dialogs(ctx);
        self.command_palette(ctx);
        self.toast_ui(ctx, t);
    }

    // ───────────────────────── menus & toolbars ─────────────────────────

    fn menu_item(&self, ui: &mut Ui, ctx: &Context, cmd: Cmd, todo: &mut Option<Cmd>) {
        let enabled = !cmd.needs_doc() || self.doc.as_ref().is_some_and(|d| d.info.is_some());
        let mut b = egui::Button::new(cmd.label());
        if let Some(s) = cmd.shortcut(self.mods_label(ctx)) {
            b = b.shortcut_text(s);
        }
        if ui.add_enabled(enabled, b).clicked() {
            *todo = Some(cmd);
            ui.close();
        }
    }

    fn menu_group(&self, ui: &mut Ui, ctx: &Context, title: &str, cmds: &[Cmd], todo: &mut Option<Cmd>) {
        ui.menu_button(title, |ui| {
            for &c in cmds {
                self.menu_item(ui, ctx, c, todo);
            }
        });
    }

    fn menu_bar(&mut self, ui: &mut Ui, ctx: &Context) {
        let mut todo = None;
        egui::MenuBar::new().ui(ui, |ui| {
            self.menu_group(ui, ctx, "File", &[Cmd::Open, Cmd::OpenSample, Cmd::Save, Cmd::SaveAs, Cmd::ExportPng, Cmd::CloseDoc], &mut todo);
            self.menu_group(ui, ctx, "Edit", &[Cmd::Undo, Cmd::Redo, Cmd::Copy, Cmd::Find, Cmd::FindNext, Cmd::FindPrev, Cmd::GoToPage, Cmd::Bookmark], &mut todo);
            self.menu_group(ui, ctx, "View", &[
                Cmd::ZoomIn, Cmd::ZoomOut, Cmd::FitWidth, Cmd::FitPage, Cmd::Zoom100, Cmd::ViewContinuous, Cmd::ViewSingle, Cmd::ViewTwoPage,
                Cmd::ModeLight, Cmd::ModeSepia, Cmd::ModeDark, Cmd::ModeOled, Cmd::ToggleSidebar, Cmd::ToggleInspector,
                Cmd::FontBigger, Cmd::FontSmaller, Cmd::ReduceMotion, Cmd::Debug,
            ], &mut todo);
            self.menu_group(ui, ctx, "Pages", &[
                Cmd::RotateCw, Cmd::RotateCcw, Cmd::DeletePage, Cmd::InsertBlank, Cmd::InsertImagePage, Cmd::MovePageUp, Cmd::MovePageDown,
                Cmd::ExtractPages, Cmd::SplitDoc, Cmd::Merge,
            ], &mut todo);
            self.menu_group(ui, ctx, "Document", &[
                Cmd::Properties, Cmd::FillForms, Cmd::PlaceImage, Cmd::Flatten, Cmd::ApplyRedactions, Cmd::Compress, Cmd::Protect, Cmd::Unlock,
            ], &mut todo);
            self.menu_group(ui, ctx, "Help", &[Cmd::Palette, Cmd::About], &mut todo);
        });
        if let Some(c) = todo {
            self.run(ctx, c);
        }
    }

    fn toolbar(&mut self, ui: &mut Ui, ctx: &Context, wide: bool) {
        let (cu, cr, dirty, ul, rl) = self
            .doc
            .as_ref()
            .map_or((false, false, false, None, None), |d| (d.can_undo, d.can_redo, d.dirty, d.undo_label.clone(), d.redo_label.clone()));
        ui.horizontal(|ui| {
            if self.btn(ui, "☰", true) {
                self.run(ctx, Cmd::ToggleSidebar);
            }
            if self.btn(ui, "📂", true) {
                self.run(ctx, Cmd::Open);
            }
            if self.btn(ui, if dirty { "💾 Save•" } else { "💾 Save" }, true) {
                self.run(ctx, Cmd::Save);
            }
            if ui.add_enabled(cu, egui::Button::new("↶").min_size(vec2(0.0, self.touch_h()))).on_hover_text(ul.map_or("Undo".to_owned(), |l| format!("Undo {l}"))).clicked() {
                self.run(ctx, Cmd::Undo);
            }
            if ui.add_enabled(cr, egui::Button::new("↷").min_size(vec2(0.0, self.touch_h()))).on_hover_text(rl.map_or("Redo".to_owned(), |l| format!("Redo {l}"))).clicked() {
                self.run(ctx, Cmd::Redo);
            }
            ui.separator();
            for &t in Tool::ALL {
                let label = if wide { format!("{} {}", t.glyph(), t.label()) } else { t.glyph().to_owned() };
                let b = egui::Button::new(label).selected(self.tool == t).min_size(vec2(0.0, self.touch_h()));
                if ui.add(b).on_hover_text(t.label()).clicked() {
                    self.tool = t;
                    if t == Tool::Image && self.doc.as_ref().is_some_and(|d| d.pending_image.is_none()) {
                        self.run(ctx, Cmd::PlaceImage);
                    }
                }
            }
            ui.separator();
            if self.btn(ui, "−", true) {
                self.run(ctx, Cmd::ZoomOut);
            }
            if self.btn(ui, "+", true) {
                self.run(ctx, Cmd::ZoomIn);
            }
            if self.btn(ui, "Fit", true) {
                self.run(ctx, Cmd::FitWidth);
            }
            if self.btn(ui, "🔍", true) {
                self.run(ctx, Cmd::Find);
            }
            if self.btn(ui, "Commands", true) {
                self.run(ctx, Cmd::Palette);
            }
        });
    }

    fn status_bar(&mut self, ui: &mut Ui) {
        let Some(d) = self.doc.as_ref() else { return };
        let (n, size) = d.info.as_ref().map_or((0, 0), |i| (i.pages.len(), i.byte_len));
        ui.horizontal(|ui| {
            ui.label(RichText::new(format!("Page {} / {}", d.page + 1, n)).color(self.palette.text_dim));
            ui.separator();
            ui.label(RichText::new(format!("{:.0}%", d.scale * 100.0)).color(self.palette.text_dim));
            ui.separator();
            ui.label(RichText::new(folio_core::fmt_bytes(size)).color(self.palette.text_dim));
            ui.separator();
            let state = if d.edit_busy { "Applying edit…" } else if d.dirty { "Unsaved changes" } else { "No changes" };
            ui.label(RichText::new(state).color(self.palette.text_dim));
        });
    }

    fn bottom_bar(&mut self, ui: &mut Ui, ctx: &Context) {
        ui.columns(5, |c| {
            let items: [(&str, BarAction); 5] = [
                ("☰ Pages", Box::new(|a, _| a.sheet = if a.sheet == Some(Sheet::Nav) { None } else { Some(Sheet::Nav) })),
                ("🔍 Find", Box::new(|a, ctx| a.run(ctx, Cmd::Find))),
                ("✏ Tools", Box::new(|a, _| a.sheet = if a.sheet == Some(Sheet::Tools) { None } else { Some(Sheet::Tools) })),
                ("◐ View", Box::new(|a, _| a.sheet = if a.sheet == Some(Sheet::View) { None } else { Some(Sheet::View) })),
                ("⋯ More", Box::new(|a, ctx| a.run(ctx, Cmd::Palette))),
            ];
            for (i, (label, f)) in items.into_iter().enumerate() {
                c[i].vertical_centered(|ui| {
                    if ui.add(egui::Button::new(label).min_size(vec2(ui.available_width(), TOUCH))).clicked() {
                        f(self, ctx);
                    }
                });
            }
        });
    }

    fn tool_grid(&mut self, ui: &mut Ui) {
        ui.horizontal_wrapped(|ui| {
            for &t in Tool::ALL {
                let b = egui::Button::new(format!("{} {}", t.glyph(), t.label())).selected(self.tool == t).min_size(vec2(0.0, TOUCH));
                if ui.add(b).clicked() {
                    self.tool = t;
                }
            }
        });
    }

    fn view_options(&mut self, ui: &mut Ui, ctx: &Context) {
        ui.label(RichText::new("Layout").strong());
        ui.horizontal_wrapped(|ui| {
            for (m, l) in [(ViewMode::Continuous, "Continuous"), (ViewMode::Single, "Single page"), (ViewMode::TwoPage, "Two pages")] {
                if ui.add(egui::Button::new(l).selected(self.lib.settings.view_mode == m).min_size(vec2(0.0, TOUCH))).clicked() {
                    self.set_view(m);
                }
            }
        });
        ui.label(RichText::new("Reading mode").strong());
        ui.horizontal_wrapped(|ui| {
            for (m, l) in [(ReadingMode::Light, "Light"), (ReadingMode::Sepia, "Sepia"), (ReadingMode::Dark, "Dark"), (ReadingMode::Oled, "OLED")] {
                if ui.add(egui::Button::new(l).selected(self.lib.settings.reading_mode == m).min_size(vec2(0.0, TOUCH))).clicked() {
                    self.set_mode(m);
                }
            }
        });
        ui.label(RichText::new("Zoom").strong());
        ui.horizontal_wrapped(|ui| {
            for (c, l) in [(Cmd::ZoomOut, "−"), (Cmd::ZoomIn, "+"), (Cmd::FitWidth, "Fit width"), (Cmd::FitPage, "Fit page"), (Cmd::Zoom100, "100%")] {
                if self.btn(ui, l, true) {
                    self.run(ctx, c);
                }
            }
        });
        ui.label(RichText::new("Interface").strong());
        ui.horizontal_wrapped(|ui| {
            if self.btn(ui, "A−", true) {
                self.run(ctx, Cmd::FontSmaller);
            }
            if self.btn(ui, "A+", true) {
                self.run(ctx, Cmd::FontBigger);
            }
            let mut rm = self.lib.settings.reduce_motion;
            if ui.checkbox(&mut rm, "Reduce motion").changed() {
                self.lib.settings.reduce_motion = rm;
            }
            let mut dbg = self.lib.settings.show_debug;
            if ui.checkbox(&mut dbg, "Debug overlay").changed() {
                self.lib.settings.show_debug = dbg;
            }
        });
    }

    // ───────────────────────── sidebar ─────────────────────────

    fn sidebar(&mut self, ui: &mut Ui) {
        ui.horizontal_wrapped(|ui| {
            for (t, l) in [(SideTab::Pages, "Pages"), (SideTab::Outline, "Outline"), (SideTab::Bookmarks, "Marks"), (SideTab::Search, "Search")] {
                if ui.selectable_label(self.tab == t, l).clicked() {
                    self.tab = t;
                }
            }
        });
        ui.separator();
        let Some(mut d) = self.doc.take() else { return };
        let Some(info) = d.info.clone() else {
            self.doc = Some(d);
            return;
        };
        let mut restart = false;
        let mut pick_hit: Option<usize> = None;
        match self.tab {
            SideTab::Pages => {
                let row_h = 196.0;
                let rev = (self.epoch & 0xFFFF) as u16;
                let filter = self.filter();
                egui::ScrollArea::vertical().auto_shrink([false, false]).show_rows(ui, row_h, info.pages.len(), |ui, range| {
                    for i in range {
                        let g = info.pages[i];
                        d.thumb_want.push(i as u32);
                        let w = 128.0f32.min(ui.available_width() - 12.0);
                        let h = (w * g.height / g.width).min(row_h - 26.0);
                        let w = h * g.width / g.height;
                        ui.vertical_centered(|ui| {
                            let (r, resp) = ui.allocate_exact_size(vec2(w, h), Sense::click());
                            ui.painter().rect_filled(r, 2.0, self.palette.paper);
                            let k = crate::viewer::preview_key(i, &g, filter, rev);
                            if let Some(t) = d.tiles.get(&k) {
                                ui.painter().image(t.id(), r, egui::Rect::from_min_max(egui::pos2(0.0, 0.0), egui::pos2(1.0, 1.0)), Color32::WHITE);
                            }
                            let cur = d.page == i;
                            let col = if cur { self.palette.accent } else { self.palette.border };
                            ui.painter().rect_stroke(r, 2.0, egui::Stroke::new(if cur { 3.0 } else { 1.0 }, col), egui::StrokeKind::Outside);
                            ui.label(RichText::new(format!("{}", i + 1)).size(tokens::T_CAPTION).color(self.palette.text_dim));
                            if resp.clicked() {
                                d.jump = Some((i, None));
                            }
                        });
                    }
                });
            }
            SideTab::Outline => match d.nav.clone() {
                None => {
                    ui.label("Loading outline…");
                }
                Some(nav) if nav.outline.is_empty() => {
                    ui.label(RichText::new("This document has no outline.").color(self.palette.text_dim));
                }
                Some(nav) => {
                    egui::ScrollArea::vertical().show(ui, |ui| {
                        for it in &nav.outline {
                            ui.horizontal(|ui| {
                                ui.add_space(it.level as f32 * 14.0);
                                let t = if it.title.is_empty() { "(untitled)" } else { &it.title };
                                if ui.add_enabled(it.page.is_some(), egui::Button::new(t).frame(false)).clicked() {
                                    if let Some(p) = it.page {
                                        d.jump = Some((p, None));
                                    }
                                }
                            });
                        }
                    });
                }
            },
            SideTab::Bookmarks => {
                let list = self.lib.bookmarks.get(&d.key).cloned().unwrap_or_default();
                if list.is_empty() {
                    ui.label(RichText::new("No bookmarks. Press Ctrl+D to bookmark the current page.").color(self.palette.text_dim));
                }
                for b in list {
                    if ui.add(egui::Button::new(format!("🔖 {}", b.label)).frame(false)).clicked() {
                        d.jump = Some((b.page as usize, None));
                    }
                }
            }
            SideTab::Search => {
                let r = ui.add(egui::TextEdit::singleline(&mut d.search.query).hint_text("Find in document").desired_width(f32::INFINITY));
                if d.search.focus {
                    r.request_focus();
                    d.search.focus = false;
                }
                if r.changed() {
                    restart = true;
                }
                if r.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                    pick_hit = Some(usize::MAX);
                }
                if ui.checkbox(&mut d.search.case, "Match case").changed() {
                    restart = true;
                }
                let total: usize = d.search.by_page.values().map(|v| v.len()).sum();
                let pending = d.text_requested.iter().filter(|p| !d.texts.contains_key(p)).count();
                let status = if d.search.query.trim().is_empty() {
                    String::new()
                } else if pending > 0 {
                    format!("{total} matches · scanning {pending} pages…")
                } else {
                    format!("{total} matches")
                };
                ui.label(RichText::new(status).color(self.palette.text_dim));
                egui::ScrollArea::vertical().show(ui, |ui| {
                    let mut idx = 0usize;
                    'outer: for (p, hits) in &d.search.by_page {
                        if let Some(t) = d.texts.get(p) {
                            for h in hits {
                                if idx > 400 {
                                    break 'outer;
                                }
                                let s = format!("p.{}  {}", p + 1, t.snippet(h, 24));
                                if ui.selectable_label(idx == d.search.current, s).clicked() {
                                    pick_hit = Some(idx);
                                }
                                idx += 1;
                            }
                        }
                    }
                });
            }
        }
        self.doc = Some(d);
        if restart {
            self.restart_search();
        }
        match pick_hit {
            Some(usize::MAX) => self.step_search(1),
            Some(i) => {
                if let Some(d) = self.doc.as_mut() {
                    d.search.current = i;
                }
                self.show_current_hit();
            }
            None => {}
        }
    }

    // ───────────────────────── inspector ─────────────────────────

    fn inspector(&mut self, ui: &mut Ui, ctx: &Context) {
        ui.add_space(4.0);
        ui.label(RichText::new("Tool").strong());
        ui.label(RichText::new(self.tool.label()).color(self.palette.text_dim));
        ui.horizontal_wrapped(|ui| {
            for (c, name) in SWATCHES {
                let (r, resp) = ui.allocate_exact_size(vec2(26.0, 26.0), Sense::click());
                ui.painter().circle_filled(r.center(), 11.0, Color32::from_rgb((c[0] * 255.0) as u8, (c[1] * 255.0) as u8, (c[2] * 255.0) as u8));
                if self.ann_color == c {
                    ui.painter().circle_stroke(r.center(), 13.0, egui::Stroke::new(2.0, self.palette.text));
                }
                if resp.on_hover_text(name).clicked() {
                    self.ann_color = c;
                }
            }
        });
        ui.add(egui::Slider::new(&mut self.ink_width, 1.0..=12.0).text("Stroke"));
        egui::ComboBox::from_label("Stamp").selected_text(self.stamp_label.clone()).show_ui(ui, |ui| {
            for s in STAMPS {
                ui.selectable_value(&mut self.stamp_label, s.to_owned(), s);
            }
        });
        ui.separator();
        ui.label(RichText::new("Page").strong());
        ui.horizontal_wrapped(|ui| {
            for (c, l) in [
                (Cmd::RotateCcw, "⟲"), (Cmd::RotateCw, "⟳"), (Cmd::MovePageUp, "⬆"), (Cmd::MovePageDown, "⬇"),
                (Cmd::InsertBlank, "＋ Blank"), (Cmd::InsertImagePage, "＋ Image"), (Cmd::DeletePage, "🗑"), (Cmd::Bookmark, "🔖"),
            ] {
                if self.btn(ui, l, true) {
                    self.run(ctx, c);
                }
            }
        });
        ui.separator();
        ui.label(RichText::new("Document").strong());
        if let Some(d) = &self.doc {
            let pages = d.info.as_ref().map_or(0, |i| i.pages.len());
            let size = d.info.as_ref().map_or(0, |i| i.byte_len);
            ui.label(RichText::new(format!("{} · {} pages · {}", d.name, pages, folio_core::fmt_bytes(size))).color(self.palette.text_dim));
            if let Some(t) = d.info.as_ref().and_then(|i| i.meta.title.clone()) {
                ui.label(RichText::new(t).color(self.palette.text_dim));
            }
        }
        ui.horizontal_wrapped(|ui| {
            for (c, l) in [
                (Cmd::Properties, "Properties"), (Cmd::FillForms, "Forms"), (Cmd::PlaceImage, "Signature / image"), (Cmd::Flatten, "Flatten"),
                (Cmd::ApplyRedactions, "Apply redactions"), (Cmd::ExtractPages, "Extract"), (Cmd::SplitDoc, "Split"), (Cmd::Merge, "Merge"),
                (Cmd::Compress, "Compress"), (Cmd::Protect, "Protect"), (Cmd::Unlock, "Unlock"), (Cmd::ExportPng, "Export PNG"),
            ] {
                if self.btn(ui, l, true) {
                    self.run(ctx, c);
                }
            }
        });
        ui.separator();
        self.view_options(ui, ctx);
    }

    // ───────────────────────── welcome ─────────────────────────

    fn welcome(&mut self, ui: &mut Ui, ctx: &Context) {
        ui.vertical_centered(|ui| {
            ui.add_space((ui.available_height() * 0.14).max(24.0));
            ui.label(RichText::new("Folio").size(tokens::T_HEADLINE * 1.6).strong());
            ui.label(RichText::new("A calm, fast PDF reader and editor — written entirely in Rust.").size(tokens::T_TITLE).color(self.palette.text_dim));
            ui.add_space(tokens::S6);
            ui.horizontal(|ui| {
                let w = 150.0;
                ui.add_space((ui.available_width() - 2.0 * w - 12.0).max(0.0) / 2.0);
                let open = egui::Button::new(RichText::new("📂  Open PDF").size(16.0).color(self.palette.on_accent)).fill(self.palette.accent).min_size(vec2(w, TOUCH));
                if ui.add(open).clicked() {
                    self.run(ctx, Cmd::Open);
                }
                if ui.add(egui::Button::new("Open sample").min_size(vec2(w, TOUCH))).clicked() {
                    self.run(ctx, Cmd::OpenSample);
                }
            });
            ui.add_space(tokens::S3);
            ui.label(RichText::new("…or drop a PDF anywhere in this window.  Nothing leaves your device.").size(tokens::T_CAPTION).color(self.palette.text_dim));
            ui.add_space(tokens::S6);
            if !self.lib.recents.is_empty() {
                ui.label(RichText::new("Recent").strong());
                let recents = self.lib.recents.clone();
                egui::ScrollArea::vertical().max_height(260.0).show(ui, |ui| {
                    for r in recents.iter().take(8) {
                        let label = format!("{}   ·   {}   ·   page {}", r.name, folio_core::fmt_bytes(r.size as usize), r.last_page + 1);
                        match &r.path {
                            Some(p) => {
                                if ui.add(egui::Button::new(label).frame(false)).clicked() {
                                    #[cfg(not(target_arch = "wasm32"))]
                                    self.open_path(p);
                                    #[cfg(target_arch = "wasm32")]
                                    let _ = p;
                                }
                            }
                            None => {
                                ui.label(RichText::new(label).color(self.palette.text_dim));
                            }
                        }
                    }
                });
            }
        });
    }

    // ───────────────────────── dialogs ─────────────────────────

    fn dialogs(&mut self, ctx: &Context) {
        let Some(mut dlg) = self.dialog.take() else { return };
        let mut keep = true;
        let n_pages = self.doc.as_ref().and_then(|d| d.info.as_ref()).map_or(0, |i| i.pages.len());
        let title = match &dlg {
            Dialog::Password { .. } => "Password required",
            Dialog::Text { note, .. } => if *note { "Add note" } else { "Add text box" },
            Dialog::Pages { split, .. } => if *split { "Split document" } else { "Extract pages" },
            Dialog::Protect { .. } => "Protect with password",
            Dialog::Properties { .. } => "Document properties",
            Dialog::Forms { .. } => "Form fields",
            Dialog::Goto { .. } => "Go to page",
            Dialog::About => "About Folio",
        };
        let mut run_after: Option<Cmd> = None;
        egui::Window::new(title).collapsible(false).resizable(false).anchor(Align2::CENTER_CENTER, [0.0, 0.0]).min_width(320.0).show(ctx, |ui| {
            match &mut dlg {
                Dialog::Password { bytes, name, path, input, error } => {
                    ui.label(format!("“{name}” is encrypted. Enter its password to open it."));
                    let r = ui.add(egui::TextEdit::singleline(input).password(true).desired_width(f32::INFINITY));
                    r.request_focus();
                    if let Some(e) = error {
                        ui.colored_label(self.palette.danger, e.as_str());
                    }
                    ui.horizontal(|ui| {
                        if self.btn(ui, "Open", true) || (r.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter))) {
                            self.begin_open(name.clone(), path.clone(), Arc::clone(bytes), input.clone());
                            self.doc = None;
                            keep = false;
                        }
                        if self.btn(ui, "Cancel", true) {
                            keep = false;
                        }
                    });
                }
                Dialog::Text { note, page, pos, rect, input } => {
                    ui.add(egui::TextEdit::multiline(input).desired_rows(4).desired_width(f32::INFINITY).hint_text("Type here (Latin-1 characters are embedded; others become “?”)"));
                    ui.horizontal(|ui| {
                        if self.btn(ui, "Add", !input.trim().is_empty()) {
                            let spec = if *note {
                                AnnotSpec::Note { pos: (pos.x, pos.y), text: input.clone() }
                            } else {
                                AnnotSpec::FreeText { rect: rect.unwrap_or([pos.x, pos.y - 40.0, pos.x + 200.0, pos.y]), text: input.clone(), size: 12.0, color: [0.0, 0.0, 0.0] }
                            };
                            self.add_annotation(*page, spec);
                            keep = false;
                        }
                        if self.btn(ui, "Cancel", true) {
                            keep = false;
                        }
                    });
                }
                Dialog::Pages { split, input } => {
                    ui.label(if *split { "Split into files of this many pages (delivered as a .zip):" } else { "Pages to extract, e.g. 1-3, 7, 10-:" });
                    ui.add(egui::TextEdit::singleline(input).desired_width(f32::INFINITY));
                    ui.horizontal(|ui| {
                        if self.btn(ui, if *split { "Split" } else { "Extract" }, true) {
                            if let Some((slot, bytes, pw, dirty, name)) = self.current_bytes_job_pub() {
                                let spec = input.clone();
                                let is_split = *split;
                                let base = name.trim_end_matches(".pdf").to_owned();
                                let job = move || -> Result<Vec<u8>, String> {
                                    let (cur, pw) = current_bytes_pub(&slot, &bytes, &pw, dirty)?;
                                    if is_split {
                                        let every: usize = spec.trim().parse().map_err(|_| "enter a number of pages per file".to_owned())?;
                                        let parts = folio_edit::split_every(&cur, &pw, every).map_err(|e| e.to_string())?;
                                        let files: Vec<(String, Vec<u8>)> = parts.into_iter().enumerate().map(|(i, b)| (format!("{base}-part-{:03}.pdf", i + 1), b)).collect();
                                        Ok(folio_edit::zip_store(&files))
                                    } else {
                                        let idx = folio_edit::parse_ranges(&spec, n_pages).map_err(|e| e.to_string())?;
                                        folio_edit::extract_pages(&cur, &pw, &idx).map_err(|e| e.to_string())
                                    }
                                };
                                if is_split {
                                    self.produce_zip_and_save(format!("{}-split.zip", name.trim_end_matches(".pdf")), job);
                                } else {
                                    self.produce_and_save(format!("{}-extract.pdf", name.trim_end_matches(".pdf")), job);
                                }
                            }
                            keep = false;
                        }
                        if self.btn(ui, "Cancel", true) {
                            keep = false;
                        }
                    });
                }
                Dialog::Protect { user, owner } => {
                    ui.label("Encrypts a copy with AES-256 (PDF 2.0). Keep the password safe – it cannot be recovered.");
                    ui.add(egui::TextEdit::singleline(user).password(true).hint_text("Open password").desired_width(f32::INFINITY));
                    ui.add(egui::TextEdit::singleline(owner).password(true).hint_text("Owner password (optional)").desired_width(f32::INFINITY));
                    ui.horizontal(|ui| {
                        if self.btn(ui, "Protect…", !user.is_empty()) {
                            if let Some((slot, bytes, pw, dirty, name)) = self.current_bytes_job_pub() {
                                let (u, o) = (user.clone(), owner.clone());
                                self.produce_and_save(format!("{}-protected.pdf", name.trim_end_matches(".pdf")), move || {
                                    let (cur, pw) = current_bytes_pub(&slot, &bytes, &pw, dirty)?;
                                    folio_edit::protect(&cur, &pw, &u, &o).map_err(|e| e.to_string())
                                });
                            }
                            keep = false;
                        }
                        if self.btn(ui, "Cancel", true) {
                            keep = false;
                        }
                    });
                }
                Dialog::Properties { title, author, subject, keywords } => {
                    for (l, v) in [("Title", &mut *title), ("Author", &mut *author), ("Subject", &mut *subject), ("Keywords", &mut *keywords)] {
                        ui.label(l);
                        ui.add(egui::TextEdit::singleline(v).desired_width(f32::INFINITY));
                    }
                    ui.horizontal(|ui| {
                        if self.btn(ui, "Apply", true) {
                            let cur = self.doc.as_ref().and_then(|d| d.info.clone()).map(|i| i.meta.clone()).unwrap_or_default();
                            for (k, new, old) in [("Title", &*title, cur.title), ("Author", &*author, cur.author), ("Subject", &*subject, cur.subject), ("Keywords", &*keywords, cur.keywords)] {
                                if *new != old.unwrap_or_default() {
                                    self.enqueue_edit(EditJobKind::Cmd(folio_edit::SetMetadata::new(k, new)));
                                }
                            }
                            keep = false;
                        }
                        if self.btn(ui, "Cancel", true) {
                            keep = false;
                        }
                    });
                }
                Dialog::Forms { fields, edited } => {
                    egui::ScrollArea::vertical().max_height(320.0).show(ui, |ui| {
                        for (i, f) in fields.iter().enumerate() {
                            ui.label(RichText::new(&f.name).size(tokens::T_CAPTION).color(self.palette.text_dim));
                            ui.add_enabled(f.editable, egui::TextEdit::singleline(&mut edited[i]).desired_width(f32::INFINITY));
                        }
                    });
                    ui.horizontal(|ui| {
                        let flatten = self.btn(ui, "Apply & flatten", true);
                        let apply = flatten || self.btn(ui, "Apply", true);
                        if apply {
                            for (i, f) in fields.iter().enumerate() {
                                if f.editable && edited[i] != f.value {
                                    self.enqueue_edit(EditJobKind::Cmd(folio_edit::SetFormField::new(&f.name, &edited[i])));
                                }
                            }
                            if flatten {
                                run_after = Some(Cmd::Flatten);
                            }
                            keep = false;
                        }
                        if self.btn(ui, "Cancel", true) {
                            keep = false;
                        }
                    });
                }
                Dialog::Goto { input } => {
                    let r = ui.add(egui::TextEdit::singleline(input).hint_text(format!("1 – {n_pages}")).desired_width(f32::INFINITY));
                    r.request_focus();
                    if (r.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter))) || self.btn(ui, "Go", true) {
                        if let Ok(p) = input.trim().parse::<usize>() {
                            self.goto(p.saturating_sub(1));
                        }
                        keep = false;
                    }
                }
                Dialog::About => {
                    ui.label("Folio 0.1 — one Rust codebase, no C dependencies.");
                    ui.label(RichText::new("Parsing/rendering: hayro · editing/encryption: lopdf + RustCrypto · UI: egui.").color(self.palette.text_dim));
                    ui.label(RichText::new("See STATUS.md for what is implemented, partial and not yet done.").color(self.palette.text_dim));
                    if self.btn(ui, "Close", true) {
                        keep = false;
                    }
                }
            }
        });
        if keep && self.dialog.is_none() {
            self.dialog = Some(dlg);
        }
        if let Some(c) = run_after {
            self.run(ctx, c);
        }
    }

    // ───────────────────────── palette & toast ─────────────────────────

    fn command_palette(&mut self, ctx: &Context) {
        if !self.palette_open {
            return;
        }
        let q = self.palette_q.to_lowercase();
        let has_doc = self.doc.as_ref().is_some_and(|d| d.info.is_some());
        let matches: Vec<Cmd> = Cmd::ALL.iter().copied().filter(|c| (has_doc || !c.needs_doc()) && fuzzy(&c.label().to_lowercase(), &q)).take(12).collect();
        let (up, down, enter) = ctx.input(|i| (i.key_pressed(egui::Key::ArrowUp), i.key_pressed(egui::Key::ArrowDown), i.key_pressed(egui::Key::Enter)));
        if down {
            self.palette_sel = (self.palette_sel + 1).min(matches.len().saturating_sub(1));
        }
        if up {
            self.palette_sel = self.palette_sel.saturating_sub(1);
        }
        let mut chosen = if enter { matches.get(self.palette_sel).copied() } else { None };
        let mods = self.mods_label(ctx);
        let width = 460.0_f32.min(ctx.content_rect().width() - 24.0);
        egui::Window::new("Command palette").title_bar(false).collapsible(false).resizable(false).anchor(Align2::CENTER_TOP, [0.0, 72.0]).fixed_size(vec2(width, 0.0)).show(ctx, |ui| {
            let r = ui.add(egui::TextEdit::singleline(&mut self.palette_q).hint_text("Type a command…").desired_width(f32::INFINITY));
            r.request_focus();
            if r.changed() {
                self.palette_sel = 0;
            }
            ui.separator();
            for (i, c) in matches.iter().enumerate() {
                ui.horizontal(|ui| {
                    let b = egui::Button::new(c.label()).selected(i == self.palette_sel).frame(i == self.palette_sel).min_size(vec2(ui.available_width() - 90.0, 30.0));
                    if ui.add(b).clicked() {
                        chosen = Some(*c);
                    }
                    ui.label(RichText::new(c.shortcut(mods).unwrap_or_default()).size(tokens::T_CAPTION).color(self.palette.text_dim));
                });
            }
        });
        if let Some(c) = chosen {
            self.palette_open = false;
            self.run(ctx, c);
        }
    }

    fn toast_ui(&mut self, ctx: &Context, now: f64) {
        let Some((msg, t0)) = self.toast.clone() else { return };
        if now - t0 > 4.5 {
            self.toast = None;
            return;
        }
        ctx.request_repaint_after(std::time::Duration::from_millis(300));
        egui::Area::new(egui::Id::new("toast")).anchor(Align2::CENTER_BOTTOM, [0.0, -72.0]).order(egui::Order::Tooltip).show(ctx, |ui| {
            Frame::popup(ui.style()).show(ui, |ui| {
                ui.set_max_width(520.0);
                ui.label(msg);
            });
        });
    }

    pub fn current_bytes_job_pub(&self) -> Option<(Arc<std::sync::Mutex<Option<folio_edit::Session>>>, Arc<Vec<u8>>, String, bool, String)> {
        let d = self.doc.as_ref()?;
        Some((d.session.clone(), d.bytes.clone(), d.password.clone(), d.dirty, d.name.clone()))
    }

    pub fn produce_zip_and_save(&mut self, suggested: String, job: impl FnOnce() -> Result<Vec<u8>, String> + Send + 'static) {
        let n = self.notify.clone();
        crate::task::spawn_async(async move {
            match job() {
                Err(e) => n.send(Msg::Error(e)),
                Ok(bytes) => {
                    let Some(h) = rfd::AsyncFileDialog::new().set_file_name(suggested.as_str()).add_filter("ZIP archive", &["zip"]).save_file().await else { return };
                    #[cfg(not(target_arch = "wasm32"))]
                    let r = folio_edit::write_atomic(h.path(), &bytes).map(|_| h.path().display().to_string()).map_err(|e| e.to_string());
                    #[cfg(target_arch = "wasm32")]
                    let r = h.write(&bytes).await.map(|_| h.file_name()).map_err(|e| e.to_string());
                    match r {
                        Ok(p) => n.send(Msg::Info(format!("Saved {p}"))),
                        Err(e) => n.send(Msg::Error(e)),
                    }
                }
            }
        });
    }
}

pub fn current_bytes_pub(slot: &Arc<std::sync::Mutex<Option<folio_edit::Session>>>, bytes: &Arc<Vec<u8>>, pw: &str, dirty: bool) -> Result<(Vec<u8>, String), String> {
    if dirty {
        let mut g = slot.lock().map_err(|_| "internal lock error".to_string())?;
        if let Some(s) = g.as_mut() {
            return Ok((s.to_bytes().map_err(|e| e.to_string())?, String::new()));
        }
    }
    Ok((bytes.to_vec(), pw.to_owned()))
}

fn fuzzy(hay: &str, needle: &str) -> bool {
    let mut it = hay.chars();
    needle.chars().filter(|c| !c.is_whitespace()).all(|n| it.any(|h| h == n))
}
