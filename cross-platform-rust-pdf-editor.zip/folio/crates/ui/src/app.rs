//! Application state, message pipeline and command dispatch. Drawing lives in `viewer.rs` / `chrome.rs`.
use crate::cmds::{Cmd, Tool};
use crate::layout::{SizeClass, ZoomMode};
use crate::task::{now_ms, spawn_async};
use crate::tokens::{self, Palette};
use egui::{Context, Pos2, TextureHandle, Vec2};
use folio_core::{DocInfo, Nav, OpenError};
use folio_edit::{AddAnnotation, AnnotSpec, Command, Session};
use folio_render::{Filter, Request, Response, Service, TileKey};
use folio_store::{Library, Lru, Platform, ReadingMode, Recent, ViewMode, doc_key};
use folio_text::{Hit, PageText};
use std::collections::{BTreeMap, HashMap, HashSet, VecDeque};
use std::sync::mpsc::{Receiver, Sender, channel};
use std::sync::{Arc, Mutex};

pub const STORAGE_KEY: &str = "folio.library.v1";

// ───────────────────────────── messages ─────────────────────────────

pub struct EditOut {
    pub bytes: Vec<u8>,
    pub label: String,
    pub can_undo: bool,
    pub can_redo: bool,
    pub undo_label: Option<String>,
    pub redo_label: Option<String>,
}

#[derive(Clone)]
pub struct FieldInfo {
    pub name: String,
    pub value: String,
    pub editable: bool,
}

pub enum Msg {
    Loaded { name: String, path: Option<String>, bytes: Vec<u8> },
    MergeWith { name: String, bytes: Vec<u8> },
    Image(Vec<u8>),
    ImageForPage(Vec<u8>),
    Nav(u64, Result<Nav, String>),
    EditDone(Result<EditOut, String>),
    Fields(Vec<FieldInfo>),
    Saved { path: Option<String>, text: String, clean: bool },
    Info(String),
    Error(String),
}

#[derive(Clone)]
pub struct Notifier {
    tx: Sender<Msg>,
    ctx: Context,
}
impl Notifier {
    pub fn send(&self, m: Msg) {
        let _ = self.tx.send(m);
        self.ctx.request_repaint();
    }
}

pub enum EditJob {
    Cmd(Box<dyn Command>),
    Undo,
    Redo,
    ApplyRedactions,
    ListFields,
}

// ───────────────────────────── state ─────────────────────────────

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum SideTab {
    Pages,
    Outline,
    Bookmarks,
    Search,
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Sheet {
    Nav,
    Tools,
    View,
}

pub enum Dialog {
    Password { bytes: Arc<Vec<u8>>, name: String, path: Option<String>, input: String, error: Option<String> },
    Text { note: bool, page: usize, pos: Pos2, rect: Option<[f32; 4]>, input: String },
    Pages { split: bool, input: String },
    Protect { user: String, owner: String },
    Properties { title: String, author: String, subject: String, keywords: String },
    Forms { fields: Vec<FieldInfo>, edited: Vec<String> },
    Goto { input: String },
    About,
}

#[derive(Default)]
pub struct SearchState {
    pub query: String,
    pub case: bool,
    pub by_page: BTreeMap<u32, Vec<Hit>>,
    pub current: usize,
    pub focus: bool,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum DragMode {
    Pan,
    Text,
    Ink,
    Rubber,
}

pub struct Drag {
    pub page: usize,
    pub mode: DragMode,
    pub start: Pos2,
    pub cur: Pos2,
    pub pts: Vec<Pos2>,
    pub force_sum: f32,
    pub force_n: u32,
    pub anchor_char: Option<usize>,
}

#[derive(Clone, Copy, PartialEq)]
pub struct Selection {
    pub page: usize,
    pub a: usize,
    pub b: usize,
}

pub struct DocState {
    pub name: String,
    pub path: Option<String>,
    pub bytes: Arc<Vec<u8>>,
    pub password: String,
    pub encrypted: bool,
    pub info: Option<Arc<DocInfo>>,
    pub key: String,
    pub texts: HashMap<u32, Arc<PageText>>,
    pub nav: Option<Arc<Nav>>,
    pub nav_requested: bool,
    pub dirty: bool,
    pub page: usize,
    pub scroll: Vec2,
    pub velocity: Vec2,
    pub zoom: ZoomMode,
    pub scale: f32,
    pub tiles: Lru<TileKey, TextureHandle>,
    pub failed: HashSet<TileKey>,
    pub last_wanted: Vec<TileKey>,
    pub text_requested: HashSet<u32>,
    pub thumb_want: Vec<u32>,
    pub jump: Option<(usize, Option<f32>)>,
    pub sel: Option<Selection>,
    pub drag: Option<Drag>,
    pub search: SearchState,
    pub session: Arc<Mutex<Option<Session>>>,
    pub edit_queue: VecDeque<EditJob>,
    pub edit_busy: bool,
    pub can_undo: bool,
    pub can_redo: bool,
    pub undo_label: Option<String>,
    pub redo_label: Option<String>,
    pub pending_image: Option<Vec<u8>>,
    pub loading_since: f64,
}

pub struct Stats {
    pub frame_ms: f32,
    pub fps: f32,
}

pub struct FolioApp {
    pub lib: Library,
    pub service: Service,
    pub notify: Notifier,
    pub rx: Receiver<Msg>,
    pub doc: Option<DocState>,
    pub epoch: u64,
    pub opening: Option<(String, Option<String>, Arc<Vec<u8>>, String)>,
    pub tool: Tool,
    pub ann_color: [f32; 3],
    pub ink_width: f32,
    pub stamp_label: String,
    pub dialog: Option<Dialog>,
    pub toast: Option<(String, f64)>,
    pub palette_open: bool,
    pub palette_q: String,
    pub palette_sel: usize,
    pub sidebar_open: bool,
    pub inspector_open: bool,
    pub tab: SideTab,
    pub sheet: Option<Sheet>,
    pub last_active: f64,
    pub touch_seen: bool,
    pub palette: Palette,
    pub applied: Option<(ReadingMode, bool, f32)>,
    pub stats: Stats,
    pub class: SizeClass,
    pub wanted_png: HashMap<u32, String>,
    pub budget: usize,
}

impl FolioApp {
    pub fn new(cc: &eframe::CreationContext<'_>, open_path: Option<String>) -> Self {
        let lib = cc.storage.and_then(|s| s.get_string(STORAGE_KEY)).map(|s| Library::from_json(&s)).unwrap_or_default();
        let (tx, rx) = channel();
        let ctx = cc.egui_ctx.clone();
        let wake_ctx = ctx.clone();
        let service = Service::new(move || wake_ctx.request_repaint());
        let mut lib = lib;
        if crate::task::system_reduce_motion() {
            lib.settings.reduce_motion = true;
        }
        let palette = Palette::for_mode(lib.settings.reading_mode);
        #[allow(unused_mut)]
        let mut app = Self {
            lib,
            service,
            notify: Notifier { tx, ctx },
            rx,
            doc: None,
            epoch: 0,
            opening: None,
            tool: Tool::Select,
            ann_color: [1.0, 0.92, 0.0],
            ink_width: 2.5,
            stamp_label: "Approved".into(),
            dialog: None,
            toast: None,
            palette_open: false,
            palette_q: String::new(),
            palette_sel: 0,
            sidebar_open: true,
            inspector_open: true,
            tab: SideTab::Pages,
            sheet: None,
            last_active: 0.0,
            touch_seen: false,
            palette,
            applied: None,
            stats: Stats { frame_ms: 0.0, fps: 0.0 },
            class: SizeClass::Expanded,
            wanted_png: HashMap::new(),
            budget: Platform::detect().tile_budget(),
        };
        #[cfg(not(target_arch = "wasm32"))]
        if let Some(p) = open_path {
            app.open_path(&p);
        }
        #[cfg(target_arch = "wasm32")]
        let _ = open_path;
        app
    }

    // ───────────────────────── helpers ─────────────────────────

    pub fn toast(&mut self, ctx: &Context, s: impl Into<String>) {
        let t = ctx.input(|i| i.time);
        self.toast = Some((s.into(), t));
        ctx.request_repaint();
    }

    pub fn mods_label(&self, ctx: &Context) -> &'static str {
        if ctx.os() == egui::os::OperatingSystem::Mac { "⌘" } else { "Ctrl+" }
    }

    pub fn filter(&self) -> Filter {
        match self.lib.settings.reading_mode {
            ReadingMode::Light => Filter::None,
            ReadingMode::Sepia => Filter::Sepia,
            ReadingMode::Dark => Filter::Dark,
            ReadingMode::Oled => Filter::Oled,
        }
    }

    pub fn doc_key_of(name: &str, len: usize) -> String {
        doc_key(name, len as u64)
    }

    // ───────────────────────── opening ─────────────────────────

    #[cfg(not(target_arch = "wasm32"))]
    pub fn open_path(&mut self, p: &str) {
        let n = self.notify.clone();
        let path = p.to_owned();
        spawn_async(async move {
            match std::fs::read(&path) {
                Ok(bytes) => {
                    let name = std::path::Path::new(&path).file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| path.clone());
                    n.send(Msg::Loaded { name, path: Some(path), bytes });
                }
                Err(e) => n.send(Msg::Error(format!("Could not read {path}: {e}"))),
            }
        });
    }

    pub fn pick_and_open(&mut self) {
        let n = self.notify.clone();
        spawn_async(async move {
            let Some(h) = rfd::AsyncFileDialog::new().add_filter("PDF documents", &["pdf"]).pick_file().await else { return };
            let bytes = h.read().await;
            #[cfg(not(target_arch = "wasm32"))]
            let path = Some(h.path().to_string_lossy().into_owned());
            #[cfg(target_arch = "wasm32")]
            let path = None;
            n.send(Msg::Loaded { name: h.file_name(), path, bytes });
        });
    }

    pub fn pick_file_msg(&mut self, filters: (&'static str, &'static [&'static str]), make: fn(String, Vec<u8>) -> Msg) {
        let n = self.notify.clone();
        spawn_async(async move {
            let Some(h) = rfd::AsyncFileDialog::new().add_filter(filters.0, filters.1).pick_file().await else { return };
            let bytes = h.read().await;
            n.send(make(h.file_name(), bytes));
        });
    }

    pub fn begin_open(&mut self, name: String, path: Option<String>, bytes: Arc<Vec<u8>>, password: String) {
        self.epoch += 1;
        self.opening = Some((name, path, bytes.clone(), password.clone()));
        self.service.send(Request::Open { epoch: self.epoch, bytes, password });
    }

    fn new_doc_state(&self, name: String, path: Option<String>, bytes: Arc<Vec<u8>>, password: String, now: f64) -> DocState {
        let key = Self::doc_key_of(&name, bytes.len());
        let page = self.lib.last_page(&name, bytes.len() as u64).unwrap_or(0) as usize;
        DocState {
            name, path, encrypted: !password.is_empty(), bytes, password, info: None, key,
            texts: HashMap::new(), nav: None, nav_requested: false, dirty: false, page,
            scroll: Vec2::ZERO, velocity: Vec2::ZERO, zoom: ZoomMode::FitWidth, scale: 1.0,
            tiles: Lru::new(self.budget), failed: HashSet::new(), last_wanted: Vec::new(), text_requested: HashSet::new(),
            thumb_want: Vec::new(), jump: None, sel: None, drag: None, search: SearchState::default(),
            session: Arc::new(Mutex::new(None)), edit_queue: VecDeque::new(), edit_busy: false,
            can_undo: false, can_redo: false, undo_label: None, redo_label: None, pending_image: None, loading_since: now,
        }
    }

    // ───────────────────────── message pump ─────────────────────────

    pub fn pump(&mut self, ctx: &Context) {
        let now = ctx.input(|i| i.time);
        while let Ok(m) = self.rx.try_recv() {
            match m {
                Msg::Loaded { name, path, bytes } => {
                    let bytes = Arc::new(bytes);
                    self.doc = Some(self.new_doc_state(name.clone(), path.clone(), bytes.clone(), String::new(), now));
                    self.begin_open(name, path, bytes, String::new());
                }
                Msg::MergeWith { name, bytes } => self.start_merge(name, bytes),
                Msg::Image(b) => {
                    if let Some(d) = self.doc.as_mut() {
                        d.pending_image = Some(b);
                        self.tool = Tool::Image;
                    }
                    self.toast(ctx, "Drag a rectangle on the page to place the image");
                }
                Msg::ImageForPage(b) => self.enqueue_edit(EditJobKind::Cmd(folio_edit::InsertPage::image(self.doc.as_ref().map(|d| d.page), b))),
                Msg::Nav(ep, r) => {
                    if ep == self.epoch {
                        if let (Some(d), Ok(n)) = (self.doc.as_mut(), r) {
                            d.nav = Some(Arc::new(n));
                        }
                    }
                }
                Msg::EditDone(r) => self.edit_done(ctx, r),
                Msg::Fields(fields) => {
                    if let Some(d) = self.doc.as_mut() {
                        d.edit_busy = false;
                    }
                    if fields.is_empty() {
                        self.toast(ctx, "This document has no form fields");
                    } else {
                        let edited = fields.iter().map(|f| f.value.clone()).collect();
                        self.dialog = Some(Dialog::Forms { fields, edited });
                    }
                    self.kick_edit();
                }
                Msg::Saved { path, text, clean } => {
                    if let Some(d) = self.doc.as_mut() {
                        if clean {
                            d.dirty = false;
                            if path.is_some() {
                                d.path = path;
                            }
                        }
                    }
                    self.toast(ctx, text);
                }
                Msg::Info(s) => self.toast(ctx, s),
                Msg::Error(s) => {
                    if let Some(d) = self.doc.as_mut() {
                        d.edit_busy = false;
                    }
                    self.toast(ctx, format!("⚠ {s}"));
                    self.kick_edit();
                }
            }
        }
        for r in self.service.poll() {
            self.on_response(ctx, r);
        }
        if self.service.busy() {
            ctx.request_repaint();
        }
    }

    fn on_response(&mut self, ctx: &Context, r: Response) {
        match r {
            Response::Opened { epoch, result } => {
                if epoch != self.epoch {
                    return;
                }
                let Some((name, path, bytes, pw)) = self.opening.take() else { return };
                match result {
                    Ok(info) => {
                        let now = ctx.input(|i| i.time);
                        let reopen = self.doc.as_ref().is_some_and(|d| d.info.is_some() || d.name == name);
                        if self.doc.is_none() {
                            self.doc = Some(self.new_doc_state(name.clone(), path.clone(), bytes.clone(), pw.clone(), now));
                        }
                        let (lib_name, size) = (name.clone(), bytes.len() as u64);
                        let d = self.doc.as_mut().expect("doc");
                        let first_open = d.info.is_none();
                        d.bytes = bytes.clone();
                        d.password = pw;
                        d.tiles.clear();
                        d.failed.clear();
                        d.last_wanted.clear();
                        d.texts.clear();
                        d.text_requested.clear();
                        d.nav = None;
                        d.nav_requested = false;
                        d.page = d.page.min(info.pages.len().saturating_sub(1));
                        if first_open || !reopen {
                            d.jump = Some((d.page, None));
                        }
                        d.info = Some(info);
                        if !d.search.query.is_empty() {
                            d.search.by_page.clear();
                        }
                        if first_open {
                            let rec = Recent { name: lib_name, path, size, last_page: d.page as u32, opened_ms: now_ms() };
                            self.lib.touch_recent(rec);
                        }
                    }
                    Err(OpenError::NeedPassword) | Err(OpenError::WrongPassword) => {
                        let wrong = !pw.is_empty();
                        self.doc = None;
                        self.dialog = Some(Dialog::Password { bytes, name, path, input: String::new(), error: wrong.then(|| "That password is not correct.".to_owned()) });
                    }
                    Err(e) => {
                        if self.doc.as_ref().is_some_and(|d| d.info.is_none()) {
                            self.doc = None;
                        }
                        self.toast(ctx, format!("⚠ {e}"));
                    }
                }
            }
            Response::Tile(t) => {
                let Some(d) = self.doc.as_mut() else { return };
                if t.key.rev != (self.epoch & 0xFFFF) as u16 {
                    return;
                }
                let img = egui::ColorImage::from_rgba_unmultiplied([t.w as usize, t.h as usize], &t.rgba);
                let tex = ctx.load_texture("tile", img, egui::TextureOptions::LINEAR);
                d.tiles.insert(t.key, tex, (t.w * t.h * 4) as usize);
            }
            Response::TileFailed(k) => {
                if let Some(d) = self.doc.as_mut() {
                    d.failed.insert(k);
                }
            }
            Response::Text { page, text } => {
                if let Some(d) = self.doc.as_mut() {
                    if !d.search.query.is_empty() {
                        let hits = text.search(&d.search.query, d.search.case);
                        if !hits.is_empty() {
                            d.search.by_page.insert(page, hits);
                        }
                    }
                    d.texts.insert(page, text);
                }
            }
            Response::Png { page, result } => {
                let name = self.wanted_png.remove(&page).unwrap_or_else(|| format!("page-{}.png", page + 1));
                match result {
                    Ok(bytes) => self.save_bytes_dialog(name, bytes, "PNG image", "png"),
                    Err(e) => self.toast(ctx, format!("⚠ Export failed: {e}")),
                }
            }
        }
    }

    // ───────────────────────── editing pipeline ─────────────────────────

    pub fn enqueue_edit(&mut self, k: EditJobKind) {
        let Some(d) = self.doc.as_mut() else { return };
        d.edit_queue.push_back(match k {
            EditJobKind::Cmd(c) => EditJob::Cmd(c),
            EditJobKind::Undo => EditJob::Undo,
            EditJobKind::Redo => EditJob::Redo,
            EditJobKind::Redact => EditJob::ApplyRedactions,
            EditJobKind::Fields => EditJob::ListFields,
        });
        self.kick_edit();
    }

    pub fn kick_edit(&mut self) {
        let Some(d) = self.doc.as_mut() else { return };
        if d.edit_busy || d.info.is_none() {
            return;
        }
        let Some(job) = d.edit_queue.pop_front() else { return };
        d.edit_busy = true;
        let (slot, bytes, pw, n) = (d.session.clone(), d.bytes.clone(), d.password.clone(), self.notify.clone());
        spawn_async(async move {
            let r = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| run_edit_job(&slot, &bytes, &pw, job)));
            match r {
                Ok(Ok(m)) => n.send(m),
                Ok(Err(e)) => n.send(Msg::Error(e)),
                Err(_) => {
                    if let Ok(mut g) = slot.lock() {
                        *g = None;
                    }
                    n.send(Msg::Error("The edit failed unexpectedly; your document was not changed.".into()));
                }
            }
        });
    }

    fn edit_done(&mut self, ctx: &Context, r: Result<EditOut, String>) {
        match r {
            Err(e) => {
                if let Some(d) = self.doc.as_mut() {
                    d.edit_busy = false;
                }
                self.toast(ctx, format!("⚠ {e}"));
                self.kick_edit();
            }
            Ok(o) => {
                let Some(d) = self.doc.as_mut() else { return };
                d.edit_busy = false;
                d.dirty = true;
                d.can_undo = o.can_undo;
                d.can_redo = o.can_redo;
                d.undo_label = o.undo_label;
                d.redo_label = o.redo_label;
                d.sel = None;
                // Edits decrypt in memory; a later Save writes an unprotected copy (explained to the user).
                let was_encrypted = d.encrypted;
                d.password.clear();
                let (name, path, bytes) = (d.name.clone(), d.path.clone(), Arc::new(o.bytes));
                let msg = if was_encrypted { format!("{} (note: saves are written without a password – use Protect to re-encrypt)", o.label) } else { o.label };
                self.begin_open(name, path, bytes, String::new());
                self.toast(ctx, msg);
            }
        }
    }

    pub fn add_annotation(&mut self, page: usize, spec: AnnotSpec) {
        self.enqueue_edit(EditJobKind::Cmd(AddAnnotation::new(page, spec)));
    }

    // ───────────────────────── saving / exporting ─────────────────────────

    pub fn save_bytes_dialog(&mut self, name: String, bytes: Vec<u8>, filter: &'static str, ext: &'static str) {
        let n = self.notify.clone();
        spawn_async(async move {
            let Some(h) = rfd::AsyncFileDialog::new().set_file_name(name.as_str()).add_filter(filter, &[ext]).save_file().await else { return };
            #[cfg(not(target_arch = "wasm32"))]
            let r = folio_edit::write_atomic(h.path(), &bytes).map(|_| h.path().display().to_string()).map_err(|e| e.to_string());
            #[cfg(target_arch = "wasm32")]
            let r = h.write(&bytes).await.map(|_| h.file_name()).map_err(|e| e.to_string());
            match r {
                Ok(p) => n.send(Msg::Info(format!("Saved {p}"))),
                Err(e) => n.send(Msg::Error(e)),
            }
        });
    }

    /// Produce bytes on a worker (may take a while) and then offer them in a Save dialog.
    pub fn produce_and_save(&mut self, suggested: String, job: impl FnOnce() -> Result<Vec<u8>, String> + Send + 'static) {
        let n = self.notify.clone();
        spawn_async(async move {
            match job() {
                Err(e) => n.send(Msg::Error(e)),
                Ok(bytes) => {
                    let Some(h) = rfd::AsyncFileDialog::new().set_file_name(suggested.as_str()).add_filter("PDF documents", &["pdf"]).save_file().await else { return };
                    #[cfg(not(target_arch = "wasm32"))]
                    let r = folio_edit::write_atomic(h.path(), &bytes).map(|_| h.path().display().to_string()).map_err(|e| e.to_string());
                    #[cfg(target_arch = "wasm32")]
                    let r = h.write(&bytes).await.map(|_| h.file_name()).map_err(|e| e.to_string());
                    match r {
                        Ok(p) => n.send(Msg::Info(format!("Saved {p}"))),
                        Err(e) => n.send(Msg::Error(e)),
                    }
                }
            }
        });
    }

    /// Save current document (incremental when possible). `as_copy` always asks for a location.
    pub fn save(&mut self, as_copy: bool) {
        let Some(d) = self.doc.as_ref() else { return };
        if d.info.is_none() {
            return;
        }
        let (slot, bytes, name, path, dirty, n) = (d.session.clone(), d.bytes.clone(), d.name.clone(), d.path.clone(), d.dirty, self.notify.clone());
        let session_exists = slot.lock().map(|g| g.is_some()).unwrap_or(false);
        let produce = move || -> Result<(Vec<u8>, bool), String> {
            if !session_exists || !dirty {
                return Ok((bytes.to_vec(), false));
            }
            let mut g = slot.lock().map_err(|_| "internal lock error".to_string())?;
            let s = g.as_mut().ok_or("no edits to save")?;
            s.to_bytes_incremental_or_full().map_err(|e| e.to_string())
        };
        #[cfg(not(target_arch = "wasm32"))]
        if !as_copy {
            if let Some(p) = path.clone() {
                spawn_async(async move {
                    match produce() {
                        Ok((b, inc)) => match folio_edit::write_atomic(std::path::Path::new(&p), &b) {
                            Ok(()) => n.send(Msg::Saved { path: Some(p.clone()), text: format!("Saved {p}{}", if inc { " (incremental update)" } else { "" }), clean: true }),
                            Err(e) => n.send(Msg::Error(e.to_string())),
                        },
                        Err(e) => n.send(Msg::Error(e)),
                    }
                });
                return;
            }
        }
        let _ = path;
        let suggested = if as_copy { format!("{}-copy.pdf", name.trim_end_matches(".pdf")) } else { name };
        spawn_async(async move {
            let (b, _) = match produce() {
                Ok(x) => x,
                Err(e) => return n.send(Msg::Error(e)),
            };
            let Some(h) = rfd::AsyncFileDialog::new().set_file_name(suggested.as_str()).add_filter("PDF documents", &["pdf"]).save_file().await else { return };
            #[cfg(not(target_arch = "wasm32"))]
            let r = folio_edit::write_atomic(h.path(), &b).map(|_| (h.path().display().to_string(), Some(h.path().display().to_string()))).map_err(|e| e.to_string());
            #[cfg(target_arch = "wasm32")]
            let r = h.write(&b).await.map(|_| (h.file_name(), None)).map_err(|e| e.to_string());
            match r {
                Ok((shown, p)) => n.send(Msg::Saved { path: p, text: format!("Saved {shown}"), clean: !as_copy }),
                Err(e) => n.send(Msg::Error(e)),
            }
        });
    }

    fn start_merge(&mut self, other_name: String, other: Vec<u8>) {
        let Some(d) = self.doc.as_ref() else { return };
        let (slot, bytes, pw, name) = (d.session.clone(), d.bytes.clone(), d.password.clone(), d.name.clone());
        let dirty = d.dirty;
        let _ = other_name;
        self.produce_and_save(format!("{}-merged.pdf", name.trim_end_matches(".pdf")), move || {
            let current = if dirty {
                match slot.lock() {
                    Ok(mut g) => match g.as_mut() {
                        Some(s) => s.to_bytes().map_err(|e| e.to_string())?,
                        None => bytes.to_vec(),
                    },
                    Err(_) => bytes.to_vec(),
                }
            } else {
                bytes.to_vec()
            };
            let pw = if dirty { String::new() } else { pw };
            folio_edit::merge(&[(current, pw), (other, String::new())]).map_err(|e| e.to_string())
        });
    }

    /// Bytes of the document as currently shown (edits included) for derived-file operations.
    fn current_bytes_job(&self) -> Option<(Arc<Mutex<Option<Session>>>, Arc<Vec<u8>>, String, bool, String)> {
        let d = self.doc.as_ref()?;
        Some((d.session.clone(), d.bytes.clone(), d.password.clone(), d.dirty, d.name.clone()))
    }

    // ───────────────────────── commands ─────────────────────────

    pub fn run(&mut self, ctx: &Context, cmd: Cmd) {
        if cmd.needs_doc() && self.doc.as_ref().is_none_or(|d| d.info.is_none()) {
            return;
        }
        let page = self.doc.as_ref().map_or(0, |d| d.page);
        let n_pages = self.doc.as_ref().and_then(|d| d.info.as_ref()).map_or(0, |i| i.pages.len());
        match cmd {
            Cmd::Open => self.pick_and_open(),
            Cmd::OpenSample => {
                let bytes = folio_core::sample::sample_pdf(24);
                self.notify.send(Msg::Loaded { name: "Folio sample.pdf".into(), path: None, bytes });
            }
            Cmd::Save => self.save(false),
            Cmd::SaveAs => self.save(true),
            Cmd::CloseDoc => {
                if let Some(d) = &self.doc {
                    let (n, s, p) = (d.name.clone(), d.bytes.len() as u64, d.page as u32);
                    self.lib.set_last_page(&n, s, p);
                }
                self.doc = None;
                self.service.send(Request::Close);
            }
            Cmd::Undo => self.enqueue_edit(EditJobKind::Undo),
            Cmd::Redo => self.enqueue_edit(EditJobKind::Redo),
            Cmd::Copy => {
                if let Some(t) = self.selection_text() {
                    ctx.copy_text(t);
                    self.toast(ctx, "Copied");
                }
            }
            Cmd::Find => {
                self.tab = SideTab::Search;
                self.sidebar_open = true;
                if self.class == SizeClass::Compact {
                    self.sheet = Some(Sheet::Nav);
                }
                if let Some(d) = self.doc.as_mut() {
                    d.search.focus = true;
                }
            }
            Cmd::FindNext => self.step_search(1),
            Cmd::FindPrev => self.step_search(-1),
            Cmd::GoToPage => self.dialog = Some(Dialog::Goto { input: String::new() }),
            Cmd::Palette => {
                self.palette_open = !self.palette_open;
                self.palette_q.clear();
                self.palette_sel = 0;
            }
            Cmd::ZoomIn | Cmd::ZoomOut => {
                if let Some(d) = self.doc.as_mut() {
                    let f = if cmd == Cmd::ZoomIn { 1.25 } else { 0.8 };
                    d.zoom = ZoomMode::Custom((d.scale * f).clamp(0.1, 12.0));
                }
            }
            Cmd::FitWidth => self.set_zoom(ZoomMode::FitWidth),
            Cmd::FitPage => self.set_zoom(ZoomMode::FitPage),
            Cmd::Zoom100 => self.set_zoom(ZoomMode::Custom(1.0)),
            Cmd::ViewContinuous => self.set_view(ViewMode::Continuous),
            Cmd::ViewSingle => self.set_view(ViewMode::Single),
            Cmd::ViewTwoPage => self.set_view(ViewMode::TwoPage),
            Cmd::ModeLight => self.set_mode(ReadingMode::Light),
            Cmd::ModeSepia => self.set_mode(ReadingMode::Sepia),
            Cmd::ModeDark => self.set_mode(ReadingMode::Dark),
            Cmd::ModeOled => self.set_mode(ReadingMode::Oled),
            Cmd::ToggleSidebar => self.sidebar_open = !self.sidebar_open,
            Cmd::ToggleInspector => self.inspector_open = !self.inspector_open,
            Cmd::Bookmark => {
                if let Some(d) = self.doc.as_ref() {
                    let on = self.lib.toggle_bookmark(&d.key.clone(), page as u32);
                    self.toast(ctx, if on { "Bookmark added" } else { "Bookmark removed" });
                }
            }
            Cmd::Debug => self.lib.settings.show_debug = !self.lib.settings.show_debug,
            Cmd::ReduceMotion => self.lib.settings.reduce_motion = !self.lib.settings.reduce_motion,
            Cmd::FontBigger => self.lib.settings.font_scale = (self.lib.settings.font_scale + 0.1).min(1.6),
            Cmd::FontSmaller => self.lib.settings.font_scale = (self.lib.settings.font_scale - 0.1).max(0.8),
            Cmd::NextPage => self.goto(page + 1),
            Cmd::PrevPage => self.goto(page.saturating_sub(1)),
            Cmd::FirstPage => self.goto(0),
            Cmd::LastPage => self.goto(n_pages.saturating_sub(1)),
            Cmd::RotateCw => self.enqueue_edit(EditJobKind::Cmd(folio_edit::RotatePage::new(page, 90))),
            Cmd::RotateCcw => self.enqueue_edit(EditJobKind::Cmd(folio_edit::RotatePage::new(page, -90))),
            Cmd::DeletePage => self.enqueue_edit(EditJobKind::Cmd(folio_edit::DeletePage::new(page))),
            Cmd::InsertBlank => {
                let size = self.doc.as_ref().and_then(|d| d.info.as_ref()).and_then(|i| i.pages.get(page)).map_or((612.0, 792.0), |g| (g.width, g.height));
                self.enqueue_edit(EditJobKind::Cmd(folio_edit::InsertPage::blank(Some(page), size)));
            }
            Cmd::InsertImagePage => self.pick_file_msg(("Images", &["png", "jpg", "jpeg"]), |_, b| Msg::ImageForPage(b)),
            Cmd::PlaceImage => self.pick_file_msg(("Images", &["png", "jpg", "jpeg"]), |_, b| Msg::Image(b)),
            Cmd::MovePageUp => {
                if page > 0 {
                    self.enqueue_edit(EditJobKind::Cmd(folio_edit::MovePage::new(page, page - 1)));
                    self.goto(page - 1);
                }
            }
            Cmd::MovePageDown => {
                if page + 1 < n_pages {
                    self.enqueue_edit(EditJobKind::Cmd(folio_edit::MovePage::new(page, page + 1)));
                    self.goto(page + 1);
                }
            }
            Cmd::Merge => self.pick_file_msg(("PDF documents", &["pdf"]), |n, b| Msg::MergeWith { name: n, bytes: b }),
            Cmd::ExtractPages => self.dialog = Some(Dialog::Pages { split: false, input: format!("{}", page + 1) }),
            Cmd::SplitDoc => self.dialog = Some(Dialog::Pages { split: true, input: "10".into() }),
            Cmd::Compress => {
                if let Some((slot, bytes, pw, dirty, name)) = self.current_bytes_job() {
                    self.produce_and_save(format!("{}-compressed.pdf", name.trim_end_matches(".pdf")), move || {
                        let (cur, pw) = current_bytes(&slot, &bytes, &pw, dirty)?;
                        let (out, st) = folio_edit::compress(&cur, &pw).map_err(|e| e.to_string())?;
                        let _ = st;
                        Ok(out)
                    });
                }
            }
            Cmd::Protect => self.dialog = Some(Dialog::Protect { user: String::new(), owner: String::new() }),
            Cmd::Unlock => {
                if let Some((slot, bytes, pw, dirty, name)) = self.current_bytes_job() {
                    self.produce_and_save(format!("{}-unlocked.pdf", name.trim_end_matches(".pdf")), move || {
                        let (cur, pw) = current_bytes(&slot, &bytes, &pw, dirty)?;
                        folio_edit::unlock(&cur, &pw).map_err(|e| e.to_string())
                    });
                }
            }
            Cmd::ExportPng => {
                if let Some(d) = self.doc.as_ref() {
                    self.wanted_png.insert(page as u32, format!("{}-page-{}.png", d.name.trim_end_matches(".pdf"), page + 1));
                    self.service.send(Request::Png { page: page as u32, zoom_milli: 2000, filter: Filter::None });
                }
            }
            Cmd::Flatten => self.enqueue_edit(EditJobKind::Cmd(folio_edit::Snapshot::new("Flattened annotations and forms", |d| {
                let w = folio_edit::forms::flatten_annotations(d, false);
                match w {
                    Ok(_) => Ok(()),
                    Err(_) => folio_edit::forms::flatten_annotations(d, true).map(|_| ()),
                }
            }))),
            Cmd::ApplyRedactions => self.enqueue_edit(EditJobKind::Redact),
            Cmd::Properties => {
                if let Some(d) = self.doc.as_ref().and_then(|d| d.info.clone()) {
                    let m = &d.meta;
                    self.dialog = Some(Dialog::Properties {
                        title: m.title.clone().unwrap_or_default(), author: m.author.clone().unwrap_or_default(),
                        subject: m.subject.clone().unwrap_or_default(), keywords: m.keywords.clone().unwrap_or_default(),
                    });
                }
            }
            Cmd::FillForms => self.enqueue_edit(EditJobKind::Fields),
            Cmd::About => self.dialog = Some(Dialog::About),
        }
    }

    pub fn set_zoom(&mut self, z: ZoomMode) {
        if let Some(d) = self.doc.as_mut() {
            d.zoom = z;
            d.scroll.x = 0.0;
        }
    }
    pub fn set_view(&mut self, v: ViewMode) {
        self.lib.settings.view_mode = v;
        if let Some(d) = self.doc.as_mut() {
            d.jump = Some((d.page, None));
        }
    }
    pub fn set_mode(&mut self, m: ReadingMode) {
        self.lib.settings.reading_mode = m;
        // New epoch-bound keys: tiles are re-rendered with the new filter.
        if let Some(d) = self.doc.as_mut() {
            d.tiles.clear();
            d.failed.clear();
            d.last_wanted.clear();
        }
    }
    pub fn goto(&mut self, p: usize) {
        if let Some(d) = self.doc.as_mut() {
            let n = d.info.as_ref().map_or(0, |i| i.pages.len());
            if n > 0 {
                d.jump = Some((p.min(n - 1), None));
            }
        }
    }

    pub fn selection_text(&self) -> Option<String> {
        let d = self.doc.as_ref()?;
        let s = d.sel?;
        let t = d.texts.get(&(s.page as u32))?;
        let (a, b) = (s.a.min(s.b), s.a.max(s.b) + 1);
        let txt = t.slice(a, b);
        (!txt.is_empty()).then_some(txt)
    }

    pub fn step_search(&mut self, dir: i32) {
        let Some(d) = self.doc.as_mut() else { return };
        let total: usize = d.search.by_page.values().map(|v| v.len()).sum();
        if total == 0 {
            return;
        }
        d.search.current = ((d.search.current as i64 + dir as i64).rem_euclid(total as i64)) as usize;
        self.show_current_hit();
    }

    pub fn show_current_hit(&mut self) {
        let Some(d) = self.doc.as_mut() else { return };
        let mut k = d.search.current;
        for (&p, hits) in &d.search.by_page {
            if k < hits.len() {
                let y = hits[k].rects.first().map(|r| r[1]);
                d.jump = Some((p as usize, y));
                return;
            }
            k -= hits.len();
        }
    }

    /// (Re)start a search from the current query: recompute from cached text, request the rest.
    pub fn restart_search(&mut self) {
        let Some(d) = self.doc.as_mut() else { return };
        d.search.by_page.clear();
        d.search.current = 0;
        if d.search.query.trim().is_empty() {
            return;
        }
        let (q, cs) = (d.search.query.clone(), d.search.case);
        for (p, t) in &d.texts {
            let h = t.search(&q, cs);
            if !h.is_empty() {
                d.search.by_page.insert(*p, h);
            }
        }
        let Some(info) = d.info.clone() else { return };
        let n = info.pages.len() as u32;
        let start = d.page as u32;
        let order: Vec<u32> = (start..n).chain(0..start).filter(|p| !d.texts.contains_key(p)).collect();
        for p in &order {
            d.text_requested.insert(*p);
        }
        self.service.send(Request::Text(order));
    }

    // ───────────────────────── frame ─────────────────────────

    pub fn begin_frame(&mut self, ctx: &Context) {
        let dt = ctx.input(|i| i.unstable_dt).clamp(0.0001, 1.0);
        self.stats.frame_ms = self.stats.frame_ms * 0.9 + dt * 1000.0 * 0.1;
        self.stats.fps = 1000.0 / self.stats.frame_ms.max(0.1);
        let want = (self.lib.settings.reading_mode, self.lib.settings.reduce_motion, self.lib.settings.font_scale);
        if self.applied != Some(want) {
            self.palette = Palette::for_mode(want.0);
            tokens::apply(ctx, &self.palette, want.1);
            ctx.set_zoom_factor(want.2);
            self.applied = Some(want);
        }
        self.class = SizeClass::from_width(ctx.content_rect().width());
        self.pump(ctx);
        let t = ctx.input(|i| i.time);
        if ctx.input(|i| i.pointer.is_moving() || i.pointer.any_down() || i.smooth_scroll_delta().length() > 0.0 || !i.events.is_empty()) {
            self.last_active = t;
        }
        if ctx.input(|i| i.events.iter().any(|e| matches!(e, egui::Event::Touch { .. }))) {
            self.touch_seen = true;
        }
        // Dropped files (drag-and-drop).
        let dropped = ctx.input(|i| i.raw.dropped_files.clone());
        for f in dropped {
            #[cfg(not(target_arch = "wasm32"))]
            {
                let p = f.path().to_string_lossy().into_owned();
                self.open_path(&p);
            }
            #[cfg(target_arch = "wasm32")]
            {
                let n = self.notify.clone();
                let name = f.path().file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(|| "dropped.pdf".into());
                spawn_async(async move {
                    match f.bytes_async().await {
                        Ok(b) => n.send(Msg::Loaded { name, path: None, bytes: b }),
                        Err(e) => n.send(Msg::Error(format!("Could not read dropped file: {e}"))),
                    }
                });
            }
        }
        self.shortcuts(ctx);
        // Nav extraction: after the first frames of a freshly opened document.
        if let Some(d) = self.doc.as_mut() {
            if d.info.is_some() && !d.nav_requested && (t - d.loading_since) > 0.15 {
                d.nav_requested = true;
                let (bytes, pw, ep, n) = (d.bytes.clone(), d.password.clone(), self.epoch, self.notify.clone());
                spawn_async(async move {
                    let r = std::panic::catch_unwind(|| folio_core::extract_nav(&bytes, &pw)).unwrap_or_else(|_| Err("panic".into()));
                    n.send(Msg::Nav(ep, r));
                });
            }
        }
        self.kick_edit();
    }

    fn shortcuts(&mut self, ctx: &Context) {
        use egui::Key;
        let typing = ctx.egui_wants_keyboard_input();
        let (cmd_down, shift) = ctx.input(|i| (i.modifiers.command, i.modifiers.shift));
        let pressed = |k: Key| ctx.input(|i| i.key_pressed(k));
        let mut run: Option<Cmd> = None;
        if cmd_down {
            for (k, c) in [(Key::K, Cmd::Palette), (Key::O, Cmd::Open), (Key::S, Cmd::Save), (Key::F, Cmd::Find), (Key::G, Cmd::GoToPage), (Key::D, Cmd::Bookmark), (Key::B, Cmd::ToggleSidebar), (Key::Y, Cmd::Redo)] {
                if pressed(k) {
                    run = Some(c);
                }
            }
            if pressed(Key::Z) {
                run = Some(if shift { Cmd::Redo } else { Cmd::Undo });
            }
            if pressed(Key::Plus) || pressed(Key::Equals) {
                run = Some(Cmd::ZoomIn);
            }
            if pressed(Key::Minus) {
                run = Some(Cmd::ZoomOut);
            }
            if pressed(Key::Num0) {
                run = Some(Cmd::Zoom100);
            }
            if pressed(Key::C) && !typing {
                run = Some(Cmd::Copy);
            }
            if typing && matches!(run, Some(Cmd::Undo | Cmd::Redo)) {
                run = None; // let text fields handle their own undo
            }
        } else if !typing && self.dialog.is_none() {
            for (k, c) in [(Key::PageDown, Cmd::NextPage), (Key::PageUp, Cmd::PrevPage), (Key::Home, Cmd::FirstPage), (Key::End, Cmd::LastPage), (Key::F3, Cmd::Debug)] {
                if pressed(k) {
                    run = Some(c);
                }
            }
            if pressed(Key::F3) && shift {
                run = Some(Cmd::FindPrev);
            }
        }
        if let Some(c) = run {
            self.run(ctx, c);
        }
        if pressed(Key::Escape) {
            self.palette_open = false;
            self.dialog = None;
            if let Some(d) = self.doc.as_mut() {
                d.sel = None;
                d.drag = None;
            }
            self.tool = Tool::Select;
        }
        if pressed(Key::Enter) && !typing {
            if let Some(d) = self.doc.as_ref() {
                if !d.search.by_page.is_empty() {
                    self.step_search(if shift { -1 } else { 1 });
                }
            }
        }
    }
}

pub enum EditJobKind {
    Cmd(Box<dyn Command>),
    Undo,
    Redo,
    Redact,
    Fields,
}

fn current_bytes(slot: &Arc<Mutex<Option<Session>>>, bytes: &Arc<Vec<u8>>, pw: &str, dirty: bool) -> Result<(Vec<u8>, String), String> {
    if dirty {
        let mut g = slot.lock().map_err(|_| "internal lock error".to_string())?;
        if let Some(s) = g.as_mut() {
            return Ok((s.to_bytes().map_err(|e| e.to_string())?, String::new()));
        }
    }
    Ok((bytes.to_vec(), pw.to_owned()))
}

fn run_edit_job(slot: &Arc<Mutex<Option<Session>>>, bytes: &Arc<Vec<u8>>, pw: &str, job: EditJob) -> Result<Msg, String> {
    let mut g = slot.lock().map_err(|_| "internal lock error".to_string())?;
    if g.is_none() {
        *g = Some(Session::load(bytes, pw).map_err(|e| e.to_string())?);
    }
    let s = g.as_mut().ok_or("no session")?;
    let label = match job {
        EditJob::Cmd(c) => {
            let l = c.label();
            s.execute(c).map_err(|e| e.to_string())?;
            l
        }
        EditJob::Undo => format!("Undid: {}", s.undo().map_err(|e| e.to_string())?.unwrap_or_else(|| "nothing to undo".into())),
        EditJob::Redo => format!("Redid: {}", s.redo().map_err(|e| e.to_string())?.unwrap_or_else(|| "nothing to redo".into())),
        EditJob::ListFields => {
            let fields = folio_edit::forms::list_fields(&s.doc)
                .into_iter()
                .map(|f| FieldInfo { editable: f.kind == folio_edit::forms::FieldKind::Text, name: f.name, value: f.value })
                .collect();
            return Ok(Msg::Fields(fields));
        }
        EditJob::ApplyRedactions => {
            let pages: Vec<usize> = folio_edit::page_ids(&s.doc)
                .iter()
                .enumerate()
                .filter(|(_, pid)| {
                    s.doc.get_page_annotations(**pid).map(|a| a.iter().any(|d| matches!(d.get(b"Subtype"), Ok(lopdf_name) if lopdf_name.as_name().ok() == Some(b"Redact")))).unwrap_or(false)
                })
                .map(|(i, _)| i)
                .collect();
            if pages.is_empty() {
                return Err("There are no redaction marks. Use the Redact tool to mark areas first.".into());
            }
            let view = s.to_view_bytes().map_err(|e| e.to_string())?;
            let mut eng = folio_render::Engine::new();
            eng.push(Request::Open { epoch: 0, bytes: Arc::new(view), password: String::new() });
            let info = match eng.step() {
                Some(Response::Opened { result: Ok(i), .. }) => i,
                _ => return Err("could not render the document for redaction".into()),
            };
            let mut rendered = Vec::new();
            for p in &pages {
                eng.push(Request::Png { page: *p as u32, zoom_milli: 2000, filter: Filter::None });
                match eng.step() {
                    Some(Response::Png { result: Ok(png), .. }) => {
                        let g = info.pages[*p];
                        rendered.push((*p, png, g.width, g.height));
                    }
                    _ => return Err("could not rasterise a page".into()),
                }
            }
            let n = pages.len();
            s.execute(folio_edit::Snapshot::new("Applied redactions", move |d| folio_edit::rasterize_pages(d, &rendered))).map_err(|e| e.to_string())?;
            format!("Redacted {n} page(s) – content under the black boxes no longer exists in the file")
        }
    };
    let bytes = s.to_view_bytes().map_err(|e| e.to_string())?;
    Ok(Msg::EditDone(Ok(EditOut { bytes, label, can_undo: s.can_undo(), can_redo: s.can_redo(), undo_label: s.undo_label(), redo_label: s.redo_label() })))
}

impl FolioApp {
    /// React to OS memory pressure: shrink tile caches to a third and evict immediately.
    pub fn shrink_caches(&mut self) {
        self.budget = (self.budget / 3).max(8 << 20);
        if let Some(d) = self.doc.as_mut() {
            d.tiles.shrink(0.33, |_| false);
            d.last_wanted.clear();
        }
    }
}
