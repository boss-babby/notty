//! `folio-store` – memory budget manager, LRU caches and the persisted library.
//!
//! Everything that holds large buffers (tiles, decoded images, thumbnails) goes through [`Lru`],
//! which enforces a global byte budget and evicts least-recently-used entries that are not pinned
//! by the current viewport. Platform memory warnings call [`Lru::shrink`].

use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, HashMap};
use std::hash::Hash;

/// Platform classes with different memory envelopes (bytes of *cache*, not total RSS).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Platform {
    Desktop,
    Web,
    Mobile,
}

impl Platform {
    /// Default cache budget. The 500-page RSS targets (150 MB desktop / 80 MB mobile) leave room for
    /// the parsed document, fonts and the worker's page buffers.
    pub const fn tile_budget(self) -> usize {
        match self {
            Platform::Desktop => 72 << 20,
            Platform::Web => 48 << 20,
            Platform::Mobile => 32 << 20,
        }
    }
    pub fn detect() -> Self {
        if cfg!(target_arch = "wasm32") {
            Platform::Web
        } else if cfg!(any(target_os = "android", target_os = "ios")) {
            Platform::Mobile
        } else {
            Platform::Desktop
        }
    }
}

struct Entry<V> {
    value: V,
    tick: u64,
    bytes: usize,
}

/// Byte-budgeted LRU cache with pinning and hit-rate statistics.
pub struct Lru<K, V> {
    map: HashMap<K, Entry<V>>,
    budget: usize,
    used: usize,
    tick: u64,
    pub hits: u64,
    pub misses: u64,
}

impl<K: Hash + Eq + Clone, V> Lru<K, V> {
    pub fn new(budget: usize) -> Self {
        Self { map: HashMap::new(), budget, used: 0, tick: 0, hits: 0, misses: 0 }
    }
    pub fn len(&self) -> usize {
        self.map.len()
    }
    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }
    pub fn used(&self) -> usize {
        self.used
    }
    pub fn budget(&self) -> usize {
        self.budget
    }
    pub fn contains(&self, k: &K) -> bool {
        self.map.contains_key(k)
    }
    /// Lookup that counts towards hit-rate and refreshes recency.
    pub fn get(&mut self, k: &K) -> Option<&V> {
        self.tick += 1;
        let t = self.tick;
        match self.map.get_mut(k) {
            Some(e) => {
                e.tick = t;
                self.hits += 1;
                Some(&e.value)
            }
            None => {
                self.misses += 1;
                None
            }
        }
    }
    /// Lookup without touching statistics or recency.
    pub fn peek(&self, k: &K) -> Option<&V> {
        self.map.get(k).map(|e| &e.value)
    }
    pub fn insert(&mut self, k: K, v: V, bytes: usize) {
        self.tick += 1;
        if let Some(old) = self.map.insert(k, Entry { value: v, tick: self.tick, bytes }) {
            self.used -= old.bytes;
        }
        self.used += bytes;
    }
    pub fn clear(&mut self) {
        self.map.clear();
        self.used = 0;
    }
    pub fn retain(&mut self, mut f: impl FnMut(&K) -> bool) {
        let mut freed = 0;
        self.map.retain(|k, e| {
            let keep = f(k);
            if !keep {
                freed += e.bytes;
            }
            keep
        });
        self.used -= freed;
    }
    /// Evict least-recently-used entries until under budget. `pinned` entries are never evicted
    /// (viewport + prefetch ring). Returns the number evicted.
    pub fn enforce(&mut self, pinned: impl Fn(&K) -> bool) -> usize {
        let mut n = 0;
        if self.used <= self.budget {
            return 0;
        }
        let mut order: Vec<(u64, K)> = self.map.iter().filter(|(k, _)| !pinned(k)).map(|(k, e)| (e.tick, k.clone())).collect();
        order.sort_by_key(|(t, _)| *t);
        for (_, k) in order {
            if self.used <= self.budget {
                break;
            }
            if let Some(e) = self.map.remove(&k) {
                self.used -= e.bytes;
                n += 1;
            }
        }
        n
    }
    /// Memory-pressure response (Android `onTrimMemory`, iOS memory warning): shrink the budget to
    /// `factor` of its current size and evict immediately. Budget can be restored with [`Lru::set_budget`].
    pub fn shrink(&mut self, factor: f32, pinned: impl Fn(&K) -> bool) -> usize {
        self.budget = ((self.budget as f32) * factor.clamp(0.1, 1.0)) as usize;
        self.enforce(pinned)
    }
    pub fn set_budget(&mut self, b: usize) {
        self.budget = b;
    }
    pub fn hit_rate(&self) -> f32 {
        let t = self.hits + self.misses;
        if t == 0 { 1.0 } else { self.hits as f32 / t as f32 }
    }
}

// ───────────────────────────── persisted library ─────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
pub enum ReadingMode {
    #[default]
    Light,
    Sepia,
    Dark,
    Oled,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
pub enum ViewMode {
    #[default]
    Continuous,
    Single,
    TwoPage,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Settings {
    pub reading_mode: ReadingMode,
    pub view_mode: ViewMode,
    pub reduce_motion: bool,
    /// Dynamic-type style multiplier for UI text (0.8 – 1.6).
    pub font_scale: f32,
    pub show_debug: bool,
}

impl Default for Settings {
    fn default() -> Self {
        Self { reading_mode: ReadingMode::Light, view_mode: ViewMode::Continuous, reduce_motion: false, font_scale: 1.0, show_debug: false }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Recent {
    pub name: String,
    /// Native only; the web cannot reopen by path.
    pub path: Option<String>,
    pub size: u64,
    pub last_page: u32,
    pub opened_ms: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Bookmark {
    pub page: u32,
    pub label: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Library {
    pub settings: Settings,
    pub recents: Vec<Recent>,
    /// Keyed by [`doc_key`].
    pub bookmarks: BTreeMap<String, Vec<Bookmark>>,
}

/// Stable-enough identity for a document without hashing its content.
pub fn doc_key(name: &str, size: u64) -> String {
    format!("{name}:{size}")
}

impl Library {
    pub const MAX_RECENTS: usize = 20;

    pub fn from_json(s: &str) -> Self {
        serde_json::from_str(s).unwrap_or_default()
    }
    pub fn to_json(&self) -> String {
        serde_json::to_string(self).unwrap_or_default()
    }

    pub fn touch_recent(&mut self, r: Recent) {
        self.recents.retain(|x| !(x.name == r.name && x.size == r.size));
        self.recents.insert(0, r);
        self.recents.truncate(Self::MAX_RECENTS);
    }
    pub fn set_last_page(&mut self, name: &str, size: u64, page: u32) {
        if let Some(r) = self.recents.iter_mut().find(|r| r.name == name && r.size == size) {
            r.last_page = page;
        }
    }
    pub fn last_page(&self, name: &str, size: u64) -> Option<u32> {
        self.recents.iter().find(|r| r.name == name && r.size == size).map(|r| r.last_page)
    }
    pub fn toggle_bookmark(&mut self, key: &str, page: u32) -> bool {
        let v = self.bookmarks.entry(key.to_owned()).or_default();
        if let Some(i) = v.iter().position(|b| b.page == page) {
            v.remove(i);
            false
        } else {
            v.push(Bookmark { page, label: format!("Page {}", page + 1) });
            v.sort_by_key(|b| b.page);
            true
        }
    }
    pub fn is_bookmarked(&self, key: &str, page: u32) -> bool {
        self.bookmarks.get(key).is_some_and(|v| v.iter().any(|b| b.page == page))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lru_respects_budget_pins_and_recency() {
        let mut c: Lru<u32, Vec<u8>> = Lru::new(300);
        for i in 0..5 {
            c.insert(i, vec![0; 100], 100);
        }
        assert_eq!(c.used(), 500);
        c.get(&0); // refresh 0
        let evicted = c.enforce(|k| *k == 1); // 1 pinned
        assert_eq!(evicted, 2);
        assert!(c.contains(&0) && c.contains(&1) && c.contains(&4));
        assert!(!c.contains(&2) && !c.contains(&3));
        assert!(c.used() <= 300);
    }

    #[test]
    fn shrink_and_stats() {
        let mut c: Lru<u32, ()> = Lru::new(1000);
        for i in 0..10 {
            c.insert(i, (), 100);
        }
        assert_eq!(c.shrink(0.5, |_| false), 5);
        assert!(c.used() <= 500);
        assert!(c.get(&9).is_some());
        assert!(c.get(&0).is_none());
        assert!((c.hit_rate() - 0.5).abs() < 1e-6);
    }

    #[test]
    fn library_roundtrip_and_bookmarks() {
        let mut l = Library::default();
        l.touch_recent(Recent { name: "a.pdf".into(), path: None, size: 10, last_page: 3, opened_ms: 1 });
        l.touch_recent(Recent { name: "b.pdf".into(), path: None, size: 20, last_page: 0, opened_ms: 2 });
        l.touch_recent(Recent { name: "a.pdf".into(), path: None, size: 10, last_page: 4, opened_ms: 3 });
        assert_eq!(l.recents.len(), 2);
        assert_eq!(l.recents[0].name, "a.pdf");
        let k = doc_key("a.pdf", 10);
        assert!(l.toggle_bookmark(&k, 2));
        assert!(l.is_bookmarked(&k, 2));
        let l2 = Library::from_json(&l.to_json());
        assert!(l2.is_bookmarked(&k, 2));
        assert!(!l2.clone().toggle_bookmark(&k, 2));
        assert_eq!(Library::from_json("garbage").recents.len(), 0);
    }
}
