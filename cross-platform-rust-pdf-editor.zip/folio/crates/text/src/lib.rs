//! `folio-text` – text layer for a page: glyph boxes, reading order, search, selection.
//!
//! The layer is built by running hayro's content interpreter with a [`TextDevice`] that records
//! every glyph's Unicode value and box. All coordinates are **page space**: points, origin top-left.

use hayro_interpret::font::GlyphRun;
use hayro_interpret::hayro_cmap::BfString;
use hayro_interpret::hayro_syntax::page::Page;
use hayro_interpret::kurbo::{Affine, BezPath, Point, Rect};
use hayro_interpret::util::TransformExt;
use hayro_interpret::{Context, InterpreterCache, InterpreterSettings, interpret_page};
use hayro_interpret::{
    BlendMode, ClipPath, Device, DrawMode, DrawProps, Image, ImageDrawProps, SoftMask,
};

/// One character with its page-space box `[x0, y0, x1, y1]`.
#[derive(Debug, Clone, PartialEq)]
pub struct TChar {
    pub ch: char,
    pub rect: [f32; 4],
}

/// Text of a page in reading order.
#[derive(Debug, Clone, Default)]
pub struct PageText {
    pub chars: Vec<TChar>,
    /// `(start, end)` char ranges (end exclusive), one per visual line, top to bottom.
    pub lines: Vec<(usize, usize)>,
}

/// A search hit: char range plus per-line highlight rectangles.
#[derive(Debug, Clone, PartialEq)]
pub struct Hit {
    pub start: usize,
    pub end: usize,
    pub rects: Vec<[f32; 4]>,
}

/// Records glyphs while the interpreter walks a page.
pub struct TextDevice {
    raw: Vec<TChar>,
    /// PDF user space → page space (top-left origin).
    base: Affine,
}

impl TextDevice {
    pub fn new(base: Affine) -> Self {
        Self { raw: Vec::new(), base }
    }
    /// Finish: order into lines and build the [`PageText`].
    pub fn finish(self) -> PageText {
        PageText::from_chars(self.raw)
    }
}

fn push_glyph(out: &mut Vec<TChar>, t: Affine, next: Option<Point>, prev_adv: &mut Option<(f64, f64)>, unicode: Option<BfString>) {
    let o = t * Point::new(0.0, 0.0);
    let up = t * Point::new(0.0, 1.0);
    // Height of the em square in page space.
    // hayro normalises glyph space to 1000 units per em.
    let h = (((up.x - o.x).powi(2) + (up.y - o.y).powi(2)).sqrt() * 1000.0) as f32;
    // Advance along the baseline = distance to the next glyph origin (or the previous advance).
    let adv = match next {
        Some(n) => (n.x - o.x, n.y - o.y),
        None => prev_adv.unwrap_or((h as f64 * 0.5, 0.0)),
    };
    // Ignore wild jumps (new text object) – fall back to half an em.
    let adv = if adv.0.abs() > h as f64 * 8.0 || adv.1.abs() > h as f64 * 2.0 { (h as f64 * 0.5, 0.0) } else { adv };
    *prev_adv = Some(adv);
    let Some(u) = unicode else { return };
    let s: String = match u {
        BfString::Char(c) => c.to_string(),
        BfString::String(s) => s,
    };
    let (x0, x1) = (o.x.min(o.x + adv.0) as f32, o.x.max(o.x + adv.0) as f32);
    let y_top = o.y as f32 - h * 0.8;
    let y_bot = o.y as f32 + h * 0.2;
    if !(x0.is_finite() && x1.is_finite() && y_top.is_finite() && h.is_finite()) || h <= 0.0 {
        return;
    }
    let n = s.chars().count().max(1) as f32;
    let w = (x1 - x0) / n;
    for (i, ch) in s.chars().enumerate() {
        if ch == '\0' || ch.is_control() {
            continue;
        }
        let a = x0 + w * i as f32;
        out.push(TChar { ch, rect: [a, y_top, a + w, y_bot] });
    }
}

impl<'a> Device<'a> for TextDevice {
    fn draw_path(&mut self, _: &BezPath, _: DrawProps<'a>, _: &DrawMode) {}
    fn push_clip_path(&mut self, _: &ClipPath) {}
    fn push_transparency_group(&mut self, _: f32, _: Option<SoftMask<'a>>, _: BlendMode) {}
    fn draw_glyph_run(&mut self, run: &GlyphRun<'_, 'a>, _: DrawProps<'a>, _: &DrawMode) {
        let glyphs = run.glyphs();
        let mut prev = None;
        for (i, g) in glyphs.iter().enumerate() {
            let next = glyphs.get(i + 1).map(|n| self.base * n.transform() * Point::new(0.0, 0.0));
            push_glyph(&mut self.raw, self.base * g.transform(), next, &mut prev, g.as_unicode());
        }
    }
    fn draw_image(&mut self, _: Image<'a, '_>, _: ImageDrawProps<'a>) {}
    fn pop_clip(&mut self) {}
    fn pop_transparency_group(&mut self) {}
}

/// Extract the text layer of a page. `cache` should be reused across pages of one document.
pub fn extract_page<'a>(page: &'a Page<'a>, cache: &InterpreterCache<'a>, settings: InterpreterSettings) -> PageText {
    let (w, h) = page.render_dimensions();
    let t = page.initial_transform(true).to_kurbo();
    let mut ctx = Context::new(Affine::IDENTITY, Rect::new(0.0, 0.0, w as f64, h as f64), cache, page.xref(), settings);
    let mut dev = TextDevice::new(t);
    interpret_page(page, &mut ctx, &mut dev);
    dev.finish()
}

fn rect_union(a: [f32; 4], b: [f32; 4]) -> [f32; 4] {
    [a[0].min(b[0]), a[1].min(b[1]), a[2].max(b[2]), a[3].max(b[3])]
}
fn mid_y(r: &[f32; 4]) -> f32 {
    (r[1] + r[3]) * 0.5
}
fn height(r: &[f32; 4]) -> f32 {
    (r[3] - r[1]).abs().max(0.1)
}

impl PageText {
    /// Group glyphs (content-stream order) into lines, then order lines top→bottom and
    /// chars left→right inside a line. Inserts spaces where a visible gap exists.
    pub fn from_chars(raw: Vec<TChar>) -> Self {
        // 1. Cluster into lines by baseline proximity (stream order keeps words intact).
        let mut groups: Vec<Vec<TChar>> = Vec::new();
        for c in raw {
            let placed = groups.iter_mut().rev().take(6).find(|g| {
                let last = g.last().expect("non-empty group");
                (mid_y(&last.rect) - mid_y(&c.rect)).abs() < height(&last.rect).min(height(&c.rect)) * 0.5
                    && c.rect[0] >= last.rect[0] - height(&last.rect) * 0.3
                    && c.rect[0] - last.rect[2] < height(&last.rect) * 6.0
            });
            match placed {
                Some(g) => g.push(c),
                None => groups.push(vec![c]),
            }
        }
        // 2. Order groups.
        groups.sort_by(|a, b| {
            let (ya, yb) = (mid_y(&a[0].rect), mid_y(&b[0].rect));
            let tol = height(&a[0].rect).min(height(&b[0].rect)) * 0.5;
            if (ya - yb).abs() < tol {
                a[0].rect[0].partial_cmp(&b[0].rect[0]).unwrap_or(std::cmp::Ordering::Equal)
            } else {
                ya.partial_cmp(&yb).unwrap_or(std::cmp::Ordering::Equal)
            }
        });
        // 3. Flatten, synthesising spaces for gaps.
        let mut chars = Vec::new();
        let mut lines = Vec::new();
        for mut g in groups {
            g.sort_by(|a, b| a.rect[0].partial_cmp(&b.rect[0]).unwrap_or(std::cmp::Ordering::Equal));
            let start = chars.len();
            let mut prev: Option<[f32; 4]> = None;
            for c in g {
                if let Some(p) = prev {
                    let gap = c.rect[0] - p[2];
                    if gap > height(&p) * 0.25 && c.ch != ' ' && chars.last().map(|l: &TChar| l.ch) != Some(' ') {
                        chars.push(TChar { ch: ' ', rect: [p[2], p[1], c.rect[0], p[3]] });
                    }
                }
                prev = Some(c.rect);
                chars.push(c);
            }
            if chars.len() > start {
                lines.push((start, chars.len()));
            }
        }
        PageText { chars, lines }
    }

    pub fn is_empty(&self) -> bool {
        self.chars.is_empty()
    }

    /// Plain text with `\n` between lines.
    pub fn plain(&self) -> String {
        self.slice(0, self.chars.len())
    }

    /// Text of char range `[a, b)` with line breaks where lines change.
    pub fn slice(&self, a: usize, b: usize) -> String {
        let (a, b) = (a.min(self.chars.len()), b.min(self.chars.len()));
        let mut s = String::new();
        for &(ls, le) in &self.lines {
            let (x, y) = (ls.max(a), le.min(b));
            if x < y {
                if !s.is_empty() {
                    s.push('\n');
                }
                s.extend(self.chars[x..y].iter().map(|c| c.ch));
            }
        }
        s
    }

    /// Highlight rects for char range `[a, b)`: one merged rect per line.
    pub fn rects_for(&self, a: usize, b: usize) -> Vec<[f32; 4]> {
        let mut out = Vec::new();
        for &(ls, le) in &self.lines {
            let (x, y) = (ls.max(a), le.min(b));
            if x < y {
                let mut r = self.chars[x].rect;
                for c in &self.chars[x + 1..y] {
                    r = rect_union(r, c.rect);
                }
                out.push(r);
            }
        }
        out
    }

    /// Index of the char nearest to a page-space point (for selection). `None` if no text.
    pub fn char_at(&self, x: f32, y: f32) -> Option<usize> {
        if self.chars.is_empty() {
            return None;
        }
        // Choose line by vertical distance, then char by horizontal distance.
        let mut best_line = None;
        let mut best_dy = f32::MAX;
        for (li, &(ls, le)) in self.lines.iter().enumerate() {
            let r = self.rects_for(ls, le)[0];
            let dy = if y < r[1] { r[1] - y } else if y > r[3] { y - r[3] } else { 0.0 };
            if dy < best_dy {
                best_dy = dy;
                best_line = Some(li);
            }
        }
        let (ls, le) = self.lines[best_line?];
        let mut best = ls;
        let mut best_dx = f32::MAX;
        for i in ls..le {
            let r = &self.chars[i].rect;
            let dx = if x < r[0] { r[0] - x } else if x > r[2] { x - r[2] } else { 0.0 };
            if dx < best_dx {
                best_dx = dx;
                best = i;
            }
        }
        Some(best)
    }

    /// Case-insensitive substring search. Whitespace in the query matches any run of spaces.
    pub fn search(&self, query: &str, case_sensitive: bool) -> Vec<Hit> {
        let q: Vec<char> = fold(query.trim(), case_sensitive);
        if q.is_empty() || self.chars.is_empty() {
            return Vec::new();
        }
        let hay: Vec<char> = self
            .chars
            .iter()
            .map(|c| fold_char(c.ch, case_sensitive))
            .collect();
        let mut hits = Vec::new();
        let mut i = 0;
        while i + q.len() <= hay.len() {
            if hay[i..i + q.len()] == q[..] {
                hits.push(Hit { start: i, end: i + q.len(), rects: self.rects_for(i, i + q.len()) });
                i += q.len();
            } else {
                i += 1;
            }
        }
        hits
    }

    /// A short context snippet around a hit (for the results list).
    pub fn snippet(&self, hit: &Hit, radius: usize) -> String {
        let a = hit.start.saturating_sub(radius);
        let b = (hit.end + radius).min(self.chars.len());
        self.chars[a..b].iter().map(|c| if c.ch == '\n' { ' ' } else { c.ch }).collect()
    }
}

fn fold_char(c: char, cs: bool) -> char {
    if cs { c } else { c.to_lowercase().next().unwrap_or(c) }
}
fn fold(s: &str, cs: bool) -> Vec<char> {
    s.chars().map(|c| fold_char(c, cs)).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn extracts_real_page_text() {
        let bytes = folio_core::sample::sample_pdf(2);
        let pdf = folio_core::open(std::sync::Arc::new(bytes), "").unwrap();
        let cache = InterpreterCache::new();
        let page = &pdf.pages()[0];
        let t = extract_page(page, &cache, InterpreterSettings::default());
        eprintln!("TEXT: {:?}", t.plain());
        for c in t.chars.iter().take(6) { eprintln!("{:?}", c); }
        assert!(t.plain().contains("quick brown fox"), "{}", t.plain());
        let hit = t.search("needle", false);
        assert_eq!(hit.len(), 1);
        let r = hit[0].rects[0];
        // "needle" is on the third body line, ~ y = 792-660+36 = 168 pt from top, x >= 72.
        assert!(r[0] > 72.0 && r[1] > 100.0 && r[1] < 190.0 && (r[3] - r[1]) < 20.0, "{r:?}");
    }

    fn ch(c: char, x: f32, y: f32) -> TChar {
        TChar { ch: c, rect: [x, y, x + 6.0, y + 12.0] }
    }
    fn word(s: &str, x: f32, y: f32) -> Vec<TChar> {
        s.chars().enumerate().map(|(i, c)| ch(c, x + 6.0 * i as f32, y)).collect()
    }

    #[test]
    fn orders_lines_and_searches() {
        let mut raw = word("second", 10.0, 40.0);
        raw.extend(word("first", 10.0, 10.0));
        let t = PageText::from_chars(raw);
        assert_eq!(t.plain(), "first\nsecond");
        let hits = t.search("COND", false);
        assert_eq!(hits.len(), 1);
        assert_eq!(hits[0].rects.len(), 1);
        assert!(t.search("COND", true).is_empty());
    }

    #[test]
    fn inserts_spaces_for_gaps() {
        let mut raw = word("hello", 10.0, 10.0);
        raw.extend(word("world", 60.0, 10.0));
        let t = PageText::from_chars(raw);
        assert_eq!(t.plain(), "hello world");
        assert_eq!(t.search("o w", false).len(), 1);
    }

    #[test]
    fn hit_testing() {
        let t = PageText::from_chars(word("abc", 10.0, 10.0));
        assert_eq!(t.char_at(17.0, 15.0), Some(1));
        assert_eq!(t.char_at(500.0, 500.0), Some(2));
        assert_eq!(PageText::default().char_at(0.0, 0.0), None);
    }
}
