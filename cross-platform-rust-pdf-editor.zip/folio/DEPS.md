# Dependency justifications

Every *direct* dependency has one line: **why**, size impact, maintenance, licence, wasm support.
Transitive crates are covered by `cargo deny` (licences, advisories, bans) and `scripts/check-no-c-deps.sh`.
"wasm ✔" = compiles and runs on `wasm32-unknown-unknown` (verified by `scripts/build-web.sh`).

## PDF engine
| Crate | Why | Size | Maintenance | Licence | wasm |
|---|---|---|---|---|---|
| `hayro` (+`hayro-interpret`, `hayro-syntax`, `hayro-*` codecs) | Pure-Rust PDF parser + content interpreter + CPU rasteriser (vello_cpu). Handles AES/RC4 decryption, JPX, JBIG2, CCITT. Only credible pure-Rust renderer. | ~1.3 MB wasm | Active (0.9, weekly releases) | MIT/Apache-2.0 | ✔ |
| `lopdf` | Object-level read/write for edits, annotations, page tree surgery, AES-256 encryption, incremental xref writing. `default-features=false` drops chrono/rayon. | ~0.3 MB | Active | MIT | ✔ (`wasm_js` feature for getrandom) |
| `self_cell` | Safe self-referential struct so the engine can own `Pdf` + the caches that borrow it without `unsafe`. | tiny | Stable | MIT/Apache-2.0 | ✔ |
| `image` (png, jpeg only) | Decode user images/signatures for embedding. Pure-Rust codecs only (`png`, `zune-jpeg`). | ~0.2 MB | Active | MIT/Apache-2.0 | ✔ |
| `getrandom` | OS randomness for the AES-256 file key (browser: `crypto.getRandomValues`). | tiny | Active (rust-random) | MIT/Apache-2.0 | ✔ (`wasm_js`) |
| `serde`, `serde_json` | Persisted library (recents, bookmarks, settings). | small | Standard | MIT/Apache-2.0 | ✔ |

## UI and platform glue
| Crate | Why | Size | Maintenance | Licence | wasm |
|---|---|---|---|---|---|
| `eframe` / `egui` | One immediate-mode UI for all targets (see ADR-0001). glow (OpenGL/WebGL2) backend, accesskit enabled. | ~1 MB wasm | Very active | MIT/Apache-2.0 | ✔ |
| `rfd` | System file open/save dialogs; browser file picker + download on wasm. | small | Active | MIT | ✔ |
| `pollster` | Block on `rfd` futures in worker threads (native only). | tiny | Stable | MIT/Apache-2.0 | n/a |
| `memory-stats` | RSS for the debug overlay (native only). Uses `windows-sys`/`libc` (FFI declarations only). | tiny | Stable | MIT/Apache-2.0 | n/a |
| `wasm-bindgen`, `wasm-bindgen-futures`, `web-sys`, `js-sys` | Browser glue: entry point, file futures, `prefers-reduced-motion`, `Date.now()`. | small | rustwasm | MIT/Apache-2.0 | ✔ |
| `winit` (Android only, via eframe) | `AndroidApp` type for the NativeActivity entry point. Its `android-activity` dependency needs the `cc` build helper to compile a tiny JNI glue file – the *only* C-compiling crate in any tree, allowlisted per target (ADR-0003). | – | Active | Apache-2.0 | n/a |

## Test / tooling (not shipped)
`libfuzzer-sys` (fuzz harness only), `cargo-deny`, `cargo-fuzz`, `wasm-bindgen-cli` (pinned to the crate version), `binaryen` (`wasm-opt`, build-time only).

## Build-time note
Cross-compiling to Windows from Linux uses MinGW-w64 **only as a linker** – no C is compiled. Building natively on Windows (MSVC target) needs no extra tools.
