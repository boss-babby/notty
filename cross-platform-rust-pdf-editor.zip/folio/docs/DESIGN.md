# Design doc: Folio

Principles: calm, content-first, native-feeling. Chrome recedes while reading; the page is always the largest element.
Design tokens live in **one file**: `crates/ui/src/tokens.rs` (colour for light/sepia/dark/OLED, 4/8 spacing grid, radii, type scale, elevation, motion). A unit test asserts WCAG AA (≥4.5:1) for every text/background pair in every theme.

## Size classes (window width in dp, not device checks) – `crates/ui/src/layout.rs`
```
COMPACT  < 600dp                MEDIUM  600–840dp               EXPANDED  > 840dp
┌──────────────────┐            ┌─┬────────────────────────┐    ┌────────────────────────────────────────────────┐
│ title  ↶ ↷  (auto│            │ │  ✎ ▭ ◯ T 🖼 − + Fit 🔍 │    │ File Edit View Pages Document Help             │
│ hides while read)│            │ │  (floating, auto-hides)│    ├────────────────────────────────────────────────┤
│                  │            │R│                        │    │ ☰ 📂 💾 ↶ ↷ │ tools … │ − + Fit 🔍 Commands      │
│   ┌──────────┐   │            │a│    ┌────────────┐      │    ├──────────┬───────────────────────┬─────────────┤
│   │  page    │   │            │i│    │   page     │      │    │ Pages    │                       │ Tool        │
│   │ (full    │   │            │l│    │            │      │    │ Outline  │      ┌─────────┐      │ ● ● ● ●     │
│   │  bleed)  │   │            │ │    └────────────┘      │    │ Marks    │      │  page   │      │ Page        │
│   └──────────┘   │            │ │                        │    │ Search   │      └─────────┘      │ Document    │
│            3 / 24│            │ │  [Copy][🖍][U][S] ←sel │    │ (resize) │                       │ (resize)    │
├──────────────────┤            └─┴────────────────────────┘    ├──────────┴───────────────────────┴─────────────┤
│☰ 🔍 ✏ ◐ ⋯  (44dp)│  ← sheets slide up (Nav/Tools/View)         │ Page 3 / 24 · 125% · 1.2 MB · No changes        │
└──────────────────┘                                              └────────────────────────────────────────────────┘
```
- **Compact**: full-bleed page, bottom toolbar (≥44 dp targets), bottom sheets for navigation/tools/view.
- **Medium**: collapsible side panel, scrolling toolbar that auto-hides, contextual selection toolbar floats over the page.
- **Expanded**: menu bar, three resizable panes (thumbnails/outline/marks/search | document | inspector), status bar. (Tabs: not yet.)

## Interaction
Auto-hiding chrome (3 s idle) on compact/medium · command palette `Ctrl/Cmd+K` · pinch / ctrl-wheel zoom anchored at the pointer · drag-pan with momentum · double-click toggles fit/200 % · keyboard: arrows, PgUp/PgDn, Home/End, `Ctrl/Cmd+F/G/D/B/O/S/Z/Y/+/−/0`, `F3` debug overlay.
Motion: all transitions < 250 ms (egui animation time 120 ms), 0 ms when *Reduce motion* is on (also read from `prefers-reduced-motion` on the web).
Accessibility: AccessKit tree for all widgets; the canvas node carries "document, page N of M" plus the page text; full keyboard navigation of chrome via egui focus.
