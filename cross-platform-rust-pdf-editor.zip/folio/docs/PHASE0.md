# Phase 0 report (abridged, honest)

## Toolkit decision: egui (+ eframe, glow backend)
Chosen without running the full six-target spike matrix (time-boxed; recorded as a gap).
| Criterion | egui | Slint | Makepad | Dioxus-native |
|---|---|---|---|---|
| wasm size | ~1 MB | ~0.6 MB | ~2 MB | immature |
| custom canvas (tile painting) | excellent (`Painter::image`) | needs custom renderer hooks | good | immature |
| iOS / Android | works via eframe/winit, rough edges (IME, safe areas) | best (own mobile runtime) | works | not ready |
| IME / text input | weakest part of egui (mobile) | good | improving | – |
| accessibility | AccessKit ✔ | AccessKit ✔ | partial | partial |
| licence | MIT/Apache | GPL / royalty-free / commercial | MIT | MIT/Apache |
**Risk:** egui's mobile text input is the weakest piece; Slint is the fallback if mobile IME proves unacceptable. The UI crate keeps all PDF logic out of widgets, so a toolkit swap touches `crates/ui` only.

## hayro gap analysis (what was actually tested)
Tested: generated documents (text, links, outline, annotations with `/AP`), AES-256 (R6) encrypted output of our own writer, 200 deterministic byte-mutations + truncations (no panics; each job is also wrapped in `catch_unwind`).
Known gaps from hayro's own README (not independently verified here): blending/isolation, knockout groups, colour-key masking. Embedded fonts only cover the 14 standard fonts: **CJK fallback fonts are not embedded**.
Not tested: the 200-PDF corpus (pdf.js/PDFBox sets) – run `folio-corpus <dir>` on it; the harness prints per-file failures and timings.

## Risks
1. wasm engine on the UI thread (ADR-0004). 2. Mobile builds unverified. 3. lopdf loads whole files for editing (fine for ≤ ~100 MB; huge files should edit incrementally – future work). 4. Digital signatures need an RFC 3161/CMS implementation on RustCrypto (`cms`, `x509-cert`) – not started.
