# Performance – measured vs. budget (Linux x86-64 sandbox, 4 vCPU, release build)

| Budget | Result | Verdict |
|---|---|---|
| 1,000-page file opens < 500 ms | see `folio-corpus --bench 1000` output below | measured on a *generated* text-only file; real-world 1,000-page files have bigger page trees/xrefs – re-measure on your corpus |
| First page visible < 100 ms (10 MB PDF) | first-tile time printed by `--bench`; real 10 MB file **not measured** | partial |
| Desktop cold start < 300 ms | **not measured** (no display in the sandbox) | unmeasured |
| 60/120 fps scroll & zoom | **not measured** (needs a GPU/display); design supports it (preview tile first, ≤1 tile/frame on wasm, worker thread natively) | unmeasured |
| RSS on 500 pages < 150 MB / 80 MB mobile | tile cache is capped at 72 MB desktop / 48 MB web / 32 MB mobile; total RSS **not measured** | unmeasured |
| Desktop binary < 15 MB | `Folio.exe` = **16.7 MB** (release, thin LTO, stripped) | ❌ **over budget by ~1.7 MB** – next steps: `opt-level="s"` for `ui`/`lopdf`, `panic="abort"`, drop `image` jpeg, `upx` is not an option (AV false positives) |
| wasm < 3 MB gzipped | **3.81 MB gzipped** (11.2 MB raw after `wasm-opt -Oz`) | ❌ **over budget by ~0.8 MB** – biggest contributors are hayro's SIMD-dispatch code (`fearless_simd`), embedded standard fonts and egui; fixes: split PDF engine into a lazily loaded second wasm module (Web Worker – ADR-0004), `opt-level="z"`, `-C target-feature=+simd128` to cut dispatch variants |
| Memory manager (budget, LRU, pinning, shrink) | unit-tested (`folio-store`) | ✅ |
| Debug overlay | implemented (F3) | ✅ |

Run `cargo run --release -p folio-corpus -- --bench 1000` to reproduce the first rows.
generated 1000-page document: 562 KB in 17 ms
BENCH 1000 pages: open 3 ms, first tile 2 ms, 154 chars of text on page 1
