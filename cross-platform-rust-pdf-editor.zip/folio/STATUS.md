# Status – what is real, what is partial, what is not done

Legend: ✅ implemented and covered by tests · 🟡 partial · ⛔ not done · 🧪 code written, not buildable/verifiable here

## Targets
| Target | State |
|---|---|
| Windows x64 | ✅ builds (`scripts/build-windows.sh`, GNU cross-build; MSVC build is the same crate). Not executed on a real Windows machine in this environment. |
| WebAssembly | ✅ builds, bundled in the website (`/viewer`) |
| Linux / macOS | 🟡 same `folio-desktop` crate; not built here (needs system GL/Wayland/X11 dev packages) |
| Android | 🧪 entry point + memory-trim hook written; needs NDK + `cargo-apk`/`cargo-ndk`; **never built** |
| iOS | 🧪 static-lib entry point written; needs Xcode; **never built** |

## Tiers
**T1 Read** ✅ fast open (lazy xref via hayro), continuous / single / two-page, zoom (pinch, ctrl-wheel, buttons, fit), tile renderer with instant low-res preview then refinement, text search across the document, selection + copy, outline, thumbnails, links (internal + http/https/mailto only), go-to-page, bookmarks, recent files, light/sepia/dark/OLED modes, password-protected files.
🟡 selection works within one page; single-page mode does not flip pages on wheel overscroll; no rubber-band overscroll; CJK text needs a CJK font that is not embedded (size budget) so CJK pages without embedded fonts render without glyphs.

**T2 Annotate** ✅ highlight, underline, strikeout, ink (touch force → width), notes, rectangle, ellipse, stamps, text boxes, each written with a real `/AP` appearance stream; AcroForm text fields can be listed, filled and flattened. 🟡 no checkbox/radio/choice editing, no in-canvas form widgets; stylus *pressure* only where egui reports touch force; no palm rejection beyond what the OS does.
**T3 Organize** ✅ merge, split (zip), extract ranges, reorder, rotate, delete, insert blank/image pages, compress, metadata, AES-256 protect / unlock (self-checked after encrypt). Every output is re-parsed before it is offered for saving; annotation-only edits are saved as **incremental updates** (original bytes untouched; classic and xref-stream files).
**T4 Advanced** ✅ redaction by *page rasterisation* (true removal: text/vectors/links of that page no longer exist; text layer of that page is lost – by design), image signatures / pictures (PNG with alpha, JPEG), text boxes, export page → PNG. ⛔ digital (PKCS#7/CMS) signatures, moving/resizing existing annotations after creation, tabs (single document per window).
**T5** ⛔ not started (text-run editing, OCR hooks).

## Cross-cutting
- ✅ Off-UI-thread rendering on native (worker thread, cancellation by queue replacement). 🟡 **wasm runs the engine cooperatively on the UI thread, one tile per frame** (no Web Worker yet – ADR-0004). Large pages can still drop frames on the web build.
- ✅ Memory manager (byte-budgeted LRU, pinning, shrink-on-warning API). 🧪 Android `onTrimMemory` / iOS warning *wiring* is not done (`folio_ui::memory_warning` exists).
- ✅ Debug overlay (F3). ✅ Command palette (Ctrl/Cmd+K). ✅ Size classes + design tokens + WCAG AA test for all four themes.
- 🟡 Accessibility: egui→AccessKit tree for all UI, plus the current page's text exposed on the canvas node; no per-glyph text-layer tree. RTL layout: ⛔ (egui limitation). System accent colour / system font: ⛔.
- ✅ No-C check (`scripts/check-no-c-deps.sh`) + `deny.toml`. ✅ Fuzz harness (`fuzz/`, needs nightly + cargo-fuzz; **not run here**). ✅ Mutation smoke test (`folio-corpus`).

## Phase 0 – honest account
Not done as specified: no multi-toolkit spike matrix on six targets, and the 200-PDF corpus was **not available offline**, so hayro was not scored on it. What was done instead is in `docs/PHASE0.md`.

## Budget misses (flagged, not hidden)
- **wasm: 3.81 MB gzipped** (budget 3 MB). **Windows exe: 16.7 MB** (budget 15 MB). Details and next steps in `docs/PERF.md`.
- Cold start, fps, RSS: **not measured** in this environment (no display). Only open/first-tile timings were measured (`folio-corpus --bench`).
