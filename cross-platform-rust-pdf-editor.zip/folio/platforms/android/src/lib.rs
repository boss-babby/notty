//! Android entry point (NativeActivity). Compiles to an empty crate on other targets.
//! NOTE: not built in this repository's CI sandbox – see STATUS.md ("unverified targets").
#![cfg(target_os = "android")]

use winit::platform::android::activity::AndroidApp;

#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let _ = eframe::run_native(folio_ui::APP_NAME, options, Box::new(|cc| Ok(Box::new(folio_ui::FolioApp::new(cc, None)))));
}
