//! WebAssembly entry point: `new FolioWeb().start("canvas-id")` from JavaScript.
#![cfg(target_arch = "wasm32")]

use wasm_bindgen::prelude::*;
use wasm_bindgen::JsCast;

#[wasm_bindgen]
pub struct FolioWeb {
    runner: eframe::WebRunner,
}

#[wasm_bindgen]
impl FolioWeb {
    #[wasm_bindgen(constructor)]
    #[allow(clippy::new_without_default)]
    pub fn new() -> FolioWeb {
        FolioWeb { runner: eframe::WebRunner::new() }
    }

    /// Mount the app on the `<canvas>` with the given id.
    pub async fn start(&self, canvas_id: &str) -> Result<(), JsValue> {
        let document = web_sys::window().and_then(|w| w.document()).ok_or_else(|| JsValue::from_str("no document"))?;
        let canvas = document
            .get_element_by_id(canvas_id)
            .ok_or_else(|| JsValue::from_str("canvas element not found"))?
            .dyn_into::<web_sys::HtmlCanvasElement>()?;
        self.runner
            .start(canvas, eframe::WebOptions::default(), Box::new(|cc| Ok(Box::new(folio_ui::FolioApp::new(cc, None)))))
            .await
    }

    pub fn destroy(&self) {
        self.runner.destroy();
    }
}
