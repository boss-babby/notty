//! iOS entry point: a static library exposing `folio_ios_main`, called from a minimal host `main.m`.
//! NOTE: not built in this repository's CI sandbox – see STATUS.md ("unverified targets").
#![cfg(target_os = "ios")]

#[unsafe(no_mangle)]
pub extern "C" fn folio_ios_main() {
    let options = eframe::NativeOptions::default();
    let _ = eframe::run_native(folio_ui::APP_NAME, options, Box::new(|cc| Ok(Box::new(folio_ui::FolioApp::new(cc, None)))));
}
