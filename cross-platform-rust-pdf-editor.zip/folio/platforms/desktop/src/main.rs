//! Windows / macOS / Linux entry point. Thin adapter: window options, CLI path, drag-and-drop.
#![cfg_attr(all(not(debug_assertions), target_os = "windows"), windows_subsystem = "windows")]

use eframe::egui;

fn main() -> eframe::Result {
    let path = std::env::args().nth(1);
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title(folio_ui::APP_NAME)
            .with_inner_size([1280.0, 820.0])
            .with_min_inner_size([360.0, 480.0])
            .with_drag_and_drop(true),
        ..Default::default()
    };
    eframe::run_native(folio_ui::APP_NAME, options, Box::new(move |cc| Ok(Box::new(folio_ui::FolioApp::new(cc, path)))))
}
