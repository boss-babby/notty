#!/usr/bin/env bash
# Build the WebAssembly bundle and drop it where the Next.js site serves it (public/wasm).
# Requires: rustup target wasm32-unknown-unknown, wasm-bindgen-cli == the wasm-bindgen crate version in Cargo.lock,
#           binaryen's wasm-opt (optional, shrinks the bundle).
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${1:-../public/wasm}"
cargo build -p folio-web --target wasm32-unknown-unknown --profile web
WASM="${CARGO_TARGET_DIR:-target}/wasm32-unknown-unknown/web/folio_web.wasm"
mkdir -p "$OUT"
wasm-bindgen --target web --no-typescript --out-dir "$OUT" --out-name folio "$WASM"
if command -v wasm-opt >/dev/null; then
  wasm-opt -Oz --all-features "$OUT/folio_bg.wasm" -o "$OUT/folio_bg.opt.wasm" && mv "$OUT/folio_bg.opt.wasm" "$OUT/folio_bg.wasm" || echo "wasm-opt failed – shipping unoptimised wasm"
fi
ls -l "$OUT"
gzip -9 -c "$OUT/folio_bg.wasm" | wc -c | awk '{printf "wasm gzipped: %.2f MB\n", $1/1048576}'
