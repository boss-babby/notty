#!/usr/bin/env bash
# Fails if the dependency tree of any shipped target contains a crate that builds C/C++ code:
#   * `cc`, `cmake`, `bindgen`, `pkg-config`, `vcpkg` build helpers
#   * any `*-sys` crate that is not on the explicit platform-binding allowlist
# Usage: scripts/check-no-c-deps.sh [target-triple ...]   (default: wasm32 + windows-gnu/msvc + android + ios + macOS)
set -euo pipefail
cd "$(dirname "$0")/.."
# Platform-binding allowlist (thin FFI declarations, no C compiled): Microsoft `windows*` crates, js/web-sys, Objective-C
# runtime bindings, JNI/NDK declarations. Every entry must be justified in DEPS.md.
ALLOW_SYS='^(windows([-_].*)?|js-sys|web-sys|objc-sys|objc2-.*|jni-sys|ndk-sys|core-foundation-sys|wayland-sys|x11-dl)$'
# Build helpers that are tolerated ONLY for a given target, because a platform *glue* crate needs them (see ADR-0003).
declare -A ALLOW_BUILD_FOR=( [aarch64-linux-android]='cc' )
BANNED_BUILD='^(cc|cmake|bindgen|pkg-config|vcpkg|autocfg-c|cxx-build|cxx|zstd-sys|libz-sys|openssl-sys|freetype-sys|harfbuzz-sys|pdfium-render|mupdf-sys|poppler|cairo-sys-rs|ring)$'
TARGETS=("$@")
[ ${#TARGETS[@]} -eq 0 ] && TARGETS=(wasm32-unknown-unknown x86_64-pc-windows-gnu x86_64-pc-windows-msvc aarch64-linux-android aarch64-apple-ios aarch64-apple-darwin)
fail=0
for t in "${TARGETS[@]}"; do
  names=$(cargo metadata --format-version 1 --filter-platform "$t" 2>/dev/null | python3 -c '
import json,sys
m=json.load(sys.stdin)
ids={n["id"] for n in m["resolve"]["nodes"]}
print("\n".join(sorted({p["name"] for p in m["packages"] if p["id"] in ids})))')
  bad=$(echo "$names" | grep -E "$BANNED_BUILD" || true)
  if [ -n "${ALLOW_BUILD_FOR[$t]:-}" ]; then bad=$(echo "$bad" | grep -Ev "^(${ALLOW_BUILD_FOR[$t]})$" || true); fi
  sys=$(echo "$names" | grep -E -- '-sys$|^windows[-_]' | grep -Ev "$ALLOW_SYS" || true)
  if [ -n "$bad$sys" ]; then
    echo "✘ $t: forbidden crates:"; printf "%s\n%s\n" "$bad" "$sys" | sort -u | grep -v "^$" | sed 's/^/    /'; fail=1
  else
    echo "✔ $t: no C-building crates ($(echo "$names" | wc -l) crates checked)"
  fi
done
exit $fail
