#!/usr/bin/env bash
# Windows x64 build. On Linux/macOS: cross-compiles with the GNU target (MinGW only used as a linker).
# On a Windows host run:  cargo build -p folio-desktop --release   (msvc toolchain, no extra tools needed).
set -euo pipefail
cd "$(dirname "$0")/.."
cargo build -p folio-desktop --release --target x86_64-pc-windows-gnu
EXE="${CARGO_TARGET_DIR:-target}/x86_64-pc-windows-gnu/release/folio.exe"
OUT="${1:-dist}"
mkdir -p "$OUT"
cp "$EXE" "$OUT/Folio.exe"
ls -l "$OUT/Folio.exe"
