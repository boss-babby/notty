#![no_main]
use libfuzzer_sys::fuzz_target;

fuzz_target!(|data: &[u8]| {
    if let Ok(mut s) = folio_edit::Session::load(data, "") {
        let _ = s.execute(folio_edit::RotatePage::new(0, 90));
        let _ = s.to_bytes();
    }
});
