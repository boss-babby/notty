#![no_main]
// cargo +nightly fuzz run open_render   (libFuzzer is the only non-Rust piece and lives in the fuzz harness only)
use folio_render::{Engine, Filter, Request, TileKey};
use libfuzzer_sys::fuzz_target;
use std::sync::Arc;

fuzz_target!(|data: &[u8]| {
    let mut e = Engine::new();
    e.push(Request::Open { epoch: 1, bytes: Arc::new(data.to_vec()), password: String::new() });
    while e.step().is_some() {}
    e.push(Request::Wanted(vec![TileKey { page: 0, zoom_milli: 500, col: 0, row: 0, filter: Filter::None, rev: 0 }]));
    e.push(Request::Text(vec![0]));
    while e.step().is_some() {}
    let _ = folio_core::extract_nav(data, "");
});
