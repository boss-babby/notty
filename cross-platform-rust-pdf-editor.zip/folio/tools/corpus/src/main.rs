//! Corpus runner. `folio-corpus <dir> [--strict]` opens every *.pdf under <dir>, renders page 1,
//! extracts its text and reports failures + timings. With no argument it self-tests on generated
//! documents and byte-mutated copies (parser must never panic).
use folio_render::{Engine, Filter, Request, Response, TileKey};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Instant;

fn walk(dir: &Path, out: &mut Vec<PathBuf>) {
    if let Ok(rd) = std::fs::read_dir(dir) {
        for e in rd.flatten() {
            let p = e.path();
            if p.is_dir() {
                walk(&p, out);
            } else if p.extension().is_some_and(|x| x.eq_ignore_ascii_case("pdf")) {
                out.push(p);
            }
        }
    }
}

#[derive(Debug)]
enum Outcome {
    Ok { pages: usize, open_ms: u128, first_page_ms: u128, chars: usize },
    NeedsPassword,
    Failed(String),
}

fn run_one(bytes: Vec<u8>) -> Outcome {
    let r = std::panic::catch_unwind(|| {
        let mut e = Engine::new();
        let t0 = Instant::now();
        e.push(Request::Open { epoch: 1, bytes: Arc::new(bytes), password: String::new() });
        let info = match e.step() {
            Some(Response::Opened { result: Ok(i), .. }) => i,
            Some(Response::Opened { result: Err(folio_core::OpenError::NeedPassword), .. }) => return Outcome::NeedsPassword,
            Some(Response::Opened { result: Err(err), .. }) => return Outcome::Failed(err.to_string()),
            _ => return Outcome::Failed("no response".into()),
        };
        let open_ms = t0.elapsed().as_millis();
        let t1 = Instant::now();
        e.push(Request::Wanted(vec![TileKey { page: 0, zoom_milli: 1000, col: 0, row: 0, filter: Filter::None, rev: 0 }]));
        match e.step() {
            Some(Response::Tile(_)) => {}
            _ => return Outcome::Failed("first page failed to render".into()),
        }
        let first_page_ms = t1.elapsed().as_millis();
        e.push(Request::Text(vec![0]));
        let chars = match e.step() {
            Some(Response::Text { text, .. }) => text.chars.len(),
            _ => 0,
        };
        Outcome::Ok { pages: info.pages.len(), open_ms, first_page_ms, chars }
    });
    r.unwrap_or_else(|_| Outcome::Failed("PANIC".into()))
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let strict = args.iter().any(|a| a == "--strict");
    if let Some(i) = args.iter().position(|a| a == "--bench") {
        let n: usize = args.get(i + 1).and_then(|v| v.parse().ok()).unwrap_or(1000);
        let t = Instant::now();
        let bytes = folio_core::sample::sample_pdf(n);
        println!("generated {n}-page document: {} KB in {} ms", bytes.len() / 1024, t.elapsed().as_millis());
        match run_one(bytes) {
            Outcome::Ok { pages, open_ms, first_page_ms, chars } => println!("BENCH {pages} pages: open {open_ms} ms, first tile {first_page_ms} ms, {chars} chars of text on page 1"),
            other => println!("BENCH failed: {other:?}"),
        }
        return;
    }
    let mut failures = 0usize;
    let mut total = 0usize;
    let mut files: Vec<(String, Vec<u8>)> = Vec::new();
    match args.iter().find(|a| !a.starts_with("--")) {
        Some(dir) => {
            let mut paths = Vec::new();
            walk(Path::new(dir), &mut paths);
            paths.sort();
            for p in paths {
                if let Ok(b) = std::fs::read(&p) {
                    files.push((p.display().to_string(), b));
                }
            }
        }
        None => {
            let base = folio_core::sample::sample_pdf(8);
            files.push(("generated/sample-8p".into(), base.clone()));
            files.push(("generated/protected".into(), folio_edit::protect(&base, "", "pw", "").unwrap_or_default()));
            // deterministic byte-mutation smoke test: parsers must never panic
            let mut seed = 0x9E37_79B9u32;
            for i in 0..200 {
                let mut m = base.clone();
                for _ in 0..(1 + i % 8) {
                    seed = seed.wrapping_mul(1664525).wrapping_add(1013904223);
                    let at = (seed as usize) % m.len();
                    m[at] = (seed >> 24) as u8;
                }
                if i % 5 == 0 {
                    m.truncate(m.len() * (i % 100 + 1) / 101);
                }
                files.push((format!("mutated/{i:03}"), m));
            }
        }
    }
    for (name, bytes) in files {
        total += 1;
        let size = bytes.len();
        match run_one(bytes) {
            Outcome::Ok { pages, open_ms, first_page_ms, chars } => println!("OK    {name}  {pages} pages  open {open_ms} ms  page1 {first_page_ms} ms  {chars} chars  ({size} B)"),
            Outcome::NeedsPassword => println!("PASS  {name}  (password required)"),
            Outcome::Failed(e) => {
                // Mutated files are *expected* to fail to open – only a PANIC is a bug.
                let is_bug = e == "PANIC";
                if is_bug || (!name.starts_with("mutated/") && strict) {
                    failures += 1;
                }
                println!("{}  {name}  {e}", if is_bug { "PANIC" } else { "FAIL " });
            }
        }
    }
    println!("\n{total} files, {failures} hard failures");
    if failures > 0 {
        std::process::exit(1);
    }
}
