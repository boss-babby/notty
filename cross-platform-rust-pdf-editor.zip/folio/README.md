# Folio – a lightweight PDF reader & editor in pure Rust

One Cargo workspace, one responsive UI (egui), thin platform shells. No PDFium / MuPDF / Poppler / Cairo / FreeType / HarfBuzz / OpenSSL.
**Read `STATUS.md` first** – it says exactly what is done, partial, and unverified.

```
crates/core-pdf   open/validate, page geometry, outline + links (hayro-syntax, lopdf)
crates/render     tile renderer (hayro + vello_cpu), render service: worker thread (native) / cooperative (wasm)
crates/text       glyph boxes, reading order, search, selection
crates/edit       reversible commands + undo/redo, annotations (/AP), pages, forms, redaction, encryption, safe saving
crates/store      byte-budget LRU caches, recents / bookmarks / settings
crates/ui         design tokens, size classes, viewer, gestures, command palette
platforms/        desktop (Win/macOS/Linux) · web (wasm-bindgen) · android · ios
tools/corpus      corpus runner + mutation smoke test      fuzz/   cargo-fuzz targets
scripts/          build-web.sh · build-windows.sh · check-no-c-deps.sh
docs/             DESIGN.md · PHASE0.md · adr/
```

## Build
Prerequisite for every target: Rust stable (`rustup`), see `rust-toolchain.toml`.

| Target | Command | Notes |
|---|---|---|
| **Windows** (on Windows) | `cargo build -p folio-desktop --release` | MSVC toolchain; output `target\release\folio.exe` |
| **Windows** (cross, Linux/macOS) | `rustup target add x86_64-pc-windows-gnu && scripts/build-windows.sh` | needs `x86_64-w64-mingw32-gcc` as *linker only* (`apt install gcc-mingw-w64-x86-64`) |
| **macOS / Linux** | `cargo build -p folio-desktop --release` | Linux: `pkg-config libwayland-dev libxkbcommon-dev libgl1-mesa-dev` |
| **WebAssembly** | `rustup target add wasm32-unknown-unknown && cargo install wasm-bindgen-cli --version 0.2.130 --locked && scripts/build-web.sh <outdir>` | the version must equal `wasm-bindgen` in `Cargo.lock`; `wasm-opt` (binaryen) optional. Serve `<outdir>` + `viewer-app/index.html` from any static host. |
| **Android** | `cargo install cargo-ndk && cargo ndk -t arm64-v8a build -p folio-android --release` then package with `cargo-apk`/Gradle | 🧪 never built |
| **iOS** | `cargo build -p folio-ios --release --target aarch64-apple-ios`, link the static lib into a minimal Xcode app calling `folio_ios_main()` | 🧪 never built |

## Test / verify
```
cargo test --workspace --exclude folio-android --exclude folio-ios      # unit + integration (render, edit, text, store, ui layout/tokens)
cargo run --release -p folio-corpus                                      # mutation smoke test; or: folio-corpus <dir-of-pdfs> --strict
scripts/check-no-c-deps.sh                                               # fails on cc/cmake/*-sys outside the allowlist
cargo deny check                                                         # licences, advisories, bans
cargo +nightly fuzz run open_render --fuzz-dir fuzz                      # needs cargo-fuzz
```

## Using the app
`Ctrl/Cmd+K` command palette · `Ctrl/Cmd+O/S/F/G/D/B/Z/Y` · `+ − 0` zoom · pinch / ctrl-wheel · `F3` debug overlay (fps, frame time, RSS, cache hit-rate, queue) · drop a PDF on the window.
Edits are applied to a working copy; *Save* appends an incremental update to the original (or rewrites + validates when that is not possible); *Save a copy…* always asks for a location.

## Performance budgets
Measured numbers (and the ones we could not measure) are in `docs/PERF.md`.
