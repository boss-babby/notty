//! Automation: rules ("when … if … then …"), buttons, schedules, reminders and repeat rules — one engine for the whole app.
//!
//! Design (read this before extending):
//! * **Data** — a [`Rule`] is plain serde data stored in the workspace (`Workspace::auto`), so it is part of every backup and
//!   will sync with the future cloud unchanged. JSON in = JSON out, which is also how an assistant will create rules
//!   (see [`spec_json`]).
//! * **Triggers** are *observed*, not hooked: [`tick`] diffs the rows of the workspace against the previous frame, so any
//!   source of change (typing in a cell, a drag on the board, an import, a script, later the cloud) produces the same events.
//! * **Actions** (`Step`) and **scripts** run through one path, [`WsHost`]: visual steps are thin wrappers over the same
//!   functions a script can call (`set`, `create_row`, `notify` …). Anything the UI can do, a script can do.
//! * **Safety** — rules never retrigger themselves, chained rules are limited, scripts have a step budget, every run is
//!   written to a log, and a "Test" run works on a copy of the workspace.
//! * Properties are addressed **by name** (case-insensitive) so rules are readable, portable between databases and easy to
//!   generate.

use std::collections::{BTreeMap, HashMap, HashSet};

use serde::{Deserialize, Serialize};

use crate::dates;
use crate::model::{Database, Opt, PageKind, Prop, PropKind, Val, Workspace};
use crate::recur::{self, Repeat};
use crate::script::{self, Host, Value};

const DAY_MS: f64 = 86_400_000.0;

// ───────────────────────────── data model ─────────────────────────────

#[derive(Clone, Serialize, Deserialize, Default)]
pub struct Store {
    pub rules: Vec<Rule>,
    #[serde(default)]
    pub next_id: u64,
    /// Keys of reminders that already fired (ring buffer, newest last).
    #[serde(default)]
    pub fired: Vec<String>,
    /// Run history (newest last, capped).
    #[serde(default)]
    pub log: Vec<LogEntry>,
    /// Global kill switch.
    #[serde(default)]
    pub paused: bool,
}

#[derive(Clone, Serialize, Deserialize)]
pub struct Rule {
    pub id: u64,
    pub name: String,
    pub enabled: bool,
    #[serde(default)]
    pub scope: Scope,
    pub trigger: Trigger,
    #[serde(default)]
    pub conditions: Vec<Cond>,
    /// Optional script expression that must be true (e.g. `row.Due < today() and row.Priority == "High"`).
    #[serde(default)]
    pub when: String,
    #[serde(default)]
    pub steps: Vec<Step>,
    #[serde(default)]
    pub runs: u32,
    /// UTC ms of the last run (0 = never).
    #[serde(default)]
    pub last_run: f64,
    #[serde(default)]
    pub last_error: String,
    #[serde(default)]
    pub created: f64,
    #[serde(default)]
    pub note: String,
}

#[derive(Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Debug, Default)]
pub enum Scope {
    /// Rows of every database.
    #[default]
    Workspace,
    /// Rows of this database (page id).
    Database(u64),
}

#[derive(Clone, PartialEq, Serialize, Deserialize, Debug)]
pub enum Trigger {
    /// A row was added (fires ~1 s later so a title typed right away is already there).
    RowAdded,
    /// A property changed. `prop` empty = any property; `to` empty = any value (otherwise the new value, e.g. "Done").
    PropChanged { prop: String, to: String },
    /// Run by hand: a button block, the row menu, the command palette or the Run button.
    Button,
    Schedule(Sched),
    /// A date property arrives, `days_before` days earlier, at `time` (HH:MM) — the reminder trigger.
    DateReached { prop: String, days_before: i32, time: String },
    /// Once, when the app starts.
    AppOpened,
}

#[derive(Clone, PartialEq, Serialize, Deserialize, Debug)]
pub enum Sched {
    Every { minutes: u32 },
    Daily { time: String },
    /// `days`: bit 0 = Monday … bit 6 = Sunday.
    Weekly { days: u8, time: String },
    Monthly { day: u8, time: String },
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct Cond {
    pub prop: String,
    pub op: CondOp,
    #[serde(default)]
    pub value: String,
}

#[derive(Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Debug)]
pub enum CondOp {
    Is,
    IsNot,
    Contains,
    Empty,
    NotEmpty,
    Greater,
    Less,
}

impl CondOp {
    pub const ALL: [CondOp; 7] = [CondOp::Is, CondOp::IsNot, CondOp::Contains, CondOp::Empty, CondOp::NotEmpty, CondOp::Greater, CondOp::Less];
    pub fn label(self) -> &'static str {
        match self {
            CondOp::Is => "is",
            CondOp::IsNot => "is not",
            CondOp::Contains => "contains",
            CondOp::Empty => "is empty",
            CondOp::NotEmpty => "is not empty",
            CondOp::Greater => "is after / greater than",
            CondOp::Less => "is before / less than",
        }
    }
    pub fn needs_value(self) -> bool {
        !matches!(self, CondOp::Empty | CondOp::NotEmpty)
    }
}

/// An action. Text fields are *templates*: `{row.Status}`, `{title}`, `{add_days(today(), 3)}` are evaluated by Lumen Script.
#[derive(Clone, PartialEq, Serialize, Deserialize, Debug)]
pub enum Step {
    /// Set a property of the row. Dates accept `today`, `tomorrow`, `+3d`, `next monday`. Missing properties are created.
    SetProp { prop: String, value: String },
    /// Add a row to a database (`db` empty = the row's own database).
    CreateRow { db: String, title: String, props: Vec<(String, String)> },
    /// Move the row to another database (properties with the same name and type are kept).
    MoveRow { db: String },
    /// Add a block of text to a page (`page` empty = this page).
    AddBlock { page: String, text: String, kind: String },
    Notify { title: String, body: String },
    /// Move a date property to its next occurrence and reset the status (recurring tasks).
    RepeatDate { prop: String, rule: String, from_done: bool, reset_prop: String, reset_value: String },
    /// Move the row to the trash.
    Trash,
    /// Any Lumen Script.
    Script { code: String },
}

#[derive(Clone, Serialize, Deserialize)]
pub struct LogEntry {
    pub ts: f64,
    pub rule: u64,
    pub name: String,
    pub ok: bool,
    pub msg: String,
}

impl Store {
    pub fn rule(&self, id: u64) -> Option<&Rule> {
        self.rules.iter().find(|r| r.id == id)
    }
    pub fn rule_mut(&mut self, id: u64) -> Option<&mut Rule> {
        self.rules.iter_mut().find(|r| r.id == id)
    }
    pub fn add(&mut self, mut r: Rule) -> u64 {
        self.next_id += 1;
        r.id = self.next_id.max(self.rules.iter().map(|x| x.id).max().unwrap_or(0) + 1);
        self.next_id = r.id;
        if r.created == 0.0 {
            r.created = crate::auth::now_ms();
        }
        if r.last_run == 0.0 {
            // a new schedule starts counting from now: it must not "catch up" for the past
            r.last_run = crate::auth::now_ms();
        }
        let id = r.id;
        self.rules.push(r);
        id
    }
    pub fn remove(&mut self, id: u64) {
        self.rules.retain(|r| r.id != id);
    }
    pub fn push_log(&mut self, e: LogEntry) {
        self.log.push(e);
        if self.log.len() > 150 {
            let n = self.log.len() - 150;
            self.log.drain(..n);
        }
    }
    pub fn enabled(&self) -> usize {
        self.rules.iter().filter(|r| r.enabled).count()
    }
    /// Rules that can be run by hand (buttons) and apply to rows of `db` (or everywhere).
    pub fn manual_for(&self, db: Option<u64>) -> Vec<&Rule> {
        self.rules
            .iter()
            .filter(|r| r.enabled && r.trigger == Trigger::Button)
            .filter(|r| match (r.scope, db) {
                (Scope::Database(d), Some(x)) => d == x,
                (Scope::Database(_), None) => false,
                _ => true,
            })
            .collect()
    }
}

impl Rule {
    pub fn blank(name: &str, trigger: Trigger) -> Rule {
        Rule { id: 0, name: name.into(), enabled: true, scope: Scope::Workspace, trigger, conditions: vec![], when: String::new(), steps: vec![], runs: 0, last_run: 0.0, last_error: String::new(), created: 0.0, note: String::new() }
    }

    pub fn applies_to_db(&self, db: Option<u64>) -> bool {
        match (self.scope, db) {
            (Scope::Workspace, _) => true,
            (Scope::Database(d), Some(x)) => d == x,
            _ => false,
        }
    }

    pub fn trigger_text(&self) -> String {
        match &self.trigger {
            Trigger::RowAdded => "A row is added".into(),
            Trigger::PropChanged { prop, to } => match (prop.is_empty(), to.is_empty()) {
                (true, _) => "Anything changes".into(),
                (false, true) => format!("{prop} changes"),
                (false, false) => format!("{prop} becomes {to}"),
            },
            Trigger::Button => "Button is pressed".into(),
            Trigger::Schedule(s) => sched_text(s),
            Trigger::DateReached { prop, days_before, time } => match days_before {
                0 => format!("{prop} arrives, at {time}"),
                n if *n > 0 => format!("{n} day{} before {prop}, at {time}", if *n == 1 { "" } else { "s" }),
                n => format!("{} day{} after {prop}, at {time}", -n, if *n == -1 { "" } else { "s" }),
            },
            Trigger::AppOpened => "The app opens".into(),
        }
    }

    pub fn summary(&self) -> String {
        let steps: Vec<String> = self.steps.iter().map(|s| s.short()).collect();
        format!("When {} → {}", self.trigger_text().to_lowercase_first(), if steps.is_empty() { "nothing yet".into() } else { steps.join(", ") })
    }
}

trait LowerFirst {
    fn to_lowercase_first(&self) -> String;
}
impl LowerFirst for String {
    fn to_lowercase_first(&self) -> String {
        let mut c = self.chars();
        match c.next() {
            Some(f) if self.chars().nth(1).map_or(true, |s| !s.is_uppercase()) => f.to_lowercase().collect::<String>() + c.as_str(),
            _ => self.clone(),
        }
    }
}

pub fn sched_text(s: &Sched) -> String {
    match s {
        Sched::Every { minutes } if *minutes % 60 == 0 && *minutes >= 60 => format!("Every {} hour{}", minutes / 60, if *minutes == 60 { "" } else { "s" }),
        Sched::Every { minutes } => format!("Every {minutes} minutes"),
        Sched::Daily { time } => format!("Every day at {time}"),
        Sched::Weekly { days, time } => {
            if *days == Repeat::WEEKDAYS {
                format!("Every weekday at {time}")
            } else {
                let names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
                let d: Vec<&str> = (0..7).filter(|i| days & (1 << i) != 0).map(|i| names[i]).collect();
                format!("Every {} at {time}", d.join(", "))
            }
        }
        Sched::Monthly { day, time } => format!("Monthly on day {day} at {time}"),
    }
}

impl Step {
    pub fn short(&self) -> String {
        match self {
            Step::SetProp { prop, value } => format!("set {prop} to {}", if value.is_empty() { "empty" } else { value }),
            Step::CreateRow { db, title, .. } => format!("add \"{title}\" to {}", if db.is_empty() { "this database" } else { db }),
            Step::MoveRow { db } => format!("move to {db}"),
            Step::AddBlock { text, .. } => format!("add note \"{}\"", text.chars().take(24).collect::<String>()),
            Step::Notify { title, .. } => format!("notify \"{title}\""),
            Step::RepeatDate { prop, rule, .. } => format!("repeat {prop} ({})", Repeat::parse(rule).map(|r| r.describe().to_lowercase()).unwrap_or_else(|| rule.clone())),
            Step::Trash => "move to trash".into(),
            Step::Script { code } => format!("run script ({} lines)", code.lines().count()),
        }
    }

    pub fn kind_label(&self) -> &'static str {
        match self {
            Step::SetProp { .. } => "Set property",
            Step::CreateRow { .. } => "Add row",
            Step::MoveRow { .. } => "Move row",
            Step::AddBlock { .. } => "Add note",
            Step::Notify { .. } => "Notify",
            Step::RepeatDate { .. } => "Repeat date",
            Step::Trash => "Move to trash",
            Step::Script { .. } => "Script",
        }
    }

    /// The same step as Lumen Script — "convert to script" in the editor, and the reference for assistants.
    pub fn to_script(&self) -> String {
        let q = |s: &str| format!("\"{}\"", s.replace('\\', "\\\\").replace('"', "\\\""));
        match self {
            Step::SetProp { prop, value } => format!("set(row, {}, {})", q(prop), q(value)),
            Step::CreateRow { db, title, props } => {
                let mut fields = vec![format!("title: {}", q(title))];
                fields.extend(props.iter().map(|(k, v)| format!("{}: {}", q(k), q(v))));
                format!("create_row({}, {{{}}})", if db.is_empty() { "row.db".into() } else { q(db) }, fields.join(", "))
            }
            Step::MoveRow { db } => format!("move_row(row, {})", q(db)),
            Step::AddBlock { page, text, kind } => format!("append({}, {}, {})", if page.is_empty() { "row".into() } else { q(page) }, q(text), q(if kind.is_empty() { "text" } else { kind })),
            Step::Notify { title, body } => format!("notify({}, {})", q(title), q(body)),
            Step::RepeatDate { prop, rule, from_done, reset_prop, reset_value } => {
                let mut s = format!("repeat_date(row, {}, {}, {})", q(prop), q(rule), from_done);
                if !reset_prop.is_empty() {
                    s.push_str(&format!("\nset(row, {}, {})", q(reset_prop), q(reset_value)));
                }
                s
            }
            Step::Trash => "trash(row)".into(),
            Step::Script { code } => code.clone(),
        }
    }
}

// ───────────────────────────── effects & host ─────────────────────────────

/// Things a run asks the app to do (the engine itself has no UI).
#[derive(Clone, Debug, PartialEq)]
pub enum Effect {
    Notify { title: String, body: String },
    Toast(String),
    Open(u64),
}

/// Workspace functions exposed to scripts and used by visual steps.
pub struct WsHost<'a> {
    pub ws: &'a mut Workspace,
    pub row: Option<u64>,
    pub effects: Vec<Effect>,
    /// (page, property id) pairs written by this run — the engine uses them to stop a rule from retriggering itself.
    pub writes: Vec<(u64, u64)>,
    pub notes: Vec<String>,
    pub ops: u32,
}

pub const HOST_FUNCS: &[(&str, &str, &str)] = &[
    ("rows", "rows(db?)", "All rows of a database (a name or handle; default: the current row's database)."),
    ("db", "db(name)", "A database by name."),
    ("page", "page(name)", "A page by title (or id)."),
    ("find_row", "find_row(db, title)", "The first row whose title matches (ignores case)."),
    ("get", "get(page, \"Prop\")", "Read a property — same as page.Prop or page[\"Prop\"]."),
    ("set", "set(page, \"Prop\", value)", "Write a property — same as page.Prop = value. Missing properties are created."),
    ("props", "props(page)", "All properties of a row as a map."),
    ("create_row", "create_row(db, {title: \"…\", Status: \"Todo\"})", "Add a row; returns it."),
    ("create_page", "create_page(title, parent?)", "Add a page; returns it."),
    ("append", "append(page, text, kind?)", "Add a block (text, todo, bullet, h1, h2, h3, quote, callout)."),
    ("move_row", "move_row(row, db)", "Move a row to another database."),
    ("duplicate", "duplicate(page)", "Copy a page or row; returns the copy."),
    ("trash", "trash(page)", "Move to the trash."),
    ("repeat_date", "repeat_date(row, \"Prop\", rule, from_done?)", "Move a date to its next occurrence (rule: \"weekly\", \"every 2 weeks\", \"mon,thu\")."),
    ("notify", "notify(title, body?)", "Desktop notification on Windows, push notification on the web (and a toast in the app)."),
    ("toast", "toast(message)", "Show a message inside the app."),
    ("open", "open(page)", "Open a page in the app."),
];

/// Variables every script can use.
pub const SCRIPT_VARS: &[(&str, &str)] = &[
    ("row", "The row (page) the rule runs for, or null for schedules."),
    ("db", "The database of that row."),
    ("title", "Title of the row."),
    ("trigger", "Map: kind (\"changed\", \"added\", \"button\", \"schedule\", \"date\", \"open\"), prop, from, to."),
];

fn norm(s: &str) -> String {
    s.trim().to_lowercase()
}

fn is_title_key(k: &str) -> bool {
    matches!(norm(k).as_str(), "title" | "name")
}

impl<'a> WsHost<'a> {
    pub fn new(ws: &'a mut Workspace, row: Option<u64>) -> Self {
        WsHost { ws, row, effects: vec![], writes: vec![], notes: vec![], ops: 0 }
    }

    fn page_title(&self, id: u64) -> String {
        match self.ws.page(id) {
            Some(p) if p.title.is_empty() => "Untitled".into(),
            Some(p) => p.title.clone(),
            None => String::new(),
        }
    }

    fn row_db(&self, row: u64) -> Option<u64> {
        self.ws.page(row).filter(|p| p.row).and_then(|p| p.parent)
    }

    fn find_db(&self, name: &str) -> Option<u64> {
        let n = norm(name);
        if let Ok(id) = n.parse::<u64>() {
            if self.ws.db(id).is_some() {
                return Some(id);
            }
        }
        self.ws.pages.iter().find(|p| p.db.is_some() && !p.trashed && norm(&p.title) == n).map(|p| p.id)
    }

    fn find_page(&self, name: &str) -> Option<u64> {
        let n = norm(name);
        if let Ok(id) = n.parse::<u64>() {
            if self.ws.page(id).is_some() {
                return Some(id);
            }
        }
        self.ws.pages.iter().find(|p| !p.trashed && !p.row && norm(&p.title) == n).or_else(|| self.ws.pages.iter().find(|p| !p.trashed && norm(&p.title) == n)).map(|p| p.id)
    }

    fn as_page(&self, v: &Value) -> Option<u64> {
        match v {
            Value::Page(id) => Some(*id),
            Value::Str(s) => self.find_page(s),
            Value::Num(n) => Some(*n as u64).filter(|id| self.ws.page(*id).is_some()),
            _ => None,
        }
    }

    fn as_db(&self, v: &Value) -> Option<u64> {
        match v {
            Value::Page(id) if self.ws.db(*id).is_some() => Some(*id),
            Value::Page(id) => self.row_db(*id),
            Value::Str(s) if s.trim().is_empty() => self.row.and_then(|r| self.row_db(r)),
            Value::Str(s) => self.find_db(s),
            Value::Null => self.row.and_then(|r| self.row_db(r)),
            _ => None,
        }
    }

    fn prop_named(&self, db: u64, name: &str) -> Option<&Prop> {
        let n = norm(name);
        self.ws.db(db)?.props.iter().find(|p| norm(&p.name) == n)
    }

    /// Reads a property of a row as a script value.
    pub fn read(&self, id: u64, key: &str) -> Result<Value, String> {
        let page = self.ws.page(id).ok_or_else(|| "that page no longer exists".to_owned())?;
        let lk = norm(key);
        // a real property wins over the built-in names, except for the title
        if page.row {
            if let Some(db) = page.parent.and_then(|d| self.ws.db(d)) {
                if let Some(prop) = db.props.iter().find(|p| norm(&p.name) == lk) {
                    return Ok(self.prop_value(db, prop, page.props.get(&prop.id)));
                }
            }
        }
        Ok(match lk.as_str() {
            "title" | "name" => Value::Str(page.title.clone()),
            "id" => Value::Num(id as f64),
            "db" | "database" => page.parent.filter(|_| page.row).map(Value::Page).unwrap_or(Value::Null),
            "parent" => page.parent.map(Value::Page).unwrap_or(Value::Null),
            "updated" => Value::Num(page.updated),
            "icon" => Value::Str(page.icon.clone()),
            "trashed" => Value::Bool(page.trashed),
            "text" => Value::Str(page.blocks.iter().filter(|b| b.kind.has_text()).map(|b| b.text.as_str()).collect::<Vec<_>>().join("\n")),
            "rows" if page.db.is_some() => Value::list(self.ws.rows(id).into_iter().map(Value::Page).collect()),
            "children" => Value::list(self.ws.children(Some(id)).into_iter().map(Value::Page).collect()),
            _ => {
                let have: Vec<String> = page.parent.filter(|_| page.row).and_then(|d| self.ws.db(d)).map(|d| d.props.iter().map(|p| p.name.clone()).collect()).unwrap_or_default();
                return Err(if have.is_empty() { format!("'{}' has no field '{key}'", self.page_title(id)) } else { format!("no property '{key}' in {} (it has: {})", self.page_title(page.parent.unwrap_or(0)), have.join(", ")) });
            }
        })
    }

    fn prop_value(&self, db: &Database, prop: &Prop, v: Option<&Val>) -> Value {
        match (prop.kind, v) {
            (PropKind::Checkbox, Some(Val::Check(b))) => Value::Bool(*b),
            (PropKind::Checkbox, _) => Value::Bool(false),
            (PropKind::MultiSelect, Some(Val::Multi(m))) => Value::list(m.iter().filter_map(|o| db.opt(prop.id, *o)).map(|o| Value::Str(o.name.clone())).collect()),
            (PropKind::MultiSelect, _) => Value::list(vec![]),
            (PropKind::Relation, Some(Val::Multi(m))) => Value::list(m.iter().filter(|id| self.ws.page(**id).is_some()).map(|id| Value::Page(*id)).collect()),
            (PropKind::Relation, _) => Value::list(vec![]),
            (_, None) => Value::Null,
            (_, Some(Val::Num(n))) => Value::Num(*n),
            (_, Some(Val::Check(b))) => Value::Bool(*b),
            (_, Some(Val::Sel(o))) => db.opt(prop.id, *o).map(|o| Value::Str(o.name.clone())).unwrap_or(Value::Null),
            (_, Some(Val::Multi(_))) => Value::str(db.val_text(prop.id, v.unwrap_or(&Val::Text(String::new())))),
            (PropKind::Date, Some(Val::Text(s))) | (PropKind::Text, Some(Val::Text(s))) | (PropKind::Url, Some(Val::Text(s))) => {
                if s.is_empty() {
                    Value::Null
                } else {
                    Value::Str(s.clone())
                }
            }
            (_, Some(Val::Text(s))) => Value::Str(s.clone()),
        }
    }

    fn ensure_opt(&mut self, db: u64, prop: u64, name: &str) -> u64 {
        let n = norm(name);
        if let Some(o) = self.ws.db(db).and_then(|d| d.prop(prop)).and_then(|p| p.opts.iter().find(|o| norm(&o.name) == n)) {
            return o.id;
        }
        let oid = self.ws.id();
        if let Some(p) = self.ws.db_mut(db).and_then(|d| d.props.iter_mut().find(|p| p.id == prop)) {
            let color = p.opts.len() % 9;
            p.opts.push(Opt { id: oid, name: name.trim().to_owned(), color });
        }
        oid
    }

    fn text_of(&self, v: &Value) -> String {
        match v {
            Value::Null => String::new(),
            Value::Bool(b) => b.to_string(),
            Value::Num(n) => script::fmt_num(*n),
            Value::Str(s) => s.clone(),
            Value::Page(id) => self.page_title(*id),
            other => format!("{other:?}"),
        }
    }

    /// Writes a property of a row (creating the property when it does not exist yet).
    pub fn write(&mut self, id: u64, key: &str, v: Value) -> Result<(), String> {
        self.ops += 1;
        if self.ops > 2000 {
            return Err("too many changes in one run (limit 2000)".into());
        }
        let page = self.ws.page(id).ok_or_else(|| "that page no longer exists".to_owned())?;
        let (is_row, parent) = (page.row, page.parent);
        let db_id = parent.filter(|_| is_row);
        let existing = db_id.and_then(|d| self.prop_named(d, key)).map(|p| (p.id, p.kind));
        if existing.is_none() && is_title_key(key) {
            let t = self.text_of(&v).replace('\n', " ");
            if let Some(p) = self.ws.page_mut(id) {
                p.title = t;
            }
            self.writes.push((id, 0));
            self.ws.touch(id);
            return Ok(());
        }
        let Some(db) = db_id else { return Err(format!("'{}' is not a database row, so it has no property '{key}'", self.page_title(id))) };
        let (pid, kind) = match existing {
            Some(x) => x,
            None => {
                let kind = match &v {
                    Value::Num(_) => PropKind::Number,
                    Value::Bool(_) => PropKind::Checkbox,
                    Value::List(_) => PropKind::MultiSelect,
                    Value::Str(s) if dates::span(s).is_some() || recur::resolve_date(s, dates::today_day()).is_some() => PropKind::Date,
                    _ => PropKind::Text,
                };
                let pid = self.ws.add_prop(db, key.trim(), kind, &[]);
                self.notes.push(format!("created property \"{}\" ({})", key.trim(), kind.label()));
                (pid, kind)
            }
        };
        let new: Option<Val> = match kind {
            PropKind::Formula | PropKind::Rollup => return Err(format!("'{key}' is computed and cannot be set")),
            PropKind::Text | PropKind::Url => {
                let s = self.text_of(&v);
                if s.is_empty() { None } else { Some(Val::Text(s)) }
            }
            PropKind::Number => match &v {
                Value::Null => None,
                other => Some(Val::Num(other.as_num().ok_or_else(|| format!("'{}' is not a number (property {key})", self.text_of(other)))?)),
            },
            PropKind::Checkbox => Some(Val::Check(match &v {
                Value::Str(s) => matches!(norm(s).as_str(), "true" | "yes" | "checked" | "done" | "on" | "1"),
                other => other.truthy(),
            })),
            PropKind::Date => match &v {
                Value::Null => None,
                other => {
                    let s = self.text_of(other);
                    if s.trim().is_empty() {
                        None
                    } else if dates::span(&s).is_some() {
                        Some(Val::Text(s.trim().to_owned()))
                    } else if let Some(d) = recur::resolve_date(&s, dates::today_day()) {
                        Some(Val::Text(dates::iso_of_day(d)))
                    } else {
                        return Err(format!("'{s}' is not a date for property {key} (use YYYY-MM-DD, today, tomorrow, +3d, next monday)"));
                    }
                }
            },
            PropKind::Select => {
                let s = self.text_of(&v);
                if s.trim().is_empty() {
                    None
                } else {
                    Some(Val::Sel(self.ensure_opt(db, pid, &s)))
                }
            }
            PropKind::MultiSelect => {
                let names: Vec<String> = match &v {
                    Value::List(l) => l.borrow().iter().map(|x| self.text_of(x)).collect(),
                    Value::Null => vec![],
                    other => self.text_of(other).split(',').map(|s| s.trim().to_owned()).collect(),
                };
                let ids: Vec<u64> = names.iter().filter(|n| !n.is_empty()).map(|n| self.ensure_opt(db, pid, n)).collect();
                if ids.is_empty() { None } else { Some(Val::Multi(ids)) }
            }
            PropKind::Relation => {
                let target = self.ws.db(db).and_then(|d| d.prop(pid)).map(|p| p.cfg.relation).unwrap_or(0);
                let items: Vec<Value> = match &v {
                    Value::List(l) => l.borrow().clone(),
                    Value::Null => vec![],
                    other => vec![other.clone()],
                };
                let mut ids = vec![];
                for it in items {
                    let found = match &it {
                        Value::Page(p) => Some(*p),
                        other => {
                            let t = norm(&self.text_of(other));
                            self.ws.rows(target).into_iter().find(|r| norm(&self.page_title(*r)) == t)
                        }
                    };
                    if let Some(f) = found {
                        ids.push(f);
                    }
                }
                if ids.is_empty() { None } else { Some(Val::Multi(ids)) }
            }
        };
        if let Some(p) = self.ws.page_mut(id) {
            match new {
                Some(nv) => {
                    p.props.insert(pid, nv);
                }
                None => {
                    p.props.remove(&pid);
                }
            }
        }
        self.writes.push((id, pid));
        self.ws.touch(id);
        Ok(())
    }

    fn make_row(&mut self, db: u64, fields: Vec<(String, Value)>) -> Result<u64, String> {
        let row = self.ws.add_row(db, None);
        for (k, v) in fields {
            self.write(row, &k, v)?;
        }
        Ok(row)
    }

    fn move_to(&mut self, row: u64, new_db: u64) -> Result<(), String> {
        let old_db = self.row_db(row).ok_or("only database rows can be moved")?;
        if old_db == new_db {
            return Ok(());
        }
        if self.ws.db(new_db).is_none() {
            return Err("the target is not a database".into());
        }
        // read every value by name first, then re-write them in the new database
        let carry: Vec<(String, Value)> = self.ws.db(old_db).map(|d| d.props.iter().filter(|p| !p.kind.computed() && p.kind != PropKind::Relation).map(|p| p.name.clone()).collect::<Vec<_>>()).unwrap_or_default().into_iter().filter_map(|n| self.read(row, &n).ok().map(|v| (n, v))).collect();
        if let Some(p) = self.ws.page_mut(row) {
            p.parent = Some(new_db);
            p.props.clear();
        }
        for (name, v) in carry {
            if self.prop_named(new_db, &name).is_some() {
                let _ = self.write(row, &name, v);
            }
        }
        self.ws.touch(row);
        Ok(())
    }

    fn block_kind(kind: &str) -> crate::model::BlockKind {
        use crate::model::BlockKind as B;
        match norm(kind).as_str() {
            "todo" | "task" | "checkbox" => B::Todo,
            "bullet" | "bulleted" | "list" => B::Bullet,
            "numbered" => B::Numbered,
            "h1" | "heading" => B::H1,
            "h2" => B::H2,
            "h3" => B::H3,
            "quote" => B::Quote,
            "callout" => B::Callout,
            "code" => B::Code,
            _ => B::Text,
        }
    }

    fn append_block(&mut self, page: u64, text: &str, kind: &str) -> Result<(), String> {
        let k = Self::block_kind(kind);
        let b = self.ws.blk(k, text, 0);
        let p = self.ws.page_mut(page).ok_or("that page no longer exists")?;
        if p.blocks.len() == 1 && p.blocks[0].text.is_empty() && p.blocks[0].kind == crate::model::BlockKind::Text {
            p.blocks.clear();
        }
        p.blocks.push(b);
        self.ws.touch(page);
        Ok(())
    }

    /// Moves the date property of `row` to its next occurrence (after the current date, or after today when `from_done`).
    fn repeat(&mut self, row: u64, prop: &str, rule: &str, from_done: bool) -> Result<String, String> {
        let rep = Repeat::parse(rule).ok_or_else(|| format!("don't understand the repeat rule '{rule}' (try \"weekly\", \"every 2 weeks\", \"mon,thu\", \"monthly\")"))?;
        let cur = self.read(row, prop)?;
        let today = dates::today_day();
        let (start, end) = match &cur {
            Value::Str(s) => dates::span(s).unwrap_or((today, today)),
            _ => (today, today),
        };
        let len = end - start;
        let mut next = rep.next_after(if from_done { today } else { start });
        let mut guard = 0;
        while next < today && guard < 1000 {
            next = rep.next_after(next);
            guard += 1;
        }
        let val = dates::span_value(next, next + len);
        self.write(row, prop, Value::Str(val.clone()))?;
        Ok(val)
    }

    fn row_arg(&self, a: &[Value], i: usize, f: &str) -> Result<u64, String> {
        match a.get(i) {
            Some(v) => self.as_page(v).ok_or_else(|| format!("{f}(): argument {} must be a page or row", i + 1)),
            None => self.row.ok_or_else(|| format!("{f}() needs a row (this rule has no row — pass one in)")),
        }
    }
}

impl Host for WsHost<'_> {
    fn call(&mut self, name: &str, a: &[Value]) -> Option<Result<Value, String>> {
        let r: Result<Value, String> = (|| match name {
            "rows" => {
                let db = a.first().map(|v| self.as_db(v)).unwrap_or_else(|| self.row.and_then(|r| self.row_db(r)));
                let db = db.ok_or("rows(): which database? pass a name, e.g. rows(\"Tasks\")")?;
                Ok(Value::list(self.ws.rows(db).into_iter().map(Value::Page).collect()))
            }
            "db" => {
                let n = a.first().map(|v| self.text_of(v)).unwrap_or_default();
                Ok(self.find_db(&n).map(Value::Page).unwrap_or(Value::Null))
            }
            "page" => Ok(a.first().and_then(|v| self.as_page(v)).map(Value::Page).unwrap_or(Value::Null)),
            "find_row" => {
                let db = a.first().and_then(|v| self.as_db(v)).ok_or("find_row(): unknown database")?;
                let t = norm(&a.get(1).map(|v| self.text_of(v)).unwrap_or_default());
                Ok(self.ws.rows(db).into_iter().find(|r| norm(&self.page_title(*r)) == t).map(Value::Page).unwrap_or(Value::Null))
            }
            "get" => {
                let p = self.row_arg(a, 0, "get")?;
                let k = a.get(1).map(|v| self.text_of(v)).unwrap_or_default();
                self.read(p, &k)
            }
            "set" => {
                let p = self.row_arg(a, 0, "set")?;
                let k = a.get(1).map(|v| self.text_of(v)).ok_or("set(page, \"Property\", value)")?;
                self.write(p, &k, a.get(2).cloned().unwrap_or(Value::Null))?;
                Ok(Value::Null)
            }
            "props" => {
                let p = self.row_arg(a, 0, "props")?;
                let mut m = BTreeMap::new();
                m.insert("title".to_owned(), Value::Str(self.page_title(p)));
                let names: Vec<String> = self.row_db(p).and_then(|d| self.ws.db(d)).map(|d| d.props.iter().map(|x| x.name.clone()).collect()).unwrap_or_default();
                for n in names {
                    if let Ok(v) = self.read(p, &n) {
                        m.insert(n, v);
                    }
                }
                Ok(Value::map(m))
            }
            "create_row" => {
                let db = a.first().and_then(|v| self.as_db(v)).ok_or("create_row(db, {…}): unknown database — use its exact name")?;
                let fields: Vec<(String, Value)> = match a.get(1) {
                    Some(Value::Map(m)) => m.borrow().iter().map(|(k, v)| (k.clone(), v.clone())).collect(),
                    Some(Value::Str(t)) => vec![("title".into(), Value::Str(t.clone()))],
                    _ => vec![],
                };
                Ok(Value::Page(self.make_row(db, fields)?))
            }
            "create_page" => {
                let parent = a.get(1).and_then(|v| self.as_page(v));
                let id = self.ws.add_page(parent, PageKind::Doc);
                let t = a.first().map(|v| self.text_of(v)).unwrap_or_default();
                if let Some(p) = self.ws.page_mut(id) {
                    p.title = t;
                }
                Ok(Value::Page(id))
            }
            "append" => {
                let p = self.row_arg(a, 0, "append")?;
                let t = a.get(1).map(|v| self.text_of(v)).unwrap_or_default();
                let k = a.get(2).map(|v| self.text_of(v)).unwrap_or_default();
                self.append_block(p, &t, &k)?;
                Ok(Value::Null)
            }
            "move_row" => {
                let p = self.row_arg(a, 0, "move_row")?;
                let db = a.get(1).and_then(|v| self.as_db(v)).ok_or("move_row(row, db): unknown database")?;
                self.move_to(p, db)?;
                Ok(Value::Null)
            }
            "duplicate" => {
                let p = self.row_arg(a, 0, "duplicate")?;
                Ok(self.ws.duplicate(p).map(Value::Page).unwrap_or(Value::Null))
            }
            "trash" => {
                let p = self.row_arg(a, 0, "trash")?;
                self.ws.set_trashed(p, true);
                Ok(Value::Null)
            }
            "repeat_date" => {
                let p = self.row_arg(a, 0, "repeat_date")?;
                let prop = a.get(1).map(|v| self.text_of(v)).unwrap_or_default();
                let rule = a.get(2).map(|v| self.text_of(v)).unwrap_or_default();
                let from_done = a.get(3).map_or(false, |v| v.truthy());
                Ok(Value::Str(self.repeat(p, &prop, &rule, from_done)?))
            }
            "notify" => {
                let t = a.first().map(|v| self.text_of(v)).unwrap_or_default();
                let b = a.get(1).map(|v| self.text_of(v)).unwrap_or_default();
                self.effects.push(Effect::Notify { title: t, body: b });
                Ok(Value::Null)
            }
            "toast" => {
                let t = a.first().map(|v| self.text_of(v)).unwrap_or_default();
                self.effects.push(Effect::Toast(t));
                Ok(Value::Null)
            }
            "open" => {
                if let Some(p) = a.first().and_then(|v| self.as_page(v)) {
                    self.effects.push(Effect::Open(p));
                }
                Ok(Value::Null)
            }
            _ => Err(String::new()),
        })();
        match r {
            Err(e) if e.is_empty() && !HOST_FUNCS.iter().any(|f| f.0 == name) => None,
            other => Some(other),
        }
    }

    fn get(&mut self, page: u64, key: &str) -> Result<Value, String> {
        self.read(page, key)
    }

    fn set(&mut self, page: u64, key: &str, v: Value) -> Result<(), String> {
        self.write(page, key, v)
    }

    fn title(&mut self, page: u64) -> String {
        self.page_title(page)
    }
}

// ───────────────────────────── running a rule ─────────────────────────────

#[derive(Clone, Default, Debug)]
pub struct TrigInfo {
    pub kind: String,
    pub prop: String,
    pub from: String,
    pub to: String,
}

#[derive(Default)]
pub struct Report {
    pub ok: bool,
    /// False when the conditions did not match (not an error, nothing ran).
    pub matched: bool,
    pub lines: Vec<String>,
    pub error: Option<String>,
    pub effects: Vec<Effect>,
    pub writes: Vec<(u64, u64)>,
}

fn script_vars(host: &WsHost, rule: u64, row: Option<u64>, t: &TrigInfo) -> Vec<(&'static str, Value)> {
    let mut trig = BTreeMap::new();
    trig.insert("kind".to_owned(), Value::str(t.kind.clone()));
    trig.insert("prop".to_owned(), Value::str(t.prop.clone()));
    trig.insert("from".to_owned(), Value::str(t.from.clone()));
    trig.insert("to".to_owned(), Value::str(t.to.clone()));
    trig.insert("rule".to_owned(), Value::Num(rule as f64));
    let row_v = row.filter(|r| host.ws.page(*r).is_some()).map(Value::Page).unwrap_or(Value::Null);
    let db_v = row.and_then(|r| host.row_db(r)).map(Value::Page).unwrap_or(Value::Null);
    let title = row.map(|r| host.page_title(r)).unwrap_or_default();
    vec![("row", row_v), ("db", db_v), ("title", Value::Str(title)), ("trigger", Value::map(trig))]
}

fn val_key_text(db: &Database, prop: u64, v: Option<&Val>) -> String {
    match v {
        None => String::new(),
        Some(Val::Check(b)) => b.to_string(),
        Some(v) => db.val_text(prop, v),
    }
}

fn cond_ok(host: &mut WsHost, row: Option<u64>, c: &Cond) -> bool {
    let Some(row) = row else { return true };
    let v = host.read(row, &c.prop).unwrap_or(Value::Null);
    let text = host.text_of(&v);
    let want = c.value.trim();
    match c.op {
        CondOp::Empty => !v.truthy() && !matches!(v, Value::Bool(true)) || text.is_empty(),
        CondOp::NotEmpty => !(text.is_empty() || matches!(&v, Value::List(l) if l.borrow().is_empty())) && !matches!(v, Value::Bool(false)),
        CondOp::Is | CondOp::IsNot => {
            let eq = match &v {
                Value::Bool(b) => {
                    let w = norm(want);
                    *b == matches!(w.as_str(), "true" | "yes" | "checked" | "done" | "on" | "1")
                }
                Value::List(l) => l.borrow().iter().any(|x| norm(&host.text_of(x)) == norm(want)),
                Value::Num(n) => want.parse::<f64>().map_or(false, |w| w == *n),
                _ => {
                    if dates::span(&text).is_some() {
                        match (recur::resolve_date(want, dates::today_day()), dates::span(&text)) {
                            (Some(w), Some(s)) => w >= s.0 && w <= s.1,
                            _ => norm(&text) == norm(want),
                        }
                    } else {
                        norm(&text) == norm(want)
                    }
                }
            };
            eq == (c.op == CondOp::Is)
        }
        CondOp::Contains => match &v {
            Value::List(l) => l.borrow().iter().any(|x| norm(&host.text_of(x)).contains(&norm(want))),
            _ => norm(&text).contains(&norm(want)),
        },
        CondOp::Greater | CondOp::Less => {
            let ord = if let (Some(a), Some(s)) = (recur::resolve_date(want, dates::today_day()), dates::span(&text)) {
                if dates::span(want).is_some() || !want.chars().all(|c| c.is_ascii_digit() || c == '.') {
                    Some(s.0.cmp(&a))
                } else {
                    None
                }
            } else {
                None
            };
            let ord = ord.or_else(|| match (v.as_num(), want.parse::<f64>()) {
                (Some(a), Ok(b)) => a.partial_cmp(&b),
                _ => None,
            });
            match ord {
                Some(std::cmp::Ordering::Greater) => c.op == CondOp::Greater,
                Some(std::cmp::Ordering::Less) => c.op == CondOp::Less,
                _ => false,
            }
        }
    }
}

/// Runs one rule against `row` (conditions first). Changes are applied to `ws`.
pub fn run_rule(ws: &mut Workspace, rule: &Rule, row: Option<u64>, trig: &TrigInfo) -> Report {
    let mut host = WsHost::new(ws, row);
    let mut rep = Report::default();
    // conditions
    if let Some(r) = row {
        let db = host.row_db(r);
        if !rule.applies_to_db(db) && trig.kind != "button" {
            return rep;
        }
    }
    for c in &rule.conditions {
        if !cond_ok(&mut host, row, c) {
            return rep;
        }
    }
    if !rule.when.trim().is_empty() {
        let vars = script_vars(&host, rule.id, row, trig);
        match script::eval_expr(&rule.when, &mut host, &vars) {
            Ok(v) if v.truthy() => {}
            Ok(_) => return rep,
            Err(e) => {
                rep.matched = true;
                rep.error = Some(format!("condition script: {e}"));
                return rep;
            }
        }
    }
    rep.matched = true;
    let subject = row.map(|r| format!(" on \"{}\"", host.page_title(r))).unwrap_or_default();
    for (i, step) in rule.steps.iter().enumerate() {
        match exec_step(&mut host, rule, step, row, trig) {
            Ok(mut lines) => rep.lines.append(&mut lines),
            Err(e) => {
                rep.error = Some(format!("step {} ({}): {e}", i + 1, step.kind_label()));
                break;
            }
        }
    }
    rep.ok = rep.error.is_none();
    if rep.ok && rep.lines.is_empty() {
        rep.lines.push(format!("Ran{subject}"));
    }
    rep.lines.extend(std::mem::take(&mut host.notes));
    rep.effects = std::mem::take(&mut host.effects);
    rep.writes = std::mem::take(&mut host.writes);
    rep
}

fn exec_step(host: &mut WsHost, rule: &Rule, step: &Step, row: Option<u64>, trig: &TrigInfo) -> Result<Vec<String>, String> {
    let tpl = |host: &mut WsHost, t: &str| -> Result<Value, String> {
        if !t.contains('{') {
            return Ok(Value::Str(t.to_owned()));
        }
        let vars = script_vars(host, rule.id, row, trig);
        script::eval_template(t, host, &vars).map_err(|e| format!("in \"{t}\": {e}"))
    };
    let txt = |host: &mut WsHost, t: &str| -> Result<String, String> {
        let v = tpl(host, t)?;
        Ok(host.text_of(&v))
    };
    let need_row = || row.ok_or_else(|| "this step needs a row — the trigger has none (use a database trigger or a button on a row)".to_owned());
    let title_of = |host: &WsHost, r: u64| host.page_title(r);
    let mut out = vec![];
    match step {
        Step::SetProp { prop, value } => {
            let r = need_row()?;
            let v = tpl(host, value)?;
            host.write(r, prop, v.clone())?;
            out.push(format!("Set {prop} to {} on \"{}\"", host.text_of(&v), title_of(host, r)));
        }
        Step::CreateRow { db, title, props } => {
            let db_id = if db.trim().is_empty() {
                row.and_then(|r| host.row_db(r))
            } else {
                let name = txt(host, db)?;
                host.find_db(&name)
            };
            let db_id = db_id.ok_or_else(|| format!("database \"{db}\" not found"))?;
            let mut fields = vec![("title".to_owned(), Value::Str(txt(host, title)?))];
            for (k, v) in props {
                fields.push((k.clone(), tpl(host, v)?));
            }
            let t = host.text_of(&fields[0].1);
            host.make_row(db_id, fields)?;
            out.push(format!("Added \"{t}\" to {}", host.page_title(db_id)));
        }
        Step::MoveRow { db } => {
            let r = need_row()?;
            let name = txt(host, db)?;
            let target = host.find_db(&name).ok_or_else(|| format!("database \"{name}\" not found"))?;
            host.move_to(r, target)?;
            out.push(format!("Moved \"{}\" to {name}", title_of(host, r)));
        }
        Step::AddBlock { page, text, kind } => {
            let target = if page.trim().is_empty() {
                need_row()?
            } else {
                let n = txt(host, page)?;
                host.find_page(&n).ok_or_else(|| format!("page \"{n}\" not found"))?
            };
            let t = txt(host, text)?;
            host.append_block(target, &t, kind)?;
            out.push(format!("Added a note to \"{}\"", title_of(host, target)));
        }
        Step::Notify { title, body } => {
            let (t, b) = (txt(host, title)?, txt(host, body)?);
            out.push(format!("Notified: {t}"));
            host.effects.push(Effect::Notify { title: t, body: b });
        }
        Step::RepeatDate { prop, rule: rr, from_done, reset_prop, reset_value } => {
            let r = need_row()?;
            let next = host.repeat(r, prop, rr, *from_done)?;
            out.push(format!("{prop} → {} on \"{}\"", dates::pretty(&next), title_of(host, r)));
            if !reset_prop.trim().is_empty() {
                let v = tpl(host, reset_value)?;
                host.write(r, reset_prop, v)?;
                out.push(format!("Reset {reset_prop}"));
            }
        }
        Step::Trash => {
            let r = need_row()?;
            out.push(format!("Moved \"{}\" to the trash", title_of(host, r)));
            host.ws.set_trashed(r, true);
        }
        Step::Script { code } => {
            let vars = script_vars(host, rule.id, row, trig);
            let o = script::run(code, host, &vars).map_err(|e| e.to_string())?;
            out.extend(o.output.iter().map(|l| format!("› {l}")));
            if o.output.is_empty() {
                out.push(format!("Script finished ({} steps)", o.steps));
            }
        }
    }
    Ok(out)
}

/// Runs a rule on a copy of the workspace: shows what would happen without changing anything.
pub fn dry_run(ws: &Workspace, rule: &Rule, row: Option<u64>) -> Report {
    let mut copy = ws.clone();
    let trig = TrigInfo { kind: "button".into(), ..Default::default() };
    let mut rep = run_rule(&mut copy, rule, row, &trig);
    rep.writes.clear();
    rep
}

// ───────────────────────────── engine ─────────────────────────────

#[derive(Clone)]
struct RowSnap {
    parent: u64,
    title: String,
    props: BTreeMap<u64, Val>,
}

#[derive(Clone, Debug)]
enum EvKind {
    Added,
    Changed { prop: u64, from: Option<Val>, to: Option<Val> },
}

#[derive(Clone, Debug)]
struct Event {
    row: u64,
    kind: EvKind,
}

#[derive(Default)]
pub struct Runtime {
    snap: HashMap<u64, RowSnap>,
    primed: bool,
    /// Rows added but not yet announced: (row, due ms).
    added: Vec<(u64, f64)>,
    /// (row, prop) → (value before the burst of edits, due ms) — text edits fire once typing pauses.
    changing: HashMap<(u64, u64), (Option<Val>, f64)>,
    started: bool,
    last_tick: f64,
    busy_ticks: u32,
    guard_until: f64,
    /// Writes made by rules in the previous tick: (rule, row, prop). A rule is not triggered by its own writes.
    own_writes: Vec<(u64, u64, u64)>,
    /// Manual runs requested by the UI: (rule, row).
    pub manual: Vec<(u64, Option<u64>)>,
    /// Latest result per rule, for the UI.
    pub last: HashMap<u64, Report>,
}

#[derive(Default)]
pub struct TickOut {
    pub effects: Vec<Effect>,
    pub ran: usize,
    /// Ask the app to wake up again in this many milliseconds (None = nothing scheduled).
    pub wake_ms: Option<u64>,
}

fn parse_hm(t: &str) -> f64 {
    let mut it = t.trim().split(':');
    let h: f64 = it.next().and_then(|x| x.trim().parse().ok()).unwrap_or(9.0);
    let m: f64 = it.next().and_then(|x| x.trim().parse().ok()).unwrap_or(0.0);
    (h.clamp(0.0, 23.0) * 60.0 + m.clamp(0.0, 59.0)) * 60_000.0
}

/// The most recent scheduled instant at or before `now` (local ms).
fn latest_instant(s: &Sched, now: f64) -> Option<f64> {
    let day = (now / DAY_MS).floor() as i64;
    match s {
        Sched::Every { .. } => None,
        Sched::Daily { time } => {
            let t = day as f64 * DAY_MS + parse_hm(time);
            Some(if t <= now { t } else { t - DAY_MS })
        }
        Sched::Weekly { days, time } => (0..8).find_map(|k| {
            let d = day - k;
            if days & (1 << recur::weekday_of(d)) == 0 {
                return None;
            }
            let t = d as f64 * DAY_MS + parse_hm(time);
            (t <= now).then_some(t)
        }),
        Sched::Monthly { day: dom, time } => {
            let (y, m, _) = dates::civil_from_days(day);
            (0..2).find_map(|k| {
                let total = y as i64 * 12 + (m as i64 - 1) - k;
                let (ny, nm) = (total.div_euclid(12) as i32, total.rem_euclid(12) as u32 + 1);
                let dd = (*dom as u32).clamp(1, dates::days_in_month(ny, nm));
                let t = dates::days_from_civil(ny, nm, dd) as f64 * DAY_MS + parse_hm(time);
                (t <= now).then_some(t)
            })
        }
    }
}

fn tz_ms() -> f64 {
    dates::tz_offset() as f64 * 60_000.0
}

fn db_of(ws: &Workspace, row: u64) -> Option<u64> {
    ws.page(row).filter(|p| p.row).and_then(|p| p.parent)
}

fn prop_matches(ws: &Workspace, db: u64, prop: u64, name: &str) -> bool {
    if name.trim().is_empty() {
        return true;
    }
    if prop == 0 {
        return is_title_key(name);
    }
    ws.db(db).and_then(|d| d.prop(prop)).map_or(false, |p| norm(&p.name) == norm(name))
}

fn to_matches(want: &str, text: &str) -> bool {
    let w = norm(want);
    if w.is_empty() {
        return true;
    }
    let t = norm(text);
    match t.as_str() {
        "true" => matches!(w.as_str(), "true" | "yes" | "checked" | "done" | "on" | "1" | "✓"),
        "false" => matches!(w.as_str(), "false" | "no" | "unchecked" | "off" | "0"),
        _ => t == w,
    }
}

/// One engine step. Call every frame; it is cheap when nothing changed and does nothing without enabled rules.
pub fn tick(ws: &mut Workspace, rt: &mut Runtime, now: f64) -> TickOut {
    let mut out = TickOut::default();
    let manual: Vec<(u64, Option<u64>)> = std::mem::take(&mut rt.manual);
    if !manual.is_empty() {
        for (rid, row) in manual {
            if let Some(rule) = ws.auto.rule(rid).cloned() {
                execute(ws, rt, &rule, row, TrigInfo { kind: "button".into(), ..Default::default() }, now, &mut out);
            }
        }
    }
    if ws.auto.paused || ws.auto.enabled() == 0 {
        rt.snap.clear();
        rt.primed = false;
        rt.changing.clear();
        rt.added.clear();
        return out;
    }
    if now - rt.last_tick < 200.0 {
        out.wake_ms = Some(220);
        return out;
    }
    rt.last_tick = now;

    // ── app opened ──
    if !rt.started {
        rt.started = true;
        let ids: Vec<u64> = ws.auto.rules.iter().filter(|r| r.enabled && r.trigger == Trigger::AppOpened).map(|r| r.id).collect();
        for id in ids {
            if let Some(rule) = ws.auto.rule(id).cloned() {
                execute(ws, rt, &rule, None, TrigInfo { kind: "open".into(), ..Default::default() }, now, &mut out);
            }
        }
    }

    // ── row events (diff) ──
    let wants_rows = ws.auto.rules.iter().any(|r| r.enabled && matches!(r.trigger, Trigger::RowAdded | Trigger::PropChanged { .. }));
    let mut events: Vec<Event> = vec![];
    if wants_rows {
        let mut seen: HashSet<u64> = HashSet::new();
        let first = !rt.primed;
        for p in ws.pages.iter().filter(|p| p.row && !p.trashed) {
            seen.insert(p.id);
            let Some(parent) = p.parent else { continue };
            match rt.snap.get_mut(&p.id) {
                None => {
                    rt.snap.insert(p.id, RowSnap { parent, title: p.title.clone(), props: p.props.clone() });
                    if !first {
                        rt.added.push((p.id, now + 1200.0));
                    }
                }
                Some(s) => {
                    if s.title != p.title || s.props != p.props {
                        let db = ws.db(parent);
                        if s.title != p.title {
                            let e = rt.changing.entry((p.id, 0)).or_insert((Some(Val::Text(s.title.clone())), now));
                            e.1 = now + 900.0;
                            s.title = p.title.clone();
                        }
                        let keys: HashSet<u64> = s.props.keys().chain(p.props.keys()).copied().collect();
                        for k in keys {
                            let (a, b) = (s.props.get(&k), p.props.get(&k));
                            if a == b {
                                continue;
                            }
                            let kind = db.map(|d| d.kind_of(k));
                            if kind.map_or(false, |k| k.computed()) {
                                continue;
                            }
                            let slow = matches!(kind, Some(PropKind::Text | PropKind::Url | PropKind::Number));
                            let e = rt.changing.entry((p.id, k)).or_insert((a.cloned(), now));
                            e.1 = now + if slow { 900.0 } else { 0.0 };
                        }
                        s.props = p.props.clone();
                    }
                }
            }
        }
        rt.snap.retain(|id, _| seen.contains(id));
        rt.primed = true;
        // announce rows that have been there for a moment
        let mut keep = vec![];
        for (id, due) in std::mem::take(&mut rt.added) {
            if !seen.contains(&id) {
                continue;
            }
            if due <= now {
                events.push(Event { row: id, kind: EvKind::Added });
            } else {
                keep.push((id, due));
            }
        }
        rt.added = keep;
        // announce settled edits
        let due: Vec<(u64, u64)> = rt.changing.iter().filter(|(_, (_, d))| *d <= now).map(|(k, _)| *k).collect();
        for key in due {
            let Some((from, _)) = rt.changing.remove(&key) else { continue };
            let cur: Option<Val> = if key.1 == 0 { ws.page(key.0).map(|p| Val::Text(p.title.clone())) } else { ws.page(key.0).and_then(|p| p.props.get(&key.1).cloned()) };
            if from != cur && ws.page(key.0).map_or(false, |p| !p.trashed) {
                events.push(Event { row: key.0, kind: EvKind::Changed { prop: key.1, from, to: cur } });
            }
        }
    } else {
        rt.snap.clear();
        rt.primed = false;
        rt.added.clear();
        rt.changing.clear();
    }

    // ── run row-triggered rules ──
    let prev_writes = std::mem::take(&mut rt.own_writes);
    if !events.is_empty() {
        rt.busy_ticks += 1;
        if rt.busy_ticks > 12 && now > rt.guard_until {
            rt.guard_until = now + 15_000.0;
            let msg = "Paused row-triggered rules for 15 s: they kept triggering each other (a loop). Check your rules.".to_owned();
            ws.auto.push_log(LogEntry { ts: now, rule: 0, name: "Loop guard".into(), ok: false, msg: msg.clone() });
            out.effects.push(Effect::Toast(msg));
            rt.busy_ticks = 0;
        }
    } else {
        rt.busy_ticks = 0;
    }
    if now >= rt.guard_until {
        for ev in &events {
            let Some(db) = db_of(ws, ev.row) else { continue };
            let rules: Vec<Rule> = ws.auto.rules.iter().filter(|r| r.enabled && r.applies_to_db(Some(db))).cloned().collect();
            for rule in rules {
                let info = match (&rule.trigger, &ev.kind) {
                    (Trigger::RowAdded, EvKind::Added) => TrigInfo { kind: "added".into(), ..Default::default() },
                    (Trigger::PropChanged { prop, to }, EvKind::Changed { prop: pid, from, to: new }) => {
                        let dbr = ws.db(db);
                        let text = |v: &Option<Val>| -> String {
                            match (dbr, v) {
                                (Some(d), Some(Val::Text(s))) if *pid == 0 => {
                                    let _ = d;
                                    s.clone()
                                }
                                (Some(d), v) => val_key_text(d, *pid, v.as_ref()),
                                _ => String::new(),
                            }
                        };
                        if !prop_matches(ws, db, *pid, prop) {
                            continue;
                        }
                        let (new_t, old_t) = (text(new), text(from));
                        if !to_matches(to, &new_t) {
                            continue;
                        }
                        if prev_writes.iter().any(|w| w.0 == rule.id && w.1 == ev.row && w.2 == *pid) {
                            continue;
                        }
                        let pname = if *pid == 0 { "title".to_owned() } else { dbr.and_then(|d| d.prop(*pid)).map(|p| p.name.clone()).unwrap_or_default() };
                        TrigInfo { kind: "changed".into(), prop: pname, from: old_t, to: new_t }
                    }
                    _ => continue,
                };
                execute(ws, rt, &rule, Some(ev.row), info, now, &mut out);
            }
        }
    }

    // ── schedules & reminders ──
    let local = now + tz_ms();
    let mut wake: Option<f64> = if rt.changing.is_empty() && rt.added.is_empty() { None } else { Some(300.0) };
    let mut bump = |w: &mut Option<f64>, ms: f64| {
        let ms = ms.max(250.0);
        *w = Some(w.map_or(ms, |x| x.min(ms)));
    };
    let ids: Vec<u64> = ws.auto.rules.iter().filter(|r| r.enabled).map(|r| r.id).collect();
    for id in ids {
        let Some(rule) = ws.auto.rule(id).cloned() else { continue };
        match &rule.trigger {
            Trigger::Schedule(s) => {
                let last_local = rule.last_run + tz_ms();
                let due = match s {
                    Sched::Every { minutes } => {
                        let gap = (*minutes).max(1) as f64 * 60_000.0;
                        let next = rule.last_run + gap;
                        if now >= next {
                            true
                        } else {
                            bump(&mut wake, next - now);
                            false
                        }
                    }
                    other => match latest_instant(other, local) {
                        Some(inst) if inst > last_local && inst >= rule.created + tz_ms() - 60_000.0 => true,
                        Some(inst) => {
                            let next = latest_instant(other, local + 31.0 * DAY_MS).map(|_| 0.0);
                            let _ = (inst, next);
                            bump(&mut wake, 30_000.0);
                            false
                        }
                        None => false,
                    },
                };
                if due {
                    execute(ws, rt, &rule, None, TrigInfo { kind: "schedule".into(), ..Default::default() }, now, &mut out);
                }
            }
            Trigger::DateReached { prop, days_before, time } => {
                bump(&mut wake, 30_000.0);
                let hm = parse_hm(time);
                let rows: Vec<(u64, String)> = ws
                    .pages
                    .iter()
                    .filter(|p| p.row && !p.trashed && p.parent.map_or(false, |d| rule.applies_to_db(Some(d))))
                    .filter_map(|p| {
                        let d = ws.db(p.parent?)?;
                        let pr = d.props.iter().find(|x| norm(&x.name) == norm(prop) && x.kind == PropKind::Date)?;
                        match p.props.get(&pr.id) {
                            Some(Val::Text(s)) if !s.is_empty() => Some((p.id, s.clone())),
                            _ => None,
                        }
                    })
                    .collect();
                for (row, val) in rows {
                    let Some((start, _)) = dates::span(&val) else { continue };
                    let inst = (start - *days_before as i64) as f64 * DAY_MS + hm;
                    if inst > local || inst < rule.created + tz_ms() - 60_000.0 {
                        continue;
                    }
                    let key = format!("{}:{}:{}:{}:{}", rule.id, row, norm(prop), val, days_before);
                    if ws.auto.fired.iter().any(|k| *k == key) {
                        continue;
                    }
                    ws.auto.fired.push(key);
                    if ws.auto.fired.len() > 3000 {
                        ws.auto.fired.drain(..500);
                    }
                    execute(ws, rt, &rule, Some(row), TrigInfo { kind: "date".into(), prop: prop.clone(), to: val, ..Default::default() }, now, &mut out);
                }
            }
            _ => {}
        }
    }
    out.wake_ms = wake.map(|w| w as u64);
    out
}

fn execute(ws: &mut Workspace, rt: &mut Runtime, rule: &Rule, row: Option<u64>, info: TrigInfo, now: f64, out: &mut TickOut) {
    let rep = run_rule(ws, rule, row, &info);
    if !rep.matched {
        return;
    }
    for w in &rep.writes {
        rt.own_writes.push((rule.id, w.0, w.1));
    }
    let msg = match &rep.error {
        Some(e) => e.clone(),
        None => rep.lines.iter().take(4).cloned().collect::<Vec<_>>().join(" · "),
    };
    if let Some(r) = ws.auto.rule_mut(rule.id) {
        r.runs += 1;
        r.last_run = now;
        r.last_error = rep.error.clone().unwrap_or_default();
    }
    ws.auto.push_log(LogEntry { ts: now, rule: rule.id, name: rule.name.clone(), ok: rep.ok, msg: msg.clone() });
    out.ran += 1;
    out.effects.extend(rep.effects.iter().cloned());
    if let Some(e) = &rep.error {
        out.effects.push(Effect::Toast(format!("Automation \"{}\" failed: {e}", rule.name)));
    }
    rt.last.insert(rule.id, rep);
}

// ───────────────────────────── upcoming reminders (for the browser's push scheduler) ─────────────────────────────

/// Notifications that will fire in the next `hours`: `(key, utc ms, title, body)`. The web build hands these to a small
/// JavaScript scheduler so reminders still appear while the tab is in the background.
pub fn upcoming_notifications(ws: &Workspace, now: f64, hours: f64) -> Vec<(String, f64, String, String)> {
    let mut out = vec![];
    if ws.auto.paused {
        return out;
    }
    let local = now + tz_ms();
    let horizon = local + hours * 3_600_000.0;
    let mut copy: Option<Workspace> = None;
    for rule in ws.auto.rules.iter().filter(|r| r.enabled) {
        let notifies: Vec<(&String, &String)> = rule.steps.iter().filter_map(|s| if let Step::Notify { title, body } = s { Some((title, body)) } else { None }).collect();
        if notifies.is_empty() {
            continue;
        }
        let render = |copy: &mut Option<Workspace>, row: Option<u64>, t: &str, b: &str| -> (String, String) {
            let w = copy.get_or_insert_with(|| ws.clone());
            let mut host = WsHost::new(w, row);
            let trig = TrigInfo::default();
            let vars = script_vars(&host, rule.id, row, &trig);
            let tt = script::eval_template(t, &mut host, &vars).map(|v| host.text_of(&v)).unwrap_or_else(|_| t.to_owned());
            let bb = script::eval_template(b, &mut host, &vars).map(|v| host.text_of(&v)).unwrap_or_else(|_| b.to_owned());
            (tt, bb)
        };
        match &rule.trigger {
            Trigger::DateReached { prop, days_before, time } => {
                let hm = parse_hm(time);
                for p in ws.pages.iter().filter(|p| p.row && !p.trashed && p.parent.map_or(false, |d| rule.applies_to_db(Some(d)))) {
                    let Some(d) = p.parent.and_then(|d| ws.db(d)) else { continue };
                    let Some(pr) = d.props.iter().find(|x| norm(&x.name) == norm(prop) && x.kind == PropKind::Date) else { continue };
                    let Some(Val::Text(val)) = p.props.get(&pr.id) else { continue };
                    let Some((start, _)) = dates::span(val) else { continue };
                    let inst = (start - *days_before as i64) as f64 * DAY_MS + hm;
                    if inst < local - 60_000.0 || inst > horizon || inst < rule.created + tz_ms() - 60_000.0 {
                        continue;
                    }
                    let key = format!("{}:{}:{}:{}:{}", rule.id, p.id, norm(prop), val, days_before);
                    if ws.auto.fired.iter().any(|k| *k == key) {
                        continue;
                    }
                    // conditions are evaluated on the copy so the rule's filters apply
                    let ok = {
                        let w = copy.get_or_insert_with(|| ws.clone());
                        let mut host = WsHost::new(w, Some(p.id));
                        rule.conditions.iter().all(|c| cond_ok(&mut host, Some(p.id), c))
                    };
                    if !ok {
                        continue;
                    }
                    for (t, b) in &notifies {
                        let (tt, bb) = render(&mut copy, Some(p.id), t, b);
                        out.push((key.clone(), inst - tz_ms(), tt, bb));
                    }
                }
            }
            Trigger::Schedule(s) => {
                let next = match s {
                    Sched::Every { minutes } => Some(rule.last_run + (*minutes).max(1) as f64 * 60_000.0 + tz_ms()),
                    other => {
                        let mut t = latest_instant(other, local);
                        if let Some(i) = t {
                            if i <= rule.last_run + tz_ms() || i < local - 60_000.0 {
                                // look for the next instant after `local`
                                t = (1..=62).find_map(|h| latest_instant(other, local + h as f64 * 12.0 * 3_600_000.0).filter(|x| *x > local));
                            }
                        } else {
                            t = (1..=62).find_map(|h| latest_instant(other, local + h as f64 * 12.0 * 3_600_000.0).filter(|x| *x > local));
                        }
                        t
                    }
                };
                if let Some(n) = next.filter(|n| *n <= horizon && *n >= local - 60_000.0) {
                    for (t, b) in &notifies {
                        let (tt, bb) = render(&mut copy, None, t, b);
                        out.push((format!("{}:sched:{}", rule.id, n as i64 / 60_000), n - tz_ms(), tt, bb));
                    }
                }
            }
            _ => {}
        }
    }
    out.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
    out.truncate(60);
    out
}

// ───────────────────────────── recipes ─────────────────────────────

/// What the recipes need to know about a database.
#[derive(Clone, Debug, Default)]
pub struct DbInfo {
    pub id: u64,
    pub title: String,
    pub status: Option<String>,
    pub done: Option<String>,
    pub first_status: Option<String>,
    pub date: Option<String>,
    pub check: Option<String>,
}

pub fn db_info(ws: &Workspace, db: u64) -> DbInfo {
    let mut i = DbInfo { id: db, title: ws.page(db).map(|p| p.title.clone()).unwrap_or_default(), ..Default::default() };
    if let Some(d) = ws.db(db) {
        let status = d.props.iter().find(|p| p.kind == PropKind::Select && norm(&p.name).contains("status")).or_else(|| d.props.iter().find(|p| p.kind == PropKind::Select));
        if let Some(s) = status {
            i.status = Some(s.name.clone());
            i.done = s.opts.iter().find(|o| matches!(norm(&o.name).as_str(), "done" | "complete" | "completed" | "finished" | "closed")).map(|o| o.name.clone()).or_else(|| s.opts.last().map(|o| o.name.clone()));
            i.first_status = s.opts.first().map(|o| o.name.clone());
        }
        i.date = d.props.iter().find(|p| p.kind == PropKind::Date && (norm(&p.name).contains("due") || norm(&p.name).contains("date"))).or_else(|| d.props.iter().find(|p| p.kind == PropKind::Date)).map(|p| p.name.clone());
        i.check = d.props.iter().find(|p| p.kind == PropKind::Checkbox).map(|p| p.name.clone());
    }
    i
}

pub struct Recipe {
    pub name: &'static str,
    pub desc: &'static str,
    pub glyph: &'static str,
    /// Needs a database to be useful.
    pub needs_db: bool,
}

pub const RECIPES: &[Recipe] = &[
    Recipe { name: "Stamp the completion date", desc: "When a task is marked done, record the date it was finished.", glyph: crate::lucide::CALENDAR_CHECK, needs_db: true },
    Recipe { name: "Recurring task", desc: "When a task is done, move its due date forward and reopen it.", glyph: crate::lucide::REPEAT, needs_db: true },
    Recipe { name: "Remind me before the due date", desc: "A notification the day before — desktop on Windows, push on the web.", glyph: crate::lucide::BELL, needs_db: true },
    Recipe { name: "Daily digest", desc: "Every weekday morning: how many items are open and which are overdue.", glyph: crate::lucide::SUNRISE, needs_db: true },
    Recipe { name: "Stamp new rows", desc: "Fill a date property with today's date whenever a row is added.", glyph: crate::lucide::PLUS, needs_db: true },
    Recipe { name: "Quick-add button", desc: "A one-click button (put it on any page with /button) that adds a row.", glyph: crate::lucide::MOUSE_POINTER_CLICK, needs_db: true },
    Recipe { name: "Overdue sweeper (script)", desc: "Every morning a script flags overdue, unfinished items. Edit it to taste.", glyph: crate::lucide::CODE, needs_db: true },
];

pub fn build_recipe(idx: usize, i: &DbInfo) -> Rule {
    let db = i.id;
    let t = &i.title;
    let status = i.status.clone().unwrap_or_else(|| "Status".into());
    let done = i.done.clone().unwrap_or_else(|| "Done".into());
    let date = i.date.clone().unwrap_or_else(|| "Due".into());
    let mut r = match idx {
        0 => {
            let mut r = Rule::blank("Stamp the completion date", Trigger::PropChanged { prop: status.clone(), to: done.clone() });
            r.steps = vec![Step::SetProp { prop: "Completed".into(), value: "today".into() }];
            r
        }
        1 => {
            let (trigger, reset) = match &i.check {
                Some(c) if i.status.is_none() => (Trigger::PropChanged { prop: c.clone(), to: "checked".into() }, (c.clone(), "false".to_owned())),
                _ => (Trigger::PropChanged { prop: status.clone(), to: done.clone() }, (status.clone(), i.first_status.clone().unwrap_or_else(|| "Not started".into()))),
            };
            let mut r = Rule::blank("Recurring task", trigger);
            r.steps = vec![Step::RepeatDate { prop: date.clone(), rule: "weekly".into(), from_done: false, reset_prop: reset.0, reset_value: reset.1 }];
            r.note = "Change \"weekly\" to any rule: \"daily\", \"every 2 weeks\", \"mon,thu\", \"monthly\", \"weekdays\".".into();
            r
        }
        2 => {
            let mut r = Rule::blank("Remind me before the due date", Trigger::DateReached { prop: date.clone(), days_before: 1, time: "09:00".into() });
            r.conditions = vec![Cond { prop: status.clone(), op: CondOp::IsNot, value: done.clone() }];
            r.steps = vec![Step::Notify { title: "Due tomorrow".into(), body: "{title}".into() }];
            r
        }
        3 => {
            let mut r = Rule::blank("Daily digest", Trigger::Schedule(Sched::Weekly { days: Repeat::WEEKDAYS, time: "09:00".into() }));
            r.steps = vec![Step::Script {
                code: format!(
                    "let open = rows(\"{t}\").filter(|r| r[\"{status}\"] != \"{done}\")\nlet late = open.filter(|r| r[\"{date}\"] != null and r[\"{date}\"] < today())\nnotify(\"{t}: {{open.len}} open\", \"{{late.len}} overdue\")"
                ),
            }];
            r
        }
        4 => {
            let mut r = Rule::blank("Stamp new rows", Trigger::RowAdded);
            r.steps = vec![Step::SetProp { prop: "Created".into(), value: "today".into() }];
            r
        }
        5 => {
            let mut r = Rule::blank("Quick-add task", Trigger::Button);
            let mut props = vec![];
            if let (Some(s), Some(f)) = (&i.status, &i.first_status) {
                props.push((s.clone(), f.clone()));
            }
            props.push((date.clone(), "today".into()));
            r.steps = vec![Step::CreateRow { db: t.clone(), title: "New task".into(), props }, Step::Script { code: "toast(\"Added\")".into() }];
            r
        }
        _ => {
            let mut r = Rule::blank("Overdue sweeper", Trigger::Schedule(Sched::Daily { time: "08:00".into() }));
            r.steps = vec![Step::Script {
                code: format!(
                    "// flag every unfinished item whose date has passed\nlet n = 0\nfor r in rows(\"{t}\") {{\n    if r[\"{status}\"] != \"{done}\" and r[\"{date}\"] != null and r[\"{date}\"] < today() {{\n        r.Overdue = true\n        n += 1\n    }}\n}}\nif n > 0 {{ notify(\"{{n}} overdue in {t}\") }}"
                ),
            }];
            r
        }
    };
    r.scope = Scope::Database(db);
    if matches!(r.trigger, Trigger::Button | Trigger::Schedule(_)) && idx != 5 {
        r.scope = Scope::Database(db);
    }
    r
}

// ───────────────────────────── machine-readable spec ─────────────────────────────

/// Everything a program (or a future assistant) needs to write rules and scripts: the JSON shapes, the functions, the
/// variables, and one worked example. Exposed in the UI ("Copy spec") and testable.
pub fn spec_json() -> String {
    let example = {
        let mut r = Rule::blank("Recurring task", Trigger::PropChanged { prop: "Status".into(), to: "Done".into() });
        r.steps = vec![Step::RepeatDate { prop: "Due".into(), rule: "weekly".into(), from_done: false, reset_prop: "Status".into(), reset_value: "Not started".into() }];
        r.scope = Scope::Database(0);
        r
    };
    let funcs: Vec<serde_json::Value> = script::BUILTINS.iter().chain(HOST_FUNCS.iter()).map(|(n, s, d)| serde_json::json!({"name": n, "signature": s, "doc": d})).collect();
    let vars: Vec<serde_json::Value> = SCRIPT_VARS.iter().map(|(n, d)| serde_json::json!({"name": n, "doc": d})).collect();
    let v = serde_json::json!({
        "format": "lumen-automation/1",
        "about": "A rule = trigger + optional conditions + steps. Properties are addressed by name. Text fields in steps are templates: {expr} is Lumen Script. Scripts use only the listed functions.",
        "rule_example": example,
        "triggers": ["RowAdded", "PropChanged{prop,to}", "Button", "Schedule(Every{minutes}|Daily{time}|Weekly{days,time}|Monthly{day,time})", "DateReached{prop,days_before,time}", "AppOpened"],
        "steps": ["SetProp{prop,value}", "CreateRow{db,title,props}", "MoveRow{db}", "AddBlock{page,text,kind}", "Notify{title,body}", "RepeatDate{prop,rule,from_done,reset_prop,reset_value}", "Trash", "Script{code}"],
        "condition_ops": ["Is", "IsNot", "Contains", "Empty", "NotEmpty", "Greater", "Less"],
        "repeat_rules": ["daily", "weekly", "biweekly", "monthly", "quarterly", "yearly", "weekdays", "every 3 days", "every 2 weeks", "mon,thu", "every 2 months"],
        "date_phrases": ["today", "tomorrow", "yesterday", "+3d", "-1w", "+2m", "next monday", "2026-05-01"],
        "script_variables": vars,
        "script_functions": funcs,
        "script_syntax": "let x = 1; if c { } else { }; for r in list { }; while c { }; fn f(a) { return a }; |x| x + 1; \"text {expr}\"; page.Prop = value; list.filter(|r| r.Status == \"Done\")",
    });
    serde_json::to_string_pretty(&v).unwrap_or_default()
}

// ───────────────────────────── tests ─────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::ViewKind;

    /// A database "Tasks" with Status (Not started / In progress / Done), Date and a few rows.
    fn setup() -> (Workspace, u64, u64, Vec<u64>) {
        let mut ws = Workspace::seed();
        let db = ws.add_database(None, ViewKind::Table);
        ws.page_mut(db).unwrap().title = "Tasks".into();
        let status = ws.db(db).unwrap().props.iter().find(|p| p.name == "Status").unwrap().id;
        let date = ws.db(db).unwrap().props.iter().find(|p| p.name == "Date").unwrap().id;
        let rows = ws.rows(db);
        for (i, r) in rows.iter().enumerate() {
            ws.page_mut(*r).unwrap().title = format!("Task {i}");
        }
        (ws, db, status, rows).tap(|_| ())
    }

    trait Tap: Sized {
        fn tap(self, f: impl FnOnce(&Self)) -> Self {
            f(&self);
            self
        }
    }
    impl<T> Tap for T {}

    fn rule(name: &str, trigger: Trigger, steps: Vec<Step>) -> Rule {
        let mut r = Rule::blank(name, trigger);
        r.steps = steps;
        r
    }

    fn text_of(ws: &Workspace, row: u64, prop: &str) -> String {
        let h_ws = ws.clone();
        let mut w = h_ws;
        let h = WsHost::new(&mut w, Some(row));
        match h.read(row, prop).unwrap_or(Value::Null) {
            Value::Str(s) => s,
            Value::Bool(b) => b.to_string(),
            Value::Num(n) => script::fmt_num(n),
            Value::Null => String::new(),
            other => format!("{other:?}"),
        }
    }

    #[test]
    fn set_prop_creates_options_and_properties() {
        let (mut ws, _db, _s, rows) = setup();
        let r = rule("t", Trigger::Button, vec![Step::SetProp { prop: "status".into(), value: "Blocked".into() }, Step::SetProp { prop: "Completed".into(), value: "today".into() }, Step::SetProp { prop: "Score".into(), value: "{2 * 21}".into() }, Step::SetProp { prop: "Title".into(), value: "Renamed {title}".into() }]);
        let rep = run_rule(&mut ws, &r, Some(rows[0]), &TrigInfo::default());
        assert!(rep.ok, "{:?}", rep.error);
        assert_eq!(text_of(&ws, rows[0], "Status"), "Blocked");
        assert_eq!(text_of(&ws, rows[0], "Completed"), dates::today_iso());
        assert_eq!(text_of(&ws, rows[0], "Score"), "42");
        assert_eq!(ws.page(rows[0]).unwrap().title, "Renamed Task 0");
    }

    #[test]
    fn status_change_trigger_with_conditions_and_no_self_loop() {
        let (mut ws, db, status, rows) = setup();
        let done = ws.opt_id(db, status, "Done").unwrap();
        let mut r = rule("stamp", Trigger::PropChanged { prop: "Status".into(), to: "Done".into() }, vec![Step::SetProp { prop: "Completed".into(), value: "today".into() }, Step::SetProp { prop: "Status".into(), value: "Done".into() }]);
        r.scope = Scope::Database(db);
        ws.auto.add(r);
        let mut rt = Runtime::default();
        let mut now = 1_000_000.0;
        tick(&mut ws, &mut rt, now); // primes the snapshot, no events
        assert_eq!(ws.auto.rules[0].runs, 0);
        ws.page_mut(rows[1]).unwrap().props.insert(status, Val::Sel(done));
        now += 500.0;
        let o = tick(&mut ws, &mut rt, now);
        assert_eq!(o.ran, 1, "{:?}", ws.auto.log.last().map(|l| l.msg.clone()));
        assert_eq!(text_of(&ws, rows[1], "Completed"), dates::today_iso());
        // the rule wrote Status itself — it must not trigger again
        now += 500.0;
        tick(&mut ws, &mut rt, now);
        now += 500.0;
        tick(&mut ws, &mut rt, now);
        assert_eq!(ws.auto.rules[0].runs, 1);
        // other rows are untouched
        assert_eq!(text_of(&ws, rows[0], "Completed"), "");
    }

    #[test]
    fn recurring_task_moves_the_date_and_reopens() {
        let (mut ws, db, status, rows) = setup();
        let date = ws.db(db).unwrap().props.iter().find(|p| p.name == "Date").unwrap().id;
        let info = db_info(&ws, db);
        assert_eq!(info.done.as_deref(), Some("Done"));
        let mut rule = build_recipe(1, &info);
        rule.id = 1;
        let today = dates::today_day();
        ws.page_mut(rows[0]).unwrap().props.insert(date, Val::Text(dates::iso_of_day(today + 2)));
        let done = ws.opt_id(db, status, "Done").unwrap();
        ws.page_mut(rows[0]).unwrap().props.insert(status, Val::Sel(done));
        let rep = run_rule(&mut ws, &rule, Some(rows[0]), &TrigInfo::default());
        assert!(rep.ok, "{:?}", rep.error);
        assert_eq!(text_of(&ws, rows[0], "Date"), dates::iso_of_day(today + 9));
        assert_eq!(text_of(&ws, rows[0], "Status"), "Not started");
        // an overdue task jumps to the next future occurrence, not just one step
        ws.page_mut(rows[1]).unwrap().props.insert(date, Val::Text(dates::iso_of_day(today - 20)));
        run_rule(&mut ws, &rule, Some(rows[1]), &TrigInfo::default());
        let next = dates::span(&text_of(&ws, rows[1], "Date")).unwrap().0;
        assert!(next >= today && next < today + 7, "{next} {today}");
    }

    #[test]
    fn scripts_can_query_and_change_the_workspace() {
        let (mut ws, db, status, rows) = setup();
        let done = ws.opt_id(db, status, "Done").unwrap();
        ws.page_mut(rows[0]).unwrap().props.insert(status, Val::Sel(done));
        let code = "let open = rows(\"Tasks\").filter(|r| r.Status != \"Done\")\nfor r in open { r.Priority = \"High\" }\nlet n = create_row(\"Tasks\", {title: \"Summary\", Score: open.len})\nnotify(\"Open\", \"{open.len} open\")\nprint(n.title, n.Score)";
        let r = rule("s", Trigger::Button, vec![Step::Script { code: code.into() }]);
        let rep = run_rule(&mut ws, &r, None, &TrigInfo::default());
        assert!(rep.ok, "{:?}", rep.error);
        assert_eq!(text_of(&ws, rows[1], "Priority"), "High");
        assert_eq!(text_of(&ws, rows[0], "Priority"), "");
        assert!(rep.effects.contains(&Effect::Notify { title: "Open".into(), body: "2 open".into() }));
        assert!(rep.lines.iter().any(|l| l.contains("Summary 2")), "{:?}", rep.lines);
        assert_eq!(ws.rows(db).len(), 4);
        // errors name the line and the problem
        let bad = rule("b", Trigger::Button, vec![Step::Script { code: "let x = 1\nrows(\"Nope\")".into() }]);
        let rep = run_rule(&mut ws, &bad, None, &TrigInfo::default());
        assert!(rep.error.as_deref().unwrap_or("").contains("line 2"), "{:?}", rep.error);
    }

    #[test]
    fn reminders_and_schedules_fire_once() {
        let (mut ws, db, _s, rows) = setup();
        let date = ws.db(db).unwrap().props.iter().find(|p| p.name == "Date").unwrap().id;
        let now = crate::auth::now_ms();
        let today = dates::today_day();
        ws.page_mut(rows[0]).unwrap().props.insert(date, Val::Text(dates::iso_of_day(today + 1)));
        let mut r = rule("remind", Trigger::DateReached { prop: "Date".into(), days_before: 1, time: "00:00".into() }, vec![Step::Notify { title: "Due tomorrow".into(), body: "{title}".into() }]);
        r.scope = Scope::Database(db);
        r.created = now - 3_600_000.0; // created an hour ago, so today's 00:00 instant is already inside the window
        r.last_run = now;
        ws.auto.add(r);
        let mut rt = Runtime::default();
        let o = tick(&mut ws, &mut rt, now);
        let notes: Vec<_> = o.effects.iter().filter(|e| matches!(e, Effect::Notify { .. })).collect();
        // fires if "created" (an hour ago) is before today's 00:00 instant; otherwise it waits — both are valid, but never twice
        let again = tick(&mut ws, &mut rt, now + 1000.0);
        assert!(notes.len() <= 1 && again.effects.iter().all(|e| !matches!(e, Effect::Notify { .. })));
        // schedule maths
        let day = 20_000.0 * DAY_MS;
        let d = Sched::Daily { time: "09:00".into() };
        assert_eq!(latest_instant(&d, day + 10.0 * 3_600_000.0), Some(day + 9.0 * 3_600_000.0));
        assert_eq!(latest_instant(&d, day + 3_600_000.0), Some(day - 15.0 * 3_600_000.0));
        let m = Sched::Monthly { day: 31, time: "00:00".into() };
        assert!(latest_instant(&m, day).is_some());
        let w = Sched::Weekly { days: Repeat::WEEKDAYS, time: "09:00".into() };
        let i = latest_instant(&w, day + 12.0 * 3_600_000.0).unwrap();
        assert!(recur::weekday_of((i / DAY_MS).floor() as i64) < 5);
        // a scheduled rule fires when its instant passed since the last run and is not retroactive for new rules
        let mut s = rule("digest", Trigger::Schedule(Sched::Every { minutes: 5 }), vec![Step::Notify { title: "tick".into(), body: String::new() }]);
        s.last_run = now - 6.0 * 60_000.0;
        s.created = now - 10.0 * 60_000.0;
        let id = ws.auto.add(s);
        ws.auto.rule_mut(id).unwrap().last_run = now - 6.0 * 60_000.0;
        let o = tick(&mut ws, &mut rt, now + 5000.0);
        assert!(o.effects.iter().any(|e| matches!(e, Effect::Notify { title, .. } if title == "tick")));
        let o = tick(&mut ws, &mut rt, now + 6000.0);
        assert!(!o.effects.iter().any(|e| matches!(e, Effect::Notify { title, .. } if title == "tick")));
    }

    #[test]
    fn row_added_waits_for_the_title_and_moves_work() {
        let (mut ws, db, _s, _rows) = setup();
        let mut r = rule("new", Trigger::RowAdded, vec![Step::SetProp { prop: "Created".into(), value: "today".into() }, Step::AddBlock { page: String::new(), text: "Created for {title}".into(), kind: "todo".into() }]);
        r.scope = Scope::Database(db);
        ws.auto.add(r);
        let mut rt = Runtime::default();
        tick(&mut ws, &mut rt, 1000.0);
        let nr = ws.add_row(db, None);
        tick(&mut ws, &mut rt, 1300.0);
        ws.page_mut(nr).unwrap().title = "Typed later".into();
        assert_eq!(ws.auto.rules[0].runs, 0);
        tick(&mut ws, &mut rt, 2600.0);
        assert_eq!(ws.auto.rules[0].runs, 1);
        assert_eq!(ws.page(nr).unwrap().blocks.last().unwrap().text, "Created for Typed later");
        // move to another database keeps matching properties
        let other = ws.add_database(None, ViewKind::Table);
        ws.page_mut(other).unwrap().title = "Archive".into();
        let mv = rule("mv", Trigger::Button, vec![Step::MoveRow { db: "Archive".into() }]);
        let rep = run_rule(&mut ws, &mv, Some(nr), &TrigInfo::default());
        assert!(rep.ok, "{:?}", rep.error);
        assert_eq!(ws.page(nr).unwrap().parent, Some(other));
        assert_eq!(text_of(&ws, nr, "Created"), "");
    }

    #[test]
    fn dry_run_changes_nothing_and_loops_are_guarded() {
        let (mut ws, db, _s, rows) = setup();
        let r = rule("d", Trigger::Button, vec![Step::SetProp { prop: "Status".into(), value: "Done".into() }]);
        let rep = dry_run(&ws, &r, Some(rows[0]));
        assert!(rep.ok);
        assert_eq!(text_of(&ws, rows[0], "Status"), "");
        // two rules that flip a property back and forth would loop forever without the guard
        let mut a = rule("a", Trigger::PropChanged { prop: "Flag".into(), to: "true".into() }, vec![Step::SetProp { prop: "Flag".into(), value: "false".into() }]);
        a.scope = Scope::Database(db);
        let mut b = rule("b", Trigger::PropChanged { prop: "Flag".into(), to: "false".into() }, vec![Step::SetProp { prop: "Flag".into(), value: "true".into() }]);
        b.scope = Scope::Database(db);
        ws.auto.add(a);
        ws.auto.add(b);
        let mut host = WsHost::new(&mut ws, Some(rows[0]));
        host.write(rows[0], "Flag", Value::Bool(false)).unwrap();
        let mut rt = Runtime::default();
        let mut now = 1000.0;
        tick(&mut ws, &mut rt, now);
        ws.page_mut(rows[0]).unwrap().props.iter_mut().for_each(|(_, v)| {
            if let Val::Check(c) = v {
                *c = true;
            }
        });
        let mut guarded = false;
        for _ in 0..60 {
            now += 300.0;
            let o = tick(&mut ws, &mut rt, now);
            guarded |= o.effects.iter().any(|e| matches!(e, Effect::Toast(t) if t.contains("loop")));
        }
        assert!(guarded, "the loop guard must trip");
        assert!(ws.auto.rules.iter().map(|r| r.runs).sum::<u32>() < 40);
    }

    #[test]
    fn serde_roundtrip_spec_and_to_script() {
        let (ws, db, ..) = setup();
        for i in 0..RECIPES.len() {
            let r = build_recipe(i, &db_info(&ws, db));
            let json = serde_json::to_string(&r).unwrap();
            let back: Rule = serde_json::from_str(&json).unwrap();
            assert_eq!(back.steps, r.steps);
            for s in &back.steps {
                if let Step::Script { code } = s {
                    script::parse(code).unwrap_or_else(|e| panic!("recipe {i}: {e}\n{code}"));
                }
                script::parse(&s.to_script()).unwrap_or_else(|e| panic!("to_script {s:?}: {e}"));
            }
        }
        let spec: serde_json::Value = serde_json::from_str(&spec_json()).unwrap();
        assert!(spec["script_functions"].as_array().unwrap().len() > 60);
        // the store survives serialisation inside the workspace
        let mut w2 = ws.clone();
        w2.auto.add(build_recipe(0, &db_info(&ws, db)));
        let s = serde_json::to_string(&w2).unwrap();
        let back: Workspace = serde_json::from_str(&s).unwrap();
        assert_eq!(back.auto.rules.len(), 1);
        // an old workspace without the field still loads
        let mut v: serde_json::Value = serde_json::from_str(&serde_json::to_string(&ws).unwrap()).unwrap();
        v.as_object_mut().unwrap().remove("auto");
        assert!(serde_json::from_value::<Workspace>(v).is_ok());
    }
}
