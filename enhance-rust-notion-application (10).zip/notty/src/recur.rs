//! Repeat rules for date properties ("every 2 weeks", "weekdays", "every mon,thu", "monthly" …).
//!
//! A rule is stored as plain text (so it can be typed in a script, stored in JSON and written by an assistant) and parsed here.
//! `Repeat::next_after(day)` returns the first occurrence strictly after `day` (days are the numbers of `dates::day_of`).

use crate::dates;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Unit {
    Day,
    Week,
    Month,
    Year,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Repeat {
    pub every: u32,
    pub unit: Unit,
    /// Week rules only: bit 0 = Monday … bit 6 = Sunday (0 = same weekday as the previous date).
    pub weekdays: u8,
}

const DAY_NAMES: [&str; 7] = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
const LONG_DAYS: [&str; 7] = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

/// Day of the week (0 = Monday) of a day number.
pub fn weekday_of(day: i64) -> u32 {
    (day + 3).rem_euclid(7) as u32
}

pub fn weekday_name(day: i64) -> &'static str {
    LONG_DAYS[weekday_of(day) as usize]
}

/// Adds calendar months, clamping the day of the month (Jan 31 + 1 month = Feb 28/29).
pub fn add_months(day: i64, months: i64) -> i64 {
    let (y, m, d) = dates::civil_from_days(day);
    let total = y as i64 * 12 + (m as i64 - 1) + months;
    let ny = total.div_euclid(12) as i32;
    let nm = total.rem_euclid(12) as u32 + 1;
    dates::days_from_civil(ny, nm, d.min(dates::days_in_month(ny, nm)))
}

/// Index (0 = Monday) of a weekday word: `mon`, `monday`, `tues` …
fn weekday_word(tok: &str) -> Option<usize> {
    if tok.len() < 3 {
        return None;
    }
    (0..7).find(|&i| LONG_DAYS[i].to_lowercase().starts_with(tok) && tok.starts_with(DAY_NAMES[i]))
}

impl Repeat {
    pub const WEEKDAYS: u8 = 0b0001_1111;

    pub fn parse(text: &str) -> Option<Repeat> {
        let t = text.trim().to_lowercase();
        if t.is_empty() {
            return None;
        }
        let simple = |every, unit| Some(Repeat { every, unit, weekdays: 0 });
        match t.as_str() {
            "daily" | "every day" | "day" => return simple(1, Unit::Day),
            "weekly" | "every week" | "week" => return simple(1, Unit::Week),
            "biweekly" | "fortnightly" => return simple(2, Unit::Week),
            "monthly" | "every month" | "month" => return simple(1, Unit::Month),
            "quarterly" => return simple(3, Unit::Month),
            "yearly" | "annually" | "every year" | "year" => return simple(1, Unit::Year),
            "weekdays" | "every weekday" | "workdays" => return Some(Repeat { every: 1, unit: Unit::Week, weekdays: Self::WEEKDAYS }),
            _ => {}
        }
        let mut every: Option<u32> = None;
        let mut unit: Option<Unit> = None;
        let mut mask = 0u8;
        for tok in t.split(|c: char| c.is_whitespace() || c == ',').filter(|s| !s.is_empty()) {
            if matches!(tok, "every" | "on" | "and" | "each" | "the") {
                continue;
            }
            if let Some(i) = weekday_word(tok) {
                mask |= 1 << i;
                continue;
            }
            // "2w", "3days", "1m", "2", "weeks"
            let digits: String = tok.chars().take_while(|c| c.is_ascii_digit()).collect();
            let rest = &tok[digits.len()..];
            if !digits.is_empty() {
                every = digits.parse().ok();
            }
            if !rest.is_empty() {
                unit = Some(match rest {
                    "d" | "day" | "days" => Unit::Day,
                    "w" | "wk" | "week" | "weeks" => Unit::Week,
                    "m" | "mo" | "month" | "months" => Unit::Month,
                    "y" | "yr" | "year" | "years" => Unit::Year,
                    _ => return None,
                });
            } else if digits.is_empty() {
                return None;
            }
        }
        if mask != 0 {
            return Some(Repeat { every: every.unwrap_or(1).clamp(1, 52), unit: Unit::Week, weekdays: mask });
        }
        Some(Repeat { every: every.unwrap_or(1).clamp(1, 1000), unit: unit?, weekdays: 0 })
    }

    pub fn next_after(&self, day: i64) -> i64 {
        let every = self.every.max(1) as i64;
        match self.unit {
            Unit::Day => day + every,
            Unit::Week if self.weekdays == 0 => day + 7 * every,
            Unit::Week => {
                let week = |d: i64| (d + 3).div_euclid(7);
                let base = week(day);
                for d in day + 1..day + 7 * every + 8 {
                    if self.weekdays & (1 << weekday_of(d)) != 0 && (week(d) - base).rem_euclid(every) == 0 {
                        return d;
                    }
                }
                day + 7 * every
            }
            Unit::Month => add_months(day, every),
            Unit::Year => add_months(day, 12 * every),
        }
    }

    pub fn describe(&self) -> String {
        if self.unit == Unit::Week && self.weekdays == Self::WEEKDAYS && self.every == 1 {
            return "Every weekday".into();
        }
        if self.unit == Unit::Week && self.weekdays != 0 {
            let days: Vec<String> = (0..7).filter(|i| self.weekdays & (1 << i) != 0).map(|i| LONG_DAYS[i][..3].to_owned()).collect();
            return if self.every == 1 { format!("Every {}", days.join(", ")) } else { format!("Every {} weeks on {}", self.every, days.join(", ")) };
        }
        let (one, many) = match self.unit {
            Unit::Day => ("day", "days"),
            Unit::Week => ("week", "weeks"),
            Unit::Month => ("month", "months"),
            Unit::Year => ("year", "years"),
        };
        if self.every == 1 {
            format!("Every {one}")
        } else {
            format!("Every {} {many}", self.every)
        }
    }
}

/// Resolves a date phrase to a day number: `today`, `tomorrow`, `yesterday`, `today+3`, `+2w`, `-1m`, `next monday`, `2026-05-01`.
pub fn resolve_date(text: &str, today: i64) -> Option<i64> {
    let t = text.trim().to_lowercase();
    match t.as_str() {
        "today" | "now" => return Some(today),
        "tomorrow" => return Some(today + 1),
        "yesterday" => return Some(today - 1),
        _ => {}
    }
    if let Some(d) = dates::span(&t) {
        return Some(d.0);
    }
    if let Some(name) = t.strip_prefix("next ") {
        let i = weekday_word(name.trim())?;
        let mut delta = i as i64 - weekday_of(today) as i64;
        if delta <= 0 {
            delta += 7;
        }
        return Some(today + delta);
    }
    let rest = t.strip_prefix("today").unwrap_or(&t).trim();
    let (sign, rest) = match rest.chars().next()? {
        '+' => (1, &rest[1..]),
        '-' => (-1, &rest[1..]),
        _ => return None,
    };
    let rest = rest.trim();
    let digits: String = rest.chars().take_while(|c| c.is_ascii_digit()).collect();
    let n: i64 = digits.parse().ok()?;
    let unit = rest[digits.len()..].trim();
    Some(match unit {
        "" | "d" | "day" | "days" => today + sign * n,
        "w" | "week" | "weeks" => today + sign * 7 * n,
        "m" | "month" | "months" => add_months(today, sign * n),
        "y" | "year" | "years" => add_months(today, sign * 12 * n),
        _ => return None,
    })
}
