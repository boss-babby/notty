//! The Automation Center: one calm place to build rules, recipes, buttons, reminders and scripts.
//!
//! Layout: a modal (full-width on phones) with four tabs — **Automations**, **Recipes**, **Activity**, **Reference**.
//! A rule is edited as three stacked cards, *When → Only if → Then*, with plain fields (no node graph) and a script editor for
//! anything the cards cannot say. Everything stacks vertically so the same screen works at 360 pt and at 1400 pt.
//!
//! Other parts of the app reach the center through [`ask`] (open it, edit a rule, create one for a button) and run rules
//! through [`request_run`]; the app drains both once per frame (`LumenApp::frame`). This keeps blocks and menus free of any
//! reference to the engine.

use std::cell::RefCell;

use egui::{pos2, vec2, Align2, Color32, Context, CornerRadius, Frame, Id, Margin, Rect, RichText, ScrollArea, Sense, Stroke, TextEdit, Ui};

use crate::automation::{self as au, Cond, CondOp, Effect, Report, Rule, Runtime, Sched, Scope, Step, Trigger};
use crate::icons;
use crate::lucide as l;
use crate::model::{PropKind, Workspace};
use crate::script;
use crate::theme::{bold, body, lerp_color, Palette};
use crate::widgets::{primary_button, with_alpha};

// ───────────────────────────── requests from the rest of the app ─────────────────────────────

pub enum Ask {
    /// Open the center on the Automations tab.
    Open,
    /// Open the Recipes tab, preselecting a database.
    Recipes(Option<u64>),
    /// Edit an existing rule.
    Edit(u64),
    /// A new, empty rule (optionally scoped to a database).
    New(Option<u64>),
    /// A new button rule; when saved it is attached to this block (page, block).
    NewButton { page: u64, block: u64 },
}

thread_local! {
    static ASKS: RefCell<Vec<Ask>> = const { RefCell::new(Vec::new()) };
    static RUNS: RefCell<Vec<(u64, Option<u64>)>> = const { RefCell::new(Vec::new()) };
    static NAMES: RefCell<Vec<(u64, String, bool)>> = const { RefCell::new(Vec::new()) };
}

pub fn ask(a: Ask) {
    ASKS.with(|q| q.borrow_mut().push(a));
}

/// Run a rule now (buttons, menus). `row` is the page the click happened on.
pub fn request_run(rule: u64, row: Option<u64>) {
    RUNS.with(|q| q.borrow_mut().push((rule, row)));
}

pub fn take_runs() -> Vec<(u64, Option<u64>)> {
    RUNS.with(|q| std::mem::take(&mut *q.borrow_mut()))
}

/// Id, name and enabled flag of every button-style rule (what a button block can attach to).
pub fn button_rules() -> Vec<(u64, String, bool)> {
    NAMES.with(|n| n.borrow().clone())
}

pub fn publish(ws: &Workspace) {
    NAMES.with(|n| {
        let mut n = n.borrow_mut();
        n.clear();
        n.extend(ws.auto.rules.iter().filter(|r| r.trigger == Trigger::Button).map(|r| (r.id, r.name.clone(), r.enabled)));
    });
}

pub fn rule_name(id: u64) -> Option<(String, bool)> {
    NAMES.with(|n| n.borrow().iter().find(|r| r.0 == id).map(|r| (r.1.clone(), r.2)))
}

// ───────────────────────────── state ─────────────────────────────

#[derive(Clone, Copy, PartialEq, Eq)]
enum Tab {
    Rules,
    Recipes,
    Activity,
    Reference,
}

struct Edit {
    rule: Rule,
    is_new: bool,
    test: Option<(Report, bool)>,
    adv_cond: bool,
}

pub struct UiState {
    pub open: bool,
    tab: Tab,
    edit: Option<Edit>,
    recipe_db: u64,
    test_row: Option<u64>,
    confirm_delete: Option<u64>,
    bind: Option<(u64, u64)>,
    import: String,
    filter: String,
    msg: Option<String>,
}

impl Default for UiState {
    fn default() -> Self {
        UiState { open: false, tab: Tab::Rules, edit: None, recipe_db: 0, test_row: None, confirm_delete: None, bind: None, import: String::new(), filter: String::new(), msg: None }
    }
}

impl UiState {
    pub fn handle_asks(&mut self, ws: &Workspace) {
        let asks: Vec<Ask> = ASKS.with(|q| std::mem::take(&mut *q.borrow_mut()));
        for a in asks {
            self.open = true;
            self.msg = None;
            match a {
                Ask::Open => {
                    self.tab = Tab::Rules;
                    self.edit = None;
                }
                Ask::Recipes(db) => {
                    self.tab = Tab::Recipes;
                    self.edit = None;
                    self.recipe_db = db.or_else(|| first_db(ws)).unwrap_or(0);
                }
                Ask::Edit(id) => {
                    if let Some(r) = ws.auto.rule(id) {
                        self.tab = Tab::Rules;
                        self.edit = Some(Edit { rule: r.clone(), is_new: false, test: None, adv_cond: !r.when.is_empty() });
                    }
                }
                Ask::New(db) => {
                    self.tab = Tab::Rules;
                    let mut r = Rule::blank("", Trigger::PropChanged { prop: String::new(), to: String::new() });
                    if let Some(d) = db {
                        r.scope = Scope::Database(d);
                    }
                    self.edit = Some(Edit { rule: r, is_new: true, test: None, adv_cond: false });
                }
                Ask::NewButton { page, block } => {
                    self.tab = Tab::Rules;
                    self.bind = Some((page, block));
                    let mut r = Rule::blank("My button", Trigger::Button);
                    let db = ws.page(page).filter(|p| p.row).and_then(|p| p.parent);
                    if let Some(d) = db {
                        r.scope = Scope::Database(d);
                    }
                    self.edit = Some(Edit { rule: r, is_new: true, test: None, adv_cond: false });
                }
            }
        }
    }
}

fn first_db(ws: &Workspace) -> Option<u64> {
    ws.pages.iter().find(|p| p.db.is_some() && !p.trashed).map(|p| p.id)
}

fn databases(ws: &Workspace) -> Vec<(u64, String)> {
    ws.pages.iter().filter(|p| p.db.is_some() && !p.trashed).map(|p| (p.id, if p.title.is_empty() { "Untitled".to_owned() } else { p.title.clone() })).collect()
}

fn scope_dbs(ws: &Workspace, s: Scope) -> Vec<u64> {
    match s {
        Scope::Database(d) => vec![d],
        Scope::Workspace => databases(ws).into_iter().map(|d| d.0).collect(),
    }
}

/// Property names (optionally of one kind) in the databases a rule covers — suggestions for the fields.
fn prop_names(ws: &Workspace, s: Scope, kind: Option<PropKind>) -> Vec<String> {
    let mut v: Vec<String> = vec![];
    for d in scope_dbs(ws, s) {
        if let Some(db) = ws.db(d) {
            for p in &db.props {
                if kind.map_or(!p.kind.computed(), |k| p.kind == k) && !v.iter().any(|x| x.eq_ignore_ascii_case(&p.name)) {
                    v.push(p.name.clone());
                }
            }
        }
    }
    v
}

fn option_names(ws: &Workspace, s: Scope, prop: &str) -> Vec<String> {
    let mut v: Vec<String> = vec![];
    for d in scope_dbs(ws, s) {
        if let Some(p) = ws.db(d).and_then(|db| db.props.iter().find(|p| p.name.eq_ignore_ascii_case(prop))) {
            match p.kind {
                PropKind::Select | PropKind::MultiSelect => {
                    for o in &p.opts {
                        if !v.contains(&o.name) {
                            v.push(o.name.clone());
                        }
                    }
                }
                PropKind::Checkbox => {
                    v = vec!["checked".into(), "unchecked".into()];
                }
                _ => {}
            }
        }
    }
    v
}

// ───────────────────────────── small widgets ─────────────────────────────

fn narrow(ui: &Ui) -> bool {
    ui.available_width() < 520.0
}

fn pill(ui: &mut Ui, pal: &Palette, text: &str, selected: bool) -> egui::Response {
    let g = ui.painter().layout_no_wrap(text.to_owned(), body(13.5), pal.text);
    let touch = crate::touch::touchy();
    let h = if touch { 34.0 } else { 28.0 };
    let (rect, resp) = ui.allocate_exact_size(vec2(g.size().x + 22.0, h), Sense::click());
    let t = ui.ctx().animate_bool_with_time(resp.id, resp.hovered(), 0.1);
    let fill = if selected { pal.accent } else { lerp_color(pal.hover, pal.active, t) };
    ui.painter().rect_filled(rect, h / 2.0, fill);
    ui.painter().text(rect.center(), Align2::CENTER_CENTER, text, if selected { bold(13.5) } else { body(13.5) }, if selected { Color32::WHITE } else { pal.text });
    resp.on_hover_cursor(egui::CursorIcon::PointingHand)
}

fn small_btn(ui: &mut Ui, pal: &Palette, glyph: &str, tip: &str, danger: bool) -> egui::Response {
    let side = if crate::touch::touchy() { 36.0 } else { 28.0 };
    let (rect, resp) = ui.allocate_exact_size(vec2(side, side), Sense::click());
    let t = ui.ctx().animate_bool_with_time(resp.id, resp.hovered(), 0.1);
    ui.painter().rect_filled(rect, 7.0, with_alpha(pal.hover, t));
    let col = if danger { lerp_color(pal.muted, pal.danger, t) } else { lerp_color(pal.muted, pal.text, t) };
    icons::glyph(ui.painter(), rect.center(), 15.0, glyph, col);
    resp.on_hover_cursor(egui::CursorIcon::PointingHand).on_hover_text(tip)
}

fn text_btn(ui: &mut Ui, pal: &Palette, glyph: &str, label: &str, primary: bool) -> egui::Response {
    let g = ui.painter().layout_no_wrap(label.to_owned(), bold(13.5), pal.text);
    let h = if crate::touch::touchy() { 38.0 } else { 32.0 };
    let w = g.size().x + 24.0 + if glyph.is_empty() { 0.0 } else { 22.0 };
    let (rect, resp) = ui.allocate_exact_size(vec2(w, h), Sense::click());
    let t = ui.ctx().animate_bool_with_time(resp.id, resp.hovered(), 0.1);
    let (fill, fg) = if primary { (lerp_color(pal.accent, Color32::from_rgb(20, 100, 190), t * 0.5), Color32::WHITE) } else { (lerp_color(pal.hover, pal.active, t), pal.text) };
    ui.painter().rect_filled(rect, 8.0, fill);
    let mut x = rect.left() + 12.0;
    if !glyph.is_empty() {
        icons::glyph(ui.painter(), pos2(x + 7.0, rect.center().y), 14.0, glyph, fg);
        x += 22.0;
    }
    ui.painter().text(pos2(x, rect.center().y), Align2::LEFT_CENTER, label, bold(13.5), fg);
    resp.on_hover_cursor(egui::CursorIcon::PointingHand)
}

fn toggle(ui: &mut Ui, pal: &Palette, on: &mut bool) -> bool {
    let (rect, resp) = ui.allocate_exact_size(vec2(40.0, 24.0), Sense::click());
    let t = ui.ctx().animate_bool_with_time(resp.id, *on, 0.14);
    ui.painter().rect_filled(rect, 12.0, lerp_color(pal.active, pal.accent, t));
    let x = rect.left() + 12.0 + t * 16.0;
    ui.painter().circle_filled(pos2(x, rect.center().y), 9.0, Color32::WHITE);
    let clicked = resp.on_hover_cursor(egui::CursorIcon::PointingHand).clicked();
    if clicked {
        *on = !*on;
    }
    clicked
}

fn card<R>(ui: &mut Ui, pal: &Palette, add: impl FnOnce(&mut Ui) -> R) -> R {
    let w = ui.available_width();
    Frame::new()
        .fill(pal.card)
        .stroke(Stroke::new(1.0_f32, pal.border))
        .corner_radius(CornerRadius::same(10))
        .inner_margin(Margin::same(12))
        .show(ui, |ui| {
            ui.set_width(w - 26.0);
            let r = add(ui);
            r
        })
        .inner
}

fn caption(ui: &mut Ui, pal: &Palette, text: &str) {
    ui.label(RichText::new(text).font(bold(11.5)).color(pal.muted));
}

fn hint(ui: &mut Ui, pal: &Palette, text: &str) {
    ui.add(egui::Label::new(RichText::new(text).font(body(12.5)).color(pal.muted)).wrap());
}

fn field(ui: &mut Ui, pal: &Palette, id: Id, text: &mut String, hint_text: &str, width: f32) -> bool {
    let focused = ui.memory(|m| m.has_focus(id));
    let t = ui.ctx().animate_bool_with_time(id.with("f"), focused, 0.12);
    let stroke = Stroke::new(1.0_f32 + t * 0.6, lerp_color(pal.border.gamma_multiply(1.5), pal.accent, t));
    Frame::new()
        .fill(pal.bg)
        .stroke(stroke)
        .corner_radius(CornerRadius::same(8))
        .inner_margin(Margin::symmetric(10, 7))
        .show(ui, |ui| {
            ui.add(TextEdit::singleline(text).id(id).frame(false).hint_text(RichText::new(hint_text).color(with_alpha(pal.muted, 0.8))).desired_width((width - 22.0).max(40.0)).margin(Margin::ZERO).font(body(14.0))).changed()
        })
        .inner
}

/// A text field with a ▾ menu of suggestions.
fn suggest(ui: &mut Ui, pal: &Palette, id: Id, text: &mut String, hint_text: &str, options: &[String], width: f32) -> bool {
    let mut changed = false;
    ui.horizontal(|ui| {
        ui.spacing_mut().item_spacing.x = 4.0;
        let has = !options.is_empty();
        changed |= field(ui, pal, id, text, hint_text, width - if has { 36.0 } else { 0.0 });
        if has {
            let (rect, resp) = ui.allocate_exact_size(vec2(32.0, 33.0), Sense::click());
            let t = ui.ctx().animate_bool_with_time(resp.id, resp.hovered(), 0.1);
            ui.painter().rect_filled(rect, 8.0, lerp_color(pal.hover, pal.active, t));
            icons::glyph(ui.painter(), rect.center(), 14.0, l::CHEVRON_DOWN, pal.muted);
            let pid = id.with("menu");
            if resp.clicked() {
                ui.memory_mut(|m| m.toggle_popup(pid));
            }
            egui::popup_below_widget(ui, pid, &resp, egui::PopupCloseBehavior::CloseOnClick, |ui| {
                ui.set_min_width(180.0);
                ScrollArea::vertical().max_height(260.0).show(ui, |ui| {
                    for o in options {
                        if ui.selectable_label(o == text, o).clicked() {
                            *text = o.clone();
                            changed = true;
                        }
                    }
                });
            });
        }
    });
    changed
}

/// A drop-down list of (value, label) choices.
fn choose<T: PartialEq + Clone>(ui: &mut Ui, id: Id, cur: &mut T, items: &[(T, String)], width: f32) -> bool {
    let label = items.iter().find(|i| i.0 == *cur).map(|i| i.1.clone()).unwrap_or_else(|| "—".into());
    let mut changed = false;
    egui::ComboBox::from_id_salt(id).selected_text(label).width(width).show_ui(ui, |ui| {
        for (v, name) in items {
            if ui.selectable_label(v == cur, name).clicked() {
                *cur = v.clone();
                changed = true;
            }
        }
    });
    changed
}

fn code_box(ui: &mut Ui, pal: &Palette, id: Id, code: &mut String, rows: usize) -> bool {
    let mut changed = false;
    Frame::new().fill(pal.code_bg).stroke(Stroke::new(1.0_f32, pal.border)).corner_radius(CornerRadius::same(8)).inner_margin(Margin::same(8)).show(ui, |ui| {
        let w = ui.available_width();
        changed = ui.add(TextEdit::multiline(code).id(id).code_editor().frame(false).margin(Margin::ZERO).desired_rows(rows).desired_width(w).lock_focus(true).hint_text("// write Lumen Script here")).changed();
    });
    changed
}

fn script_status(ui: &mut Ui, pal: &Palette, code: &str) -> bool {
    if code.trim().is_empty() {
        hint(ui, pal, "Empty script — it will do nothing.");
        return true;
    }
    match script::parse(code) {
        Ok(_) => {
            ui.label(RichText::new(format!("{}  Syntax OK", l::CIRCLE_CHECK)).font(body(12.5)).color(Color32::from_rgb(68, 131, 97)));
            true
        }
        Err(e) => {
            ui.add(egui::Label::new(RichText::new(format!("{}  {e}", l::CIRCLE_ALERT)).font(body(12.5)).color(pal.danger)).wrap());
            false
        }
    }
}

// ───────────────────────────── the modal ─────────────────────────────

pub fn show(ctx: &Context, ws: &mut Workspace, rt: &mut Runtime, st: &mut UiState, pal: &Palette) {
    if !st.open {
        return;
    }
    let screen = ctx.screen_rect();
    let top = if screen.width() < 560.0 { 8.0 } else { 36.0 };
    let max_h = (screen.height() - top - 28.0).max(240.0);
    let open = crate::app::modal(ctx, Id::new("auto_center"), pal, 780.0, top, |ui| {
        ui.set_max_height(max_h);
        header(ui, ws, st, pal);
        ui.add_space(6.0);
        ScrollArea::vertical().id_salt("auto_scroll").max_height(max_h - 74.0).auto_shrink([false, true]).show(ui, |ui| {
            ui.add_space(2.0);
            if st.edit.is_some() {
                editor(ui, ws, rt, st, pal);
            } else {
                match st.tab {
                    Tab::Rules => rules_tab(ui, ws, rt, st, pal),
                    Tab::Recipes => recipes_tab(ui, ws, st, pal),
                    Tab::Activity => activity_tab(ui, ws, st, pal),
                    Tab::Reference => reference_tab(ui, ws, st, pal),
                }
            }
            ui.add_space(6.0);
        });
    });
    if !open {
        st.open = false;
        st.edit = None;
        st.bind = None;
    }
}

fn header(ui: &mut Ui, ws: &mut Workspace, st: &mut UiState, pal: &Palette) {
    ui.horizontal(|ui| {
        ui.add_space(6.0);
        icons::glyph(ui.painter(), ui.cursor().left_center() + vec2(8.0, 0.0), 18.0, l::ZAP, pal.accent);
        ui.add_space(24.0);
        ui.label(RichText::new("Automations").font(bold(17.0)).color(pal.text));
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if small_btn(ui, pal, l::X, "Close", false).clicked() {
                st.open = false;
                st.edit = None;
            }
            let mut on = !ws.auto.paused;
            if toggle(ui, pal, &mut on) {
                ws.auto.paused = !on;
            }
            ui.label(RichText::new(if ws.auto.paused { "Paused" } else { "Running" }).font(body(12.5)).color(pal.muted));
        });
    });
    if st.edit.is_none() {
        ui.add_space(4.0);
        ScrollArea::horizontal().id_salt("auto_tabs").auto_shrink([false, true]).show(ui, |ui| {
            ui.horizontal(|ui| {
                ui.add_space(6.0);
                let n = ws.auto.rules.len();
                for (t, label) in [(Tab::Rules, format!("Automations ({n})")), (Tab::Recipes, "Recipes".to_owned()), (Tab::Activity, "Activity".to_owned()), (Tab::Reference, "Script & reference".to_owned())] {
                    if pill(ui, pal, &label, st.tab == t).clicked() {
                        st.tab = t;
                        st.msg = None;
                    }
                }
            });
        });
    }
}

// ───────────────────────────── automations tab ─────────────────────────────

fn rules_tab(ui: &mut Ui, ws: &mut Workspace, rt: &mut Runtime, st: &mut UiState, pal: &Palette) {
    ui.horizontal_wrapped(|ui| {
        ui.add_space(6.0);
        if text_btn(ui, pal, l::PLUS, "New automation", true).clicked() {
            ask(Ask::New(first_db(ws)));
        }
        if text_btn(ui, pal, l::SPARKLES, "Browse recipes", false).clicked() {
            st.tab = Tab::Recipes;
            st.recipe_db = first_db(ws).unwrap_or(0);
        }
    });
    ui.add_space(8.0);
    permission_banner(ui, pal);
    if ws.auto.rules.is_empty() {
        card(ui, pal, |ui| {
            ui.add_space(6.0);
            ui.vertical_centered(|ui| {
                icons::glyph(ui.painter(), ui.cursor().center_top() + vec2(0.0, 18.0), 30.0, l::WORKFLOW, pal.muted);
                ui.add_space(46.0);
                ui.label(RichText::new("Nothing automated yet").font(bold(16.0)));
                ui.add_space(4.0);
            });
            hint(ui, pal, "Automations do the repetitive parts for you: stamp a date when a task is done, repeat a weekly task, remind you the day before something is due, or add a row with one click from a button on any page.");
            ui.add_space(8.0);
            hint(ui, pal, "Start from a recipe — each one is a normal automation you can change. Or write your own with a script.");
            ui.add_space(6.0);
        });
        return;
    }
    let ids: Vec<u64> = ws.auto.rules.iter().map(|r| r.id).collect();
    for id in ids {
        let Some(rule) = ws.auto.rule(id).cloned() else { continue };
        let mut enabled = rule.enabled;
        let (mut edit, mut run, mut del) = (false, false, false);
        card(ui, pal, |ui| {
            ui.horizontal(|ui| {
                if toggle(ui, pal, &mut enabled) {
                    if let Some(r) = ws.auto.rule_mut(id) {
                        r.enabled = enabled;
                    }
                }
                ui.add_space(4.0);
                ui.vertical(|ui| {
                    ui.add(egui::Label::new(RichText::new(if rule.name.is_empty() { "Untitled automation" } else { &rule.name }).font(bold(15.0)).color(if rule.enabled { pal.text } else { pal.muted })).wrap());
                });
            });
            ui.add_space(2.0);
            ui.add(egui::Label::new(RichText::new(rule.summary()).font(body(13.0)).color(pal.muted)).wrap());
            let scope = match rule.scope {
                Scope::Workspace => "Everywhere".to_owned(),
                Scope::Database(d) => ws.page(d).map(|p| format!("In {}", if p.title.is_empty() { "Untitled" } else { &p.title })).unwrap_or_else(|| "Database missing".into()),
            };
            let last = if rule.runs == 0 { "never run".to_owned() } else { format!("ran {}× · {}", rule.runs, crate::app::ago(rule.last_run)) };
            hint(ui, pal, &format!("{scope}  ·  {last}"));
            if !rule.last_error.is_empty() {
                ui.add(egui::Label::new(RichText::new(format!("{}  {}", l::CIRCLE_ALERT, rule.last_error)).font(body(12.5)).color(pal.danger)).wrap());
            }
            ui.add_space(6.0);
            ui.horizontal_wrapped(|ui| {
                if rule.trigger == Trigger::Button && text_btn(ui, pal, l::PLAY, "Run now", true).clicked() {
                    run = true;
                }
                if text_btn(ui, pal, l::PENCIL, "Edit", false).clicked() {
                    edit = true;
                }
                if small_btn(ui, pal, l::TRASH_2, "Delete", true).clicked() {
                    del = true;
                }
            });
            if st.confirm_delete == Some(id) {
                ui.add_space(4.0);
                ui.horizontal_wrapped(|ui| {
                    ui.label(RichText::new("Delete this automation?").font(body(13.0)).color(pal.danger));
                    if text_btn(ui, pal, "", "Delete", true).clicked() {
                        ws.auto.remove(id);
                        st.confirm_delete = None;
                    }
                    if text_btn(ui, pal, "", "Cancel", false).clicked() {
                        st.confirm_delete = None;
                    }
                });
            }
        });
        ui.add_space(8.0);
        if edit {
            ask(Ask::Edit(id));
        }
        if run {
            rt.manual.push((id, None));
        }
        if del {
            st.confirm_delete = Some(id);
        }
    }
}

fn permission_banner(ui: &mut Ui, pal: &Palette) {
    let perm = crate::platform::notification_permission();
    if perm == "granted" {
        return;
    }
    card(ui, pal, |ui| {
        ui.horizontal_wrapped(|ui| {
            icons::glyph(ui.painter(), ui.cursor().left_center() + vec2(8.0, 0.0), 16.0, l::BELL, pal.accent);
            ui.add_space(24.0);
            if perm == "denied" {
                hint(ui, pal, "Notifications are blocked for this site — allow them in the browser's site settings to get reminders.");
            } else {
                hint(ui, pal, "Allow notifications to get reminders and automation alerts.");
                if text_btn(ui, pal, "", "Enable notifications", true).clicked() {
                    crate::platform::request_notification_permission();
                }
            }
        });
    });
    ui.add_space(8.0);
}

fn sample_row(ws: &Workspace, scope: Scope) -> Option<u64> {
    scope_dbs(ws, scope).into_iter().find_map(|d| ws.rows(d).into_iter().next())
}

// ───────────────────────────── recipes tab ─────────────────────────────

fn recipes_tab(ui: &mut Ui, ws: &mut Workspace, st: &mut UiState, pal: &Palette) {
    let dbs = databases(ws);
    if dbs.is_empty() {
        card(ui, pal, |ui| hint(ui, pal, "Recipes work on a database (a table of tasks, projects, contacts …). Create a database first — then come back."));
        return;
    }
    if !dbs.iter().any(|d| d.0 == st.recipe_db) {
        st.recipe_db = dbs[0].0;
    }
    ui.horizontal(|ui| {
        ui.add_space(6.0);
        ui.label(RichText::new("For database").font(body(13.5)).color(pal.muted));
        let items: Vec<(u64, String)> = dbs.clone();
        choose(ui, Id::new("recipe_db"), &mut st.recipe_db, &items, 200.0);
    });
    ui.add_space(8.0);
    let info = au::db_info(ws, st.recipe_db);
    for (i, r) in au::RECIPES.iter().enumerate() {
        let mut add = false;
        card(ui, pal, |ui| {
            ui.horizontal(|ui| {
                let (rect, _) = ui.allocate_exact_size(vec2(36.0, 36.0), Sense::hover());
                ui.painter().rect_filled(rect, 9.0, pal.accent_soft);
                icons::glyph(ui.painter(), rect.center(), 17.0, r.glyph, pal.accent);
                ui.add_space(4.0);
                ui.vertical(|ui| {
                    ui.label(RichText::new(r.name).font(bold(14.5)));
                    ui.add(egui::Label::new(RichText::new(r.desc).font(body(13.0)).color(pal.muted)).wrap());
                });
            });
            ui.add_space(4.0);
            if text_btn(ui, pal, l::PLUS, "Use this recipe", false).clicked() {
                add = true;
            }
        });
        ui.add_space(8.0);
        if add {
            let rule = au::build_recipe(i, &info);
            st.tab = Tab::Rules;
            st.edit = Some(Edit { adv_cond: !rule.when.is_empty(), rule, is_new: true, test: None });
        }
    }
}

// ───────────────────────────── activity tab ─────────────────────────────

fn activity_tab(ui: &mut Ui, ws: &mut Workspace, _st: &mut UiState, pal: &Palette) {
    ui.horizontal_wrapped(|ui| {
        ui.add_space(6.0);
        ui.label(RichText::new(format!("{} runs recorded", ws.auto.log.len())).font(body(13.0)).color(pal.muted));
        if !ws.auto.log.is_empty() && text_btn(ui, pal, l::TRASH_2, "Clear", false).clicked() {
            ws.auto.log.clear();
        }
    });
    ui.add_space(6.0);
    if ws.auto.log.is_empty() {
        card(ui, pal, |ui| hint(ui, pal, "When an automation runs, what it did (or why it failed) shows up here."));
        return;
    }
    for e in ws.auto.log.iter().rev().take(80) {
        card(ui, pal, |ui| {
            ui.horizontal(|ui| {
                let c = if e.ok { Color32::from_rgb(68, 131, 97) } else { pal.danger };
                let (r, _) = ui.allocate_exact_size(vec2(10.0, 18.0), Sense::hover());
                ui.painter().circle_filled(r.center(), 4.0, c);
                ui.label(RichText::new(&e.name).font(bold(13.5)));
                ui.label(RichText::new(crate::app::ago(e.ts)).font(body(12.0)).color(pal.muted));
            });
            ui.add(egui::Label::new(RichText::new(&e.msg).font(body(12.5)).color(if e.ok { pal.muted } else { pal.danger })).wrap());
        });
        ui.add_space(6.0);
    }
}

// ───────────────────────────── reference tab ─────────────────────────────

const SAMPLE: &str = "// Lumen Script: a tiny, safe language. Run it from any automation's \"Script\" step.\nlet open = rows(\"Tasks\").filter(|t| t.Status != \"Done\")\nlet late = open.filter(|t| t.Due != null and t.Due < today())\n\nfor t in late {\n    t.Priority = \"High\"              // assigning to a field writes the property\n}\nif late.len > 0 {\n    notify(\"{late.len} overdue\", join(late.map(|t| t.title), \", \"))\n}";

fn reference_tab(ui: &mut Ui, ws: &mut Workspace, st: &mut UiState, pal: &Palette) {
    let ctx = ui.ctx().clone();
    card(ui, pal, |ui| {
        ui.label(RichText::new("Lumen Script in a minute").font(bold(15.0)));
        hint(ui, pal, "Every automation can contain scripts, and every visual step can be turned into one (Edit → Convert to script). Scripts see the row that triggered them as row, its database as db, and the trigger details as trigger.");
        ui.add_space(6.0);
        let mut s = SAMPLE.to_owned();
        code_box(ui, pal, Id::new("ref_sample"), &mut s, 11);
        ui.add_space(4.0);
        ui.horizontal_wrapped(|ui| {
            if text_btn(ui, pal, l::COPY, "Copy example", false).clicked() {
                ctx.copy_text(SAMPLE.to_owned());
                st.msg = Some("Example copied".into());
            }
        });
        ui.add_space(4.0);
        hint(ui, pal, "Values: numbers, \"text {with} {expressions}\", true / false / null, [lists], {maps}. Pages are live: row.Status reads, row.Status = \"Done\" writes. Control flow: if / else, for x in list, while, fn name(a) { … }, |x| x + 1. Operators: + - * / %  == != < > <= >=  and or not  ??  a..b. Method style works for every function: list.filter(…) is filter(list, …).");
    });
    ui.add_space(8.0);
    card(ui, pal, |ui| {
        ui.label(RichText::new("Triggers").font(bold(15.0)));
        for (n, d) in [
            ("A property changes", "e.g. Status becomes Done — fires once the edit settles."),
            ("A row is added", "fires about a second later so the title you type is already there."),
            ("A button is pressed", "put a button anywhere with /button, or run from here."),
            ("On a schedule", "every N minutes, daily, weekdays, weekly, monthly."),
            ("A date arrives", "N days before a date property, at a time — reminders."),
            ("The app opens", "once per launch."),
        ] {
            ui.horizontal_wrapped(|ui| {
                ui.label(RichText::new(n).font(bold(13.0)));
                ui.label(RichText::new(d).font(body(13.0)).color(pal.muted));
            });
        }
        ui.add_space(4.0);
        hint(ui, pal, "Safety: a rule never reacts to its own changes, chains of rules are limited, scripts stop after 400 000 steps, and Test runs on a copy of your data.");
    });
    ui.add_space(8.0);
    card(ui, pal, |ui| {
        ui.label(RichText::new("Functions").font(bold(15.0)));
        field(ui, pal, Id::new("ref_filter"), &mut st.filter, "Filter functions…", ui.available_width());
        ui.add_space(4.0);
        let q = st.filter.trim().to_lowercase();
        let mut copied: Option<String> = None;
        let groups: [(&str, &[(&str, &str, &str)]); 2] = [("Your workspace", au::HOST_FUNCS), ("Built in", script::BUILTINS)];
        for (title, list) in groups {
            let shown: Vec<&(&str, &str, &str)> = list.iter().filter(|f| q.is_empty() || f.0.contains(&q) || f.2.to_lowercase().contains(&q)).collect();
            if shown.is_empty() {
                continue;
            }
            caption(ui, pal, &title.to_uppercase());
            for (_, sig, doc) in shown {
                let resp = ui.add(egui::Label::new(RichText::new(*sig).font(egui::FontId::monospace(12.5)).color(pal.accent)).sense(Sense::click()).wrap());
                if resp.on_hover_cursor(egui::CursorIcon::PointingHand).clicked() {
                    copied = Some((*sig).to_owned());
                }
                ui.add(egui::Label::new(RichText::new(*doc).font(body(12.5)).color(pal.muted)).wrap());
                ui.add_space(3.0);
            }
        }
        if let Some(c) = copied {
            ctx.copy_text(c);
            st.msg = Some("Copied".into());
        }
        ui.add_space(4.0);
        caption(ui, pal, "VARIABLES");
        for (n, d) in au::SCRIPT_VARS {
            ui.horizontal_wrapped(|ui| {
                ui.label(RichText::new(*n).font(egui::FontId::monospace(12.5)).color(pal.accent));
                ui.label(RichText::new(*d).font(body(12.5)).color(pal.muted));
            });
        }
    });
    ui.add_space(8.0);
    card(ui, pal, |ui| {
        ui.label(RichText::new("Share, back up, hand to an assistant").font(bold(15.0)));
        hint(ui, pal, "Rules are plain JSON and travel with your workspace backups. The API spec lists every trigger, step and function in one machine-readable document — the same format an assistant will use to write automations for you.");
        ui.add_space(6.0);
        ui.horizontal_wrapped(|ui| {
            if text_btn(ui, pal, l::COPY, "Copy rules (JSON)", false).clicked() {
                ctx.copy_text(serde_json::to_string_pretty(&ws.auto.rules).unwrap_or_default());
                st.msg = Some(format!("{} rule(s) copied", ws.auto.rules.len()));
            }
            if text_btn(ui, pal, l::COPY, "Copy API spec", false).clicked() {
                ctx.copy_text(au::spec_json());
                st.msg = Some("API spec copied".into());
            }
        });
        ui.add_space(6.0);
        caption(ui, pal, "IMPORT RULES — paste JSON");
        let w = ui.available_width();
        Frame::new().fill(pal.code_bg).stroke(Stroke::new(1.0_f32, pal.border)).corner_radius(CornerRadius::same(8)).inner_margin(Margin::same(8)).show(ui, |ui| {
            ui.add(TextEdit::multiline(&mut st.import).id(Id::new("auto_import")).code_editor().frame(false).margin(Margin::ZERO).desired_rows(3).desired_width(w - 20.0).hint_text("[ { \"name\": … } ]  or a single rule"));
        });
        ui.add_space(4.0);
        if !st.import.trim().is_empty() && text_btn(ui, pal, l::PLUS, "Import", true).clicked() {
            let txt = st.import.trim().to_owned();
            let parsed: Result<Vec<Rule>, _> = serde_json::from_str::<Vec<Rule>>(&txt).or_else(|_| serde_json::from_str::<Rule>(&txt).map(|r| vec![r]));
            match parsed {
                Ok(rules) => {
                    let n = rules.len();
                    for mut r in rules {
                        r.runs = 0;
                        r.last_run = 0.0;
                        r.created = 0.0;
                        ws.auto.add(r);
                    }
                    st.import.clear();
                    st.msg = Some(format!("Imported {n} automation(s)"));
                }
                Err(e) => st.msg = Some(format!("Couldn't read that: {e}")),
            }
        }
    });
    if let Some(m) = &st.msg {
        ui.add_space(6.0);
        hint(ui, pal, m);
    }
}

// ───────────────────────────── rule editor ─────────────────────────────

const TRIGGER_KINDS: [&str; 6] = ["A property changes", "A row is added", "A button is pressed", "On a schedule", "A date arrives (reminder)", "The app opens"];

fn trigger_index(t: &Trigger) -> usize {
    match t {
        Trigger::PropChanged { .. } => 0,
        Trigger::RowAdded => 1,
        Trigger::Button => 2,
        Trigger::Schedule(_) => 3,
        Trigger::DateReached { .. } => 4,
        Trigger::AppOpened => 5,
    }
}

fn default_trigger(i: usize, ws: &Workspace, scope: Scope) -> Trigger {
    match i {
        0 => Trigger::PropChanged { prop: prop_names(ws, scope, Some(PropKind::Select)).first().cloned().unwrap_or_default(), to: String::new() },
        1 => Trigger::RowAdded,
        2 => Trigger::Button,
        3 => Trigger::Schedule(Sched::Daily { time: "09:00".into() }),
        4 => Trigger::DateReached { prop: prop_names(ws, scope, Some(PropKind::Date)).first().cloned().unwrap_or_default(), days_before: 1, time: "09:00".into() },
        _ => Trigger::AppOpened,
    }
}

fn editor(ui: &mut Ui, ws: &mut Workspace, rt: &mut Runtime, st: &mut UiState, pal: &Palette) {
    let Some(mut ed) = st.edit.take() else { return };
    let mut close = false;
    let mut save = false;
    let mut delete = false;
    let mut test = false;
    let mut to_script = false;
    let scope = ed.rule.scope;

    ui.horizontal(|ui| {
        ui.add_space(4.0);
        if text_btn(ui, pal, l::CHEVRON_LEFT, "Automations", false).clicked() {
            close = true;
        }
    });
    ui.add_space(8.0);
    // ── name ──
    card(ui, pal, |ui| {
        caption(ui, pal, "NAME");
        let w = ui.available_width();
        field(ui, pal, Id::new("ed_name"), &mut ed.rule.name, "Name this automation", w);
        ui.add_space(6.0);
        ui.horizontal_wrapped(|ui| {
            ui.label(RichText::new("Works on").font(body(13.5)).color(pal.muted));
            let mut items: Vec<(Scope, String)> = vec![(Scope::Workspace, "Every database".to_owned())];
            items.extend(databases(ws).into_iter().map(|(id, t)| (Scope::Database(id), t)));
            choose(ui, Id::new("ed_scope"), &mut ed.rule.scope, &items, 190.0);
            ui.add_space(8.0);
            let mut on = ed.rule.enabled;
            if toggle(ui, pal, &mut on) {
                ed.rule.enabled = on;
            }
            ui.label(RichText::new(if ed.rule.enabled { "On" } else { "Off" }).font(body(13.0)).color(pal.muted));
        });
    });
    ui.add_space(10.0);

    // ── WHEN ──
    card(ui, pal, |ui| {
        caption(ui, pal, "WHEN");
        let mut ti = trigger_index(&ed.rule.trigger);
        let items: Vec<(usize, String)> = TRIGGER_KINDS.iter().enumerate().map(|(i, s)| (i, (*s).to_owned())).collect();
        if choose(ui, Id::new("ed_trig"), &mut ti, &items, 240.0) {
            ed.rule.trigger = default_trigger(ti, ws, scope);
        }
        ui.add_space(6.0);
        let w = ui.available_width();
        match &mut ed.rule.trigger {
            Trigger::PropChanged { prop, to } => {
                caption(ui, pal, "PROPERTY (EMPTY = ANY)");
                let names = prop_names(ws, scope, None);
                suggest(ui, pal, Id::new("ed_tprop"), prop, "e.g. Status", &names, w);
                ui.add_space(4.0);
                caption(ui, pal, "BECOMES (EMPTY = ANY VALUE)");
                let opts = option_names(ws, scope, prop);
                suggest(ui, pal, Id::new("ed_tto"), to, "e.g. Done", &opts, w);
            }
            Trigger::RowAdded => hint(ui, pal, "Fires about a second after a row appears, so a title typed right away is already in place."),
            Trigger::Button => hint(ui, pal, "Add a button to any page with /button, or press Run now in the list. On a row's page the button runs for that row."),
            Trigger::AppOpened => hint(ui, pal, "Runs once every time Lumen starts."),
            Trigger::DateReached { prop, days_before, time } => {
                caption(ui, pal, "DATE PROPERTY");
                let names = prop_names(ws, scope, Some(PropKind::Date));
                suggest(ui, pal, Id::new("ed_dprop"), prop, "e.g. Due", &names, w);
                ui.add_space(4.0);
                ui.horizontal_wrapped(|ui| {
                    ui.add(egui::DragValue::new(days_before).range(-365..=365).speed(0.2));
                    ui.label(RichText::new(if *days_before > 0 { "day(s) before, at" } else if *days_before == 0 { "on the day, at" } else { "day(s) after, at" }).font(body(13.5)).color(pal.muted));
                    field(ui, pal, Id::new("ed_dtime"), time, "09:00", 80.0);
                });
                hint(ui, pal, "Negative numbers fire after the date (overdue nudges). On Windows this is a desktop notification, on the web a push notification.");
            }
            Trigger::Schedule(s) => schedule_editor(ui, pal, s, w),
        }
    });
    ui.add_space(10.0);

    // ── ONLY IF ──
    card(ui, pal, |ui| {
        caption(ui, pal, "ONLY IF");
        if ed.rule.conditions.is_empty() && !ed.adv_cond {
            hint(ui, pal, "No conditions — it runs every time.");
        }
        let names = prop_names(ws, scope, None);
        let mut remove: Option<usize> = None;
        let w = ui.available_width();
        for (i, c) in ed.rule.conditions.iter_mut().enumerate() {
            ui.add_space(2.0);
            suggest(ui, pal, Id::new(("ed_cp", i)), &mut c.prop, "Property", &names, w);
            ui.horizontal_wrapped(|ui| {
                let items: Vec<(CondOp, String)> = CondOp::ALL.iter().map(|o| (*o, o.label().to_owned())).collect();
                choose(ui, Id::new(("ed_co", i)), &mut c.op, &items, 170.0);
                if c.op.needs_value() {
                    let opts = option_names(ws, scope, &c.prop);
                    suggest(ui, pal, Id::new(("ed_cv", i)), &mut c.value, "value, e.g. Done or today", &opts, (w - 190.0).max(150.0));
                }
                if small_btn(ui, pal, l::X, "Remove", true).clicked() {
                    remove = Some(i);
                }
            });
            ui.add_space(4.0);
        }
        if let Some(i) = remove {
            ed.rule.conditions.remove(i);
        }
        ui.horizontal_wrapped(|ui| {
            if text_btn(ui, pal, l::PLUS, "Add condition", false).clicked() {
                ed.rule.conditions.push(Cond { prop: names.first().cloned().unwrap_or_default(), op: CondOp::IsNot, value: String::new() });
            }
            if !ed.adv_cond && text_btn(ui, pal, l::CODE, "Script condition", false).clicked() {
                ed.adv_cond = true;
            }
        });
        if ed.adv_cond {
            ui.add_space(6.0);
            caption(ui, pal, "SCRIPT CONDITION (MUST BE TRUE)");
            let w = ui.available_width();
            field(ui, pal, Id::new("ed_when"), &mut ed.rule.when, "row.Due < today() and row.Priority == \"High\"", w);
            script_status(ui, pal, &ed.rule.when);
        }
    });
    ui.add_space(10.0);

    // ── THEN ──
    card(ui, pal, |ui| {
        caption(ui, pal, "THEN");
        if ed.rule.steps.is_empty() {
            hint(ui, pal, "Add at least one step.");
        }
        let n = ed.rule.steps.len();
        let mut action: Option<(usize, i8)> = None; // (index, -1 up / 1 down / 0 delete)
        for i in 0..n {
            ui.add_space(4.0);
            let outer = ui.available_width();
            Frame::new().fill(pal.bg).stroke(Stroke::new(1.0_f32, pal.border)).corner_radius(CornerRadius::same(9)).inner_margin(Margin::same(10)).show(ui, |ui| {
                let w = outer - 22.0;
                ui.set_width(w);
                ui.horizontal(|ui| {
                    ui.label(RichText::new(format!("{}. {}", i + 1, ed.rule.steps[i].kind_label())).font(bold(13.5)));
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if small_btn(ui, pal, l::TRASH_2, "Remove step", true).clicked() {
                            action = Some((i, 0));
                        }
                        if i + 1 < n && small_btn(ui, pal, l::CHEVRON_DOWN, "Move down", false).clicked() {
                            action = Some((i, 1));
                        }
                        if i > 0 && small_btn(ui, pal, l::CHEVRON_UP, "Move up", false).clicked() {
                            action = Some((i, -1));
                        }
                    });
                });
                ui.add_space(4.0);
                step_editor(ui, ws, pal, scope, i, &mut ed.rule.steps[i], w);
            });
        }
        if let Some((i, a)) = action {
            match a {
                0 => {
                    ed.rule.steps.remove(i);
                }
                1 => ed.rule.steps.swap(i, i + 1),
                _ => ed.rule.steps.swap(i, i - 1),
            }
        }
        ui.add_space(8.0);
        add_step_menu(ui, pal, &mut ed.rule.steps, ws, scope);
    });
    ui.add_space(10.0);

    // ── test & save ──
    card(ui, pal, |ui| {
        caption(ui, pal, "TRY IT");
        let rows = row_choices(ws, scope);
        if st.test_row.map_or(true, |r| !rows.iter().any(|x| x.0 == r)) {
            st.test_row = rows.first().map(|r| r.0);
        }
        if !rows.is_empty() && ed.rule.trigger != Trigger::AppOpened && !matches!(ed.rule.trigger, Trigger::Schedule(_)) {
            ui.horizontal_wrapped(|ui| {
                ui.label(RichText::new("On row").font(body(13.5)).color(pal.muted));
                let mut cur = st.test_row;
                let items: Vec<(Option<u64>, String)> = rows.iter().map(|(id, t)| (Some(*id), t.clone())).collect();
                if choose(ui, Id::new("ed_testrow"), &mut cur, &items, 220.0) {
                    st.test_row = cur;
                }
            });
        }
        ui.add_space(4.0);
        ui.horizontal_wrapped(|ui| {
            if text_btn(ui, pal, l::FLASK_CONICAL, "Test (changes nothing)", false).clicked() {
                test = true;
            }
            if text_btn(ui, pal, l::CODE, "Convert to script", false).clicked() {
                to_script = true;
            }
        });
        if let Some((rep, _)) = &ed.test {
            ui.add_space(6.0);
            report_view(ui, pal, rep);
        }
    });
    ui.add_space(10.0);
    let script_ok = ed.rule.steps.iter().all(|s| if let Step::Script { code } = s { script::parse(code).is_ok() } else { true }) && (ed.rule.when.trim().is_empty() || script::parse(&ed.rule.when).is_ok());
    ui.horizontal_wrapped(|ui| {
        if !script_ok {
            hint(ui, pal, "Fix the script errors above to save.");
        } else if text_btn(ui, pal, l::CIRCLE_CHECK, "Save", true).clicked() {
            save = true;
        }
        if text_btn(ui, pal, "", "Cancel", false).clicked() {
            close = true;
        }
        if !ed.is_new && small_btn(ui, pal, l::TRASH_2, "Delete this automation", true).clicked() {
            delete = true;
        }
    });

    // ── apply actions ──
    if test {
        let row = if matches!(ed.rule.trigger, Trigger::Schedule(_) | Trigger::AppOpened) { None } else { st.test_row };
        let rep = au::dry_run(ws, &ed.rule, row);
        ed.test = Some((rep, true));
    }
    if to_script {
        let code: Vec<String> = ed.rule.steps.iter().map(|s| s.to_script()).collect();
        ed.rule.steps = vec![Step::Script { code: code.join("\n") }];
    }
    if save {
        if ed.rule.name.trim().is_empty() {
            ed.rule.name = ed.rule.trigger_text();
        }
        if !ed.adv_cond {
            ed.rule.when.clear();
        }
        let id = if ed.is_new {
            ws.auto.add(ed.rule.clone())
        } else {
            let id = ed.rule.id;
            if let Some(r) = ws.auto.rule_mut(id) {
                let (runs, last, created) = (r.runs, r.last_run, r.created);
                *r = ed.rule.clone();
                r.runs = runs;
                r.last_run = last;
                r.created = created;
                r.last_error.clear();
            }
            id
        };
        if let Some((page, block)) = st.bind.take() {
            if let Some(b) = ws.page_mut(page).and_then(|p| p.blocks.iter_mut().find(|b| b.id == block)) {
                b.link = Some(id);
                if b.text.is_empty() {
                    b.text = ed.rule.name.clone();
                }
            }
        }
        close = true;
    }
    if delete {
        ws.auto.remove(ed.rule.id);
        close = true;
    }
    if close {
        st.bind = None;
        st.edit = None;
    } else {
        st.edit = Some(ed);
    }
    let _ = rt;
}

/// "+ Add step" with a menu of step kinds.
fn add_step_menu(ui: &mut Ui, pal: &Palette, steps: &mut Vec<Step>, ws: &Workspace, scope: Scope) {
    let resp = text_btn(ui, pal, l::PLUS, "Add step", false);
    let dates = prop_names(ws, scope, Some(PropKind::Date));
    let statuses = prop_names(ws, scope, Some(PropKind::Select));
    let pid = Id::new("add_step_menu");
    if resp.clicked() {
        ui.memory_mut(|m| m.toggle_popup(pid));
    }
    egui::popup_below_widget(ui, pid, &resp, egui::PopupCloseBehavior::CloseOnClick, |ui| {
        ui.set_min_width(230.0);
        let kinds: Vec<(&str, &str, Step)> = vec![
            (l::PENCIL, "Set a property", Step::SetProp { prop: statuses.first().cloned().unwrap_or_default(), value: String::new() }),
            (l::PLUS, "Add a row", Step::CreateRow { db: String::new(), title: "New item".into(), props: vec![] }),
            (l::REPEAT, "Repeat a date", Step::RepeatDate { prop: dates.first().cloned().unwrap_or_else(|| "Due".into()), rule: "weekly".into(), from_done: false, reset_prop: statuses.first().cloned().unwrap_or_default(), reset_value: String::new() }),
            (l::BELL, "Send a notification", Step::Notify { title: "Reminder".into(), body: "{title}".into() }),
            (l::FILE_PLUS, "Add a note to a page", Step::AddBlock { page: String::new(), text: "{today()}: ".into(), kind: "bullet".into() }),
            (l::FILE_UP, "Move to another database", Step::MoveRow { db: String::new() }),
            (l::TRASH_2, "Move to trash", Step::Trash),
            (l::CODE, "Run a script", Step::Script { code: "// row, db, title and trigger are available\n".into() }),
        ];
        for (g, label, step) in kinds {
            if ui.selectable_label(false, format!("{g}   {label}")).clicked() {
                steps.push(step);
            }
        }
    });
}

fn row_choices(ws: &Workspace, scope: Scope) -> Vec<(u64, String)> {
    let mut v = vec![];
    for d in scope_dbs(ws, scope) {
        for r in ws.rows(d).into_iter().take(40) {
            let t = ws.page(r).map(|p| if p.title.is_empty() { "Untitled".to_owned() } else { p.title.clone() }).unwrap_or_default();
            v.push((r, t));
        }
        if v.len() > 80 {
            break;
        }
    }
    v
}

fn report_view(ui: &mut Ui, pal: &Palette, rep: &Report) {
    if !rep.matched {
        hint(ui, pal, "Conditions not met for this row — nothing would happen. Pick another row or relax a condition.");
        return;
    }
    if let Some(e) = &rep.error {
        ui.add(egui::Label::new(RichText::new(format!("{}  {e}", l::CIRCLE_ALERT)).font(body(13.0)).color(pal.danger)).wrap());
    } else {
        ui.label(RichText::new(format!("{}  Would run fine — nothing was changed", l::CIRCLE_CHECK)).font(body(13.0)).color(Color32::from_rgb(68, 131, 97)));
    }
    for line in &rep.lines {
        ui.add(egui::Label::new(RichText::new(format!("•  {line}")).font(body(12.5)).color(pal.muted)).wrap());
    }
    for e in &rep.effects {
        let t = match e {
            Effect::Notify { title, body } => format!("🔔  {title} {body}"),
            Effect::Toast(m) => format!("💬  {m}"),
            Effect::Open(_) => "Opens a page".to_owned(),
        };
        ui.add(egui::Label::new(RichText::new(t).font(body(12.5)).color(pal.muted)).wrap());
    }
}

fn schedule_editor(ui: &mut Ui, pal: &Palette, s: &mut Sched, w: f32) {
    #[derive(Clone, Copy, PartialEq)]
    enum K {
        Every,
        Daily,
        Weekdays,
        Weekly,
        Monthly,
    }
    let mut k = match s {
        Sched::Every { .. } => K::Every,
        Sched::Daily { .. } => K::Daily,
        Sched::Weekly { days, .. } if *days == crate::recur::Repeat::WEEKDAYS => K::Weekdays,
        Sched::Weekly { .. } => K::Weekly,
        Sched::Monthly { .. } => K::Monthly,
    };
    let time_of = |s: &Sched| match s {
        Sched::Daily { time } | Sched::Weekly { time, .. } | Sched::Monthly { time, .. } => time.clone(),
        _ => "09:00".to_owned(),
    };
    let items = vec![(K::Every, "Every few minutes / hours".to_owned()), (K::Daily, "Every day".to_owned()), (K::Weekdays, "Every weekday (Mon–Fri)".to_owned()), (K::Weekly, "On chosen weekdays".to_owned()), (K::Monthly, "Every month".to_owned())];
    let before = k;
    choose(ui, Id::new("ed_sched"), &mut k, &items, 240.0);
    if k != before {
        let t = time_of(s);
        *s = match k {
            K::Every => Sched::Every { minutes: 60 },
            K::Daily => Sched::Daily { time: t },
            K::Weekdays => Sched::Weekly { days: crate::recur::Repeat::WEEKDAYS, time: t },
            K::Weekly => Sched::Weekly { days: 0b0000_0001, time: t },
            K::Monthly => Sched::Monthly { day: 1, time: t },
        };
    }
    ui.add_space(4.0);
    match s {
        Sched::Every { minutes } => {
            ui.horizontal_wrapped(|ui| {
                ui.label(RichText::new("Every").font(body(13.5)).color(pal.muted));
                ui.add(egui::DragValue::new(minutes).range(1..=10_080).speed(1.0).suffix(" min"));
                for (m, label) in [(15u32, "15 min"), (60, "1 hour"), (180, "3 hours"), (1440, "1 day")] {
                    if pill(ui, pal, label, *minutes == m).clicked() {
                        *minutes = m;
                    }
                }
            });
        }
        Sched::Daily { time } | Sched::Monthly { time, .. } | Sched::Weekly { time, .. } if k != K::Weekly && k != K::Monthly => {
            ui.horizontal_wrapped(|ui| {
                ui.label(RichText::new("At").font(body(13.5)).color(pal.muted));
                field(ui, pal, Id::new("ed_stime"), time, "09:00", 90.0);
            });
        }
        Sched::Weekly { days, time } => {
            ui.horizontal_wrapped(|ui| {
                for (i, n) in ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].iter().enumerate() {
                    if pill(ui, pal, n, *days & (1 << i) != 0).clicked() {
                        *days ^= 1 << i;
                        if *days == 0 {
                            *days = 1 << i;
                        }
                    }
                }
            });
            ui.horizontal_wrapped(|ui| {
                ui.label(RichText::new("At").font(body(13.5)).color(pal.muted));
                field(ui, pal, Id::new("ed_stime2"), time, "09:00", 90.0);
            });
        }
        Sched::Monthly { day, time } => {
            ui.horizontal_wrapped(|ui| {
                ui.label(RichText::new("On day").font(body(13.5)).color(pal.muted));
                ui.add(egui::DragValue::new(day).range(1..=31));
                ui.label(RichText::new("at").font(body(13.5)).color(pal.muted));
                field(ui, pal, Id::new("ed_stime3"), time, "09:00", 90.0);
            });
        }
        _ => {}
    }
    let _ = w;
    hint(ui, pal, "Runs while Lumen is open (and, on the web, reminders also appear when the tab is in the background). A schedule missed while the app was closed runs once when you return.");
}

fn step_editor(ui: &mut Ui, ws: &Workspace, pal: &Palette, scope: Scope, i: usize, step: &mut Step, w: f32) {
    let names = prop_names(ws, scope, None);
    let dates = prop_names(ws, scope, Some(PropKind::Date));
    let dbs: Vec<String> = databases(ws).into_iter().map(|d| d.1).collect();
    let id = |k: &str| Id::new(("step", i, k.to_owned()));
    match step {
        Step::SetProp { prop, value } => {
            caption(ui, pal, "PROPERTY (CREATED IF IT DOESN'T EXIST)");
            suggest(ui, pal, id("p"), prop, "e.g. Status", &names, w);
            ui.add_space(4.0);
            caption(ui, pal, "SET TO");
            let mut opts = option_names(ws, scope, prop);
            if dates.iter().any(|d| d.eq_ignore_ascii_case(prop)) {
                opts = vec!["today".into(), "tomorrow".into(), "+3d".into(), "+1w".into(), "next monday".into(), String::new()];
                opts.pop();
            }
            suggest(ui, pal, id("v"), value, "text, Done, today, +3d, {title} …", &opts, w);
            hint(ui, pal, "Anything in { } is evaluated: {title}, {row.Status}, {add_days(today(), 3)}.");
        }
        Step::CreateRow { db, title, props } => {
            caption(ui, pal, "DATABASE (EMPTY = SAME AS THE ROW)");
            suggest(ui, pal, id("db"), db, "e.g. Tasks", &dbs, w);
            ui.add_space(4.0);
            caption(ui, pal, "TITLE");
            field(ui, pal, id("t"), title, "e.g. Follow up: {title}", w);
            ui.add_space(4.0);
            caption(ui, pal, "PROPERTIES");
            let mut rm = None;
            for (k, (name, val)) in props.iter_mut().enumerate() {
                ui.horizontal(|ui| {
                    field(ui, pal, id(&format!("n{k}")), name, "Property", (w - 60.0) * 0.4);
                    field(ui, pal, id(&format!("pv{k}")), val, "Value", (w - 60.0) * 0.6);
                    if small_btn(ui, pal, l::X, "Remove", true).clicked() {
                        rm = Some(k);
                    }
                });
            }
            if let Some(k) = rm {
                props.remove(k);
            }
            if text_btn(ui, pal, l::PLUS, "Add property", false).clicked() {
                props.push((String::new(), String::new()));
            }
        }
        Step::MoveRow { db } => {
            caption(ui, pal, "MOVE TO DATABASE");
            suggest(ui, pal, id("db"), db, "e.g. Archive", &dbs, w);
            hint(ui, pal, "Properties with the same name are carried over.");
        }
        Step::AddBlock { page, text, kind } => {
            caption(ui, pal, "PAGE (EMPTY = THIS PAGE)");
            field(ui, pal, id("pg"), page, "page title", w);
            ui.add_space(4.0);
            caption(ui, pal, "TEXT");
            field(ui, pal, id("tx"), text, "{today()}: reviewed", w);
            ui.add_space(4.0);
            ui.horizontal_wrapped(|ui| {
                for (k, n) in [("text", "Text"), ("bullet", "Bullet"), ("todo", "To-do"), ("quote", "Quote"), ("callout", "Callout")] {
                    if pill(ui, pal, n, kind == k || (kind.is_empty() && k == "text")).clicked() {
                        *kind = k.to_owned();
                    }
                }
            });
        }
        Step::Notify { title, body } => {
            caption(ui, pal, "TITLE");
            field(ui, pal, id("t"), title, "Due tomorrow", w);
            ui.add_space(4.0);
            caption(ui, pal, "MESSAGE");
            field(ui, pal, id("b"), body, "{title}", w);
            hint(ui, pal, "Windows: desktop notification. Web: push notification. Always also shown in the app.");
        }
        Step::RepeatDate { prop, rule, from_done, reset_prop, reset_value } => {
            caption(ui, pal, "DATE PROPERTY");
            suggest(ui, pal, id("p"), prop, "e.g. Due", &dates, w);
            ui.add_space(4.0);
            caption(ui, pal, "REPEAT");
            field(ui, pal, id("r"), rule, "weekly, every 2 weeks, mon,thu …", w);
            ui.horizontal_wrapped(|ui| {
                for r in ["daily", "weekdays", "weekly", "every 2 weeks", "monthly", "yearly"] {
                    if pill(ui, pal, r, rule.trim() == r).clicked() {
                        *rule = r.to_owned();
                    }
                }
            });
            match crate::recur::Repeat::parse(rule) {
                Some(r) => hint(ui, pal, &format!("{} — next date after {}", r.describe(), crate::dates::pretty(&crate::dates::iso_of_day(r.next_after(crate::dates::today_day()))))),
                None => {
                    ui.label(RichText::new("Don't understand that rule — try \"weekly\", \"every 3 days\" or \"mon,thu\".").font(body(12.5)).color(pal.danger));
                }
            }
            ui.add_space(4.0);
            let mut b = *from_done;
            if ui.checkbox(&mut b, RichText::new("Count from the completion date instead of the due date").font(body(13.0))).changed() {
                *from_done = b;
            }
            ui.add_space(4.0);
            caption(ui, pal, "THEN RESET (OPTIONAL)");
            suggest(ui, pal, id("rp"), reset_prop, "property, e.g. Status", &names, w);
            let opts = option_names(ws, scope, reset_prop);
            suggest(ui, pal, id("rv"), reset_value, "value, e.g. Not started", &opts, w);
        }
        Step::Trash => hint(ui, pal, "The row goes to the trash — you can restore it from there."),
        Step::Script { code } => {
            let lines = code.lines().count().clamp(6, 18);
            code_box(ui, pal, id("code"), code, lines);
            script_status(ui, pal, code);
            ui.add_space(4.0);
            ui.horizontal_wrapped(|ui| {
                for (label, snip) in [
                    ("for each row", "for r in rows(\"Tasks\") {\n    \n}\n"),
                    ("set property", "row.Status = \"Done\"\n"),
                    ("notify", "notify(\"Title\", \"Message {title}\")\n"),
                    ("create row", "create_row(\"Tasks\", {title: \"New\", Status: \"Not started\"})\n"),
                    ("next date", "row.Due = next_date(row.Due, \"weekly\")\n"),
                ] {
                    if pill(ui, pal, label, false).clicked() {
                        if !code.ends_with('\n') && !code.is_empty() {
                            code.push('\n');
                        }
                        code.push_str(snip);
                    }
                }
            });
        }
    }
}

// ───────────────────────────── effects ─────────────────────────────

/// Applies the effects of runs: notifications, toasts, navigation. Returns toast texts for the app to show.
pub fn apply_effects(ws: &mut Workspace, effects: Vec<Effect>) -> Vec<String> {
    let mut toasts = vec![];
    for e in effects {
        match e {
            Effect::Notify { title, body } => {
                crate::platform::notify(&title, &body);
                toasts.push(if body.is_empty() { format!("🔔 {title}") } else { format!("🔔 {title} — {body}") });
            }
            Effect::Toast(t) => toasts.push(t),
            Effect::Open(id) => {
                if ws.page(id).map_or(false, |p| !p.trashed) {
                    crate::views::set(crate::views::Mode::Page, None);
                    ws.current = Some(id);
                }
            }
        }
    }
    toasts
}

// ───────────────────────────── block: the one-click button ─────────────────────────────

/// Draws a button block. Returns true when the block changed (label edited, rule attached / detached).
pub fn button_block(ui: &mut Ui, b: &mut crate::model::Block, page_id: u64, pal: &Palette, w: f32) -> bool {
    let ctx = ui.ctx().clone();
    let mut changed = false;
    let rules = button_rules();
    let linked = b.link.and_then(|id| rules.iter().find(|r| r.0 == id).cloned());
    let Some((rid, rname, enabled)) = linked else {
        // not attached yet (or the rule was deleted): pick one or create one
        Frame::new().fill(pal.hover).stroke(Stroke::new(1.0_f32, pal.border)).corner_radius(CornerRadius::same(10)).inner_margin(Margin::symmetric(14, 12)).show(ui, |ui| {
            ui.set_width(w - 30.0);
            ui.horizontal(|ui| {
                icons::glyph(ui.painter(), ui.cursor().left_center() + vec2(9.0, 0.0), 18.0, l::MOUSE_POINTER_CLICK, pal.accent);
                ui.add_space(26.0);
                ui.label(RichText::new("Button").font(bold(15.0)));
            });
            ui.add(egui::Label::new(RichText::new("One click runs an automation on this page — add a task, set a date, send a reminder.").font(body(13.0)).color(pal.muted)).wrap());
            ui.add_space(6.0);
            ui.horizontal_wrapped(|ui| {
                if text_btn(ui, pal, l::PLUS, "Create button action", true).clicked() {
                    ask(Ask::NewButton { page: page_id, block: b.id });
                }
                for (id, name, _) in rules.iter().take(4) {
                    if text_btn(ui, pal, l::ZAP, name, false).clicked() {
                        b.link = Some(*id);
                        if b.text.is_empty() {
                            b.text = name.clone();
                        }
                        changed = true;
                    }
                }
            });
        });
        return changed;
    };
    let label = if b.text.trim().is_empty() { rname.clone() } else { b.text.clone() };
    let id = Id::new(("btn_blk", b.id));
    let g = ui.painter().layout_no_wrap(label.clone(), bold(14.5), Color32::WHITE);
    let height = if crate::touch::touchy() { 44.0 } else { 36.0 };
    let bw = (g.size().x + 54.0).min(w).max(120.0);
    ui.horizontal(|ui| {
        let (rect, resp) = ui.allocate_exact_size(vec2(bw, height), Sense::click());
        let hov = ui.ctx().animate_bool_with_time(id.with("h"), resp.hovered(), 0.12);
        let flash_at: f64 = ctx.data(|d| d.get_temp(id.with("flash"))).unwrap_or(0.0);
        let since = (ctx.input(|i| i.time) - flash_at) as f32;
        let flash = if since < 0.9 { 1.0 - since / 0.9 } else { 0.0 };
        if flash > 0.0 {
            ctx.request_repaint();
        }
        let base = if enabled { pal.accent } else { pal.muted };
        let fill = lerp_color(lerp_color(base, Color32::from_rgb(20, 100, 190), hov * 0.5), Color32::from_rgb(68, 131, 97), flash);
        let r = if resp.is_pointer_button_down_on() { rect.shrink(1.5) } else { rect };
        ui.painter().rect_filled(r, 9.0, fill);
        let glyph = if flash > 0.3 { l::CIRCLE_CHECK } else { l::MOUSE_POINTER_CLICK };
        icons::glyph(ui.painter(), pos2(r.left() + 20.0, r.center().y), 16.0, glyph, Color32::WHITE);
        crate::widgets::text_fit(ui.painter(), pos2(r.left() + 38.0, r.center().y), Align2::LEFT_CENTER, &label, bold(14.5), Color32::WHITE, r.width() - 48.0);
        if resp.on_hover_cursor(egui::CursorIcon::PointingHand).clicked() {
            if enabled {
                request_run(rid, Some(page_id));
                ctx.data_mut(|d| d.insert_temp(id.with("flash"), ctx.input(|i| i.time)));
            } else {
                crate::dashcfg::set_toast("That automation is switched off — enable it in Automations");
            }
        }
        if crate::touch::reveal(ui.rect_contains_pointer(rect.expand2(vec2(180.0, 4.0)))) {
            ui.add_space(6.0);
            if small_btn(ui, pal, l::PENCIL, "Edit the automation", false).clicked() {
                ask(Ask::Edit(rid));
            }
            if small_btn(ui, pal, l::X, "Detach (keeps the automation)", false).clicked() {
                b.link = None;
                changed = true;
            }
        }
    });
    // the label: a quiet, always-available text field under the button
    let edit_id = id.with("label");
    let mut t = b.text.clone();
    let r = ui.add(TextEdit::singleline(&mut t).id(edit_id).frame(false).font(body(12.5)).text_color(pal.muted).hint_text(format!("Button label (now: {rname})")).desired_width(bw.max(180.0)).margin(Margin::symmetric(2, 4)));
    if r.changed() {
        b.text = t;
        changed = true;
    }
    changed
}
