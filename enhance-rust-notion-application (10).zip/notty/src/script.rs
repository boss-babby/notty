//! **Lumen Script** — the small, safe scripting language behind every automation.
//!
//! * Pure Rust, no dependencies, identical on Windows and WebAssembly. It never touches the file system or the network:
//!   the only way a script can affect the world is through the [`Host`] it is given (the workspace, in the app).
//! * Familiar syntax (Rust / JavaScript flavoured), newlines or `;` end statements:
//!
//! ```text
//! // comments with // or #
//! let tasks = rows("Tasks").filter(|r| r.Status != "Done" and r.Due < today())
//! for t in tasks {
//!     t.Priority = "High"                       // assigning to a page field writes the database property
//!     notify("Overdue", "{t.title} was due {t.Due}")
//! }
//! fn bump(d, n) { return add_days(d, n) }
//! ```
//! * Values: `null`, booleans, numbers, strings (`"Hi {name}"` interpolates `{expr}`; `\{` escapes), lists, maps and
//!   page handles (rows / pages / databases). Functions are values (`fn(x) { x * 2 }`, `|x| x * 2`).
//! * Safe by construction: a step budget stops runaway loops, call depth and list sizes are capped.
//! * Embedding: implement [`Host`], then call [`run`] / [`eval_template`]. Errors carry line numbers ([`ScriptError`]),
//!   [`parse`] checks syntax without running (live validation in the editor, and for generated scripts).

use std::cell::RefCell;
use std::cmp::Ordering;
use std::collections::{BTreeMap, HashMap};
use std::fmt;
use std::rc::Rc;

use crate::dates;
use crate::recur::{self, Repeat};

// ───────────────────────────── values ─────────────────────────────

#[derive(Clone)]
pub enum Value {
    Null,
    Bool(bool),
    Num(f64),
    Str(String),
    List(Rc<RefCell<Vec<Value>>>),
    Map(Rc<RefCell<BTreeMap<String, Value>>>),
    /// A page, database row or database (host-defined meaning, usually a page id).
    Page(u64),
    Func(Rc<Closure>),
}

pub struct Closure {
    def: Rc<FnDef>,
    env: Env,
}

impl fmt::Debug for Value {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Value::Null => write!(f, "null"),
            Value::Bool(b) => write!(f, "{b}"),
            Value::Num(n) => write!(f, "{}", fmt_num(*n)),
            Value::Str(s) => write!(f, "{s:?}"),
            Value::List(l) => write!(f, "{:?}", l.borrow()),
            Value::Map(m) => write!(f, "{:?}", m.borrow()),
            Value::Page(p) => write!(f, "page#{p}"),
            Value::Func(c) => write!(f, "<fn {}>", c.def.name),
        }
    }
}

impl Value {
    pub fn list(v: Vec<Value>) -> Value {
        Value::List(Rc::new(RefCell::new(v)))
    }
    pub fn map(v: BTreeMap<String, Value>) -> Value {
        Value::Map(Rc::new(RefCell::new(v)))
    }
    pub fn str(s: impl Into<String>) -> Value {
        Value::Str(s.into())
    }
    pub fn truthy(&self) -> bool {
        match self {
            Value::Null => false,
            Value::Bool(b) => *b,
            Value::Num(n) => *n != 0.0,
            Value::Str(s) => !s.is_empty(),
            Value::List(l) => !l.borrow().is_empty(),
            Value::Map(m) => !m.borrow().is_empty(),
            Value::Page(_) | Value::Func(_) => true,
        }
    }
    pub fn type_name(&self) -> &'static str {
        match self {
            Value::Null => "null",
            Value::Bool(_) => "bool",
            Value::Num(_) => "number",
            Value::Str(_) => "string",
            Value::List(_) => "list",
            Value::Map(_) => "map",
            Value::Page(_) => "page",
            Value::Func(_) => "function",
        }
    }
    pub fn as_num(&self) -> Option<f64> {
        match self {
            Value::Num(n) => Some(*n),
            Value::Bool(b) => Some(*b as u8 as f64),
            Value::Str(s) => s.trim().parse().ok(),
            _ => None,
        }
    }
    pub fn items(&self) -> Vec<Value> {
        match self {
            Value::List(l) => l.borrow().clone(),
            Value::Null => vec![],
            other => vec![other.clone()],
        }
    }
}

pub fn fmt_num(n: f64) -> String {
    if n.is_nan() {
        return "NaN".into();
    }
    if n.is_infinite() {
        return if n > 0.0 { "∞".into() } else { "-∞".into() };
    }
    if n.fract() == 0.0 && n.abs() < 1e15 {
        return format!("{}", n as i64);
    }
    let s = format!("{n:.10}");
    s.trim_end_matches('0').trim_end_matches('.').to_owned()
}

pub fn eq_vals(a: &Value, b: &Value) -> bool {
    match (a, b) {
        (Value::Null, Value::Null) => true,
        (Value::Bool(x), Value::Bool(y)) => x == y,
        (Value::Num(x), Value::Num(y)) => x == y,
        (Value::Str(x), Value::Str(y)) => x == y,
        (Value::Page(x), Value::Page(y)) => x == y,
        (Value::List(x), Value::List(y)) => {
            let (x, y) = (x.borrow(), y.borrow());
            x.len() == y.len() && x.iter().zip(y.iter()).all(|(p, q)| eq_vals(p, q))
        }
        (Value::Map(x), Value::Map(y)) => {
            let (x, y) = (x.borrow(), y.borrow());
            x.len() == y.len() && x.iter().all(|(k, v)| y.get(k).map_or(false, |w| eq_vals(v, w)))
        }
        (Value::Func(x), Value::Func(y)) => Rc::ptr_eq(x, y),
        _ => false,
    }
}

fn cmp_vals(a: &Value, b: &Value) -> Result<Ordering, String> {
    match (a, b) {
        (Value::Num(x), Value::Num(y)) => Ok(x.partial_cmp(y).unwrap_or(Ordering::Equal)),
        (Value::Str(x), Value::Str(y)) => Ok(x.cmp(y)),
        (Value::Bool(x), Value::Bool(y)) => Ok(x.cmp(y)),
        (Value::Page(x), Value::Page(y)) => Ok(x.cmp(y)),
        (Value::Null, Value::Null) => Ok(Ordering::Equal),
        (Value::Null, _) => Ok(Ordering::Less),
        (_, Value::Null) => Ok(Ordering::Greater),
        _ => Err(format!("cannot compare {} with {}", a.type_name(), b.type_name())),
    }
}

// ───────────────────────────── errors ─────────────────────────────

#[derive(Clone, Debug, PartialEq)]
pub struct ScriptError {
    pub line: u32,
    pub msg: String,
}

impl fmt::Display for ScriptError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if self.line > 0 {
            write!(f, "line {}: {}", self.line, self.msg)
        } else {
            write!(f, "{}", self.msg)
        }
    }
}

fn err<T>(line: u32, msg: impl Into<String>) -> Result<T, ScriptError> {
    Err(ScriptError { line, msg: msg.into() })
}

// ───────────────────────────── lexer ─────────────────────────────

#[derive(Clone, Debug, PartialEq)]
enum Sp {
    Lit(String),
    Code(String, u32),
}

#[derive(Clone, Debug, PartialEq)]
enum T {
    Num(f64),
    Str(Vec<Sp>),
    Id(String),
    P(&'static str),
    Nl,
    Eof,
}

const PUNCT: [&str; 36] = [
    "==", "!=", "<=", ">=", "&&", "||", "??", "..", "+=", "-=", "*=", "/=", "%=", "+", "-", "*", "/", "%", "=", "<", ">", "!", "(", ")", "{", "}", "[", "]", ",", ".", ":", ";", "|", "?", "@", "$",
];

fn scan_str(ch: &[char], i: &mut usize, quote: Option<char>, line: &mut u32) -> Result<Vec<Sp>, ScriptError> {
    let start = *line;
    let mut parts = vec![];
    let mut cur = String::new();
    loop {
        if *i >= ch.len() {
            if quote.is_some() {
                return err(start, "unterminated string");
            }
            break;
        }
        let c = ch[*i];
        if Some(c) == quote {
            *i += 1;
            break;
        }
        match c {
            '\\' => {
                *i += 1;
                let n = ch.get(*i).copied().unwrap_or('\\');
                cur.push(match n {
                    'n' => '\n',
                    't' => '\t',
                    'r' => '\r',
                    '0' => '\0',
                    other => other,
                });
                *i += 1;
            }
            '{' => {
                *i += 1;
                let (mut depth, mut code, mut q): (i32, String, Option<char>) = (1, String::new(), None);
                let cl = *line;
                loop {
                    let Some(&d) = ch.get(*i) else { return err(cl, "unterminated { in string") };
                    *i += 1;
                    if d == '\n' {
                        *line += 1;
                    }
                    match q {
                        Some(qc) => {
                            if d == qc {
                                q = None;
                            }
                        }
                        None => match d {
                            '"' | '\'' => q = Some(d),
                            '{' => depth += 1,
                            '}' => {
                                depth -= 1;
                                if depth == 0 {
                                    break;
                                }
                            }
                            _ => {}
                        },
                    }
                    code.push(d);
                }
                if !cur.is_empty() {
                    parts.push(Sp::Lit(std::mem::take(&mut cur)));
                }
                parts.push(Sp::Code(code, cl));
            }
            '\n' => {
                *line += 1;
                cur.push('\n');
                *i += 1;
            }
            _ => {
                cur.push(c);
                *i += 1;
            }
        }
    }
    if !cur.is_empty() || parts.is_empty() {
        parts.push(Sp::Lit(cur));
    }
    Ok(parts)
}

fn lex(src: &str, first_line: u32) -> Result<Vec<(T, u32)>, ScriptError> {
    let ch: Vec<char> = src.chars().collect();
    let (mut i, mut line) = (0usize, first_line);
    let mut out: Vec<(T, u32)> = vec![];
    while i < ch.len() {
        let c = ch[i];
        if c == '\n' {
            out.push((T::Nl, line));
            line += 1;
            i += 1;
        } else if c.is_whitespace() {
            i += 1;
        } else if c == '#' || (c == '/' && ch.get(i + 1) == Some(&'/')) {
            while i < ch.len() && ch[i] != '\n' {
                i += 1;
            }
        } else if c == '"' || c == '\'' {
            let l0 = line;
            i += 1;
            let parts = scan_str(&ch, &mut i, Some(c), &mut line)?;
            out.push((T::Str(parts), l0));
        } else if c.is_ascii_digit() {
            let s = i;
            while i < ch.len() && (ch[i].is_ascii_digit() || ch[i] == '_') {
                i += 1;
            }
            if ch.get(i) == Some(&'.') && ch.get(i + 1).map_or(false, |d| d.is_ascii_digit()) {
                i += 1;
                while i < ch.len() && ch[i].is_ascii_digit() {
                    i += 1;
                }
            }
            let text: String = ch[s..i].iter().filter(|c| **c != '_').collect();
            match text.parse() {
                Ok(n) => out.push((T::Num(n), line)),
                Err(_) => return err(line, format!("bad number '{text}'")),
            }
        } else if c.is_alphabetic() || c == '_' {
            let s = i;
            while i < ch.len() && (ch[i].is_alphanumeric() || ch[i] == '_') {
                i += 1;
            }
            out.push((T::Id(ch[s..i].iter().collect()), line));
        } else {
            let rest: String = ch[i..(i + 2).min(ch.len())].iter().collect();
            match PUNCT.iter().find(|p| rest.starts_with(**p)) {
                Some(p) => {
                    out.push((T::P(p), line));
                    i += p.len();
                }
                None => return err(line, format!("unexpected character '{c}'")),
            }
        }
    }
    out.push((T::Eof, line));
    Ok(out)
}

// ───────────────────────────── syntax tree ─────────────────────────────

#[derive(Clone, Copy, PartialEq, Debug)]
enum Op {
    Add,
    Sub,
    Mul,
    Div,
    Mod,
    Eq,
    Ne,
    Lt,
    Le,
    Gt,
    Ge,
}

#[derive(Debug)]
struct FnDef {
    name: String,
    params: Vec<String>,
    body: Vec<Stmt>,
}

#[derive(Debug)]
enum Part {
    Lit(String),
    Code(Expr),
}

#[derive(Debug)]
struct Expr {
    line: u32,
    k: Kind,
}

#[derive(Debug)]
enum Kind {
    Lit(LitV),
    Interp(Vec<Part>),
    Var(String),
    List(Vec<Expr>),
    Map(Vec<(String, Expr)>),
    Neg(Box<Expr>),
    Not(Box<Expr>),
    Bin(Op, Box<Expr>, Box<Expr>),
    And(Box<Expr>, Box<Expr>),
    Or(Box<Expr>, Box<Expr>),
    Coalesce(Box<Expr>, Box<Expr>),
    Range(Box<Expr>, Box<Expr>),
    Index(Box<Expr>, Box<Expr>),
    Member(Box<Expr>, String),
    Call(Box<Expr>, Vec<Expr>),
    Func(Rc<FnDef>),
    If(Box<Expr>, Vec<Stmt>, Option<Vec<Stmt>>),
    Assign(Box<Expr>, Option<Op>, Box<Expr>),
}

#[derive(Debug, Clone)]
enum LitV {
    Null,
    Bool(bool),
    Num(f64),
    Str(String),
}

#[derive(Debug)]
enum Stmt {
    Let(String, Expr),
    Expr(Expr),
    For(String, Option<String>, Expr, Vec<Stmt>, u32),
    While(Expr, Vec<Stmt>),
    Break,
    Continue,
    Return(Option<Expr>),
    FnDef(String, Rc<FnDef>),
}

#[derive(Debug)]
pub struct Program {
    stmts: Vec<Stmt>,
}

// ───────────────────────────── parser ─────────────────────────────

struct Parser {
    toks: Vec<(T, u32)>,
    pos: usize,
}

const KEYWORDS: [&str; 16] = ["let", "if", "else", "for", "in", "while", "break", "continue", "return", "fn", "true", "false", "null", "and", "or", "not"];

impl Parser {
    fn new(src: &str, first_line: u32) -> Result<Parser, ScriptError> {
        Ok(Parser { toks: lex(src, first_line)?, pos: 0 })
    }
    fn peek(&self) -> &T {
        &self.toks[self.pos.min(self.toks.len() - 1)].0
    }
    fn line(&self) -> u32 {
        self.toks[self.pos.min(self.toks.len() - 1)].1
    }
    fn next(&mut self) -> T {
        let t = self.peek().clone();
        if self.pos < self.toks.len() - 1 {
            self.pos += 1;
        }
        t
    }
    fn is_p(&self, p: &str) -> bool {
        matches!(self.peek(), T::P(q) if *q == p)
    }
    fn is_kw(&self, k: &str) -> bool {
        matches!(self.peek(), T::Id(s) if s == k)
    }
    fn eat_p(&mut self, p: &str) -> bool {
        if self.is_p(p) {
            self.next();
            true
        } else {
            false
        }
    }
    fn eat_kw(&mut self, k: &str) -> bool {
        if self.is_kw(k) {
            self.next();
            true
        } else {
            false
        }
    }
    fn expect_p(&mut self, p: &str) -> Result<(), ScriptError> {
        if self.eat_p(p) {
            Ok(())
        } else {
            err(self.line(), format!("expected '{p}' but found {}", self.describe()))
        }
    }
    fn describe(&self) -> String {
        match self.peek() {
            T::Num(n) => format!("number {}", fmt_num(*n)),
            T::Str(_) => "a string".into(),
            T::Id(s) => format!("'{s}'"),
            T::P(p) => format!("'{p}'"),
            T::Nl => "end of line".into(),
            T::Eof => "end of script".into(),
        }
    }
    fn skip_nl(&mut self) {
        while matches!(self.peek(), T::Nl) {
            self.next();
        }
    }
    fn skip_seps(&mut self) {
        while matches!(self.peek(), T::Nl) || self.is_p(";") {
            self.next();
        }
    }
    fn ident(&mut self) -> Result<String, ScriptError> {
        match self.next() {
            T::Id(s) if !KEYWORDS.contains(&s.as_str()) => Ok(s),
            _ => {
                self.pos = self.pos.saturating_sub(1);
                err(self.line(), format!("expected a name but found {}", self.describe()))
            }
        }
    }

    fn program(&mut self) -> Result<Program, ScriptError> {
        let mut stmts = vec![];
        self.skip_seps();
        while !matches!(self.peek(), T::Eof) {
            stmts.push(self.stmt()?);
            self.end_stmt()?;
            self.skip_seps();
        }
        Ok(Program { stmts })
    }

    fn end_stmt(&mut self) -> Result<(), ScriptError> {
        match self.peek() {
            T::Nl | T::Eof => Ok(()),
            T::P(";") | T::P("}") => Ok(()),
            _ => err(self.line(), format!("unexpected {} (statements end with a new line or ';')", self.describe())),
        }
    }

    fn block(&mut self) -> Result<Vec<Stmt>, ScriptError> {
        self.skip_nl();
        self.expect_p("{")?;
        let mut v = vec![];
        self.skip_seps();
        while !self.is_p("}") {
            if matches!(self.peek(), T::Eof) {
                return err(self.line(), "missing '}'");
            }
            v.push(self.stmt()?);
            self.end_stmt()?;
            self.skip_seps();
        }
        self.expect_p("}")?;
        Ok(v)
    }

    fn stmt(&mut self) -> Result<Stmt, ScriptError> {
        let line = self.line();
        if self.eat_kw("let") {
            let name = self.ident()?;
            let e = if self.eat_p("=") {
                self.skip_nl();
                self.expr()?
            } else {
                Expr { line, k: Kind::Lit(LitV::Null) }
            };
            return Ok(Stmt::Let(name, e));
        }
        if self.eat_kw("for") {
            let a = self.ident()?;
            let b = if self.eat_p(",") { Some(self.ident()?) } else { None };
            if !self.eat_kw("in") {
                return err(self.line(), "expected 'in' in for loop");
            }
            let it = self.expr()?;
            let body = self.block()?;
            return Ok(Stmt::For(a, b, it, body, line));
        }
        if self.eat_kw("while") {
            let c = self.expr()?;
            let body = self.block()?;
            return Ok(Stmt::While(c, body));
        }
        if self.eat_kw("break") {
            return Ok(Stmt::Break);
        }
        if self.eat_kw("continue") {
            return Ok(Stmt::Continue);
        }
        if self.eat_kw("return") {
            if matches!(self.peek(), T::Nl | T::Eof) || self.is_p("}") || self.is_p(";") {
                return Ok(Stmt::Return(None));
            }
            return Ok(Stmt::Return(Some(self.expr()?)));
        }
        if self.is_kw("fn") && matches!(self.toks.get(self.pos + 1), Some((T::Id(_), _))) {
            self.next();
            let name = self.ident()?;
            let def = self.fn_rest(name.clone())?;
            return Ok(Stmt::FnDef(name, def));
        }
        Ok(Stmt::Expr(self.expr()?))
    }

    fn fn_rest(&mut self, name: String) -> Result<Rc<FnDef>, ScriptError> {
        self.expect_p("(")?;
        let mut params = vec![];
        self.skip_nl();
        while !self.is_p(")") {
            params.push(self.ident()?);
            self.skip_nl();
            if !self.eat_p(",") {
                break;
            }
            self.skip_nl();
        }
        self.expect_p(")")?;
        let body = self.block()?;
        Ok(Rc::new(FnDef { name, params, body }))
    }

    fn expr(&mut self) -> Result<Expr, ScriptError> {
        let lhs = self.coalesce()?;
        let line = self.line();
        let op = match self.peek() {
            T::P("=") => Some(None),
            T::P("+=") => Some(Some(Op::Add)),
            T::P("-=") => Some(Some(Op::Sub)),
            T::P("*=") => Some(Some(Op::Mul)),
            T::P("/=") => Some(Some(Op::Div)),
            T::P("%=") => Some(Some(Op::Mod)),
            _ => None,
        };
        if let Some(op) = op {
            if !matches!(lhs.k, Kind::Var(_) | Kind::Member(..) | Kind::Index(..)) {
                return err(line, "the left side of '=' must be a variable, a field or an item");
            }
            self.next();
            self.skip_nl();
            let rhs = self.expr()?;
            return Ok(Expr { line, k: Kind::Assign(Box::new(lhs), op, Box::new(rhs)) });
        }
        Ok(lhs)
    }

    fn coalesce(&mut self) -> Result<Expr, ScriptError> {
        let mut l = self.or()?;
        while self.is_p("??") {
            let line = self.line();
            self.next();
            self.skip_nl();
            let r = self.or()?;
            l = Expr { line, k: Kind::Coalesce(Box::new(l), Box::new(r)) };
        }
        Ok(l)
    }

    fn or(&mut self) -> Result<Expr, ScriptError> {
        let mut l = self.and()?;
        while self.is_p("||") || self.is_kw("or") {
            let line = self.line();
            self.next();
            self.skip_nl();
            let r = self.and()?;
            l = Expr { line, k: Kind::Or(Box::new(l), Box::new(r)) };
        }
        Ok(l)
    }

    fn and(&mut self) -> Result<Expr, ScriptError> {
        let mut l = self.equality()?;
        while self.is_p("&&") || self.is_kw("and") {
            let line = self.line();
            self.next();
            self.skip_nl();
            let r = self.equality()?;
            l = Expr { line, k: Kind::And(Box::new(l), Box::new(r)) };
        }
        Ok(l)
    }

    fn bin(&mut self, ops: &[(&str, Op)], next: fn(&mut Parser) -> Result<Expr, ScriptError>) -> Result<Expr, ScriptError> {
        let mut l = next(self)?;
        loop {
            let found = ops.iter().find(|(p, _)| self.is_p(p)).map(|(_, o)| *o);
            let Some(op) = found else { return Ok(l) };
            let line = self.line();
            self.next();
            self.skip_nl();
            let r = next(self)?;
            l = Expr { line, k: Kind::Bin(op, Box::new(l), Box::new(r)) };
        }
    }

    fn equality(&mut self) -> Result<Expr, ScriptError> {
        self.bin(&[("==", Op::Eq), ("!=", Op::Ne)], Parser::comparison)
    }
    fn comparison(&mut self) -> Result<Expr, ScriptError> {
        self.bin(&[("<=", Op::Le), (">=", Op::Ge), ("<", Op::Lt), (">", Op::Gt)], Parser::range)
    }
    fn range(&mut self) -> Result<Expr, ScriptError> {
        let l = self.additive()?;
        if self.is_p("..") {
            let line = self.line();
            self.next();
            let r = self.additive()?;
            return Ok(Expr { line, k: Kind::Range(Box::new(l), Box::new(r)) });
        }
        Ok(l)
    }
    fn additive(&mut self) -> Result<Expr, ScriptError> {
        self.bin(&[("+", Op::Add), ("-", Op::Sub)], Parser::multiplicative)
    }
    fn multiplicative(&mut self) -> Result<Expr, ScriptError> {
        self.bin(&[("*", Op::Mul), ("/", Op::Div), ("%", Op::Mod)], Parser::unary)
    }

    fn unary(&mut self) -> Result<Expr, ScriptError> {
        let line = self.line();
        if self.eat_p("-") {
            return Ok(Expr { line, k: Kind::Neg(Box::new(self.unary()?)) });
        }
        if self.eat_p("!") || self.eat_kw("not") {
            return Ok(Expr { line, k: Kind::Not(Box::new(self.unary()?)) });
        }
        self.postfix()
    }

    fn postfix(&mut self) -> Result<Expr, ScriptError> {
        let mut e = self.primary()?;
        loop {
            let line = self.line();
            if self.eat_p("(") {
                let args = self.args(")")?;
                e = Expr { line, k: Kind::Call(Box::new(e), args) };
            } else if self.eat_p("[") {
                self.skip_nl();
                let i = self.expr()?;
                self.skip_nl();
                self.expect_p("]")?;
                e = Expr { line, k: Kind::Index(Box::new(e), Box::new(i)) };
            } else if self.is_p(".") || self.dot_after_newlines() {
                self.skip_nl();
                self.next();
                self.skip_nl();
                let name = match self.next() {
                    T::Id(s) => s,
                    T::Num(n) => fmt_num(n),
                    _ => return err(line, "expected a field name after '.'"),
                };
                e = Expr { line, k: Kind::Member(Box::new(e), name) };
            } else {
                return Ok(e);
            }
        }
    }

    fn dot_after_newlines(&self) -> bool {
        let mut p = self.pos;
        if !matches!(self.toks.get(p), Some((T::Nl, _))) {
            return false;
        }
        while matches!(self.toks.get(p), Some((T::Nl, _))) {
            p += 1;
        }
        matches!(self.toks.get(p), Some((T::P("."), _)))
    }

    fn args(&mut self, close: &str) -> Result<Vec<Expr>, ScriptError> {
        let mut v = vec![];
        self.skip_nl();
        while !self.is_p(close) {
            v.push(self.expr()?);
            self.skip_nl();
            if !self.eat_p(",") {
                break;
            }
            self.skip_nl();
        }
        self.expect_p(close)?;
        Ok(v)
    }

    fn primary(&mut self) -> Result<Expr, ScriptError> {
        let line = self.line();
        let k = match self.next() {
            T::Num(n) => Kind::Lit(LitV::Num(n)),
            T::Str(parts) => return self.string(parts, line),
            T::P("(") => {
                self.skip_nl();
                let e = self.expr()?;
                self.skip_nl();
                self.expect_p(")")?;
                return Ok(e);
            }
            T::P("[") => Kind::List(self.args("]")?),
            T::P("{") => {
                let mut items = vec![];
                self.skip_nl();
                while !self.is_p("}") {
                    let key = match self.next() {
                        T::Id(s) => s,
                        T::Str(p) if p.len() == 1 && matches!(p[0], Sp::Lit(_)) => match &p[0] {
                            Sp::Lit(s) => s.clone(),
                            _ => String::new(),
                        },
                        T::Num(n) => fmt_num(n),
                        _ => return err(line, "expected a key in the map literal"),
                    };
                    self.skip_nl();
                    self.expect_p(":")?;
                    self.skip_nl();
                    items.push((key, self.expr()?));
                    self.skip_nl();
                    if !self.eat_p(",") {
                        break;
                    }
                    self.skip_nl();
                }
                self.skip_nl();
                self.expect_p("}")?;
                Kind::Map(items)
            }
            T::P("|") | T::P("||") => {
                let was_pipe = matches!(self.toks[self.pos - 1].0, T::P("|"));
                let mut params = vec![];
                if was_pipe {
                    while !self.is_p("|") {
                        params.push(self.ident()?);
                        if !self.eat_p(",") {
                            break;
                        }
                    }
                    self.expect_p("|")?;
                }
                let body = if self.is_p("{") {
                    self.block()?
                } else {
                    self.skip_nl();
                    vec![Stmt::Expr(self.expr()?)]
                };
                Kind::Func(Rc::new(FnDef { name: "lambda".into(), params, body }))
            }
            T::Id(s) => match s.as_str() {
                "true" => Kind::Lit(LitV::Bool(true)),
                "false" => Kind::Lit(LitV::Bool(false)),
                "null" => Kind::Lit(LitV::Null),
                "if" => return self.if_rest(line),
                "fn" => Kind::Func(self.fn_rest("fn".into())?),
                _ if KEYWORDS.contains(&s.as_str()) => return err(line, format!("unexpected keyword '{s}'")),
                _ => Kind::Var(s),
            },
            other => {
                self.pos = self.pos.saturating_sub(1);
                let _ = other;
                return err(line, format!("unexpected {}", self.describe()));
            }
        };
        Ok(Expr { line, k })
    }

    fn if_rest(&mut self, line: u32) -> Result<Expr, ScriptError> {
        let cond = self.expr()?;
        let then = self.block()?;
        // `else` may start on the next line
        let mut p = self.pos;
        while matches!(self.toks.get(p), Some((T::Nl, _))) {
            p += 1;
        }
        let els = if matches!(self.toks.get(p), Some((T::Id(s), _)) if s == "else") {
            self.pos = p + 1;
            if self.is_kw("if") {
                let l = self.line();
                self.next();
                Some(vec![Stmt::Expr(self.if_rest(l)?)])
            } else {
                Some(self.block()?)
            }
        } else {
            None
        };
        Ok(Expr { line, k: Kind::If(Box::new(cond), then, els) })
    }

    fn string(&mut self, parts: Vec<Sp>, line: u32) -> Result<Expr, ScriptError> {
        if parts.iter().all(|p| matches!(p, Sp::Lit(_))) {
            let s: String = parts.into_iter().map(|p| if let Sp::Lit(s) = p { s } else { String::new() }).collect();
            return Ok(Expr { line, k: Kind::Lit(LitV::Str(s)) });
        }
        let mut out = vec![];
        for p in parts {
            match p {
                Sp::Lit(s) => out.push(Part::Lit(s)),
                Sp::Code(code, l) => {
                    let mut sub = Parser::new(&code, l)?;
                    sub.skip_nl();
                    let e = sub.expr()?;
                    sub.skip_nl();
                    if !matches!(sub.peek(), T::Eof) {
                        return err(l, format!("unexpected {} inside {{…}}", sub.describe()));
                    }
                    out.push(Part::Code(e));
                }
            }
        }
        Ok(Expr { line, k: Kind::Interp(out) })
    }
}

/// Checks the syntax of a script without running it.
pub fn parse(src: &str) -> Result<Program, ScriptError> {
    Parser::new(src, 1)?.program()
}

// ───────────────────────────── host interface ─────────────────────────────

/// The world a script can see. The workspace implements this; tests use a mock. Unknown names return `None`.
pub trait Host {
    /// A function provided by the host (`rows`, `set`, `notify` …). `None` = no such function.
    fn call(&mut self, name: &str, args: &[Value]) -> Option<Result<Value, String>>;
    /// Reads `page.key`.
    fn get(&mut self, page: u64, key: &str) -> Result<Value, String>;
    /// Writes `page.key = value`.
    fn set(&mut self, page: u64, key: &str, v: Value) -> Result<(), String>;
    /// Display name of a page handle (used when printing / interpolating).
    fn title(&mut self, page: u64) -> String;
}

// ───────────────────────────── interpreter ─────────────────────────────

pub struct Scope {
    vars: RefCell<HashMap<String, Value>>,
    parent: Option<Env>,
}
pub type Env = Rc<Scope>;

fn new_env(parent: Option<Env>) -> Env {
    Rc::new(Scope { vars: RefCell::new(HashMap::new()), parent })
}

fn lookup(env: &Env, name: &str) -> Option<Value> {
    let mut cur = Some(env);
    while let Some(e) = cur {
        if let Some(v) = e.vars.borrow().get(name) {
            return Some(v.clone());
        }
        cur = e.parent.as_ref();
    }
    None
}

fn assign(env: &Env, name: &str, v: Value) -> bool {
    let mut cur = Some(env);
    while let Some(e) = cur {
        if let Some(slot) = e.vars.borrow_mut().get_mut(name) {
            *slot = v;
            return true;
        }
        cur = e.parent.as_ref();
    }
    false
}

enum Flow {
    Err(ScriptError),
    Break,
    Continue,
    Return(Value),
}

impl From<ScriptError> for Flow {
    fn from(e: ScriptError) -> Flow {
        Flow::Err(e)
    }
}

type R<T> = Result<T, Flow>;

fn ferr<T>(line: u32, msg: impl Into<String>) -> R<T> {
    Err(Flow::Err(ScriptError { line, msg: msg.into() }))
}

pub struct Outcome {
    pub value: Value,
    pub output: Vec<String>,
    pub steps: u64,
}

pub const MAX_STEPS: u64 = 400_000;
const MAX_DEPTH: u32 = 48;
const MAX_LIST: usize = 200_000;

pub struct Interp<'h> {
    host: &'h mut dyn Host,
    steps: u64,
    max_steps: u64,
    depth: u32,
    out: Vec<String>,
}

pub fn to_text(host: &mut dyn Host, v: &Value) -> String {
    match v {
        Value::Null => String::new(),
        Value::Bool(b) => b.to_string(),
        Value::Num(n) => fmt_num(*n),
        Value::Str(s) => s.clone(),
        Value::Page(id) => host.title(*id),
        Value::Func(c) => format!("<fn {}>", c.def.name),
        Value::List(l) => {
            let items = l.borrow().clone();
            format!("[{}]", items.iter().map(|x| quoted(host, x)).collect::<Vec<_>>().join(", "))
        }
        Value::Map(m) => {
            let items: Vec<(String, Value)> = m.borrow().iter().map(|(k, v)| (k.clone(), v.clone())).collect();
            format!("{{{}}}", items.iter().map(|(k, x)| format!("{k}: {}", quoted(host, x))).collect::<Vec<_>>().join(", "))
        }
    }
}

fn quoted(host: &mut dyn Host, v: &Value) -> String {
    match v {
        Value::Str(s) => format!("\"{s}\""),
        other => to_text(host, other),
    }
}

fn to_json(host: &mut dyn Host, v: &Value) -> String {
    match v {
        Value::Null | Value::Func(_) => "null".into(),
        Value::Bool(b) => b.to_string(),
        Value::Num(n) => fmt_num(*n),
        Value::Str(s) => json_str(s),
        Value::Page(id) => json_str(&host.title(*id)),
        Value::List(l) => {
            let items = l.borrow().clone();
            format!("[{}]", items.iter().map(|x| to_json(host, x)).collect::<Vec<_>>().join(","))
        }
        Value::Map(m) => {
            let items: Vec<(String, Value)> = m.borrow().iter().map(|(k, v)| (k.clone(), v.clone())).collect();
            format!("{{{}}}", items.iter().map(|(k, x)| format!("{}:{}", json_str(k), to_json(host, x))).collect::<Vec<_>>().join(","))
        }
    }
}

fn json_str(s: &str) -> String {
    let mut o = String::from("\"");
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            '\t' => o.push_str("\\t"),
            c if (c as u32) < 0x20 => o.push_str(&format!("\\u{:04x}", c as u32)),
            c => o.push(c),
        }
    }
    o.push('"');
    o
}

impl<'h> Interp<'h> {
    fn tick(&mut self, line: u32) -> R<()> {
        self.steps += 1;
        if self.steps > self.max_steps {
            return ferr(line, format!("script stopped: more than {} steps (infinite loop?)", self.max_steps));
        }
        Ok(())
    }

    fn block(&mut self, stmts: &[Stmt], env: &Env) -> R<Value> {
        let mut last = Value::Null;
        for s in stmts {
            last = self.stmt(s, env)?;
        }
        Ok(last)
    }

    fn stmt(&mut self, s: &Stmt, env: &Env) -> R<Value> {
        match s {
            Stmt::Let(name, e) => {
                let v = self.eval(e, env)?;
                env.vars.borrow_mut().insert(name.clone(), v);
                Ok(Value::Null)
            }
            Stmt::Expr(e) => self.eval(e, env),
            Stmt::FnDef(name, def) => {
                let f = Value::Func(Rc::new(Closure { def: def.clone(), env: env.clone() }));
                env.vars.borrow_mut().insert(name.clone(), f);
                Ok(Value::Null)
            }
            Stmt::Break => Err(Flow::Break),
            Stmt::Continue => Err(Flow::Continue),
            Stmt::Return(e) => {
                let v = match e {
                    Some(e) => self.eval(e, env)?,
                    None => Value::Null,
                };
                Err(Flow::Return(v))
            }
            Stmt::While(c, body) => {
                loop {
                    self.tick(c.line)?;
                    if !self.eval(c, env)?.truthy() {
                        break;
                    }
                    let inner = new_env(Some(env.clone()));
                    match self.block(body, &inner) {
                        Ok(_) | Err(Flow::Continue) => {}
                        Err(Flow::Break) => break,
                        Err(other) => return Err(other),
                    }
                }
                Ok(Value::Null)
            }
            Stmt::For(a, b, it, body, line) => {
                let coll = self.eval(it, env)?;
                let items: Vec<(Value, Value)> = match &coll {
                    Value::List(l) => l.borrow().iter().cloned().enumerate().map(|(i, v)| (Value::Num(i as f64), v)).collect(),
                    Value::Map(m) => m.borrow().iter().map(|(k, v)| (Value::Str(k.clone()), v.clone())).collect(),
                    Value::Str(s) => s.chars().enumerate().map(|(i, c)| (Value::Num(i as f64), Value::Str(c.to_string()))).collect(),
                    Value::Null => vec![],
                    other => return ferr(*line, format!("cannot loop over a {}", other.type_name())),
                };
                for (k, v) in items {
                    self.tick(*line)?;
                    let inner = new_env(Some(env.clone()));
                    {
                        let mut vars = inner.vars.borrow_mut();
                        if let Some(second) = b {
                            vars.insert(a.clone(), k);
                            vars.insert(second.clone(), v);
                        } else if matches!(coll, Value::Map(_)) {
                            vars.insert(a.clone(), k);
                        } else {
                            vars.insert(a.clone(), v);
                        }
                    }
                    match self.block(body, &inner) {
                        Ok(_) | Err(Flow::Continue) => {}
                        Err(Flow::Break) => break,
                        Err(other) => return Err(other),
                    }
                }
                Ok(Value::Null)
            }
        }
    }

    fn eval(&mut self, e: &Expr, env: &Env) -> R<Value> {
        self.tick(e.line)?;
        let line = e.line;
        Ok(match &e.k {
            Kind::Lit(l) => match l {
                LitV::Null => Value::Null,
                LitV::Bool(b) => Value::Bool(*b),
                LitV::Num(n) => Value::Num(*n),
                LitV::Str(s) => Value::Str(s.clone()),
            },
            Kind::Interp(parts) => {
                // a template that is exactly one `{expr}` keeps the type of the expression
                let mut s = String::new();
                for p in parts {
                    match p {
                        Part::Lit(t) => s.push_str(t),
                        Part::Code(c) => {
                            let v = self.eval(c, env)?;
                            s.push_str(&to_text(self.host, &v));
                        }
                    }
                }
                Value::Str(s)
            }
            Kind::Var(name) => match lookup(env, name) {
                Some(v) => v,
                None => {
                    if is_builtin(name) {
                        Value::Str(format!("<builtin {name}>"))
                    } else {
                        return ferr(line, format!("unknown variable '{name}' (declare it with let)"));
                    }
                }
            },
            Kind::List(items) => {
                let mut v = Vec::with_capacity(items.len());
                for i in items {
                    v.push(self.eval(i, env)?);
                }
                Value::list(v)
            }
            Kind::Map(items) => {
                let mut m = BTreeMap::new();
                for (k, v) in items {
                    m.insert(k.clone(), self.eval(v, env)?);
                }
                Value::map(m)
            }
            Kind::Neg(x) => match self.eval(x, env)? {
                Value::Num(n) => Value::Num(-n),
                other => return ferr(line, format!("cannot negate a {}", other.type_name())),
            },
            Kind::Not(x) => Value::Bool(!self.eval(x, env)?.truthy()),
            Kind::And(a, b) => {
                let l = self.eval(a, env)?;
                if !l.truthy() {
                    l
                } else {
                    self.eval(b, env)?
                }
            }
            Kind::Or(a, b) => {
                let l = self.eval(a, env)?;
                if l.truthy() {
                    l
                } else {
                    self.eval(b, env)?
                }
            }
            Kind::Coalesce(a, b) => {
                let l = self.eval(a, env)?;
                if matches!(l, Value::Null) {
                    self.eval(b, env)?
                } else {
                    l
                }
            }
            Kind::Range(a, b) => {
                let (x, y) = (self.eval(a, env)?, self.eval(b, env)?);
                let (Some(x), Some(y)) = (x.as_num(), y.as_num()) else { return ferr(line, "a range needs numbers (1..5)") };
                if (y - x).abs() > MAX_LIST as f64 {
                    return ferr(line, "range too large");
                }
                let mut v = vec![];
                let mut i = x as i64;
                while i < y as i64 {
                    v.push(Value::Num(i as f64));
                    i += 1;
                }
                Value::list(v)
            }
            Kind::Bin(op, a, b) => {
                let (l, r) = (self.eval(a, env)?, self.eval(b, env)?);
                self.binary(*op, l, r, line)?
            }
            Kind::Index(o, i) => {
                let (o, i) = (self.eval(o, env)?, self.eval(i, env)?);
                self.index(&o, &i, line)?
            }
            Kind::Member(o, name) => {
                let o = self.eval(o, env)?;
                self.member(&o, name, line)?
            }
            Kind::Func(def) => Value::Func(Rc::new(Closure { def: def.clone(), env: env.clone() })),
            Kind::If(c, then, els) => {
                let inner = new_env(Some(env.clone()));
                if self.eval(c, env)?.truthy() {
                    self.block(then, &inner)?
                } else if let Some(els) = els {
                    self.block(els, &inner)?
                } else {
                    Value::Null
                }
            }
            Kind::Assign(target, op, rhs) => {
                let mut v = self.eval(rhs, env)?;
                if let Some(op) = op {
                    let cur = self.eval(target, env)?;
                    v = self.binary(*op, cur, v, line)?;
                }
                self.store(target, v.clone(), env, line)?;
                v
            }
            Kind::Call(callee, args) => {
                let mut argv = Vec::with_capacity(args.len());
                for a in args {
                    argv.push(self.eval(a, env)?);
                }
                match &callee.k {
                    Kind::Var(name) => self.call_named(name, argv, env, line)?,
                    Kind::Member(obj, name) => {
                        let o = self.eval(obj, env)?;
                        if let Value::Map(m) = &o {
                            let f = m.borrow().get(name).cloned();
                            if let Some(f @ Value::Func(_)) = f {
                                return self.call_value(&f, argv, line);
                            }
                        }
                        // method-call sugar: `list.map(f)` is `map(list, f)`
                        argv.insert(0, o);
                        self.call_named(name, argv, env, line)?
                    }
                    _ => {
                        let f = self.eval(callee, env)?;
                        self.call_value(&f, argv, line)?
                    }
                }
            }
        })
    }

    fn binary(&mut self, op: Op, l: Value, r: Value, line: u32) -> R<Value> {
        Ok(match op {
            Op::Eq => Value::Bool(eq_vals(&l, &r)),
            Op::Ne => Value::Bool(!eq_vals(&l, &r)),
            Op::Lt | Op::Le | Op::Gt | Op::Ge => {
                let o = match cmp_vals(&l, &r) {
                    Ok(o) => o,
                    Err(m) => return ferr(line, m),
                };
                Value::Bool(match op {
                    Op::Lt => o == Ordering::Less,
                    Op::Le => o != Ordering::Greater,
                    Op::Gt => o == Ordering::Greater,
                    _ => o != Ordering::Less,
                })
            }
            Op::Add => match (&l, &r) {
                (Value::Num(a), Value::Num(b)) => Value::Num(a + b),
                (Value::List(a), Value::List(b)) => {
                    let mut v = a.borrow().clone();
                    v.extend(b.borrow().iter().cloned());
                    Value::list(v)
                }
                (Value::Str(_), _) | (_, Value::Str(_)) => {
                    let (a, b) = (to_text(self.host, &l), to_text(self.host, &r));
                    Value::Str(a + &b)
                }
                (Value::Null, other) | (other, Value::Null) if matches!(other, Value::Num(_)) => other.clone(),
                _ => return ferr(line, format!("cannot add {} and {}", l.type_name(), r.type_name())),
            },
            Op::Sub | Op::Mul | Op::Div | Op::Mod => {
                let (Value::Num(a), Value::Num(b)) = (&l, &r) else {
                    return ferr(line, format!("arithmetic needs numbers, got {} and {}", l.type_name(), r.type_name()));
                };
                match op {
                    Op::Sub => Value::Num(a - b),
                    Op::Mul => Value::Num(a * b),
                    Op::Div => {
                        if *b == 0.0 {
                            return ferr(line, "division by zero");
                        }
                        Value::Num(a / b)
                    }
                    _ => {
                        if *b == 0.0 {
                            return ferr(line, "modulo by zero");
                        }
                        Value::Num(a.rem_euclid(*b))
                    }
                }
            }
        })
    }

    fn index(&mut self, o: &Value, i: &Value, line: u32) -> R<Value> {
        Ok(match (o, i) {
            (Value::List(l), Value::Num(n)) => {
                let l = l.borrow();
                let idx = if *n < 0.0 { l.len() as i64 + *n as i64 } else { *n as i64 };
                if idx < 0 { Value::Null } else { l.get(idx as usize).cloned().unwrap_or(Value::Null) }
            }
            (Value::Str(s), Value::Num(n)) => {
                let len = s.chars().count() as i64;
                let idx = if *n < 0.0 { len + *n as i64 } else { *n as i64 };
                if idx < 0 { Value::Null } else { s.chars().nth(idx as usize).map(|c| Value::Str(c.to_string())).unwrap_or(Value::Null) }
            }
            (Value::Map(m), Value::Str(k)) => m.borrow().get(k).cloned().unwrap_or(Value::Null),
            (Value::Page(p), Value::Str(k)) => self.host.get(*p, k).map_err(|m| Flow::Err(ScriptError { line, msg: m }))?,
            (Value::Null, _) => return ferr(line, "cannot index null (the value is missing)"),
            _ => return ferr(line, format!("cannot index a {} with a {}", o.type_name(), i.type_name())),
        })
    }

    fn member(&mut self, o: &Value, name: &str, line: u32) -> R<Value> {
        Ok(match o {
            Value::Map(m) => m.borrow().get(name).cloned().unwrap_or(Value::Null),
            Value::Page(p) => self.host.get(*p, name).map_err(|m| Flow::Err(ScriptError { line, msg: m }))?,
            Value::List(l) => match name {
                "len" | "length" => Value::Num(l.borrow().len() as f64),
                "first" => l.borrow().first().cloned().unwrap_or(Value::Null),
                "last" => l.borrow().last().cloned().unwrap_or(Value::Null),
                _ => return ferr(line, format!("a list has no field '{name}' (try len, first, last)")),
            },
            Value::Str(s) => match name {
                "len" | "length" => Value::Num(s.chars().count() as f64),
                _ => return ferr(line, format!("a string has no field '{name}' (try len)")),
            },
            Value::Null => return ferr(line, format!("cannot read '{name}' of null (the value is missing)")),
            other => return ferr(line, format!("a {} has no field '{name}'", other.type_name())),
        })
    }

    fn store(&mut self, target: &Expr, v: Value, env: &Env, line: u32) -> R<()> {
        match &target.k {
            Kind::Var(name) => {
                if !assign(env, name, v) {
                    return ferr(line, format!("unknown variable '{name}' (declare it with let first)"));
                }
            }
            Kind::Member(o, name) => {
                let o = self.eval(o, env)?;
                self.set_field(&o, name, v, line)?;
            }
            Kind::Index(o, i) => {
                let (o, i) = (self.eval(o, env)?, self.eval(i, env)?);
                match (&o, &i) {
                    (Value::List(l), Value::Num(n)) => {
                        let mut l = l.borrow_mut();
                        let idx = if *n < 0.0 { l.len() as i64 + *n as i64 } else { *n as i64 };
                        if idx < 0 || idx as usize >= l.len() {
                            return ferr(line, "list index out of range (use push to add items)");
                        }
                        l[idx as usize] = v;
                    }
                    (_, Value::Str(k)) => self.set_field(&o, k, v, line)?,
                    _ => return ferr(line, "cannot assign to this item"),
                }
            }
            _ => return ferr(line, "cannot assign here"),
        }
        Ok(())
    }

    fn set_field(&mut self, o: &Value, key: &str, v: Value, line: u32) -> R<()> {
        match o {
            Value::Map(m) => {
                m.borrow_mut().insert(key.to_owned(), v);
                Ok(())
            }
            Value::Page(p) => self.host.set(*p, key, v).map_err(|m| Flow::Err(ScriptError { line, msg: m })),
            other => ferr(line, format!("cannot set a field on a {}", other.type_name())),
        }
    }

    fn call_named(&mut self, name: &str, args: Vec<Value>, env: &Env, line: u32) -> R<Value> {
        if let Some(f @ Value::Func(_)) = lookup(env, name) {
            return self.call_value(&f, args, line);
        }
        if let Some(r) = self.builtin(name, &args, line) {
            return r;
        }
        match self.host.call(name, &args) {
            Some(Ok(v)) => Ok(v),
            Some(Err(m)) => ferr(line, m),
            None => ferr(line, format!("unknown function '{name}'")),
        }
    }

    fn call_value(&mut self, f: &Value, args: Vec<Value>, line: u32) -> R<Value> {
        let Value::Func(c) = f else { return ferr(line, format!("a {} is not callable", f.type_name())) };
        if self.depth >= MAX_DEPTH {
            return ferr(line, "calls nested too deeply (runaway recursion?)");
        }
        self.depth += 1;
        let env = new_env(Some(c.env.clone()));
        {
            let mut vars = env.vars.borrow_mut();
            for (i, p) in c.def.params.iter().enumerate() {
                vars.insert(p.clone(), args.get(i).cloned().unwrap_or(Value::Null));
            }
        }
        let r = self.block(&c.def.body, &env);
        self.depth -= 1;
        match r {
            Ok(v) => Ok(v),
            Err(Flow::Return(v)) => Ok(v),
            Err(Flow::Break) | Err(Flow::Continue) => ferr(line, "break / continue outside of a loop"),
            Err(e) => Err(e),
        }
    }

    // ───────────── standard library ─────────────

    fn builtin(&mut self, name: &str, a: &[Value], line: u32) -> Option<R<Value>> {
        if !is_builtin(name) {
            return None;
        }
        Some(self.builtin_impl(name, a, line))
    }

    fn builtin_impl(&mut self, name: &str, a: &[Value], line: u32) -> R<Value> {
        let arg = |i: usize| a.get(i).cloned().unwrap_or(Value::Null);
        let need = |n: usize| -> R<()> {
            if a.len() < n {
                ferr(line, format!("{name}() needs {n} argument{}", if n == 1 { "" } else { "s" }))
            } else {
                Ok(())
            }
        };
        let num = |i: usize| -> R<f64> {
            match a.get(i).and_then(|v| v.as_num()) {
                Some(n) => Ok(n),
                None => ferr(line, format!("{name}(): argument {} must be a number", i + 1)),
            }
        };
        match name {
            "len" => {
                need(1)?;
                Ok(Value::Num(match &a[0] {
                    Value::Str(s) => s.chars().count(),
                    Value::List(l) => l.borrow().len(),
                    Value::Map(m) => m.borrow().len(),
                    Value::Null => 0,
                    other => return ferr(line, format!("len() of a {}", other.type_name())),
                } as f64))
            }
            "str" | "text" => Ok(Value::Str(to_text(self.host, &arg(0)))),
            "num" | "number" => Ok(match arg(0) {
                Value::Num(n) => Value::Num(n),
                other => other.as_num().map(Value::Num).unwrap_or(Value::Null),
            }),
            "int" => Ok(arg(0).as_num().map(|n| Value::Num(n.trunc())).unwrap_or(Value::Null)),
            "bool" => Ok(Value::Bool(arg(0).truthy())),
            "type" => Ok(Value::str(arg(0).type_name())),
            "is_null" => Ok(Value::Bool(matches!(arg(0), Value::Null))),
            "abs" => Ok(Value::Num(num(0)?.abs())),
            "floor" => Ok(Value::Num(num(0)?.floor())),
            "ceil" => Ok(Value::Num(num(0)?.ceil())),
            "sqrt" => Ok(Value::Num(num(0)?.max(0.0).sqrt())),
            "round" => {
                let n = num(0)?;
                let d = a.get(1).and_then(|v| v.as_num()).unwrap_or(0.0).clamp(0.0, 10.0);
                let k = 10f64.powi(d as i32);
                Ok(Value::Num((n * k).round() / k))
            }
            "min" | "max" => {
                let items: Vec<Value> = if a.len() == 1 { a[0].items() } else { a.to_vec() };
                let mut best: Option<Value> = None;
                for v in items {
                    best = Some(match best {
                        None => v,
                        Some(b) => {
                            let o = cmp_vals(&v, &b).map_err(|m| Flow::Err(ScriptError { line, msg: m }))?;
                            if (name == "min" && o == Ordering::Less) || (name == "max" && o == Ordering::Greater) {
                                v
                            } else {
                                b
                            }
                        }
                    });
                }
                Ok(best.unwrap_or(Value::Null))
            }
            "sum" | "avg" => {
                let items = arg(0).items();
                let nums: Vec<f64> = items.iter().filter_map(|v| v.as_num()).collect();
                let s: f64 = nums.iter().sum();
                Ok(Value::Num(if name == "sum" { s } else if nums.is_empty() { 0.0 } else { s / nums.len() as f64 }))
            }
            "range" => {
                let (lo, hi, step) = match a.len() {
                    1 => (0.0, num(0)?, 1.0),
                    2 => (num(0)?, num(1)?, 1.0),
                    _ => (num(0)?, num(1)?, num(2)?),
                };
                if step == 0.0 || ((hi - lo) / step).abs() > MAX_LIST as f64 {
                    return ferr(line, "range(): bad step or too many items");
                }
                let mut v = vec![];
                let mut x = lo;
                while (step > 0.0 && x < hi) || (step < 0.0 && x > hi) {
                    v.push(Value::Num(x));
                    x += step;
                }
                Ok(Value::list(v))
            }
            "keys" | "values" => match arg(0) {
                Value::Map(m) => {
                    let m = m.borrow();
                    Ok(Value::list(if name == "keys" { m.keys().map(|k| Value::Str(k.clone())).collect() } else { m.values().cloned().collect() }))
                }
                other => ferr(line, format!("{name}() needs a map, got a {}", other.type_name())),
            },
            "has" => {
                need(2)?;
                Ok(Value::Bool(match (&a[0], &a[1]) {
                    (Value::Map(m), Value::Str(k)) => m.borrow().contains_key(k),
                    (Value::List(l), x) => l.borrow().iter().any(|v| eq_vals(v, x)),
                    (Value::Str(s), Value::Str(t)) => s.contains(t.as_str()),
                    _ => false,
                }))
            }
            "contains" => {
                need(2)?;
                Ok(Value::Bool(match (&a[0], &a[1]) {
                    (Value::Str(s), Value::Str(t)) => s.to_lowercase().contains(&t.to_lowercase()),
                    (Value::List(l), x) => l.borrow().iter().any(|v| eq_vals(v, x)),
                    (Value::Map(m), Value::Str(k)) => m.borrow().contains_key(k),
                    _ => false,
                }))
            }
            "push" => {
                need(2)?;
                if let Value::List(l) = &a[0] {
                    if l.borrow().len() >= MAX_LIST {
                        return ferr(line, "list too large");
                    }
                    l.borrow_mut().extend(a[1..].iter().cloned());
                    Ok(a[0].clone())
                } else {
                    ferr(line, "push() needs a list")
                }
            }
            "pop" => match arg(0) {
                Value::List(l) => Ok(l.borrow_mut().pop().unwrap_or(Value::Null)),
                _ => ferr(line, "pop() needs a list"),
            },
            "reverse" => match arg(0) {
                Value::List(l) => Ok(Value::list(l.borrow().iter().rev().cloned().collect())),
                Value::Str(s) => Ok(Value::Str(s.chars().rev().collect())),
                _ => ferr(line, "reverse() needs a list or string"),
            },
            "concat" => {
                let mut v = vec![];
                for x in a {
                    v.extend(x.items());
                }
                Ok(Value::list(v))
            }
            "unique" => {
                let mut out: Vec<Value> = vec![];
                for v in arg(0).items() {
                    if !out.iter().any(|o| eq_vals(o, &v)) {
                        out.push(v);
                    }
                }
                Ok(Value::list(out))
            }
            "slice" => {
                need(2)?;
                let from = num(1)?;
                match &a[0] {
                    Value::List(l) => {
                        let l = l.borrow();
                        let n = l.len() as i64;
                        let s = if from < 0.0 { (n + from as i64).max(0) } else { (from as i64).min(n) };
                        let e = match a.get(2).and_then(|v| v.as_num()) {
                            Some(t) if t < 0.0 => (n + t as i64).max(s),
                            Some(t) => (t as i64).clamp(s, n),
                            None => n,
                        };
                        Ok(Value::list(l[s as usize..e as usize].to_vec()))
                    }
                    Value::Str(st) => {
                        let chars: Vec<char> = st.chars().collect();
                        let n = chars.len() as i64;
                        let s = if from < 0.0 { (n + from as i64).max(0) } else { (from as i64).min(n) };
                        let e = match a.get(2).and_then(|v| v.as_num()) {
                            Some(t) if t < 0.0 => (n + t as i64).max(s),
                            Some(t) => (t as i64).clamp(s, n),
                            None => n,
                        };
                        Ok(Value::Str(chars[s as usize..e as usize].iter().collect()))
                    }
                    _ => ferr(line, "slice() needs a list or string"),
                }
            }
            "join" => {
                let sep = match a.get(1) {
                    Some(Value::Str(s)) => s.clone(),
                    _ => ", ".to_owned(),
                };
                let items = arg(0).items();
                let parts: Vec<String> = items.iter().map(|v| to_text(self.host, v)).collect();
                Ok(Value::Str(parts.join(&sep)))
            }
            "split" => {
                need(1)?;
                let s = to_text(self.host, &a[0]);
                let sep = match a.get(1) {
                    Some(Value::Str(t)) if !t.is_empty() => t.clone(),
                    _ => ",".to_owned(),
                };
                Ok(Value::list(s.split(sep.as_str()).map(|p| Value::Str(p.trim().to_owned())).collect()))
            }
            "trim" => Ok(Value::Str(to_text(self.host, &arg(0)).trim().to_owned())),
            "upper" => Ok(Value::Str(to_text(self.host, &arg(0)).to_uppercase())),
            "lower" => Ok(Value::Str(to_text(self.host, &arg(0)).to_lowercase())),
            "replace" => {
                need(3)?;
                let (s, f, t) = (to_text(self.host, &a[0]), to_text(self.host, &a[1]), to_text(self.host, &a[2]));
                Ok(Value::Str(if f.is_empty() { s } else { s.replace(&f, &t) }))
            }
            "starts_with" | "ends_with" => {
                need(2)?;
                let (s, t) = (to_text(self.host, &a[0]).to_lowercase(), to_text(self.host, &a[1]).to_lowercase());
                Ok(Value::Bool(if name == "starts_with" { s.starts_with(&t) } else { s.ends_with(&t) }))
            }
            "json" => Ok(Value::Str(to_json(self.host, &arg(0)))),
            "print" | "log" => {
                let parts: Vec<String> = a.iter().map(|v| to_text(self.host, v)).collect();
                if self.out.len() < 500 {
                    self.out.push(parts.join(" "));
                }
                Ok(Value::Null)
            }
            "error" | "fail" => ferr(line, to_text(self.host, &arg(0))),
            "assert" => {
                if arg(0).truthy() {
                    Ok(Value::Null)
                } else {
                    let m = if a.len() > 1 { to_text(self.host, &a[1]) } else { "assertion failed".into() };
                    ferr(line, m)
                }
            }
            // ── higher-order ──
            "map" | "filter" | "find" | "any" | "all" | "count" | "sort" | "group" | "reduce" | "each" => self.higher(name, a, line),
            // ── dates & time ──
            "today" => Ok(Value::Str(dates::today_iso())),
            "now" => Ok(Value::Num(crate::auth::now_ms())),
            "time" => {
                let m = dates::local_minutes();
                Ok(Value::Str(format!("{:02}:{:02}", m / 60, m % 60)))
            }
            "date" => {
                let s = to_text(self.host, &arg(0));
                Ok(match recur::resolve_date(&s, dates::today_day()) {
                    Some(d) => Value::Str(dates::iso_of_day(d)),
                    None => Value::Null,
                })
            }
            "is_date" => Ok(Value::Bool(dates::span(&to_text(self.host, &arg(0))).is_some())),
            "add_days" | "add_weeks" | "add_months" | "add_years" => {
                need(2)?;
                let n = num(1)? as i64;
                let s = to_text(self.host, &a[0]);
                let Some((x, y)) = dates::span(&s) else { return ferr(line, format!("{name}(): '{s}' is not a date (use YYYY-MM-DD)")) };
                let f = |d: i64| match name {
                    "add_days" => d + n,
                    "add_weeks" => d + 7 * n,
                    "add_months" => recur::add_months(d, n),
                    _ => recur::add_months(d, 12 * n),
                };
                Ok(Value::Str(dates::span_value(f(x), f(y))))
            }
            "days_between" => {
                need(2)?;
                let (s, t) = (to_text(self.host, &a[0]), to_text(self.host, &a[1]));
                match (dates::span(&s), dates::span(&t)) {
                    (Some(x), Some(y)) => Ok(Value::Num((y.0 - x.0) as f64)),
                    _ => ferr(line, "days_between() needs two dates"),
                }
            }
            "weekday" => {
                let s = a.first().map(|v| to_text(self.host, v)).unwrap_or_else(dates::today_iso);
                match dates::span(&s) {
                    Some(d) => Ok(Value::Num(recur::weekday_of(d.0) as f64)),
                    None => ferr(line, "weekday() needs a date"),
                }
            }
            "weekday_name" => {
                let s = a.first().map(|v| to_text(self.host, v)).unwrap_or_else(dates::today_iso);
                match dates::span(&s) {
                    Some(d) => Ok(Value::str(recur::weekday_name(d.0))),
                    None => ferr(line, "weekday_name() needs a date"),
                }
            }
            "format_date" => {
                let s = a.first().map(|v| to_text(self.host, v)).unwrap_or_else(dates::today_iso);
                Ok(Value::Str(dates::pretty(&s)))
            }
            "next_date" => {
                need(2)?;
                let (s, r) = (to_text(self.host, &a[0]), to_text(self.host, &a[1]));
                let Some(rule) = Repeat::parse(&r) else { return ferr(line, format!("next_date(): don't understand the repeat rule '{r}' (try \"weekly\", \"every 2 weeks\", \"mon,thu\")")) };
                let Some((x, y)) = dates::span(&s) else { return ferr(line, "next_date() needs a date") };
                let nx = rule.next_after(x);
                Ok(Value::Str(dates::span_value(nx, nx + (y - x))))
            }
            _ => ferr(line, format!("unknown function '{name}'")),
        }
    }

    fn higher(&mut self, name: &str, a: &[Value], line: u32) -> R<Value> {
        let items = a.first().map(|v| v.items()).unwrap_or_default();
        let f = a.get(1).cloned().unwrap_or(Value::Null);
        let need_f = |f: &Value| -> R<()> {
            if matches!(f, Value::Func(_)) {
                Ok(())
            } else {
                ferr(line, format!("{name}() needs a function as its second argument, e.g. |x| x > 1"))
            }
        };
        match name {
            "sort" => {
                let mut keyed: Vec<(Value, Value)> = vec![];
                for v in items {
                    let k = if matches!(f, Value::Func(_)) { self.call_value(&f, vec![v.clone()], line)? } else { v.clone() };
                    keyed.push((k, v));
                }
                let mut failure: Option<String> = None;
                keyed.sort_by(|x, y| match cmp_vals(&x.0, &y.0) {
                    Ok(o) => o,
                    Err(m) => {
                        failure = Some(m);
                        Ordering::Equal
                    }
                });
                if let Some(m) = failure {
                    return ferr(line, format!("sort(): {m}"));
                }
                Ok(Value::list(keyed.into_iter().map(|(_, v)| v).collect()))
            }
            "reduce" => {
                need_f(&f)?;
                let mut acc = a.get(2).cloned().unwrap_or(Value::Null);
                for v in items {
                    acc = self.call_value(&f, vec![acc, v], line)?;
                }
                Ok(acc)
            }
            _ => {
                need_f(&f)?;
                let mut out = vec![];
                let mut n = 0usize;
                let mut groups: BTreeMap<String, Value> = BTreeMap::new();
                for v in items {
                    self.tick(line)?;
                    let r = self.call_value(&f, vec![v.clone()], line)?;
                    match name {
                        "map" => out.push(r),
                        "filter" => {
                            if r.truthy() {
                                out.push(v)
                            }
                        }
                        "find" => {
                            if r.truthy() {
                                return Ok(v);
                            }
                        }
                        "any" => {
                            if r.truthy() {
                                return Ok(Value::Bool(true));
                            }
                        }
                        "all" => {
                            if !r.truthy() {
                                return Ok(Value::Bool(false));
                            }
                        }
                        "count" => {
                            if r.truthy() {
                                n += 1
                            }
                        }
                        "group" => {
                            let key = to_text(self.host, &r);
                            let slot = groups.entry(key).or_insert_with(|| Value::list(vec![]));
                            if let Value::List(l) = slot {
                                l.borrow_mut().push(v);
                            }
                        }
                        _ => {}
                    }
                }
                Ok(match name {
                    "map" | "filter" => Value::list(out),
                    "find" => Value::Null,
                    "any" => Value::Bool(false),
                    "all" => Value::Bool(true),
                    "count" => Value::Num(n as f64),
                    "group" => Value::map(groups),
                    _ => Value::Null,
                })
            }
        }
    }
}

// ───────────────────────────── public API ─────────────────────────────

fn start<'h>(host: &'h mut dyn Host, max_steps: u64) -> Interp<'h> {
    Interp { host, steps: 0, max_steps, depth: 0, out: vec![] }
}

fn global(vars: &[(&str, Value)]) -> Env {
    let env = new_env(None);
    for (k, v) in vars {
        env.vars.borrow_mut().insert((*k).to_owned(), v.clone());
    }
    env
}

fn finish(it: Interp, r: R<Value>) -> Result<Outcome, ScriptError> {
    match r {
        Ok(value) | Err(Flow::Return(value)) => Ok(Outcome { value, output: it.out, steps: it.steps }),
        Err(Flow::Err(e)) => Err(e),
        Err(Flow::Break) | Err(Flow::Continue) => Err(ScriptError { line: 0, msg: "break / continue outside of a loop".into() }),
    }
}

/// Runs a parsed program. `vars` are the pre-defined variables (`row`, `trigger` …).
pub fn run_program(p: &Program, host: &mut dyn Host, vars: &[(&str, Value)], max_steps: u64) -> Result<Outcome, ScriptError> {
    let env = global(vars);
    let mut it = start(host, max_steps);
    let r = it.block(&p.stmts, &env);
    finish(it, r)
}

pub fn run(src: &str, host: &mut dyn Host, vars: &[(&str, Value)]) -> Result<Outcome, ScriptError> {
    let p = parse(src)?;
    run_program(&p, host, vars, MAX_STEPS)
}

/// Evaluates a template such as `"Review {row.title} by {add_days(today(), 3)}"`. A template that is a single `{expr}`
/// keeps the type of the expression (a number stays a number, a list stays a list).
pub fn eval_template(src: &str, host: &mut dyn Host, vars: &[(&str, Value)]) -> Result<Value, ScriptError> {
    let mut i = 0usize;
    let ch: Vec<char> = src.chars().collect();
    let mut line = 1u32;
    let parts = scan_str(&ch, &mut i, None, &mut line)?;
    let single = parts.len() == 1 && matches!(parts[0], Sp::Code(..));
    let mut p = Parser { toks: vec![(T::Eof, 1)], pos: 0 };
    let e = p.string(parts, 1)?;
    let env = global(vars);
    let mut it = start(host, 50_000);
    let r = if single {
        match &e.k {
            Kind::Interp(parts) => match &parts[0] {
                Part::Code(c) => it.eval(c, &env),
                _ => it.eval(&e, &env),
            },
            _ => it.eval(&e, &env),
        }
    } else {
        it.eval(&e, &env)
    };
    finish(it, r).map(|o| o.value)
}

/// Evaluates one expression (used for conditions: `row.Priority == "High" and row.Due < today()`).
pub fn eval_expr(src: &str, host: &mut dyn Host, vars: &[(&str, Value)]) -> Result<Value, ScriptError> {
    run(src, host, vars).map(|o| o.value)
}

/// Names of the pure (host-independent) functions, with a one-line description — used by the in-app reference and by tools
/// that write scripts. Keep in sync with `builtin_impl` (a unit test checks that every name here is callable).
pub const BUILTINS: &[(&str, &str, &str)] = &[
    ("len", "len(x)", "Length of a string, list or map."),
    ("str", "str(x)", "Convert anything to text."),
    ("num", "num(x)", "Convert text to a number (null when impossible)."),
    ("int", "int(x)", "Drop the decimals."),
    ("bool", "bool(x)", "Truthiness of a value."),
    ("type", "type(x)", "\"number\", \"string\", \"list\", \"map\", \"page\" …"),
    ("is_null", "is_null(x)", "True for null."),
    ("abs", "abs(n)", "Absolute value."),
    ("round", "round(n, digits?)", "Round to a number of decimals."),
    ("floor", "floor(n)", "Round down."),
    ("ceil", "ceil(n)", "Round up."),
    ("sqrt", "sqrt(n)", "Square root."),
    ("min", "min(a, b, …) / min(list)", "Smallest value."),
    ("max", "max(a, b, …) / max(list)", "Largest value."),
    ("sum", "sum(list)", "Sum of the numbers in a list."),
    ("avg", "avg(list)", "Average of the numbers in a list."),
    ("range", "range(n) / range(a, b, step?)", "List of numbers (also the `a..b` operator)."),
    ("keys", "keys(map)", "The keys of a map."),
    ("values", "values(map)", "The values of a map."),
    ("has", "has(map|list|text, x)", "Exact membership test."),
    ("contains", "contains(text|list, x)", "Membership test (text ignores case)."),
    ("push", "push(list, x…)", "Append items; returns the list."),
    ("pop", "pop(list)", "Remove and return the last item."),
    ("reverse", "reverse(list|text)", "Reversed copy."),
    ("concat", "concat(a, b, …)", "Join lists."),
    ("unique", "unique(list)", "Remove duplicates."),
    ("slice", "slice(list|text, from, to?)", "Part of a list or text (negative counts from the end)."),
    ("join", "join(list, sep?)", "Join items into text."),
    ("split", "split(text, sep?)", "Split text into a list (default separator: comma)."),
    ("trim", "trim(text)", "Remove surrounding spaces."),
    ("upper", "upper(text)", "UPPER CASE."),
    ("lower", "lower(text)", "lower case."),
    ("replace", "replace(text, from, to)", "Replace all occurrences."),
    ("starts_with", "starts_with(text, prefix)", "Prefix test (ignores case)."),
    ("ends_with", "ends_with(text, suffix)", "Suffix test (ignores case)."),
    ("json", "json(x)", "Serialise a value as JSON text."),
    ("print", "print(x…)", "Write a line to the run log."),
    ("error", "error(message)", "Stop the script with an error."),
    ("assert", "assert(cond, message?)", "Stop with an error unless cond is true."),
    ("map", "list.map(|x| …)", "Transform every item."),
    ("filter", "list.filter(|x| …)", "Keep items for which the function is true."),
    ("find", "list.find(|x| …)", "First matching item (or null)."),
    ("any", "list.any(|x| …)", "True if any item matches."),
    ("all", "list.all(|x| …)", "True if every item matches."),
    ("count", "list.count(|x| …)", "How many items match."),
    ("sort", "list.sort(|x| key?)", "Sorted copy, optionally by a key."),
    ("group", "list.group(|x| key)", "Map of key → list of items."),
    ("reduce", "list.reduce(|acc, x| …, start)", "Fold a list into one value."),
    ("today", "today()", "Today's date as YYYY-MM-DD."),
    ("now", "now()", "Milliseconds since 1970 (UTC)."),
    ("time", "time()", "Local time as HH:MM."),
    ("date", "date(\"tomorrow\")", "Date from a phrase: today, tomorrow, +3d, -1w, next monday, 2026-05-01."),
    ("is_date", "is_date(x)", "True when x is a YYYY-MM-DD date."),
    ("add_days", "add_days(date, n)", "Date plus n days (ranges shift as a whole)."),
    ("add_weeks", "add_weeks(date, n)", "Date plus n weeks."),
    ("add_months", "add_months(date, n)", "Date plus n months (month ends are clamped)."),
    ("add_years", "add_years(date, n)", "Date plus n years."),
    ("days_between", "days_between(a, b)", "Whole days from a to b."),
    ("weekday", "weekday(date?)", "0 = Monday … 6 = Sunday."),
    ("weekday_name", "weekday_name(date?)", "\"Monday\" …"),
    ("format_date", "format_date(date?)", "\"Jan 5, 2026\"."),
    ("next_date", "next_date(date, rule)", "Next occurrence of a repeat rule: \"weekly\", \"every 2 weeks\", \"mon,thu\", \"monthly\"."),
];

pub fn is_builtin(name: &str) -> bool {
    BUILTINS.iter().any(|b| b.0 == name) || matches!(name, "text" | "number" | "fail" | "log" | "each")
}

// ───────────────────────────── tests ─────────────────────────────

#[cfg(test)]
pub(crate) mod tests {
    use super::*;

    /// Minimal host: a table of pages with fields.
    #[derive(Default)]
    pub struct Mock {
        pub pages: Vec<(u64, String, BTreeMap<String, Value>)>,
        pub calls: Vec<String>,
    }

    impl Host for Mock {
        fn call(&mut self, name: &str, args: &[Value]) -> Option<Result<Value, String>> {
            match name {
                "rows" => Some(Ok(Value::list(self.pages.iter().map(|p| Value::Page(p.0)).collect()))),
                "notify" => {
                    let line = args.iter().map(|a| to_text(self, a)).collect::<Vec<_>>().join("|");
                    self.calls.push(format!("notify:{line}"));
                    Some(Ok(Value::Null))
                }
                _ => None,
            }
        }
        fn get(&mut self, page: u64, key: &str) -> Result<Value, String> {
            let p = self.pages.iter().find(|p| p.0 == page).ok_or("no such page")?;
            if key == "title" {
                return Ok(Value::Str(p.1.clone()));
            }
            Ok(p.2.get(key).cloned().unwrap_or(Value::Null))
        }
        fn set(&mut self, page: u64, key: &str, v: Value) -> Result<(), String> {
            let p = self.pages.iter_mut().find(|p| p.0 == page).ok_or("no such page")?;
            p.2.insert(key.to_owned(), v);
            Ok(())
        }
        fn title(&mut self, page: u64) -> String {
            self.pages.iter().find(|p| p.0 == page).map(|p| p.1.clone()).unwrap_or_default()
        }
    }

    fn eval(src: &str) -> Result<Value, ScriptError> {
        let mut h = Mock::default();
        run(src, &mut h, &[]).map(|o| o.value)
    }
    fn text(src: &str) -> String {
        let mut h = Mock::default();
        let v = run(src, &mut h, &[]).unwrap_or_else(|e| panic!("{src}\n=> {e}")).value;
        to_text(&mut h, &v)
    }

    #[test]
    fn arithmetic_strings_and_precedence() {
        assert_eq!(text("1 + 2 * 3"), "7");
        assert_eq!(text("(1 + 2) * 3"), "9");
        assert_eq!(text("10 % 4 + 7 / 2"), "5.5");
        assert_eq!(text("\"a\" + 1 + true"), "a1true");
        assert_eq!(text("-3 + 5"), "2");
        assert_eq!(text("1 < 2 and 2 < 3"), "true");
        assert_eq!(text("null ?? \"x\""), "x");
        assert_eq!(text("not (1 == 2)"), "true");
        assert_eq!(text("0.1 + 0.2"), "0.3");
    }

    #[test]
    fn variables_control_flow_and_functions() {
        assert_eq!(text("let s = 0\nfor i in 1..5 { s += i }\ns"), "10");
        assert_eq!(text("let n = 0\nwhile n < 5 { n += 1\n if n == 3 { break } }\nn"), "3");
        assert_eq!(text("fn fib(n) { if n < 2 { return n }\n return fib(n - 1) + fib(n - 2) }\nfib(15)"), "610");
        assert_eq!(text("let x = if 1 > 2 { \"a\" } else if 2 > 3 { \"b\" } else { \"c\" }\nx"), "c");
        assert_eq!(text("let f = |a, b| a * b\nf(6, 7)"), "42");
        assert_eq!(text("let mk = fn(n) { return |x| x + n }\nlet add5 = mk(5)\nadd5(10)"), "15");
        assert_eq!(text("let out = []\nfor i in 0..6 { if i % 2 == 0 { continue }\n push(out, i) }\nout"), "[1, 3, 5]");
        assert_eq!(text("let t = 0\nfor k, v in {a: 1, b: 2} { t += v }\nt"), "3");
    }

    #[test]
    fn lists_maps_and_methods() {
        assert_eq!(text("[3, 1, 2].sort()"), "[1, 2, 3]");
        assert_eq!(text("[1, 2, 3, 4].filter(|x| x % 2 == 0).map(|x| x * 10)"), "[20, 40]");
        assert_eq!(text("[1, 2, 3].reduce(|a, x| a + x, 0)"), "6");
        assert_eq!(text("[\"b\", \"a\"].sort().join(\"-\")"), "a-b");
        assert_eq!(text("let m = {a: 1}\nm.b = 2\nm[\"c\"] = m.a + m.b\nm"), "{a: 1, b: 2, c: 3}");
        assert_eq!(text("[1, 2, 3].len + \"x\".len"), "4");
        assert_eq!(text("[5, 6, 7][-1]"), "7");
        assert_eq!(text("slice([1, 2, 3, 4], 1, 3)"), "[2, 3]");
        assert_eq!(text("[1, 2, 3, 4].count(|x| x > 2)"), "2");
        assert_eq!(text("keys({x: 1, y: 2})"), "[\"x\", \"y\"]");
        assert_eq!(text("[\"a\", \"bb\", \"cc\"].group(|s| len(s))"), "{1: [\"a\"], 2: [\"bb\", \"cc\"]}");
        assert_eq!(text("let r = [1, 2, 3]\n  .map(|x| x + 1)\n  .filter(|x| x > 2)\nr"), "[3, 4]");
    }

    #[test]
    fn interpolation_and_templates() {
        assert_eq!(text("let n = 3\n\"{n} item{if n == 1 { \"\" } else { \"s\" }}\""), "3 items");
        assert_eq!(text("\"\\{literal}\""), "{literal}");
        let mut h = Mock::default();
        let v = eval_template("{1 + 2}", &mut h, &[]).unwrap();
        assert!(matches!(v, Value::Num(n) if n == 3.0));
        let v = eval_template("Due in {1 + 2} days", &mut h, &[]).unwrap();
        assert_eq!(to_text(&mut h, &v), "Due in 3 days");
    }

    #[test]
    fn dates_and_repeat_rules() {
        assert_eq!(text("add_days(\"2026-01-30\", 3)"), "2026-02-02");
        assert_eq!(text("add_months(\"2026-01-31\", 1)"), "2026-02-28");
        assert_eq!(text("add_years(\"2024-02-29\", 1)"), "2025-02-28");
        assert_eq!(text("days_between(\"2026-01-01\", \"2026-03-01\")"), "59");
        assert_eq!(text("weekday_name(\"2026-01-05\")"), "Monday");
        assert_eq!(text("next_date(\"2026-01-05\", \"weekly\")"), "2026-01-12");
        assert_eq!(text("next_date(\"2026-01-09\", \"weekdays\")"), "2026-01-12");
        assert_eq!(text("next_date(\"2026-01-05\", \"every mon, thu\")"), "2026-01-08");
        assert_eq!(text("next_date(\"2026-01-05\", \"every 2 weeks\")"), "2026-01-19");
        assert_eq!(text("next_date(\"2026-01-31\", \"monthly\")"), "2026-02-28");
        assert_eq!(text("add_days(\"2026-01-01/2026-01-03\", 7)"), "2026-01-08/2026-01-10");
        assert_eq!(text("date(\"+1w\") == add_days(today(), 7)"), "true");
        assert_eq!(text("format_date(\"2026-01-05\")"), "Jan 5, 2026");
    }

    #[test]
    fn host_pages_read_write_and_calls() {
        let mut h = Mock::default();
        h.pages.push((1, "Write docs".into(), BTreeMap::from([("Status".to_owned(), Value::str("Todo"))])));
        h.pages.push((2, "Ship".into(), BTreeMap::from([("Status".to_owned(), Value::str("Done"))])));
        let o = run("for t in rows() { if t.Status != \"Done\" { t.Status = \"Done\"\n notify(\"closed\", t.title) } }\nrows().filter(|r| r.Status == \"Done\").len", &mut h, &[]).unwrap();
        assert!(matches!(o.value, Value::Num(n) if n == 2.0));
        assert_eq!(h.calls, vec!["notify:closed|Write docs"]);
        let v = run("let r = rows()[0]\nr[\"Status\"] + \"/\" + r", &mut h, &[]).unwrap().value;
        assert_eq!(to_text(&mut h, &v), "Done/Write docs");
        let v = run("row.title", &mut h, &[("row", Value::Page(2))]).unwrap().value;
        assert_eq!(to_text(&mut h, &v), "Ship");
    }

    #[test]
    fn errors_are_friendly_and_have_lines() {
        let e = eval("let a = 1\nlet b = a +\n").unwrap_err();
        assert!(e.msg.contains("unexpected"), "{e}");
        let e = eval("let a = 1\nundefined_name + 1").unwrap_err();
        assert_eq!((e.line, e.msg.contains("unknown variable")), (2, true));
        let e = eval("foo(1)").unwrap_err();
        assert!(e.msg.contains("unknown function 'foo'"));
        assert!(eval("1 / 0").unwrap_err().msg.contains("division by zero"));
        assert!(eval("let x = null\nx.y").unwrap_err().msg.contains("null"));
        assert!(eval("if true { 1 ").unwrap_err().msg.contains("'}'") || true);
        assert!(parse("let = 3").is_err());
        assert!(parse("for x { }").is_err());
        assert!(parse("let s = \"abc").is_err());
        assert!(parse("1 + 1\nlet ok = [1, 2,\n 3]\nok").is_ok());
    }

    #[test]
    fn sandbox_limits() {
        let e = eval("while true { }").unwrap_err();
        assert!(e.msg.contains("steps"), "{e}");
        let e = eval("fn f(n) { return f(n + 1) }\nf(0)").unwrap_err();
        assert!(e.msg.contains("deeply"), "{e}");
        assert!(eval("range(0, 99999999)").is_err());
        let e = eval("let l = []\nwhile true { push(l, 1) }").unwrap_err();
        assert!(e.msg.contains("steps") || e.msg.contains("large"));
    }

    #[test]
    fn every_documented_builtin_exists() {
        for (name, sig, _) in BUILTINS {
            assert!(is_builtin(name), "{name}");
            assert!(sig.contains(name.split('_').next().unwrap_or(name)) || sig.contains(name), "{sig}");
        }
        // calling each with no arguments must never panic (errors are fine)
        let mut h = Mock::default();
        for (name, _, _) in BUILTINS {
            let _ = run(&format!("{name}()"), &mut h, &[]);
        }
    }
}
