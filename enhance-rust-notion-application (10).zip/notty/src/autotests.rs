//! Headless render tests for the automation UI and the redesigned media cards (they run a real egui frame at phone and desktop
//! sizes, so layout panics, runaway widths and broken state machines show up in `cargo test`).

use egui::{pos2, Event, Id, Modifiers, PointerButton, RawInput, Rect};

use crate::automation::{self as au, Rule, Runtime, Scope, Trigger};
use crate::autoui::{self, Ask, UiState};
use crate::model::{Block, BlockKind, ViewKind, Workspace};
use crate::theme::Palette;

fn ctx() -> egui::Context {
    let ctx = egui::Context::default();
    crate::theme::setup_fonts(&ctx);
    let _ = ctx.run(RawInput::default(), |_| {});
    ctx
}

fn input(w: f32, h: f32, t: f64, events: Vec<Event>) -> RawInput {
    let mut i = RawInput::default();
    i.screen_rect = Some(Rect::from_min_size(pos2(0.0, 0.0), egui::vec2(w, h)));
    i.time = Some(t);
    i.events = events;
    i
}

fn click(p: egui::Pos2) -> Vec<Event> {
    vec![
        Event::PointerMoved(p),
        Event::PointerButton { pos: p, button: PointerButton::Primary, pressed: true, modifiers: Modifiers::NONE },
        Event::PointerButton { pos: p, button: PointerButton::Primary, pressed: false, modifiers: Modifiers::NONE },
    ]
}

fn workspace() -> (Workspace, u64) {
    let mut ws = Workspace::seed();
    let db = ws.add_database(None, ViewKind::Table);
    ws.page_mut(db).unwrap().title = "Tasks".into();
    let info = au::db_info(&ws, db);
    for i in 0..au::RECIPES.len() {
        let mut r = au::build_recipe(i, &info);
        r.last_error = if i == 2 { "step 1: something went wrong".into() } else { String::new() };
        ws.auto.add(r);
    }
    let mut b = Rule::blank("Say hi", Trigger::Button);
    b.scope = Scope::Workspace;
    ws.auto.add(b);
    ws.auto.push_log(au::LogEntry { ts: 1.0, rule: 1, name: "Stamp".into(), ok: true, msg: "Set Completed to today".into() });
    ws.auto.push_log(au::LogEntry { ts: 2.0, rule: 2, name: "Broken".into(), ok: false, msg: "boom ".repeat(30) });
    (ws, db)
}

fn run_frames(ctx: &egui::Context, ws: &mut Workspace, rt: &mut Runtime, st: &mut UiState, size: (f32, f32), t: &mut f64, n: usize) -> Option<Rect> {
    let pal = Palette::light();
    let mut rect = None;
    for _ in 0..n {
        *t += 0.1;
        let _ = ctx.run(input(size.0, size.1, *t, vec![]), |c| {
            st.handle_asks(ws);
            autoui::show(c, ws, rt, st, &pal);
            rect = c.memory(|m| m.area_rect(Id::new("auto_center")));
        });
    }
    rect
}

#[test]
fn automation_center_fits_phone_and_desktop_on_every_tab() {
    let (mut ws, db) = workspace();
    let ctx = ctx();
    let mut rt = Runtime::default();
    let mut t = 0.0;
    for (w, h) in [(320.0_f32, 640.0_f32), (390.0, 760.0), (720.0, 800.0), (1300.0, 900.0)] {
        let mut st = UiState::default();
        // every tab
        for ask in [Ask::Open, Ask::Recipes(Some(db)), Ask::Open] {
            autoui_ask(ask);
            let r = run_frames(&ctx, &mut ws, &mut rt, &mut st, (w, h), &mut t, 4).expect("the center is shown");
            assert!(r.left() >= -0.5 && r.right() <= w + 0.5, "{w}px: center spans {:?}", r);
        }
        // every rule in the editor (conditions, steps, scripts, schedules …)
        let ids: Vec<u64> = ws.auto.rules.iter().map(|r| r.id).collect();
        for id in ids {
            autoui_ask(Ask::Edit(id));
            let r = run_frames(&ctx, &mut ws, &mut rt, &mut st, (w, h), &mut t, 4).expect("editor shown");
            assert!(r.left() >= -0.5 && r.right() <= w + 0.5, "{w}px rule {id}: editor spans {:?}", r);
        }
        // new automation and new button
        autoui_ask(Ask::New(Some(db)));
        run_frames(&ctx, &mut ws, &mut rt, &mut st, (w, h), &mut t, 3);
        autoui_ask(Ask::NewButton { page: db, block: 1 });
        run_frames(&ctx, &mut ws, &mut rt, &mut st, (w, h), &mut t, 3);
    }
}

fn autoui_ask(a: Ask) {
    autoui::ask(a);
}

#[test]
fn media_placeholders_and_button_block_render_at_every_width() {
    let (mut ws, _db) = workspace();
    autoui::publish(&ws);
    let ctx = ctx();
    let pal = Palette::light();
    let mut t = 0.0;
    let mut ed = crate::editor::EditorState::default();
    for width in [320.0_f32, 360.0, 430.0, 700.0, 1000.0] {
        let mut blocks: Vec<Block> = [BlockKind::Image, BlockKind::File, BlockKind::Embed, BlockKind::Bookmark, BlockKind::Button].iter().enumerate().map(|(i, k)| Block::new(100 + i as u64, *k, "", 0)).collect();
        let mut btn = Block::new(200, BlockKind::Button, "Quick add", 0);
        btn.link = ws.auto.rules.iter().find(|r| r.trigger == Trigger::Button).map(|r| r.id);
        blocks.push(btn);
        let w = (width - 40.0).max(240.0);
        for frame in 0..6 {
            t += 0.1;
            let mut max_right = 0.0_f32;
            let _ = ctx.run(input(width, 2600.0, t, if frame == 3 { click(pos2(60.0, 120.0)) } else { vec![] }), |c| {
                egui::CentralPanel::default().show(c, |ui| {
                    for b in blocks.iter_mut() {
                        if b.kind == BlockKind::Button {
                            crate::autoui::button_block(ui, b, 1, &pal, w);
                        } else {
                            crate::mediablocks::draw(ui, b, 1, &mut ed, &pal, w);
                        }
                    }
                    max_right = ui.min_rect().right();
                });
            });
            assert!(max_right <= width + 0.5, "{width}px: media cards are {max_right}px wide");
        }
        let _ = &mut ws;
    }
    // pressing the button queues exactly one run
    let _ = autoui::take_runs();
}

#[test]
fn script_condition_and_steps_survive_editing_roundtrip() {
    // a rule saved from the editor keeps its counters; converting to script keeps the behaviour
    let (mut ws, db) = workspace();
    let id = ws.auto.rules[0].id;
    let before = ws.auto.rule(id).unwrap().steps.clone();
    let code: Vec<String> = before.iter().map(|s| s.to_script()).collect();
    let script = code.join("\n");
    assert!(crate::script::parse(&script).is_ok(), "{script}");
    let rows = ws.rows(db);
    ws.page_mut(rows[0]).unwrap().title = "A".into();
    let mut r = Rule::blank("script", Trigger::Button);
    r.steps = vec![au::Step::Script { code: script }];
    let rep = au::run_rule(&mut ws, &r, Some(rows[0]), &au::TrigInfo::default());
    assert!(rep.ok, "{:?}", rep.error);
}
