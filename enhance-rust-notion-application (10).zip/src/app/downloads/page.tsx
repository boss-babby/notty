import { promises as fs } from "node:fs";
import path from "node:path";

export const dynamic = "force-dynamic";
export const metadata = { title: "Downloads — Lumen" };

export default async function Downloads() {
  let sums = "";
  try {
    sums = await fs.readFile(path.join(process.cwd(), "public", "downloads", "SHA256SUMS.txt"), "utf8");
  } catch {}
  return (
    <main className="mx-auto max-w-3xl px-5 py-16">
      <a href="/" className="text-sm text-[#2383e2] hover:underline">← Lumen</a>
      <h1 className="mt-4 text-3xl font-bold tracking-tight">Downloads</h1>
      <ul className="mt-6 space-y-3">
        <li><a className="font-semibold text-[#2383e2] hover:underline" href="/downloads/Lumen-windows-x64.zip">Lumen-windows-x64.zip</a> <span className="text-[#787774]">— the portable Windows app, zipped</span></li>
        <li><a className="font-semibold text-[#2383e2] hover:underline" href="/downloads/Lumen-windows-x64.exe">Lumen-windows-x64.exe</a> <span className="text-[#787774]">— the same executable, unzipped</span></li>
        <li><a className="font-semibold text-[#2383e2] hover:underline" href="/app">Web app (WebAssembly)</a> <span className="text-[#787774]">— opens right in the browser</span></li>
      </ul>
      <h2 className="mt-10 text-lg font-semibold">SHA-256</h2>
      <pre className="mt-2 overflow-x-auto rounded-lg bg-[#f7f6f3] p-4 text-xs">{sums || "No checksums published yet."}</pre>
      <h2 className="mt-10 text-lg font-semibold">Good to know</h2>
      <ul className="mt-2 list-disc space-y-2 pl-5 text-[15px] text-[#5f5e5b]">
        <li>The .exe is not code-signed, so Windows SmartScreen may ask you to confirm: <i>More info → Run anyway</i>.</li>
        <li>Windows desktop notifications for reminders appear while Lumen is running.</li>
        <li>Your workspace is stored on your device; use <i>Back up workspace</i> in the app to export it.</li>
      </ul>
    </main>
  );
}
