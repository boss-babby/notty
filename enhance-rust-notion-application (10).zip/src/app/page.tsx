import { promises as fs } from "node:fs";
import path from "node:path";
import LivePreview from "@/components/LivePreview";

export const dynamic = "force-dynamic";

async function info() {
  const pub = path.join(process.cwd(), "public");
  const stat = async (p: string) => {
    try {
      return (await fs.stat(path.join(pub, p))).size;
    } catch {
      return 0;
    }
  };
  let version = "";
  let built = "";
  try {
    const v = JSON.parse(await fs.readFile(path.join(pub, "webapp", "version.json"), "utf8"));
    version = v.version ?? "";
    built = v.built ?? "";
  } catch {}
  return { version, built, wasm: await stat("webapp/lumen_bg.wasm"), zip: await stat("downloads/Lumen-windows-x64.zip"), exe: await stat("downloads/Lumen-windows-x64.exe") };
}

const mb = (n: number) => (n ? `${(n / 1048576).toFixed(1)} MB` : "");

const FEATURES = [
  { t: "Pages that think", d: "Rich blocks, toggles, callouts, code, columns, table of contents, backlinks, page history and templates." },
  { t: "Databases, five ways", d: "Table, board, list, gallery and calendar views, plus timeline. Relations, rollups and formulas." },
  { t: "Dashboards & graph", d: "33 widgets and charts you can place in any page, and a graph of how your notes connect." },
  { t: "Media that looks right", d: "Images, video, embeds, bookmarks and a built-in PDF reader — added with a new drag-and-drop card." },
  { t: "Private by default", d: "Offline-first. Optional password lock. Your workspace lives on your device and in your backups." },
  { t: "Made for fingers", d: "Touch gestures, tap-and-hold menus, a phone-friendly layout and an installable PWA." },
];

const SCRIPT = `// Lumen Script — runs inside any automation
let late = rows("Tasks").filter(|t|
    t.Status != "Done" and t.Due != null and t.Due < today())

for t in late {
    t.Priority = "High"          // writes the property
}
if late.len > 0 {
    notify("{late.len} overdue", join(late.map(|t| t.title), ", "))
}`;

export default async function Home() {
  const i = await info();
  return (
    <main>
      <header className="sticky top-0 z-20 border-b border-[#efefed] bg-white/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-5 py-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#2383e2] text-lg font-bold text-white">L</span>
          <span className="text-lg font-semibold tracking-tight">Lumen</span>
          <nav className="ml-auto hidden items-center gap-6 text-sm text-[#5f5e5b] sm:flex">
            <a href="#automation" className="hover:text-black">Automation</a>
            <a href="#preview" className="hover:text-black">Live preview</a>
            <a href="#download" className="hover:text-black">Download</a>
          </nav>
          <a href="/app" className="ml-auto rounded-lg bg-[#2383e2] px-4 py-2 text-sm font-semibold text-white hover:bg-[#1b6fc4] sm:ml-2">Open web app</a>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-5 pb-14 pt-16 text-center sm:pt-24">
        <p className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full bg-[#e7f3f8] px-3 py-1 text-xs font-semibold text-[#2383e2]">
          Written entirely in Rust · Windows + WebAssembly{i.version ? ` · v${i.version}` : ""}
        </p>
        <h1 className="mx-auto max-w-3xl text-4xl font-bold leading-[1.08] tracking-tight sm:text-6xl">Your workspace, with an automation engine built in.</h1>
        <p className="mx-auto mt-5 max-w-2xl text-lg text-[#5f5e5b]">
          Lumen is a Notion-style notes and database app in one Rust codebase. New: rules, one-click buttons, recurring tasks, reminders — and a small scripting language for everything the cards can’t say.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <a href="/app" className="rounded-xl bg-[#2383e2] px-6 py-3 text-base font-semibold text-white shadow-sm hover:bg-[#1b6fc4]">Open in your browser</a>
          <a href="#download" className="rounded-xl border border-[#e0dfdc] px-6 py-3 text-base font-semibold hover:bg-[#f7f7f5]">Download for Windows{i.zip ? ` · ${mb(i.zip)}` : ""}</a>
        </div>
      </section>

      <section id="preview" className="mx-auto max-w-6xl scroll-mt-20 px-5 pb-20">
        <LivePreview />
      </section>

      <section id="automation" className="scroll-mt-20 bg-[#fbfbfa] py-20">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-[#2383e2]">Automation Center</p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">When this happens, do that. Or write it.</h2>
            <p className="mt-4 text-[#5f5e5b]">One calm screen for every automation: <b>When → Only if → Then</b> cards on top, a script editor underneath, and recipes to start from. It works the same on a 360&nbsp;pt phone and a 4K monitor.</p>
            <ul className="mt-6 space-y-3 text-[15px]">
              {[
                ["Rules", "Status changes, a row is added, a property changes — set dates, create rows, move rows, add notes."],
                ["Buttons", "Type /button on any page: one click runs an automation for that page or row."],
                ["Recurring tasks", "“Every 2 weeks”, “mon,thu”, “weekdays” — finish a task and its date moves on."],
                ["Reminders", "N days before a date, at a time. Desktop toast on Windows, push notification on the web."],
                ["Schedules", "Every N minutes, daily, weekdays, weekly or monthly — a missed run happens once when you return."],
                ["Safe by design", "Rules never retrigger themselves, loops are stopped, scripts are sandboxed, Test runs on a copy."],
              ].map(([a, b]) => (
                <li key={a} className="flex gap-3">
                  <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-[#2383e2]" />
                  <span><b>{a}.</b> <span className="text-[#5f5e5b]">{b}</span></span>
                </li>
              ))}
            </ul>
          </div>
          <div className="overflow-hidden rounded-2xl border border-[#e9e9e7] bg-white shadow-[0_16px_50px_rgba(15,15,15,0.08)]">
            <div className="border-b border-[#efefed] px-4 py-2.5 text-xs font-semibold text-[#787774]">Script step · Lumen Script</div>
            <pre className="overflow-x-auto bg-[#f7f6f3] p-5 text-[13px] leading-6 text-[#37352f]"><code>{SCRIPT}</code></pre>
            <div className="border-t border-[#efefed] px-4 py-3 text-xs text-[#787774]">
              Every visual step converts to script in one click. Rules are plain JSON and ship a machine-readable API spec — so an assistant can write them for you later.
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-20">
        <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Everything you expect from a workspace</h2>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.t} className="rounded-2xl border border-[#e9e9e7] p-6">
              <h3 className="text-lg font-semibold">{f.t}</h3>
              <p className="mt-2 text-[15px] text-[#5f5e5b]">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="download" className="scroll-mt-20 bg-[#fbfbfa] py-20">
        <div className="mx-auto max-w-6xl px-5">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Get Lumen</h2>
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <div className="rounded-2xl border border-[#e9e9e7] bg-white p-7">
              <h3 className="text-xl font-semibold">Windows</h3>
              <p className="mt-2 text-[#5f5e5b]">64-bit, a single portable .exe — no installer. Windows 10 / 11.</p>
              <div className="mt-5 flex flex-wrap gap-3">
                {i.zip ? (
                  <a href="/downloads/Lumen-windows-x64.zip" className="rounded-lg bg-[#2383e2] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#1b6fc4]">Download .zip · {mb(i.zip)}</a>
                ) : (
                  <span className="rounded-lg bg-[#efefed] px-5 py-2.5 text-sm text-[#787774]">Windows build not published yet</span>
                )}
                {i.exe ? <a href="/downloads/Lumen-windows-x64.exe" className="rounded-lg border border-[#e0dfdc] px-5 py-2.5 text-sm font-semibold hover:bg-[#f7f7f5]">.exe · {mb(i.exe)}</a> : null}
                <a href="/downloads" className="rounded-lg px-3 py-2.5 text-sm font-medium text-[#2383e2] hover:underline">Checksums &amp; notes</a>
              </div>
            </div>
            <div className="rounded-2xl border border-[#e9e9e7] bg-white p-7">
              <h3 className="text-xl font-semibold">WebAssembly</h3>
              <p className="mt-2 text-[#5f5e5b]">The same program in any modern browser. Installable on Android and iOS as an app (PWA) and usable offline.</p>
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <a href="/app" className="rounded-lg bg-[#2383e2] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#1b6fc4]">Open /app</a>
                <span className="text-sm text-[#787774]">{i.wasm ? `${mb(i.wasm)} wasm` : ""}{i.built ? ` · built ${i.built.slice(0, 10)}` : ""}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-[#efefed] py-10 text-center text-sm text-[#787774]">Lumen · Rust · egui · MIT licensed</footer>
    </main>
  );
}
