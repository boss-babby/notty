import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Lumen — a Notion-style workspace written entirely in Rust",
  description:
    "Pages, databases, boards, calendars, dashboards and a full automation engine with scripting — one Rust codebase that runs natively on Windows and as WebAssembly in your browser.",
  manifest: "/webapp/manifest.webmanifest",
  icons: { icon: "/webapp/icons/icon-192.png", apple: "/webapp/icons/apple-touch-icon.png" },
};

export const viewport: Viewport = { themeColor: "#ffffff", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-white text-[#37352f] antialiased">{children}</body>
    </html>
  );
}
