"use client";

import { useState } from "react";

/** Loads the real WebAssembly app in a frame — only after a click, so the landing page stays light. */
export default function LivePreview() {
  const [on, setOn] = useState(false);
  return (
    <div className="overflow-hidden rounded-2xl border border-[#e9e9e7] bg-white shadow-[0_20px_60px_rgba(15,15,15,0.10)]">
      <div className="flex items-center gap-2 border-b border-[#efefed] bg-[#fbfbfa] px-4 py-2.5">
        <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
        <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
        <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
        <span className="ml-3 truncate rounded-md bg-white px-3 py-1 text-xs text-[#787774] ring-1 ring-[#e9e9e7]">/app — Lumen (WebAssembly)</span>
        <a href="/app" target="_blank" rel="noreferrer" className="ml-auto text-xs font-medium text-[#2383e2] hover:underline">
          Open full screen ↗
        </a>
      </div>
      <div className="relative h-[560px] w-full bg-[#fbfbfa] sm:h-[640px]">
        {on ? (
          <iframe title="Lumen web app" src="/app" className="h-full w-full border-0" allow="clipboard-read; clipboard-write; fullscreen" />
        ) : (
          <button
            onClick={() => setOn(true)}
            className="group absolute inset-0 flex flex-col items-center justify-center gap-4 text-center"
            aria-label="Launch the live app"
          >
            <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#2383e2] text-3xl font-bold text-white shadow-lg transition group-hover:scale-105">L</span>
            <span className="text-lg font-semibold">Launch the live app</span>
            <span className="max-w-sm px-6 text-sm text-[#787774]">This is the real Rust program compiled to WebAssembly — your data stays in this browser.</span>
            <span className="rounded-lg bg-[#2383e2] px-5 py-2.5 text-sm font-semibold text-white">Start Lumen</span>
          </button>
        )}
      </div>
    </div>
  );
}
