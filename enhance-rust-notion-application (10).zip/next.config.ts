import type { NextConfig } from "next";

// The WebAssembly build lives in public/webapp (produced by notty/build-web.sh). The page itself is served at /app;
// its <base href="/webapp/"> makes every relative asset (lumen.js, lumen_bg.wasm, icons) resolve there.
const nextConfig: NextConfig = {
  async rewrites() {
    return [
      { source: "/app", destination: "/webapp/index.html" },
      { source: "/app/", destination: "/webapp/index.html" },
    ];
  },
  async headers() {
    return [
      {
        // the service worker is registered with scope "/" from /webapp/, so it needs this header; it must never be cached
        source: "/webapp/sw.js",
        headers: [
          { key: "Service-Worker-Allowed", value: "/" },
          { key: "Cache-Control", value: "no-cache, no-store, must-revalidate" },
          { key: "Content-Type", value: "text/javascript; charset=utf-8" },
        ],
      },
      {
        source: "/webapp/index.html",
        headers: [{ key: "Cache-Control", value: "no-cache" }],
      },
      {
        source: "/webapp/:file*.wasm",
        headers: [
          { key: "Content-Type", value: "application/wasm" },
          { key: "Cache-Control", value: "public, max-age=31536000, immutable" },
        ],
      },
    ];
  },
};

export default nextConfig;
