// ===== persist.js — compact save format for the explored map, the discovered-place atlas and world deltas =====
import { bkey, unkeyX, unkeyY } from './keys.js';

/** explored block keys → run-length rows  [[by, x0, len, x0, len …], …]  (a 1 M-block exploration is a few hundred KB, not tens of MB) */
export function encodeExplored(set) {
  const rows = new Map();
  for (const k of set) { const x = unkeyX(k), y = unkeyY(k); let r = rows.get(y); if (!r) rows.set(y, (r = [])); r.push(x); }
  const out = [];
  for (const [y, xs] of rows) {
    xs.sort((a, b) => a - b); const row = [y]; let s = xs[0], p = xs[0];
    for (let i = 1; i < xs.length; i++) { if (xs[i] === p + 1) { p = xs[i]; continue; } row.push(s, p - s + 1); s = p = xs[i]; }
    row.push(s, p - s + 1); out.push(row);
  }
  return out;
}
export function decodeExplored(rows, set) {
  if (!Array.isArray(rows)) return set;
  for (const row of rows) { const y = row[0]; for (let i = 1; i + 1 < row.length; i += 2) for (let x = row[i], e = row[i] + row[i + 1]; x < e; x++) set.add(bkey(x, y)); }
  return set;
}

/** everything that is "map knowledge": fog-of-war, every named place generated so far (only inside explored blocks) and the destroyed-prop deltas */
export function collectMapData(W) {
  const sites = W.atlas.toJSON().filter((r) => r[5] || W.explored.has(bkey(Math.floor(r[2] / 512), Math.floor(r[3] / 512))));
  return { v: 2, seed: W.seed, ex: encodeExplored(W.explored), atlas: sites, dl: [...W.deltas] };
}
export function applyMapData(W, d) {
  if (!d || d.seed !== W.seed) return false;
  decodeExplored(d.ex, W.explored); W.reindexExplored();
  W.atlas.load(d.atlas); for (const k of d.dl || []) W.deltas.add(k);
  return true;
}
const KEY = 'nt_save_map';
export function saveMapData(W) {
  const rev = (W.exploredRev || 0) + '|' + W.atlas.rev + '|' + W.deltas.size; if (W._mapRev === rev) return true; // nothing new since the last save → skip the encode
  const d = collectMapData(W);
  try { localStorage.setItem(KEY, JSON.stringify(d)); W._mapRev = rev; return true; }
  catch (e) { // quota: keep the registry + fast-travel destinations but drop the fog-of-war detail beyond the most recent area
    try { d.ex = encodeExplored(new Set([...W.explored].slice(-60000))); localStorage.setItem(KEY, JSON.stringify(d)); return true; } catch (e2) { return false; }
  }
}
export function loadMapData() { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { return null; } }
