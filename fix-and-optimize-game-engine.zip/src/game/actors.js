// ===== actors.js — characters & vehicles: pools, physics, player control, enter/exit, collisions =====
import { WEAPONS, VEHICLES, WEAPON_ORDER, SKINS, HAIR_COLORS, SHIRTS, PANTS, GANGS } from './data.js';
import { T } from './world.js';
import { clamp, rnd, pick, chance, angDiff, rotToward, TAU } from './util.js';
import { P } from './fx.js';
import { fireWeapon, startReload, finishReload, switchWeapon, damageActor, damageVehicle, damageProp, inVehicleBox, blow } from './combat.js';
import { crime } from './wanted.js';
import { paintOnChunks, vehicleSprite } from './gfx.js';

export function randomLook(type, fac) {
  const L = { skin: pick(SKINS), hair: pick(HAIR_COLORS), shirt: pick(SHIRTS), pants: pick(PANTS), style: Math.floor(Math.random() * 5), shades: chance(0.15), vest: false };
  if (fac === 'pd') { Object.assign(L, { shirt: '#24467f', pants: '#14213d', hair: '#14213d', style: 4, vest: true }); }
  else if (type === 'swat') Object.assign(L, { shirt: '#15181d', pants: '#101216', hair: '#0e0f12', style: 4, shades: true, vest: true });
  else if (type === 'army') Object.assign(L, { shirt: '#4b5a2f', pants: '#3a4524', hair: '#3a4a22', style: 4, vest: true });
  else if (fac === 'kes') Object.assign(L, { shirt: '#8a1a2c', pants: '#1a1a22', shades: true, style: chance(0.5) ? 3 : 1 });
  else if (GANGS.some((x) => x.id === fac)) { const gc = GANGS.find((x) => x.id === fac).color; Object.assign(L, { shirt: gc, pants: '#1d1f26', style: pick([1, 3, 4]), hair: pick(['#1b1b1b', '#c8c8c8']) }); }
  else if (type === 'guard') Object.assign(L, { shirt: '#4a4f57', pants: '#202228', style: 4, hair: '#2a2d33', vest: true });
  return L;
}

export class Actor {
  constructor(i) { this.i = i; this.on = false; this.look = randomLook('civ', 'civ'); }
  init(type, x, y, o = {}) {
    this.on = true; this.type = type; this.fac = o.fac || 'civ'; this.x = this.px = x; this.y = this.py = y; this.vx = this.vy = 0; this.kx = this.ky = 0;
    this.a = this.pa = o.a || 0; this.aim = this.a; this.r = 8; this.hp = this.max = o.hp || 100; this.armor = o.armor || 0; this.dead = false; this.deadT = 0; this.deadA = 0;
    this.wid = o.w || 'fists'; this.wdef = WEAPONS[this.wid]; this.cool = 0; this.reload = 0; this.bloom = 0; this.flash = 0; this.swing = 0; this.hurt = 0; this.stun = 0;
    this.anim = 0; this.moveAmt = 0; this.roll = 0; this.rollA = 0; this.vault = 0; this.crouch = false; this.cover = null; this.swim = false; this.stam = 100; this.stamDelay = 0;
    this.veh = null; this.heli = null; this.entering = 0; this.enterV = null; this.inside = o.inside || null; this.look = o.look || randomLook(type, this.fac);
    this.st = 'idle'; this.t = Math.random() * 2; this.goal = null; this.path = null; this.pi = 0; this.fear = 0; this.alert = 0; this.seen = false; this.target = null;
    this.mis = !!o.mis; this.speed = o.speed || 70 + Math.random() * 25; this.fire = 0; this.provoked = false; this.lastHitBy = null; this.noLoot = false; this.dmgMul = o.dmgMul || 0;
    this.brave = Math.random() < 0.12; this.snitch = Math.random() < 0.3; this.curious = Math.random() < 0.25; this.gx = 0; this.gy = 0; this.repath = 0; this.lastKnownX = 0; this.lastKnownY = 0;
    this.home = null; this.work = null; this.phone = 0; this.role = o.role || ''; this.boss = false; this.patrol = null; this.pw = 0; this.ally = false; this.strafe = Math.random() < 0.5 ? 1 : -1; this.burst = 0; this.vis = 260;
    this.lowSound = false; this.stuck = 0; this.sx = x; this.sy = y;
    return this;
  }
}

export function makeActors(n = 110) { return Array.from({ length: n }, (_, i) => new Actor(i)); }
export function spawnActor(g, type, x, y, o = {}) {
  for (const a of g.actors) if (!a.on && a !== g.player) return a.init(type, x, y, o);
  return null;
}

// ---------- shared movement ----------
export function stepActor(g, a, dt, dx, dy, speed) {
  const ctrl = a.stun > 0 ? 0.1 : 1, k = 1 - Math.exp(-11 * dt);
  a.vx += (dx * speed * ctrl - a.vx) * k; a.vy += (dy * speed * ctrl - a.vy) * k;
  a.x += (a.vx + a.kx) * dt; a.y += (a.vy + a.ky) * dt; const kd = Math.exp(-6 * dt); a.kx *= kd; a.ky *= kd;
  const r = g.pushCircle(a.x, a.y, a.r, true, a.vault > 0); a.x = r.x; a.y = r.y;
  if (r.hit && (Math.abs(a.kx) + Math.abs(a.ky)) > 200) { a.kx *= 0.3; a.ky *= 0.3; }
  const sp = Math.hypot(a.vx, a.vy);
  a.swim = !g.scene && g.world.tileAt(a.x, a.y) === T.WATER;
  a.moveAmt += ((sp > 20 ? Math.min(1, sp / 120) : 0) - a.moveAmt) * Math.min(1, dt * 12);
  a.anim += sp * dt * 0.1;
  if (a.stun > 0) a.stun -= dt;
  if (a.cool > 0) a.cool -= dt;
  if (a.flash > 0) a.flash -= dt; if (a.hurt > 0) a.hurt -= dt; if (a.swing > 0) a.swing -= dt * 4;
  a.bloom = Math.max(0, a.bloom - dt * 0.12);
  if (a.fire > 0) { a.fire -= dt; if (Math.random() < 0.6) g.parts.emit(P.FIRE, a.x + rnd(-4, 4), a.y + rnd(-4, 4), rnd(-10, 10), rnd(-30, -10), 0.4, 5, '#f90'); damageActor(g, a, 9 * dt, { kind: 'fire', by: null }); }
  if (a.swim && Math.random() < 0.05) g.parts.emit(P.RING, a.x, a.y, 0, 0, 0.6, 6, '#cfe8ff');
  if (a.swim && !a.wasSwim) g.audio.sfx('splash', a.x, a.y, 0.7);
  a.wasSwim = a.swim;
}
export function deadStep(g, a, dt) {
  a.deadT += dt; a.x += a.kx * dt; a.y += a.ky * dt; const kd = Math.exp(-5 * dt); a.kx *= kd; a.ky *= kd;
  const r = g.pushCircle(a.x, a.y, 6, false); a.x = r.x; a.y = r.y;
}

// ---------- player on foot ----------
export function cycleWeapon(g, dir) {
  const list = WEAPON_ORDER.filter((w) => g.inv.have[w]); if (list.length < 2) return;
  const i = list.indexOf(g.player.wid); switchWeapon(g, g.player, list[(i + dir + list.length) % list.length]);
}
export function updatePlayerFoot(g, dt) {
  const p = g.player, inp = g.input, mv = inp.move(), pad = inp.pad;
  const sk = g.skillLvl('stamina'), stamMax = 100 + 12 * sk;
  // --- aiming ---
  let aimA = p.aim;
  const mw = g.mouseWorld();
  const mouseActive = !(pad.on || inp.touch) || performance.now() - (inp.moveT || 0) < 2500;
  if (pad.aimActive) { aimA = Math.atan2(pad.ay, pad.ax); const t = padAssist(g, aimA); if (t !== null) aimA = t; }
  else if (pad.on && pad.down.aim) { const t = padAssist(g, p.aim); aimA = t !== null ? t : p.aim; }
  else if (mouseActive) aimA = Math.atan2(mw.y - p.y, mw.x - p.x);
  else if (Math.hypot(mv.x, mv.y) > 0.2) aimA = Math.atan2(mv.y, mv.x);
  p.aim = aimA; p.aimDist = Math.hypot(mw.x - p.x, mw.y - p.y);
  const wd = p.wdef; g.aiming = inp.down('aim') && (wd.type === 'gun' || wd.type === 'rocket');
  p.a = rotToward(p.a, p.aim, 16 * dt);
  // --- stamina / sprint ---
  const moving = Math.hypot(mv.x, mv.y) > 0.1;
  const sprint = inp.down('sprint') && moving && p.stam > 1 && !p.crouch && !p.swim && !g.aiming && p.roll <= 0;
  if (sprint) { p.stam -= 22 * dt; p.stamDelay = 0.7; g.xp('stamina', dt * 0.8); } else { p.stamDelay -= dt; if (p.stamDelay <= 0 && !p.swim) p.stam = Math.min(stamMax, p.stam + (16 + sk * 2) * dt); }
  p.stam = Math.min(p.stam, stamMax);
  if (p.swim) { p.stam -= 6 * dt; if (p.stam <= 0) { p.stam = 0; damageActor(g, p, 10 * dt, { kind: 'drown' }); } }
  // --- dodge / vault / cover ---
  if (inp.pressed('roll') && p.roll <= 0 && p.stam >= 16 && !p.swim && p.vault <= 0) {
    p.roll = 0.42; p.rollA = 0; p.stam -= 16; p.stamDelay = 0.8; p.rd = moving ? Math.atan2(mv.y, mv.x) : p.aim; p.cover = null; g.audio.sfx('swing', p.x, p.y, 0.4); g.style(0.01);
  }
  if (inp.pressed('jump') && p.vault <= 0 && p.roll <= 0 && !p.swim) { p.vault = 0.34; p.rd = moving ? Math.atan2(mv.y, mv.x) : p.a; p.cover = null; g.audio.sfx('swing', p.x, p.y, 0.3); }
  if (inp.pressed('cover')) {
    if (p.cover) { p.cover = null; p.crouch = false; }
    else {
      let best = null, bd = 99;
      for (let k = 0; k < 8; k++) { const a = (k * TAU) / 8; for (const d of [18, 26]) { const x = p.x + Math.cos(a) * d, y = p.y + Math.sin(a) * d; if (g.solidAt(x, y) || g.propSolidAt(x, y)) { if (d < bd) { bd = d; best = { x: Math.cos(a), y: Math.sin(a) }; } } } }
      if (best) { p.cover = best; p.crouch = true; } else p.crouch = !p.crouch;
    }
  }
  if (p.cover) { const x = p.x + p.cover.x * 24, y = p.y + p.cover.y * 24; if (!g.solidAt(x, y) && !g.propSolidAt(x, y) || sprint || p.roll > 0) { p.cover = null; p.crouch = false; } }
  if (p.roll > 0) { p.roll -= dt; p.rollA += dt * 16; stepActor(g, p, dt, Math.cos(p.rd), Math.sin(p.rd), 285); if (p.roll <= 0) p.rollA = 0; }
  else if (p.vault > 0) { p.vault -= dt; stepActor(g, p, dt, Math.cos(p.rd), Math.sin(p.rd), 235); }
  else {
    let spd = p.swim ? 62 : p.crouch ? 58 : sprint ? 205 * (1 + 0.02 * sk) : g.aiming ? 96 : 132;
    if (g.focusT > 0) spd *= 1.35;
    stepActor(g, p, dt, mv.x, mv.y, spd);
    // footsteps
    if (moving && !p.swim && Math.floor(p.anim / Math.PI) !== p.stepN) { p.stepN = Math.floor(p.anim / Math.PI); const t = g.scene ? 0 : g.world.tileAt(p.x, p.y); g.audio.footstep(t === T.GRASS || t === T.DIRT ? 'grass' : t === T.SAND ? 'sand' : t === T.WOOD ? 'wood' : 'stone', p.x, p.y, sprint ? 0.9 : 0.5); }
  }
  // --- weapons ---
  if (inp.wheel && !g.wheelOpen) { if (g.aiming && p.wid === 'sniper') g.scopeZ = clamp((g.scopeZ || 2.4) - inp.wheel * 0.4, 1.6, 5); else cycleWeapon(g, inp.wheel); }
  if (pad.pr.prevW) cycleWeapon(g, -1); if (pad.pr.nextW) cycleWeapon(g, 1);
  for (let i = 1; i <= 9; i++) if (inp.pr.has('Digit' + i)) { const w = WEAPON_ORDER.filter((x) => g.inv.have[x])[i - 1]; if (w) switchWeapon(g, p, w); }
  if (inp.pressed('reload')) startReload(g, p);
  if (p.reload > 0) { p.reload -= dt; if (p.reload <= 0) finishReload(g, p); }
  if (!g.wheelOpen && !g.uiOpen && p.roll <= 0 && p.vault <= 0) {
    const want = wd.auto || wd.type === 'melee' ? inp.down('fire') : inp.pressed('fire') || (inp.down('fire') && p.cool <= 0 && false);
    if (want) fireWeapon(g, p);
  }
  if (p.hp < p.max && g.regen) p.hp = Math.min(p.max, p.hp + dt * 0.5);
}
function padAssist(g, aimA) {
  let best = null, bd = 1e9;
  for (const a of g.actors) {
    if (!a.on || a.dead || a === g.player || a.inside !== g.insideId) continue;
    const hostile = a.fac === 'kes' || (a.fac === 'pd' && g.wanted.stars > 0) || a.target === g.player; if (!hostile) continue;
    const dx = a.x - g.player.x, dy = a.y - g.player.y, d = Math.hypot(dx, dy); if (d > 650) continue;
    const da = Math.abs(angDiff(aimA, Math.atan2(dy, dx))); if (da > 0.6) continue;
    const sc = d + da * 300; if (sc < bd) { bd = sc; best = a; }
  }
  return best ? Math.atan2(best.y - g.player.y, best.x - g.player.x) : null;
}

// ---------- vehicles ----------
export class Vehicle {
  constructor(i) { this.i = i; this.on = false; }
  init(type, x, y, a, o = {}) {
    const d = VEHICLES[type]; this.def = d; this.type = type; this.on = true; this.x = this.px = x; this.y = this.py = y; this.a = this.pa = a; this.vx = this.vy = 0; this.av = 0;
    this.hp = d.hp; this.color = o.color || pick(d.colors); this.ai = o.ai || 'none'; this.npc = o.npc || null; this.driver = null; this.thr = 0; this.str = 0; this.brk = 0; this.hb = false;
    this.hot = o.hot !== undefined ? o.hot : !!o.npc; this.owned = !!o.owned; this.siren = !!o.siren; this.wreck = false; this.exploded = false; this.burning = false; this.wreckT = 0;
    this.flat = false; this.z = 0; this.vz = 0; this.airT = 0; this.dents = []; this.upg = o.upg || { engine: 0, tires: 0, armor: 0 }; this.plate = o.plate || plate();
    this.panic = 0; this.provoked = false; this.mis = !!o.mis; this.lane = 0; this.dir = 0; this.turn = null; this.stuck = 0; this.rev = 0; this.skid = 0; this.rpm = 0; this.ind = 0;
    this.tgt = null; this.t = 0; this.lastHit = 0; this.gun = 0; this.flatT = 0; this.honkT = 0; this.alarm = 0; this.gunner = !!o.gunner; this.speedMul = o.speedMul || 1; this.lastSlipX = null; this.spotted = false;
    this.fireT = 0; this.cop = o.cop || false;
    return this;
  }
}
const plate = () => 'ABCDEFGHJKLMNPRSTUVWXYZ'[Math.floor(Math.random() * 23)] + 'ABCDEFGHJKLMNPRSTUVWXYZ'[Math.floor(Math.random() * 23)] + '-' + (100 + Math.floor(Math.random() * 900));
export function makeVehicles(n = 110) { return Array.from({ length: n }, (_, i) => new Vehicle(i)); }
export function spawnVehicle(g, type, x, y, a, o = {}) {
  for (const v of g.vehicles) if (!v.on) return v.init(type, x, y, a, o);
  // forced spawns (cheat menu, purchases, deliveries) evict the farthest unoccupied, non-mission, non-owned vehicle so they can never fail
  if (o.force) {
    const p = g.player; let ev = null, ed = -1;
    for (const v of g.vehicles) if (v.on && !v.driver && !v.mis && !v.owned && v !== p.veh) { const d = Math.hypot(v.x - p.x, v.y - p.y) + (v.wreck ? 5000 : 0); if (d > ed) { ed = d; ev = v; } }
    if (!ev) for (const v of g.vehicles) if (v.on && !v.driver && v !== p.veh && !v.mis) { ev = v; break; }
    if (ev) { if (ev.spot) { ev.spot.v = null; ev.spot = null; } return ev.init(type, x, y, a, o); }
  }
  // recycle the farthest wreck
  let w = null, wd = 0; for (const v of g.vehicles) if (v.wreck && !v.mis) { const d = Math.hypot(v.x - g.player.x, v.y - g.player.y); if (d > wd) { wd = d; w = v; } }
  return w ? w.init(type, x, y, a, o) : null;
}
const SURF = { [T.RUNWAY]: [1, 0.3], [T.TARMAC]: [0.97, 0.3], [T.CONCRETE]: [0.97, 0.3], [T.DESERT]: [0.6, 1.0], [T.MARSH]: [0.35, 2.2], [T.FARM]: [0.62, 0.9], [T.FOREST]: [0.5, 1.1], [T.SNOW]: [0.4, 1], [T.GRAVEL]: [0.72, 0.6], [T.TURF]: [0.6, 0.9], [T.ROAD]: [1, 0.35], [T.BRIDGE]: [1, 0.35], [T.PARKING]: [0.95, 0.3], [T.PLAZA]: [0.95, 0.3], [T.SIDEWALK]: [0.95, 0.3], [T.QUAY]: [0.95, 0.3], [T.BRIDGEW]: [0.95, 0.3], [T.WOOD]: [0.9, 0.3], [T.GRASS]: [0.55, 0.9], [T.DIRT]: [0.62, 0.7], [T.SAND]: [0.45, 1.3], [T.PATH]: [0.7, 0.5], [T.WATER]: [0.3, 3] };

export function updateVehicle(g, v, dt) {
  const d = v.def, W = g.env, w = g.world;
  if (v.wreck) { v.wreckT += dt; v.thr = 0; v.brk = 0; const k = Math.exp(-2 * dt); v.vx *= k; v.vy *= k; v.av *= k; if (v.wreckT > 55 && Math.hypot(v.x - g.player.x, v.y - g.player.y) > 900 && !v.mis) v.on = false; }
  const fx = Math.cos(v.a), fy = Math.sin(v.a), lx = -fy, ly = fx;
  let vF = v.vx * fx + v.vy * fy, vL = v.vx * lx + v.vy * ly;
  const tile = g.scene ? T.ROAD : w.tileAt(v.x, v.y); let sf = SURF[tile] || [0.8, 0.5]; if (d.offroad && sf[0] < 0.9) sf = [Math.max(sf[0], 0.88), sf[1] * 0.45];
  const wet = tile === T.ROAD || tile === T.BRIDGE || tile === T.PARKING ? W.wet : 0;
  const hpf = v.hp / d.hp, lvl = v.driver === g.player ? g.skillLvl('driving') : 0;
  const acc = d.acc * (1 + 0.09 * v.upg.engine) * (hpf < 0.3 ? 0.7 : 1) * v.speedMul, vmax = d.vmax * (1 + 0.04 * v.upg.engine + 0.01 * lvl) * (hpf < 0.3 ? 0.85 : 1) * v.speedMul;
  if (v.z <= 0) {
    // throttle / brake
    if (v.thr > 0) { if (vF < vmax) vF += acc * v.thr * (1 - Math.max(0, vF) / vmax * 0.8) * dt; }
    else if (v.thr < 0) { if (vF > 25) vF -= d.brk * 0.9 * dt; else if (vF > -vmax * 0.38) vF -= acc * 0.6 * -v.thr * dt; }
    if (v.brk > 0) { const b = d.brk * v.brk * dt; vF = Math.abs(vF) < b ? 0 : vF - Math.sign(vF) * b; }
    if (!v.thr && !v.brk) vF -= vF * 0.6 * dt;
    vF -= vF * sf[1] * 0.35 * dt; vF -= vF * Math.abs(vF) / (vmax * 2200) * 60 * dt * 0.1;
    // lateral grip
    let grip = d.grip * sf[0] * (1 - 0.5 * wet) * (1 + 0.08 * v.upg.tires + 0.025 * lvl) * (v.flat ? 0.55 : 1);
    if (v.hb) grip *= 0.16;
    vL *= Math.exp(-grip * dt);
    // steering
    const sp = Math.abs(vF), maxSteer = d.steer / (1 + (sp / vmax) * 1.7) * (v.flat ? 0.7 : 1);
    let rate = v.str * maxSteer * clamp(vF / 70, -1, 1);
    if (v.hb && sp > 60) rate = v.str * d.steer * 0.95 * clamp(sp / 200, 0.3, 1.1);
    if (Math.abs(vL) > 90) rate += Math.sign(vL) * 0.0; // keep slide yaw from input only
    v.av += (rate - v.av) * (1 - Math.exp(-(v.hb ? 6 : 11) * dt));
    v.a += v.av * dt;
    v.vx = fx * vF + lx * vL; v.vy = fy * vF + ly * vL;
    v.rpm += (clamp(Math.abs(vF) / vmax, 0, 1) * 0.8 + (v.thr > 0 ? 0.2 : 0) - v.rpm) * Math.min(1, dt * 6);
    // skid & smoke
    const slip = Math.abs(vL) + (v.hb && sp > 150 ? 80 : 0);
    v.skid = slip > 85 && (tile !== T.WATER) ? clamp((slip - 70) / 160, 0, 1) : 0;
    if (v.skid > 0 && !g.scene) {
      const bx = v.x - fx * d.len * 0.3, by = v.y - fy * d.len * 0.3, ox = lx * d.wid * 0.38, oy = ly * d.wid * 0.38;
      if (v.lastSlipX !== null && tile !== T.GRASS && tile !== T.SAND && tile !== T.DIRT) {
        paintOnChunks(w, bx, by, bx, by, (c) => { c.strokeStyle = `rgba(8,8,10,${0.22 * v.skid})`; c.lineWidth = 2.4; c.beginPath(); c.moveTo(v.lastSlipX + ox, v.lastSlipY + oy); c.lineTo(bx + ox, by + oy); c.moveTo(v.lastSlipX - ox, v.lastSlipY - oy); c.lineTo(bx - ox, by - oy); c.stroke(); });
      }
      v.lastSlipX = bx; v.lastSlipY = by;
      if (Math.random() < 0.5 * v.skid) g.parts.emit(P.SMOKE, bx + rnd(-3, 3), by + rnd(-3, 3), rnd(-12, 12), rnd(-12, 12), 0.7, 4, tile === T.GRASS || tile === T.DIRT || tile === T.SAND ? '#a89870' : '#ccc');
      if (v.driver === g.player && v.skid > 0.5 && sp > 120) { g.xp('driving', dt * 1.2); g.style(dt * 0.06); g.stats.drift += dt; }
    } else v.lastSlipX = null;
    if (tile === T.GRASS || tile === T.DIRT || tile === T.SAND) { if (sp > 120 && Math.random() < 0.3) g.parts.emit(P.SMOKE, v.x - fx * d.len * 0.4, v.y - fy * d.len * 0.4, 0, 0, 0.6, 3, '#a89870'); }
  } else { v.a += v.av * dt; v.av *= Math.exp(-0.3 * dt); }
  // water
  if (tile === T.WATER && !g.scene && v.z <= 0) { v.vx *= Math.exp(-1.6 * dt); v.vy *= Math.exp(-1.6 * dt); v.waterT = (v.waterT || 0) + dt; damageVehicle(g, v, 28 * dt, {}); if (Math.random() < 0.2) g.parts.emit(P.RING, v.x + rnd(-10, 10), v.y + rnd(-10, 10), 0, 0, 0.6, 8, '#cfe8ff'); if (v.waterT > 1.5 && v.driver) { g.exitVehicle(v.driver, true); } }
  else v.waterT = 0;
  // ramps / air
  if (v.z <= 0 && !g.scene) {
    const sp = Math.hypot(v.vx, v.vy);
    if (sp > 230) { g._q2 = g._q2 || []; g._q2.length = 0; w.propHash.query(v.x, v.y, 60, g._q2); for (const p of g._q2) if (p.t === 'ramp' && Math.hypot(p.x - v.x, p.y - v.y) < 30 && Math.abs(angDiff(v.a, p.a)) < 1) { v.vz = Math.min(430, sp * 0.85); v.z = 0.1; v.airT = 0; g.audio.sfx('thud', v.x, v.y, 0.4); break; } }
  }
  if (v.z > 0) {
    v.airT += dt; v.vz -= 780 * dt; v.z += v.vz * dt;
    if (v.z <= 0) { v.z = 0; v.vz = 0; g.audio.sfx('crash', v.x, v.y, 0.6); g.parts.burst(P.SPARK, v.x, v.y, 10, 200, 0.4, 2, '#ffd27a'); g.cam.shake = Math.max(g.cam.shake, 6); damageVehicle(g, v, 12, {}); if (v.driver === g.player && v.airT > 0.8) g.stunt(v.airT); v.airT = 0; }
  }
  v.x += v.vx * dt; v.y += v.vy * dt;
  // tile & prop collisions via 3 circles
  if (v.z <= 0 || true) collideTiles(g, v, v.z > 4);
  // burning, smoke, damage
  if (v.hp < d.hp * 0.4 && !v.wreck && Math.random() < dt * 8) g.parts.emit(P.SMOKE, v.x + fx * d.len * 0.3, v.y + fy * d.len * 0.3, rnd(-10, 10), rnd(-20, -5), 1, 5, v.hp < d.hp * 0.2 ? '#222' : '#777');
  if (v.burning) {
    if (!v.wreck) { v.hp -= 9 * dt; if (v.hp <= 0) blow(g, v, {}); }
    if (Math.random() < dt * 22) g.parts.emit(P.FIRE, v.x + rnd(-d.len / 3, d.len / 3), v.y + rnd(-d.wid / 3, d.wid / 3), rnd(-8, 8), rnd(-30, -10), 0.5, 7, '#f90');
    if (Math.random() < dt * 5) g.parts.emit(P.SMOKE, v.x, v.y, 0, -22, 1.5, 7, '#333');
    g.lights.add(v.x, v.y, 120, '#ff8a2a', 0.7);
    if (v.wreck && v.wreckT > 14) v.burning = false;
  }
  if (v.driver && v.flat && v.driver === g.player) v.flatT += dt;
  if (v.alarm > 0) { v.alarm -= dt; if (Math.floor(v.alarm * 3) !== Math.floor((v.alarm + dt) * 3)) g.audio.sfx('caralarm', v.x, v.y, 0.3); }
  if (v.ind > 0) v.ind -= dt;
  if (v.panic > 0) v.panic -= dt;
}
function collideTiles(g, v, airborne) {
  if (airborne) return;
  const d = v.def, fx = Math.cos(v.a), fy = Math.sin(v.a), offs = d.len > 80 ? [-0.36, -0.12, 0.12, 0.36] : [-0.3, 0, 0.3], rad = d.wid / 2 + 1;
  for (let it = 0; it < 2; it++) for (const o of offs) {
    const cx = v.x + fx * d.len * o, cy = v.y + fy * d.len * o, res = g.pushCircle(cx, cy, rad, true, false);
    if (!res.hit) continue;
    const px = res.x - cx, py = res.y - cy; v.x += px; v.y += py;
    const nx = res.nx, ny = res.ny, vn = v.vx * nx + v.vy * ny;
    if (vn < 0) {
      const imp = -vn;
      if (res.prop && res.prop.hp < 1e8 && imp > 140) { const pr = res.prop; damageProp(g, pr, imp * 0.6, { by: v.driver }); v.vx *= 0.82; v.vy *= 0.82; if (pr.dead) continue; }
      v.vx -= 1.25 * vn * nx; v.vy -= 1.25 * vn * ny;
      const rx = cx - v.x, ry = cy - v.y; v.av += (rx * ny - ry * nx) * imp * 0.0011 / d.mass;
      if (imp > 70) { const dm = Math.max(0, imp - 110) * 0.14; if (dm > 0) { damageVehicle(g, v, dm, { by: v.driver }); g.addDent(v, cx, cy); } if (imp > 150) { g.parts.burst(P.SPARK, cx + nx * -rad, cy + ny * -rad, 6, 200, 0.3, 1.6, '#ffd27a'); g.audio.sfx('crash', v.x, v.y, Math.min(1, imp / 300)); if (v.driver === g.player) { g.cam.shake = Math.max(g.cam.shake, imp / 40); g.fx.ab = Math.max(g.fx.ab, 0.3); } if (v.npc && v.panic <= 0) v.panic = 3; } }
      if (!g.scene && !res.prop && imp > 100 && g.world.solid(cx - nx * (rad + 2), cy - ny * (rad + 2)) && v.driver === g.player) crime(g, 'vandal', v.x, v.y);
    }
    const f = Math.exp(-0.5 * 0.016); v.vx *= f; v.vy *= f;
  }
}

/** vehicle-vs-vehicle and vehicle-vs-actor collisions (run once per step after movement) */
const _vq = [];
export function collideAll(g) {
  for (const a of g.vehicles) {
    if (!a.on || a.z > 4) continue;
    _vq.length = 0; g.hashV.query(a.x, a.y, a.def.len + 70, _vq);
    for (const b of _vq) {
      if (b.i <= a.i || !b.on || b.z > 4) continue;
      const dx = b.x - a.x, dy = b.y - a.y, dd = Math.hypot(dx, dy); if (dd > (a.def.len + b.def.len) / 2 + 6) continue;
      const af = Math.cos(a.a), as = Math.sin(a.a), bf = Math.cos(b.a), bs = Math.sin(b.a), ra = a.def.wid / 2, rb = b.def.wid / 2;
      const ao = a.def.len > 80 ? [-0.36, -0.12, 0.12, 0.36] : [-0.3, 0, 0.3], bo = b.def.len > 80 ? [-0.36, -0.12, 0.12, 0.36] : [-0.3, 0, 0.3];
      let done = false;
      for (const oa of ao) { if (done) break; for (const ob of bo) {
        const ax = a.x + af * a.def.len * oa, ay = a.y + as * a.def.len * oa, bx = b.x + bf * b.def.len * ob, by = b.y + bs * b.def.len * ob;
        const cx = bx - ax, cy = by - ay, cd = Math.hypot(cx, cy), rr = ra + rb;
        if (cd >= rr || cd < 0.001) continue;
        const nx = cx / cd, ny = cy / cd, pen = rr - cd, ma = a.def.mass, mb = b.def.mass, tm = ma + mb;
        const wa = a.driver || a.npc ? 1 : 1.2, wb = b.driver || b.npc ? 1 : 1.2;
        a.x -= nx * pen * (mb / tm) * 0.9 * wb / wb; a.y -= ny * pen * (mb / tm) * 0.9; b.x += nx * pen * (ma / tm) * 0.9; b.y += ny * pen * (ma / tm) * 0.9; void wa;
        const rvx = a.vx - b.vx, rvy = a.vy - b.vy, vn = rvx * nx + rvy * ny;
        if (vn > 0) {
          const j = (1.35 * vn) / (1 / ma + 1 / mb);
          a.vx -= (j / ma) * nx; a.vy -= (j / ma) * ny; b.vx += (j / mb) * nx; b.vy += (j / mb) * ny;
          a.av += ((ax - a.x) * -ny - (ay - a.y) * -nx) * vn * 0.0008 / ma; b.av -= ((bx - b.x) * -ny - (by - b.y) * -nx) * vn * 0.0008 / mb;
          if (vn > 60) {
            const dmA = Math.max(0, vn - 55) * 0.16 * (mb / tm) * 2, dmB = Math.max(0, vn - 55) * 0.16 * (ma / tm) * 2;
            damageVehicle(g, a, dmA, { by: b.driver }); damageVehicle(g, b, dmB, { by: a.driver }); g.addDent(a, ax, ay); g.addDent(b, bx, by);
            g.parts.burst(P.SPARK, (ax + bx) / 2, (ay + by) / 2, 6, 200, 0.3, 1.6, '#ffd27a'); g.audio.sfx('crash', (ax + bx) / 2, (ay + by) / 2, Math.min(1, vn / 280));
            if (a.driver === g.player || b.driver === g.player) { g.cam.shake = Math.max(g.cam.shake, vn / 35); g.style(0.01); const o = a.driver === g.player ? b : a; if (o.npc) { o.panic = 5; o.provoked = true; if (vn > 140) crime(g, 'vandal', o.x, o.y); } }
            else { if (a.npc && a.panic <= 0) a.panic = 3; if (b.npc && b.panic <= 0) b.panic = 3; }
          }
        }
        done = true; break;
      } }
    }
    vehicleVsActors(g, a);
  }
}
const _aq = [];
function vehicleVsActors(g, v) {
  const sp = Math.hypot(v.vx, v.vy), c = Math.cos(v.a), s = Math.sin(v.a); _aq.length = 0; g.hashA.query(v.x, v.y, v.def.len / 2 + 30, _aq);
  for (const a of _aq) {
    if (!a.on || a.veh || a.enterV === v || a.inside !== g.insideId) continue;
    const dx = a.x - v.x, dy = a.y - v.y, lx = dx * c + dy * s, ly = -dx * s + dy * c, hx = v.def.len / 2 + a.r, hy = v.def.wid / 2 + a.r;
    if (Math.abs(lx) > hx || Math.abs(ly) > hy) continue;
    if (a.dead) { if (sp > 40) { a.kx += v.vx * 0.5; a.ky += v.vy * 0.5; } continue; }
    if (sp > 80 && v.z < 8) {
      const dm = (sp - 60) * 0.4 * Math.min(2, v.def.mass); damageActor(g, a, dm, { by: v.driver, kind: 'vehicle', dx: v.vx, dy: v.vy });
      a.kx += v.vx * 0.9; a.ky += v.vy * 0.9; a.stun = 0.8; g.audio.sfx('thud', a.x, a.y, 0.8); v.vx *= 0.97; v.vy *= 0.97;
      if (v.driver === g.player && a.fac === 'civ') { crime(g, 'runover', a.x, a.y); g.style(0.04); }
      if (a === g.player) { g.fx.ab = 1; g.cam.shake = Math.max(g.cam.shake, 10); }
    } else {
      const px = hx - Math.abs(lx), py = hy - Math.abs(ly);
      if (px < py) { const k = (lx > 0 ? 1 : -1) * px; a.x += c * k; a.y += s * k; } else { const k = (ly > 0 ? 1 : -1) * py; a.x += -s * k; a.y += c * k; }
    }
  }
}

// ---------- enter / exit ----------
export function nearestVehicle(g, x, y, maxD = 46) {
  let best = null, bd = maxD;
  for (const v of g.vehicles) {
    if (!v.on || v.z > 2 || (v.wreck && v.def.shape !== 'x')) continue;
    const dx = x - v.x, dy = y - v.y, c = Math.cos(v.a), s = Math.sin(v.a), lx = dx * c + dy * s, ly = -dx * s + dy * c;
    const d = Math.hypot(Math.max(0, Math.abs(lx) - v.def.len / 2), Math.max(0, Math.abs(ly) - v.def.wid / 2));
    if (d < bd) { bd = d; best = v; }
  }
  return best;
}
export function tryEnterVehicle(g) {
  const p = g.player; const v = nearestVehicle(g, p.x, p.y); if (!v || v.wreck || p.entering > 0) return false;
  if (v.driver && v.driver !== p) return false;
  if (v.def.shape === 'army' && !g.cheats.god && false) return false;
  if (v.npc) {
    // carjack: pull the driver out
    const kind = v.npc, fac = kind === 'cop' || kind === 'swat' ? 'pd' : kind === 'army' ? 'pd' : ['vip', 'sun', 'vel', 'kes'].includes(kind) ? kind : 'civ';
    const side = doorPos(v, -1), a = spawnActor(g, kind === 'army' ? 'army' : kind === 'swat' ? 'swat' : fac === 'pd' ? 'cop' : fac === 'civ' ? 'civ' : 'gang', side.x, side.y, { fac, w: fac === 'pd' ? 'pistol' : fac === 'civ' ? 'fists' : 'pistol' });
    if (a) { a.kx = (side.x - v.x) * 8; a.ky = (side.y - v.y) * 8; a.stun = 1.2; a.fear = 1; if (fac !== 'civ') { a.st = 'combat'; a.target = p; } else if (chance(0.25)) { a.brave = true; } a.provoked = true; }
    v.npc = null; v.ai = 'none'; v.hot = true; crime(g, 'carjack', v.x, v.y); g.stats.carjacks++; g.news && g.news('carjack');
    if (!v.mis) { if (g.checkTheft) g.checkTheft(v); }
  } else if (!v.hot && !v.owned) {
    if (g.ui && g.ui.hotwire) { g.ui.hotwire(v, (ok) => { if (ok) { v.hot = true; crime(g, 'theft', v.x, v.y); g.audio.sfx('engineStart', v.x, v.y); beginEnter(g, p, v); } else { v.alarm = 6; g.noise(v.x, v.y, 600, { by: p }); crime(g, 'theft', v.x, v.y); } }); return true; }
    v.hot = true;
  }
  beginEnter(g, p, v); return true;
}
function doorPos(v, side) { const k = v.def.wid / 2 + 12; return side < 0 ? { x: v.x + Math.sin(v.a) * k, y: v.y - Math.cos(v.a) * k } : { x: v.x - Math.sin(v.a) * k, y: v.y + Math.cos(v.a) * k }; }
function beginEnter(g, p, v) { p.entering = 0.32; p.enterV = v; p.cover = null; p.crouch = false; g.audio.sfx('door', v.x, v.y, 0.5); }
export function updateEntering(g, dt) {
  const p = g.player, v = p.enterV; p.entering -= dt;
  if (!v || !v.on) { p.entering = 0; return; }
  const k = 1 - Math.exp(-18 * dt); p.x += (v.x - p.x) * k; p.y += (v.y - p.y) * k; p.a = rotToward(p.a, v.a, 10 * dt);
  if (p.entering <= 0) seat(g, p, v);
}
export function seat(g, p, v) {
  p.veh = v; v.driver = p; v.ai = 'none'; v.npc = null; v.hot = true; p.enterV = null; v.brk = 0; p.vx = p.vy = 0; p.roll = 0;
  v.spotted = false; if (v.def.siren && v.cop) v.siren = false;
  g.stats.vehiclesDriven++; if (g.onEnterVehicle) g.onEnterVehicle(v);
}
export function exitVehicle(g, a, force) {
  const v = a.veh; if (!v) return;
  const sides = [-1, 1, 2, -2];
  let spot = null;
  for (const s of sides) {
    const k = s === 2 ? { x: v.x + Math.cos(v.a) * (v.def.len / 2 + 14), y: v.y + Math.sin(v.a) * (v.def.len / 2 + 14) } : s === -2 ? { x: v.x - Math.cos(v.a) * (v.def.len / 2 + 14), y: v.y - Math.sin(v.a) * (v.def.len / 2 + 14) } : { x: v.x + Math.sin(v.a) * (v.def.wid / 2 + 13) * s, y: v.y - Math.cos(v.a) * (v.def.wid / 2 + 13) * s };
    if (!g.solidAt(k.x, k.y) && !g.propSolidAt(k.x, k.y)) { spot = k; break; }
  }
  if (!spot) spot = { x: v.x, y: v.y };
  a.x = spot.x; a.y = spot.y; a.veh = null; a.vx = v.vx * 0.3; a.vy = v.vy * 0.3; a.entering = 0;
  v.driver = null; v.thr = 0; v.str = 0; v.brk = 0.6; v.hb = false; v.siren = a === g.player ? false : v.siren;
  const sp = Math.hypot(v.vx, v.vy);
  if (force || sp > 260) { a.kx = v.vx * 0.5; a.ky = v.vy * 0.5; a.stun = 0.8; if (sp > 260 && !force) damageActor(g, a, (sp - 200) * 0.08, { kind: 'fall' }); }
  g.audio.setTire(0); g.audio.engine(0, -1, 0);
  if (a === g.player) { g.audio.setHorn(false); if (g.onExitVehicle) g.onExitVehicle(v); }
}

// ---------- player driving ----------
export function updatePlayerDrive(g, dt) {
  const p = g.player, v = p.veh, inp = g.input, mv = inp.move();
  const vF = v.vx * Math.cos(v.a) + v.vy * Math.sin(v.a);
  v.thr = 0; v.brk = 0; v.str = mv.x * (g.settings.steerAssist ? 1 : 1);
  if (mv.y < -0.1) v.thr = -mv.y;
  if (mv.y > 0.1) { if (vF > 30) v.brk = mv.y; else v.thr = -mv.y; }
  v.hb = inp.down('jump');
  if (inp.pressed('siren') && v.def.siren) { v.siren = !v.siren; g.audio.sfx('click'); }
  if (inp.down('horn') || (v.driver && inp.pad.down.horn)) { g.audio.setHorn(true); g.hornT = 0.2; if (Math.random() < dt * 3) g.noise(v.x, v.y, 300, { by: p }); } else g.audio.setHorn(false);
  if (inp.pressed('radio')) g.nextStation();
  if (inp.wheel) { g.nextStation(inp.wheel); }
  p.x = v.x; p.y = v.y; p.a = v.a; p.aim = v.a;
  if (p.stam < 100) p.stam += 20 * dt;
  p.moveAmt = 0; p.reload = 0; p.cover = null;
  if (v.def.turret && false) return;
  g.xp('driving', Math.hypot(v.vx, v.vy) * dt * 0.0016);
  g.stats.distance += Math.hypot(v.vx, v.vy) * dt * 0.05;
}

// ---------- drawing ----------
export function drawVehicle(c, v, x, y, a, time, night) {
  const d = v.def, spr = vehicleSprite(d, v.color), W = d.len + 10, H = d.wid + 10, z = v.z, sc = 1 + z / 220;
  c.save();
  if (!v.wreck || true) { c.translate(x + z * 0.35, y + z * 0.5 + 2); c.rotate(a); c.fillStyle = `rgba(0,0,0,${0.3 - Math.min(0.15, z / 400)})`; rr2(c, -d.len / 2 - 1, -d.wid / 2 - 1, d.len + 2, d.wid + 2, 6); c.fill(); }
  c.restore(); c.save(); c.translate(x, y - z * 0.6); c.rotate(a); c.scale(sc, sc);
  c.drawImage(spr, -W / 2, -H / 2, W, H);
  if (v.wreck) { c.fillStyle = 'rgba(10,8,8,.72)'; rr2(c, -d.len / 2, -d.wid / 2, d.len, d.wid, 6); c.fill(); }
  else {
    if (v.dents.length) for (const k of v.dents) { c.fillStyle = 'rgba(0,0,0,.35)'; c.beginPath(); c.ellipse(k.x, k.y, k.s, k.s * 0.6, k.r, 0, 6.3); c.fill(); c.strokeStyle = 'rgba(255,255,255,.2)'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(k.x - k.s, k.y); c.lineTo(k.x + k.s, k.y - 1); c.stroke(); }
    if (v.brk > 0.1 || (v.thr < 0 && Math.abs(v.vx * Math.cos(v.a) + v.vy * Math.sin(v.a)) < 40)) { c.fillStyle = '#ff2a2a'; c.fillRect(-d.len / 2 - 0.5, -d.wid / 2 + 1.5, 3, 5); c.fillRect(-d.len / 2 - 0.5, d.wid / 2 - 6.5, 3, 5); }
    if (v.ind > 0 && Math.floor(time * 3) % 2 === 0) { c.fillStyle = '#ffb300'; c.fillRect(d.len / 2 - 3, v.turnDir > 0 ? d.wid / 2 - 3 : -d.wid / 2, 3, 3); c.fillRect(-d.len / 2, v.turnDir > 0 ? d.wid / 2 - 3 : -d.wid / 2, 3, 3); }
    if (v.siren && d.siren) { const ph = Math.floor(time * 8) % 2; c.fillStyle = ph ? '#ff2a3a' : '#2a6aff'; c.fillRect(-4, -d.wid / 2 + 3, 5, (d.wid - 6) / 2); c.fillStyle = ph ? '#2a6aff' : '#ff2a3a'; c.fillRect(-4, 0, 5, (d.wid - 6) / 2); }
    if (d.shape === 'moto' && v.driver) { c.fillStyle = '#243'; c.beginPath(); c.arc(-2, 0, 4.5, 0, 6.3); c.fill(); c.fillStyle = v.driver.look.skin; c.beginPath(); c.arc(0, 0, 3.4, 0, 6.3); c.fill(); c.fillStyle = '#222'; c.beginPath(); c.arc(-0.5, 0, 3.6, 0, 6.3); c.fill(); }
    if (d.turret) { c.fillStyle = '#1a2310'; c.save(); c.translate(-6, 0); c.rotate(v.gunA || 0); c.fillRect(0, -1.5, 22, 3); c.restore(); }
  }
  c.restore();
  void night;
}
function rr2(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
export { startReload, WEAPONS };
