// ===== input.js — keyboard, mouse, gamepad, touch; rebindable actions =====
export const ACTIONS = [
  ['up', 'Move Up'], ['down', 'Move Down'], ['left', 'Move Left'], ['right', 'Move Right'], ['sprint', 'Sprint'], ['roll', 'Dodge Roll'],
  ['jump', 'Vault / Handbrake'], ['interact', 'Interact / Enter Vehicle'], ['reload', 'Reload'], ['cover', 'Take Cover'], ['wheel', 'Weapon Wheel'],
  ['fire', 'Fire'], ['aim', 'Aim / Scope'], ['radio', 'Next Radio Station'], ['horn', 'Horn'], ['siren', 'Siren'], ['phone', 'Phone'],
  ['map', 'Map'], ['focus', 'Tidal Focus'], ['pause', 'Pause'],
];
const DEFAULTS = {
  up: ['KeyW', 'ArrowUp'], down: ['KeyS', 'ArrowDown'], left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'],
  sprint: ['ShiftLeft', 'ShiftRight'], roll: ['KeyV', 'ControlLeft'], jump: ['Space'], interact: ['KeyE'], reload: ['KeyR'], cover: ['KeyC'],
  wheel: ['KeyQ'], fire: ['Mouse0'], aim: ['Mouse2'], radio: ['KeyX'], horn: ['KeyH'], siren: ['KeyG'], phone: ['Tab'], map: ['KeyM'], focus: ['KeyF'], pause: ['Escape', 'KeyP'],
};
const BLOCK = new Set(['Tab', 'Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'F1', 'F2', 'F3', 'F4', 'Backquote', 'ControlLeft']);

export class Input {
  constructor(el) {
    this.el = el; this.keys = new Set(); this.pr = new Set(); this.rel = new Set();
    this.mx = 0; this.my = 0; this.wheel = 0; this.virt = {}; this.virtPr = {};
    this.pad = { on: false, mx: 0, my: 0, ax: 0, ay: 0, down: {}, pr: {}, prev: {}, aimActive: false, lock: false };
    this.touch = false; this.rebinding = null; this.onRebind = null; this.enabled = true; this.unsub = [];
    this.bind = JSON.parse(JSON.stringify(DEFAULTS));
    try { const s = JSON.parse(localStorage.getItem('nt_bind') || 'null'); if (s) Object.assign(this.bind, s); } catch (e) { /* ignore */ }
    const on = (t, ev, fn, o) => { t.addEventListener(ev, fn, o); this.unsub.push(() => t.removeEventListener(ev, fn, o)); };
    on(window, 'keydown', (e) => {
      if (this.rebinding) { e.preventDefault(); this.setBind(this.rebinding, e.code); return; }
      if (e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
      if (BLOCK.has(e.code) && this.enabled) e.preventDefault();
      if (!e.repeat) this.pr.add(e.code);
      this.keys.add(e.code);
    });
    on(window, 'keyup', (e) => { this.keys.delete(e.code); this.rel.add(e.code); });
    on(window, 'blur', () => { this.keys.clear(); });
    on(el, 'mousemove', (e) => { this.mx = e.clientX; this.my = e.clientY; this.moveT = performance.now(); });
    on(el, 'mousedown', (e) => {
      this.mx = e.clientX; this.my = e.clientY;
      if (this.rebinding) { e.preventDefault(); this.setBind(this.rebinding, 'Mouse' + e.button); return; }
      this.keys.add('Mouse' + e.button); this.pr.add('Mouse' + e.button);
    });
    on(window, 'mouseup', (e) => { this.keys.delete('Mouse' + e.button); this.rel.add('Mouse' + e.button); });
    on(el, 'contextmenu', (e) => e.preventDefault());
    on(el, 'wheel', (e) => { this.wheel += Math.sign(e.deltaY); }, { passive: true });
    on(window, 'touchstart', () => { if (!this.touch) { this.touch = true; this.buildTouch(); } }, { passive: true });
  }
  destroy() { this.unsub.forEach((f) => f()); if (this.touchEl) this.touchEl.remove(); }
  setBind(a, code) {
    this.bind[a] = [code]; this.rebinding = null;
    try { localStorage.setItem('nt_bind', JSON.stringify(this.bind)); } catch (e) { /* ignore */ }
    if (this.onRebind) this.onRebind();
  }
  resetBinds() { this.bind = JSON.parse(JSON.stringify(DEFAULTS)); try { localStorage.removeItem('nt_bind'); } catch (e) { /* ignore */ } }
  down(a) { const b = this.bind[a]; if (b) for (let i = 0; i < b.length; i++) if (this.keys.has(b[i])) return true; return !!this.virt[a] || !!this.pad.down[a]; }
  pressed(a) { const b = this.bind[a]; if (b) for (let i = 0; i < b.length; i++) if (this.pr.has(b[i])) return true; return !!this.virtPr[a] || !!this.pad.pr[a]; }
  released(a) { const b = this.bind[a]; if (b) for (let i = 0; i < b.length; i++) if (this.rel.has(b[i])) return true; return false; }
  /** movement vector, normalised if > 1 */
  move() {
    let x = (this.down('right') ? 1 : 0) - (this.down('left') ? 1 : 0), y = (this.down('down') ? 1 : 0) - (this.down('up') ? 1 : 0);
    x += this.pad.mx + (this.virt.mx || 0); y += this.pad.my + (this.virt.my || 0);
    const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; }
    return { x, y };
  }
  endStep() { this.pr.clear(); this.rel.clear(); this.wheel = 0; this.virtPr = {}; this.pad.pr = {}; }
  /** gamepad polling — call once per frame */
  poll() {
    let gp = null;
    try { const l = navigator.getGamepads ? navigator.getGamepads() : []; for (const p of l) if (p && p.connected) { gp = p; break; } } catch (e) { /* ignore */ }
    const P = this.pad;
    if (!gp) { P.on = false; P.mx = P.my = 0; P.down = {}; if (!this.touch) P.aimActive = false; return; }
    P.on = true;
    const dz = (v) => (Math.abs(v) < 0.18 ? 0 : v);
    P.mx = dz(gp.axes[0] || 0); P.my = dz(gp.axes[1] || 0); P.ax = dz(gp.axes[2] || 0); P.ay = dz(gp.axes[3] || 0);
    P.aimActive = Math.hypot(P.ax, P.ay) > 0.3;
    const b = (i) => !!(gp.buttons[i] && gp.buttons[i].pressed);
    const map = { interact: 0, roll: 1, reload: 2, focus: 3, fire: 7, aim: 6, sprint: 10, map: 8, pause: 9, cover: 11, phone: 12, radio: 13, horn: 14, wheel: 15 };
    const cur = {};
    for (const k in map) cur[k] = b(map[k]);
    cur.prevW = b(4); cur.nextW = b(5);
    for (const k in cur) { if (cur[k] && !P.prev[k]) P.pr[k] = true; }
    P.down = cur; P.prev = cur;
    P.lock = b(6);
  }
  buildTouch() {
    const d = document.createElement('div'); d.id = 'touch'; this.touchEl = d;
    d.innerHTML = '<div class="tj" id="tjL"><i></i></div><div class="tj" id="tjR"><i></i></div>' +
      [['interact', 'E', 'right:150px;bottom:30px'], ['jump', '⤒', 'right:30px;bottom:150px'], ['roll', '↻', 'right:100px;bottom:210px'], ['reload', 'R', 'right:30px;bottom:230px'], ['sprint', '»', 'left:30px;bottom:200px'], ['phone', '☎', 'right:20px;top:90px'], ['pause', 'II', 'right:20px;top:20px'], ['focus', 'F', 'right:100px;bottom:20px']]
        .map(([a, t, s]) => `<button class="tb" data-a="${a}" style="${s}">${t}</button>`).join('');
    document.body.appendChild(d);
    d.querySelectorAll('.tb').forEach((b) => {
      const a = b.dataset.a;
      b.addEventListener('touchstart', (e) => { e.preventDefault(); this.virt[a] = true; this.virtPr[a] = true; }, { passive: false });
      const up = () => { this.virt[a] = false; };
      b.addEventListener('touchend', up); b.addEventListener('touchcancel', up);
    });
    const stick = (id, cb) => {
      const el = d.querySelector(id), knob = el.firstChild; let tid = null, cx = 0, cy = 0;
      el.addEventListener('touchstart', (e) => { e.preventDefault(); const t = e.changedTouches[0]; tid = t.identifier; const r = el.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2; }, { passive: false });
      el.addEventListener('touchmove', (e) => {
        e.preventDefault();
        for (const t of e.changedTouches) if (t.identifier === tid) {
          let dx = (t.clientX - cx) / 50, dy = (t.clientY - cy) / 50; const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; }
          knob.style.transform = `translate(${dx * 40}px,${dy * 40}px)`; cb(dx, dy);
        }
      }, { passive: false });
      const end = () => { tid = null; knob.style.transform = ''; cb(0, 0); };
      el.addEventListener('touchend', end); el.addEventListener('touchcancel', end);
    };
    stick('#tjL', (x, y) => { this.virt.mx = x; this.virt.my = y; });
    stick('#tjR', (x, y) => { this.pad.ax = x; this.pad.ay = y; this.pad.aimActive = Math.hypot(x, y) > 0.3; this.virt.fire = Math.hypot(x, y) > 0.75; });
  }
}
