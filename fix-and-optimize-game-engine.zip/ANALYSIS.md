# NEON TIDE — Analysis, fixes and the road to procedural infinity

## 1. What the game was (analysis of the uploaded ZIP)
A very complete engine (~4,600 dense lines, zero external assets): seeded city generator, chunked ground canvases, y-sorted sprites, AI (peds, traffic, police, gangs), 12 story missions, 14 interiors, synthesised audio. Weak points found:

| Area | Finding | Impact |
|---|---|---|
| **Lighting** | Night = a 0.86-alpha navy rectangle with soft holes punched out (`destination-out`). Dusk lasted 3 in-game hours, the game *started* at 18:50, vignette 0.55–0.7 black on top, bloom raised with darkness. | Large unreadable black areas, harsh pools of light, player lost in the dark. |
| **Cheat "summon car"** | Vehicle pool = 70 slots. Traffic + parked cars fill it, and `spawnVehicle` only recycled *wrecks* → returned `null`, the cheat silently did nothing. The car was also dropped 90 px in front of the player with no check for walls, water or props. Same bug in the AutoTrader delivery. | Car summons "randomly" failed. |
| **World** | 192×192 tiles, one city, one climate, 5 districts, no air/military/rural content. Many magic numbers (`11`, `192`, `180`) baked in. | Small, repetitive. |
| **Interiors** | 14 hand-made rooms; every house door was decoration. | Few places to go. |
| **Gameplay variety** | 14 vehicles, one region of traffic, no travel, no restricted areas, no regional identity. | Little reason to explore. |

## 2. What was changed

### 2.1 Lighting (realistic model — `render.js`, `game.js`)
* **Ambient colour of the sky is multiplied over the world** instead of a black overlay: moonlight blue at night (never below ~33 % brightness), pink/gold sunrise, neutral noon, golden hour, red sunset, purple dusk (14 keyframes, smooth-stepped, in `AMB`). Rain/fog/storm desaturate and dim it.
* **Every light adds coloured energy** to the lightmap (additive `lighter`), then the map is multiplied over the frame: lamp posts (warm 2700 K), neon signs, headlights (cones), brake lights, sirens, muzzle flashes, explosions, ATC tower/terminal glow. Lights fade in smoothly at dusk (`vis`) instead of popping on.
* A faint moon-fill/torch light always follows the player. A small additive bloom + wet-road reflections sit on top.
* Vignette 0.55 → 0.34, bloom 0.3×dark → 0.16×dark, game starts at 16:20 (sunny afternoon), interiors use a warm per-theme ambient + lamps, never black.

### 2.2 Cheat / car summons (`game.js`, `actors.js`, `ui.js`)
* `spawnVehicle(..., {force:true})` evicts the farthest unoccupied, non-mission, non-owned vehicle → **cannot fail**. Pool enlarged 70 → 110, actor pool 110 → 130.
* `g.summonVehicle()` searches rings around the player (96–340 px, 10 headings) for a spot not inside a building, water, solid prop or another car, aligns the car with the road if on one, and toasts "press E". Menu closes on click.
* New cheat items: repair vehicle, deliver every car to the garage, time presets (golden hour, sunset…), fast travel to every city, grouped vehicle list.
* AutoTrader deliveries use the same forced spawn.

### 2.3 One continuous world, 9× larger (`regions.js`, `world.js`)
18,432 px × 18,432 px (576×576 tiles, 36×36 blocks), 3×3 super-regions, all connected by roads/bridges and sharing the traffic grid:

| | Region | Contents |
|---|---|---|
| NW | **Port Meridian** | the original city (story missions untouched) |
| N | **Sol Costa** | neon pastel beach city: resort towers, Galleria mall, marina, mansions, Club Electra, stadium, SCPD, hospital, tiki bar |
| NE | **Fort Granite** | fenced **army camp**: HQ, barracks, armory, hangars, helipads + helicopters, tanks, tents, sandbags, watchtowers, gate/checkpoint, firing range; snowy highlands & quarry. Trespass 7 s → soldiers open fire (3★) |
| W | **Saguaro Springs** | desert town (saloon, sheriff, motel, mission church, diner, clinic, trailer park, gas), ranches, solar farm, copper mine, drive-in, red mesa canyon |
| Centre | **Aurelia** | mega-city: 80–170 px skyscrapers, central park, station, Dome stadium, university, casino, grand hotel, mall, police, hospital |
| E | **Skyline International Airport** | 156-tile runway + 2nd runway, taxiways, apron with 10 airliners / jets, terminal (**enter it, buy a ticket, fly to any city**), control tower (enterable), hangars, cargo, fuel farm, helipads, parking, hotel |
| SW | **Pine Ridge** | forest, Lake Verde with docks/boats, lodge, cabins, ranger station, campground, lumber mill, snowcapped mountains |
| S | **Ambrose Valley** | crop fields, farmsteads, Marlow town, power plant, wind farm, crop-duster airstrip |
| SE | **Bayou Rouge & the Keys** | swamp (marsh tiles), boardwalk stilt village, gator bar, bait shop, motel, three resort islands linked by the Overseas Highway bridge |

New tile types (runway, tarmac, desert, marsh, farm, forest, snow, concrete, gravel, turf) with their own art, driving grip and AI costs; new building kinds (mountain, hangar, terminal, ATC tower, stadium, solar); 25 new prop types (airliners, jets, helicopters, tanks, trucks, boats, tents, turbines, cattle, cacti, pines…) with collision "blockers" so planes are solid.

### 2.4 Rooms / interiors (`interiors.js`)
17 new enterable interiors: furnished multi-room **houses** (every house door works), cabins, lodge, motel, hotel, mansion, mall, nightclub, church, **airport terminal**, ATC tower, hangar, barracks, army HQ, armory & duty-free shops. Sleep/save/shop/ATM/flight objects, staff and passenger NPCs, per-theme warm lighting.

### 2.5 GTA-VI-style variety
* 10 new vehicles (SUV, off-road 4×4, cabrio, hypercar, limo, army jeep, long-haul truck, tractor, golf cart + existing) with **regional traffic mixes** (cabrios & limos in Sol Costa, pickups in the desert, tractors in farmland, jeeps at the fort, taxis in Aurelia).
* Regional population density, soldiers on base, street names per region, 100+ discoverable places (+$25 each), world map with city labels, fast-travel flights.
* Planned next (data hooks exist): boats/jet-ski, flyable helicopter, wildlife (gators, deer), heists per region, regional gang turf, social-media phone app, dynamic wanted-level by jurisdiction.

---

## 3. Infinite procedural worlds (No Man's Sky style) and how they relate to this game

### 3.1 How NMS-like generation actually works
1. **One seed → everything.** A 64-bit seed is hashed with coordinates (`hash(seed, x, y, z, salt)`); every attribute (terrain height, biome, creature morphology, colours) is a *pure function* of that hash. No world is stored — it is recomputed on demand and is identical for every player.
2. **Hierarchy of scales.** Galaxy → star system → planet → region → chunk → voxel. Each level only needs its parent's seed. This is why a planet can be generated without its neighbours.
3. **Layered noise.** Continents = low-frequency simplex/Perlin, mountains = ridged multifractal, erosion = domain warping, biomes = temperature × humidity lookup. Rules (not hand-placement) decide where life, ore, settlements appear.
4. **Streaming + LOD.** Only chunks near the camera exist; far chunks are discarded or kept at low detail. Generation runs on worker threads within a per-frame budget.
5. **Grammar-based content.** Creatures, ships, buildings are assembled from parts using weighted rules and constraints, so variety is combinatorial.
6. **Hand-authored anchors.** Story, missions and key set-pieces are placed *on top* of the generated substrate.

### 3.2 What we already share with it
* `hash2`, `vnoise`, `mulberry32` in `util.js` are exactly the primitives above; the whole world is generated from `seed = 1337`.
* The ground is already **streamed per 16×16-tile chunk** with LRU eviction (`ensureChunks`), and props/vehicles/peds are spawned around the camera.
* Block generators (`genBlock`, `genDowntown`, region blocks) are *functions of (seed, bx, by)* — re-running one block never needs the rest of the world.
* Regions are a 3×3 "galaxy map" of biomes with their own rules (palette, building grammar, traffic, density) — the same idea as NMS biomes, just authored on a fixed grid.

### 3.3 Why it is not infinite yet (and what blocks it)
| Limit | Today | Needed for infinity |
|---|---|---|
| Storage | `tiles/meta/bid` are fixed `Uint8Array(576²)`; buildings/props are global arrays | sparse **chunk store**: `Map<chunkKey, {tiles, buildings, props}>` generated on demand, freed when far |
| Coordinates | float px up to 18,432 | float32 jitters beyond ~100k px → **floating origin** (re-centre the world on the player, keep chunk ints) |
| Roads | global grid lines, hand-picked per region | procedural network: arterial lines from a low-frequency field, local streets via subdivision, bridges where road crosses water |
| Pathfinding | A* over the whole array | hierarchical A* (chunk graph) + local A* within loaded chunks |
| Persistence | save = player + a few globals | save only *deltas* (destroyed props, owned cars, mission flags); the base world is re-derived from the seed |
| Missions | POIs hard-coded in `data.js` | quest templates that pick a POI of a type from the nearest chunks ("steal a jet from an airfield", "deliver to a farm") |
| Global scans | `world.buildings` is iterated every frame | spatial hash / per-chunk lists (already in place for props) |

### 3.4 A concrete migration plan
1. **Chunk-local generators.** Convert each region block function to `genChunk(cx, cy)`; the call becomes `hash(seed, cx, cy)` seeded. Cross-chunk features (rivers, highways, mountains) use *continuous* noise sampled in world space so neighbouring chunks agree without communicating.
2. **Macro layer.** Sample 2-3 low-frequency fields per chunk (elevation, moisture, "urbanity"). Biome = lookup (`urbanity>0.7 → city; elevation>0.6 → mountains; moisture>0.6 → swamp; …`). The nine hand-made regions become *authored overrides* ("anchors") at fixed chunk ranges — exactly the NMS approach of hand-placed content in a procedural galaxy.
3. **Cities by grammar.** City = centre + radius; density falls off with distance; blocks pick a template (tower, shops, park, houses) weighted by distance from centre and district noise; landmarks (airport, army base, stadium) are placed by *rules* (flat land, near a highway, minimum spacing) from a per-super-cell hash.
4. **Streaming budget.** Generate ≤ 1 chunk per frame (or in a Web Worker returning transferable typed arrays); keep a ring of N chunks; render chunk canvases as already done.
5. **Floating origin** to keep precision, plus chunk-key integers (`(cx+32768)*65536+cy+32768`) instead of the current `cx*64+cy`.
6. **Planetary scale** (optional "Discovery mode"): a *seed browser* — each seed is a whole "state" (like a planet). Show the seed in the menu, let players share seeds, and use the same generator with different biome weights → a different continent with different city names (name grammar: syllable tables per region).
7. **Content variety with grammars:** building facades (kind × palette × signage grammar), vehicles (body shape × colour × livery tables), NPC outfits per biome, shop names from word-lists. This is the cheapest way to get the NMS "everything is different" feeling.

### 3.5 Where it helps us most
* **Replayability:** every new game can roll a new seed — new geography, same handcrafted story anchored at the player's starting city.
* **Size without authoring cost:** the 9 regions took ~600 lines because they reuse helpers and hash-based scattering (`sprinkle`, `massif`, `plane`). Infinite = the same helpers driven by noise instead of coordinates.
* **Risks:** procedural worlds are *wide but shallow* (the NMS criticism). The fix used in this project is the right one: **procedural substrate + authored anchors** (airport, fort, mansions, story missions) + systemic gameplay (heat, turf, traffic, weather) that makes any place feel alive.
* **Performance:** keep generation deterministic and cheap (< 3 ms/chunk), cache chunk canvases, never scan global arrays per frame.

## 4. Controls added
`E` at the airport terminal's *Departures* desk → fast travel (fare by distance). `` ` ``/`F2` cheat menu → summon any vehicle, travel to any city/POI, time presets, repair, deliver all cars.

---

# v3 update — bug fixes, street-light control, helicopters, procedural Frontier

## 5. Bugs fixed
| Bug | Root cause | Fix |
|---|---|---|
| **Player invisible inside buildings / rooms** | `renderInterior` only draws actors whose `inside === g.insideId`, but `player.inside` was never set (it stayed `null`), so the player was skipped (and interior guards could never target him). | `stepSim` now syncs `player.inside = g.insideId` every tick, and the interior renderer always draws the player as a safety net. |
| **Sniper zoom buggy** | (1) "scope" set `cam.zoom = 0.6` = *zoom out*; (2) camera lead was `aimDir × 330`, but the aim direction is computed from the cursor's world position, which depends on the camera → positive feedback loop (aim stuck / drifting); (3) a black disc hid the world and the reticle was at screen centre while the cursor aimed elsewhere. | Camera lead is now derived from the cursor's **screen** offset (`mouseLead`), so it can never feed back into the aim. The scope is a real magnifying lens that follows the cursor (×1.6–5, mouse wheel), surroundings dimmed not blacked out, mil-dot reticle, faster zoom blend. Same stable lead for normal aiming. |

## 6. Street lights & evening / night aesthetics
* `env.eve` = schedule curve (on 17:10→19:10, off 05:00→06:50, bad weather lifts it in the daytime); `env.lamp` = that, or the user override.
* **Control:** Settings → *Street lights* (Auto / Always on / Always off) + *Light glow* slider; **L** key cycles the mode; Cheat menu has three buttons.
* Lamp posts are now unlit fixtures in the sprite; the bulb, halo and light pool are drawn by the renderer only when on. Each lamp has its own switch-on threshold (they pop on one by one at dusk), ~6 % flicker, halos grow in fog/rain (volumetric haze), wet-road reflections kept.
* Windows light up building by building (staggered). Soft-light **golden-hour** grade from the low sun (mirrored at dawn), and a teal→magenta **night split-tone**. Bloom scales with lamps.

## 7. Helicopters (cheat menu → *Helicopters*)
`heli.js`: **Skylark** charter helicopter (general aviation, 5 colours) and **Reaper AH-9** gunship (combat; olive/black/desert). E boards, hold **Space** to lift off, **Shift/C** descend, land to exit (rooftops are landable; flying below a roofline clips it). Gunship: nose follows the mouse, **LMB** minigun, **RMB/R** rocket pods (24, regenerate). 2.5D lift + shadow, rotor blur, nav lights/strobes, searchlight pool at night, rotor-wash dust/spray, synthesised rotor audio, altitude/hull/rotor HUD. Damage to the pilot is redirected to the hull (armour factor 0.42 / 0.2); crashes explode.

## 8. Procedural Frontier — first concrete step of §3.4
The world grew from 576² to **768² tiles** (NT0 = 576 authored, NT = 768). East and south of the nine authored regions, across an ocean channel (with bridges/causeways wherever an authored road meets the shore), `frontier.js` generates land as a pure function of **(seed, tile)**:
* **Macro layer:** elevation + moisture fBm (value noise) → biome lookup: lakes/bays, beaches, desert, grass/farmland, forest, marsh, rock massifs, snow caps; outer coast falls off to ocean.
* **Cities by grammar:** one candidate per 6×6-block super-cell (hash) → centre, radius, name (syllable grammar); urbanity falls off with distance: towers → shops → houses/parks; landmark hotel (enterable, helipad roof) + fountain at the centre; shops/houses use the existing interiors; lamps, crosswalks, zones, discoveries, fast-travel + flight destinations are registered automatically.
* **Roads** follow the existing 16-tile block grid (arterials every 4th block, full grids in cities) so traffic AI, minimap, bridges and the map work unchanged.
* **Seeds:** the main menu has a *World seed* box (🎲 = random). New Game rebuilds the world from the seed (turf is restored from `turf0` instead of re-generating), the seed is shown in the welcome toast and stored in saves. Generation of the whole world takes ≈130 ms.
* **Still to do for true infinity** (see §3.3): chunk-sparse storage, floating origin, hierarchical A*. `frontier.js` is already written as pure per-tile / per-block functions, so those steps are mechanical.

---

# v4 update — a truly infinite world (no boundary), with identity

> Goal: *no boundary, explore as much as you want — and the generated land must not be generic: it must be as unique and competent as the hand-coded regions.*
> Result: the 768² authored map (nine regions + Frontier) is now an **anchor island inside an unbounded plane** generated by `terra.js`, `terra_gen.js`, `terra_data.js`. Walk, drive or fly in any direction forever; nothing is stored except what you changed.

## 9. Analysis — what really stopped the world from being infinite

I audited every consumer of the world arrays before writing a line of generator code (blast-radius map):

| # | Blocker | Where | How it was solved |
|---|---|---|---|
| 1 | `tiles/meta/bid` are flat `Uint8Array(NT²)` indexed `y*NT+x`; out-of-range reads returned **BUILDING** (an invisible wall) | `world.js` (`tileAt`, `solidTile`, `metaAt`), `gfx.js`, `render.js`, `heli.js` | New accessors `tl/mt/bidAt`. Inside the core they hit the flat arrays (zero cost); outside they hit a **sparse block store** (`Map<blockKey, Block>`) that generates on demand. Edge-walls removed. |
| 2 | Global arrays `buildings`, `props`, `doorList`, `parkSpots` iterated per frame / per AI tick (`for b of world.buildings` in the renderer) | `render.js`, `game.js`, `ai.js`, `missions.js` | Buildings are registered in a block hash (`bHash`) → `buildingsNear(rect)`, `nearestEnterable`, `randomDoor`, `parkIter`, `poiNear`. Procedural props live **only** in `propHash` (never in `world.props`). |
| 3 | `SpatialHash` key `(cx+64)*4096+(cy+64)` – breaks for negative / large cells; the vehicle/actor hashes never freed empty cells | `util.js` | 15-bit-wrapped integer key; `clear()` now drops empty cells; `dropCells(rect)` for eviction. |
| 4 | Chunk-canvas key `cx*64+cy` (collides for negatives) | `render.js`, `gfx.js` | `chunkKey(cx,cy)`; chunk streaming no longer clamps to `0..NB-1`. |
| 5 | A* allocated `Float32Array(NT²)` and used flat indices | `world.js` | **Windowed A\*** (512×512 tiles around the start) over `tl()` — works anywhere, partial path if the goal is outside the window. |
| 6 | Traffic AI clamps lanes to `0..NB-1`, spawn bounds `WS-200`, lights modulo of negatives | `ai.js`, `world.js` | Clamps removed; `trafficLight` is negative-safe; lights/stop-lines only at junctions with **≥3 arms** (`arms()`), so rural bends have none. |
| 7 | Heat/turf arrays are `NB²` | `world.js` | Outside the core `blockAt` maps to a dummy slot (turf wars stay a Port Meridian feature). |
| 8 | Minimap / world map = one 768² overview bitmap | `ui.js`, `gfx.js` | Overview kept for the core; outside, per-block 16×16 RGBA (`miniRGBA`: exact for loaded blocks, **pure-macro approximation** for the rest). World map = pan/zoom canvas with fog-of-war (explored block set, saved with the game). |
| 9 | Frontier ended in an ocean ring with dead-end roads | `frontier.js` | Arterials continue as bridges through the outer ring → they are the east/south "gateways". |
| 10 | Precision | camera / canvas | Canvas paths are float32: crisp to about ±1 M px (≈ 32 k tiles ≈ 35 min of non-stop driving). No wall exists beyond that, only sub-pixel shimmer — a floating origin is the documented next step (§12). |

Things that did **not** need to change (by design of the original engine): physics/collision (tile + prop-hash based), combat, vehicles, interiors, audio, lighting, missions (anchored in the core), save format (seed + deltas).

## 10. Design — "unique, not generic" (layers of the generator)

The No-Man's-Sky rule applied literally: *every attribute is a pure function of (seed, coordinates)*; hierarchy of scales; authored anchors on a procedural substrate. Layers, from large to small:

1. **Macro fields** (`terra.js`): continents = domain-warped fBm (scale ≈ 720 tiles) + hills (74) → elevation; **rivers** are iso-lines of a third field (width shrinks with altitude); temperature (1150) × moisture (560) → **11 biomes** (ocean, lake, coast, plains, farm, desert, forest, taiga, tundra, marsh, alpine). A sea **moat** surrounds the core's east/south (matching the authored coast) and the authored border biome is **continued outward** with a distance-weighted, jittered blend, so there is no visible seam at the edge of the old map.
2. **Settlement nodes**: one node per 8×8-block macro cell (4 retries to find dry land) → class *none / village / town / city / metro / special*, **theme chosen from the biome** (desert → "Saguaro" identity, coast → "Sol Costa", forest → "Pine Ridge", tundra/alpine → ski-town, marsh → "Bayou", metro → "Aurelia", plains → "Ambrose Valley"), grammar-generated name per theme (Spanish-style desert towns, Nordic alpine towns, "Bayou Landing", "Palm Beach"…), organic noise-perturbed outline, overlapping into conurbations.
3. **Road network**: nodes form a graph (E, S + diagonals); each link is routed over the existing 16-tile block lattice by a **turn-penalised A\*** that sees water (→ **bridges**), mountains and the authored core; routes are memoised, so a block only needs the links of its 5×5 cells. Highways (M.HWY, faster traffic, "Highway 37") connect big nodes; everything else gets themed street names. 42 **gateways** route the authored map's border roads to the nearest node, so the new network is physically joined to the old one. This keeps the traffic AI (lane maths on the lattice, junction turning, lights) working unchanged.
4. **Settlement interiors by grammar** (`terra_gen.js`): the centre block is a landmark (metro: 150-190 px financial tower; city: grand hotel + fountain; town: town hall square; village: green with store & diner); fixed offsets give civic anchors (police, hospital, hotel/galleria, stadium, chapel, park); the rest is urbanity-driven (towers → mid-rise → shop rows → apartments/motel → houses → farms/warehouses). Shops get theme-specific names, houses theme palettes/roofs/yards/fences/parked cars, lamps, crosswalks at real intersections.
5. **Plots (2×2 blocks) for "special" nodes** – the authored-quality set pieces: **private airstrip** (runway, apron, jets, hangar, enterable tower), **army outpost** (fenced concrete compound, barracks, HQ, armory, tank, helipad, watch-towers; district `fortbase` → the existing *restricted area* + soldiers logic fires automatically), **coastal resort** (towers, pool, loungers, supercars), **port** (cranes, container stacks, silos), **quarry** (pit ringed by rock massifs, crusher, trucks). Roads never cross a plot interior.
6. **Wilderness set pieces** (1 block, biome-matched): farmstead, cattle ranch, wind farm, radio mast, open mine, solar array, hermit shack, cabin cluster, campground, lumber mill, stilt shack, lighthouse, beach bar — plus **roadside services** (gas station, diner, motel) beside roads and at empty junction nodes. Mountains are 3×3 massifs on gravel/snow (height from elevation); trees/cacti/rocks are placed in **noisy groves** (copses and clearings) instead of uniform sprinkles.
7. **Systemic hooks reuse the authored systems**: district keys register into the same tables (`DENS`, `TRAFFIC_BY`, `DISTRICT_NAMES`, crowd), so a Prairie town spawns tractors/pickups, a coastal town cabrios/limos, a metro taxis/buses; discoveries (+$25) and map labels work for every generated place; `fortbase` trespass works at every outpost.

## 11. Engineering of the infinite store

* **Unit of generation** = one block (16×16 tiles) or a whole plot. A unit reads **only pure macro functions** (never neighbouring generated data) ⇒ generating a block can never cascade, and the result is bit-identical after eviction (verified: tile/meta probes before and after `evict()` are equal).
* **Streaming** (`World.stream`, called every sim tick): keeps a ring of 5 blocks around the player generated ahead, with a 5 ms budget per frame; synchronous on-demand generation guarantees physics/AI never see a hole (e.g. after fast travel). LRU eviction of whole units when > 1100 blocks (down to 800, never within 10 blocks of the player); building slots become `null`, sprites are LRU-capped, props are dropped from the hash by cell range.
* **Deltas, not worlds**: destroyed props are remembered in a `Set` keyed `blockKey*1024+index`; explored blocks are saved; everything else is re-derived from the seed.
* **Measured** (node, 15 000 simulated player steps ≈ 100 km): average streaming cost **0.08–0.19 ms/frame**, worst spike 12–20 ms (a new road link being routed), ~7.5 props and ~3.9 buildings per generated block, block store plateaus at ≈ 1000 blocks. Works at 1.5 M tiles from the origin. World creation ≈ 270 ms (unchanged) + 26 ms for the gateways.
* **Layout statistics** (4000 random far blocks): ≈ 80 % land / 20 % water, forest 14 %, desert 14 %, alpine 13 %, plains 11 %, tundra 9 %, taiga 7 %, farm 4 %, marsh 4 %; ≈ 9 % of blocks are settlement, ≈ 27 % carry a road. Different seeds give different continents.

## 12. Known limits and next steps

* **Floating origin** for coordinates beyond ±1 M px (canvas float32 jitter; no wall).
* Oceans between continents are crossed by bridges only where the router found a ≤ 10-segment crossing; other islands need the helicopter / swimming (boats are the obvious next feature).
* Missions and turf wars stay anchored in the authored core; quest templates ("steal a jet from the nearest airstrip", "deliver to a farmstead") can now be written against `poiNear`/`randomDoor`.
* Road routing runs on the main thread (≤ 20 ms spike per new link); it is pure and memoised, so it can move to a Web Worker unchanged.
* Hierarchical A\* (chunk graph) for city-to-city NPC travel; wildlife; weather fronts per province (the province name/biome is already computed in `Terra.province`).

## 13. How to try it
Drive or walk out of Port Meridian in any direction (north / west highways, bridges east / south), or use `` ` `` → *Teleport*. Press **M** for the world map (drag to pan, wheel to zoom, fog-of-war shows what you explored), and set a **waypoint** anywhere – the plane has no edge. The main-menu *World seed* now rolls a whole new infinite world.

---

# v5 update — bug fixes, scalable world map, cultural provinces, richer sites, sparse systems, full persistence

## 14. Bugs fixed
| Bug | Root cause | Fix |
|---|---|---|
| **Player invisible after leaving a room (forever)** | v3 syncs `player.inside = g.insideId`. `exitBuilding` then switched off *every* actor with `inside === room id` (to despawn the room's NPCs) — the player included → `player.on = false`, so he was never drawn again. Same pattern in `respawn()`. | `exitBuilding`, `respawn` and `teleport` skip the player, force `player.on = true` / `player.inside = null`, and `stepSim` re-asserts `player.on` while playing (belt and braces). |
| **Cheat menu dead after loading a save** | `loadGame` wrote `world.pois[key] = null` for every discovered procedural place (they were not re-generated yet). `openCheats` sorts `pois` by `.name` → `TypeError` *before* the modal was created, so `` ` `` / F2 did nothing. | Discovered places are now restored from the **Atlas** (see 17), nothing is ever set to `null`, and `openCheats` filters/guards defensively. |
| **Place names missing in "Discovered" sites after reload** | same `null` POIs (the map skipped them). | Atlas persists every name/position/category exactly as generated. |

## 15. World map performance (`worldmap.js`)
* **Macro-tile cache / multi-resolution LOD.** Explored ground is baked into 128×128 px canvases: LOD0 = 8×8 blocks at 1 px/tile, LOD *n* = 4×4 tiles of LOD *n-1* stitched together (8·4ⁿ blocks, up to LOD4 = 2048 blocks). The map picks the LOD whose texel ≈ 1 screen pixel, so zooming out to continental scale costs a few dozen `drawImage` calls instead of one per 16×16 block (before: thousands per frame).
* **Viewport culling** of tiles, labels, overlays; an **explored-tile index** (`World.exploredIdx`, per-LOD counts) lets the map bake only tiles that contain explored blocks and detect stale ones without scanning the explored set.
* **Zoom-aware detail throttling:** draws are coalesced to one per animation frame; turf/heat overlays and small-tier labels are skipped while panning/zooming; baking has a 9 ms/frame budget (tiles pop in progressively, never a frozen frame); LRU cap of 420 tiles.

## 16. Names everywhere (labels with priority tiers + collision culling)
`atlas.js` categorises every place (`metro, city, town, village, district, airport, outpost, port, resort, casino, stadium, industrial, stunt, ghost, quarry, landmark, hospital, police, hotel, mall, park, church, service, rural, shop`) and gives it a **tier** (0 = province … 8 = shop) with a zoom threshold (`TIER_ZOOM`). On the map: provinces are drawn first as big translucent names (own collision layer); everything else is placed greedily by tier with rectangle-overlap culling, so a metropolis always wins over a hospital, and small sites appear (without overlapping) as you zoom in. Markers that lose their label stay as icons.

## 17. Richer, more diverse world
* **9 cultures** (`CULTURES` in `terra_data.js`): Valdric, Marisol, Orlovic, Anglian, Aurelian, Qasari, Hanori, Moana, Tessaro. A province belongs to one culture, independent of biome; the culture drives **syllable-grammar place names** (prefix+middle+suffix tables; provinces too), **street grammar** (`Calle X`, `X Straße`, `Rue X`, `X Dori`, `Via X`…), **highway prefixes** (A12, AP-12, M12, N12, E12, SS12, Route 12), **building palettes / roofs**, **shop names** and a **regional vehicle mix** (dynamic district keys `x_<theme>_<class>_<culture>` feed the existing traffic/density tables; the HUD shows e.g. "Hanori Town").
* **New plot kits** (`terra_sites.js`, 2×2 blocks, biome-matched, placed on the jittered settlement-node positions and forcibly levelled so they always fit; roads route around them): **regional airport** (runway, apron, airliners/jets, *enterable terminal with a working departures desk*, enterable tower, hangar, helipad), **fortress** (walls, corner towers, keep, barracks, armory, tanks — `fortbase` restricted zone → soldiers), **casino resort**, **stadium complex**, **industrial park**, **stunt park** (ramp rings, cones), **ghost town**, **fishing harbor** (quay, piers into the water, cranes, boats). Existing airstrip/outpost/resort/port/quarry are kept; every plot is guaranteed to register a named place.
* **New single-block landmarks:** truck stops (roadside), fire watchtowers, oases, hot springs, geyser fields, ruins, standing stones, orchards, fishing piers, bunkers — chosen per biome.
* **Districts**: cities/metropolises/towns get culture-named districts (e.g. "Kaldheim Altstadt") registered as map sites.

## 18. Infinite core systems
* **Collision-free integer keys** (`keys.js`): `(x+2²⁴)·2²⁵ + (y+2²⁴)` — one safe-integer Number for any |x|,|y| < 16.7 M cells; used by the block store, building hash, chunk cache, spatial hash (`(cx+2²⁵)·2²⁶+(cy+2²⁵)`), explored set and the prop-delta key (`< 2⁵²`). Verified: cells exactly 32768 apart no longer alias (they did with the old 15-bit wrap).
* **Sparse infinite heat** (`World.heatAdd/heatAt/heatDecay`): a `Map` keyed per 512-px block outside the authored core, same API inside. Crimes add local heat; a hot neighbourhood escalates wanted heat faster (+≤60 %) and makes cops harder to shake (+≤50 % evade time); decays 1.5 %/s; drawn on the map.
* **Background road routing** (`road_worker.js`, inlined into the single-file build as a blob worker): `Terra.prefetchRoads` asks the worker for every macro cell within 3 cells of the player (nearest first); results are `Map`s injected into `Terra.cells`. If the player outruns the worker (teleport/flight) the identical pure routine runs synchronously, so generation never sees a hole. Verified bit-identical to the synchronous result; falls back automatically when `Worker` is unavailable.
* **Auto-registered destinations**: every generated city (class ≥ town) and regional airport is added to `World.cities` once (`addDestination`) → cheat teleport list and every flight desk; both lists are sorted **nearest first** with distance and fare.

## 19. Persistence (`persist.js`, `atlas.js`)
Saved in `nt_save_map` (separate from `nt_save`, so a quota problem can never lose the character): **fog-of-war** (run-length encoded rows — thousands of blocks in a few KB; previously the explored set was silently dropped above 40 000 blocks), the **Atlas** (key, name, position, category, fast-travel flag of every place seen), unlocked **destinations**, and **world deltas** (destroyed props). Loading rebuilds a fresh `World` from the seed, re-applies all of it, re-indexes the explored tiles and restores `cities` / flight lists — the exact explored map and names come back. Generation remains a pure function of (seed, coordinates): verified identical tiles/props/POIs across two independent worlds and across evict/regenerate.
