// ===== plane.js — flyable fixed-wing aircraft (v7) =====
// Three aircraft share the helicopter entity list (g.choppers / p.heli) so boarding, camera, HUD, lights, audio, damage and crash handling are common:
//   Sparrow SR-2     — light 4-seat prop plane, forgiving, perfect for learning
//   Cropmaster AT-9  — agile crop-duster biplane: hold FIRE to spray (cosmetic + pays at farms in air jobs)
//   Falcon F-12      — fast jet with nose cannon + missiles
// Flight model (arcade-realistic, top-down 2.5D):
//   • throttle is a persistent lever (W/S, stick up/down)  • speed follows throttle with inertia, climbing bleeds speed, diving gains it
//   • below rotate speed the plane stays on the ground (taxi, steer with wheels)  • above rotate speed ▲ lifts off; ▼ descends
//   • under stall speed lift collapses and the nose drops  • landing needs a gentle sink rate — runways forgive, grass hurts, water/rooftops are fatal
import { T } from './world.js';
import { P } from './fx.js';
import { clamp, rnd, TAU } from './util.js';
import { crime } from './wanted.js';

export const PLANES = {
  sparrow: { n: 'Sparrow SR-2', plane: true, prop: true, hp: 260, vmax: 400, vstall: 118, vrot: 150, turn: 1.25, R: 44, rockets: 0, guns: false, dmgK: 0.5, colors: ['#f2f4f8', '#e8453c', '#2f7bd9', '#f2c230'] },
  cropmaster: { n: 'Cropmaster AT-9', plane: true, prop: true, spray: true, hp: 320, vmax: 340, vstall: 98, vrot: 126, turn: 1.45, R: 46, rockets: 0, guns: false, dmgK: 0.5, colors: ['#f2c230', '#e8eaf0', '#4aa86a'] },
  falcon: { n: 'Falcon F-12 Jet', plane: true, jet: true, hp: 700, vmax: 640, vstall: 205, vrot: 250, turn: 1.7, R: 48, rockets: 12, guns: true, dmgK: 0.25, colors: ['#8a929a', '#3c4a5c', '#b5651d'] },
};

export function aircraftState(def) { return { sp: 0, thr: 0, bank: 0, vz: 0, stall: false, air: false, auto: false, hintT: 8, gearHard: 0, spray: 0 }; }

const PAVED = new Set([T.RUNWAY, T.TARMAC, T.ROAD, T.CONCRETE, T.PLAZA, T.PARKING, T.BRIDGE, T.QUAY]);

export function controlPlane(g, c, dt, H) {
  const p = g.player, inp = g.input, d = c.def, mv = inp.move(), w = g.world;
  g.aiming = false; p.x = c.x; p.y = c.y; p.inside = null;
  const fl = H.floorAt(g, c.x, c.y), air = c.alt > fl + 0.02, tile = w.tileAt(c.x, c.y), paved = PAVED.has(tile);
  c.hintT = Math.max(0, c.hintT - dt);
  // ---- inputs
  const pitch = (inp.down('jump') || inp.down('climb') ? 1 : 0) - (inp.down('sprint') || inp.down('descend') || inp.down('cover') ? 1 : 0);
  const thrIn = -mv.y, wantBrake = inp.down('hbrake') || inp.keys.has('KeyB') || (thrIn < -0.35 && c.thr <= 0.001);
  c.thr = clamp(c.thr + (thrIn > 0.08 ? thrIn : thrIn < -0.08 ? thrIn : 0) * 0.5 * dt, 0, 1);
  if (pitch !== 0 || Math.abs(mv.x) > 0.2) c.auto = false;
  c.rpm += ((0.32 + 0.68 * c.thr) - c.rpm) * Math.min(1, dt * 2.4);
  // ---- speed
  const tgt = d.vmax * c.thr * (1 + c.alt * 0.06), rate = tgt > c.sp ? (d.jet ? 0.75 : 0.55) : air ? 0.22 : 0.6;
  c.sp += (tgt - c.sp) * (1 - Math.exp(-rate * dt));
  if (air) c.sp = clamp(c.sp - pitch * dt * d.vmax * 0.075, 0, d.vmax * 1.25);
  else {
    if (wantBrake) c.sp = Math.max(0, c.sp - d.vmax * 0.9 * dt);
    if (c.thr < 0.03) c.sp = Math.max(0, c.sp - d.vmax * 0.2 * dt);
    if (!paved && tile !== T.WATER) c.sp = Math.max(0, c.sp - d.vmax * 0.16 * dt * (c.sp > d.vrot ? 1 : 0.4));
  }
  // ---- lift
  const lift = clamp((c.sp - d.vstall * 0.85) / (d.vrot - d.vstall * 0.85 + 1), 0, 1);
  let vz;
  if (!air) vz = pitch > 0 && c.sp >= d.vrot * 0.96 ? 0.26 * lift + 0.04 : 0;
  else if (pitch > 0) vz = lift < 0.3 ? -0.12 : 0.3 * lift;
  else if (pitch < 0) vz = -0.4;
  else vz = c.sp < d.vstall ? -((d.vstall - c.sp) / d.vstall) * 0.5 : 0;
  c.stall = air && c.sp < d.vstall * 0.97;
  const vzPrev = c.vz; c.vz += (vz - c.vz) * Math.min(1, dt * 3.5); c.alt += c.vz * dt;
  if (c.alt >= 1) { c.alt = 1; if (c.vz > 0) c.vz = 0; }
  // ---- touchdown / ground contact
  if (c.alt <= fl) {
    if (c.air || air) touchdown(g, c, H, fl, Math.max(0, -Math.min(vzPrev, c.vz)), tile, paved);
    c.alt = fl; c.vz = 0;
  }
  c.air = c.alt > fl + 0.02;
  if (!c.air && tile === T.WATER && fl < 0.1) { c.hp -= 38 * dt; c.sp *= Math.exp(-1.4 * dt); if (Math.random() < 0.3) g.parts.emit(P.WATER, c.x + rnd(-14, 14), c.y + rnd(-10, 10), rnd(-30, 30), rnd(-30, 30), 0.5, 3, '#cfe6ff'); if (c.hp <= 0 && !g.cheats.god) { H.crash(g, c); return; } }
  else if (!c.air && !paved && c.sp > 160 && Math.random() < 0.25) { g.cam.shake = Math.max(g.cam.shake, 1.6); g.parts.emit(P.SMOKE, c.x + rnd(-8, 8), c.y + rnd(-8, 8), rnd(-20, 20), rnd(-20, 20), 0.5, 3, '#a89a78'); }
  // ---- steering
  const ctl = c.air ? clamp(c.sp / (d.vstall * 0.9), 0, 1) * (c.stall ? 0.55 : 1) : clamp(c.sp / 70, 0, 1) * 0.6;
  c.a += mv.x * d.turn * ctl * dt;
  c.bank += ((c.air ? mv.x * ctl : 0) - c.bank) * Math.min(1, dt * 4);
  // auto-level assist (hold LAND): keep nose on the runway heading, throttle back, sink gently
  if (c.auto) { c.thr = Math.max(0.12, c.thr - 0.3 * dt); if (c.air && c.sp > d.vstall * 1.12) c.thr = Math.max(0.1, c.thr - 0.2 * dt); }
  // ---- move (+ collisions with rooftops / ridges at our altitude)
  c.vx = Math.cos(c.a) * c.sp; c.vy = Math.sin(c.a) * c.sp;
  const mx = c.vx * dt, my = c.vy * dt, ca = Math.cos(c.a), sa = Math.sin(c.a);
  if (H.floorAt(g, c.x + mx + ca * 20, c.y + my + sa * 20) > c.alt + 0.03 || H.floorAt(g, c.x + mx - sa * 14, c.y + my + ca * 14) > c.alt + 0.03 && H.floorAt(g, c.x + mx + sa * 14, c.y + my - ca * 14) > c.alt + 0.03) {
    if (c.sp > 60) planeBump(g, c, H); c.sp *= 0.3; c.thr = Math.max(0, c.thr - 0.3);
  } else { c.x += mx; c.y += my; }
  c.tilt += ((c.sp / d.vmax) - c.tilt) * Math.min(1, dt * 4);
  // ---- weapons / spray / exhaust
  c.cool -= 0; if (d.guns && inp.down('fire') && c.cool <= 0 && !g.uiOpen) {
    c.cool = 0.055; c.flash = 0.05; c.mgT++;
    for (const s of [-1, 1]) { const ox = c.x + ca * 34 - sa * s * 9, oy = c.y + sa * 34 + ca * s * 9, aa = c.a + (Math.random() - 0.5) * 0.04; g.bullets.spawn({ x: ox, y: oy, vx: Math.cos(aa) * (2400 + c.sp), vy: Math.sin(aa) * (2400 + c.sp), dmg: 17, owner: p, ownerV: null, fac: 'pl', life: 1000, kind: 'b', rad: 0 }); }
    if (c.mgT % 3 === 0) { g.audio.sfx('smg', c.x, c.y, 0.5); g.noise(c.x, c.y, 900, { by: p }); g.combatT = 6; crime(g, 'shots', c.x, c.y); }
    g.cam.shake = Math.max(g.cam.shake, 1.8);
  }
  if (d.rockets && c.alt >= 0 && (inp.down('rocket') || inp.pressed('aim') || inp.pressed('reload')) && c.rcool <= 0 && !g.uiOpen) {
    if (c.rockets > 0) { c.rockets--; c.rcool = 0.55; const side = c.rockets % 2 ? 1 : -1, ox = c.x + ca * 20 - sa * side * 18, oy = c.y + sa * 20 + ca * side * 18;
      g.bullets.spawn({ x: ox, y: oy, vx: ca * (1000 + c.sp), vy: sa * (1000 + c.sp), dmg: 240, owner: p, ownerV: null, fac: 'pl', life: 1500, kind: 'rk', rad: 120 });
      g.audio.sfx('rocket', c.x, c.y); g.noise(c.x, c.y, 1000, { by: p }); g.combatT = 8; crime(g, 'shots', c.x, c.y); g.cam.shake = Math.max(g.cam.shake, 4); }
    else { g.audio.sfx('empty'); c.rcool = 0.4; }
  }
  if (d.rockets) { c.regen += dt; if (c.regen > 5 && c.rockets < d.rockets) { c.regen = 0; c.rockets++; } }
  if (d.spray && inp.down('fire') && c.alt > 0.02 && c.alt < 0.5) { c.spray += dt; if (Math.random() < 0.9) for (const s of [-1, 1]) g.parts.emit(P.SMOKE, c.x - ca * 20 - sa * s * 38, c.y - sa * 20 + ca * s * 38, -ca * 60 + rnd(-10, 10), -sa * 60 + rnd(-10, 10), 0.9, 5, '#b9f08a'); }
  if (d.jet && c.thr > 0.7 && Math.random() < 0.5) g.parts.emit(P.FIRE, c.x - ca * 44, c.y - sa * 44 - c.alt * 70, -ca * 40, -sa * 40, 0.2, 3, '#ffb040');
  if (c.alt > 0.6 && c.sp > d.vstall * 1.3 && Math.random() < 0.35) for (const s of [-1, 1]) g.parts.emit(P.SMOKE, c.x - ca * 10 - sa * s * d.R * 0.85, c.y - sa * 10 + ca * s * d.R * 0.85 - c.alt * 70, 0, 0, 1.1, 3, '#ffffff');
}
function touchdown(g, c, H, fl, sink, tile, paved) {
  const d = c.def;
  if (fl > 0.1) { c.hp -= 30 + c.sp * 0.4; c.sp *= 0.4; g.cam.shake = 10; g.toast('Rooftop landing! Dangerous.', '#ff9a3c'); g.audio.sfx('crash', c.x, c.y, 0.7); if (c.hp <= 0 && !g.cheats.god) H.crash(g, c); return; }
  if (tile === T.WATER) { if (c.sp > d.vstall * 0.55) { c.hp -= d.hp * 0.5; g.toast('Water impact!', '#ff7788'); g.cam.shake = 12; g.audio.sfx('crash', c.x, c.y, 0.8); if (c.hp <= 0 && !g.cheats.god) H.crash(g, c); } return; }
  const dmg = Math.max(0, sink - 0.34) * 520 + (paved ? 0 : Math.max(0, c.sp - d.vstall * 1.25) * 0.6);
  if (dmg > 4) { c.hp -= dmg; c.hitT = 0.25; g.cam.shake = Math.max(g.cam.shake, 7); g.audio.sfx('crash', c.x, c.y, 0.5); g.toast(dmg > 40 ? 'Crash landing!' : 'Hard landing', '#ff9a3c'); if (c.hp <= 0 && !g.cheats.god) H.crash(g, c); }
  else if (sink > 0.08) { g.parts.burst(P.SMOKE, c.x, c.y, 5, 60, 0.6, 3, '#ddd'); g.audio.sfx('door', c.x, c.y, 0.3); }
  void d;
}
function planeBump(g, c, H) {
  c.hp -= c.sp * 0.55; c.hitT = 0.3; g.cam.shake = Math.max(g.cam.shake, 12); g.audio.sfx('crash', c.x, c.y, 0.9); g.fx.hurt = Math.max(g.fx.hurt, 0.4);
  g.parts.burst(P.SPARK, c.x, c.y, 10, 220, 0.4, 2, '#ffd27a'); g.toast('Collision! Climb higher to clear buildings', '#ff9a3c'); if (c.hp <= 0 && !g.cheats.god) H.crash(g, c);
}
export function planeIdle(g, c, dt, H) {
  const fl = H.floorAt(g, c.x, c.y); c.thr = 0; c.rpm = Math.max(0, c.rpm - dt * 0.6); c.sp = Math.max(0, c.sp - c.def.vmax * 0.5 * dt);
  if (c.alt > fl) { c.alt = Math.max(fl, c.alt - dt * 0.4); c.sp = Math.max(c.sp, 40); } c.vx = Math.cos(c.a) * c.sp; c.vy = Math.sin(c.a) * c.sp;
  if (c.sp > 1) { c.x += c.vx * dt; c.y += c.vy * dt; } c.bank *= Math.exp(-3 * dt); c.tilt *= Math.exp(-2 * dt);
}

// ---------- drawing ----------
export function planeShadow(c, h) {
  const R = h.def.R, a = h.alt, s = 1 - a * 0.25; c.save(); c.translate(h.x + 8 + a * 46, h.y + 10 + a * 74); c.rotate(h.a); c.scale(s, s);
  c.fillStyle = `rgba(0,0,0,${0.3 - a * 0.12})`; c.beginPath(); c.ellipse(0, 0, R * 0.78, h.def.jet ? 6 : 7, 0, 0, TAU); c.fill();
  c.beginPath(); if (h.def.jet) { c.moveTo(8, 0); c.lineTo(-22, -R * 0.85); c.lineTo(-30, -R * 0.85); c.lineTo(-24, 0); c.lineTo(-30, R * 0.85); c.lineTo(-22, R * 0.85); } else { c.rect(-6, -R * 0.98, 15, R * 1.96); c.rect(-R * 0.9, -R * 0.3, 10, R * 0.6); } c.fill(); c.restore();
}
export function drawPlane(g, c, h) {
  const d = h.def, R = d.R, lift = h.alt * 70, sc = 1 + h.alt * 0.2, bank = Math.cos(h.bank * 0.7);
  c.save(); c.translate(h.x, h.y - lift); c.rotate(h.a); c.scale(sc, sc * bank);
  const body = h.color, dark = '#14171c';
  if (d.jet) {
    c.fillStyle = shade(body, -0.18); c.beginPath(); c.moveTo(12, -4); c.lineTo(-22, -R * 0.86); c.lineTo(-33, -R * 0.86); c.lineTo(-27, -4); c.closePath(); c.fill(); c.beginPath(); c.moveTo(12, 4); c.lineTo(-22, R * 0.86); c.lineTo(-33, R * 0.86); c.lineTo(-27, 4); c.closePath(); c.fill();
    c.fillStyle = shade(body, -0.28); for (const s of [-1, 1]) { c.beginPath(); c.moveTo(-30, s * 5); c.lineTo(-42, s * 20); c.lineTo(-47, s * 20); c.lineTo(-42, s * 4); c.closePath(); c.fill(); }
    c.fillStyle = body; c.beginPath(); c.moveTo(52, 0); c.lineTo(30, -4.5); c.lineTo(-30, -6); c.lineTo(-44, -3.5); c.lineTo(-44, 3.5); c.lineTo(-30, 6); c.lineTo(30, 4.5); c.closePath(); c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 1; c.stroke();
    c.fillStyle = dark; c.fillRect(8, -8.5, 14, 3.5); c.fillRect(8, 5, 14, 3.5); c.fillStyle = '#d33'; c.fillRect(-26, -R * 0.86 - 1, 3, 2.4); c.fillStyle = '#2d3'; c.fillRect(-26, R * 0.86 - 1.4, 3, 2.4);
    c.fillStyle = '#1d3a52'; c.beginPath(); c.ellipse(26, 0, 11, 3.3, 0, 0, TAU); c.fill(); c.fillStyle = 'rgba(170,220,255,.5)'; c.beginPath(); c.ellipse(28, -0.9, 6, 1.2, 0, 0, TAU); c.fill();
    c.fillStyle = shade(body, 0.2); c.fillRect(-16, -1, 22, 2);
    if (h.thr > 0.15 || h.rpm > 0.5) { const f = (h.thr > 0.7 ? 14 + Math.random() * 8 : 3 + h.thr * 6); c.fillStyle = 'rgba(255,170,60,.9)'; c.beginPath(); c.moveTo(-44, -2.5); c.lineTo(-44 - f, 0); c.lineTo(-44, 2.5); c.fill(); c.fillStyle = 'rgba(140,200,255,.9)'; c.beginPath(); c.moveTo(-44, -1.2); c.lineTo(-44 - f * 0.5, 0); c.lineTo(-44, 1.2); c.fill(); }
    if (h.flash > 0) { c.fillStyle = '#ffe9a0'; c.beginPath(); c.arc(54, 0, 5, 0, TAU); c.fill(); }
  } else {
    const dbl = !!d.spray, span = R * 0.98, col2 = dbl ? '#e8eaf0' : '#f4f5f8';
    c.fillStyle = shade(body, -0.25); c.fillRect(-40, -13, 9, 26); c.fillRect(-38, -2, 6, 4);                 // tailplane
    c.fillStyle = body; c.beginPath(); c.moveTo(32, 0); c.bezierCurveTo(30, -7, 18, -7.5, 6, -7); c.lineTo(-34, -2.6); c.lineTo(-44, -1.4); c.lineTo(-44, 1.4); c.lineTo(-34, 2.6); c.lineTo(6, 7); c.bezierCurveTo(18, 7.5, 30, 7, 32, 0); c.fill(); c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 1; c.stroke();
    c.fillStyle = col2; c.fillRect(-4, -span, 16, span * 2); c.fillStyle = body; c.fillRect(-4, -span, 16, 7); c.fillRect(-4, span - 7, 16, 7); c.fillStyle = 'rgba(0,0,0,.15)'; c.fillRect(-4, -span, 3, span * 2);
    if (dbl) { c.fillStyle = shade(col2, -0.08); c.fillRect(14, -span * 0.85, 11, span * 1.7); c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 1; for (const s of [-1, 1]) for (const x of [-0.4, -0.7]) { c.beginPath(); c.moveTo(8, s * span * -x); c.lineTo(19, s * span * -x); c.stroke(); } c.fillStyle = '#3a8a4a'; c.fillRect(-14, -5, 12, 10); }
    c.fillStyle = '#26475f'; c.beginPath(); c.ellipse(dbl ? 3 : 8, 0, 7, 4.4, 0, 0, TAU); c.fill(); c.fillStyle = 'rgba(180,225,255,.5)'; c.beginPath(); c.ellipse(dbl ? 4.5 : 10, -1.2, 3.5, 1.4, 0, 0, TAU); c.fill();
    c.fillStyle = dark; c.beginPath(); c.arc(33, 0, 2.6, 0, TAU); c.fill();
    if (h.rpm > 0.3) { c.fillStyle = `rgba(215,225,235,${0.12 + 0.12 * h.rpm})`; c.beginPath(); c.arc(34, 0, 15, 0, TAU); c.fill(); } else { c.strokeStyle = '#111'; c.lineWidth = 3; c.beginPath(); c.moveTo(34, -13); c.lineTo(34, 13); c.stroke(); }
    if (h.rpm > 0.3) { c.strokeStyle = 'rgba(20,22,28,.5)'; c.lineWidth = 2.4; const r = h.rot * 9; c.beginPath(); c.moveTo(34 + Math.cos(r) * 0.8, Math.sin(r) * 14); c.lineTo(34, -Math.sin(r) * 14); c.stroke(); }
  }
  if (h.hitT > 0) { c.fillStyle = `rgba(255,80,60,${h.hitT * 2})`; c.beginPath(); c.ellipse(0, 0, R * 0.6, 9, 0, 0, TAU); c.fill(); }
  const blink = Math.floor(h.strobe * 1.7) % 2 === 0; if (blink) { c.fillStyle = '#fff'; c.beginPath(); c.arc(-44, 0, 2, 0, TAU); c.fill(); }
  c.restore();
}
export function planeLights(g, L, vis, h) {
  const lift = h.alt * 70, ca = Math.cos(h.a), sa = Math.sin(h.a), R = h.def.R;
  if (vis > 0.03 && (h.driver || h.rpm > 0.3)) { const f = 120 + h.alt * 160; L.add(h.x + ca * f, h.y + sa * f, 140 + h.alt * 90, '#fff4d6', 0.8 * Math.min(1, vis + 0.2)); }
  if (Math.floor(h.strobe * 1.7) % 2 === 0) L.add(h.x - ca * 44, h.y - sa * 44 - lift, 44, '#ffffff', 0.5);
  L.add(h.x - sa * R * 0.85, h.y + ca * R * 0.85 - lift, 30, '#ff2a2a', 0.45); L.add(h.x + sa * R * 0.85, h.y - ca * R * 0.85 - lift, 30, '#2aff6a', 0.45);
  if (h.def.jet && h.thr > 0.6) L.add(h.x - ca * 50, h.y - sa * 50 - lift, 60, '#ffa040', 0.6);
}
function shade(hex, k) { const n = parseInt(hex.slice(1), 16), f = (v) => Math.max(0, Math.min(255, Math.round(v + (k < 0 ? v * k : (255 - v) * k)))); return '#' + [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => f(v).toString(16).padStart(2, '0')).join(''); }
