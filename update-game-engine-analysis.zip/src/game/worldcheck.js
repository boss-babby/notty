// ===== worldcheck.js — post-generation audit & self-repair of the authored world (v7) =====
// The nine authored regions are stamped by hand-written generators, so a prop can end up in a lake, a fence inside a wall or a delivery door
// that no one can walk to.  This pass runs once after generation (≈25 ms) and repairs what it finds, deterministically:
//   1. props standing in water / inside buildings are moved to the nearest free tile (or retired)
//   2. parked-car spots, flyable-aircraft spots and key POIs are validated and nudged onto solid, reachable ground
//   3. a flood-fill from the start point builds a land-reachability mask; doors nobody can reach are pruned from the random-destination list
//   4. a compact report is stored in W.audit (shown in the debug overlay / console) so regressions are visible
const AQUATIC = new Set(['boat']);
const BIG = new Set(['airliner', 'jet', 'tank', 'truck', 'tent', 'turbine', 'hay', 'cattle', 'fountain']);

export function auditWorld(W, K) {
  const { T, NT, TS } = K, t0 = performance.now();
  const tiles = W.tiles, rep = { propsMoved: 0, propsRetired: 0, parkDropped: 0, spotsFixed: 0, spotsDropped: 0, poisNudged: 0, doorsPruned: 0, reachPct: 0, ms: 0 };
  const tt = (x, y) => { const tx = Math.floor(x / TS), ty = Math.floor(y / TS); return tx < 0 || ty < 0 || tx >= NT || ty >= NT ? T.WATER : tiles[ty * NT + tx]; };
  const bad = (t) => t === T.WATER || t === T.BUILDING;
  const roomy = (tx, ty) => { for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) { const x = tx + i, y = ty + j; if (x < 0 || y < 0 || x >= NT || y >= NT || bad(tiles[y * NT + x])) return false; } return true; };
  /** nearest tile (spiral) satisfying `ok`, returns pixel centre or null */
  const nearest = (x, y, maxR, ok) => {
    const cx = Math.floor(x / TS), cy = Math.floor(y / TS);
    for (let r = 0; r <= maxR; r++) for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) {
      if (Math.max(Math.abs(i), Math.abs(j)) !== r) continue; const tx = cx + i, ty = cy + j;
      if (tx < 1 || ty < 1 || tx >= NT - 1 || ty >= NT - 1) continue; if (ok(tx, ty)) return { x: tx * TS + TS / 2, y: ty * TS + TS / 2 };
    }
    return null;
  };

  // 1 — props in impossible places
  const n0 = W.props.length;
  for (let i = 0; i < n0; i++) {
    const p = W.props[i]; if (p.dead || AQUATIC.has(p.t)) continue; const t = tt(p.x, p.y);
    if (!bad(t)) continue;
    if (p.t === 'blocker' || p.t === 'fence' || p.t === 'lamp' || p.t === 'sandbag' || p.t === 'shard') { p.dead = true; rep.propsRetired++; continue; }
    const s = BIG.has(p.t) ? nearest(p.x, p.y, 9, (x, y) => roomy(x, y) && W.free(x, y)) : nearest(p.x, p.y, 5, (x, y) => !bad(tiles[y * NT + x]) && W.free(x, y));
    p.dead = true;
    if (s) { W.addProp(p.t, s.x, s.y, { a: p.a, v: p.v }); rep.propsMoved++; } else rep.propsRetired++;
  }
  // 2a — parked cars
  if (W.parkSpots) { const keep = W.parkSpots.filter((s) => !bad(tt(s.x, s.y))); rep.parkDropped = W.parkSpots.length - keep.length; W.parkSpots.length = 0; for (const s of keep) W.parkSpots.push(s); }
  // 2b — flyable aircraft spots: need a clear 3×3 patch
  if (W.aircraftSpots) {
    const keep = [];
    for (const s of W.aircraftSpots) {
      if (roomy(Math.floor(s.x / TS), Math.floor(s.y / TS))) { keep.push(s); continue; }
      const n = nearest(s.x, s.y, 8, (x, y) => roomy(x, y)); if (n) { s.x = n.x; s.y = n.y; keep.push(s); rep.spotsFixed++; } else rep.spotsDropped++;
    }
    W.aircraftSpots.length = 0; for (const s of keep) W.aircraftSpots.push(s);
  }
  // 2c — POIs that sit *inside* a building tile are unreachable: nudge to the nearest open tile (water POIs are intentional: bridges, piers)
  for (const k in W.pois) { const p = W.pois[k]; if (tt(p.x, p.y) !== T.BUILDING) continue; const n = nearest(p.x, p.y, 6, (x, y) => !bad(tiles[y * NT + x])); if (n) { p.x = n.x; p.y = n.y; rep.poisNudged++; } }

  // 3 — reachability on foot (flood fill from the start point; bridges are plain tiles so islands linked by bridges stay connected)
  const N = NT, seen = new Uint8Array(N * N), q = new Int32Array(N * N); let head = 0, tail = 0, cnt = 0, land = 0;
  const s0 = W.pois.start || { x: N * TS / 2, y: N * TS / 2 }; let sx = Math.floor(s0.x / TS), sy = Math.floor(s0.y / TS);
  if (bad(tiles[sy * N + sx])) { const n = nearest(s0.x, s0.y, 12, (x, y) => !bad(tiles[y * N + x])); if (n) { sx = Math.floor(n.x / TS); sy = Math.floor(n.y / TS); } }
  q[tail++] = sy * N + sx; seen[sy * N + sx] = 1;
  while (head < tail) {
    const k = q[head++], x = k % N, y = (k / N) | 0; cnt++;
    if (x > 0 && !seen[k - 1] && !bad(tiles[k - 1])) { seen[k - 1] = 1; q[tail++] = k - 1; }
    if (x < N - 1 && !seen[k + 1] && !bad(tiles[k + 1])) { seen[k + 1] = 1; q[tail++] = k + 1; }
    if (y > 0 && !seen[k - N] && !bad(tiles[k - N])) { seen[k - N] = 1; q[tail++] = k - N; }
    if (y < N - 1 && !seen[k + N] && !bad(tiles[k + N])) { seen[k + N] = 1; q[tail++] = k + N; }
  }
  for (let i = 0; i < N * N; i++) if (!bad(tiles[i])) land++;
  rep.reachPct = Math.round((cnt / Math.max(1, land)) * 1000) / 10;
  W.reach = seen; W.reachable = (x, y) => { const tx = Math.floor(x / TS), ty = Math.floor(y / TS); return tx >= 0 && ty >= 0 && tx < N && ty < N && seen[ty * N + tx] === 1; };
  if (W.doorList) { const before = W.doorList.length, keep = W.doorList.filter((d) => W.reachable(d.x, d.y)); if (keep.length >= before * 0.5) { rep.doorsPruned = before - keep.length; W.doorList.length = 0; for (const d of keep) W.doorList.push(d); } }

  rep.ms = Math.round((performance.now() - t0) * 10) / 10; W.audit = rep; return rep;
}
