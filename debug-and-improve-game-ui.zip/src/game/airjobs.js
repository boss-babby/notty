// ===== airjobs.js — v7 new playstyles: Sky Rings, Air Courier, Heli Medevac and Street Trial =====
// They plug into the existing side-job engine (g.side / g.obj / missionMarkers) so HUD objective, map marker, fail/cancel and payouts behave like taxi & delivery.
//   skyrings    — fly through a procedurally laid ring course (heli or plane). Pays per ring + time bonus.
//   aircourier  — land at one airfield / helipad, load cargo, land at another. Pays by distance.
//   medevac     — helicopter: land beside a distress beacon, pick the patient up, land at a hospital before the clock runs out.
//   streettrial — drive a chain of road checkpoints against the clock in any road vehicle.
// Course layout is a pure function of (seed, start position, heading) — no Math.random — so a refreshed game offers the same course from the same spot.
import { T } from './world.js';
import { hash2 } from './util.js';

const TS = 32, hyp = Math.hypot, TAU = Math.PI * 2;
export const AIR_JOBS = ['skyrings', 'aircourier', 'medevac', 'streettrial'];
const best = () => { try { return JSON.parse(localStorage.getItem('nt_airbest') || '{}'); } catch (e) { return {}; } };
const saveBest = (k, v) => { try { const b = best(); if (!b[k] || v < b[k]) { b[k] = v; localStorage.setItem('nt_airbest', JSON.stringify(b)); return true; } } catch (e) { /* ignore */ } return false; };
const pay = (g, n, msg) => { g.cash += n; g.stats.cashEarned += n; g.toast(msg + ' +$' + n, '#7cff4f'); g.audio.sfx('cash'); };
const rnd = (g, i, salt) => hash2(Math.floor(g.player.x / 8) + i * 17, Math.floor(g.player.y / 8) + salt * 31, (g.world.seed | 0) + 4242);

/** every place an aircraft can be landed deliberately: helipads, plus the runways / strips where aircraft spots exist */
function sites(g) {
  const out = [], seen = new Set();
  for (const p of g.world.props) if (p.t === 'helipad' && !p.dead) { const k = Math.round(p.x / 160) + ',' + Math.round(p.y / 160); if (!seen.has(k)) { seen.add(k); out.push({ x: p.x, y: p.y, name: g.world.areaName(p.x, p.y) + ' helipad', heli: true, r: 70 }); } }
  for (const s of g.world.aircraftSpots || []) if (s.home && !seen.has(s.home)) { seen.add(s.home); out.push({ x: s.x + 180, y: s.y, name: s.home, heli: false, r: 170 }); }
  return out;
}
const inAir = (g) => g.player.heli;

export function startAirJob(g, kind) {
  const p = g.player, c = p.heli, w = g.world;
  if (kind === 'streettrial') {
    if (!p.veh || p.veh.def.shape === 'bus') { g.toast('Get into a car or bike for the street trial.', '#ff7788'); return false; }
    const pts = []; let a = p.veh.a, x = p.x, y = p.y;
    for (let i = 0, tries = 0; pts.length < 8 && tries < 60; tries++, i++) {
      const aa = a + (rnd(g, i, 1) - 0.5) * 1.5, dd = 300 + rnd(g, i, 2) * 220; let found = null;
      for (let k = 0; k < 7 && !found; k++) for (const s of [0, 1, -1]) { const px = x + Math.cos(aa) * dd + s * k * 24 * -Math.sin(aa), py = y + Math.sin(aa) * dd + s * k * 24 * Math.cos(aa); if (w.tileAt(px, py) === T.ROAD) { found = { x: px, y: py }; break; } }
      if (found) { pts.push(found); a = Math.atan2(found.y - y, found.x - x); x = found.x; y = found.y; } else a += 0.7;
    }
    if (pts.length < 4) { g.toast('No clear road here — try another street.', '#ff7788'); return false; }
    let len = 0, px = p.x, py = p.y; for (const q of pts) { len += hyp(q.x - px, q.y - py); px = q.x; py = q.y; }
    g.side = { kind, air: true, pts, i: 0, t: 0, limit: Math.round(len / 210 + 14), len, hp0: p.veh.hp };
    g.toast('Street trial — hit every checkpoint before the clock runs out!', '#4fe0ff'); setObj(g); return true;
  }
  if (!c) {
    const spots = (w.aircraftSpots || []).slice().sort((a, b) => hyp(a.x - p.x, a.y - p.y) - hyp(b.x - p.x, b.y - p.y)), s = spots[0];
    g.toast('You need an aircraft' + (s ? ' — nearest one is marked on your map (' + (s.home || 'airfield') + ')' : ' — spawn one from the cheat menu') + '.', '#ff7788'); if (s) g.waypoint = { x: s.x, y: s.y }; return false;
  }
  if (kind === 'skyrings') {
    const plane = !!c.def.plane, gap = plane ? 640 : 360, R = plane ? 120 : 84, rings = []; let a = c.a, x = c.x, y = c.y;
    for (let i = 0; i < 10; i++) { a += (rnd(g, i, 3) - 0.5) * (plane ? 0.8 : 1.2); x += Math.cos(a) * gap; y += Math.sin(a) * gap; rings.push({ x, y, alt: 0.4 + (i % 3) * 0.12, r: R }); }
    let len = 0, px = c.x, py = c.y; for (const q of rings) { len += hyp(q.x - px, q.y - py); px = q.x; py = q.y; }
    const sp = plane ? c.def.vmax * 0.62 : c.def.vmax * 0.55;
    g.side = { kind, air: true, rings, i: 0, t: 0, limit: Math.round(len / sp * 1.35 + 18), len };
    g.toast('Sky rings — fly through all 10 gates' + (plane ? '. Keep speed up!' : ''), '#4fe0ff'); setObj(g); return true;
  }
  const all = sites(g);
  if (kind === 'aircourier') {
    const near = all.filter((s) => (c.def.plane ? !s.heli : true)).sort((a, b) => hyp(a.x - c.x, a.y - c.y) - hyp(b.x - c.x, b.y - c.y));
    const A = near[0]; if (!A) { g.toast('No airfield found for this aircraft.', '#ff7788'); return false; }
    const far = all.filter((s) => s !== A && (c.def.plane ? !s.heli : true) && hyp(s.x - A.x, s.y - A.y) > 1500).sort((a, b) => hyp(a.x - A.x, a.y - A.y) - hyp(b.x - A.x, b.y - A.y)), B = far[Math.min(far.length - 1, Math.floor(rnd(g, 5, 4) * Math.min(3, far.length)))];
    if (!B) { g.toast('No destination in range.', '#ff7788'); return false; }
    const dist = hyp(B.x - A.x, B.y - A.y), toA = hyp(A.x - c.x, A.y - c.y);
    g.side = { kind, air: true, A, B, stage: 0, t: 0, dist, limit: Math.round(dist / (c.def.vmax * 0.5) * 1.5 + 60 + toA / 250) };
    g.toast('Air courier — land at ' + A.name + ' to load the cargo.', '#4fe0ff'); setObj(g); return true;
  }
  if (kind === 'medevac') {
    if (c.def.plane) { g.toast('Medevac needs a helicopter.', '#ff7788'); return false; }
    let P = null; for (let i = 0; i < 40 && !P; i++) { const aa = rnd(g, i, 6) * TAU, dd = 1100 + rnd(g, i, 7) * 1800, x = c.x + Math.cos(aa) * dd, y = c.y + Math.sin(aa) * dd, tx = Math.floor(x / TS), ty = Math.floor(y / TS); let ok = true; for (let j = -2; j <= 2 && ok; j++) for (let k = -2; k <= 2; k++) { const t = w.tileAt((tx + k) * TS, (ty + j) * TS); if (t === T.WATER || t === T.BUILDING) { ok = false; break; } } if (ok && (!w.reachable || w.reachable(x, y))) P = { x, y }; }
    const hosp = ['hosp', 'sc_hosp', 'au_hosp', 'sag_clinic'].map((k) => w.pois[k]).filter(Boolean).sort((a, b) => hyp(a.x - (P ? P.x : c.x), a.y - (P ? P.y : c.y)) - hyp(b.x - (P ? P.x : c.x), b.y - (P ? P.y : c.y)))[0];
    if (!P || !hosp) { g.toast('No emergency call right now — try again.', '#aaa'); return false; }
    const pad = sites(g).filter((s) => s.heli).sort((a, b) => hyp(a.x - hosp.x, a.y - hosp.y) - hyp(b.x - hosp.x, b.y - hosp.y))[0];
    const dest = { x: hosp.x, y: hosp.y + 70, name: hosp.name, r: 150 };
    g.side = { kind, air: true, P, dest, pad, stage: 0, t: 0, limit: Math.round((hyp(P.x - c.x, P.y - c.y) + hyp(dest.x - P.x, dest.y - P.y)) / (c.def.vmax * 0.5) * 1.5 + 55), hold: 0 };
    g.toast('Medevac — distress beacon marked. Land beside the patient!', '#ff7788'); setObj(g); return true;
  }
  return false;
}

function setObj(g) {
  const S = g.side; if (!S) return; let text = '', pt = null, sub = '';
  const left = Math.max(0, Math.ceil(S.limit - S.t)), cl = left + 's';
  if (S.kind === 'skyrings') { pt = S.rings[S.i]; text = `Fly through ring ${S.i + 1}/${S.rings.length}`; sub = cl; }
  else if (S.kind === 'streettrial') { pt = S.pts[S.i]; text = `Checkpoint ${S.i + 1}/${S.pts.length}`; sub = cl; }
  else if (S.kind === 'aircourier') { pt = S.stage === 0 ? S.A : S.B; text = S.stage === 0 ? 'Land to load cargo: ' + S.A.name : 'Deliver to ' + S.B.name; sub = cl; }
  else if (S.kind === 'medevac') { pt = S.stage === 0 ? S.P : S.dest; text = S.stage === 0 ? 'Land beside the beacon' : 'Patient aboard — land at ' + S.dest.name; sub = cl; }
  if (pt) g.obj = { text, x: pt.x, y: pt.y, sub };
}
const landed = (c) => c && c.alt < 0.1 && (c.def.plane ? c.sp < 45 : Math.hypot(c.vx, c.vy) < 40);

export function updateAirJob(g, S, dt) {
  const p = g.player, c = p.heli; S.t += dt;
  if (p.dead) { g.side = null; g.obj = null; return true; }
  const needsAir = S.kind !== 'streettrial';
  if (needsAir ? !c : !p.veh) { S.off = (S.off || 0) + dt; if (S.off > 25) { g.toast('Job abandoned.', '#ff7788'); g.audio.sfx('fail'); g.side = null; g.obj = null; return true; } } else S.off = 0;
  if (S.t > S.limit) { g.toast('Time is up — job failed.', '#ff7788'); g.audio.sfx('fail'); g.side = null; g.obj = null; return true; }
  if (S.kind === 'skyrings') {
    const r = S.rings[S.i]; if (c && hyp(c.x - r.x, c.y - r.y) < r.r && c.alt > 0.12) {
      S.i++; g.audio.sfx('pickup'); g.toast(`Ring ${S.i}/${S.rings.length}`, '#4fe0ff');
      if (S.i >= S.rings.length) { const bonus = Math.max(0, Math.round((S.limit - S.t) * 6)), key = 'rings' + (c.def.plane ? 'P' : 'H'), nb = saveBest(key, Math.round(S.t * 10) / 10); pay(g, 350 + S.rings.length * 40 + bonus, 'Course complete in ' + S.t.toFixed(1) + 's' + (nb ? ' — new record!' : '')); g.side = null; g.obj = null; return true; }
    }
  } else if (S.kind === 'streettrial') {
    const q = S.pts[S.i]; if (p.veh && hyp(p.x - q.x, p.y - q.y) < 70) {
      S.i++; g.audio.sfx('pickup');
      if (S.i >= S.pts.length) { const bonus = Math.max(0, Math.round((S.limit - S.t) * 8)), dmg = Math.max(0, Math.round((S.hp0 - p.veh.hp) * 0.4)), nb = saveBest('trial', Math.round(S.t * 10) / 10); pay(g, Math.max(150, 300 + bonus - dmg), 'Trial finished in ' + S.t.toFixed(1) + 's' + (nb ? ' — new record!' : '')); g.side = null; g.obj = null; return true; }
    }
  } else if (S.kind === 'aircourier') {
    const tgt = S.stage === 0 ? S.A : S.B;
    if (c && landed(c) && hyp(c.x - tgt.x, c.y - tgt.y) < tgt.r + 40) {
      S.hold = (S.hold || 0) + dt; g.obj && (g.obj.sub = (S.stage ? 'Unloading… ' : 'Loading… ') + Math.max(0, 2 - S.hold).toFixed(1) + 's');
      if (S.hold > 2) { S.hold = 0; if (S.stage === 0) { S.stage = 1; S.t = Math.min(S.t, 5); g.toast('Cargo loaded — take off for ' + S.B.name, '#7cff4f'); g.audio.sfx('pickup'); } else { pay(g, Math.round(300 + S.dist * 0.22 + Math.max(0, S.limit - S.t) * 2), 'Cargo delivered'); g.side = null; g.obj = null; return true; } }
    } else S.hold = 0;
  } else if (S.kind === 'medevac') {
    const tgt = S.stage === 0 ? S.P : S.dest, rr = S.stage === 0 ? 110 : S.dest.r;
    if (c && landed(c) && hyp(c.x - tgt.x, c.y - tgt.y) < rr) {
      S.hold = (S.hold || 0) + dt; g.obj && (g.obj.sub = (S.stage ? 'Handing over… ' : 'Loading patient… ') + Math.max(0, 3 - S.hold).toFixed(1) + 's');
      if (S.hold > 3) { S.hold = 0; if (S.stage === 0) { S.stage = 1; S.t = Math.min(S.t, 8); g.toast('Patient aboard — rush to ' + S.dest.name + '!', '#ff7788'); g.audio.sfx('pickup'); } else { pay(g, Math.round(650 + Math.max(0, S.limit - S.t) * 5), 'Patient saved'); g.side = null; g.obj = null; return true; } }
    } else S.hold = 0;
  }
  setObj(g); return true;
}

/** world-space visuals: gates / beacons.  Called inside the camera transform, after airborne aircraft are drawn. */
export function drawAirJob(g, c) {
  const S = g.side; if (!S || !S.air) return; const t = g.time;
  const ring = (x, y, alt, r, col, a, solid) => { const lift = alt * 70, ry = r * 0.55; c.save(); c.translate(x, y - lift); c.globalAlpha = a; c.strokeStyle = col; c.lineWidth = solid ? 7 : 4; c.shadowColor = col; c.shadowBlur = solid ? 14 : 6; c.beginPath(); c.ellipse(0, 0, r, ry, 0, 0, TAU); c.stroke(); if (solid) { c.setLineDash([10, 12]); c.lineDashOffset = -t * 40; c.lineWidth = 2; c.strokeStyle = '#fff'; c.beginPath(); c.ellipse(0, 0, r * 0.82, ry * 0.82, 0, 0, TAU); c.stroke(); } c.restore(); };
  const beam = (x, y, col) => { c.save(); const gr = c.createLinearGradient(0, y - 360, 0, y); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(1, col); c.globalAlpha = 0.5 + 0.2 * Math.sin(t * 4); c.fillStyle = gr; c.fillRect(x - 5, y - 360, 10, 360); c.globalAlpha = 1; c.strokeStyle = col; c.lineWidth = 3; c.beginPath(); c.ellipse(x, y, 30 + 6 * Math.sin(t * 5), 17, 0, 0, TAU); c.stroke(); c.restore(); };
  if (S.kind === 'skyrings') { for (let i = S.i; i < Math.min(S.rings.length, S.i + 4); i++) { const r = S.rings[i]; ring(r.x, r.y, r.alt, r.r, i === S.i ? '#4fe0ff' : '#ffe14a', i === S.i ? 1 : 0.45 - (i - S.i) * 0.08, i === S.i); } }
  else if (S.kind === 'streettrial') { for (let i = S.i; i < Math.min(S.pts.length, S.i + 3); i++) { const q = S.pts[i]; if (i === S.i) beam(q.x, q.y, '#4fe0ff'); else { c.save(); c.globalAlpha = 0.5; c.strokeStyle = '#ffe14a'; c.lineWidth = 3; c.beginPath(); c.ellipse(q.x, q.y, 28, 16, 0, 0, TAU); c.stroke(); c.restore(); } } }
  else if (S.kind === 'aircourier') { const q = S.stage ? S.B : S.A; beam(q.x, q.y, S.stage ? '#7cff4f' : '#ffe14a'); }
  else if (S.kind === 'medevac') { const q = S.stage ? S.dest : S.P; beam(q.x, q.y, '#ff4f5f'); if (!S.stage) { c.save(); c.fillStyle = '#fff'; c.strokeStyle = '#d22'; c.lineWidth = 2; c.beginPath(); c.arc(S.P.x, S.P.y, 14, 0, TAU); c.fill(); c.stroke(); c.fillStyle = '#d22'; c.fillRect(S.P.x - 8, S.P.y - 2.5, 16, 5); c.fillRect(S.P.x - 2.5, S.P.y - 8, 5, 16); c.restore(); } }
}
