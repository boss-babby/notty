// ===== main.js — bootstrap (mounts the game into a host element; returns a disposer) =====
import { bootGame } from './game.js';

export function boot(root) {
  const host = document.createElement('div'); host.id = 'nt-host'; root.appendChild(host);
  let dead = false, game = null;
  bootGame(host).then((g) => { if (dead) g.destroy(); else game = g; }).catch((e) => { console.error(e); host.innerHTML = '<pre style="color:#f66;padding:20px">Failed to start: ' + String(e && e.message) + '</pre>'; });
  return () => { dead = true; if (game) game.destroy(); host.remove(); };
}
