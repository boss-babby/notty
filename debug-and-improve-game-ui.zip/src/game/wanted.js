// ===== wanted.js — crime registration, stars, search/evade state =====
import { clamp } from './util.js';
export const STAR_T = [0, 15, 45, 90, 150, 230];
export const HEAT = { assault: 6, murder: 18, copHit: 15, copKill: 40, carjack: 12, runover: 9, explosion: 20, shots: 4, theft: 5, vandal: 3, bank: 30 };

export function newWanted() { return { stars: 0, heat: 0, seen: false, seenFrame: false, lx: 0, ly: 0, unseen: 0, evade: 0, flash: 0, busted: 0, god: false }; }

export function starsFromHeat(h) { let s = 0; for (let i = 1; i < STAR_T.length; i++) if (h >= STAR_T[i]) s = i; return s; }

/** register a crime. If `force` is false, someone must have witnessed it (a ped or cop nearby with line of sight) */
export function crime(g, kind, x, y, force = false) {
  if (g.zm) return;
  const W = g.wanted, amt = HEAT[kind] || 5;
  const local = g.world.heatAt(x, y);          // sparse infinite heat: works in every block of the endless world
  g.world.heatAdd(x, y, amt * 0.6);
  g.stats.crimes++;
  let witness = force;
  if (!witness) {
    for (const a of g.actors) {
      if (!a.on || a.dead || a === g.player || a.fac === 'kes' || (a.mis && a.fac !== 'pd')) continue;
      const rr = a.fac === 'pd' ? 520 : 360, dx = a.x - x, dy = a.y - y;
      if (dx * dx + dy * dy < rr * rr && g.world.lineClear(a.x, a.y, x, y)) { witness = true; break; }
    }
  }
  if (!witness) return;
  const before = W.stars; W.heat = Math.max(W.heat, 0) + amt * (1 + Math.min(0.6, local / 150)); // a 'hot' neighbourhood escalates faster
  W.stars = Math.max(W.stars, starsFromHeat(W.heat)); if (W.stars > 5) W.stars = 5;
  if (W.stars > before) { W.unseen = 0; W.flash = 2; g.audio.sfx('beep'); g.toast && g.toast('WANTED LEVEL ' + '★'.repeat(W.stars), '#ff5566'); g.news && g.news('crime', kind); }
  W.lx = g.player.x; W.ly = g.player.y;
}
export function setStars(g, n) {
  const W = g.wanted; W.stars = clamp(n, 0, 5); W.heat = STAR_T[W.stars]; W.unseen = 0; W.evade = 0; W.flash = 2;
  if (!n) { W.seen = false; }
}
export function updateWanted(g, dt) {
  const W = g.wanted, p = g.player;
  if (W.flash > 0) W.flash -= dt;
  if (W.stars === 0) { W.heat = Math.max(0, W.heat - dt * 0.8); W.seen = false; W.evade = 0; return; }
  if (W.seenFrame) { W.seen = true; W.unseen = 0; W.lx = p.x; W.ly = p.y; } else { W.seen = false; W.unseen += dt * (p.veh && g.skillLvl('driving') >= 12 ? 1.4 : 1) * (g.scene ? 3 : 1); }
  W.seenFrame = false;
  const need = (13 + W.stars * 3 * (1 - Math.min(0.5, g.skillLvl('stealth') * 0.06))) * (1 + Math.min(0.5, g.world.heatAt(p.x, p.y) / 220));
  W.evade = clamp(W.unseen / need, 0, 1);
  if (W.unseen >= need) { W.stars--; W.heat = STAR_T[W.stars]; W.unseen = 0; W.flash = 1.5; g.audio.sfx('pickup'); g.toast && g.toast(W.stars ? 'Heat dropping: ' + '★'.repeat(W.stars) : 'WANTED LEVEL CLEARED', '#7cff4f'); }
}
