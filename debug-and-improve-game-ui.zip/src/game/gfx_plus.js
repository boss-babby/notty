// ===== gfx_plus.js — procedural sprites for the v7 props (drawn once into a cached canvas by gfx.propSprite) =====
const TAU = Math.PI * 2;
export function drawPlusProp(c, t, v) {
  switch (t) {
    case 'radar': {
      c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(5, 6, 20, 14, 0, 0, TAU); c.fill();
      c.fillStyle = '#6b7078'; c.beginPath(); c.arc(0, 0, 11, 0, TAU); c.fill(); c.fillStyle = '#3d4249'; c.beginPath(); c.arc(0, 0, 6, 0, TAU); c.fill();
      c.save(); c.rotate(-0.45); c.fillStyle = '#e6e9ee'; c.beginPath(); c.ellipse(5, 0, 22, 9, 0, 0, TAU); c.fill(); c.strokeStyle = '#9aa1ab'; c.lineWidth = 1.2; for (let i = -2; i <= 2; i++) { c.beginPath(); c.moveTo(-14, i * 3.4); c.lineTo(24, i * 3.4); c.stroke(); }
      c.fillStyle = 'rgba(0,0,0,.18)'; c.beginPath(); c.ellipse(1, 0, 17, 6, 0, 0, TAU); c.fill(); c.strokeStyle = '#444a52'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, 0); c.lineTo(-18, 0); c.stroke(); c.fillStyle = '#d33'; c.beginPath(); c.arc(-18, 0, 2, 0, TAU); c.fill(); c.restore(); break;
    }
    case 'container': {
      const col = ['#c0392b', '#2471a3', '#d9962b', '#2e8b57'][v % 4];
      c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(-19, -6, 42, 17); c.fillStyle = col; c.fillRect(-21, -9, 42, 17);
      c.fillStyle = 'rgba(255,255,255,.14)'; c.fillRect(-21, -9, 42, 3); c.strokeStyle = 'rgba(0,0,0,.28)'; c.lineWidth = 1; for (let x = -18; x < 21; x += 4) { c.beginPath(); c.moveTo(x, -8); c.lineTo(x, 7); c.stroke(); }
      c.strokeStyle = 'rgba(0,0,0,.45)'; c.lineWidth = 1.4; c.strokeRect(-21, -9, 42, 17); c.fillStyle = 'rgba(255,255,255,.7)'; c.fillRect(-14, -2, 9, 3); break;
    }
    case 'billboard': {
      const cols = ['#ff4fd8', '#4fe0ff', '#ffe14a', '#7cff4f'], col = cols[v % 4];
      c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(-22, -2, 48, 13); c.fillStyle = '#3a3f48'; c.fillRect(-24, -6, 48, 9);
      c.fillStyle = col; c.fillRect(-22, -5, 44, 5); c.fillStyle = 'rgba(255,255,255,.55)'; c.fillRect(-18, -4, 14, 2); c.fillRect(0, -4, 8, 2); c.fillStyle = '#23262d'; c.fillRect(-14, 3, 3, 5); c.fillRect(11, 3, 3, 5); break;
    }
    case 'busstop': {
      c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(-14, -3, 32, 14); c.fillStyle = '#6fb6d8'; c.fillRect(-16, -8, 32, 12); c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(-16, -8, 32, 3);
      c.strokeStyle = '#2b3a46'; c.lineWidth = 1.5; c.strokeRect(-16, -8, 32, 12); c.fillStyle = '#6d4c2f'; c.fillRect(-10, 6, 20, 4); c.fillStyle = ['#e53935', '#fdd835', '#1e88e5'][v % 3]; c.fillRect(11, -14, 4, 7); break;
    }
    case 'scarecrow': {
      c.fillStyle = 'rgba(0,0,0,.22)'; c.beginPath(); c.ellipse(3, 4, 12, 4, 0, 0, TAU); c.fill(); c.strokeStyle = '#7a5a30'; c.lineWidth = 2.4; c.beginPath(); c.moveTo(-12, 0); c.lineTo(12, 0); c.moveTo(0, -2); c.lineTo(0, 10); c.stroke();
      c.fillStyle = '#c0432f'; c.fillRect(-5, -3, 10, 7); c.fillStyle = '#e8c97a'; c.beginPath(); c.arc(0, -3, 4, 0, TAU); c.fill(); c.fillStyle = '#5b3d1a'; c.beginPath(); c.ellipse(0, -4, 8, 3.2, 0, 0, TAU); c.fill(); break;
    }
    case 'campfire': {
      c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.arc(1, 2, 12, 0, TAU); c.fill(); c.fillStyle = '#7d8187'; for (let i = 0; i < 9; i++) { const a = i * TAU / 9; c.beginPath(); c.arc(Math.cos(a) * 10, Math.sin(a) * 10, 3.2, 0, TAU); c.fill(); }
      c.strokeStyle = '#5a3a1a'; c.lineWidth = 3; c.lineCap = 'round'; c.beginPath(); c.moveTo(-6, -4); c.lineTo(6, 4); c.moveTo(-6, 4); c.lineTo(6, -4); c.stroke();
      c.fillStyle = '#ff7a1a'; c.beginPath(); c.arc(0, 0, 5, 0, TAU); c.fill(); c.fillStyle = '#ffd23a'; c.beginPath(); c.arc(0, 0, 3, 0, TAU); c.fill(); c.fillStyle = '#fff6c8'; c.beginPath(); c.arc(0, 0, 1.4, 0, TAU); c.fill(); break;
    }
    case 'windpump': {
      c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.ellipse(6, 9, 13, 8, 0, 0, TAU); c.fill(); c.strokeStyle = '#6a6f77'; c.lineWidth = 1.5; c.strokeRect(-6, -6, 12, 12); c.beginPath(); c.moveTo(-6, -6); c.lineTo(6, 6); c.moveTo(6, -6); c.lineTo(-6, 6); c.stroke();
      c.strokeStyle = '#b9bec6'; c.lineWidth = 2; for (let i = 0; i < 12; i++) { const a = i * TAU / 12; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(a) * 20, Math.sin(a) * 20); c.stroke(); }
      c.strokeStyle = '#7e848c'; c.lineWidth = 1; c.beginPath(); c.arc(0, 0, 20, 0, TAU); c.stroke(); c.fillStyle = '#d33'; c.beginPath(); c.arc(0, 0, 3, 0, TAU); c.fill(); break;
    }
    case 'picnic': {
      c.fillStyle = 'rgba(0,0,0,.22)'; c.fillRect(-12, -5, 26, 20); c.fillStyle = '#8a5a32'; c.fillRect(-12, -6, 24, 12); c.fillStyle = '#a8703f'; c.fillRect(-12, -6, 24, 3); c.fillStyle = '#6d4c2f'; c.fillRect(-12, -14, 24, 5); c.fillRect(-12, 9, 24, 5);
      c.fillStyle = '#f3efe2'; c.fillRect(-5, -4, 10, 8); c.fillStyle = '#d33'; c.fillRect(-5, -4, 5, 4); c.fillRect(0, 0, 5, 4); break;
    }
    default: return false;
  }
  return true;
}
