// ===== fleetdefs.js — data + pure helpers for the v8 fleet (no imports, so world generation can use it without import cycles) =====
const TAU = Math.PI * 2;
export const FLEET = {
  bulldog: { n: 'Bulldog M-1 Battle Tank', ground: 'tank', hp: 2400, vmax: 175, acc: 150, turn: 1.05, R: 46, len: 88, wid: 50, dmgK: 0.1, cannon: true, mg: true, crush: true, vol: 1.4, zoom: 0.9, colors: ['#4f5a3a', '#8a7a55', '#3c4048'] },
  hornet: { n: 'Hornet APC', ground: 'tank', apc: true, hp: 1100, vmax: 310, acc: 250, turn: 1.7, R: 36, len: 68, wid: 36, dmgK: 0.18, mg: true, crush: true, vol: 1.1, zoom: 0.95, colors: ['#4f5a3a', '#8a7a55', '#cfd2d6'] },
  jetski: { n: 'Wave Runner Jet Ski', ground: 'boat', hull: 'jetski', hp: 150, vmax: 560, acc: 400, turn: 2.8, R: 20, len: 38, wid: 16, grip: 3.2, dmgK: 0.8, exitR: 120, vol: 0.7, colors: ['#ff5a1f', '#1e88e5', '#00c853', '#ffd600'] },
  speedboat: { n: 'Barracuda Speedboat', ground: 'boat', hull: 'speed', hp: 320, vmax: 680, acc: 330, turn: 2.1, R: 36, len: 76, wid: 26, grip: 2.2, dmgK: 0.6, exitR: 150, vol: 1, colors: ['#f5f7fa', '#e53935', '#1e88e5', '#212121'] },
  cruiser: { n: 'Marlin Sea Cruiser', ground: 'boat', hull: 'cruiser', hp: 700, vmax: 390, acc: 170, turn: 1.2, R: 56, len: 118, wid: 40, grip: 1.5, dmgK: 0.4, exitR: 180, vol: 1, zoom: 0.92, colors: ['#f5f7fa', '#fff3e0', '#cfd8dc'] },
  gunboat: { n: 'Sentinel Patrol Gunboat', ground: 'boat', hull: 'gun', hp: 1700, vmax: 450, acc: 170, turn: 1.0, R: 68, len: 142, wid: 44, grip: 1.3, dmgK: 0.2, cannon: true, mg: true, exitR: 220, vol: 1.2, zoom: 0.85, colors: ['#7c8a96', '#5f6b5a', '#3e4650'] },
  freighter: { n: 'Titan Container Ship', ground: 'boat', hull: 'ship', hp: 7000, vmax: 235, acc: 55, turn: 0.38, R: 170, len: 340, wid: 80, grip: 0.9, dmgK: 0.08, crush: true, exitR: 300, vol: 1.6, zoom: 0.6, colors: ['#8e1b1b', '#1d3557', '#2d3a30'] },
  liner: { n: 'Aurora Cruise Liner', ground: 'boat', hull: 'liner', hp: 6000, vmax: 265, acc: 60, turn: 0.42, R: 150, len: 300, wid: 68, grip: 0.95, dmgK: 0.08, crush: true, exitR: 300, vol: 1.5, zoom: 0.62, colors: ['#f3f5f8', '#e8eef7'] },
};

export function hullPoints(def, x, y, a, margin = 0) {
  const L = def.len, Wd = def.wid, ca = Math.cos(a), sa = Math.sin(a), pts = [], n = Math.max(2, Math.round(L / 36));
  for (let i = 0; i <= n; i++) { const o = (i / n - 0.5) * L; pts.push([x + ca * o, y + sa * o]); }
  const hw = Wd / 2 + margin;
  for (const o of [-0.38, 0, 0.38, 0.5]) for (const s of [-1, 1]) pts.push([x + ca * o * L - sa * s * hw, y + sa * o * L + ca * s * hw]);
  return pts;
}

export function genFleet(W, K) {
  const { T, TS, NT, mulberry32 } = K, tiles = W.tiles, rng = mulberry32(((W.seed || 1337) * 40503 + 71) >>> 0), INF = 60;
  const dl = new Uint8Array(NT * NT); for (let i = 0; i < NT * NT; i++) dl[i] = tiles[i] === T.WATER ? INF : 0;
  for (let y = 0; y < NT; y++) for (let x = 0; x < NT; x++) { const i = y * NT + x; if (!dl[i]) continue; let v = dl[i]; if (x > 0) v = Math.min(v, dl[i - 1] + 1); if (y > 0) v = Math.min(v, dl[i - NT] + 1); dl[i] = v; }
  for (let y = NT - 1; y >= 0; y--) for (let x = NT - 1; x >= 0; x--) { const i = y * NT + x; if (!dl[i]) continue; let v = dl[i]; if (x < NT - 1) v = Math.min(v, dl[i + 1] + 1); if (y < NT - 1) v = Math.min(v, dl[i + NT] + 1); dl[i] = v; }
  W.landDist = dl;
  const spots = (W.aircraftSpots || (W.aircraftSpots = [])), placed = [];
  const clearAt = (x, y) => { const tx = Math.floor(x / TS), ty = Math.floor(y / TS); return tx < 0 || ty < 0 || tx >= NT || ty >= NT ? 0 : dl[ty * NT + tx]; };
  const fits = (def, x, y, a) => { for (const [px, py] of hullPoints(def, x, y, a, 0)) if (clearAt(px, py) * TS < def.wid / 2 + 26) return false; return true; };
  const place = (kind, ax, ay, minD, maxD, home) => {
    const def = FLEET[kind];
    for (let r = minD; r <= maxD; r += 48) for (let k = 0; k < 24; k++) {
      const ang = rng() * TAU, x = ax + Math.cos(ang) * r, y = ay + Math.sin(ang) * r; if (placed.some(([px, py]) => Math.hypot(px - x, py - y) < Math.max(150, def.len * 0.9))) continue;
      if (clearAt(x, y) < 2) continue;
      for (let h = 0; h < 8; h++) { const ha = rng() * TAU; if (fits(def, x, y, ha)) { placed.push([x, y]); spots.push({ kind, x, y, a: ha, home, noFix: true, col: undefined }); return true; } }
    }
    return false;
  };
  const anchors = [['start', 'Harbor Road'], ['pier', 'Sunset Pier'], ['cranes', 'Meridian Docks']];
  for (const [key, home] of anchors) {
    const o = W.pois[key]; if (!o) continue;
    const mix = key === 'start' ? ['speedboat', 'speedboat', 'jetski', 'jetski', 'cruiser', 'gunboat', 'freighter', 'liner'] : key === 'pier' ? ['speedboat', 'cruiser', 'jetski'] : ['freighter', 'speedboat', 'gunboat'];
    for (const kind of mix) place(kind, o.x, o.y, 90, FLEET[kind].len > 200 ? 2600 : 1600, home);
  }
  let n = 0; for (const key of Object.keys(W.pois)) { if (n >= 24) break; if (!/^c_/.test(key) || /^c_ap/.test(key)) continue; const o = W.pois[key]; if (place(rng() < 0.5 ? 'speedboat' : 'jetski', o.x, o.y, 120, 1500, o.name)) { n++; if (rng() < 0.4) place('cruiser', o.x, o.y, 200, 1700, o.name); } }
  // open sea: a couple of ships and gunboats scattered along the coast
  for (let i = 0; i < 40 && placed.length < 60; i++) { const tx = 8 + Math.floor(rng() * (NT - 16)), ty = 8 + Math.floor(rng() * (NT - 16)); if (dl[ty * NT + tx] < 4 || dl[ty * NT + tx] > 14) continue; const kind = ['freighter', 'liner', 'gunboat', 'cruiser', 'speedboat'][Math.floor(rng() * 5)]; place(kind, tx * TS, ty * TS, 0, 40, 'Open Sea'); }
  W.fleetStats = { boats: spots.filter((s) => FLEET[s.kind] && FLEET[s.kind].hull).length };
}
