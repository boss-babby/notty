// ===== regions.js — the 8 new regions that surround Port Meridian (one continuous 18,432 px world) =====
// World = 3×3 super-regions of 12×12 blocks (192×192 tiles each). Region (0,0) is the original Port Meridian.
//   (1,0) Sol Costa (beach city)   (2,0) Fort Granite army base + highlands
//   (0,1) Saguaro Springs (desert) (1,1) Aurelia (mega-city)        (2,1) Skyline International Airport
//   (0,2) Pine Ridge (forest/lake) (1,2) Ambrose Valley (farms)     (2,2) Bayou Rouge swamp + the Keys
// Everything is generated from the world seed with hash functions, so any block can be rebuilt on its own —
// the same trick an infinite generator would use (see ANALYSIS.md).
import { shade } from './util.js';
const fSpot = (W, kind, x, y, a, home) => (W.aircraftSpots || (W.aircraftSpots = [])).push({ kind, x, y, a, home, noFix: true });
const BOATK = ['speedboat', 'cruiser', 'jetski', 'speedboat'];
const boatSpot = (W, x, y, o = {}) => fSpot(W, BOATK[(o.v || 0) % 4], x, y, o.a || 0, 'Marina');

export const REGKEY = ['suburbs', 'solcosta', 'fort', 'saguaro', 'aurelia', 'airport', 'pine', 'valley', 'bayou'];
export const REGION_NAMES = { solcosta: 'Sol Costa', fort: 'Fort Granite', saguaro: 'Saguaro Springs', aurelia: 'Aurelia', airport: 'Skyline Airport', pine: 'Pine Ridge', valley: 'Ambrose Valley', bayou: 'Bayou Rouge' };
export function regionOf(bx, by) { if (bx >= 36 || by >= 36) return 'frontier'; const rx = Math.min(2, Math.floor(bx / 12)), ry = Math.min(2, Math.floor(by / 12)); return REGKEY[ry * 3 + rx]; }

const NEONS = ['#ff4fd8', '#4fe0ff', '#ffe14a', '#7cff4f', '#ff6a3d', '#b36bff'];
const PAL = {
  pastel: ['#e8a6b8', '#9fd8d0', '#f2d28b', '#a8c5e8', '#d8b4e8', '#f5b895'],
  glass: ['#3a5a7a', '#2f6b7a', '#4a5a8a', '#5a6a7a', '#2c4a6a', '#6a7a8a', '#4b6a8a'],
  west: ['#b98a5a', '#c9a26a', '#a7774a', '#d3b27a', '#c08a6a'],
  mil: ['#5a6248', '#4f5a3f', '#6b6f58', '#58604a'],
  log: ['#7a5230', '#8a6038', '#6a4528', '#935f38'],
  mesa: ['#a8573a', '#b9694a', '#9b4a30', '#c07a50'],
  rock: ['#6b6358', '#756c60', '#5f5850', '#7a7065'],
  swamp: ['#6a7a5a', '#8a7a5a', '#5a6a4a', '#7a6a50'],
  house: ['#c9b79c', '#a7b8c9', '#c9a7a7', '#b5c9a7', '#d9d0b0'],
  roofs: ['#7a4b3a', '#4a5a6a', '#5a3f3a', '#3f4a3a'],
  ind: ['#6b6f73', '#7a6f5c', '#5f6b73', '#70655a'],
};
const NAMES = {
  bar: ['SALTY DOG', 'THE GATOR', 'LAST RESORT', 'TIKI HUT', 'BLUE AGAVE', 'RED DOOR'],
  burger: ['SUNNY DINER', 'DUSTY DINER', 'CAJUN KITCHEN', 'BEACH BITES', 'ROUTE DINER', 'TACO LOCO'],
  mart: ['QUIK-E', 'GENERAL STORE', 'BAIT & TACKLE', 'PLAZA MARKET', 'PRONTO MART'],
  clothes: ['SOL WEAR', 'BOOT BARN', 'URBAN CUT', 'SWIMSUIT CO', 'VOODOO & CO'],
  gun: ['GUN DEN', 'BIG IRON', 'LEAD & BRASS'],
};

export function genRegions(W, K) {
  const { T, M, TS, NT, N0, NB, mulberry32, hash2 } = K;
  const tiles = W.tiles, meta = W.meta, rng = mulberry32(W.seed + 4242);
  const R = (a, b) => a + Math.floor(rng() * (b - a + 1)), P = (a) => a[Math.floor(rng() * a.length)], rn = () => rng();
  const WEDGE = (K.NT0 || NT) - 16;
  const k = (x, y) => (x < 0 || y < 0 || x >= NT || y >= NT ? -1 : y * NT + x);
  const put = (x, y, w, h, t) => { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const q = k(x + i, y + j); if (q >= 0) tiles[q] = t; } };
  const FREE = new Set([T.GRASS, T.DIRT, T.DESERT, T.FOREST, T.GRAVEL, T.SAND, T.FARM, T.SNOW, T.TURF, T.CONCRETE, T.PLAZA, T.PARKING, T.SIDEWALK, T.TARMAC]);
  const can = (x, y, w, h) => { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const q = k(x + i, y + j); if (q < 0 || !FREE.has(tiles[q])) return false; } return true; };
  const B = (x, y, w, h, o = {}) => (can(x, y, w, h) ? W.addBuilding(x, y, w, h, o) : null);
  W.discList = W.discList || [];
  const door = (key, b, name, disc = true) => { if (!b || !b.door) return; W.poi(key, b.door.x, b.door.y, name); if (disc) W.discList.push(key); };
  const zone = (key, x0, y0, x1, y1) => W.zones.push({ key, x0: x0 * TS, y0: y0 * TS, x1: x1 * TS, y1: y1 * TS });
  const city = (key, name, tx, ty) => { W.cities.push({ key, name, x: tx * TS, y: ty * TS }); W.poi('c_' + key, tx * TS, ty * TS, name); W.discList.push('c_' + key); };
  const shop = (x, y, w, h, kind, d, o = {}) => B(x, y, w, h, { kind: 'shop', hgt: o.hgt || 22, color: o.color || P(PAL.pastel), interior: kind, name: P(NAMES[kind.replace('shop_', '')] || NAMES.mart), neon: P(NEONS), ...o });
  const house = (x, y, w, h, pal = PAL.house, o = {}) => B(x, y, w, h, { kind: 'house', hgt: R(12, 18), color: P(pal), roof: P(PAL.roofs), door: true, interior: 'house', ...o });
  const sprinkle = (x0, y0, w, h, type, thr, ok, cell = 2, salt = 1) => {
    for (let cy = 0; cy < h; cy += cell) for (let cx = 0; cx < w; cx += cell) {
      const tx = x0 + cx, ty = y0 + cy; if (hash2(tx, ty, salt + 31) < thr || tx >= WEDGE - 5 || ty >= WEDGE - 5) continue;
      const px = tx + Math.floor(hash2(tx, ty, salt + 7) * cell), py = ty + Math.floor(hash2(tx, ty, salt + 9) * cell), q = k(px, py);
      if (q < 0 || !ok.has(tiles[q]) || W.nearSolid(px, py)) continue;
      W.addProp(type, px * TS + 4 + hash2(px, py, salt + 3) * 24, py * TS + 4 + hash2(px, py, salt + 5) * 24);
    }
  };
  const massif = (x, y, w, h, o = {}) => {
    const cols = o.cols || PAL.rock, minH = o.minH || 50, maxH = o.maxH || 130, snow = o.snow || 9999, cx = x + w / 2, cy = y + h / 2, n = Math.floor((w * h) / 9);
    for (let t = 0; t < n * 4; t++) {
      const rw = R(3, 7), rh = R(3, 6), rx = x + R(0, Math.max(0, w - rw)), ry = y + R(0, Math.max(0, h - rh));
      if (!can(rx, ry, rw, rh)) continue;
      const d = Math.min(1, Math.hypot((rx + rw / 2 - cx) / (w / 2), (ry + rh / 2 - cy) / (h / 2))), hgt = Math.round(minH + (maxH - minH) * Math.pow(1 - d, 0.8) * (0.7 + rn() * 0.5));
      W.addBuilding(rx, ry, rw, rh, { kind: 'mountain', hgt, color: P(cols), roof: hgt > snow ? '#e9eff3' : shade(P(cols), 0.1 + (hgt / maxH) * 0.25), windows: false });
    }
  };
  const plane = (tx, ty, ang, type = 'airliner') => {
    const v = R(0, 3), kind = type === 'airliner' ? (v === 2 ? 'jumbo' : v === 3 ? 'atlas' : 'airliner') : 'falcon';
    fSpot(W, kind, tx * TS, ty * TS, ang);   // v8: apron aircraft are real, flyable planes (see heli.js aircraft spots)
  };
  const ringWalk = (bx, by) => { for (let i = 4; i < 16; i++) for (const [x, y] of [[bx * 16 + i, by * 16 + 4], [bx * 16 + i, by * 16 + 15], [bx * 16 + 4, by * 16 + i], [bx * 16 + 15, by * 16 + i]]) { const q = k(x, y); if (q >= 0 && tiles[q] !== T.ROAD && tiles[q] !== T.BRIDGE && tiles[q] !== T.WATER) tiles[q] = T.SIDEWALK; } };
  // ---------------- base terrain + roads ----------------
  const base = (rx, ry, terr, vR, hR, ring) => {
    for (let ty = ry * N0; ty < (ry + 1) * N0; ty++) for (let tx = rx * N0; tx < (rx + 1) * N0; tx++) {
      const lx = tx & 15, ly = ty & 15, bx = tx >> 4, by = ty >> 4, q = ty * NT + tx;
      let t = typeof terr === 'function' ? terr(tx, ty) : terr, m = 0;
      const inV = lx < 4 && vR(bx, by), inH = ly < 4 && hR(bx, by);
      if (inV || inH) { t = T.ROAD; if (inV) m |= M.V; if (inH) { m |= M.H; if (by % 12 === 0) m |= M.HWY; } }
      else if (ring && (lx === 4 || lx === 15 || ly === 4 || ly === 15)) t = T.SIDEWALK;
      tiles[q] = t; meta[q] = m;
    }
  };
  const crosswalks = (rx, ry) => { for (let cy = ry * 12; cy < ry * 12 + 12; cy++) for (let cx = rx * 12; cx < rx * 12 + 12; cx++) { const x0 = cx * 16, y0 = cy * 16; for (let i = 0; i < 4; i++) { W.xw(x0 + i, y0 + 4, M.V); W.xw(x0 + i, y0 - 1, M.V); W.xw(x0 + 4, y0 + i, M.H); W.xw(x0 - 1, y0 + i, M.H); } } };
  const lamps = (rx, ry) => {
    for (let by = ry * 12; by < ry * 12 + 12; by++) for (let bx = rx * 12; bx < rx * 12 + 12; bx++) {
      const a = bx * 16 + 4, b = bx * 16 + 15, c = by * 16 + 4, d = by * 16 + 15;
      const L = (tx, ty) => { const q = k(tx, ty); if (q >= 0 && tiles[q] === T.SIDEWALK) W.propAtTile('lamp', tx, ty); };
      L(a, c); L(b, c); L(a, d); L(b, d); L(a + 5, c); L(a + 5, d); L(a, c + 5); L(b, c + 5);
      if (rn() < 0.5) { const tx = a + 2 + Math.floor(rn() * 8), q = k(tx, c); if (q >= 0 && tiles[q] === T.SIDEWALK) W.propAtTile(rn() < 0.5 ? 'hydrant' : 'bin', tx, c); }
    }
  };
  const blocks = (rx, ry, fn) => { for (let ly = 0; ly < 12; ly++) for (let lx = 0; lx < 12; lx++) { const bx = rx * 12 + lx, by = ry * 12 + ly; fn({ bx, by, lx, ly, x0: bx * 16 + 5, y0: by * 16 + 5 }); } };
  const park = (x0, y0, w, h, tree = 'tree') => { put(x0, y0, w, h, T.GRASS); for (let i = 0; i < w; i++) put(x0 + i, y0 + (h >> 1), 1, 1, T.PATH); for (let j = 0; j < h; j++) put(x0 + (w >> 1), y0 + j, 1, 1, T.PATH); W.addProp('fountain', (x0 + (w >> 1) + 0.5) * TS, (y0 + (h >> 1) + 0.5) * TS); W.scatter(tree, 12, x0, y0, w, h, rng); W.scatter('bench', 4, x0, y0, w, h, rng); };
  const lot = (x, y, w, h, o = {}) => { put(x, y, w, h, T.PARKING); for (let j = 0; j < h - 1; j += 3) for (let i = 0; i < w - 1; i += 2) W.parkSpots.push({ x: (x + i + 1) * TS, y: (y + j + 1.2) * TS, a: Math.PI / 2, ...o }); };
  const fence = (x0, y0, x1, y1, gate) => W.fenceLine(x0 * TS, y0 * TS, x1 * TS, y1 * TS, gate);

  // ============ (1,0) SOL COSTA — neon pastel beach city ============
  (() => {
    const rx = 1, ry = 0;
    base(rx, ry, (x, y) => (hash2(x >> 2, y >> 2, 7) > 0.78 ? T.GRASS : T.SAND), () => true, () => true, true);
    crosswalks(rx, ry); lamps(rx, ry);
    blocks(rx, ry, ({ lx, ly, x0, y0, bx, by }) => {
      const key = lx + ',' + ly; W.turf[bx * NB + by] = lx > 4 && ly > 3 ? 'sun' : '';
      switch (key) {
        case '5,5': { put(x0, y0, 10, 10, T.PLAZA); const b = B(x0 + 1, y0 + 1, 8, 6, { kind: 'tower', hgt: 100, color: '#e8a6b8', roof: '#fbe3ea', interior: 'hotel', name: 'SOL TOWER HOTEL', neon: '#ff4fd8' }); door('sc_tower', b, 'Sol Tower Hotel'); W.scatter('palm', 4, x0, y0 + 7, 10, 3, rng); city('solcosta', 'Sol Costa', x0 + 5, y0 + 8.4); break; }
        case '3,3': { put(x0, y0, 10, 10, T.PLAZA); const b = B(x0, y0 + 1, 10, 6, { kind: 'civic', hgt: 34, color: '#9fd8d0', roof: '#d8f1ee', interior: 'mall', name: 'COSTA GALLERIA MALL', neon: '#4fe0ff' }); door('sc_mall', b, 'Costa Galleria Mall'); lot(x0, y0 + 8, 10, 2); break; }
        case '8,2': { put(x0, y0, 10, 10, T.GRASS); const m1 = B(x0, y0 + 1, 4, 4, { kind: 'house', hgt: 26, color: '#fff2e0', roof: '#c26a4a', interior: 'mansion', door: true, name: 'VILLA MIRAMAR', neon: '#ffd24a' }); B(x0 + 6, y0 + 1, 4, 4, { kind: 'house', hgt: 26, color: '#f5e1ee', roof: '#8a4a6a', interior: 'mansion', door: true, name: 'VILLA ROSA', neon: '#ff4fd8' }); door('sc_mansion', m1, 'Villa Miramar'); put(x0 + 4, y0 + 6, 2, 4, T.PATH); W.scatter('palm', 6, x0, y0, 10, 10, rng); W.scatter('hedge', 6, x0, y0 + 5, 10, 5, rng); W.parkSpots.push({ x: (x0 + 2) * TS, y: (y0 + 6) * TS, a: Math.PI / 2, type: 'supercar' }); break; }
        case '2,7': { put(x0, y0, 10, 10, T.WATER); put(x0, y0, 10, 2, T.WOOD); put(x0, y0 + 8, 10, 2, T.WOOD); put(x0 + 4, y0, 2, 10, T.WOOD); boatSpot(W, (x0 + 2) * TS, (y0 + 4) * TS, { a: Math.PI / 2, v: 0 }); boatSpot(W, (x0 + 8) * TS, (y0 + 5) * TS, { a: Math.PI / 2, v: 1 }); boatSpot(W, (x0 + 2.5) * TS, (y0 + 7) * TS, { a: Math.PI / 2, v: 2 }); W.poi('sc_marina', (x0 + 5) * TS, (y0 + 1) * TS, 'Costa Marina'); W.discList.push('sc_marina'); break; }
        case '9,7': { put(x0, y0, 10, 10, T.PLAZA); const b = B(x0 + 1, y0 + 1, 8, 5, { kind: 'shop', hgt: 24, color: '#2a1f4a', interior: 'nightclub', name: 'CLUB ELECTRA', neon: '#ff4fd8' }); door('sc_club', b, 'Club Electra'); W.scatter('palm', 4, x0, y0 + 6, 10, 4, rng); break; }
        case '6,8': { put(x0, y0, 10, 10, T.GRASS); B(x0, y0, 10, 9, { kind: 'stadium', hgt: 40, color: '#c8ccd2', roof: '#3f8f46', name: 'COSTA ARENA', neon: '#ffe14a', windows: false }); W.poi('sc_stadium', (x0 + 5) * TS, (y0 + 10) * TS, 'Costa Arena'); W.discList.push('sc_stadium'); break; }
        case '4,2': { const b = B(x0 + 1, y0 + 1, 8, 6, { kind: 'civic', hgt: 34, color: '#2a3f6b', interior: 'police', name: 'SCPD PRECINCT', neon: '#4aa8ff' }); door('sc_police', b, 'Sol Costa PD'); W.parkSpots.push({ x: (x0 + 2) * TS, y: (y0 + 8.5) * TS, a: 0, cop: 1 }, { x: (x0 + 7) * TS, y: (y0 + 8.5) * TS, a: 0, cop: 1 }); break; }
        case '9,4': { const b = B(x0 + 1, y0 + 1, 8, 6, { kind: 'civic', hgt: 34, color: '#e3e8ee', roof: '#f3f6fa', interior: 'hospital', name: 'COSTA MEDICAL', neon: '#ff4f6a' }); door('sc_hosp', b, 'Costa Medical'); break; }
        case '1,1': { put(x0, y0, 10, 10, T.SAND); const b = B(x0 + 1, y0 + 1, 6, 4, { kind: 'shop', hgt: 20, color: '#f2d28b', interior: 'bar', name: 'TIKI BEACH CLUB', neon: '#ff9a3c' }); door('sc_tiki', b, 'Tiki Beach Club', false); W.scatter('umbrella', 6, x0, y0 + 5, 10, 5, rng, (t) => t === T.SAND); W.scatter('lounger', 6, x0, y0 + 5, 10, 5, rng); W.scatter('palm', 5, x0, y0, 10, 10, rng); break; }
        default: {
          const r = rn();
          if (r < 0.14) park(x0, y0, 10, 10, 'palm');
          else if (r < 0.44) { put(x0, y0, 10, 10, T.PLAZA); B(x0 + 1, y0 + 1, 8, 8, { kind: 'tower', hgt: R(46, 82), color: P(PAL.pastel), roof: '#fff1f5', neon: P(NEONS), interior: rn() < 0.5 ? 'hotel' : null, name: rn() < 0.5 ? P(['PALMS RESORT', 'AZURE SUITES', 'CORAL TOWERS', 'MIAMAR LOFTS']) : '' }); }
          else { put(x0, y0, 10, 10, rn() < 0.5 ? T.PLAZA : T.SAND); shop(x0, y0, 5, 4, P(['bar', 'shop_burger', 'shop_clothes', 'shop_mart'])); shop(x0 + 5, y0, 5, 4, P(['bar', 'shop_burger', 'shop_clothes'])); B(x0, y0 + 5, 6, 5, { kind: 'tower', hgt: R(34, 56), color: P(PAL.pastel), neon: P(NEONS) }); shop(x0 + 6, y0 + 5, 4, 5, P(['shop_clothes', 'shop_mart', 'bar']), 'beach', { hgt: 26 }); W.scatter('palm', 4, x0, y0 + 4, 10, 1, rng); }
        }
      }
    });
  })();

  // ============ (2,0) FORT GRANITE — army camp + highlands ============
  (() => {
    const rx = 2, ry = 0;
    base(rx, ry, (x, y) => (hash2(x >> 2, y >> 2, 11) > 0.55 ? T.GRASS : T.DIRT), (bx) => bx % 12 === 0 || bx === 30, (bx, by) => by === 0 || by === 6, false);
    const fx = 420, fy = 10, fw = 56, fh = 80;
    put(fx, fy, fw, fh, T.CONCRETE); put(fx + 2, fy + 2, fw - 4, 6, T.GRAVEL);
    put(460, 130, 18, 14, T.GRAVEL); W.poi('quarry', 469 * TS, 137 * TS, 'Granite Quarry');
    put(390, 60, 24, 20, T.GRAVEL); for (let i = 0; i < 7; i++) W.addProp('crate', (392 + i * 3.2) * TS, 62 * TS); W.poi('fort_range', (402) * TS, 74 * TS, 'Firing Range');
    zone('fortbase', fx - 2, fy - 2, fx + fw + 2, fy + fh + 2);
    const gate = (x, y) => y > (fy + fh) * TS - 6 && x > (fx + 26) * TS && x < (fx + 31) * TS;
    fence(fx, fy, fx + fw, fy); fence(fx, fy, fx, fy + fh); fence(fx + fw, fy, fx + fw, fy + fh); fence(fx, fy + fh, fx + fw, fy + fh, gate);
    put(fx + 26, fy + fh, 5, 6, T.ROAD); for (let j = 0; j < 6; j++) for (let i = 0; i < 5; i++) meta[k(fx + 26 + i, fy + fh + j)] = M.V;
    const hq = B(fx + 20, fy + 8, 16, 7, { kind: 'civic', hgt: 34, color: '#5a6248', roof: '#6b7358', interior: 'hq', name: 'FORT GRANITE HQ', neon: '#7cff4f' }); door('fort_hq', hq, 'Fort Granite HQ');
    const arm = B(fx + 38, fy + 20, 10, 5, { kind: 'warehouse', hgt: 22, color: '#4f5a3f', interior: 'shop_armory', name: 'ARMORY', neon: '#ff3b5c' }); door('fort_armory', arm, 'Fort Armory');
    for (let i = 0; i < 4; i++) { const b = B(fx + 4 + (i % 2) * 14, fy + 20 + Math.floor(i / 2) * 9, 11, 4, { kind: 'warehouse', hgt: 18, color: P(PAL.mil), interior: 'barracks', door: true, name: 'BARRACKS ' + (i + 1), neon: null }); if (i === 0) door('fort_barracks', b, 'Barracks'); }
    for (const [tx, ty] of [[fx + 6, fy + 44], [fx + fw - 9, fy + 44], [fx + 3, fy + fh - 5], [fx + fw - 6, fy + fh - 5]]) B(tx, ty, 3, 3, { kind: 'tower', hgt: 56, color: '#4a5240', windows: false });
    B(fx + 24, fy + fh - 4, 3, 2, { kind: 'warehouse', hgt: 16, color: '#5a6248', name: 'GATEHOUSE' }); B(fx + 31, fy + fh - 4, 3, 2, { kind: 'warehouse', hgt: 16, color: '#5a6248', name: 'CHECKPOINT' });
    const h1 = B(fx + 4, fy + 66, 14, 8, { kind: 'hangar', hgt: 28, color: '#6b6f58', roof: '#7d8268', interior: 'hangar', name: 'HANGAR 1', neon: '#ffe14a' }); door('fort_hangar', h1, 'Fort Hangar', false);
    B(fx + 38, fy + 66, 14, 8, { kind: 'hangar', hgt: 28, color: '#6b6f58', roof: '#7d8268', interior: 'hangar', name: 'HANGAR 2', neon: '#ffe14a' });
    (W.aircraftSpots || (W.aircraftSpots = [])); for (const [hx, hy, kind, col] of [[fx + 24, fy + 58, 'reaper', '#4a5a35'], [fx + 31, fy + 58, 'reaper', '#8a7a55']]) { W.addProp('helipad', hx * TS, hy * TS); W.aircraftSpots.push({ kind, x: hx * TS, y: hy * TS, a: -Math.PI / 2, col, home: 'Fort Granite' }); }
    for (let i = 0; i < 6; i++) { const tx = (fx + 6 + (i % 3) * 7) * TS, ty = (fy + 46 + Math.floor(i / 3) * 4) * TS; fSpot(W, i < 4 ? 'bulldog' : 'hornet', tx, ty, -Math.PI / 2 + (rn() - 0.5) * 0.3, 'Fort Granite Motor Pool'); }
    for (let i = 0; i < 4; i++) W.parkSpots.push({ x: (fx + 36 + i * 4) * TS, y: (fy + 50) * TS, a: Math.PI / 2, type: 'hummer' });
    W.parkSpots.push({ x: (fx + 44) * TS, y: (fy + 55) * TS, a: Math.PI / 2, type: 'army' });
    for (let i = 0; i < 6; i++) W.addProp('tent', (fx + 5 + i * 8) * TS, (fy + 60) * TS, { a: 0, v: i % 4 });
    for (let i = 0; i < 20; i++) { const sx = fx + 3 + i * 2.6; if (sx > fx + 25 && sx < fx + 32) continue; W.addProp('sandbag', sx * TS, (fy + fh - 1.2) * TS); }
    W.scatter('crate', 14, fx + 2, fy + 28, 24, 16, rng); W.scatter('barrel', 8, fx + 36, fy + 28, 18, 12, rng);
    W.poi('fort', (fx + 28) * TS, (fy + fh + 8) * TS, 'Fort Granite Gate'); W.discList.push('fort'); W.poi('fort_inside', (fx + 28) * TS, (fy + 36) * TS, 'Fort Granite Parade Ground'); city('fort', 'Fort Granite', fx + 28, fy + fh + 9);
    B(fx - 24, fy + 10, 3, 3, { kind: 'tower', hgt: 90, color: '#9aa0a6', windows: false });
    massif(390, 8, 28, 48, { minH: 50, maxH: 150, snow: 120 }); massif(486, 8, 70, 82, { minH: 60, maxH: 170, snow: 125 }); massif(392, 104, 60, 70, { minH: 40, maxH: 120, cols: PAL.mesa }); massif(500, 112, 56, 70, { minH: 40, maxH: 110 });
    sprinkle(384, 0, 192, 192, 'rock', 0.93, new Set([T.GRASS, T.DIRT]), 3, 2); sprinkle(384, 0, 192, 192, 'tree', 0.9, new Set([T.GRASS]), 3, 3);
  })();

  // ============ (0,1) SAGUARO SPRINGS — desert town, mesas, mine ============
  (() => {
    const rx = 0, ry = 1;
    const inTown = (bx, by) => bx >= 3 && bx <= 8 && by >= 15 && by <= 20;
    base(rx, ry, (x, y) => { const h = hash2(x >> 1, y >> 1, 13); return h > 0.9 ? T.GRAVEL : h > 0.78 ? T.DIRT : T.DESERT; }, (bx, by) => [0, 2, 7, 10].includes(bx) || inTown(bx, by), (bx, by) => by === 12 || by === 18 || inTown(bx, by), false);
    crosswalks(rx, ry);
    for (let by = 15; by <= 20; by++) for (let bx = 3; bx <= 8; bx++) ringWalk(bx, by);
    blocks(rx, ry, ({ bx, by, x0, y0 }) => {
      if (!inTown(bx, by)) return; const lx = bx - 3, ly = by - 15, key = lx + ',' + ly;
      put(x0, y0, 10, 10, T.DESERT);
      switch (key) {
        case '2,2': park(x0, y0, 10, 10, 'cactus'); W.poi('sag_plaza', (x0 + 5) * TS, (y0 + 5) * TS, 'Saguaro Plaza'); city('saguaro', 'Saguaro Springs', x0 + 5, y0 + 10.4); break;
        case '3,2': { const b = B(x0, y0 + 1, 8, 5, { kind: 'shop', hgt: 20, color: '#a7774a', roof: '#6a4528', interior: 'bar', name: 'DEAD MULE SALOON', neon: '#ff9a3c' }); door('sag_saloon', b, 'Dead Mule Saloon'); break; }
        case '2,3': { const b = B(x0, y0, 8, 6, { kind: 'civic', hgt: 24, color: '#d3b27a', roof: '#8a6a40', interior: 'police', name: "SHERIFF'S OFFICE", neon: '#4aa8ff' }); door('sag_sheriff', b, "Sheriff's Office"); W.parkSpots.push({ x: (x0 + 2) * TS, y: (y0 + 7.5) * TS, a: 0, cop: 1 }); break; }
        case '1,1': { const b = B(x0, y0, 10, 4, { kind: 'apt', hgt: 16, color: '#e8a6b8', roof: '#c26a4a', interior: 'motel', name: 'ROUTE 18 MOTEL', neon: '#ff4fd8' }); door('sag_motel', b, 'Route 18 Motel'); lot(x0, y0 + 5, 10, 4); break; }
        case '4,2': { const b = B(x0 + 1, y0 + 1, 7, 6, { kind: 'house', hgt: 34, color: '#f3ece0', roof: '#9a6a4a', interior: 'church', door: true, name: 'ST. MARY MISSION' }); door('sag_church', b, 'St. Mary Mission', false); B(x0 + 8, y0 + 1, 2, 2, { kind: 'silo', hgt: 40, color: '#e0d8c8', windows: false }); break; }
        case '3,4': { const b = B(x0, y0, 5, 4, { kind: 'shop', hgt: 18, color: '#c9a26a', interior: 'shop_burger', name: 'DUSTY DINER', neon: '#ff6a3d' }); door('sag_diner', b, 'Dusty Diner', false); shop(x0 + 5, y0, 5, 4, 'shop_mart', 'x', { color: '#b98a5a' }); B(x0 + 3, y0 + 6, 3, 3, { kind: 'silo', hgt: 62, color: '#8a7a6a', windows: false }); break; }
        case '4,4': { const b = B(x0 + 1, y0 + 1, 8, 5, { kind: 'civic', hgt: 20, color: '#e3e8ee', interior: 'hospital', name: 'SPRINGS CLINIC', neon: '#ff4f6a' }); door('sag_clinic', b, 'Springs Clinic', false); break; }
        case '0,3': { put(x0, y0, 10, 10, T.GRAVEL); const g = B(x0 + 1, y0 + 1, 5, 3, { kind: 'shop', hgt: 16, color: '#cfd8dc', interior: 'shop_mart', name: 'GAS-N-GO', neon: '#ffe14a' }); door('sag_gas', g, 'Gas-N-Go', false); W.propAtTile('pump', x0 + 2, y0 + 5); W.propAtTile('pump', x0 + 4, y0 + 5); W.parkSpots.push({ x: (x0 + 3) * TS, y: (y0 + 7) * TS, a: Math.PI / 2 }); break; }
        case '5,3': { put(x0, y0, 10, 10, T.GRAVEL); for (let i = 0; i < 5; i++) house(x0 + Math.floor((i % 3) * 3.3), y0 + 1 + Math.floor(i / 3) * 5, 3, 2, ['#cfd8dc', '#b0bec5', '#e0e0e0'], { hgt: 12 }); W.scatter('barrel', 3, x0, y0, 10, 10, rng); W.scatter('cactus', 3, x0, y0, 10, 10, rng); W.poi('sag_trailer', (x0 + 5) * TS, (y0 + 8) * TS, 'Sundown Trailer Park'); break; }
        default: { if (rn() < 0.5) { for (let j = 0; j < 2; j++) for (let i = 0; i < 2; i++) house(x0 + i * 5 + 1, y0 + j * 5 + 1, 3, 3, PAL.west); W.scatter('cactus', 5, x0, y0, 10, 10, rng); } else { shop(x0, y0, 5, 4, P(['bar', 'shop_burger', 'shop_mart', 'shop_clothes']), 'x', { color: P(PAL.west) }); shop(x0 + 5, y0, 5, 4, P(['shop_mart', 'shop_clothes', 'bar']), 'x', { color: P(PAL.west) }); lot(x0, y0 + 5, 10, 4); } }
      }
    });
    for (const [rbx, rby] of [[1, 14], [5, 13], [9, 14], [1, 21], [5, 22], [9, 22]]) {
      const x0 = rbx * 16 + 5, y0 = rby * 16 + 5; if (!can(x0, y0, 10, 10)) continue; put(x0, y0, 10, 10, T.DIRT);
      B(x0 + 1, y0 + 1, 5, 4, { kind: 'barn', hgt: 24, color: '#9b3a2a', roof: '#6b2a20', door: true, windows: false }); house(x0 + 7, y0 + 1, 3, 3); B(x0 + 8, y0 + 5, 2, 2, { kind: 'silo', hgt: 40, color: '#9aa0a6', windows: false });
      fence(x0 - 1, y0 + 5.5, x0 + 7, y0 + 5.5); for (let i = 0; i < 4; i++) W.addProp('cattle', (x0 + 1 + rn() * 6) * TS, (y0 + 6.5 + rn() * 3) * TS, { a: rn() * 6.28, v: i % 2 }); W.addProp('hay', (x0 + 7) * TS, (y0 + 8.5) * TS);
    }
    put(168, 330, 22, 28, T.GRAVEL); const mine = B(172, 334, 8, 5, { kind: 'warehouse', hgt: 24, color: '#6b6358', name: 'COPPER MINE', door: true, interior: 'hangar', neon: '#ff9a3c' }); door('mine', mine, 'Copper Mine'); W.scatter('barrel', 6, 168, 342, 22, 14, rng); W.scatter('crate', 6, 168, 342, 22, 14, rng);
    put(38, 354, 24, 18, T.GRAVEL); B(48, 355, 5, 1, { kind: 'warehouse', hgt: 40, color: '#e8e8e8', windows: false }); W.poi('drivein', 50 * TS, 364 * TS, 'Starlight Drive-In'); for (let i = 0; i < 8; i++) W.parkSpots.push({ x: (41 + (i % 4) * 5) * TS, y: (360 + Math.floor(i / 4) * 5) * TS, a: -Math.PI / 2 });
    for (let j = 0; j < 3; j++) for (let i = 0; i < 4; i++) B(148 + i * 8, 222 + j * 8, 6, 4, { kind: 'solar', hgt: 8, color: '#2a3f6b', windows: false });
    massif(8, 352, 40, 28, { cols: PAL.mesa, minH: 40, maxH: 120 }); massif(66, 356, 40, 24, { cols: PAL.mesa, minH: 40, maxH: 100 }); massif(110, 200, 30, 24, { cols: PAL.mesa, minH: 36, maxH: 90 }); massif(14, 208, 24, 20, { cols: PAL.mesa, minH: 36, maxH: 90 }); massif(120, 352, 30, 28, { cols: PAL.mesa, minH: 40, maxH: 100 });
    W.poi('canyon', 80 * TS, 368 * TS, 'Red Mesa Canyon'); W.discList.push('canyon');
    sprinkle(0, 192, 192, 192, 'cactus', 0.82, new Set([T.DESERT, T.DIRT]), 2, 4); sprinkle(0, 192, 192, 192, 'rock', 0.95, new Set([T.DESERT, T.DIRT, T.GRAVEL]), 3, 5);
  })();

  // ============ (1,1) AURELIA — the mega-city ============
  (() => {
    const rx = 1, ry = 1;
    base(rx, ry, T.PLAZA, () => true, () => true, true);
    crosswalks(rx, ry); lamps(rx, ry);
    blocks(rx, ry, ({ lx, ly, x0, y0, bx, by }) => {
      const key = lx + ',' + ly; W.turf[bx * NB + by] = lx >= 3 && lx <= 8 && ly >= 3 && ly <= 8 ? 'vel' : '';
      switch (key) {
        case '5,5': park(x0, y0, 10, 10); W.poi('au_plaza', (x0 + 5) * TS, (y0 + 5) * TS, 'Aurelia Central Park'); W.discList.push('au_plaza'); break;
        case '6,5': { const b = B(x0 + 1, y0 + 1, 8, 8, { kind: 'tower', hgt: 170, color: '#3a5a7a', roof: '#6fa0c0', interior: 'office', name: 'AURELIA FINANCIAL', neon: '#4fe0ff' }); door('au_fin', b, 'Aurelia Financial Center'); city('aurelia', 'Aurelia', x0 + 5, y0 + 10.4); break; }
        case '2,2': { put(x0, y0, 10, 10, T.PLAZA); const b = B(x0, y0 + 1, 10, 6, { kind: 'civic', hgt: 36, color: '#8a8f9c', roof: '#b5bac4', interior: 'shop_mart', name: 'CENTRAL STATION', neon: '#ffe14a' }); door('au_station', b, 'Aurelia Central Station'); break; }
        case '9,2': { put(x0, y0, 10, 10, T.GRASS); B(x0, y0, 10, 9, { kind: 'stadium', hgt: 46, color: '#b9bec6', roof: '#2f7a3a', name: 'AURELIA DOME', neon: '#ff4fd8', windows: false }); W.poi('au_dome', (x0 + 5) * TS, (y0 + 10) * TS, 'Aurelia Dome'); W.discList.push('au_dome'); break; }
        case '2,8': { put(x0, y0, 10, 10, T.GRASS); const b = B(x0, y0, 6, 4, { kind: 'civic', hgt: 28, color: '#8a6a5a', roof: '#6a4a3a', interior: 'office', name: 'AURELIA UNIVERSITY', neon: '#ffd24a' }); door('au_uni', b, 'Aurelia University'); B(x0 + 7, y0 + 1, 3, 3, { kind: 'civic', hgt: 24, color: '#8a6a5a' }); B(x0, y0 + 6, 4, 3, { kind: 'civic', hgt: 24, color: '#8a6a5a' }); W.scatter('tree', 8, x0, y0, 10, 10, rng); break; }
        case '8,8': { const b = B(x0 + 1, y0 + 1, 8, 6, { kind: 'civic', hgt: 40, color: '#dfe5ec', roof: '#f3f6fa', interior: 'hospital', name: 'AURELIA GENERAL', neon: '#ff4f6a' }); door('au_hosp', b, 'Aurelia General'); break; }
        case '9,6': { const b = B(x0 + 1, y0 + 1, 8, 8, { kind: 'tower', hgt: 120, color: '#5b2f6b', roof: '#8a5a9a', interior: 'hotel', name: 'GRAND AURELIA', neon: '#ffd24a' }); door('au_hotel', b, 'Grand Aurelia Hotel'); break; }
        case '4,9': { const b = B(x0 + 1, y0 + 1, 8, 6, { kind: 'civic', hgt: 38, color: '#2a3f6b', interior: 'police', name: 'APD CENTRAL', neon: '#4aa8ff' }); door('au_police', b, 'Aurelia Police'); W.parkSpots.push({ x: (x0 + 2) * TS, y: (y0 + 8.5) * TS, a: 0, cop: 1 }, { x: (x0 + 7) * TS, y: (y0 + 8.5) * TS, a: 0, cop: 1 }); break; }
        case '3,5': { const b = B(x0, y0 + 1, 10, 6, { kind: 'civic', hgt: 30, color: '#c8c0b0', roof: '#e0d8c8', interior: 'mall', name: 'AURELIA GRAND MALL', neon: '#4fe0ff' }); door('au_mall', b, 'Aurelia Grand Mall'); lot(x0, y0 + 8, 10, 2); break; }
        case '7,3': { const b = B(x0 + 1, y0 + 1, 8, 6, { kind: 'shop', hgt: 24, color: '#5a2a2a', interior: 'casino', name: 'SILVER STAR CASINO', neon: '#ffd24a' }); door('au_casino', b, 'Silver Star Casino', false); break; }
        default: {
          const r = rn(), edge = lx < 2 || lx > 9 || ly < 2 || ly > 9;
          if (edge && r < 0.35) { put(x0, y0, 10, 10, T.PARKING); B(x0, y0, 10, 4, { kind: 'warehouse', hgt: 24, color: P(PAL.ind), door: true }); B(x0, y0 + 6, 10, 4, { kind: 'warehouse', hgt: 22, color: P(PAL.ind), door: true }); }
          else if (r < 0.1) park(x0, y0, 10, 10);
          else if (r < 0.62) B(x0 + 1, y0 + 1, 8, 8, { kind: 'tower', hgt: edge ? R(50, 90) : R(80, 150), color: P(PAL.glass), neon: P(NEONS), interior: rn() < 0.25 ? 'office' : null, name: '' });
          else { shop(x0, y0, 5, 4, P(['bar', 'shop_burger', 'shop_clothes', 'shop_mart', 'shop_gun']), 'downtown', { color: P(PAL.glass) }); shop(x0 + 5, y0, 5, 4, P(['bar', 'shop_burger', 'shop_clothes', 'shop_mart']), 'downtown', { color: P(PAL.glass) }); B(x0, y0 + 5, 6, 5, { kind: 'tower', hgt: R(60, 110), color: P(PAL.glass), neon: P(NEONS) }); B(x0 + 6, y0 + 5, 4, 5, { kind: 'tower', hgt: R(40, 70), color: P(PAL.glass), neon: P(NEONS) }); }
        }
      }
    });
  })();

  // ============ (2,1) SKYLINE INTERNATIONAL AIRPORT ============
  (() => {
    const rx = 2, ry = 1;
    base(rx, ry, T.GRASS, (bx) => bx % 12 === 0, (bx, by) => by % 12 === 0 || by === 18, false);
    put(396, 216, 156, 6, T.RUNWAY); put(396, 228, 156, 2, T.TARMAC); for (const x of [408, 440, 476, 512, 540]) put(x, 222, 2, 6, T.TARMAC);
    put(430, 230, 92, 42, T.TARMAC); put(396, 230, 30, 42, T.TARMAC); put(430, 271, 92, 14, T.CONCRETE); put(396, 271, 30, 14, T.CONCRETE);
    zone('airfield', 392, 208, 556, 274);
    put(398, 332, 70, 4, T.RUNWAY);
    const term = B(452, 276, 48, 8, { kind: 'terminal', hgt: 38, color: '#b9c4d0', roof: '#7a8ca0', interior: 'terminal', name: 'SKYLINE INTERNATIONAL', neon: '#4fe0ff' }); door('airport', term, 'Skyline International Airport');
    put(452, 284, 48, 4, T.PLAZA);
    const atc = B(506, 274, 3, 3, { kind: 'atc', hgt: 130, color: '#d8dde3', roof: '#4fe0ff', interior: 'atc', door: true, windows: false }); door('atc', atc, 'Air Traffic Control Tower');
    const h1 = B(398, 275, 12, 8, { kind: 'hangar', hgt: 30, color: '#8a929a', roof: '#a0a8b0', interior: 'hangar', name: 'AERO HANGAR A', neon: '#ffe14a' }); door('hangar_a', h1, 'Aero Hangar A', false); B(412, 275, 12, 8, { kind: 'hangar', hgt: 30, color: '#8a929a', roof: '#a0a8b0', interior: 'hangar', name: 'AERO HANGAR B', neon: '#ffe14a' });
    const cargo = B(522, 275, 26, 8, { kind: 'warehouse', hgt: 26, color: '#6b747c', name: 'SKYLINE CARGO', neon: '#ff9a3c', door: true, interior: 'hangar' }); door('cargo', cargo, 'Skyline Cargo', false);
    for (let i = 0; i < 6; i++) plane(446 + i * 14, 246, -Math.PI / 2, 'airliner');
    for (let i = 0; i < 4; i++) plane(450 + i * 18, 262, Math.PI / 2, i % 2 ? 'airliner' : 'jet');
    for (let i = 0; i < 5; i++) plane(402 + (i % 3) * 8, 236 + Math.floor(i / 3) * 14, -Math.PI / 2 + (rn() - 0.5) * 0.3, 'jet');
    plane(505, 240, 0, 'jet'); plane(500, 262, 0, 'jet');
    (W.aircraftSpots || (W.aircraftSpots = [])); for (const hx of [400, 408, 416]) { W.addProp('helipad', hx * TS, 294 * TS); W.aircraftSpots.push({ kind: 'skylark', x: hx * TS, y: 294 * TS, a: -Math.PI / 2 + (rn() - 0.5) * 0.4, home: 'Skyline Heliport' }); }
    for (let i = 0; i < 4; i++) W.addProp('truck', (458 + i * 10) * TS, 273 * TS, { a: 0, v: i % 3 });
    W.addProp('windsock', 394 * TS, 224 * TS); W.addProp('windsock', 555 * TS, 224 * TS);
    lot(440, 294, 24, 14); lot(468, 294, 24, 14); lot(496, 294, 20, 14);
    fence(396, 212, 556, 212); fence(396, 212, 396, 286); fence(556, 212, 556, 286);
    for (const [sx, sy] of [[526, 300], [532, 300], [538, 300], [526, 306], [532, 306], [538, 306]]) B(sx, sy, 4, 4, { kind: 'silo', hgt: 30, color: '#d8dde3', windows: false });
    const inn = B(520, 314, 12, 5, { kind: 'tower', hgt: 44, color: '#4a5a8a', interior: 'hotel', name: 'SKYLINE INN', neon: '#ffe14a' }); door('air_inn', inn, 'Skyline Inn', false);
    shop(468, 312, 10, 4, 'shop_mart', 'x', { name: 'AIRPORT SHOP', hgt: 18, color: '#d49b2a' });
    W.poi('runway', 410 * TS, 219 * TS, 'Runway 09'); W.poi('apron', 476 * TS, 254 * TS, 'Airport Apron'); W.discList.push('runway'); city('airport', 'Skyline Airport', 476, 290);
    sprinkle(384, 192, 192, 192, 'tree', 0.9, new Set([T.GRASS]), 3, 6);
  })();

  // ============ (0,2) PINE RIDGE — forests, lake, mountains ============
  (() => {
    const rx = 0, ry = 2;
    base(rx, ry, (x, y) => (hash2(x >> 3, y >> 3, 17) > 0.8 ? T.GRASS : T.FOREST), (bx) => [0, 2, 7, 10].includes(bx), (bx, by) => by === 24 || by === 30, false);
    const lcx = 108, lcy = 470;
    for (let y = lcy - 21; y <= lcy + 21; y++) for (let x = lcx - 35; x <= lcx + 35; x++) { const d = ((x - lcx) / 33) ** 2 + ((y - lcy) / 19) ** 2 + (hash2(x, y, 3) - 0.5) * 0.12, q = k(x, y); if (d < 1 && q >= 0 && tiles[q] !== T.ROAD) tiles[q] = T.WATER; else if (d < 1.25 && q >= 0 && (tiles[q] === T.FOREST || tiles[q] === T.GRASS)) tiles[q] = T.SAND; }
    W.poi('lake', lcx * TS, (lcy - 25) * TS, 'Lake Verde'); W.discList.push('lake');
    for (const [dx, dy] of [[lcx - 20, lcy - 16], [lcx + 20, lcy - 14], [lcx - 6, lcy + 14]]) { put(dx, dy, 2, 7, T.WOOD); boatSpot(W, (dx + 1) * TS, (dy + 7) * TS, { a: Math.PI / 2, v: 3 }); }
    const lodge = B(82, 436, 14, 6, { kind: 'house', hgt: 28, color: '#8a6038', roof: '#4a321e', interior: 'lodge', door: true, name: 'VERDE LAKE LODGE', neon: '#ffd24a' }); door('lodge', lodge, 'Verde Lake Lodge'); if (lodge) put(82, 442, 14, 4, T.PATH);
    for (let i = 0; i < 6; i++) house(lcx - 44 + i * 12, lcy - 44 + (i % 2) * 6, 4, 3, PAL.log, { interior: 'cabin' });
    const ranger = B(66, 410, 6, 4, { kind: 'house', hgt: 20, color: '#6a4528', roof: '#3f4a3a', interior: 'cabin', door: true, name: 'RANGER STATION' }); door('ranger', ranger, 'Ranger Station', false);
    put(60, 420, 14, 10, T.DIRT); for (let i = 0; i < 5; i++) W.addProp('tent', (62 + (i % 3) * 4.5) * TS, (422 + Math.floor(i / 3) * 4) * TS, { a: 0, v: i % 4 }); W.poi('camp', 67 * TS, 427 * TS, 'Pine Camp');
    put(122, 400, 30, 22, T.GRAVEL); const mill = B(126, 404, 10, 6, { kind: 'warehouse', hgt: 22, color: '#8a6038', name: 'RIDGE LUMBER', door: true, interior: 'hangar', neon: '#ff9a3c' }); door('mill', mill, 'Ridge Lumber Mill', false); for (let i = 0; i < 9; i++) W.addProp('stump', (126 + rn() * 22) * TS, (413 + rn() * 7) * TS);
    massif(8, 390, 56, 60, { minH: 70, maxH: 190, snow: 110 }); massif(166, 430, 24, 60, { minH: 60, maxH: 170, snow: 110 }); massif(8, 500, 70, 52, { minH: 70, maxH: 190, snow: 110 }); massif(120, 510, 60, 44, { minH: 60, maxH: 160, snow: 110 });
    W.poi('summit', 36 * TS, 520 * TS, 'Mount Ridgeback'); W.discList.push('summit');
    sprinkle(0, 384, 192, 176, 'pine', 0.55, new Set([T.FOREST, T.GRASS, T.SAND]), 2, 8); sprinkle(0, 384, 192, 176, 'rock', 0.96, new Set([T.FOREST, T.GRASS]), 3, 9);
    city('pine', 'Pine Ridge', 70, 432);
  })();

  // ============ (1,2) AMBROSE VALLEY — farmland, Marlow, power plant ============
  (() => {
    const rx = 1, ry = 2;
    const town = (bx, by) => bx >= 16 && bx <= 19 && by >= 28 && by <= 31;
    base(rx, ry, (x, y) => (hash2(x >> 4, y >> 4, 21) > 0.35 ? T.FARM : T.GRASS), (bx, by) => bx % 12 === 0 || bx === 16 || bx === 20 || town(bx, by), (bx, by) => by === 24 || by === 28 || by === 32 || town(bx, by), false);
    crosswalks(rx, ry);
    for (let by = 28; by <= 31; by++) for (let bx = 16; bx <= 19; bx++) ringWalk(bx, by);
    // power plant first (so farms do not overwrite it)
    const px = 332, py = 458;
    put(px - 6, py - 4, 44, 52, T.CONCRETE); fence(px - 6, py - 4, px + 38, py - 4); fence(px - 6, py - 4, px - 6, py + 48); fence(px + 38, py - 4, px + 38, py + 48); fence(px - 6, py + 48, px + 38, py + 48, (x) => x > (px + 10) * TS && x < (px + 16) * TS);
    for (let j = 0; j < 3; j++) for (let i = 0; i < 3; i++) B(px + i * 8, py + j * 8, 5, 5, { kind: 'silo', hgt: 36 + (i + j) * 6, color: ['#d8dde3', '#c9c2b0', '#b5442d'][(i + j) % 3], windows: false });
    const pp = B(px + 4, py + 30, 22, 7, { kind: 'warehouse', hgt: 30, color: '#6b747c', name: 'AMBROSE POWER', neon: '#ffe14a', door: true, interior: 'hangar' }); door('plant', pp, 'Ambrose Power Plant'); B(px + 28, py + 30, 3, 3, { kind: 'tower', hgt: 110, color: '#9aa0a6', windows: false }); B(px + 32, py + 36, 3, 3, { kind: 'tower', hgt: 120, color: '#9aa0a6', windows: false });
    W.scatter('barrel', 8, px, py + 38, 30, 8, rng);
    blocks(rx, ry, ({ bx, by, x0, y0 }) => {
      if (town(bx, by)) {
        const lx = bx - 16, ly = by - 28; put(x0, y0, 10, 10, T.GRASS);
        if (lx === 1 && ly === 1) { park(x0, y0, 10, 10); city('valley', 'Marlow', x0 + 5, y0 + 10.4); return; }
        if (lx === 2 && ly === 1) { const b = B(x0, y0 + 1, 6, 5, { kind: 'house', hgt: 26, color: '#e8e2d0', roof: '#7a4b3a', interior: 'church', door: true, name: 'MARLOW CHAPEL' }); door('valley_church', b, 'Marlow Chapel', false); return; }
        if (lx === 1 && ly === 2) { const b = B(x0, y0, 5, 4, { kind: 'shop', hgt: 18, color: '#d9d0b0', interior: 'shop_burger', name: 'FARMERS DINER', neon: '#ff6a3d' }); door('valley_diner', b, 'Farmers Diner', false); shop(x0 + 5, y0, 5, 4, 'shop_mart', 'x', { color: '#a7b8c9' }); B(x0 + 2, y0 + 6, 3, 3, { kind: 'silo', hgt: 56, color: '#9aa0a6', windows: false }); return; }
        if (lx === 2 && ly === 2) { const b = B(x0 + 1, y0 + 1, 8, 5, { kind: 'civic', hgt: 22, color: '#2a3f6b', interior: 'police', name: 'COUNTY SHERIFF', neon: '#4aa8ff' }); door('valley_sheriff', b, 'County Sheriff', false); W.parkSpots.push({ x: (x0 + 2) * TS, y: (y0 + 8) * TS, a: 0, cop: 1 }); return; }
        for (let j = 0; j < 2; j++) for (let i = 0; i < 2; i++) { house(x0 + i * 5 + 1, y0 + j * 5 + 1, 3, 3); W.scatter('tree', 1, x0 + i * 5, y0 + j * 5, 5, 5, rng); }
        return;
      }
      if (rn() < 0.22 && can(x0, y0, 10, 10)) { put(x0, y0, 10, 10, T.DIRT); B(x0 + 1, y0 + 1, 5, 4, { kind: 'barn', hgt: 24, color: '#9b3a2a', roof: '#6b2a20', door: true, windows: false }); house(x0 + 7, y0 + 1, 3, 3); B(x0 + 7, y0 + 5, 2, 2, { kind: 'silo', hgt: 42, color: '#9aa0a6', windows: false }); W.scatter('hay', 5, x0, y0 + 5, 7, 5, rng); for (let i = 0; i < 3; i++) W.addProp('cattle', (x0 + 1 + rn() * 5) * TS, (y0 + 6 + rn() * 3) * TS, { a: rn() * 6, v: i % 2 }); W.addProp('truck', (x0 + 4) * TS, (y0 + 9) * TS, { a: 0, v: 1 }); }
    });
    put(200, 424, 50, 5, T.RUNWAY); plane(208, 431, 0, 'jet'); W.poi('airstrip', 225 * TS, 427 * TS, 'Ambrose Airstrip'); city('airstrip', 'Ambrose Airstrip', 225, 431);
    for (let j = 0; j < 3; j++) for (let i = 0; i < 5; i++) { const tx = 200 + i * 10, ty = 396 + j * 9; if (can(tx, ty, 1, 1)) W.addProp('turbine', (tx + 0.5) * TS, (ty + 0.5) * TS, { v: (i + j) % 4 }); }
    W.poi('windfarm', 220 * TS, 405 * TS, 'Valley Wind Farm'); W.discList.push('windfarm');
    sprinkle(192, 384, 192, 176, 'tree', 0.9, new Set([T.GRASS]), 3, 10);
  })();

  // ============ (2,2) BAYOU ROUGE + THE KEYS ============
  (() => {
    const rx = 2, ry = 2;
    base(rx, ry, (x, y) => { const h = hash2(x >> 2, y >> 2, 23), h2 = hash2(x, y, 24); return y >= 496 ? T.WATER : h > 0.45 ? T.MARSH : h2 > 0.2 ? T.GRASS : T.FOREST; }, (bx, by) => bx % 12 === 0 || (bx === 29 && by <= 33), (bx, by) => by === 24 || by === 27 || by === 33, false);
    for (let ty = 496; ty < 560; ty++) for (let tx = 384; tx < NT; tx++) { const q = k(tx, ty); if (tiles[q] === T.ROAD) tiles[q] = T.BRIDGE; }
    const tx0 = 398, ty0 = 442; put(tx0 - 4, ty0 - 4, 56, 40, T.GRASS);
    for (let i = 0; i < 52; i++) put(tx0 + i - 2, ty0 + 14, 1, 2, T.WOOD); for (let j = 0; j < 30; j++) { put(tx0 + 10, ty0 - 2 + j, 2, 1, T.WOOD); put(tx0 + 30, ty0 - 2 + j, 2, 1, T.WOOD); }
    const gator = B(tx0 + 2, ty0 + 7, 7, 5, { kind: 'shop', hgt: 20, color: '#6a7a5a', roof: '#4a5a3a', interior: 'bar', name: "GATOR'S SHACK", neon: '#7cff4f' }); door('bayou_bar', gator, "Gator's Shack");
    const bait = B(tx0 + 13, ty0 + 7, 6, 5, { kind: 'shop', hgt: 18, color: '#8a7a5a', interior: 'shop_mart', name: 'BAIT & TACKLE', neon: '#ffe14a' }); door('bayou_bait', bait, 'Bait & Tackle', false);
    const voodoo = B(tx0 + 21, ty0 + 7, 6, 5, { kind: 'shop', hgt: 18, color: '#5a4a6a', interior: 'shop_clothes', name: 'MAMA ROUX', neon: '#b36bff' }); door('bayou_voodoo', voodoo, 'Mama Roux Boutique', false);
    const motel = B(tx0 + 34, ty0 + 7, 10, 5, { kind: 'apt', hgt: 16, color: '#8a7a5a', interior: 'motel', name: 'CYPRESS MOTEL', neon: '#ff6a3d' }); door('bayou_motel', motel, 'Cypress Motel', false);
    for (let i = 0; i < 6; i++) { const b = house(tx0 + 1 + i * 8, ty0 + 18, 4, 3, PAL.swamp, { interior: 'cabin' }); if (b) put(b.x - 1, b.y + b.h, b.w + 2, 2, T.WOOD); boatSpot(W, (tx0 + 3 + i * 8) * TS, (ty0 + 25) * TS, { a: rn() * 6.28, v: i % 4 }); }
    W.parkSpots.push({ x: (tx0 + 5) * TS, y: (ty0 + 13) * TS, a: 0, type: 'pickup' }); W.poi('bayou_dock', (tx0 + 26) * TS, (ty0 + 16) * TS, 'Airboat Dock'); W.discList.push('bayou_dock'); city('bayou', 'Bayou Rouge', tx0 + 24, ty0 + 13);
    for (const [ix, w2, name] of [[404, 40, 'Key Largo'], [472, 40, 'Key Palma'], [520, 34, 'Key Sombra']]) {
      for (let y = 508; y < 548; y++) for (let x = ix; x < ix + w2; x++) { const d = ((x - ix - w2 / 2) / (w2 / 2)) ** 2 + ((y - 528) / 20) ** 2 + (hash2(x, y, 6) - 0.5) * 0.18, q = k(x, y); if (d < 1 && q >= 0 && tiles[q] === T.WATER) tiles[q] = d > 0.7 ? T.SAND : T.GRASS; }
      const r = B(ix + 6, 510, 20, 9, { kind: 'tower', hgt: 60, color: P(PAL.pastel), interior: 'hotel', name: name.toUpperCase() + ' RESORT', neon: P(NEONS) }); if (r) { door('key_' + ix, r, name + ' Resort', false); put(r.x, r.y + r.h, r.w, 2, T.PLAZA); }
      B(ix + 8, 536, 8, 4, { kind: 'shop', hgt: 18, color: P(PAL.pastel), interior: 'bar', name: 'BEACH SHACK', neon: P(NEONS) }); for (let i = 0; i < 6; i++) W.addProp(rn() < 0.5 ? 'palm' : 'umbrella', (ix + 4 + rn() * (w2 - 8)) * TS, (521 + rn() * 5) * TS, { v: i % 4 });
      for (let i = 0; i < 4; i++) boatSpot(W, (ix + 4 + i * 9) * TS, (547 + (i % 2) * 2) * TS, { a: Math.PI / 2, v: i % 4 });
    }
    W.poi('keys', 424 * TS, 526 * TS, 'The Keys'); W.discList.push('keys');
    sprinkle(384, 384, 192, 112, 'tree', 0.7, new Set([T.GRASS, T.FOREST]), 2, 12); sprinkle(384, 384, 192, 112, 'palm', 0.93, new Set([T.GRASS]), 3, 13);
  })();

  // ============ connectors, coast, bridges ============
  for (const by of [0, 5, 10]) for (let ty = by * 16; ty < by * 16 + 4; ty++) for (let tx = 180; tx < 192; tx++) { const q = k(tx, ty); tiles[q] = tx < 184 ? T.ROAD : T.BRIDGE; meta[q] = M.H | (by === 0 ? M.HWY : 0); }
  for (const bx of [0, 2, 7, 10]) for (let tx = bx * 16; tx < bx * 16 + 4; tx++) for (let ty = 180; ty < 192; ty++) { const q = k(tx, ty); tiles[q] = ty < 184 ? T.ROAD : T.BRIDGE; meta[q] = M.V; }
  W.poi('bridge_e', 186 * TS, 8 * TS, 'Meridian Bridge'); W.poi('bridge_s', 8 * TS, 186 * TS, 'Southgate Bridge');
  const sandy = (q) => tiles[q] !== T.ROAD && tiles[q] !== T.BRIDGE && tiles[q] !== T.WATER && tiles[q] !== T.BUILDING && tiles[q] !== T.WOOD && tiles[q] !== T.PLAZA;
  for (let y = 0; y < NT; y++) for (let x = WEDGE - 4; x < NT; x++) { const q = y * NT + x; if (x >= WEDGE) tiles[q] = T.WATER; else if (sandy(q)) tiles[q] = T.SAND; }
  for (let y = WEDGE - 4; y < NT; y++) for (let x = 0; x < NT; x++) { const q = y * NT + x; if (y >= WEDGE) tiles[q] = T.WATER; else if (sandy(q)) tiles[q] = T.SAND; }
  for (let i = 0; i < NT * NT; i++) if (tiles[i] === T.WATER) meta[i] = 0;
}
