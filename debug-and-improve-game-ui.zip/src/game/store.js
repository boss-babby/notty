// ===== store.js — durable storage layer =====
// Two tiers, so a refresh / crash / tab-kill never loses progress:
//   • IndexedDB  — large values (explored map, atlas, full snapshots, rolling backups).  Asynchronous.
//   • localStorage — a synchronous mirror of the small "core" snapshot.  It can be written inside `pagehide` / `beforeunload`,
//     where async work may be cancelled by the browser.
// On boot the newest valid snapshot of the two wins (every snapshot carries a timestamp `t` and a version `v`).
const DB = 'neon-tide-db', ST = 'kv';
let dbp = null;
function open() {
  if (dbp) return dbp;
  dbp = new Promise((res) => {
    try {
      if (typeof indexedDB === 'undefined') return res(null);
      const rq = indexedDB.open(DB, 1);
      rq.onupgradeneeded = () => { try { rq.result.createObjectStore(ST); } catch (e) { /* exists */ } };
      rq.onsuccess = () => { const db = rq.result; db.onversionchange = () => { try { db.close(); } catch (e) { /* ignore */ } dbp = null; }; res(db); };
      rq.onerror = () => res(null); rq.onblocked = () => res(null);
    } catch (e) { res(null); }
  });
  return dbp;
}
export async function idbGet(k) {
  const db = await open(); if (!db) return null;
  return new Promise((res) => { try { const rq = db.transaction(ST, 'readonly').objectStore(ST).get(k); rq.onsuccess = () => res(rq.result === undefined ? null : rq.result); rq.onerror = () => res(null); } catch (e) { res(null); } });
}
export async function idbSet(k, v) {
  const db = await open(); if (!db) return false;
  return new Promise((res) => { try { const tx = db.transaction(ST, 'readwrite'); tx.objectStore(ST).put(v, k); tx.oncomplete = () => res(true); tx.onerror = () => res(false); tx.onabort = () => res(false); } catch (e) { res(false); } });
}
export async function idbDel(k) {
  const db = await open(); if (!db) return false;
  return new Promise((res) => { try { const tx = db.transaction(ST, 'readwrite'); tx.objectStore(ST).delete(k); tx.oncomplete = () => res(true); tx.onerror = () => res(false); } catch (e) { res(false); } });
}
export const ls = {
  get(k) { try { const s = localStorage.getItem(k); return s ? JSON.parse(s) : null; } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, typeof v === 'string' ? v : JSON.stringify(v)); return true; } catch (e) { return false; } },
  del(k) { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } },
};
/** ask the browser not to evict our data under storage pressure */
export function requestPersistence() { try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {}); } catch (e) { /* ignore */ } }

const CORE = 'nt_save', MAP = 'nt_save_map';
const valid = (d) => d && typeof d === 'object' && d.p && typeof d.p.x === 'number' && typeof d.cash === 'number';

/** newest valid core snapshot out of  localStorage / IndexedDB / IndexedDB backup */
export async function loadCore() {
  const cands = [ls.get(CORE), await idbGet('core'), await idbGet('core_bak')].filter(valid);
  cands.sort((a, b) => (b.t || 0) - (a.t || 0)); return cands[0] || null;
}
export function loadCoreSync() { const d = ls.get(CORE); return valid(d) ? d : null; }
/** the synchronous half: always safe inside pagehide */
export function saveCoreSync(d) { return ls.set(CORE, d); }
let lastBak = 0;
export function saveCoreAsync(d) {
  const now = Date.now(), p = [idbSet('core', d)];
  if (now - lastBak > 90000) { lastBak = now; p.push(idbSet('core_bak', d)); }
  return Promise.all(p);
}
export async function loadMap() {
  const a = await idbGet('map'), b = ls.get(MAP), ok = (m) => m && typeof m === 'object' && Array.isArray(m.ex);
  if (ok(a) && ok(b)) return (a.t || 0) >= (b.t || 0) ? a : b; return ok(a) ? a : ok(b) ? b : null;
}
export function saveMap(d) {
  const json = JSON.stringify(d); let lsOk = false;
  if (json.length < 1400000) lsOk = ls.set(MAP, json); else ls.del(MAP); // big maps live in IndexedDB only
  return idbSet('map', d).then((ok) => ok || lsOk);
}
export async function wipeAll() { ls.del(CORE); ls.del(MAP); await idbDel('core'); await idbDel('core_bak'); await idbDel('map'); }
