// ===== fx.js — pooled particles and per-frame light list =====
import { clamp } from './util.js';

export const P = { SMOKE: 0, SPARK: 1, BLOOD: 2, DEBRIS: 3, FIRE: 4, SHELL: 5, GLASS: 6, RING: 7, WATER: 8 };

export class Particles {
  constructor(n = 1400) {
    this.n = n; this.i = 0; this.qmul = 1;
    this.a = Array.from({ length: n }, () => ({ on: false, k: 0, x: 0, y: 0, vx: 0, vy: 0, life: 0, max: 1, size: 2, col: '#fff', rot: 0, vr: 0 }));
  }
  emit(k, x, y, vx, vy, life, size, col) {
    const p = this.a[this.i]; this.i = (this.i + 1) % this.n;
    p.on = true; p.k = k; p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.life = p.max = life; p.size = size; p.col = col; p.rot = Math.random() * 6.28; p.vr = (Math.random() - 0.5) * 12;
  }
  burst(k, x, y, n, speed, life, size, col, spread = 6.28, dir = 0) {
    n = Math.ceil(n * this.qmul);
    for (let i = 0; i < n; i++) { const a = dir + (Math.random() - 0.5) * spread, s = speed * (0.3 + Math.random() * 0.9); this.emit(k, x, y, Math.cos(a) * s, Math.sin(a) * s, life * (0.6 + Math.random() * 0.6), size * (0.6 + Math.random() * 0.8), col); }
  }
  update(dt) {
    for (let i = 0; i < this.n; i++) {
      const p = this.a[i]; if (!p.on) continue;
      p.life -= dt; if (p.life <= 0) { p.on = false; continue; }
      p.x += p.vx * dt; p.y += p.vy * dt;
      const d = p.k === P.SMOKE ? 1.2 : p.k === P.FIRE ? 2.4 : p.k === P.RING ? 0 : 3.2; const f = Math.max(0, 1 - d * dt); p.vx *= f; p.vy *= f; p.rot += p.vr * dt;
      if (p.k === P.SMOKE) p.vy -= 10 * dt;
    }
  }
  draw(c, x0, y0, x1, y1) {
    for (let i = 0; i < this.n; i++) {
      const p = this.a[i]; if (!p.on || p.x < x0 || p.x > x1 || p.y < y0 || p.y > y1) continue;
      const t = p.life / p.max;
      switch (p.k) {
        case P.SMOKE: c.globalAlpha = t * 0.45; c.fillStyle = p.col; c.beginPath(); c.arc(p.x, p.y, p.size * (1 + (1 - t) * 1.8), 0, 6.3); c.fill(); break;
        case P.SPARK: c.globalAlpha = Math.min(1, t * 2); c.strokeStyle = p.col; c.lineWidth = 1.5; c.beginPath(); c.moveTo(p.x, p.y); c.lineTo(p.x - p.vx * 0.03, p.y - p.vy * 0.03); c.stroke(); break;
        case P.BLOOD: c.globalAlpha = Math.min(1, t * 2); c.fillStyle = p.col; c.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size); break;
        case P.DEBRIS: case P.GLASS: case P.SHELL: c.globalAlpha = Math.min(1, t * 2); c.fillStyle = p.col; c.save(); c.translate(p.x, p.y); c.rotate(p.rot); c.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2); c.restore(); break;
        case P.RING: c.globalAlpha = t * 0.6; c.strokeStyle = p.col; c.lineWidth = 1.5; c.beginPath(); c.arc(p.x, p.y, p.size * (2 - t) * 2.2, 0, 6.3); c.stroke(); break;
        case P.WATER: c.globalAlpha = t * 0.7; c.fillStyle = p.col; c.beginPath(); c.arc(p.x, p.y, p.size, 0, 6.3); c.fill(); break;
        default: break;
      }
    }
    c.globalAlpha = 1;
  }
  drawGlow(c, x0, y0, x1, y1) {
    c.globalCompositeOperation = 'lighter';
    for (let i = 0; i < this.n; i++) {
      const p = this.a[i]; if (!p.on || p.k !== P.FIRE || p.x < x0 || p.x > x1 || p.y < y0 || p.y > y1) continue;
      const t = p.life / p.max; c.globalAlpha = clamp(t * 0.9, 0, 1); c.fillStyle = t > 0.6 ? '#ffe28a' : t > 0.3 ? '#ff8a2a' : '#c0391a';
      c.beginPath(); c.arc(p.x, p.y, p.size * (0.5 + t), 0, 6.3); c.fill();
    }
    c.globalCompositeOperation = 'source-over'; c.globalAlpha = 1;
  }
}

export class Lights {
  constructor(n = 300) { this.n = 0; this.a = Array.from({ length: n }, () => ({ x: 0, y: 0, r: 0, col: '#fff', i: 1, ang: 0, cone: 0 })); }
  reset() { this.n = 0; }
  add(x, y, r, col, i = 1, ang = 0, cone = 0) { if (this.n >= this.a.length) return; const l = this.a[this.n++]; l.x = x; l.y = y; l.r = r; l.col = col; l.i = i; l.ang = ang; l.cone = cone; }
}
