// ===== interiors.js — enterable building interiors (separate small scenes with fade transition) =====
import { clamp } from './util.js';
import { makeCanvas, rr } from './gfx.js';
const TS = 32;

class Interior {
  constructor(type, w, h, theme) {
    this.id = type; this.type = type; this.w = w; this.h = h; this.theme = theme; this.t = new Uint8Array(w * h); this.decor = []; this.objs = []; this.npcs = []; this.pts = {};
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (y < 2 || y === h - 1 || x === 0 || x === w - 1) this.t[y * w + x] = 1;
    this.exitDoor = { x: (w >> 1) * TS + 16, y: (h - 1) * TS + 8 };
    this.pts.entry = { x: this.exitDoor.x, y: (h - 2) * TS + 8 };
    this.objs.push({ x: this.exitDoor.x, y: (h - 0.55) * TS, r: 40, label: 'Leave', act: 'exit' });
    this.res = { x: 0, y: 0, nx: 0, ny: 0, hit: 0, prop: null };
  }
  box(x, y, w, h, col, solid = true, label) {
    this.decor.push({ x, y, w, h, col, label });
    if (solid) for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.t[(y + j) * this.w + x + i] = 2;
  }
  npc(x, y, o) { this.npcs.push({ x: x * TS, y: y * TS, ...o }); }
  obj(x, y, label, act, data, r = 40) { this.objs.push({ x: x * TS, y: y * TS, r, label, act, data }); }
  solidTile(tx, ty) { return tx < 0 || ty < 0 || tx >= this.w || ty >= this.h || this.t[ty * this.w + tx] !== 0; }
  solidAt(x, y) { return this.solidTile(Math.floor(x / TS), Math.floor(y / TS)); }
  lineClear(x0, y0, x1, y1) { const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 12); for (let i = 1; i < n; i++) { const t = i / n; if (this.solidAt(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)) return false; } return true; }
  pushCircle(x, y, r) {
    const res = this.res; res.hit = 0; res.nx = 0; res.ny = 0; res.prop = null;
    for (let ty = Math.floor((y - r) / TS); ty <= Math.floor((y + r) / TS); ty++) for (let tx = Math.floor((x - r) / TS); tx <= Math.floor((x + r) / TS); tx++) {
      if (!this.solidTile(tx, ty)) continue;
      const cx = clamp(x, tx * TS, tx * TS + TS), cy = clamp(y, ty * TS, ty * TS + TS), dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy;
      if (d2 >= r * r) continue;
      if (d2 > 1e-6) { const d = Math.sqrt(d2); x += (dx / d) * (r - d); y += (dy / d) * (r - d); res.nx = dx / d; res.ny = dy / d; } else { y += r; }
      res.hit++;
    }
    res.x = x; res.y = y; return res;
  }
  render() {
    const W = this.w * TS, H = this.h * TS, cv = makeCanvas(W, H), c = cv.getContext('2d'), th = this.theme;
    for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
      const k = this.t[y * this.w + x];
      if (k === 1) { c.fillStyle = y < 2 ? th.wallTop : th.wall; c.fillRect(x * TS, y * TS, TS, TS); if (y === 1) { c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(x * TS, y * TS + TS - 6, TS, 6); c.fillStyle = th.trim; c.fillRect(x * TS, y * TS + TS - 8, TS, 2); } }
      else { c.fillStyle = (x + y) % 2 ? th.floorA : th.floorB; c.fillRect(x * TS, y * TS, TS, TS); if (th.rug) { c.fillStyle = 'rgba(0,0,0,.05)'; c.fillRect(x * TS, y * TS, TS, 1); } }
    }
    // door mat
    c.fillStyle = '#222'; c.fillRect(this.exitDoor.x - 20, (this.h - 1) * TS, 40, TS); c.fillStyle = th.accent; c.fillRect(this.exitDoor.x - 20, (this.h - 1) * TS, 40, 3);
    for (const d of this.decor) {
      const x = d.x * TS, y = d.y * TS, w = d.w * TS, h = d.h * TS;
      c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(x + 3, y + 5, w, h);
      const g = c.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, shadeCol(d.col, 0.25)); g.addColorStop(1, d.col); c.fillStyle = g; rr(c, x, y, w, h, 4); c.fill();
      c.strokeStyle = 'rgba(0,0,0,.45)'; c.lineWidth = 1.5; c.stroke();
      if (d.label) { c.fillStyle = 'rgba(255,255,255,.85)'; c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; c.fillText(d.label, x + w / 2, y + h / 2 + 3); }
    }
    this.cv = cv; return cv;
  }
}
function shadeCol(hex, f) { const n = parseInt(hex.slice(1), 16), c = (v) => Math.min(255, Math.round(v + (255 - v) * f)); return `rgb(${c(n >> 16)},${c((n >> 8) & 255)},${c(n & 255)})`; }

const THEMES = {
  shop: { floorA: '#6c6f78', floorB: '#62656e', wall: '#2a2c36', wallTop: '#3a3d4a', trim: '#ff4fd8', accent: '#ffd24a' },
  bar: { floorA: '#4a3326', floorB: '#422d21', wall: '#1d1418', wallTop: '#2b1d24', trim: '#ff4fd8', accent: '#ff4fd8', rug: 1 },
  bank: { floorA: '#8a8f9c', floorB: '#7f8492', wall: '#2d3345', wallTop: '#3a4258', trim: '#4fe0ff', accent: '#4fe0ff' },
  police: { floorA: '#6d7584', floorB: '#646c7b', wall: '#1d2640', wallTop: '#26325a', trim: '#4aa8ff', accent: '#4aa8ff' },
  home: { floorA: '#7a6a58', floorB: '#705f4e', wall: '#34303c', wallTop: '#454052', trim: '#4fe0ff', accent: '#4fe0ff', rug: 1 },
  hospital: { floorA: '#d4dde6', floorB: '#c8d2dd', wall: '#6c7a8a', wallTop: '#8794a3', trim: '#ff4f6a', accent: '#ff4f6a' },
  casino: { floorA: '#4a1f4f', floorB: '#3e1a43', wall: '#1a0f1f', wallTop: '#2b1733', trim: '#ffd24a', accent: '#ffd24a', rug: 1 },
  garage: { floorA: '#5b5e66', floorB: '#54575f', wall: '#2a2724', wallTop: '#3a3530', trim: '#ff6a3d', accent: '#ff6a3d' },
  airport: { floorA: '#cfd6de', floorB: '#c4ccd6', wall: '#2a3342', wallTop: '#3a4760', trim: '#4fe0ff', accent: '#4fe0ff', amb: 'rgb(188,196,210)' },
  military: { floorA: '#6b6f58', floorB: '#62664f', wall: '#232a1c', wallTop: '#323b28', trim: '#7cff4f', accent: '#7cff4f', amb: 'rgb(150,156,134)' },
  luxe: { floorA: '#d8c9a8', floorB: '#cfbf9c', wall: '#3a2f3f', wallTop: '#4b3f50', trim: '#ffd24a', accent: '#ffd24a', rug: 1, amb: 'rgb(190,176,164)' },
  wood: { floorA: '#8a6038', floorB: '#7f5732', wall: '#3a2a1e', wallTop: '#4d392a', trim: '#ffb347', accent: '#ffb347', rug: 1, amb: 'rgb(170,146,124)' },
  church: { floorA: '#cbbba0', floorB: '#c2b296', wall: '#4a3f55', wallTop: '#5c506a', trim: '#ffe9a8', accent: '#ffe9a8', amb: 'rgb(176,168,172)' },
  club: { floorA: '#1b1030', floorB: '#150a26', wall: '#0d0618', wallTop: '#1a0d2c', trim: '#ff4fd8', accent: '#4fe0ff', amb: 'rgb(96,78,138)' },
  motel: { floorA: '#8a7a6a', floorB: '#807060', wall: '#40343a', wallTop: '#524450', trim: '#ff6a3d', accent: '#ff6a3d', rug: 1, amb: 'rgb(170,150,140)' },
  arena: { floorA: '#4a4040', floorB: '#433838', wall: '#241818', wallTop: '#3a2222', trim: '#ff3b3b', accent: '#ff3b3b' },
};

export function buildInterior(type, b) {
  let I;
  const shop = (title, th = 'shop') => {
    I = new Interior(type, 12, 9, THEMES[th]);
    I.box(1, 2, 10, 1, '#4a3a2a', true); I.box(2, 4, 8, 1, '#6b4a2f', true, title);
    I.npc(6, 3.6, { role: 'clerk' }); I.obj(6, 5.6, 'Browse — ' + title, 'shop:' + type, null, 46);
    if (type === 'shop_clothes') { I.box(9, 6, 1, 2, '#7ac', true, 'mirror'); I.obj(8.3, 7, 'Try clothes ($40)', 'wardrobe', 40, 44); }
    if (type === 'shop_gun') { I.decor.push({ x: 1, y: 1.1, w: 10, h: 0.6, col: '#222' }); }
    I.pts.floor = { x: 6 * TS, y: 6.5 * TS };
  };
  switch (type) {
    case 'shop_gun': shop('GUN DEN'); break;
    case 'shop_mart': shop('MART'); break;
    case 'shop_clothes': shop('THREADS'); break;
    case 'shop_burger': shop('BURGER'); break;
    case 'bar': {
      I = new Interior(type, 14, 10, THEMES.bar); I.box(2, 3, 9, 1, '#5a3a22', true, 'BAR'); I.box(3, 6, 2, 2, '#6a4a30', true); I.box(9, 6, 2, 2, '#6a4a30', true); I.box(12, 2, 1, 2, '#2a2a5a', true, 'JUKE');
      I.npc(6, 2.5, { role: 'clerk' }); I.npc(4, 5.2, { role: 'patron' }); I.obj(6, 4.7, 'Order a drink', 'shop:bar', null, 46); I.obj(11.6, 4.3, 'Jukebox', 'jukebox', null, 40); I.pts.floor = { x: 7 * TS, y: 6 * TS }; break;
    }
    case 'bank': {
      I = new Interior(type, 16, 12, THEMES.bank); I.box(9, 1, 6, 3, '#3a3f4a', true, 'VAULT'); I.box(2, 5, 12, 1, '#6b6b78', true, 'TELLERS');
      [4, 7.5, 11].forEach((x) => I.npc(x, 4.4, { role: 'teller' })); I.npc(3, 8.5, { role: 'customer' }); I.npc(12, 8, { role: 'customer' });
      I.npc(3, 9.5, { role: 'guard' }); I.npc(13, 9.5, { role: 'guard' }); I.npc(8, 7.8, { role: 'guard' });
      I.obj(1.6, 7.2, 'ATM', 'atm', null, 40); I.pts.vault = { x: 12 * TS, y: 4.4 * TS }; I.pts.floor = { x: 8 * TS, y: 8 * TS }; break;
    }
    case 'police': {
      I = new Interior(type, 16, 11, THEMES.police); I.box(5, 3, 6, 1, '#555d6c', true, 'DESK'); I.box(1, 2, 3, 4, '#2b2f3a', true, 'CELLS'); I.box(13, 2, 2, 2, '#3a4252', true);
      I.npc(8, 2.5, { role: 'sergeant' }); I.npc(12, 6, { role: 'officer' }); I.npc(4, 8, { role: 'officer' }); I.obj(8, 4.7, 'Desk Sergeant — Bribe / Fine', 'police', null, 46); I.pts.floor = { x: 8 * TS, y: 7 * TS }; break;
    }
    case 'safehouse': case 'apartment': {
      const own = type === 'safehouse'; I = new Interior(type, own ? 14 : 10, own ? 9 : 8, THEMES.home);
      I.box(1, 2, 3, 2, '#3a5a8a', true, 'BED'); I.obj(2.5, 4.6, own ? 'Sleep until morning' : 'Rent a bed ($25)', 'sleep', own ? 0 : 25, 44);
      I.box(own ? 11 : 7, 2, 2, 1, '#222', true, 'TV'); I.obj(own ? 12 : 8, 3.7, 'Watch the news', 'news', null, 42);
      if (own) { I.box(6, 2, 2, 1, '#5a4630', true, 'CLOTHES'); I.obj(7, 3.6, 'Change clothes', 'wardrobe', 0, 42); I.box(11, 5, 2, 1, '#6b5a40', true, 'DESK'); I.obj(12, 6.5, 'Save game', 'save', null, 44); I.box(7, 5, 3, 1, '#4a3a5a', true); I.box(1, 6, 2, 1, '#444', true, 'CACHE'); I.obj(2, 7.3, 'Weapon cache (free ammo, once a day)', 'cache', null, 44); }
      I.pts.floor = { x: 6 * TS, y: 5.5 * TS }; break;
    }
    case 'hospital': {
      I = new Interior(type, 16, 10, THEMES.hospital); I.box(6, 3, 4, 1, '#9ab', true, 'RECEPTION'); I.box(1, 2, 2, 2, '#bcd', true); I.box(13, 2, 2, 2, '#bcd', true);
      I.npc(8, 2.5, { role: 'nurse' }); I.npc(3, 6, { role: 'patient' }); I.obj(8, 4.8, 'Full treatment ($60)', 'heal', 60, 46); I.pts.floor = { x: 8 * TS, y: 6 * TS }; break;
    }
    case 'office': {
      I = new Interior(type, 14, 10, THEMES.home); I.box(2, 3, 3, 2, '#5a4630', true, 'DESK'); I.box(8, 3, 3, 2, '#5a4630', true, 'DESK'); I.box(11, 6, 2, 1, '#333', true, 'PRESS');
      I.npc(3.5, 5.6, { role: 'patron' }); I.obj(10, 6.2, 'Read the Ledger', 'news', null, 50); I.pts.floor = { x: 7 * TS, y: 6 * TS }; break;
    }
    case 'casino': {
      I = new Interior(type, 18, 12, THEMES.casino); for (let i = 0; i < 6; i++) { I.box(2 + i * 2, 3, 1, 1, '#c0a020', true, '7'); I.obj(2.5 + i * 2, 4.5, 'Slot machine ($20)', 'slots', 20, 36); }
      I.box(12, 7, 4, 2, '#1b5e20', true, 'FLIP'); I.obj(14, 9.5, 'Double or nothing ($100)', 'coinflip', 100, 46); I.box(2, 8, 5, 1, '#5a3a22', true, 'BAR'); I.npc(4, 7.6, { role: 'clerk' }); I.npc(9, 6, { role: 'patron' });
      I.pts.floor = { x: 9 * TS, y: 7 * TS }; break;
    }
    case 'garage': {
      I = new Interior(type, 16, 11, THEMES.garage); I.box(1, 2, 3, 3, '#444', true, 'LIFT'); I.box(12, 2, 3, 1, '#6a4a30', true, 'PARTS'); I.box(6, 6, 3, 2, '#3a3a40', true, 'TOOLS');
      I.npc(8, 3.6, { role: 'gus' }); I.obj(8, 5.2, 'Gus — "Drive up to my door to customise a ride."', 'info', 'Park a car at the garage door and press E from the driver seat to paint, upgrade and plate it.', 50); I.pts.floor = { x: 8 * TS, y: 7 * TS }; break;
    }
    case 'arena': {
      I = new Interior(type, 16, 12, THEMES.arena); I.decor.push({ x: 4, y: 4, w: 8, h: 5, col: '#6a2a2a' });
      for (let i = 0; i < 6; i++) I.npc(2 + i * 2.4, 3.2, { role: 'crowd' }); I.obj(8, 9.9, 'Enter the ring ($50)', 'fight', 50, 50); I.pts.floor = { x: 8 * TS, y: 6.5 * TS }; I.pts.ring = { x: 8 * TS, y: 6.5 * TS }; break;
    }
    case 'shop_armory': shop('FORT ARMORY', 'military'); break;
    case 'shop_duty': shop('DUTY FREE', 'airport'); break;
    case 'house': {
      const sd = (b && b.seed) || 1, pick = (a, i) => a[(sd >> i) % a.length], wallT = (x, y, w, h) => { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) I.t[(y + j) * 16 + x + i] = 1; };
      I = new Interior(type, 16, 11, THEMES.home); wallT(7, 2, 1, 5); wallT(7, 8, 1, 2); wallT(8, 6, 3, 1); wallT(13, 6, 2, 1);
      I.box(1, 2, 2, 3, pick(['#8a4a4a', '#4a6a8a', '#6a8a4a'], 2), true, 'SOFA'); I.box(4, 2, 2, 1, '#222', true, 'TV'); I.box(3, 6, 3, 2, '#6b4a2f', true, 'TABLE');
      I.box(9, 2, 3, 2, pick(['#3a5a8a', '#8a3a5a', '#5a8a3a'], 5), true, 'BED'); I.box(13, 2, 2, 1, '#5a4630', true, 'DRESSER');
      I.box(9, 8, 5, 1, '#8a8f99', true, 'KITCHEN'); I.box(14, 8, 1, 2, '#dfe3e8', true, 'FRIDGE');
      I.obj(10.5, 4.6, 'Sleep until morning', 'sleep', 0, 44); I.obj(5, 4.6, 'Watch TV', 'news', null, 44); I.obj(11.5, 9.6, 'Raid the fridge', 'info', 'You find leftovers, a half-eaten pie and a note: "Rent is due Friday."', 44);
      if (sd % 3 === 0) I.npc(4, 8.4, { role: 'patron' }); I.pts.floor = { x: 4 * TS, y: 5.5 * TS }; break;
    }
    case 'cabin': {
      I = new Interior(type, 11, 8, THEMES.wood); I.box(1, 2, 3, 2, '#7a3a2a', true, 'BED'); I.box(7, 2, 3, 1, '#4a3a30', true, 'FIREPLACE'); I.box(5, 5, 3, 2, '#6b4a2f', true, 'TABLE');
      I.obj(2.5, 4.6, 'Rest until morning', 'sleep', 0, 44); I.obj(8.5, 3.6, 'Warm up — save game', 'save', null, 44); I.pts.floor = { x: 5 * TS, y: 4 * TS }; break;
    }
    case 'lodge': {
      I = new Interior(type, 18, 11, THEMES.wood); I.box(1, 2, 4, 2, '#4a3a30', true, 'HEARTH'); I.box(7, 2, 6, 1, '#5a3a22', true, 'BAR'); I.box(14, 2, 3, 2, '#7a3a2a', true, 'BED'); I.box(3, 6, 3, 2, '#6b4a2f', true); I.box(9, 6, 3, 2, '#6b4a2f', true);
      I.npc(10, 2.6, { role: 'clerk' }); I.npc(4.5, 5.4, { role: 'patron' }); I.obj(10, 4.6, 'Order a drink', 'shop:bar', null, 46); I.obj(15.5, 4.6, 'Rent a room ($30)', 'sleep', 30, 44); I.obj(2.5, 4.6, 'Fireside — save game', 'save', null, 44); I.pts.floor = { x: 9 * TS, y: 6 * TS }; break;
    }
    case 'motel': {
      I = new Interior(type, 12, 8, THEMES.motel); I.box(1, 2, 3, 2, '#8a3a5a', true, 'BED'); I.box(6, 2, 2, 1, '#222', true, 'TV'); I.box(9, 2, 2, 2, '#5a4630', true, 'DESK'); I.npc(10, 5.4, { role: 'clerk' });
      I.obj(2.5, 4.6, 'Rent a room ($40)', 'sleep', 40, 44); I.obj(7, 3.6, 'Watch the news', 'news', null, 42); I.obj(10, 4.4, 'Save game at the desk', 'save', null, 44); I.pts.floor = { x: 6 * TS, y: 5 * TS }; break;
    }
    case 'hotel': {
      I = new Interior(type, 18, 11, THEMES.luxe); I.box(6, 2, 6, 1, '#5a4630', true, 'RECEPTION'); I.box(1, 2, 3, 3, '#7a2a4a', true, 'LOUNGE'); I.box(14, 2, 3, 3, '#2a4a7a', true, 'LOUNGE'); I.box(13, 7, 4, 1, '#5a3a22', true, 'BAR'); I.box(3, 7, 2, 2, '#6b4a2f', true);
      I.npc(9, 2.7, { role: 'clerk' }); I.npc(15, 6.4, { role: 'clerk' }); I.npc(4, 5.5, { role: 'patron' });
      I.obj(9, 4.6, 'Book a suite ($90) — sleep until morning', 'sleep', 90, 46); I.obj(15, 8.7, 'Order a drink', 'shop:bar', null, 44); I.obj(2.5, 5.8, 'Watch the news', 'news', null, 44); I.obj(6, 9.2, 'Suite service — save game', 'save', null, 44); I.pts.floor = { x: 9 * TS, y: 6 * TS }; break;
    }
    case 'mansion': {
      I = new Interior(type, 20, 13, THEMES.luxe); I.box(1, 2, 5, 3, '#7a2a4a', true, 'GRAND SOFA'); I.box(8, 2, 4, 1, '#222', true, 'HOME CINEMA'); I.box(14, 2, 5, 3, '#3a5a8a', true, 'MASTER BED'); I.box(8, 6, 4, 2, '#6b4a2f', true, 'DINING'); I.box(1, 8, 3, 4, '#2a7a9a', true, 'INDOOR POOL'); I.box(15, 8, 4, 1, '#6a6f79', true, 'KITCHEN'); I.box(15, 10, 2, 2, '#5a4630', true, 'PIANO');
      I.npc(10, 9.6, { role: 'patron' }); I.npc(6, 7, { role: 'guard' });
      I.obj(16.5, 5.6, 'Sleep in the master suite', 'sleep', 0, 46); I.obj(10, 3.8, 'Watch the news', 'news', null, 44); I.obj(8, 4.8, 'Wardrobe — free', 'wardrobe', 0, 44); I.obj(12.5, 10.6, 'Study desk — save game', 'save', null, 44); I.pts.floor = { x: 10 * TS, y: 7 * TS }; break;
    }
    case 'mall': {
      I = new Interior(type, 24, 14, THEMES.airport); I.box(1, 2, 6, 3, '#9a5ab0', true, 'THREADS'); I.box(9, 2, 6, 3, '#5a9ab0', true, 'MART'); I.box(17, 2, 6, 3, '#b0745a', true, 'FOOD COURT'); I.box(1, 8, 5, 3, '#4c5563', true, 'GUNS'); I.box(18, 8, 5, 3, '#6a6f79', true, 'BANK'); I.box(10, 7, 4, 3, '#2a7a9a', true, 'FOUNTAIN');
      I.npc(4, 5.4, { role: 'clerk' }); I.npc(12, 5.4, { role: 'clerk' }); I.npc(20, 5.4, { role: 'clerk' }); I.npc(3.5, 11.6, { role: 'clerk' }); for (let i = 0; i < 4; i++) I.npc(8 + i * 3, 12, { role: 'customer' });
      I.obj(4, 5.8, 'Threads — try clothes', 'wardrobe', 40, 46); I.obj(12, 5.8, 'Mart — browse', 'shop:shop_mart', null, 46); I.obj(20, 5.8, 'Food court', 'shop:shop_burger', null, 46); I.obj(3.5, 11.7, 'Gun counter', 'shop:shop_gun', null, 46); I.obj(20.5, 11.7, 'ATM', 'atm', null, 40); I.pts.floor = { x: 12 * TS, y: 11 * TS }; break;
    }
    case 'nightclub': {
      I = new Interior(type, 20, 13, THEMES.club); I.decor.push({ x: 5, y: 5, w: 10, h: 6, col: '#2a1050' }); I.box(8, 2, 4, 1, '#222', true, 'DJ'); I.box(1, 2, 5, 1, '#5a2a6a', true, 'BAR'); I.box(15, 2, 4, 3, '#3a1a5a', true, 'VIP'); I.box(1, 8, 2, 3, '#4a2a6a', true); I.box(17, 8, 2, 3, '#4a2a6a', true);
      I.npc(3, 3.6, { role: 'clerk' }); I.npc(10, 3.4, { role: 'patron' }); for (let i = 0; i < 6; i++) I.npc(6 + (i % 3) * 3.2, 6 + Math.floor(i / 3) * 2.4, { role: 'patron' });
      I.obj(3, 4.8, 'Order a drink', 'shop:bar', null, 46); I.obj(17, 5.8, 'VIP booth — $200 slots', 'slots', 20, 44); I.obj(10, 11, 'Hit the dance floor', 'jukebox', null, 56); I.pts.floor = { x: 10 * TS, y: 11 * TS }; break;
    }
    case 'church': {
      I = new Interior(type, 14, 12, THEMES.church); I.box(5, 2, 4, 1, '#c9a24a', true, 'ALTAR'); for (let r = 0; r < 4; r++) { I.box(2, 5 + r * 1.5 | 0, 4, 1, '#6b4a2f', true); I.box(8, 5 + r * 1.5 | 0, 4, 1, '#6b4a2f', true); }
      I.npc(7, 3.6, { role: 'patron' }); I.npc(4, 10, { role: 'patron' }); I.obj(7, 4.2, 'Light a candle', 'info', 'You light a candle. Somewhere, a very forgiving person is almost certainly not watching.', 46); I.pts.floor = { x: 7 * TS, y: 8 * TS }; break;
    }
    case 'terminal': {
      I = new Interior(type, 28, 15, THEMES.airport); I.box(2, 2, 10, 1, '#5a6a80', true, 'CHECK-IN'); I.box(16, 2, 4, 3, '#4a6a5a', true, 'SECURITY'); I.box(22, 2, 5, 1, '#8a6a3a', true, 'DUTY FREE'); I.box(1, 9, 5, 2, '#7a5a3a', true, 'CAFE'); I.box(22, 9, 5, 2, '#4a5a7a', true, 'GATES A–C'); I.box(10, 7, 6, 1, '#6a7a8a', true, 'BENCHES'); I.box(10, 10, 6, 1, '#6a7a8a', true, 'BENCHES');
      I.npc(5, 3.6, { role: 'agent' }); I.npc(9, 3.6, { role: 'agent' }); I.npc(18, 5.6, { role: 'guard' }); I.npc(24, 3.6, { role: 'clerk' }); I.npc(3.5, 11.6, { role: 'clerk' }); for (let i = 0; i < 5; i++) I.npc(6 + i * 3.4, 8.6 + (i % 2) * 2.4, { role: 'customer' });
      I.obj(7, 4.8, 'Departures — buy a ticket to another city', 'flight', null, 52); I.obj(24.5, 4.4, 'Duty free', 'shop:shop_duty', null, 46); I.obj(3.5, 12, 'Cafe', 'shop:shop_burger', null, 44); I.obj(24, 11.8, 'Gates — "boarding passes only"', 'info', 'Beyond the gates: jetways, a lot of fenced tarmac and several very serious people with radios.', 46); I.obj(13, 12.6, 'ATM', 'atm', null, 40); I.pts.floor = { x: 14 * TS, y: 9 * TS }; break;
    }
    case 'atc': {
      I = new Interior(type, 12, 10, THEMES.airport); I.box(1, 2, 4, 2, '#223', true, 'RADAR'); I.box(7, 2, 4, 2, '#223', true, 'COMMS'); I.box(4, 6, 4, 1, '#5a6a80', true, 'DESK'); I.npc(3, 4.5, { role: 'pilot' }); I.npc(9, 4.5, { role: 'pilot' });
      I.obj(3, 4.9, 'Radar scope', 'info', 'A dozen green blips crawl across the screen. One of them is you, probably. Skyline never sleeps.', 44); I.obj(9, 4.9, 'Flight status board', 'flight', null, 46); I.pts.floor = { x: 6 * TS, y: 7 * TS }; break;
    }
    case 'hangar': {
      I = new Interior(type, 20, 12, THEMES.garage); I.box(4, 3, 12, 4, '#8a929a', true, 'JET (UNDER MAINTENANCE)'); I.box(1, 9, 3, 2, '#6a4a30', true, 'PARTS'); I.box(16, 9, 3, 2, '#3a3a40', true, 'TOOLS'); I.npc(8, 8.6, { role: 'clerk' }); I.npc(13, 8.8, { role: 'customer' });
      I.obj(9, 9.8, 'Mechanic — "Not hiring, not talking."', 'info', 'The mechanic wipes his hands. "Don\'t touch the jet. Seriously. Last guy who did is still in orbit."', 46); I.pts.floor = { x: 10 * TS, y: 8 * TS }; break;
    }
    case 'barracks': {
      I = new Interior(type, 18, 10, THEMES.military); for (let i = 0; i < 4; i++) { I.box(1 + i * 4, 2, 2, 2, '#4a5a3a', true, 'BUNK'); I.box(1 + i * 4, 6, 2, 2, '#4a5a3a', true, 'BUNK'); } I.npc(5, 5, { role: 'soldier' }); I.npc(12, 5, { role: 'soldier' });
      I.obj(16.5, 4.5, 'Footlocker — spare ammo', 'cache', null, 44); I.pts.floor = { x: 9 * TS, y: 5 * TS }; break;
    }
    case 'hq': {
      I = new Interior(type, 22, 12, THEMES.military); I.box(7, 4, 8, 3, '#3a4a30', true, 'WAR TABLE'); I.box(1, 2, 4, 2, '#555', true, 'COMMS'); I.box(17, 2, 4, 2, '#555', true, 'MAPS'); I.box(1, 8, 4, 2, '#5a4630', true, 'DESK'); I.box(17, 8, 4, 2, '#4c5563', true, 'ARMORY REQ.');
      I.npc(3, 5, { role: 'soldier' }); I.npc(19, 5, { role: 'soldier' }); I.npc(11, 9, { role: 'sergeant' }); I.npc(8, 8, { role: 'soldier' });
      I.obj(11, 7.6, 'War table — "Operation Tidewater"', 'info', 'Red pins cover Port Meridian. A sticky note says: "DO NOT let the civilians find out about the Aurelia contract."', 46); I.obj(19, 10.6, 'Armory requisition', 'shop:shop_armory', null, 46); I.pts.floor = { x: 11 * TS, y: 8 * TS }; break;
    }
    default: shop('SHOP'); break;
  }
  I.render(); I.building = b; return I;
}
