// ===== atlas.js — the registry of every named place the player has ever generated / discovered =====
// * Every settlement, district, landmark, airport, outpost … that the infinite generator produces is registered here (once, by key).
// * The registry is saved with the game, so after a reload the named places / fast-travel / flight lists come back EXACTLY as generated
//   (the blocks themselves are re-derived from the seed, so they are identical anyway).
// * It is bucketed in a coarse grid (collision-free integer keys) so the world map can ask "what is inside this rectangle?" in O(visible).
import { bkey } from './keys.js';

const CELL = 2048; // px per bucket

/** category → { tier (label priority, 0 = most important), icon, colour } */
export const CATS = {
  province: { tier: 0, icon: '', col: '#ffffffcc' },
  metro: { tier: 1, icon: '★', col: '#ffe14a' }, city: { tier: 2, icon: '★', col: '#ffe14a' }, town: { tier: 3, icon: '●', col: '#ffffff' }, village: { tier: 4, icon: '•', col: '#d8e0f0' },
  district: { tier: 5, icon: '', col: '#c8d4ff' },
  airport: { tier: 5, icon: '✈', col: '#8fd8ff' }, outpost: { tier: 5, icon: '⚑', col: '#ff9a7a' }, port: { tier: 5, icon: '⚓', col: '#7fe0d0' },
  resort: { tier: 5, icon: '☀', col: '#ffb3e6' }, casino: { tier: 5, icon: '♦', col: '#ffd24a' }, stadium: { tier: 5, icon: '◎', col: '#b6ff9a' },
  industrial: { tier: 5, icon: '⚙', col: '#c0c6d0' }, stunt: { tier: 6, icon: '▲', col: '#ff8a4a' }, ghost: { tier: 6, icon: '☠', col: '#c9b8a0' }, quarry: { tier: 6, icon: '⛏', col: '#d2b48c' },
  landmark: { tier: 6, icon: '◆', col: '#ffffff' }, hospital: { tier: 7, icon: '+', col: '#ff7f95' }, police: { tier: 7, icon: '★', col: '#7fb8ff' }, hotel: { tier: 7, icon: '▣', col: '#e8d8ff' },
  mall: { tier: 7, icon: '▣', col: '#9fe8e0' }, park: { tier: 7, icon: '♣', col: '#9fe89f' }, church: { tier: 7, icon: '✝', col: '#f0e8d8' },
  service: { tier: 7, icon: '⛽', col: '#ffe9a0' }, rural: { tier: 7, icon: '◇', col: '#cfe6b0' }, shop: { tier: 8, icon: '▪', col: '#ddd' },
};
/** zoom (map pixels per tile) at which each tier starts to show its labels */
export const TIER_ZOOM = [0, 0, 0.012, 0.045, 0.1, 0.22, 0.42, 0.8, 1.6];

export function categorize(key, name = '') {
  const n = String(name).toLowerCase();
  if (/airport|airstrip|aerodrome|airfield|\baero\b|runway|apron/.test(n)) return 'airport';
  if (/outpost|fortress|\bfort\b|garrison|barracks|citadel|army|military/.test(n)) return 'outpost';
  if (/casino/.test(n)) return 'casino';
  if (/stadium|arena|dome|speedway/.test(n)) return 'stadium';
  if (/harbou?r|\bport\b|docks|marina|pier|wharf|cranes/.test(n)) return 'port';
  if (/resort|boardwalk|beach club/.test(n)) return 'resort';
  if (/quarry|\bmine\b|copper|pit\b/.test(n)) return 'quarry';
  if (/industrial|works|foundry|refinery|power plant|freight|mill\b|factory/.test(n)) return 'industrial';
  if (/stunt|ramp/.test(n)) return 'stunt';
  if (/ghost|abandoned|ruins/.test(n)) return 'ghost';
  if (/hospital|clinic|medical/.test(n)) return 'hospital';
  if (/police|sheriff|\bpd\b|ranger/.test(n)) return 'police';
  if (/mall|galleria/.test(n)) return 'mall';
  if (/hotel|grand|inn\b|motel|lodge/.test(n)) return 'hotel';
  if (/park|green|plaza|fountain|lake|summit|mount|canyon/.test(n)) return /park|green|plaza/.test(n) ? 'park' : 'landmark';
  if (/chapel|church|mission|cathedral/.test(n)) return 'church';
  if (/truck|gas|diner|fuel|stop\b|services/.test(n)) return 'service';
  if (/lighthouse|mast|wind|solar|cabin|camp|shack|farm|ranch|bar\b|stilt|nest|hermit/.test(n)) return 'rural';
  return 'landmark';
}

export class Atlas {
  constructor(W) { this.W = W; this.sites = new Map(); this.grid = new Map(); this.rev = 0; }
  _cell(x, y) { return bkey(Math.floor(x / CELL), Math.floor(y / CELL)); }
  has(key) { return this.sites.has(key); }
  get(key) { return this.sites.get(key); }
  /** register a place once (first registration wins → names never change once seen) */
  add(s) {
    if (!s || !s.key || this.sites.has(s.key)) return null;
    const cat = s.cat || categorize(s.key, s.name); const def = CATS[cat] || CATS.landmark;
    const site = { key: s.key, name: s.name, x: Math.round(s.x), y: Math.round(s.y), cat, tier: def.tier, fast: !!s.fast };
    this.sites.set(site.key, site);
    const ck = this._cell(site.x, site.y); let a = this.grid.get(ck); if (!a) { a = []; this.grid.set(ck, a); } a.push(site);
    this.rev++;
    const W = this.W;
    if (W && !W.pois[site.key]) W.pois[site.key] = { x: site.x, y: site.y, name: site.name, key: site.key, cat };
    return site;
  }
  /** all sites whose position lies inside the px rectangle */
  query(x0, y0, x1, y1, out) {
    const cx1 = Math.floor(x1 / CELL), cy1 = Math.floor(y1 / CELL);
    for (let cy = Math.floor(y0 / CELL); cy <= cy1; cy++) for (let cx = Math.floor(x0 / CELL); cx <= cx1; cx++) {
      const a = this.grid.get(bkey(cx, cy)); if (!a) continue;
      for (let i = 0; i < a.length; i++) { const s = a[i]; if (s.x >= x0 && s.x <= x1 && s.y >= y0 && s.y <= y1) out.push(s); }
    }
    return out;
  }
  toJSON() { const o = []; for (const s of this.sites.values()) o.push([s.key, s.name, s.x, s.y, s.cat, s.fast ? 1 : 0]); return o; }
  /** restore a saved registry; the fast-travel / flight lists are rebuilt from it */
  load(arr) {
    if (!Array.isArray(arr)) return;
    for (const r of arr) {
      if (!Array.isArray(r) || r.length < 5) continue;
      const s = this.add({ key: r[0], name: r[1], x: r[2], y: r[3], cat: r[4], fast: !!r[5] });
      if (s && s.fast) this.W.addDestination(s);
    }
  }
}
