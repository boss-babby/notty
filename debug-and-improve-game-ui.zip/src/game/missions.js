// ===== missions.js — story mission state machine + side activities (taxi, delivery, vigilante, race, arena, theft list) =====
import { MISSIONS, WEAPONS, ENDINGS, THEFT_LIST, VEHICLES, WEAPON_ORDER } from './data.js';
import { spawnActor, spawnVehicle } from './actors.js';
import { setStars } from './wanted.js';
import { randomLaneSpawn } from './ai.js';
import { rnd, pick, chance, TAU } from './util.js';
import { TS } from './world.js';
import { AIR_JOBS, startAirJob, updateAirJob } from './airjobs.js';

const hyp = Math.hypot;
export function initMissions(g) { g.story = { done: {}, flags: {}, complete: false }; g.mission = null; g.obj = null; g.cut = null; g.side = null; g.arena = null; g.theft = { need: THEFT_LIST.slice(), done: [] }; }
export const missionAvailable = (g, d) => !g.story.done[d.id] && (!d.after || g.story.done[d.after]);
export function resolve(g, at, dx = 0, dy = 0) {
  const m = g.mission; let p = null;
  if (at && at[0] === '@') { if (at === '@last') p = m && m.last; else if (g.scene) p = g.scene.pts[at.slice(1)]; }
  else if (at) p = g.world.pois[at];
  if (!p && at && at[0] === '@') p = g.player;
  return p ? { x: p.x + dx, y: p.y + dy } : null;
}
export function missionMarkers(g) {
  const out = [];
  if (!g.mission) for (const d of MISSIONS) if (missionAvailable(g, d) && !d.auto) { const p = g.world.pois[d.at]; if (p) out.push({ x: p.x, y: p.y, label: d.title, kind: 'mission', color: '#ffe14a' }); }
  if (!g.mission && !g.side && g.world.pois.raceStart) out.push({ x: g.world.pois.raceStart.x, y: g.world.pois.raceStart.y, label: 'Street Race', kind: 'race', color: '#7cff4f' });
  if (g.obj && g.obj.x !== undefined) out.push({ x: g.obj.x, y: g.obj.y, label: g.obj.text, kind: 'obj', color: '#ffe14a' });
  if (g.mission && g.mission.refs.vehs) for (const v of g.mission.refs.vehs) if (v.on && !v.wreck) out.push({ x: v.x, y: v.y, kind: 'foe', color: '#ff3b5c' });
  return out;
}

export function startMission(g, def) {
  if (g.mission || g.side) return;
  g.mission = { def, i: -1, step: null, refs: { vehs: [] }, ents: [], t: 0, flags: {}, last: null, spotted: false, started: g.time, prog: 0 };
  g.titleCard = { text: def.title, sub: def.side ? 'SIDE JOB' : 'MISSION', t: 3 }; g.audio.sfx('ui');
  next(g);
}
export function advanceMission(g) { next(g); }
function next(g) {
  const m = g.mission; if (!m) return;
  if (m.step && STEPS[m.step.t].end) STEPS[m.step.t].end(g, m, m.step);
  do { m.i++; } while (m.i < m.def.steps.length && m.def.steps[m.i].if && g.story.flags[m.def.steps[m.i].if[0]] !== m.def.steps[m.i].if[1]);
  if (m.i >= m.def.steps.length) return complete(g);
  m.step = { ...m.def.steps[m.i], prog: 0, t0: 0 };
  m.limit = m.step.limit || 0; m.step.done = false;
  STEPS[m.step.t].begin(g, m, m.step);
  if (g.obj && m.step.text) g.obj.text = m.step.text;
}
function setObj(g, text, x, y) { g.obj = { text, x, y }; }
export function complete(g) {
  const m = g.mission, d = m.def; let cash = d.reward?.cash || 0;
  if (d.id === 'm4' && !m.spotted) { cash += 500; g.toast('Stealth bonus +$500', '#7cff4f'); }
  g.cash += cash; g.stats.cashEarned += cash;
  if (d.reward?.rep) for (const k in d.reward.rep) g.rep[k] = Math.max(-100, Math.min(100, g.rep[k] + d.reward.rep[k]));
  if (!d.side) { g.story.done[d.id] = true; g.stats.missions++; }
  g.completeCard = { title: d.title, cash, t: 4.5 }; g.audio.sfx('complete'); g.news && g.news('mission', d.title);
  cleanup(g); g.mission = null; g.obj = null; g.onMissionDone && g.onMissionDone(d);
}
export function failMission(g, why) {
  const m = g.mission; if (!m) return;
  g.failCard = { title: m.def.title, why, t: 4 }; g.audio.sfx('fail'); cleanup(g); g.mission = null; g.obj = null; g.cut = null;
}
function cleanup(g) {
  const m = g.mission; if (!m) return;
  for (const a of g.actors) if (a.on && a.mis) { if (a.dead) a.mis = false; else if (hyp(a.x - g.player.x, a.y - g.player.y) > 500 || a.ally) a.on = false; else a.mis = false; }
  for (const v of g.vehicles) if (v.on && v.mis) { v.mis = false; if (!v.driver && v !== g.player.veh && hyp(v.x - g.player.x, v.y - g.player.y) > 600) v.on = false; if (v.ai === 'hunter' || v.ai === 'racer') { v.ai = 'traffic'; v.mode = 'random'; } }
  g.pickups = g.pickups.filter((p) => p.type !== 'mission'); g.boss = null; g.passenger = null; g.race = null;
}
export function abortMission(g) { if (g.mission) { cleanup(g); g.mission = null; g.obj = null; } if (g.side) { g.side = null; } }

// ---------- helpers ----------
function enemyActor(g, fac, w, x, y, o = {}) {
  const type = fac === 'pd' ? 'cop' : fac === 'kes' || fac === 'vip' ? 'gang' : 'gang';
  const a = spawnActor(g, o.type || type, x, y, { fac, w, mis: true, inside: g.scene ? g.scene.id : null, hp: o.hp, armor: o.armor });
  if (a) { a.vis = o.vis || 420; a.noLoot = false; if (o.combat) { a.st = 'combat'; a.alert = 1; a.target = g.player; } else { a.st = g.scene ? 'stay' : 'idle'; a.t = 2; } }
  return a;
}
function ringPoint(g, c, r) {
  for (let k = 0; k < 20; k++) {
    const a = Math.random() * TAU, d = r * (0.3 + Math.random() * 0.7), x = c.x + Math.cos(a) * d, y = c.y + Math.sin(a) * d;
    if (g.scene ? !g.scene.solidAt(x, y) : g.world.walkPx(x, y, {})) return { x, y };
  }
  return { x: c.x, y: c.y };
}
function spawnCar(g, m, type, x, y, o) { const v = spawnVehicle(g, type, x, y, o.a || 0, { ...o, mis: true }); if (v) { m.refs.vehs.push(v); } return v; }
const alive = (list) => list.filter((a) => a.on && !a.dead).length;

// ---------- step handlers ----------
const STEPS = {
  say: { begin(g, m, s) { g.cut = { lines: s.lines, i: 0, cam: s.cam ? resolve(g, s.cam) : null, t: 0 }; }, update(g) { return !g.cut; } },
  give: { begin(g, m, s) { g.giveWeapon(s.w, s.ammo); g.toast('Received ' + WEAPONS[s.w].n, '#7cff4f'); s.done = true; }, update() { return true; } },
  veh: {
    begin(g, m, s) {
      const p = resolve(g, s.at, s.dx, s.dy), ang = Math.random() * 0.2; let v = spawnCar(g, m, s.veh, p.x, p.y, { a: ang, color: s.color, hot: false });
      if (v) { v.hot = false; m.refs.veh = v; setObj(g, s.text, v.x, v.y); }
    },
    update(g, m) { const v = m.refs.veh; if (!v || !v.on || v.wreck) { failMission(g, 'The vehicle was destroyed.'); return false; } g.obj.x = v.x; g.obj.y = v.y; return g.player.veh === v; },
  },
  goto: {
    begin(g, m, s) { const p = resolve(g, s.at, s.dx, s.dy); s.pos = p; setObj(g, s.text, p.x, p.y); },
    update(g, m, s, dt) {
      const p = g.player, d = hyp(p.x - s.pos.x, p.y - s.pos.y);
      if (s.veh && !p.veh) { g.obj.sub = 'Get in a vehicle'; } else g.obj.sub = '';
      if (s.limit) { m.limit -= dt; if (m.limit <= 0) { failMission(g, 'Out of time.'); return false; } }
      return d < (p.veh ? 110 : 70) && (!s.veh || p.veh);
    },
  },
  enter: { begin(g, m, s) { const p = g.world.pois[s.poi]; setObj(g, s.text, p.x, p.y); }, update(g, m, s) { if (g.scene && g.scene.type === s.poi) return true; if (!g.scene) { const p = g.world.pois[s.poi]; g.obj.x = p.x; g.obj.y = p.y; } else g.obj.x = undefined; return false; } },
  exit: { begin(g, m, s) { const b = g.scene && g.scene.building; if (g.scene) setObj(g, s.text, g.scene.exitDoor.x, g.scene.exitDoor.y); else s.done = true; void b; }, update(g) { if (g.scene) { g.obj.x = g.scene.exitDoor.x; g.obj.y = g.scene.exitDoor.y; } return !g.scene; } },
  enemies: {
    begin(g, m, s) {
      const c = resolve(g, s.at), list = []; s.list = list;
      for (let i = 0; i < s.n; i++) { const pt = ringPoint(g, c, s.r || 120), a = enemyActor(g, s.fac, s.w[i % s.w.length], pt.x, pt.y, { combat: !!s.ring, type: s.guard ? 'guard' : undefined }); if (a) { list.push(a); if (s.ring) { const ang = (i / s.n) * TAU; a.x = c.x + Math.cos(ang) * (s.r || 160); a.y = c.y + Math.sin(ang) * (s.r || 160); } } }
      setObj(g, s.text, c.x, c.y);
    },
    update(g, m, s) { const n = alive(s.list); g.obj.sub = n + ' left'; const t = s.list.find((a) => a.on && !a.dead); if (t) { g.obj.x = t.x; g.obj.y = t.y; } m.last = { x: g.player.x, y: g.player.y }; return n === 0; },
  },
  pickup: {
    begin(g, m, s) { const p = resolve(g, s.at, s.dx, s.dy); g.pickups.push({ type: 'mission', x: p.x, y: p.y, label: s.label || 'item', life: 1e9, inside: g.scene ? g.scene.id : null }); s.pos = p; setObj(g, s.text, p.x, p.y); },
    update(g, m, s) { return !!s.got; },
  },
  wanted: { begin(g, m, s) { if (g.wanted.stars < s.stars) setStars(g, s.stars); setObj(g, s.text); }, update(g) { g.obj.x = undefined; return g.wanted.stars === 0; } },
  chase: {
    begin(g, m, s) {
      const p = resolve(g, s.at), v = spawnCar(g, m, s.veh, p.x, p.y, { color: s.color, ai: 'traffic', npc: 'kes', a: 0 });
      if (v) { v.mode = 'flee'; v.cruise = 330; v.speedMul = 0.85; v.dir = 0; v.mis = true; m.refs.target = v; v.hot = true; }
      setObj(g, s.text, p.x, p.y);
    },
    update(g, m) { const v = m.refs.target; if (!v) return true; g.obj.x = v.x; g.obj.y = v.y; if (v.wreck) { m.last = { x: v.x, y: v.y }; return true; } if (hyp(v.x - g.player.x, v.y - g.player.y) > 1500) { failMission(g, 'The courier got away.'); return false; } const d = hyp(v.x - g.player.x, v.y - g.player.y); g.obj.sub = Math.round(d / 10) + 'm'; return false; },
  },
  stealth: {
    begin(g, m, s) {
      const c = resolve(g, s.at), guards = []; s.list = guards;
      for (let i = 0; i < s.n; i++) {
        const a = enemyActor(g, 'kes', 'pistol', c.x + rnd(-120, 120), c.y + rnd(-80, 100), { type: 'guard', vis: 360 }); if (!a) continue;
        a.fov = 1.7; a.patrol = [0, 1, 2].map(() => ({ x: c.x + rnd(-150, 150), y: c.y + rnd(-90, 110) })); a.st = 'idle'; a.dmgMul = 0.5; guards.push(a);
      }
      const p = resolve(g, s.pick); g.pickups.push({ type: 'mission', x: p.x, y: p.y, label: 'ledger', life: 1e9 }); setObj(g, s.text, p.x, p.y); s.pos = p;
    },
    update(g, m, s) { if (m.spotted && !s.warned) { s.warned = true; g.toast('You were spotted! Fight your way out.', '#ff7788'); } g.obj.sub = m.spotted ? 'SPOTTED' : 'Unseen'; return !!s.got; },
  },
  escortcar: {
    begin(g, m, s) { g.passenger = 'Nina'; const p = resolve(g, s.to); s.pos = p; setObj(g, s.text, p.x, p.y); s.spawnT = 0; s.made = 0; m.refs.hunters = []; },
    update(g, m, s, dt) {
      const pl = g.player, v = pl.veh;
      if (!v) { s.out = (s.out || 0) + dt; g.obj.sub = 'Get back in the car! ' + Math.ceil(20 - s.out); if (s.out > 20) { failMission(g, 'You abandoned Nina.'); return false; } } else s.out = 0;
      if (m.refs.veh && (!m.refs.veh.on || m.refs.veh.wreck)) { failMission(g, 'The car was destroyed.'); return false; }
      s.spawnT -= dt; const act = m.refs.hunters.filter((h) => h.on && !h.wreck).length;
      if (s.spawnT <= 0 && act < 2 && s.made < s.chasers + 3 && v) { s.spawnT = 3; const r = randomLaneSpawn(g, 600, 900); if (r) { const h = spawnCar(g, m, pick(['sedan', 'muscle']), r.x, r.y, { a: r.dir * Math.PI / 2, ai: 'hunter', npc: 'kes', gunner: true, color: '#7a1020' }); if (h) { h.dir = r.dir; m.refs.hunters.push(h); s.made++; } } }
      g.obj.x = s.pos.x; g.obj.y = s.pos.y; return v && hyp(pl.x - s.pos.x, pl.y - s.pos.y) < 110;
    },
    end(g) { g.passenger = null; },
  },
  choice: { begin(g, m, s) { g.ui.choice(s.prompt, s.options, (o) => { g.story.flags[s.key] = o.val; if (o.cash) { g.cash += o.cash; g.toast('+$' + o.cash, '#7cff4f'); } if (o.rep) for (const k in o.rep) g.rep[k] = Math.max(-100, Math.min(100, g.rep[k] + o.rep[k])); s.chosen = true; }); }, update(g, m, s) { return !!s.chosen; } },
  hold: {
    begin(g, m, s) { const p = resolve(g, s.at, s.dx, s.dy); s.pos = p; setObj(g, s.text, p.x, p.y); },
    update(g, m, s, dt) {
      const p = g.player, near = hyp(p.x - s.pos.x, p.y - s.pos.y) < 60; g.hold = near ? { prog: s.prog / s.secs } : null;
      if (near && g.input.down('interact')) { s.prog += dt; if (Math.random() < 0.2) g.audio.sfx('beep', p.x, p.y, 0.4); } else s.prog = Math.max(0, s.prog - dt * 2);
      g.obj.sub = near ? 'Hold E' : '';
      if (s.prog >= s.secs) { g.hold = null; g.explode(s.pos.x, s.pos.y - 30, 90, 20, { by: null, fac: 'pl' }); g.cam.shake = 14; setStars(g, Math.max(g.wanted.stars, 3)); return true; }
      return false;
    },
    end(g) { g.hold = null; },
  },
  survive: {
    begin(g, m, s) {
      const c = resolve(g, s.at); s.c = c; s.time = s.secs; s.wave = 0; s.list = []; s.wt = 1; setObj(g, s.text, c.x, c.y);
      if (s.allies) { if (g.story.flags.tiny === 'spared') { for (let i = 0; i < s.allies; i++) { const a = spawnActor(g, 'gang', c.x + rnd(-60, 60), c.y + rnd(40, 90), { fac: 'pl', w: 'smg', mis: true }); if (a) { a.ally = true; a.look.shirt = '#7cff4f'; } } g.hasAllies = true; g.toast('Vipers arrive to help!', '#7cff4f'); } else g.toast('You are on your own.', '#aaa'); }
    },
    update(g, m, s, dt) {
      s.time -= dt; s.wt -= dt; g.obj.sub = Math.ceil(Math.max(0, s.time)) + 's';
      if (s.wt <= 0 && s.time > 3) { s.wt = s.every; for (let i = 0; i < s.perWave; i++) { const pt = g.scene ? ringPoint(g, g.scene.pts.floor || s.c, 150) : (() => { const a = Math.random() * TAU; return g.world.randomWalkable(s.c.x + Math.cos(a) * 340, s.c.y + Math.sin(a) * 340, 120) || s.c; })(); const e = enemyActor(g, s.fac, pick(s.w), pt.x, pt.y, { combat: true, type: s.fac === 'pd' ? 'swat' : undefined }); if (e) s.list.push(e); } }
      if (!g.scene && hyp(g.player.x - s.c.x, g.player.y - s.c.y) > 650 && s.fac === 'kes') { s.away = (s.away || 0) + dt; g.obj.sub = 'Return to the safehouse!'; if (s.away > 15) { failMission(g, 'You left the safehouse.'); return false; } } else s.away = 0;
      return s.time <= 0;
    },
    end(g) { g.hasAllies = false; },
  },
  race: {
    begin(g, m, s) { startRace(g, m, s); }, update(g, m, s, dt) { return raceUpdate(g, m, s, dt); }, end(g) { g.race = null; },
  },
  boss: {
    begin(g, m, s) {
      const c = resolve(g, s.at), b = enemyActor(g, 'kes', 'smg', c.x, c.y - 40, { hp: s.hp, armor: s.armor, combat: true, vis: 600 }); s.mins = [];
      if (b) { b.boss = true; b.look.shirt = '#ffffff'; b.look.shades = true; b.look.style = 0; b.dmgMul = 0.7; b.name = s.name; g.boss = b; s.b = b; b.noLoot = true; }
      for (let i = 0; i < s.minions; i++) { const pt = ringPoint(g, c, 140), a = enemyActor(g, 'kes', pick(['pistol', 'smg']), pt.x, pt.y, { combat: true }); if (a) s.mins.push(a); }
      setObj(g, s.text, c.x, c.y);
    },
    update(g, m, s) {
      const b = s.b; if (!b) return true; g.obj.x = b.x; g.obj.y = b.y;
      if (!s.phase2 && b.hp < b.max * 0.5) { s.phase2 = true; b.wid = 'shotgun'; b.wdef = WEAPONS.shotgun; b.speedMul = 1.15; g.toast(s.name + ' calls for backup!', '#ff5566'); for (let i = 0; i < 3; i++) { const pt = ringPoint(g, b, 200), a = enemyActor(g, 'kes', 'smg', pt.x, pt.y, { combat: true }); if (a) s.mins.push(a); } }
      return b.dead;
    },
    end(g) { g.boss = null; },
  },
  target: {
    begin(g, m, s) {
      const c = resolve(g, s.at), t = enemyActor(g, 'kes', 'pistol', c.x, c.y, { vis: 300, hp: 90 }); s.guards = [];
      if (t) { t.look.shirt = '#f5f5f5'; t.look.shades = true; t.look.style = 0; t.fov = 2; t.patrol = [{ x: c.x, y: c.y - 130 }, { x: c.x, y: c.y + 130 }]; t.alertFast = false; t.noLoot = true; s.tg = t; }
      s.gl = []; for (let i = 0; i < (m.def.steps[m.i].guards || 3); i++) { const pt = ringPoint(g, c, 90), a = enemyActor(g, 'kes', 'smg', pt.x, pt.y, { vis: 320 }); if (a) { a.patrol = [{ x: pt.x, y: pt.y - 100 }, { x: pt.x, y: pt.y + 100 }]; s.gl.push(a); } }
      setObj(g, s.text, c.x, c.y);
    },
    update(g, m, s) { const t = s.tg; if (!t) return true; g.obj.x = t.x; g.obj.y = t.y; g.obj.sub = Math.round(hyp(t.x - g.player.x, t.y - g.player.y) / 10) + 'm'; return t.dead; },
  },
  ending: { begin(g, m, s) { const e = ENDINGS[g.story.flags.ending || 'kill']; g.story.complete = true; g.ui.ending(e); s.shown = true; }, update(g, m, s) { return s.shown && !g.ui.endingOpen; } },
};

// ---------- race (story + side) ----------
const RACE = [[6, 5], [8, 5], [8, 3], [4, 3], [4, 6], [6, 6], [6, 4]];
function startRace(g, m, s) {
  const pts = RACE.map(([cx, cy]) => ({ x: cx * 512 + 64, y: cy * 512 + 64 })), start = g.world.pois.raceStart;
  g.race = { pts, i: 0, time: s.time || 80, rival: null, rivalI: 0, t: 0, side: !!(m && m.def.side) };
  const rv = spawnCar(g, m, 'sports', start.x + 30, start.y - 8, { a: Math.PI / 2, ai: 'racer', npc: 'vip', color: '#7cff4f' });
  if (rv) { rv.hot = true; rv.speedMul = 0.88; g.race.rival = rv; rv.cpI = 0; }
  g.race.go = 3; setObj(g, s.text || 'Race!', pts[0].x, pts[0].y);
  if (g.player.veh) { g.player.veh.vx = g.player.veh.vy = 0; }
}
function raceUpdate(g, m, s, dt) {
  const R = g.race; if (!R) return true;
  if (R.go > 0) { R.go -= dt; if (g.rival) return false; if (R.rival) { R.rival.thr = 0; R.rival.brk = 1; R.rival.ai = 'none'; } g.obj.sub = 'GET READY ' + Math.ceil(R.go); if (R.go <= 0) { if (R.rival) R.rival.ai = 'racer'; g.toast('GO!', '#7cff4f'); } return false; }
  R.t += dt; R.time -= dt;
  if (R.time <= 0) { failMission(g, 'Out of time.'); return false; }
  const p = g.player, cp = R.pts[R.i];
  if (!p.veh) { g.obj.sub = 'Get back in a vehicle!'; } else g.obj.sub = Math.ceil(R.time) + 's · CP ' + (R.i + 1) + '/' + R.pts.length;
  g.obj.x = cp.x; g.obj.y = cp.y;
  if (hyp(p.x - cp.x, p.y - cp.y) < 120) { R.i++; g.audio.sfx('pickup'); if (R.i >= R.pts.length) { if (R.rival && R.rivalI < R.pts.length && false) return false; return true; } }
  const rv = R.rival;
  if (rv && rv.on) {
    const rc = R.pts[Math.min(R.rivalI, R.pts.length - 1)]; rv.tgt = rc; if (hyp(rv.x - rc.x, rv.y - rc.y) < 110) { R.rivalI++; if (R.rivalI >= R.pts.length) { failMission(g, 'The Vipers beat you to the line.'); return false; } }
    const lead = R.rivalI - R.i; rv.speedMul = lead > 0 ? 0.75 : lead < 0 ? 0.95 : 0.86;
  }
  return false;
}

// ---------- update ----------
export function updateMissions(g, dt) {
  const m = g.mission, p = g.player;
  if (g.titleCard) { g.titleCard.t -= dt; if (g.titleCard.t <= 0) g.titleCard = null; }
  if (g.completeCard) { g.completeCard.t -= dt; if (g.completeCard.t <= 0) g.completeCard = null; }
  if (g.failCard) { g.failCard.t -= dt; if (g.failCard.t <= 0) g.failCard = null; }
  if (m) {
    m.t += dt;
    const s = m.step; if (s) { const h = STEPS[s.t]; if (h.update(g, m, s, dt) && g.mission === m && m.step === s) next(g); }
    return;
  }
  if (g.side) { updateSide(g, dt); }
  if (g.arena) updateArena(g, dt);
  if (g.cut || g.scene || g.arena) return;
  // start markers
  for (const d of MISSIONS) {
    if (!missionAvailable(g, d) || d.auto) continue; const pt = g.world.pois[d.at]; if (!pt) continue;
    if (hyp(p.x - pt.x, p.y - pt.y) < 56 && !g.side) { startMission(g, d); return; }
  }
  const rs = g.world.pois.raceStart;
  if (rs && p.veh && hyp(p.x - rs.x, p.y - rs.y) < 70 && !g.side && g.raceCool <= 0) { g.raceCool = 20; startSide(g, 'race'); }
  else if (g.raceCool > 0) g.raceCool -= dt;
}

// ---------- side activities ----------
function randomDoor(g, from, minD, maxD) {
  return g.world.randomDoor(from.x, from.y, minD, maxD) || (() => { const l = g.world.doorList.filter((d) => { const dd = hyp(d.x - from.x, d.y - from.y); return dd > minD && dd < maxD; }); return l.length ? pick(l) : pick(g.world.doorList); })();
}
export function startSide(g, kind) {
  if (g.mission || g.side) { g.toast('Finish your current job first.', '#ff7788'); return false; }
  const p = g.player;
  if (kind === 'race') { if (!p.veh) { g.toast('You need a vehicle for the race.', '#ff7788'); return false; } startMission(g, { id: 'side_race', title: 'Street Race', side: true, reward: { cash: 700 }, steps: [{ t: 'race', time: 95, text: 'Beat the rival to the finish' }] }); return true; }
  if (kind === 'taxi') {
    if (!p.veh || !p.veh.def.taxi) { g.toast('Get into a Yellow Cab first.', '#ff7788'); return false; }
    g.side = { kind, stage: 0, fares: 0 }; newFare(g); return true;
  }
  if (kind === 'delivery') {
    if (!p.veh || p.veh.def.shape === 'bus') { g.toast('You need a van, pickup or bike.', '#ff7788'); return false; }
    const a = randomDoor(g, p, 300, 1400), b = randomDoor(g, a, 1200, 3000);
    g.side = { kind, stage: 0, a, b, t: 0, limit: 160 }; g.pickups.push({ type: 'mission', x: a.x, y: a.y, label: 'parcel', life: 1e9, side: true }); setSideObj(g, 'Pick up the parcel', a); return true;
  }
  if (kind === 'vigilante') {
    if (!p.veh || p.veh.def.shape !== 'police') { g.toast('Steal a police cruiser for vigilante work.', '#ff7788'); return false; }
    const r = randomLaneSpawn(g, 700, 1000); if (!r) { g.toast('No suspects around. Try again.', '#aaa'); return false; }
    const v = spawnVehicle(g, 'sedan', r.x, r.y, r.dir * Math.PI / 2, { ai: 'traffic', npc: 'vip', color: '#ff1744', mis: true }); if (!v) return false; v.dir = r.dir; v.mode = 'flee'; v.cruise = 330; v.speedMul = 0.8;
    g.side = { kind, v, t: 0 }; g.toast('Suspect fleeing — take them down!', '#ff7788'); return true;
  }
  if (AIR_JOBS.includes(kind)) return startAirJob(g, kind);
  if (kind === 'theft') { g.toast('Steal: ' + g.theft.need.filter((t) => !g.theft.done.includes(t)).map((t) => VEHICLES[t].n).join(', ') + ' — deliver to Gus\'s door.', '#ffe14a'); return true; }
  return false;
}
function setSideObj(g, text, pt) { g.obj = { text, x: pt.x, y: pt.y }; }
function newFare(g) {
  const p = g.player, s = world(g).randomWalkable(p.x, p.y, 700, [3, 6, 11]);
  if (!s) { g.side.retry = 2; return; }
  const a = spawnActor(g, 'civ', s.x, s.y, { fac: 'civ' }); if (!a) { g.side.retry = 2; return; }
  a.st = 'stay'; a.mis = true; a.noLoot = true; g.side.ped = a; g.side.stage = 0; setSideObj(g, 'Pick up the fare', a);
}
const world = (g) => g.world;
function updateSide(g, dt) {
  const S = g.side, p = g.player; if (!S) return;
  if (S.air) { updateAirJob(g, S, dt); return; }
  if (S.kind === 'taxi') {
    if (!p.veh || !p.veh.def.taxi) { S.off = (S.off || 0) + dt; if (S.off > 25) { g.toast('Shift ended. Fares: ' + S.fares, '#ffe14a'); endSide(g); return; } } else S.off = 0;
    if (S.retry > 0) { S.retry -= dt; if (S.retry <= 0) { S.retry = 0; newFare(g); } return; }
    if (S.stage === 0 && S.ped) { g.obj.x = S.ped.x; g.obj.y = S.ped.y; if (!S.ped.on || S.ped.dead) { newFare(g); return; } if (p.veh && hyp(p.x - S.ped.x, p.y - S.ped.y) < 90 && hyp(p.veh.vx, p.veh.vy) < 120) { S.ped.on = false; const d = randomDoor(g, p, 900, 2600); S.dest = d; S.stage = 1; S.t = 0; S.dist = hyp(d.x - p.x, d.y - p.y); S.hp0 = p.veh.hp; setSideObj(g, 'Drop off the passenger', d); g.passenger = 'Fare'; g.audio.sfx('door'); } }
    else if (S.stage === 1) { S.t += dt; g.obj.sub = Math.round(hyp(p.x - S.dest.x, p.y - S.dest.y) / 10) + 'm'; if (p.veh && hyp(p.x - S.dest.x, p.y - S.dest.y) < 90) { const par = S.dist / 380, bonus = Math.max(0, par * 1.6 - S.t) * 6, dmg = Math.max(0, S.hp0 - p.veh.hp) * 0.5, fare = Math.max(30, Math.round(40 + S.dist * 0.07 + bonus - dmg)); g.cash += fare; g.stats.cashEarned += fare; S.fares++; g.toast('Fare paid: $' + fare, '#7cff4f'); g.audio.sfx('cash'); g.passenger = null; newFare(g); } if (S.t > 150) { g.toast('Fare walked away.', '#ff7788'); g.passenger = null; newFare(g); } }
  } else if (S.kind === 'delivery') {
    S.t += dt;
    if (S.stage === 0) { if (S.got) { S.stage = 1; S.t = 0; setSideObj(g, 'Deliver the parcel', S.b); } }
    else { g.obj.sub = Math.max(0, Math.ceil(S.limit - S.t)) + 's'; if (S.t > S.limit) { g.toast('Delivery failed: too slow.', '#ff7788'); g.audio.sfx('fail'); endSide(g); return; } if (hyp(p.x - S.b.x, p.y - S.b.y) < 80) { const pay = Math.round(250 + (S.limit - S.t) * 3); g.cash += pay; g.stats.cashEarned += pay; g.toast('Delivered! +$' + pay, '#7cff4f'); g.audio.sfx('cash'); endSide(g); } }
  } else if (S.kind === 'vigilante') {
    S.t += dt; g.obj = { text: 'Take down the suspect', x: S.v.x, y: S.v.y, sub: Math.round(hyp(S.v.x - p.x, S.v.y - p.y) / 10) + 'm' };
    if (!S.v.on || S.v.wreck) { g.cash += 350; g.stats.cashEarned += 350; g.toast('Suspect neutralised +$350', '#7cff4f'); g.audio.sfx('cash'); endSide(g); }
    else if (S.t > 140 || hyp(S.v.x - p.x, S.v.y - p.y) > 1600) { g.toast('The suspect escaped.', '#ff7788'); endSide(g); }
  }
}
function endSide(g) { const S = g.side; if (S && S.ped && S.ped.on) { S.ped.on = false; } if (S && S.v) { S.v.mis = false; } g.side = null; g.obj = null; g.passenger = null; g.pickups = g.pickups.filter((q) => !q.side); }
export function endSideJob(g) { endSide(g); }
export function onMissionPickup(g, pk) {
  const m = g.mission;
  if (pk.side && g.side) { g.side.got = true; g.audio.sfx('pickup'); return; }
  if (m && m.step && (m.step.t === 'pickup' || m.step.t === 'stealth')) { m.step.got = true; g.audio.sfx('pickup'); g.toast('Got the ' + pk.label, '#7cff4f'); }
}
export function onSpotted(g) { const m = g.mission; if (m && m.step && m.step.t === 'stealth') m.spotted = true; }

// ---------- arena fights ----------
export function startArena(g) {
  if (g.arena || g.mission) return; if (g.cash < 50) { g.toast('Entry costs $50.', '#ff7788'); return; }
  g.cash -= 50; g.arena = { round: 0, list: [], wait: 1.5, won: 0 }; g.toast('Round 1 — fight!', '#ff3b3b'); g.switchToMelee();
}
function updateArena(g, dt) {
  const A = g.arena; if (!A) return;
  if (!g.scene || g.scene.type !== 'arena') { g.arena = null; return; }
  A.list = A.list.filter((a) => a.on); const left = alive(A.list);
  if (left === 0) { A.wait -= dt; if (A.wait <= 0) {
    if (A.round >= 3) { const pay = 450; g.cash += pay; g.stats.cashEarned += pay; g.toast('Champion! +$' + pay, '#7cff4f'); g.audio.sfx('complete'); g.arena = null; return; }
    A.round++; A.wait = 2; const ring = g.scene.pts.ring;
    for (let i = 0; i < A.round + 1; i++) { const a = spawnActor(g, 'gang', ring.x + rnd(-80, 80), ring.y + rnd(-60, -20), { fac: 'kes', w: i === 0 && A.round > 1 ? 'bat' : 'fists', inside: g.scene.id, mis: true, hp: 80 + A.round * 15 }); if (a) { a.st = 'combat'; a.alert = 1; a.target = g.player; a.noLoot = true; a.dmgMul = 0.8; A.list.push(a); } }
    g.toast('Round ' + A.round + ' — fight!', '#ff3b3b');
  } }
}
export function theftDeliver(g, v) {
  const t = v.type; if (g.theft.need.includes(t) && !g.theft.done.includes(t)) { g.theft.done.push(t); const pay = Math.round(VEHICLES[t].price * 0.2) || 1000; g.cash += pay; g.stats.cashEarned += pay; g.toast(VEHICLES[t].n + ' delivered +$' + pay + ' (' + g.theft.done.length + '/' + g.theft.need.length + ')', '#7cff4f'); if (g.theft.done.length === g.theft.need.length) { g.cash += 5000; g.toast('Theft list complete! +$5000', '#ffe14a'); } v.on = false; g.exitVehicle(g.player, true); return true; }
  return false;
}
export { WEAPON_ORDER, TS, chance };
