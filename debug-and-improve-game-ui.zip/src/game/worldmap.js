// ===== worldmap.js — the pan / zoom world map =====
// PERFORMANCE
//  • Explored ground is baked into 128×128 px MACRO TILES that live in an LRU cache.  LOD0 tile = 8×8 blocks (1 px per map tile), each
//    higher LOD covers 4×4 tiles of the level below (8·4^L blocks) and is stitched from them — so zooming far out draws a handful of
//    pre-baked canvases instead of thousands of 16×16 block images every frame.
//  • Viewport culling (only tiles / labels that intersect the screen), an explored-tile index maintained by the World (no scanning of the
//    explored set), a per-frame bake budget (tiles appear progressively, never freezing a frame), draws coalesced to one per animation
//    frame and zoom-aware detail throttling (overlays / small labels are skipped while the user is actively panning or zooming).
// LABELS
//  • Province names, metropolises, cities, towns, villages, districts, landmarks, airports, outposts, ports … come from the Atlas
//    (every named place ever generated, persisted) plus the authored core.  Each category has a priority TIER that only appears above a
//    zoom threshold, and labels are placed greedily by priority with rectangle-overlap culling so big names read cleanly when zoomed out
//    and small sites show up (without overlapping) when zoomed in.
import { bkey } from './keys.js';
import { CATS, TIER_ZOOM, categorize } from './atlas.js';

const SZ = 128, MAXTILES = 420;
const CORE_REGIONS = [['PORT MERIDIAN', 5.5, 5], ['SOL COSTA', 18, 5.5], ['FORT GRANITE', 30, 3], ['SAGUARO SPRINGS', 5.5, 17], ['AURELIA', 18, 17.5], ['SKYLINE AIRPORT', 30, 20], ['PINE RIDGE', 5.5, 30], ['AMBROSE VALLEY', 18, 29], ['BAYOU ROUGE', 30, 28.5]];

export function mountMap(g, m, D) {
  const { $, GANGS, MAP_POIS, NT, NB, TS } = D, W = g.world, P = g.player, cv = $('#bigmap', m), c = cv.getContext('2d');
  let CW = 720, CH = 720, K = 1;
  const fit = () => { const r = cv.getBoundingClientRect(); CW = Math.max(200, Math.round(r.width) || 720); CH = Math.max(200, Math.round(r.height) || 720); K = Math.min(2, window.devicePixelRatio || 1); cv.width = Math.round(CW * K); cv.height = Math.round(CH * K); };
  fit();
  /** phones / small canvases: fewer, smaller, non-overlapping labels (v7 declutter) */
  const compact = () => CW < 760 || document.body.classList.contains('mob');
  const inCore = P.x >= 0 && P.y >= 0 && P.x < NT * TS && P.y < NT * TS;
  const mv = g.mapView && Number.isFinite(g.mapView.x) && Number.isFinite(g.mapView.s) ? g.mapView : null; // the view you left the map in comes back after a refresh
  const V = mv ? { x: mv.x, y: mv.y, s: mv.s } : inCore ? { x: NT / 2, y: NT / 2, s: Math.min(CW, CH) / NT } : { x: P.x / TS, y: P.y / TS, s: 0.9 };
  V.hide = new Set(g.mapHide || []);
  const saveView = () => { g.mapView = { x: V.x, y: V.y, s: V.s }; g.mapHide = [...V.hide]; };
  let drag = null, moved = false, raf = 0, lastInteract = 0, dead = false;
  const sx = (tx) => (tx - V.x) * V.s + CW / 2, sy = (ty) => (ty - V.y) * V.s + CH / 2, wx = (px) => (px - CW / 2) / V.s + V.x, wy = (py) => (py - CH / 2) / V.s + V.y;
  const GROUP = { metro: 'cities', city: 'cities', town: 'cities', village: 'cities', district: 'cities', airport: 'transport', port: 'transport', service: 'services', hospital: 'services', police: 'services', hotel: 'services', mall: 'services', shop: 'services', church: 'services', outpost: 'industry', industrial: 'industry', quarry: 'industry', stadium: 'fun', casino: 'fun', resort: 'fun', stunt: 'fun', park: 'nature', landmark: 'nature', rural: 'nature', ghost: 'nature' };
  const cache = (g._mapTiles && g._mapTiles.world === W) ? g._mapTiles : (g._mapTiles = { world: W, tiles: [new Map(), new Map(), new Map(), new Map(), new Map()], frame: 0 });
  const isCore = (bx, by) => bx >= 0 && by >= 0 && bx < NB && by < NB;

  // ---------- macro tiles ----------
  function bake(L, tx, ty, key) {
    const cvn = document.createElement('canvas'); cvn.width = cvn.height = SZ; const x = cvn.getContext('2d'); let ex = 0;
    if (L === 0) {
      for (let ly = 0; ly < 8; ly++) for (let lx = 0; lx < 8; lx++) {
        const bx = tx * 8 + lx, by = ty * 8 + ly, k = bkey(bx, by); if (isCore(bx, by) || !W.explored.has(k)) continue;
        x.putImageData(new ImageData(W.miniRGBA(bx, by), 16, 16), lx * 16, ly * 16); if (W.blocks.has(k)) ex++;
      }
    } else {
      x.imageSmoothingEnabled = true; const idx = W.exploredIdx[L - 1];
      for (let j = 0; j < 4; j++) for (let i = 0; i < 4; i++) { const cx = tx * 4 + i, cy = ty * 4 + j; if (!idx.has(bkey(cx, cy))) continue; const ch = getTile(L - 1, cx, cy, true); if (ch) x.drawImage(ch.cv, i * 32, j * 32, 32, 32); }
    }
    return { cv: cvn, n: W.exploredIdx[L].get(key) || 0, ex, last: cache.frame };
  }
  function exactNow(tx, ty) { let e = 0; for (let ly = 0; ly < 8; ly++) for (let lx = 0; lx < 8; lx++) { const k = bkey(tx * 8 + lx, ty * 8 + ly); if (W.explored.has(k) && W.blocks.has(k)) e++; } return e; }
  function getTile(L, tx, ty, force) {
    const key = bkey(tx, ty), mp = cache.tiles[L], cnt = W.exploredIdx[L].get(key) || 0; let t = mp.get(key);
    if (t && t.n === cnt && (L > 0 || t.ex === exactNow(tx, ty))) { t.last = cache.frame; return t; }
    if (!force && performance.now() > deadline) return null;
    t = bake(L, tx, ty, key); mp.set(key, t);
    let total = 0; for (const q of cache.tiles) total += q.size;
    if (total > MAXTILES) { let old = null, om = null, ok = null; for (const q of cache.tiles) for (const [k2, v] of q) if (!old || v.last < old.last) { old = v; om = q; ok = k2; } if (old && cache.frame - old.last > 2) om.delete(ok); }
    return t;
  }
  let deadline = 0;

  // ---------- labels ----------
  const wcache = new Map();
  const tw = (font, text) => { const k = font + text; let w = wcache.get(k); if (w === undefined) { c.font = font; w = c.measureText(text).width; if (wcache.size > 3000) wcache.clear(); wcache.set(k, w); } return w; };
  function collect(items, interacting) {
    const px0 = wx(-40) * TS, px1 = wx(CW + 40) * TS, py0 = wy(-40) * TS, py1 = wy(CH + 40) * TS, S = V.s, seen = new Set();
    const push = (key, name, x, y, cat, tier, extra) => { if (seen.has(key) || V.hide.has(GROUP[cat]) || tier >= TIER_ZOOM.length || S < TIER_ZOOM[tier] * (compact() ? 1.7 : 1) || (interacting && tier > 4 && S < 1)) return; seen.add(key); const d = CATS[cat] || CATS.landmark; items.push({ key, name, x: sx(x / TS), y: sy(y / TS), tier, icon: d.icon, col: d.col, cat, ...extra }); };
    const vis = (k, x, y) => g.disc[k] || W.explored.has(bkey(Math.floor(x / 512), Math.floor(y / 512)));
    // authored core: discovered POIs + cities
    for (const k of new Set([...Object.keys(MAP_POIS), ...Object.keys(g.disc)])) {
      const p = W.pois[k]; if (!p || W.atlas.has(k) || !(g.disc[k] || ['safe', 'gus', 'start'].includes(k))) continue;
      if (p.x < px0 || p.x > px1 || p.y < py0 || p.y > py1) continue;
      const city = k.startsWith('c_'), cat = city ? 'city' : categorize(k, p.name), nm = MAP_POIS[k] ? MAP_POIS[k][1] : p.name;
      push(k, nm, p.x, p.y, cat, CATS[cat].tier, { icon: MAP_POIS[k] ? MAP_POIS[k][0] : CATS[cat].icon });
    }
    for (const q of W.cities) { const k = 'c_' + q.key; if (W.atlas.has(k) || W.atlas.has(q.key) || q.x < px0 || q.x > px1 || q.y < py0 || q.y > py1) continue; push(k, q.name, q.x, q.y, q.airport || q.key === 'airport' ? 'airport' : 'city', q.airport || q.key === 'airport' ? 5 : 2); }
    // procedural: everything the generator ever produced here (and the player has seen)
    const hit = W.atlas.query(px0, py0, px1, py1, []);
    for (const s of hit) if (vis(s.key, s.x, s.y)) push(s.key, s.name, s.x, s.y, s.cat, s.tier);
  }
  function drawProvinces(alpha, shared) {
    const T = W.terra, PS = 13, b0x = wx(0) / 16, b1x = wx(CW) / 16, b0y = wy(0) / 16, b1y = wy(CH) / 16;
    const i0 = Math.floor(b0x / PS) - 1, i1 = Math.floor(b1x / PS) + 1, j0 = Math.floor(b0y / PS) - 1, j1 = Math.floor(b1y / PS) + 1;
    if ((i1 - i0 + 1) * (j1 - j0 + 1) > 1800) return;
    const cp = compact(), fs = cp ? Math.max(9, Math.min(14, 8 + Math.log2(1 + 13 * 16 * V.s) * 1.6)) : Math.max(10, Math.min(24, 9 + Math.log2(1 + 13 * 16 * V.s) * 2.6)), font = `700 ${fs.toFixed(0)}px sans-serif`, rects = shared || [];
    c.textAlign = 'center'; c.textBaseline = 'middle'; c.lineJoin = 'round'; c.font = font; if ('letterSpacing' in c) c.letterSpacing = cp ? '1px' : '2px';
    for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
      const bx = Math.round((i + 0.5) * PS), by = Math.round((j + 0.5) * PS); let p = T.province(bx, by); if (!p || p.px === undefined) continue;
      const pbx = Math.round(p.px), pby = Math.round(p.py); if (T.province(pbx, pby) !== p) continue; // each province once, at its own seed point
      let known = false; for (const [dx, dy] of [[0, 0], [5, 0], [-5, 0], [0, 5], [0, -5], [4, 4], [-4, -4], [4, -4], [-4, 4]]) if (W.explored.has(bkey(pbx + dx, pby + dy))) { known = true; break; }
      if (!known || (pbx >= 0 && pby >= 0 && pbx < NB && pby < NB)) continue;
      const x = sx(p.px * 16 + 8), y = sy(p.py * 16 + 8); if (x < -150 || x > CW + 150 || y < -30 || y > CH + 30) continue;
      const text = p.name.toUpperCase(), w = tw(font, text) + 6, h = fs + 4, r = [x - w / 2, y - h / 2, x + w / 2, y + h / 2];
      if (rects.some((q) => r[0] < q[2] && r[2] > q[0] && r[1] < q[3] && r[3] > q[1])) continue; rects.push(r);
      c.globalAlpha = alpha * (cp ? 0.5 : 0.62); c.strokeStyle = '#000'; c.lineWidth = cp ? 3 : 4; c.strokeText(text, x, y); c.fillStyle = '#e9f0ff'; c.fillText(text, x, y);
    }
    if ('letterSpacing' in c) c.letterSpacing = '0px'; c.globalAlpha = 1;
  }
  function drawLabels(interacting) {
    const items = []; collect(items, interacting); items.sort((a, b) => a.tier - b.tier || a.name.length - b.name.length);
    const rects = [], cp = compact(), maxShown = cp ? 90 : 420; let shown = 0; c.textAlign = 'center'; c.textBaseline = 'alphabetic'; c.lineJoin = 'round';
    for (const it of items) {
      if (it.x < -60 || it.x > CW + 60 || it.y < -20 || it.y > CH + 20) continue;
      const big = it.tier <= 2, fs = cp ? (big ? 12 : 10) : big ? 13 + (it.tier === 1 ? 2 : 0) : it.tier <= 4 ? 12 : 11, font = `${it.tier <= 4 ? 'bold ' : ''}${fs}px sans-serif`, w = tw(font, it.name) + 4, ix = it.x, iy = it.y;
      const pad = cp ? 5 : 0, r = [ix - w / 2 - pad, iy - 13 - fs - 2, ix + w / 2 + pad, iy - 9.5], ri = cp ? [ix - 8, iy - 8.5, ix + 8, iy + 8.5] : [ix - 7, iy - 7, ix + 7, iy + 7];
      const clash = (q) => (r[0] < q[2] && r[2] > q[0] && r[1] < q[3] && r[3] > q[1]);
      const iconClash = rects.some((q) => ri[0] < q[2] && ri[2] > q[0] && ri[1] < q[3] && ri[3] > q[1]);
      if (iconClash && it.tier > 2) continue;
      // marker
      c.fillStyle = '#000b'; c.beginPath(); c.arc(ix, iy, cp ? (it.tier <= 2 ? 7 : 5) : it.tier <= 2 ? 8 : 6.5, 0, 6.3); c.fill(); c.fillStyle = it.col; c.font = cp ? '9px sans-serif' : '11px sans-serif'; c.fillText(it.icon || '•', ix, iy + 4);
      rects.push(ri);
      if (rects.some(clash) || shown > maxShown) continue; // label would overlap a more important one → marker only
      rects.push(r); shown++; c.font = font; c.strokeStyle = '#000'; c.lineWidth = 3; c.strokeText(it.name, ix, iy - 11); c.fillStyle = it.tier <= 4 ? '#fff' : '#e4ecff'; c.fillText(it.name, ix, iy - 11);
    }
    return rects;
  }

  // ---------- frame ----------
  const draw = () => {
    raf = 0; if (dead || !m.isConnected) return; cache.frame++;
    const now = performance.now(), interacting = now - lastInteract < 180; deadline = now + 9; let pending = false;
    c.setTransform(K, 0, 0, K, 0, 0); c.imageSmoothingEnabled = false; c.globalAlpha = 1; c.fillStyle = '#04070d'; c.fillRect(0, 0, CW, CH);
    c.save(); c.translate(CW / 2, CH / 2); c.scale(V.s, V.s); c.translate(-V.x, -V.y);
    c.drawImage(g.overview, 0, 0);
    const ppb = V.s * 16, L = Math.max(0, Math.min(4, Math.round(Math.log(16 / ppb) / Math.log(4)))), S = 8 << (2 * L), tsz = S * 16;
    const tx0 = Math.floor(wx(0) / tsz), tx1 = Math.floor(wx(CW) / tsz), ty0 = Math.floor(wy(0) / tsz), ty1 = Math.floor(wy(CH) / tsz), idx = W.exploredIdx ? W.exploredIdx[L] : null;
    c.imageSmoothingEnabled = L > 0 && ppb < 12;
    if (idx) for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      if (!idx.has(bkey(tx, ty))) continue; const t = getTile(L, tx, ty, false); if (!t) { pending = true; continue; }
      c.drawImage(t.cv, tx * tsz, ty * tsz, tsz, tsz);
    }
    c.restore();
    const Z = V.s;
    // overlays (turf / heat) — skipped while the user is dragging or zooming
    if (!interacting) {
      if (Z > 0.12) for (let bx = 0; bx < NB; bx++) for (let by = 0; by < NB; by++) {
        const X = sx(bx * 16 + 4), Y = sy(by * 16 + 4); if (X < -20 || Y < -20 || X > CW + 20 || Y > CH + 20) continue;
        const t = W.turf[bx * NB + by]; if (t) { c.fillStyle = GANGS.find((q) => q.id === t).color + '30'; c.fillRect(X, Y, 12 * Z, 12 * Z); }
        const h = W.heat[bx * NB + by]; if (h > 4) { c.fillStyle = `rgba(255,40,70,${Math.min(0.5, h / 160)})`; c.fillRect(X, Y, 12 * Z, 12 * Z); }
      }
      for (const [k, h] of W.heatS) { if (h <= 4) continue; const bx = Math.floor(k / 33554432) - 16777216, by = (k % 33554432) - 16777216, X = sx(bx * 16), Y = sy(by * 16); if (X < -20 || Y < -20 || X > CW + 20 || Y > CH + 20) continue; c.fillStyle = `rgba(255,40,70,${Math.min(0.5, h / 160)})`; c.fillRect(X, Y, 16 * Z, 16 * Z); }
    }
    // names: city / POI labels first (priority), then authored region names and province names only where there is room
    const lr = drawLabels(interacting), cp = compact();
    if (Z < (cp ? 0.45 : 0.9)) { c.font = `bold ${cp ? 9 : 11}px sans-serif`; c.textAlign = 'center'; c.textBaseline = 'alphabetic'; c.lineJoin = 'round'; c.globalAlpha = Math.min(1, ((cp ? 0.45 : 0.9) - Z) / 0.3) * (cp ? 0.65 : 0.8);
      for (const [n, bx, by] of CORE_REGIONS) { const x = sx(bx * 16 + 9), y = sy(by * 16 + 9); if (x < -80 || x > CW + 80 || y < -20 || y > CH + 20) continue; const w = tw(c.font, n) + 4, r = [x - w / 2, y - 12, x + w / 2, y + 3]; if (lr.some((q) => r[0] < q[2] && r[2] > q[0] && r[1] < q[3] && r[3] > q[1])) continue; lr.push(r); c.strokeStyle = '#000'; c.lineWidth = 3; c.strokeText(n, x, y); c.fillStyle = '#fff'; c.fillText(n, x, y); }
      c.globalAlpha = 1; }
    if (Z < (cp ? 0.3 : 0.5)) drawProvinces(Math.min(1, ((cp ? 0.3 : 0.5) - Z) / 0.2), lr);
    if (!V.hide.has('pins')) for (const pn of g.pins || []) { const x = sx(pn.x / TS), y = sy(pn.y / TS); if (x < -20 || y < -20 || x > CW + 20 || y > CH + 20) continue; c.fillStyle = '#ffd24a'; c.strokeStyle = '#000'; c.lineWidth = 2; c.beginPath(); c.moveTo(x, y); c.lineTo(x - 6, y - 13); c.arc(x, y - 16, 7, 2.4, 0.74); c.closePath(); c.fill(); c.stroke(); c.fillStyle = '#000'; c.beginPath(); c.arc(x, y - 16, 2.4, 0, 6.3); c.fill(); if (V.s > 0.05 || true) { c.font = 'bold 11px sans-serif'; c.textAlign = 'center'; c.lineWidth = 3; c.strokeStyle = '#000'; c.strokeText(pn.n, x, y - 27); c.fillStyle = '#ffe9a0'; c.fillText(pn.n, x, y - 27); } }
    if (V.hl && V.hl.t > performance.now()) { const x = sx(V.hl.x / TS), y = sy(V.hl.y / TS), ph = (performance.now() % 900) / 900; c.strokeStyle = '#4fe0ff'; c.lineWidth = 3; c.globalAlpha = 1 - ph; c.beginPath(); c.arc(x, y, 10 + ph * 26, 0, 6.3); c.stroke(); c.globalAlpha = 1; pending = true; }
    for (const mk of g.markers) { const x = sx(mk.x / TS), y = sy(mk.y / TS); c.fillStyle = mk.color; c.beginPath(); c.arc(x, y, 6, 0, 6.3); c.fill(); c.strokeStyle = '#000'; c.stroke(); }
    if (g.waypoint) { const x = sx(g.waypoint.x / TS), y = sy(g.waypoint.y / TS); c.strokeStyle = '#7cff4f'; c.lineWidth = 3; c.beginPath(); c.arc(x, y, 8, 0, 6.3); c.moveTo(x - 12, y); c.lineTo(x + 12, y); c.moveTo(x, y - 12); c.lineTo(x, y + 12); c.stroke(); }
    { const x = sx(P.x / TS), y = sy(P.y / TS); c.save(); c.translate(x, y); c.rotate(P.a); c.fillStyle = '#4fe0ff'; c.strokeStyle = '#fff'; c.lineWidth = 2; c.beginPath(); c.moveTo(10, 0); c.lineTo(-7, 7); c.lineTo(-4, 0); c.lineTo(-7, -7); c.closePath(); c.fill(); c.stroke(); c.restore(); }
    { const wpd = g.waypoint ? Math.round(Math.hypot(g.waypoint.x - P.x, g.waypoint.y - P.y) / TS * 1.6) : -1; const el = $('#mcoord', m); if (el) el.textContent = `${W.areaName(V.x * TS, V.y * TS)} · ${Math.round(V.x)}, ${Math.round(V.y)} tiles${wpd >= 0 ? ' · waypoint ' + (wpd >= 1000 ? (wpd / 1000).toFixed(1) + ' km' : wpd + ' m') : ''}`; }
    void 0 && `Centre: ${Math.round(V.x)}, ${Math.round(V.y)} tiles · ${W.areaName(V.x * TS, V.y * TS)} · LOD ${L} · ${cache.tiles.reduce((a, q) => a + q.size, 0)} cached tiles`;
    if (pending) schedule();
  };
  const schedule = () => { if (!raf && !dead) raf = requestAnimationFrame(draw); };
  const touch = () => { lastInteract = performance.now(); schedule(); setTimeout(schedule, 200); };

  draw();
  const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => { fit(); touch(); }) : null; if (ro) ro.observe(cv);
  const clampS = (v) => Math.max(0.004, Math.min(6, v));
  const ptrs = new Map(); let pinch = null, press = null, lp = 0;
  const pos = (e) => { const r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
  const setWaypoint = (px, py) => { g.waypoint = { x: wx(px) * TS, y: wy(py) * TS }; g.toast('Waypoint set', '#7cff4f'); g.audio.sfx('ui'); schedule(); };
  const addPinAt = (px, py, name) => { if (g.ui && g.ui.addPin) g.ui.addPin(name || 'Pin ' + ((g.pins || []).length + 1), wx(px) * TS, wy(py) * TS); try { navigator.vibrate && navigator.vibrate(15); } catch (e) { /* ignore */ } schedule(); };
  cv.style.touchAction = 'none';
  cv.addEventListener('pointerdown', (e) => {
    try { cv.setPointerCapture(e.pointerId); } catch (er) { /* ignore */ } const p = pos(e); ptrs.set(e.pointerId, p); moved = false;
    if (ptrs.size === 1) { drag = { x: p.x, y: p.y, vx: V.x, vy: V.y }; press = { x: p.x, y: p.y, t: performance.now() }; clearTimeout(lp); lp = setTimeout(() => { if (press && !moved && ptrs.size === 1) { addPinAt(press.x, press.y); press = null; } }, 650); }
    else if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, s: V.s }; drag = null; moved = true; clearTimeout(lp); }
  });
  cv.addEventListener('pointermove', (e) => {
    if (!ptrs.has(e.pointerId)) return; const p = pos(e); ptrs.set(e.pointerId, p);
    if (ptrs.size === 2 && pinch) { const [a, b] = [...ptrs.values()], d = Math.hypot(a.x - b.x, a.y - b.y) || 1, cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2, ax = wx(cx), ay = wy(cy); V.s = clampS(pinch.s * d / pinch.d); V.x = ax - (cx - CW / 2) / V.s; V.y = ay - (cy - CH / 2) / V.s; touch(); }
    else if (drag) { const dx = p.x - drag.x, dy = p.y - drag.y; if (Math.abs(dx) + Math.abs(dy) > 7) { moved = true; clearTimeout(lp); } if (moved) { V.x = drag.vx - dx / V.s; V.y = drag.vy - dy / V.s; touch(); } }
  });
  const up = (e) => {
    if (!ptrs.has(e.pointerId)) return; ptrs.delete(e.pointerId); clearTimeout(lp);
    if (ptrs.size === 0) { if (press && !moved && performance.now() - press.t < 650) setWaypoint(press.x, press.y); press = null; drag = null; pinch = null; saveView(); }
    else if (ptrs.size === 1) { const [p] = [...ptrs.values()]; drag = { x: p.x, y: p.y, vx: V.x, vy: V.y }; pinch = null; }
  };
  cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
  cv.addEventListener('wheel', (e) => { e.preventDefault(); const p = pos(e), ax = wx(p.x), ay = wy(p.y); V.s = clampS(V.s * (e.deltaY < 0 ? 1.25 : 1 / 1.25)); V.x = ax - (p.x - CW / 2) / V.s; V.y = ay - (p.y - CH / 2) / V.s; touch(); saveView(); }, { passive: false });
  const zoomBy = (f) => { V.s = clampS(V.s * f); touch(); saveView(); };
  const goTo = (x, y, s) => { V.x = x / TS; V.y = y / TS; V.s = clampS(Math.max(V.s, s || 0.6)); V.hl = { x, y, t: performance.now() + 4500 }; touch(); saveView(); };
  // ---------- search ----------
  const res = $('#mres', m), sIn = $('#msearch', m);
  const known = (k, x, y) => g.disc[k] || W.explored.has(bkey(Math.floor(x / 512), Math.floor(y / 512)));
  const search = () => {
    const f = (sIn.value || '').trim().toLowerCase(); if (!f) { res.style.display = 'none'; return; }
    const out = [];
    for (const pn of g.pins || []) if (pn.n.toLowerCase().includes(f)) out.push({ n: pn.n, x: pn.x, y: pn.y, i: '📌', sub: 'pin', r: 0 });
    for (const st of W.atlas.sites.values()) if (st.name.toLowerCase().includes(f) && known(st.key, st.x, st.y)) { const c = CATS[st.cat] || CATS.landmark; out.push({ n: st.name, x: st.x, y: st.y, i: c.icon || '•', sub: st.cat, r: st.tier + 1 }); if (out.length > 60) break; }
    for (const q of W.cities) if (q.name && q.name.toLowerCase().includes(f) && !out.some((o) => o.n === q.name)) out.push({ n: q.name, x: q.x, y: q.y, i: '★', sub: 'destination', r: 1 });
    for (const [n, e] of Object.entries(g.visited || {})) if (n.toLowerCase().includes(f) && !out.some((o) => o.n === n)) out.push({ n, x: e.x, y: e.y, i: '🧭', sub: 'visited area', r: 9 });
    out.sort((a, b) => a.r - b.r || a.n.length - b.n.length); const top = out.slice(0, 8);
    res.style.display = 'block'; res.innerHTML = top.length ? top.map((o, i) => `<button data-go="${i}"><i>${o.i}</i><b>${o.n.replace(/[<>&]/g, '')}</b><small>${o.sub}</small></button>`).join('') : '<p>No known place matches</p>'; res._top = top;
  };
  sIn.addEventListener('input', search);
  res.addEventListener('click', (e) => { const b = e.target.closest('[data-go]'); if (!b) return; const o = res._top[+b.dataset.go]; goTo(o.x, o.y, 0.7); res.style.display = 'none'; sIn.value = ''; });
  m.addEventListener('click', (e) => {
    const f = e.target.closest('[data-mf]'); if (f) { const k = f.dataset.mf; if (V.hide.has(k)) V.hide.delete(k); else V.hide.add(k); f.classList.toggle('off', V.hide.has(k)); touch(); saveView(); return; }
    const b = e.target.closest('[data-mp]'); b && (() => {
      const a = b.dataset.mp;
      if (a === 'me') { V.x = P.x / TS; V.y = P.y / TS; V.hl = { x: P.x, y: P.y, t: performance.now() + 2500 }; }
      else if (a === 'tog') { const mt = $('.maptop', m); mt && mt.classList.toggle('open'); } else if (a === 'core') { V.x = NT / 2; V.y = NT / 2; V.s = Math.min(CW, CH) / NT; } else if (a === 'out') V.s = 0.02;
      else if (a === 'in') V.s = clampS(V.s * 1.6); else if (a === 'out2') V.s = clampS(V.s / 1.6);
      else if (a === 'pin') { addPinAt(CW / 2, CH / 2); } else if (a === 'wp') { setWaypoint(CW / 2, CH / 2); }
      else if (a === 'clearwp') { g.waypoint = null; g.toast('Waypoint cleared', '#889'); }
      touch(); saveView();
    })();
  });
  const mo = new MutationObserver(() => { if (!m.isConnected) { dead = true; saveView(); if (ro) ro.disconnect(); mo.disconnect(); } }); mo.observe(document.body, { childList: true, subtree: true });
}
