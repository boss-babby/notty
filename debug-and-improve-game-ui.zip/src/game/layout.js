// ===== layout.js — responsive layout manager (phones, tablets, desktop; portrait + landscape) =====
// • Phone in PORTRAIT: the canvas only occupies the top part of the screen; the bottom "dock" is a separate control panel,
//   so thumbs, sticks and buttons never cover the scene.
// • Phone / tablet in LANDSCAPE: full-screen scene, translucent controls pinned to the lower corners (outside the centre of the action),
//   the HUD is compacted and respects safe-area insets (notches / rounded corners).
// • Desktop: unchanged.
// The manager writes CSS variables (--app-h, --dock) and body classes (mob, portrait, landscape, dock) that mobile.css reacts to, and exposes
// the pixel size of the play area plus the base camera scale used by the renderer.
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

export function createLayout(g, onChange) {
  const L = { mobile: false, portrait: false, dock: 0, w: window.innerWidth, h: window.innerHeight, fullH: window.innerHeight };
  const coarse = window.matchMedia ? window.matchMedia('(pointer: coarse)') : { matches: false };
  const body = document.body;
  L.compute = () => {
    const vv = window.visualViewport, w = Math.round(vv ? vv.width : window.innerWidth), h = Math.round(vv ? vv.height : window.innerHeight);
    const short = Math.min(w, h), long = Math.max(w, h);
    const touchy = coarse.matches || (g.input && g.input.touch) || ('ontouchstart' in window && short < 900);
    const prevKey = L.key;
    L.mobile = !!touchy && long < 1400; L.portrait = h > w; L.fullH = h;
    const dockOn = L.mobile && L.portrait && g.settings.dock !== 'off';
    L.dock = dockOn ? Math.round(clamp(h * 0.33, 190, 300) * clamp(g.settings.touchScale || 1, 0.85, 1.2)) : 0;
    L.w = w; L.h = Math.max(160, h - L.dock);
    L.key = [w, h, L.mobile, L.dock, g.settings.touchScale].join('|');
    body.classList.toggle('mob', L.mobile); body.classList.toggle('portrait', L.portrait); body.classList.toggle('landscape', !L.portrait); body.classList.toggle('dock', L.dock > 0);
    body.classList.toggle('phone', L.mobile && short < 560);
    const st = body.style; st.setProperty('--app-h', h + 'px'); st.setProperty('--app-w', w + 'px'); st.setProperty('--dock', L.dock + 'px'); st.setProperty('--ts', String(clamp(g.settings.touchScale || 1, 0.7, 1.5)));
    return prevKey !== L.key;
  };
  /** CSS px of screen per world px at camera zoom 1 */
  L.base = () => {
    if (!L.mobile) return L.h / 880;
    const s = L.portrait ? L.w / 560 : L.h / (L.h < 500 ? 500 : 680);
    return clamp(s, 0.52, 1.35);
  };
  let t = 0;
  const handler = () => { clearTimeout(t); t = setTimeout(() => { if (L.compute()) onChange(); }, 60); };
  window.addEventListener('resize', handler); window.addEventListener('orientationchange', handler);
  if (window.visualViewport) window.visualViewport.addEventListener('resize', handler);
  L.destroy = () => { clearTimeout(t); window.removeEventListener('resize', handler); window.removeEventListener('orientationchange', handler); if (window.visualViewport) window.visualViewport.removeEventListener('resize', handler); body.classList.remove('mob', 'portrait', 'landscape', 'dock', 'phone', 'playing', 'uiopen'); };
  L.compute();
  return L;
}

/** frame-rate governor: if a phone cannot hold ~30 fps for a few seconds, drop one quality level (and say so) */
export function qualityGovernor(g, dt) {
  const gv = g._gov || (g._gov = { low: 0, hi: 0, cool: 6 });
  if (g.state !== 'play') { gv.low = 0; return; }
  gv.cool -= dt; if (gv.cool > 0 || dt > 0.25) return;
  const fps = g.fps || 60;
  if (fps < 27) gv.low += dt; else gv.low = Math.max(0, gv.low - dt * 2);
  if (gv.low > 4) {
    const order = ['high', 'medium', 'low'], i = order.indexOf(g.settings.quality);
    gv.low = 0; gv.cool = 10;
    if (i >= 0 && i < 2 && g.settings.autoQuality !== false) { g.settings.quality = order[i + 1]; g.applySettings(); g.saveSettings(); g.toast('Performance: graphics lowered to ' + order[i + 1], '#ffb347'); }
  }
}
