// ===== genome.js — the DIVERSITY ENGINE =====
// Every building, person, vehicle colour and behaviour in the world is a PURE FUNCTION of (seed, position, context).
// Nothing is stored; nothing uses Math.random → identical after a refresh, but very different from place to place.
//
//   1. LATENT FIELDS  six low-frequency fBm noise channels (wealth, age, density, ornament, order, novelty) are mixed with a
//      designed correlation matrix (Cholesky factor L, z' = L·z) so traits co-occur realistically (rich ⇒ newer ⇒ ornate…)
//      but with different length scales, so neighbourhoods drift smoothly and never repeat.        →  styleVec(x, y)
//   2. ARCHETYPE SELECTION  each family (facade material, window grammar, roof form, outfit …) is a table of prototypes with a
//      centre c_k in latent space and a prior π_k.  The choice is a Gumbel-max sample
//            k* = argmax_k [ −‖s−c_k‖²_W / 2σ² + ln π_k + τ·G_k ]      G_k = −ln(−ln u_k)
//      i.e. an exact draw from softmax(logit/τ).  τ = τ0 + τ1·novelty(x,y) is itself a field: calm districts are uniform and
//      coherent, "eccentric" ones are eclectic — so some places feel planned and others organic.
//   3. COLOUR  palettes live in OKLCH (perceptual).  The anchor hue comes from the culture/theme colour; a harmony scheme
//      (mono / analogous / complementary / split / triad) chosen per 6×6-tile cell offsets the hue; lightness follows wealth,
//      chroma follows (1−age), weathering desaturates.  Gamut-clamped by chroma reduction.
//   4. PEOPLE  an outfit archetype (≈20) is sampled from (local style, climate temperature, hour, zone); OCEAN personality
//      traits ~ N(μ_archetype, σ) are then *mapped to behaviour parameters* (walk speed, idleness, bravery, curiosity,
//      snitching, drinking, smoking, chattiness, tourism) which the AI consumes.
import { vnoise } from './util.js';

// ---------------------------------------------------------------------------------------------- hashing / sampling
export function h32(a, b = 0, c = 0, d = 0) {
  let h = 0x9e3779b9 ^ (a | 0);
  h = Math.imul(h ^ (h >>> 15), 0x85ebca6b); h ^= (b | 0) + 0x7f4a7c15; h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  h ^= (c | 0) + 0x165667b1; h = Math.imul(h ^ (h >>> 16), 0x27d4eb2f); h ^= (d | 0) + 0x61c88647; h = Math.imul(h ^ (h >>> 15), 0x85ebca6b);
  return (h ^ (h >>> 13)) >>> 0;
}
export const u01 = (a, b, c, d) => h32(a, b, c, d) / 4294967296;
/** tiny deterministic RNG stream (xorshift32) seeded from integers */
export function stream(a, b = 0, c = 0, d = 0) { let s = h32(a, b, c, d) || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
export const gauss = (r) => Math.sqrt(-2 * Math.log(r() + 1e-9)) * Math.cos(6.283185307 * r());
const sig = (x) => 1 / (1 + Math.exp(-x));
const cl = (v, a, b) => (v < a ? a : v > b ? b : v);

// ---------------------------------------------------------------------------------------------- latent fields
export const CH = ['wealth', 'age', 'density', 'ornament', 'order', 'novelty'];
const SCALE = [38, 52, 26, 17, 44, 11]; // blocks per noise period for each channel
const COV = [
  [1.0, -0.25, 0.35, 0.45, 0.30, 0.00],
  [-0.25, 1.0, -0.10, 0.30, -0.25, 0.10],
  [0.35, -0.10, 1.0, -0.05, 0.20, -0.10],
  [0.45, 0.30, -0.05, 1.0, 0.10, 0.20],
  [0.30, -0.25, 0.20, 0.10, 1.0, -0.35],
  [0.00, 0.10, -0.10, 0.20, -0.35, 1.0],
];
const LCH = (() => { // Cholesky factor of COV (lower triangular)
  const n = 6, L = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let i = 0; i < n; i++) for (let j = 0; j <= i; j++) { let s = COV[i][j]; for (let k = 0; k < j; k++) s -= L[i][k] * L[j][k]; L[i][j] = i === j ? Math.sqrt(Math.max(1e-6, s)) : s / L[j][j]; }
  return L;
})();
function fbm(x, y, s) { return vnoise(x, y, s) * 0.55 + vnoise(x * 2.07 + 11.3, y * 2.07 - 7.1, s + 31) * 0.3 + vnoise(x * 4.3 - 3.7, y * 4.3 + 19.2, s + 67) * 0.15; }
/** 6-D style vector in (0,1)^6 at world position (px) — wealth, age, density, ornament, order, novelty */
export function styleVec(px, py, seed, bias, out = new Array(6)) {
  const bx = px / 512, by = py / 512, z = new Array(6);
  for (let i = 0; i < 6; i++) z[i] = cl((fbm(bx / SCALE[i] * 16 + i * 5.1, by / SCALE[i] * 16 - i * 3.3, seed * 7 + i * 101) - 0.5) / 0.1, -3, 3);
  for (let i = 0; i < 6; i++) { let s = 0; for (let j = 0; j <= i; j++) s += LCH[i][j] * z[j]; out[i] = sig(s * 1.15 + (bias ? bias[i] || 0 : 0)); }
  return out;
}

// ---------------------------------------------------------------------------------------------- archetype sampling
const SIGMA2 = 2 * 0.3 * 0.3, W6 = [1.3, 1, 0.8, 0.9, 0.9, 0.5];
/** Gumbel-max draw from a prototype table  [[name, centre[6], prior], …]   (mask optional) */
export function pickArch(table, s, r, tau, mask) {
  let best = null, bv = -1e18;
  for (let k = 0; k < table.length; k++) {
    const t = table[k]; if (mask && !mask(t[0])) continue;
    let d2 = 0; for (let i = 0; i < 6; i++) { const d = s[i] - t[1][i]; d2 += W6[i] * d * d; }
    const u = r(), v = -d2 / SIGMA2 + Math.log(t[2] || 1) - tau * Math.log(-Math.log(u * 0.999998 + 1e-6));
    if (v > bv) { bv = v; best = t[0]; }
  }
  return best;
}

// ---------------------------------------------------------------------------------------------- colour (OKLCH)
const lin = (c) => (c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4));
const enc = (c) => (c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055);
export function hex2lch(hex) {
  const n = parseInt(String(hex).slice(1, 7), 16), r = lin(((n >> 16) & 255) / 255), g = lin(((n >> 8) & 255) / 255), b = lin((n & 255) / 255);
  const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b), m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b), s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
  const L = 0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s, A = 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s, B = 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s;
  return [L, Math.hypot(A, B), (Math.atan2(B, A) * 180 / Math.PI + 360) % 360];
}
function lch2rgb(L, C, h) {
  const a = C * Math.cos(h * Math.PI / 180), b = C * Math.sin(h * Math.PI / 180);
  const l = Math.pow(L + 0.3963377774 * a + 0.2158037573 * b, 3), m = Math.pow(L - 0.1055613458 * a - 0.0638541728 * b, 3), s = Math.pow(L - 0.0894841775 * a - 1.291485548 * b, 3);
  return [4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s, -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s, -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s];
}
const hx = (v) => ('0' + Math.round(cl(enc(cl(v, 0, 1)), 0, 1) * 255).toString(16)).slice(-2);
export function lch2hex(L, C, h) {
  L = cl(L, 0.05, 0.97); let rgb = lch2rgb(L, C, h);
  for (let i = 0; i < 9 && (rgb[0] < -0.001 || rgb[0] > 1.001 || rgb[1] < -0.001 || rgb[1] > 1.001 || rgb[2] < -0.001 || rgb[2] > 1.001); i++) { C *= 0.82; rgb = lch2rgb(L, C, h); }
  return '#' + hx(rgb[0]) + hx(rgb[1]) + hx(rgb[2]);
}
const HARM = { mono: [0], analog: [-28, 0, 28], compl: [0, 180], split: [0, 150, 210], triad: [0, 120, 240], warm: [-20, 10, 40] };
const HARM_KEYS = Object.keys(HARM);
/** a harmonised variant of an anchor colour for this cell/lot */
export function harmonise(anchor, cellKey, lotKey, s) {
  const [L0, C0, h0] = hex2lch(anchor), scheme = HARM_KEYS[h32(cellKey, 91) % HARM_KEYS.length], offs = HARM[scheme];
  const dh = offs[h32(lotKey, 17) % offs.length] + (u01(lotKey, 5) - 0.5) * 22;
  const L = L0 + (s[0] - 0.5) * 0.14 + (u01(lotKey, 9) - 0.5) * 0.08 - (s[1] - 0.5) * 0.05;
  const C = C0 * (0.75 + 0.6 * (1 - s[1]) * (0.5 + s[3])) + s[5] * 0.03;
  return lch2hex(L, C, h0 + dh);
}

// ---------------------------------------------------------------------------------------------- BUILDING GENOME
// prototypes: [name, [wealth, age, density, ornament, order, novelty], prior]
const FACADE = [
  ['brick', [0.35, 0.75, 0.55, 0.5, 0.6, 0.3], 1.4], ['stucco', [0.45, 0.55, 0.3, 0.4, 0.5, 0.4], 1.3], ['glass', [0.88, 0.1, 0.85, 0.1, 0.8, 0.3], 0.9], ['concrete', [0.25, 0.45, 0.7, 0.1, 0.7, 0.2], 1.1],
  ['panel', [0.4, 0.3, 0.5, 0.1, 0.65, 0.3], 1], ['stone', [0.82, 0.85, 0.5, 0.9, 0.7, 0.2], 0.8], ['wood', [0.3, 0.6, 0.1, 0.4, 0.3, 0.5], 1], ['mosaic', [0.5, 0.5, 0.4, 0.85, 0.4, 0.75], 0.6],
  ['metal', [0.15, 0.5, 0.2, 0.0, 0.5, 0.4], 0.8], ['adobe', [0.2, 0.8, 0.1, 0.3, 0.3, 0.5], 0.7], ['deco', [0.75, 0.65, 0.7, 0.95, 0.85, 0.35], 0.6], ['shingle', [0.4, 0.5, 0.15, 0.3, 0.4, 0.4], 0.7],
];
const WINDOW = [
  ['grid', [0.5, 0.5, 0.5, 0.3, 0.7, 0.2], 1.4], ['tall', [0.6, 0.65, 0.5, 0.6, 0.7, 0.3], 1], ['arch', [0.65, 0.8, 0.4, 0.85, 0.6, 0.35], 0.8], ['round', [0.5, 0.3, 0.3, 0.4, 0.3, 0.9], 0.35],
  ['slit', [0.2, 0.5, 0.7, 0.1, 0.8, 0.3], 0.6], ['band', [0.7, 0.15, 0.8, 0.1, 0.9, 0.3], 0.8], ['bay', [0.55, 0.7, 0.3, 0.7, 0.5, 0.4], 0.7], ['shutter', [0.35, 0.7, 0.1, 0.5, 0.4, 0.4], 0.9],
  ['cross', [0.4, 0.6, 0.3, 0.4, 0.5, 0.6], 0.5], ['blind', [0.1, 0.5, 0.3, 0.0, 0.5, 0.2], 0.3],
];
const ROOFS = [
  ['flat', [0.4, 0.4, 0.7, 0.2, 0.7, 0.2], 1.5], ['gable', [0.45, 0.6, 0.15, 0.4, 0.5, 0.3], 1.3], ['hip', [0.55, 0.55, 0.2, 0.5, 0.65, 0.3], 0.9], ['saw', [0.2, 0.45, 0.3, 0.0, 0.8, 0.3], 0.6],
  ['dome', [0.75, 0.8, 0.4, 0.95, 0.6, 0.5], 0.25], ['green', [0.7, 0.1, 0.5, 0.3, 0.6, 0.6], 0.45], ['solar', [0.55, 0.1, 0.4, 0.05, 0.8, 0.4], 0.6], ['barrel', [0.35, 0.4, 0.2, 0.2, 0.5, 0.6], 0.45],
  ['terrace', [0.65, 0.5, 0.6, 0.6, 0.5, 0.5], 0.5], ['pyramid', [0.7, 0.7, 0.3, 0.8, 0.8, 0.5], 0.3],
];
const SIGNS = [['plain', [0.4, 0.5, 0.5, 0.2, 0.6, 0.2], 1], ['neon', [0.45, 0.2, 0.8, 0.5, 0.3, 0.6], 1], ['wood', [0.3, 0.7, 0.2, 0.5, 0.3, 0.5], 0.8], ['banner', [0.35, 0.4, 0.4, 0.4, 0.3, 0.7], 0.7], ['brass', [0.85, 0.7, 0.6, 0.7, 0.8, 0.2], 0.5]];
// which families a building kind may draw from
const KIND_RULES = {
  house: { facade: ['stucco', 'brick', 'wood', 'adobe', 'stone', 'shingle', 'mosaic', 'panel'], roof: ['gable', 'hip', 'flat', 'barrel', 'terrace', 'green', 'solar', 'pyramid'], win: ['grid', 'tall', 'arch', 'bay', 'shutter', 'round', 'cross'] },
  apt: { facade: ['brick', 'concrete', 'panel', 'stucco', 'mosaic', 'deco', 'stone'], roof: ['flat', 'terrace', 'green', 'solar', 'gable'], win: ['grid', 'band', 'tall', 'bay', 'round', 'slit', 'cross'] },
  shop: { facade: ['brick', 'stucco', 'panel', 'mosaic', 'concrete', 'stone', 'deco', 'wood', 'adobe', 'shingle'], roof: ['flat', 'gable', 'barrel', 'green', 'solar', 'terrace'], win: ['grid', 'tall', 'arch', 'band', 'bay', 'round', 'shutter'] },
  tower: { facade: ['glass', 'concrete', 'deco', 'panel', 'stone'], roof: ['flat', 'terrace', 'pyramid', 'dome', 'green', 'solar'], win: ['band', 'grid', 'slit', 'tall', 'cross'] },
  civic: { facade: ['stone', 'deco', 'brick', 'concrete', 'glass'], roof: ['flat', 'dome', 'pyramid', 'hip', 'terrace'], win: ['arch', 'tall', 'grid', 'band'] },
  warehouse: { facade: ['metal', 'concrete', 'brick', 'panel'], roof: ['saw', 'flat', 'barrel', 'solar', 'gable'], win: ['slit', 'blind', 'grid', 'band'] },
  barn: { facade: ['wood', 'metal', 'shingle'], roof: ['gable', 'barrel', 'hip'], win: ['cross', 'blind', 'slit'] },
};
export const GENOME_KINDS = new Set(Object.keys(KIND_RULES));

/** attach a genome (b.g) to a building — recolours only when ctx.recolor !== false (procedural lots). Pure & deterministic. */
export function decorate(b, seed, ctx = {}) {
  const rules = KIND_RULES[b.kind]; if (!rules) return b;
  const cx = Math.floor(b.x / 6), cy = Math.floor(b.y / 6), cell = h32(cx, cy, seed + 3), lot = h32(b.x, b.y, seed + 5, b.w * 31 + b.h);
  const px = (b.x + b.w / 2) * 32, py = (b.y + b.h / 2) * 32, s = styleVec(px, py, seed, ctx.bias), r = stream(lot, 77);
  const hgtN = cl((b.hgt || 20) / 90, 0, 1); s[2] = cl(s[2] * 0.6 + hgtN * 0.55, 0, 1); s[0] = cl(s[0] + (ctx.wealth || 0), 0, 1);
  const tau = 0.35 + 1.05 * s[5] * s[5];
  const g = { s: s.map((v) => Math.round(v * 100) / 100), tau: Math.round(tau * 100) / 100 };
  g.f = pickArch(FACADE, s, r, tau, (k) => rules.facade.includes(k)) || rules.facade[0];
  g.w = pickArch(WINDOW, s, r, tau, (k) => rules.win.includes(k) && !(g.f === 'glass' && (k === 'arch' || k === 'shutter')) && !(g.f === 'metal' && k === 'bay')) || 'grid';
  g.r = pickArch(ROOFS, s, r, tau, (k) => rules.roof.includes(k) && !(k === 'dome' && b.w * b.h < 12)) || 'flat';
  g.sg = pickArch(SIGNS, s, r, tau * 0.8);
  g.wear = cl(s[1] * 0.75 + (1 - s[0]) * 0.35 + (r() - 0.5) * 0.25, 0, 1);
  g.cornice = s[3] > 0.55 && r() < 0.8; g.balc = (b.kind === 'apt' || (b.kind === 'house' && s[0] > 0.55)) && r() < 0.45 + 0.3 * s[0];
  g.ac = s[0] < 0.65 ? Math.floor(r() * (2 + 3 * s[2])) : Math.floor(r() * 2); g.ant = r() < 0.12 + 0.2 * s[2]; g.tank = b.hgt > 28 && r() < 0.35;
  g.graf = g.wear > 0.55 && s[0] < 0.5 && r() < 0.55; g.plants = s[3] > 0.45 && r() < 0.5; g.awn = r() < 0.4 + 0.3 * s[3];
  g.stripe = r() < 0.5; g.lit = 0.25 + 0.5 * (1 - s[4]) * r() + 0.2 * s[2]; g.shut = g.w === 'shutter' || (g.f !== 'glass' && r() < 0.18);
  g.step = b.kind === 'tower' && b.hgt > 45 && r() < 0.5; g.bill = b.kind !== 'house' && s[2] > 0.55 && s[0] < 0.7 && r() < 0.18;
  if (ctx.recolor !== false && b.color && b.color[0] === '#') {
    const hc = harmonise(b.color, cell, lot, s);
    b.color = g.f === 'glass' ? lch2hex(0.52 + s[0] * 0.1, 0.05 + s[5] * 0.06, 215 + (h32(cell, 3) % 70) - 35)
      : g.f === 'stone' || g.f === 'deco' ? lch2hex(0.7 + s[0] * 0.1, 0.03 + 0.05 * s[3], 70 + (h32(cell, 8) % 40))
        : g.f === 'metal' ? lch2hex(0.58, 0.04, 230 + (lot % 60)) : hc;
    if (!b.roof) { const [L, C, h] = hex2lch(b.color); b.roof = lch2hex(L - 0.05 + (u01(lot, 21) - 0.5) * 0.1, C * 1.1, h + (h32(cell, 11) % 3 === 0 ? 150 : 8)); }
    if (b.hgt && ctx.heightJitter !== false && b.kind !== 'civic') b.hgt = Math.max(10, Math.round(b.hgt * (0.86 + 0.3 * s[0] * u01(lot, 33) + 0.1 * s[2])));
  }
  const [L2, C2, h2] = hex2lch(b.color && b.color[0] === '#' ? b.color : '#8c8c96');
  g.trim = lch2hex(Math.min(0.92, L2 + 0.2 + s[3] * 0.06), C2 * 0.6, h2 + (g.sg === 'brass' ? 40 : 0)); g.accent = lch2hex(0.6 + s[5] * 0.15, 0.13 + s[3] * 0.06, h2 + 150 + (lot % 60));
  b.g = g; return b;
}

// ---------------------------------------------------------------------------------------------- HUMAN PERSONAS
// outfit prototypes:  [id, latent centre, prior, preferred temperature (0 cold … 1 hot), preferred hours]
const OUTFITS = [
  ['casual', [0.45, 0.4, 0.5, 0.3, 0.4, 0.4], 2.6, 0.5, null], ['office', [0.72, 0.45, 0.85, 0.25, 0.9, 0.1], 1.1, 0.5, [7, 19]], ['athlete', [0.55, 0.2, 0.5, 0.3, 0.5, 0.3], 0.7, 0.55, [5, 21]],
  ['tourist', [0.6, 0.4, 0.55, 0.7, 0.2, 0.7], 0.7, 0.8, [9, 20]], ['punk', [0.15, 0.2, 0.6, 0.6, 0.05, 0.95], 0.35, 0.4, [16, 28]], ['elder', [0.5, 0.95, 0.3, 0.4, 0.7, 0.2], 0.55, 0.5, [7, 20]],
  ['worker', [0.15, 0.5, 0.4, 0.05, 0.6, 0.2], 1, 0.5, [5, 18]], ['farmer', [0.15, 0.6, 0.05, 0.1, 0.5, 0.2], 0.8, 0.6, [5, 19]], ['hiker', [0.4, 0.35, 0.05, 0.2, 0.4, 0.5], 0.6, 0.35, [6, 19]],
  ['beach', [0.5, 0.25, 0.4, 0.5, 0.2, 0.6], 0.9, 1.0, [9, 20]], ['clubber', [0.55, 0.12, 0.8, 0.8, 0.15, 0.8], 0.55, 0.55, [20, 29]], ['student', [0.35, 0.1, 0.6, 0.3, 0.4, 0.5], 0.9, 0.5, [8, 22]],
  ['vendor', [0.25, 0.55, 0.5, 0.4, 0.5, 0.3], 0.55, 0.6, [7, 19]], ['cowboy', [0.3, 0.6, 0.05, 0.4, 0.4, 0.5], 0.45, 0.85, null], ['parka', [0.5, 0.4, 0.3, 0.2, 0.5, 0.3], 0.5, 0.05, null],
  ['hipster', [0.5, 0.15, 0.6, 0.55, 0.2, 0.8], 0.55, 0.45, [10, 26]], ['trad', [0.4, 0.6, 0.2, 0.9, 0.7, 0.4], 0.5, 0.5, null], ['chef', [0.4, 0.4, 0.6, 0.3, 0.8, 0.2], 0.3, 0.5, [8, 22]],
  ['biker', [0.3, 0.35, 0.4, 0.4, 0.2, 0.7], 0.4, 0.45, null], ['executive', [0.95, 0.5, 0.8, 0.5, 0.95, 0.1], 0.4, 0.5, [7, 20]],
];
const BEHAV = { // OCEAN means per outfit  [E, O, C, A, N]   (0..1)
  casual: [.5, .5, .5, .55, .45], office: [.45, .4, .8, .55, .5], athlete: [.75, .55, .75, .5, .3], tourist: [.7, .85, .35, .65, .4], punk: [.6, .8, .2, .25, .6], elder: [.35, .35, .65, .65, .5],
  worker: [.4, .35, .7, .5, .4], farmer: [.3, .3, .75, .6, .3], hiker: [.5, .85, .65, .6, .25], beach: [.8, .6, .3, .7, .25], clubber: [.9, .7, .2, .5, .5], student: [.6, .75, .4, .6, .55],
  vendor: [.7, .45, .7, .65, .35], cowboy: [.4, .4, .55, .45, .25], parka: [.4, .45, .6, .55, .4], hipster: [.5, .9, .4, .6, .5], trad: [.45, .35, .8, .7, .35], chef: [.55, .5, .8, .5, .5], biker: [.65, .55, .3, .3, .35], executive: [.7, .5, .85, .35, .3],
};
const ROLE_OF = { athlete: 'jogger', tourist: 'tourist', hiker: 'hiker', farmer: 'farmer', vendor: 'vendor', office: 'commuter', executive: 'commuter', worker: 'laborer', student: 'student', elder: 'elder', clubber: 'nightowl', punk: 'nightowl', hipster: 'nightowl' };
const SKIN_T = ['#f1c9a5', '#e0ac80', '#c68642', '#8d5524', '#5c3a21', '#f7d7bd', '#b97a4b', '#a86a3c'];
const HAIRC = ['#1b1b1b', '#4a2f1b', '#a0522d', '#d9b36c', '#c8c8c8', '#2b1c12', '#7a4a21', '#e8d9b0'];
const FUN = ['#ff4fd8', '#2fd0ff', '#7cff4f', '#ffe14a', '#ff7a45', '#b36bff'];
const pk = (r, a) => a[Math.floor(r() * a.length)];
/** a full human: look + personality + behaviour parameters.  Deterministic in (seed, position, salt). */
export function persona(seed, px, py, salt, ctx = {}) {
  const r = stream(seed, Math.floor(px / 7), Math.floor(py / 7), salt | 0), s = styleVec(px, py, seed, ctx.bias);
  const hour = ctx.hour === undefined ? 14 : ctx.hour, night = hour >= 21 || hour < 5, temp = ctx.temp === undefined ? 0.5 : ctx.temp, tau = 0.5 + 0.9 * s[5];
  const table = OUTFITS.map(([n, c, pr, t, hh]) => {
    let p = pr * Math.exp(-((t - temp) ** 2) / 0.12 * (n === 'parka' || n === 'beach' ? 1.6 : 0.5));
    if (hh) { const h2 = hour < 5 ? hour + 24 : hour; if (h2 < hh[0] || h2 > hh[1]) p *= 0.15; }
    const z = ctx.zone;
    if (z === 'farm' && (n === 'farmer' || n === 'cowboy')) p *= 4; if (z === 'wild' && (n === 'hiker' || n === 'farmer')) p *= 5; if (z === 'coast' && (n === 'beach' || n === 'tourist')) p *= 3.5;
    if (z === 'urban' && (n === 'office' || n === 'executive' || n === 'student' || n === 'hipster')) p *= 1.8; if (z === 'ind' && (n === 'worker' || n === 'biker')) p *= 3;
    if (z === 'night' && (n === 'clubber' || n === 'punk' || n === 'hipster')) p *= 3; if (z === 'resort' && (n === 'tourist' || n === 'beach' || n === 'executive')) p *= 3;
    return [n, c, p];
  });
  const kinds = ctx.kinds, id = pickArch(table, s, r, tau, kinds ? (k) => kinds.includes(k) : null) || 'casual';
  const hue = ctx.hue === undefined ? r() * 360 : ctx.hue, tone = (L, C, dh = 0) => lch2hex(L + (r() - 0.5) * 0.1, C * (0.7 + r() * 0.6), hue + dh + (r() - 0.5) * 40);
  const age = id === 'elder' ? 0.85 + r() * 0.15 : id === 'student' ? 0.05 + r() * 0.15 : cl(0.2 + gauss(r) * 0.17 + s[1] * 0.2, 0.02, 0.95);
  const L = { skin: ctx.skins ? pk(r, ctx.skins) : pk(r, SKIN_T), hair: age > 0.8 ? pk(r, ['#c8c8c8', '#e8e8e8', '#9a9a9a']) : pk(r, HAIRC), style: Math.floor(r() * 5), shades: r() < 0.1 + 0.2 * s[0] * (temp + 0.3), vest: false,
    build: cl(0.92 + gauss(r) * 0.08 + (id === 'athlete' ? 0.06 : 0) + (age > 0.7 ? 0.05 : 0), 0.78, 1.28), hat: 0, hatc: '#444', bag: 0, coat: null, shorts: false, beard: r() < 0.14 && age > 0.15, scarf: null, apron: null, skirt: false, hv: false, glasses: r() < 0.14 + age * 0.2, sz: cl(0.96 + gauss(r) * 0.035, 0.88, 1.08), hood: false };
  if (age > 0.85) L.style = r() < 0.5 ? 0 : 1;
  const warm = temp > 0.62, cold = temp < 0.33;
  switch (id) {
    case 'casual': L.shirt = tone(0.62, 0.12); L.pants = pk(r, ['#2a3340', '#3b3f4a', '#51463a', '#26304f']); if (warm && r() < 0.6) { L.shorts = true; L.pants = tone(0.5, 0.06); } if (cold) L.coat = tone(0.4, 0.07); if (r() < 0.12) { L.hat = 1; L.hatc = tone(0.5, 0.12); } break;
    case 'office': L.shirt = pk(r, ['#e8ebf0', '#9fb4d0', '#2a3144', '#3a3a42']); L.pants = pk(r, ['#1b1d24', '#2b2f3a', '#3a3a42']); if (r() < 0.55) L.coat = pk(r, ['#23262e', '#3b4252', '#4a443c']); L.bag = r() < 0.4 ? 1 : 0; L.style = pk(r, [0, 1, 4]); L.skirt = r() < 0.18; break;
    case 'executive': L.shirt = '#15171c'; L.pants = '#101216'; L.coat = pk(r, ['#14161b', '#2a2724', '#33384a']); L.shades = r() < 0.5; L.style = 1; break;
    case 'athlete': L.shirt = pk(r, FUN); L.pants = pk(r, ['#212121', '#1a237e', '#00251a']); L.shorts = !cold; L.hat = r() < 0.2 ? 1 : 0; L.hatc = pk(r, FUN); break;
    case 'tourist': L.shirt = pk(r, ['#ff7a45', '#2fd0ff', '#ffe14a', '#ff4fd8', '#7cff4f']); L.pants = pk(r, ['#d9cbb0', '#7a8aa0', '#3a4a5a']); L.shorts = warm; L.hat = r() < 0.7 ? 2 : 0; L.hatc = pk(r, ['#e8d9a8', '#fff', '#ffcf7a']); L.bag = 1; L.shades = r() < 0.6; break;
    case 'punk': L.shirt = pk(r, ['#15161a', '#7a1020', '#2a2a30']); L.pants = '#1a1a22'; L.style = pk(r, [3, 3, 2]); L.hair = pk(r, ['#ff4fd8', '#2fd0ff', '#7cff4f', '#ff3355']); L.coat = r() < 0.5 ? '#0e0f12' : null; L.beard = false; break;
    case 'elder': L.shirt = tone(0.58, 0.08); L.pants = pk(r, ['#3a3a42', '#51463a', '#2a3340']); if (r() < 0.4) { L.hat = 1; L.hatc = tone(0.45, 0.06); } L.coat = cold || r() < 0.3 ? tone(0.42, 0.05) : null; L.glasses = r() < 0.55; L.build = cl(L.build, 0.86, 1.05); break;
    case 'worker': L.shirt = pk(r, ['#ff8a1f', '#c9c13a', '#5a6b7a', '#7a4a2a']); L.pants = pk(r, ['#2a3340', '#3a3f2a', '#4a4036']); L.hv = true; L.hat = r() < 0.75 ? 3 : 0; L.hatc = pk(r, ['#ffd21f', '#ffffff', '#ff7a1f']); L.bag = r() < 0.2 ? 1 : 0; break;
    case 'farmer': L.shirt = pk(r, ['#a63a2a', '#3a6aa0', '#c9b27a', '#4a6a3a']); L.pants = '#3a5a8a'; L.hat = r() < 0.8 ? 2 : 0; L.hatc = pk(r, ['#d9c07a', '#bda35a', '#8a6a3a']); L.beard = r() < 0.3; break;
    case 'hiker': L.shirt = pk(r, ['#ff7a45', '#2fd0ff', '#7cff4f', '#ffe14a']); L.pants = pk(r, ['#3a3f2a', '#4a4036', '#2a3340']); L.bag = 2; L.hat = r() < 0.5 ? 1 : 0; L.hatc = pk(r, FUN); L.coat = cold ? tone(0.5, 0.15) : null; L.shorts = warm && r() < 0.5; break;
    case 'beach': L.shirt = pk(r, ['#ff7a45', '#ff4fd8', '#2fd0ff', '#ffe14a', '#ffffff']); L.pants = pk(r, ['#ff4f8a', '#2fd0ff', '#ffffff', '#1a237e']); L.shorts = true; L.hat = r() < 0.5 ? 2 : 0; L.hatc = pk(r, ['#fff', '#ffe9a8', '#ff7aa8']); L.shades = r() < 0.7; L.build = cl(L.build, 0.82, 1.18); break;
    case 'clubber': L.shirt = pk(r, FUN); L.pants = pk(r, ['#12131a', '#2a1040']); L.shades = r() < 0.4; L.skirt = r() < 0.3; L.style = pk(r, [2, 3, 1]); if (r() < 0.4) L.hair = pk(r, FUN); break;
    case 'student': L.shirt = tone(0.6, 0.15); L.pants = pk(r, ['#2a3340', '#26304f', '#51463a']); L.bag = 2; L.hat = r() < 0.15 ? 1 : 0; L.hatc = tone(0.5, 0.15); break;
    case 'vendor': L.shirt = tone(0.62, 0.12); L.pants = '#2a3340'; L.apron = pk(r, ['#e8e8e8', '#8a1a2c', '#2a5a8a']); L.hat = r() < 0.25 ? 1 : 0; break;
    case 'chef': L.shirt = '#f2f2f2'; L.pants = '#2b2f3a'; L.hat = 4; L.hatc = '#ffffff'; L.apron = '#e8e8e8'; break;
    case 'cowboy': L.shirt = pk(r, ['#a63a2a', '#2a4a7a', '#d9cbb0']); L.pants = '#2e4468'; L.hat = 5; L.hatc = pk(r, ['#6b4a2a', '#2a1c12', '#a07a4a']); L.beard = r() < 0.35; break;
    case 'parka': L.shirt = tone(0.45, 0.15); L.coat = pk(r, ['#c0392b', '#1f5a8a', '#e0a82a', '#3a5a3a', '#4a4a52']); L.pants = '#2a3340'; L.hood = r() < 0.5; L.hat = L.hood ? 0 : 1; L.hatc = tone(0.5, 0.15); L.scarf = tone(0.55, 0.14, 120); break;
    case 'hipster': L.shirt = tone(0.55, 0.1, 30); L.pants = pk(r, ['#2b2f3a', '#4a3a2a', '#36424a']); L.hat = r() < 0.5 ? 1 : 0; L.hatc = tone(0.45, 0.1); L.beard = r() < 0.55; L.glasses = r() < 0.5; L.scarf = r() < 0.3 ? tone(0.5, 0.12) : null; L.bag = r() < 0.4 ? 2 : 0; break;
    case 'trad': L.shirt = tone(0.58, 0.17, 0); L.pants = tone(0.45, 0.1, 15); L.hat = r() < 0.55 ? 4 : 0; L.hatc = tone(0.7, 0.16, 90); L.scarf = tone(0.6, 0.16, 180); L.coat = r() < 0.35 ? tone(0.5, 0.14) : null; break;
    case 'biker': L.shirt = '#15161a'; L.pants = '#22262e'; L.coat = pk(r, ['#0e0f12', '#3a2418']); L.shades = r() < 0.7; L.beard = r() < 0.5; L.hat = r() < 0.3 ? 1 : 0; L.hatc = '#111'; break;
    default: L.shirt = '#888'; L.pants = '#333';
  }
  if (warm && L.coat && id !== 'office' && id !== 'executive' && id !== 'biker') L.coat = null;
  // ---- OCEAN → behaviour ----
  const m = BEHAV[id] || BEHAV.casual, E = cl(m[0] + gauss(r) * 0.16, 0, 1), O = cl(m[1] + gauss(r) * 0.16, 0, 1), C = cl(m[2] + gauss(r) * 0.16, 0, 1), A = cl(m[3] + gauss(r) * 0.16, 0, 1), N = cl(m[4] + gauss(r) * 0.16, 0, 1);
  const vigor = cl(0.65 * E + 0.25 * C - 0.55 * age + 0.35, 0, 1);
  const P = {
    id, role: ROLE_OF[id] || '', E, O, C, A, N, age, speed: Math.round(50 + 44 * vigor + (id === 'athlete' ? 40 : 0)), idleMul: 0.4 + 1.8 * (1 - E) * (0.6 + 0.5 * O) + age * 0.8,
    brave: r() < 0.02 + 0.22 * (1 - N) * (1 - A * 0.6) * (id === 'biker' || id === 'punk' ? 1.7 : 1), curious: r() < 0.08 + 0.7 * O * (0.6 + 0.4 * E), snitch: r() < 0.08 + 0.7 * C * A,
    drunk: night && r() < 0.04 + 0.5 * (1 - C) * E * (id === 'clubber' || id === 'punk' || id === 'biker' ? 1.4 : 0.8), smoker: r() < (age > 0.12 && id !== 'athlete' ? 0.04 + 0.28 * (1 - C) : 0), chatty: E * A, photo: id === 'tourist' ? 0.9 : O * 0.12,
    panic: 0.55 + 0.9 * N * (1 - 0.4 * C), hue: Math.round(hue),
  };
  return { look: L, p: P };
}

/** colour of a car for a region: wealth picks the family (luxury = neutral & deep, economy = bright & faded), hue follows the culture */
export function vehicleColor(seed, px, py, salt, palette, hue) {
  const s = styleVec(px, py, seed), r = stream(seed, Math.floor(px / 40), Math.floor(py / 40), salt | 0), pick = r();
  if (s[0] > 0.62 && pick < 0.6) return lch2hex(pk(r, [0.16, 0.95, 0.78, 0.3, 0.45]), 0.015 + r() * 0.03, hue === undefined ? 250 : hue);
  if (s[0] < 0.4 && pick < 0.35) return lch2hex(0.55 + r() * 0.2, 0.05 + 0.08 * (1 - s[1]), r() * 360);
  if (palette && palette.length && pick < 0.8) return palette[Math.floor(r() * palette.length)];
  return lch2hex(0.45 + 0.35 * r(), 0.08 + 0.14 * s[5] + 0.05 * r(), (hue === undefined ? r() * 360 : hue) + (r() - 0.5) * 140);
}

/** human-readable summary used by the in-game journal / HUD and by the analysis tooling */
export function describeStyle(px, py, seed) {
  const s = styleVec(px, py, seed), w = (v, a, b, c) => (v < 0.36 ? a : v < 0.64 ? b : c);
  return { vec: s, wealth: w(s[0], 'working-class', 'middle-class', 'affluent'), age: w(s[1], 'modern', 'mixed-era', 'historic'), density: w(s[2], 'sparse', 'suburban', 'dense'), ornament: w(s[3], 'plain', 'tidy', 'ornate'), order: w(s[4], 'organic', 'mixed', 'planned'), novelty: w(s[5], 'uniform', 'varied', 'eclectic') };
}
