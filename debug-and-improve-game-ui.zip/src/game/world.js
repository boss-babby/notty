// ===== world.js — seeded procedural city: tiles, districts, buildings, props, collision, A* =====
import { mulberry32, SpatialHash, clamp, hash2 } from './util.js';
import { decorate } from './genome.js';
import { STREET_V, STREET_H, REGION_STREETS, DISTRICT_NAMES } from './data.js';
import { Terra } from './terra.js';
import { genUnit } from './terra_gen.js';
import { Atlas } from './atlas.js';
import { THEMES, CULTURES } from './terra_data.js';
import { bkey, chunkKey, unkeyX, unkeyY } from './keys.js';
export { chunkKey };
import { genRegions, regionOf, REGION_NAMES } from './regions.js';
import { auditWorld } from './worldcheck.js';
import { genExtras, PLUS_PROPDEF } from './extras.js';
import { genFrontier } from './frontier.js';

// NT0 = the nine authored regions (576 tiles); the world is NT = 768 tiles: the extra 192 east + south is the procedural Frontier (frontier.js)
export const TS = 32, CT = 16, NB = 48, NB0 = 11, NT0 = 576, NT = 768, WS = NT * TS, N0 = 192;
export const T = { WATER: 0, GRASS: 1, ROAD: 2, SIDEWALK: 3, SAND: 4, BUILDING: 5, PLAZA: 6, PARKING: 7, WOOD: 8, BRIDGE: 9, DIRT: 10, PATH: 11, QUAY: 12, BRIDGEW: 13, RUNWAY: 14, TARMAC: 15, DESERT: 16, MARSH: 17, FARM: 18, FOREST: 19, SNOW: 20, CONCRETE: 21, GRAVEL: 22, TURF: 23 };
export const M = { V: 1, H: 2, XW: 4, HWY: 8 };
export const PROPDEF = {
  lamp: { r: 5, hp: 80, solid: 1 }, crate: { r: 12, hp: 35, solid: 1, low: 1 }, barrel: { r: 9, hp: 22, solid: 1, expl: 1 }, sign: { r: 4, hp: 20, solid: 1 },
  fence: { r: 6, hp: 24, solid: 1, low: 1 }, tree: { r: 7, hp: 1e9, solid: 1 }, palm: { r: 6, hp: 1e9, solid: 1 }, bench: { r: 10, hp: 60, solid: 1, low: 1 },
  bin: { r: 8, hp: 40, solid: 1, low: 1 }, hydrant: { r: 6, hp: 45, solid: 1 }, cone: { r: 6, hp: 4, solid: 0 }, umbrella: { r: 0, hp: 1e9, solid: 0 },
  fountain: { r: 30, hp: 1e9, solid: 1 }, pump: { r: 10, hp: 90, solid: 1, expl: 1 }, hay: { r: 14, hp: 40, solid: 1, low: 1 }, shard: { r: 0, hp: 1e9, solid: 0 },
  ramp: { r: 0, hp: 1e9, solid: 0 }, spike: { r: 0, hp: 1e9, solid: 0 }, rock: { r: 10, hp: 1e9, solid: 1, low: 1 },
  cactus: { r: 7, hp: 30, solid: 1 }, blocker: { r: 13, hp: 1e9, solid: 1 }, pine: { r: 8, hp: 1e9, solid: 1 }, boat: { r: 0, hp: 1e9, solid: 0 }, airliner: { r: 0, hp: 1e9, solid: 0 }, jet: { r: 0, hp: 1e9, solid: 0 }, heli: { r: 0, hp: 1e9, solid: 0 }, tank: { r: 0, hp: 1e9, solid: 0 },
  tent: { r: 16, hp: 1e9, solid: 1 }, sandbag: { r: 8, hp: 60, solid: 1, low: 1 }, turbine: { r: 6, hp: 1e9, solid: 1 }, windsock: { r: 3, hp: 20, solid: 1 }, hedge: { r: 8, hp: 1e9, solid: 1, low: 1 }, cart: { r: 8, hp: 40, solid: 1, low: 1 },
  crop: { r: 0, hp: 1e9, solid: 0 }, cattle: { r: 0, hp: 1e9, solid: 0 }, truck: { r: 0, hp: 1e9, solid: 0 }, lounger: { r: 0, hp: 1e9, solid: 0 }, helipad: { r: 0, hp: 1e9, solid: 0 }, stump: { r: 6, hp: 1e9, solid: 1, low: 1 },
};
Object.assign(PROPDEF, PLUS_PROPDEF);
const SPECIAL = { '1,4': 'safe', '5,5': 'bank', '6,5': 'police', '4,4': 'news', '2,9': 'garage', '4,9': 'kess', '5,9': 'viper', '7,6': 'hospital', '8,3': 'casino', '6,4': 'gunblock', '10,4': 'hotel', '10,6': 'club', '5,10': 'wh', '2,5': 'apts', '7,5': 'shops', '1,10': 'cranes', '10,1': 'light', '6,9': 'arena', '7,4': 'park' };
const DT_COL = ['#3a4a63', '#4b3f66', '#2f5b6b', '#5a4a4a', '#33415c', '#2c6a6a', '#63406b', '#4c5563'];
const HOUSE = ['#c9b79c', '#a7b8c9', '#c9a7a7', '#b5c9a7', '#d9d0b0'];
const ROOFS = ['#7a4b3a', '#4a5a6a', '#5a3f3a', '#3f4a3a'];
const IND = ['#6b6f73', '#7a6f5c', '#5f6b73', '#70655a'];
const CONT = ['#b5442d', '#2d6fb5', '#d49b2a', '#3a8a5a', '#7a3ab5', '#c2c2c2'];
const SHOPS = {
  shop_burger: ['BURGER BARN', 'TIDE DINER', 'LUCKY NOODLE'], shop_mart: ['CORNER MART', '24/7 MINI', 'QUICKSTOP'], shop_clothes: ['THREADS', 'NEON WEAR', 'STITCH & CO'],
  shop_gun: ['GUN DEN', 'BIG IRON'], bar: ['NIGHT OWL', 'THE ANCHOR', 'LAST CALL'],
};
const MINI = { [T.WATER]: [24, 66, 95], [T.GRASS]: [47, 90, 51], [T.ROAD]: [92, 97, 112], [T.SIDEWALK]: [122, 125, 134], [T.SAND]: [185, 165, 111], [T.PLAZA]: [105, 107, 117], [T.PARKING]: [75, 78, 88], [T.WOOD]: [122, 86, 52], [T.BRIDGE]: [110, 114, 128], [T.DIRT]: [110, 84, 56], [T.PATH]: [150, 140, 110], [T.QUAY]: [100, 104, 110], [T.BRIDGEW]: [130, 132, 140], [T.RUNWAY]: [40, 42, 48], [T.TARMAC]: [88, 92, 98], [T.DESERT]: [205, 170, 112], [T.MARSH]: [48, 92, 72], [T.FARM]: [126, 154, 72], [T.FOREST]: [38, 84, 40], [T.SNOW]: [225, 235, 240], [T.CONCRETE]: [128, 130, 128], [T.GRAVEL]: [128, 120, 108], [T.TURF]: [76, 150, 72] };
const NEONS = ['#ff4fd8', '#4fe0ff', '#ffe14a', '#7cff4f', '#ff6a3d', '#b36bff'];

export class World {
  static workerFactory = null; // set by game.js (browser only) → () => new Worker()
  constructor(seed = 1337) {
    this.seed = seed;
    this.tiles = new Uint8Array(NT * NT); this.meta = new Uint8Array(NT * NT); this.bid = new Int16Array(NT * NT).fill(-1);
    this.buildings = []; this.props = []; this.propHash = new SpatialHash(64); this.pois = {}; this.parkSpots = []; this.chunks = new Map();
    this.blocks = new Map(); this.bHash = new Map(); this.deltas = new Set(); this.unitCounter = 0; this.foundCities = new Set(); this.explored = new Set(); this.exploredIdx = null; this.tick = 0; this._lbk = -1; this._lb = null; this._stamp2 = 0; this._scb = 1e9; this._scy = 1e9; this._pend = true; this.miniC = new Map();
    this.turf = new Array(NB * NB + 1).fill(''); this.heat = new Float32Array(NB * NB + 1); this.cities = []; this.zones = []; this.res = { x: 0, y: 0, nx: 0, ny: 0, hit: 0, prop: null }; this._q = [];
    this.generate(); this.turf0 = this.turf.slice();
    this.doorList = this.buildings.filter((b) => b.door).map((b) => b.door);
    try { auditWorld(this, { T, NT, TS }); } catch (e) { console.warn('world audit failed', e); }
    for (const b of this.buildings) this.regBuilding(b);
    this.terra = new Terra(seed, { T, M, NT, NB }); this.terra.attachCore(this);
    this.atlas = new Atlas(this); this.heatS = new Map(); this.sitesRev = 0;
    this.terra.startWorker(World.workerFactory); // road routing runs in a Web Worker (falls back to time-sliced main-thread routing)
  }

  districtOf(bx, by) {
    if (bx >= 12 || by >= 12) return regionOf(bx, by);
    if (bx >= 10) return 'beach';
    if (by <= 1) return 'outskirts';
    if (by >= 8 && bx <= 6) return 'docks';
    if (bx >= 4 && bx <= 8 && by >= 3 && by <= 7) return 'downtown';
    return 'suburbs';
  }
  districtAt(x, y) {
    const ftx = Math.floor(x / TS), fty = Math.floor(y / TS);
    if (ftx < 0 || fty < 0 || ftx >= NT || fty >= NT) { const b = this.getBlock(ftx >> 4, fty >> 4); if (b.zr && x > b.zr[0] && x < b.zr[2] && y > b.zr[1] && y < b.zr[3]) return b.zk; return b.dk; }
    const tx = ftx, ty = fty;
    if (this.tiles[ty * NT + tx] === T.WATER && ((tx < N0 && ty < N0 && (tx >= 184 || ty >= 184)) || tx >= NT - 16 || ty >= NT - 16 || (tx >= NT0 - 16 && tx < NT0 && ty < NT0) || (ty >= NT0 - 16 && ty < NT0 && tx < NT0))) return 'ocean';
    for (const z of this.zones) if (x > z.x0 && x < z.x1 && y > z.y0 && y < z.y1) return z.key;
    return this.districtOf(clamp(tx >> 4, 0, NB - 1), clamp(ty >> 4, 0, NB - 1));
  }
  blockAt(x, y) { const bx = Math.floor(x / TS) >> 4, by = Math.floor(y / TS) >> 4; return bx < 0 || by < 0 || bx >= NB || by >= NB ? NB * NB : bx * NB + by; }
  /** HUD place name: authored district, or the settlement / province of the infinite world */
  areaName(x, y) {
    const tx = Math.floor(x / TS), ty = Math.floor(y / TS);
    if (tx >= 0 && ty >= 0 && tx < NT && ty < NT) return DISTRICT_NAMES[this.districtAt(x, y)] || '';
    const b = this.getBlock(tx >> 4, ty >> 4), d = this.districtAt(x, y), dn = DISTRICT_NAMES[d] || '';
    if (b.S) return `${b.place} — ${dn}`; if (d === 'fortbase') return 'Military Outpost — RESTRICTED'; return b.dk.startsWith('x_wild') ? `${b.place} · ${dn}` : `${b.place}`;
  }
  streetAt(x, y) {
    const ftx = Math.floor(x / TS), fty = Math.floor(y / TS);
    if (ftx < 0 || fty < 0 || ftx >= NT || fty >= NT) {
      const b = this.getBlock(ftx >> 4, fty >> 4), m = this.mt(ftx, fty), t = this.tl(ftx, fty), V = m & M.V, H = m & M.H;
      if (t !== T.ROAD && t !== T.BRIDGE) return b.dk.startsWith('x_wild') ? 'Backcountry' : 'Frontage Rd';
      const nm = (line, o) => { const hw = m & M.HWY; if (hw) { const hp = CULTURES[b.cul] ? CULTURES[b.cul].hwy : 'Highway', num = 1 + Math.floor(hash2(line, o, this.seed + 5) * 98); return /^[A-Z-]{1,3}$/.test(hp) ? hp + num : hp + ' ' + num; } const st = b.st || ['Main St']; return st[Math.floor(hash2(line, o, this.seed + 2) * st.length)] + (hash2(line, o, this.seed + 3) < 0.4 ? ' Rd' : ''); };
      const bx = ftx >> 4, by = fty >> 4; return V && H ? nm(bx, 1) + ' / ' + nm(by, 0) : V ? nm(bx, 1) : nm(by, 0);
    }
    const tx = ftx, ty = fty, m = this.meta[ty * NT + tx], t = this.tiles[ty * NT + tx];
    if (tx >= N0 || ty >= N0) { const rs = REGION_STREETS[regionOf(tx >> 4, ty >> 4)] || REGION_STREETS.default; const a = rs[(tx >> 4) % rs.length], b = rs[((ty >> 4) + 3) % rs.length]; if (t === T.ROAD || t === T.BRIDGE) return m & M.H && !(m & M.V) ? b : a; return a; }
    if (t === T.ROAD || t === T.BRIDGE) { if (m & M.V && !(m & M.H)) return STREET_V[tx >> 4]; if (m & M.H && !(m & M.V)) return STREET_H[ty >> 4]; return STREET_V[tx >> 4] + ' / ' + STREET_H[ty >> 4]; }
    return STREET_V[clamp((tx - 2) >> 4, 0, 11)];
  }

  // ---------- generation ----------
  poi(key, x, y, name) { this.pois[key] = { x, y, name: name || key, key }; }
  fill(x, y, w, h, t) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const k = (y + j) * NT + x + i; if (x + i < NT && y + j < NT && this.tiles[k] !== T.WATER && this.tiles[k] !== T.BUILDING) this.tiles[k] = t; } }
  free(tx, ty) { if (tx < 0 || ty < 0 || tx >= NT || ty >= NT) return false; const t = this.tiles[ty * NT + tx]; return t === T.DESERT || t === T.FOREST || t === T.GRAVEL || t === T.FARM || t === T.TURF || t === T.GRASS || t === T.SAND || t === T.PLAZA || t === T.PARKING || t === T.DIRT || t === T.SIDEWALK || t === T.PATH; }
  addProp(type, x, y, o) {
    const d = PROPDEF[type]; const p = { t: type, x, y, r: d.r, hp: d.hp, a: 0, dead: false, solid: d.solid, low: d.low, id: this.props.length, v: Math.floor(hash2(x | 0, y | 0, 3) * 4) };
    if (o) Object.assign(p, o); this.props.push(p); this.propHash.insert(p, x, y); return p;
  }
  propAtTile(type, tx, ty, o) { return this.addProp(type, tx * TS + TS / 2, ty * TS + TS / 2, o); }
  addBuilding(x, y, w, h, o = {}) {
    const b = { id: this.buildings.length, x, y, w, h, hgt: o.hgt || 20, color: o.color || '#555', roof: o.roof || null, kind: o.kind || 'shop', interior: o.interior || null, name: o.name || '', neon: o.neon || null, door: null, seed: Math.floor(hash2(x, y, 7) * 1e6) + 1, windows: o.windows !== false, rt: o.rt || null };
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const k = (y + j) * NT + x + i; this.tiles[k] = T.BUILDING; this.bid[k] = b.id; }
    if (b.interior || o.door) b.door = { x: (x + (w >> 1)) * TS + TS / 2, y: (y + h) * TS + TS / 2 };
    this.buildings.push(b); decorate(b, this.seed || 1337, { recolor: false }); return b;
  }
  parking(x, y, w, h, spots = true) {
    this.fill(x, y, w, h, T.PARKING);
    if (spots) for (let j = 0; j < h; j += 3) for (let i = 0; i < w - 1; i += 2) this.parkSpots.push({ x: (x + i + 1) * TS, y: (y + j + 1.2) * TS, a: Math.PI / 2 });
  }
  scatter(type, n, x, y, w, h, rng, ok) {
    for (let k = 0; k < n; k++) for (let tries = 0; tries < 8; tries++) {
      const tx = x + Math.floor(rng() * w), ty = y + Math.floor(rng() * h);
      if (this.free(tx, ty) && (!ok || ok(this.tiles[ty * NT + tx]))) { this.addProp(type, tx * TS + 6 + rng() * 20, ty * TS + 6 + rng() * 20); break; }
    }
  }
  fenceLine(x0, y0, x1, y1, gap) {
    const n = Math.floor(Math.hypot(x1 - x0, y1 - y0) / 22);
    for (let i = 0; i <= n; i++) { const x = x0 + ((x1 - x0) * i) / n, y = y0 + ((y1 - y0) * i) / n; if (gap && gap(x, y)) continue; this.addProp('fence', x, y); }
  }
  pickShop(rng, d) {
    const l = d === 'downtown' ? ['shop_burger', 'shop_mart', 'shop_clothes', 'bar', 'shop_gun', 'shop_burger'] : d === 'beach' ? ['bar', 'shop_burger', 'shop_clothes'] : ['shop_mart', 'shop_burger', 'bar'];
    return l[Math.floor(rng() * l.length)];
  }
  shop(x, y, w, h, rng, d, o = {}) {
    const it = o.interior || this.pickShop(rng, d), nm = SHOPS[it][Math.floor(rng() * SHOPS[it].length)];
    return this.addBuilding(x, y, w, h, { kind: 'shop', hgt: o.hgt || 22, color: o.color || DT_COL[Math.floor(rng() * DT_COL.length)], interior: it, name: nm, neon: NEONS[Math.floor(rng() * NEONS.length)] });
  }

  generate() {
    const { tiles, meta } = this;
    // 1. base classification
    for (let y = 0; y < N0; y++) for (let x = 0; x < N0; x++) {
      const cx = x >> 4, cy = y >> 4, lx = x & 15, ly = y & 15, k = y * NT + x;
      const inV = lx < 4 && y < 180, inH = ly < 4 && x < 180;
      let t = T.GRASS, m = 0;
      if (inV || inH) { t = T.ROAD; if (inV) m |= M.V; if (inH) { m |= M.H; if (cy === 0) m |= M.HWY; } }
      else if (x >= 180 || y >= 180) {
        if (x >= 184 || y >= 184) t = T.WATER;
        else if (y >= 180 && x < 180) t = x < 112 ? T.QUAY : T.SAND;
        else t = x === 180 ? T.SIDEWALK : T.SAND;
        if (x >= 180 && y >= 180) t = T.WATER;
      } else {
        const bx = cx, by = cy;
        if (lx === 4 || lx === 15 || ly === 4 || ly === 15) t = by <= 1 ? T.GRASS : T.SIDEWALK; else t = T.GRASS;
      }
      tiles[k] = t; meta[k] = m;
    }
    // 2. canal (block column 3) with bridges
    for (let y = 36; y < 184; y++) for (let x = 55; x <= 57; x++) {
      const k = y * NT + x, ly = y & 15, cy = y >> 4;
      if (y >= 180) { tiles[k] = T.WATER; continue; }
      const isRoad = ly < 4, ring = ly === 4 || ly === 15, line = ly === 15 ? cy + 1 : cy;
      if (isRoad) tiles[k] = line >= 3 ? T.BRIDGE : T.ROAD; else if (ring) tiles[k] = line >= 3 && (ly === 4 ? cy >= 3 : cy + 1 >= 3) ? T.BRIDGEW : T.WATER; else tiles[k] = T.WATER;
    }
    // 3. piers & quay docks
    for (const by of [3, 6, 9]) for (let x = 180; x < 192; x++) for (let j = 0; j < 2; j++) tiles[(by * 16 + 8 + j) * NT + x] = T.WOOD;
    for (const bx of [1, 3, 5]) for (let y = 180; y < 190; y++) for (let i = 0; i < 2; i++) { if (bx === 3 && i === 0) continue; tiles[y * NT + bx * 16 + 8 + i] = T.WOOD; }
    // 4. blocks
    for (let by = 0; by < NB0; by++) for (let bx = 0; bx < NB0; bx++) { this.genBlock(bx, by); this.turf[bx * NB + by] = { downtown: 'vel', docks: 'vip', beach: 'sun' }[this.districtOf(bx, by)] || ''; }
    // 5. crosswalks
    for (let cy = 0; cy < 12; cy++) for (let cx = 0; cx < 12; cx++) {
      const x0 = cx * 16, y0 = cy * 16;
      for (let i = 0; i < 4; i++) {
        this.xw(x0 + i, y0 + 4, M.V); this.xw(x0 + i, y0 - 1, M.V); this.xw(x0 + 4, y0 + i, M.H); this.xw(x0 - 1, y0 + i, M.H);
      }
    }
    // 6. lamps, street furniture
    const rng = mulberry32(this.seed + 99);
    for (let by = 0; by < NB0; by++) for (let bx = 0; bx < NB0; bx++) {
      const L = (tx, ty) => { if (tx < NT && ty < NT && tiles[ty * NT + tx] === T.SIDEWALK) this.propAtTile('lamp', tx, ty); };
      const a = bx * 16 + 4, b = bx * 16 + 15, c = by * 16 + 4, d = by * 16 + 15;
      L(a, c); L(b, c); L(a, d); L(b, d); L(a + 5, c); L(a + 5, d); L(a, c + 5); L(b, c + 5);
      if (rng() < 0.6) { const tx = a + 2 + Math.floor(rng() * 8); if (tiles[c * NT + tx] === T.SIDEWALK) this.propAtTile(rng() < 0.5 ? 'hydrant' : 'bin', tx, c); }
      if (rng() < 0.4) { const ty = c + 2 + Math.floor(rng() * 8); if (tiles[ty * NT + a] === T.SIDEWALK) this.propAtTile('bench', a, ty); }
    }
    // 7. stunt ramps, shards, POIs
    [[40 * TS, 3 * TS, 0], [120 * TS, TS, Math.PI], [160 * TS + TS, 70 * TS, Math.PI / 2], [30 * TS, 176 * TS + 96, 0], [6 * 512 + 96, 70 * TS, -Math.PI / 2]].forEach(([x, y, a]) => this.addProp('ramp', x, y, { a }));
    let n = 0, guard = 0;
    while (n < 24 && guard++ < 4000) {
      const tx = 6 + Math.floor(rng() * 176), ty = 6 + Math.floor(rng() * 174), t = tiles[ty * NT + tx];
      if ((t === T.SAND || t === T.PLAZA || t === T.GRASS || t === T.WOOD || t === T.DIRT || t === T.QUAY) && (this.free(tx, ty) || t === T.WOOD || t === T.QUAY) && this.nearSolid(tx, ty) < 1) { this.propAtTile('shard', tx, ty); n++; }
    }
    this.poi('start', 4 * 512 + 256, 176 * TS + 96, 'Harbor Road');
    this.poi('pier', 189 * TS, 105 * TS, 'Sunset Pier');
    this.poi('raceStart', 6 * 512 + 96, 4 * 512 + 256, 'Race Start');
    genRegions(this, { T, M, TS, NT, NT0, N0, NB, mulberry32, hash2, clamp });
    genFrontier(this, { T, M, TS, NT, NT0, NB });
    this.aircraftSpots = this.aircraftSpots || [];
    try { genExtras(this, { T, M, TS, NT, hash2, mulberry32 }); } catch (e) { console.warn('extras', e); }
  }
  xw(x, y, bit) { if (x < 0 || y < 0 || x >= NT || y >= NT) return; const k = y * NT + x; if (this.tiles[k] === T.ROAD && (this.meta[k] & (M.V | M.H)) === bit) this.meta[k] |= M.XW; }
  nearSolid(tx, ty) { for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) { const t = this.tiles[(ty + j) * NT + tx + i]; if (t === T.BUILDING || t === T.WATER) return 1; } return 0; }

  genBlock(bx, by) {
    const d = this.districtOf(bx, by), rng = mulberry32(this.seed * 7919 + bx * 131 + by * 977);
    const R = (a, b) => a + Math.floor(rng() * (b - a + 1)), P = (a) => a[Math.floor(rng() * a.length)];
    let x0 = bx * CT + 5, y0 = by * CT + 5, w = 10;
    const sp = SPECIAL[bx + ',' + by];
    this.fill(x0, y0, 10, 10, { downtown: T.PLAZA, suburbs: T.GRASS, docks: T.PARKING, beach: T.SAND, outskirts: T.GRASS }[d]);
    if (bx === 3 && by >= 2) { for (let j = 0; j < 10; j++) this.fill(x0, y0 + j, 2, 1, T.GRASS); this.scatter('tree', 3, x0, y0, 2, 10, rng); x0 += 5; w = 5; }
    const O = { x0, y0, w, rng, R, P, d, bx, by };
    if (sp) { this.special(sp, O); return; }
    if (d === 'downtown') this.genDowntown(O);
    else if (d === 'suburbs') this.genSuburbs(O);
    else if (d === 'docks') this.genDocks(O);
    else if (d === 'beach') this.genBeach(O);
    else this.genOutskirts(O);
  }
  park(x0, y0, w, h, rng) {
    this.fill(x0, y0, w, h, T.GRASS);
    for (let i = 0; i < w; i++) this.fill(x0 + i, y0 + (h >> 1), 1, 1, T.PATH);
    for (let j = 0; j < h; j++) this.fill(x0 + (w >> 1), y0 + j, 1, 1, T.PATH);
    this.addProp('fountain', (x0 + (w >> 1) + 0.5) * TS, (y0 + (h >> 1) + 0.5) * TS);
    this.scatter('tree', 14, x0, y0, w, h, rng); this.scatter('bench', 4, x0, y0, w, h, rng);
  }
  genDowntown({ x0, y0, rng, R, P }) {
    const r = rng();
    if (r < 0.14) { this.park(x0, y0, 10, 10, rng); return; }
    if (r < 0.52) {
      const b = this.addBuilding(x0 + 1, y0 + 1, 8, 8, { kind: 'tower', hgt: R(44, 64), color: P(DT_COL), name: '', neon: P(NEONS) });
      if (rng() < 0.5) { b.interior = null; } return;
    }
    this.shop(x0, y0, 5, 4, rng, 'downtown'); this.shop(x0 + 5, y0, 5, 4, rng, 'downtown');
    this.addBuilding(x0, y0 + 5, 6, 5, { kind: 'tower', hgt: R(36, 52), color: P(DT_COL), neon: P(NEONS) });
    this.shop(x0 + 6, y0 + 5, 4, 5, rng, 'downtown', { hgt: 26 });
    this.scatter('crate', 2, x0, y0 + 4, 10, 1, rng);
  }
  genSuburbs({ x0, y0, w, rng, R, P }) {
    if (w === 10 && rng() < 0.2) {
      this.addBuilding(x0 + 1, y0 + 1, 8, 4, { kind: 'apt', hgt: 30, color: '#8c7f8f', interior: 'apartment', name: 'RESIDENCES', neon: null });
      this.parking(x0 + 1, y0 + 6, 8, 3); this.scatter('tree', 5, x0, y0, 10, 10, rng); return;
    }
    for (let j = 0; j < 2; j++) for (let i = 0; i < w / 5; i++) {
      const lx = x0 + i * 5, ly = y0 + j * 5, hw = R(3, 4);
      this.addBuilding(lx + 1, ly + 1, hw, 3, { kind: 'house', hgt: R(12, 18), color: P(HOUSE), roof: P(ROOFS), door: true, windows: true });
      this.fill(lx + 1, ly + 4, 2, 1, T.PARKING); this.parkSpots.push({ x: (lx + 2) * TS, y: (ly + 4.5) * TS, a: Math.PI / 2 });
      this.scatter('tree', 2, lx, ly, 5, 5, rng, (t) => t === T.GRASS);
      if (rng() < 0.45) this.fenceLine(lx * TS + 4, (ly + 5) * TS - 4, (lx + 5) * TS - 4, (ly + 5) * TS - 4, (x) => x > (lx + 1) * TS && x < (lx + 3) * TS);
    }
  }
  genDocks({ x0, y0, w, rng, R, P }) {
    const v = rng();
    if (v < 0.4 && w === 10) {
      this.addBuilding(x0, y0, 10, 4, { kind: 'warehouse', hgt: 24, color: P(IND), door: true }); this.addBuilding(x0, y0 + 6, 10, 4, { kind: 'warehouse', hgt: 22, color: P(IND), door: true });
      this.scatter('barrel', 4, x0, y0 + 4, 10, 2, rng); this.scatter('crate', 3, x0, y0 + 4, 10, 2, rng);
    } else if (v < 0.75) {
      for (let j = 0; j < 4; j++) for (let i = 0; i < Math.floor(w / 3); i++) if (rng() < 0.75) this.addBuilding(x0 + i * 3 + (j % 2), y0 + 1 + j * 2 + (rng() < 0.3 ? 1 : 0) * 0, 2, 1, { kind: 'container', hgt: 14, color: P(CONT), windows: false });
      this.scatter('barrel', 3, x0, y0, w, 10, rng);
    } else { this.parking(x0, y0, w, 10); this.scatter('crate', 3, x0, y0, w, 10, rng); this.fenceLine(x0 * TS, y0 * TS, (x0 + w) * TS, y0 * TS); }
  }
  genBeach({ x0, y0, rng, R, P, d }) {
    for (let j = 0; j < 10; j++) this.fill(x0 + 8, y0 + j, 2, 1, T.WOOD);
    if (rng() < 0.7) this.shop(x0 + 1, y0 + 1, 5, 3, rng, d, { hgt: 18 });
    if (rng() < 0.6) this.shop(x0 + 1, y0 + 6, 5, 3, rng, d, { hgt: 18 });
    this.scatter('umbrella', 6, x0, y0, 8, 10, rng, (t) => t === T.SAND); this.scatter('palm', 5, x0, y0, 8, 10, rng, (t) => t === T.SAND);
  }
  genOutskirts({ x0, y0, w, rng, R, P, bx, by }) {
    const v = rng();
    if (v < 0.35) {
      this.fill(x0, y0, 10, 10, T.DIRT); this.fill(x0 + 5, y0 + 3, 4, 2, T.GRASS);
      this.addBuilding(x0 + 1, y0 + 1, 5, 4, { kind: 'barn', hgt: 24, color: '#9b3a2a', roof: '#6b2a20', door: true, windows: false });
      this.addBuilding(x0 + 7, y0 + 1, 3, 3, { kind: 'house', hgt: 16, color: P(HOUSE), roof: P(ROOFS), door: true });
      this.addBuilding(x0 + 7, y0 + 5, 2, 2, { kind: 'silo', hgt: 42, color: '#9aa0a6', windows: false });
      this.scatter('hay', 5, x0, y0 + 5, 7, 5, rng); this.scatter('tree', 5, x0, y0, 10, 10, rng);
    } else if (v < 0.55 && by === 1) {
      this.parking(x0 + 1, y0 + 4, 8, 5, false); this.fill(x0 + 1, y0 + 4, 8, 5, T.PARKING);
      const b = this.addBuilding(x0 + 2, y0 + 1, 5, 3, { kind: 'shop', hgt: 16, color: '#cfd8dc', interior: 'shop_mart', name: 'GAS-N-GO', neon: '#ffe14a' });
      this.propAtTile('pump', x0 + 2, y0 + 6); this.propAtTile('pump', x0 + 4, y0 + 6); this.propAtTile('pump', x0 + 6, y0 + 6);
      this.parkSpots.push({ x: (x0 + 3) * TS, y: (y0 + 8) * TS, a: Math.PI / 2 }); void b;
    } else { this.scatter('tree', 30, x0, y0, 10, 10, rng); this.scatter('rock', 4, x0, y0, 10, 10, rng); }
  }

  // ----- hand-placed story blocks -----
  special(k, { x0, y0, rng, R, P, d }) {
    const B = (x, y, w, h, o) => this.addBuilding(x0 + x, y0 + y, w, h, o);
    const door = (key, b, name) => this.poi(key, b.door.x, b.door.y, name);
    switch (k) {
      case 'safe': {
        this.fill(x0, y0, 10, 10, T.GRASS);
        const b = B(1, 1, 8, 5, { kind: 'apt', hgt: 32, color: '#8a7f9a', interior: 'safehouse', name: 'HARBOR VIEW APTS', neon: '#4fe0ff' }); door('safe', b, 'Safehouse');
        this.parking(x0 + 1, y0 + 7, 8, 3, false); [0, 2, 4, 6].forEach((i) => this.parkSpots.push({ x: (x0 + 2 + i) * TS, y: (y0 + 8) * TS, a: Math.PI / 2 }));
        this.poi('safe_park', (x0 + 2) * TS, (y0 + 8) * TS, 'Garage'); this.scatter('tree', 6, x0, y0, 10, 10, rng, (t) => t === T.GRASS); break;
      }
      case 'bank': { const b = B(1, 1, 8, 6, { kind: 'civic', hgt: 44, color: '#586b8a', interior: 'bank', name: 'MERIDIAN SAVINGS', neon: '#4fe0ff' }); door('bank', b, 'Meridian Savings'); this.scatter('bin', 2, x0, y0 + 8, 10, 2, rng); break; }
      case 'police': { const b = B(1, 1, 8, 6, { kind: 'civic', hgt: 36, color: '#2a3f6b', interior: 'police', name: 'PMPD HEADQUARTERS', neon: '#4aa8ff' }); door('police', b, 'Police HQ'); this.parkSpots.push({ x: (x0 + 2) * TS, y: (y0 + 8.5) * TS, a: 0, cop: 1 }, { x: (x0 + 7) * TS, y: (y0 + 8.5) * TS, a: 0, cop: 1 }); break; }
      case 'news': { const b = B(2, 1, 6, 8, { kind: 'tower', hgt: 62, color: '#2f5b6b', interior: 'office', name: 'MERIDIAN LEDGER', neon: '#ffe14a' }); door('nina', b, 'Ledger Tower'); break; }
      case 'garage': {
        this.fill(x0, y0, 10, 10, T.PARKING);
        const b = B(1, 2, 7, 4, { kind: 'warehouse', hgt: 22, color: '#7a5d44', interior: 'garage', name: "GUS'S GARAGE", neon: '#ff6a3d' }); door('gus', b, "Gus's Garage");
        this.scatter('barrel', 3, x0, y0 + 6, 10, 3, rng); this.scatter('crate', 3, x0 + 8, y0, 2, 8, rng);
        this.parkSpots.push({ x: (x0 + 2) * TS, y: (y0 + 8) * TS, a: Math.PI / 2 }); break;
      }
      case 'kess': {
        this.fill(x0, y0, 10, 10, T.PARKING);
        B(2, 1, 6, 3, { kind: 'warehouse', hgt: 26, color: '#4a4f55', name: 'KESSLER FREIGHT', neon: '#ff3b5c' });
        B(0, 5, 2, 1, { kind: 'container', hgt: 14, color: '#b5442d', windows: false }); B(7, 6, 3, 1, { kind: 'container', hgt: 14, color: '#2d6fb5', windows: false }); B(3, 6, 2, 1, { kind: 'container', hgt: 14, color: '#d49b2a', windows: false });
        B(8, 4, 2, 1, { kind: 'container', hgt: 14, color: '#3a8a5a', windows: false });
        const px0 = x0 * TS - 6, py0 = y0 * TS - 6, px1 = (x0 + 10) * TS + 6, py1 = (y0 + 10) * TS + 6, gate = (x, y) => y > py1 - 10 && x > px0 + 4.2 * TS && x < px0 + 6.2 * TS;
        this.fenceLine(px0, py0, px1, py0); this.fenceLine(px0, py0, px0, py1); this.fenceLine(px1, py0, px1, py1); this.fenceLine(px0, py1, px1, py1, gate);
        this.scatter('barrel', 4, x0, y0 + 4, 10, 5, rng); this.scatter('crate', 3, x0, y0 + 4, 10, 5, rng);
        this.poi('kess', (x0 + 5) * TS, (y0 + 6.5) * TS, 'Kessler Freight'); this.poi('kess_gate', (x0 + 5) * TS, (y0 + 10.4) * TS, 'Freight Gate'); this.poi('ledger', (x0 + 9) * TS, (y0 + 2) * TS, 'Ledger'); break;
      }
      case 'viper': {
        this.fill(x0, y0, 10, 10, T.PARKING);
        const b = B(2, 2, 5, 4, { kind: 'shop', hgt: 18, color: '#3a5a3a', interior: 'bar', name: 'THE RUSTED EEL', neon: '#7cff4f' }); door('viper', b, 'The Rusted Eel');
        this.scatter('barrel', 3, x0, y0 + 6, 10, 3, rng); this.parkSpots.push({ x: (x0 + 8) * TS, y: (y0 + 3) * TS, a: 0 }); break;
      }
      case 'hospital': { const b = B(1, 1, 8, 6, { kind: 'civic', hgt: 34, color: '#d3d9e2', roof: '#eef2f7', interior: 'hospital', name: 'MERIDIAN GENERAL', neon: '#ff4f6a' }); door('hosp', b, 'Meridian General'); break; }
      case 'casino': { const b = B(1, 1, 8, 7, { kind: 'tower', hgt: 52, color: '#5b2f6b', interior: 'casino', name: 'GOLD COAST CASINO', neon: '#ffd24a' }); door('casino', b, 'Gold Coast Casino'); break; }
      case 'gunblock': {
        const a = B(0, 0, 4, 4, { kind: 'shop', hgt: 24, color: '#4c5563', interior: 'shop_gun', name: 'GUN DEN', neon: '#ff3b5c' }); door('gun', a, 'Gun Den');
        const c = B(5, 0, 5, 4, { kind: 'shop', hgt: 24, color: '#63406b', interior: 'shop_clothes', name: 'THREADS', neon: '#ff4fd8' }); door('clothes', c, 'Threads');
        B(0, 5, 10, 5, { kind: 'tower', hgt: 42, color: '#33415c', neon: '#4fe0ff' }); break;
      }
      case 'hotel': { this.fill(x0, y0, 8, 10, T.SAND); const b = B(1, 1, 6, 6, { kind: 'tower', hgt: 72, color: '#d9cdb8', roof: '#bfae92', name: 'SUNSET HOTEL', neon: '#ff9a3c', door: true }); door('hotel', b, 'Sunset Hotel'); for (let j = 0; j < 10; j++) this.fill(x0 + 8, y0 + j, 2, 1, T.WOOD); this.scatter('palm', 4, x0, y0 + 7, 8, 3, rng); break; }
      case 'club': {
        for (let j = 0; j < 10; j++) this.fill(x0 + 8, y0 + j, 2, 1, T.WOOD);
        const b = B(1, 2, 6, 4, { kind: 'shop', hgt: 20, color: '#4a2f6b', interior: 'bar', name: 'CLUB TIDE', neon: '#ff4fd8' }); door('p_club', b, 'Club Tide'); this.poi('club', (x0 + 9) * TS, (y0 + 5) * TS, 'Boardwalk'); this.scatter('umbrella', 6, x0, y0 + 6, 8, 4, rng); this.scatter('palm', 3, x0, y0, 8, 10, rng); break;
      }
      case 'wh': { this.fill(x0, y0, 10, 10, T.PARKING); const b = B(1, 1, 8, 5, { kind: 'warehouse', hgt: 24, color: '#5f6b73', name: 'TIDEWATER STORAGE', door: true }); door('p_wh', b, 'Dockside Warehouse'); this.scatter('crate', 5, x0, y0 + 6, 10, 4, rng); break; }
      case 'apts': { const b = B(1, 1, 8, 4, { kind: 'apt', hgt: 30, color: '#9a8a8a', interior: 'apartment', name: 'HARBORLINE APTS', neon: null }); door('p_apt', b, 'Harborline Apartments'); this.parking(x0 + 1, y0 + 6, 8, 3); this.scatter('tree', 5, x0, y0, 10, 10, rng); break; }
      case 'shops': {
        const a = B(0, 0, 4, 4, { kind: 'shop', hgt: 24, color: '#4b3f66', interior: 'shop_burger', name: 'LUCKY NOODLE', neon: '#ffe14a' }); door('p_shop', a, 'Lucky Noodle');
        this.shop(x0 + 4, y0, 3, 4, rng, d); this.shop(x0 + 7, y0, 3, 4, rng, d); B(0, 5, 10, 5, { kind: 'tower', hgt: 48, color: '#2f5b6b', neon: '#7cff4f' }); break;
      }
      case 'cranes': {
        this.fill(x0, y0, 10, 10, T.PARKING); B(0, 0, 2, 2, { kind: 'crane', hgt: 80, color: '#e0a526', windows: false }); B(8, 0, 2, 2, { kind: 'crane', hgt: 80, color: '#e0a526', windows: false });
        B(2, 0, 3, 1, { kind: 'container', hgt: 14, color: '#2d6fb5', windows: false }); B(6, 0, 2, 1, { kind: 'container', hgt: 14, color: '#b5442d', windows: false });
        this.scatter('barrel', 6, x0, y0 + 3, 10, 7, rng); this.scatter('crate', 5, x0, y0 + 3, 10, 7, rng);
        this.poi('cranes', (x0 + 5) * TS, (y0 + 6) * TS, 'The Cranes'); break;
      }
      case 'light': {
        this.fill(x0, y0, 10, 10, T.SAND); this.scatter('rock', 8, x0, y0, 10, 10, rng); this.scatter('palm', 3, x0, y0, 10, 10, rng);
        const b = B(4, 3, 2, 2, { kind: 'light', hgt: 96, color: '#ece7e0', roof: '#c0392b', windows: false, door: true }); door('light', b, 'Lighthouse'); this.fill(x0 + 4, y0 + 5, 2, 5, T.PATH); break;
      }
      case 'arena': { this.fill(x0, y0, 10, 10, T.PARKING); const b = B(1, 1, 8, 5, { kind: 'warehouse', hgt: 24, color: '#5a2a2a', interior: 'arena', name: 'THE PIT', neon: '#ff3b3b' }); door('arena', b, 'The Pit'); this.scatter('barrel', 3, x0, y0 + 7, 10, 3, rng); break; }
      case 'park': this.park(x0, y0, 10, 10, rng); this.poi('park', (x0 + 5) * TS, (y0 + 6) * TS, 'Central Park'); break;
      default: break;
    }
  }

  // ---------- queries & collision ----------
  // ---- tile access: flat arrays for the authored core, lazily generated blocks everywhere else (the world has no edge) ----
  tl(tx, ty) { if (tx >= 0 && ty >= 0 && tx < NT && ty < NT) return this.tiles[ty * NT + tx]; return this.getBlock(tx >> 4, ty >> 4).t[((ty & 15) << 4) | (tx & 15)]; }
  mt(tx, ty) { if (tx >= 0 && ty >= 0 && tx < NT && ty < NT) return this.meta[ty * NT + tx]; return this.getBlock(tx >> 4, ty >> 4).m[((ty & 15) << 4) | (tx & 15)]; }
  bidAt(tx, ty) { if (tx >= 0 && ty >= 0 && tx < NT && ty < NT) return this.bid[ty * NT + tx]; return this.getBlock(tx >> 4, ty >> 4).bid[((ty & 15) << 4) | (tx & 15)]; }
  getBlock(bx, by) {
    const k = bkey(bx, by); if (k === this._lbk) return this._lb;
    let b = this.blocks.get(k);
    if (!b) {
      let bs = null; try { bs = genUnit(this.terra, this, { T, M }, bx, by); } catch (e) { this.genFails = (this.genFails || 0) + 1; if (this.genFails < 4) console.warn('block generation failed — using safe terrain', bx, by, e); }
      if (bs) for (const x of bs) { this.blocks.set(x.key, x); this.onBlock(x); }
      b = this.blocks.get(k); if (!b) { b = this.safeBlock(bx, by); this.blocks.set(k, b); }
    }
    b.last = this.tick; this._lbk = k; this._lb = b; return b;
  }
  /** last-resort terrain for a block whose generator threw: flat meadow, no props — the game keeps running and the rest of the world is unaffected */
  safeBlock(bx, by) { return { bx, by, key: bkey(bx, by), t: new Uint8Array(256).fill(T.GRASS), m: new Uint8Array(256), bid: new Int32Array(256).fill(-1), bld: [], props: [], park: [], poi: [], dk: 'grass', place: 'meadow', st: new Array(10).fill(''), hw: 0, zr: null, zk: null, found: null, role: '', kit: null, last: this.tick, unit: 0, S: null, biome: 'plain', cul: 0 }; }
  onBlock(b) {
    const A = this.atlas;
    if (b.found) {
      const n = b.found, x = (b.bx * 16 + 10) * TS, y = (b.by * 16 + 13.9) * TS, cat = ['village', 'town', 'city', 'metro'][n.cls] || 'village';
      if (n.cls >= 1) { b.poi.push({ key: 'c_' + n.key, x, y, name: n.name, cat }); const s = A.add({ key: 'c_' + n.key, name: n.name, x, y, cat, fast: true }); if (s) this.addDestination(s); }
      else { b.poi.push({ key: 'v_' + n.key, x, y, name: n.name, cat }); A.add({ key: 'v_' + n.key, name: n.name, x, y, cat }); }
    }
    for (const p of b.poi) { if (A.has(p.key)) continue; const s = A.add({ key: p.key, name: p.name, x: p.x, y: p.y, cat: p.cat, fast: !!p.fast }); if (s && s.fast) this.addDestination(s); }
  }
  /** fast-travel / flight destination (procedural city or regional airport) — registered once, whenever it is first generated or loaded from a save */
  addDestination(s) {
    const key = s.key.startsWith('c_') ? s.key.slice(2) : s.key;
    if (this.foundCities.has(key)) return; this.foundCities.add(key);
    this.cities.push({ key, name: s.name, x: s.x, y: s.y, airport: s.cat === 'airport', cat: s.cat });
    if (!this.pois['c_' + key]) this.pois['c_' + key] = { x: s.x, y: s.y, name: s.name, key: 'c_' + key, cat: s.cat };
    this.sitesRev++;
  }
  /** destinations sorted by distance from (x,y) (nearest first) */
  destinationsNear(x, y, airportsOnly = false) {
    return this.cities.filter((c) => !airportsOnly || c.airport || c.key === 'airport').map((c) => ({ c, d: Math.hypot(c.x - x, c.y - y) })).sort((a, b) => a.d - b.d);
  }
  // ----- sparse, unbounded heat (the dense array only covers the authored core) -----
  heatAdd(x, y, a) { const i = this.blockAt(x, y); if (i < NB * NB) { this.heat[i] += a; return; } const k = bkey(Math.floor(x / 512), Math.floor(y / 512)); this.heatS.set(k, (this.heatS.get(k) || 0) + a); }
  heatAt(x, y) { const i = this.blockAt(x, y); if (i < NB * NB) return this.heat[i]; return this.heatS.get(bkey(Math.floor(x / 512), Math.floor(y / 512))) || 0; }
  heatDecay(f) { for (let i = 0; i < this.heat.length; i++) this.heat[i] *= f; for (const [k, v] of this.heatS) { const n = v * f; if (n < 0.4) this.heatS.delete(k); else this.heatS.set(k, n); } }
  heatClear() { this.heat.fill(0); this.heatS.clear(); }
  markExplored(cb, cy, r = 3) { let n = 0; for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) { const k = bkey(cb + i, cy + j); if (!this.explored.has(k)) { this.explored.add(k); this._idxAdd(cb + i, cy + j); n++; } } if (n) this.exploredRev = (this.exploredRev || 0) + 1; }
  /** per-LOD counts of explored blocks per macro tile (tile = 8·4^L blocks) — lets the world map bake / skip tiles without scanning the explored set */
  _idxAdd(bx, by) { const I = this.exploredIdx || (this.exploredIdx = [new Map(), new Map(), new Map(), new Map(), new Map()]); for (let L = 0; L < 5; L++) { const S = 8 << (2 * L), k = bkey(Math.floor(bx / S), Math.floor(by / S)); I[L].set(k, (I[L].get(k) || 0) + 1); } }
  reindexExplored() { this.exploredIdx = null; for (const k of this.explored) this._idxAdd(unkeyX(k), unkeyY(k)); this.exploredRev = (this.exploredRev || 0) + 1; }
  regBuilding(b) { const x1 = (b.x + b.w - 1) >> 4, y1 = (b.y + b.h - 1) >> 4; for (let by = b.y >> 4; by <= y1; by++) for (let bx = b.x >> 4; bx <= x1; bx++) { const k = bkey(bx, by); let a = this.bHash.get(k); if (!a) { a = []; this.bHash.set(k, a); } a.push(b); } }
  unregBuilding(b) { const x1 = (b.x + b.w - 1) >> 4, y1 = (b.y + b.h - 1) >> 4; for (let by = b.y >> 4; by <= y1; by++) for (let bx = b.x >> 4; bx <= x1; bx++) { const k = bkey(bx, by), a = this.bHash.get(k); if (a) { const i = a.indexOf(b); if (i >= 0) a.splice(i, 1); if (!a.length) this.bHash.delete(k); } } }
  /** buildings whose footprint touches the px rectangle (deduplicated) */
  buildingsNear(x0, y0, x1, y1, out) {
    const st = ++this._stamp2, bx1 = Math.floor(x1 / 512), by1 = Math.floor(y1 / 512);
    for (let by = Math.floor(y0 / 512); by <= by1; by++) for (let bx = Math.floor(x0 / 512); bx <= bx1; bx++) { const a = this.bHash.get(bkey(bx, by)); if (a) for (let i = 0; i < a.length; i++) { const b = a[i]; if (b._s !== st) { b._s = st; out.push(b); } } }
    return out;
  }
  nearestEnterable(x, y, r) { const q = this._nq || (this._nq = []); q.length = 0; this.buildingsNear(x - r - 64, y - r - 96, x + r + 64, y + r + 64, q); let best = null, bd = r; for (const b of q) { if (!b.interior || !b.door) continue; const d = Math.hypot(x - b.door.x, y - b.door.y); if (d < bd) { bd = d; best = b; } } return best; }
  randomDoor(x, y, minD, maxD) { const q = this._nq2 || (this._nq2 = []); q.length = 0; this.buildingsNear(x - maxD, y - maxD, x + maxD, y + maxD, q); const c = []; for (const b of q) { if (!b.door || b.kind === 'mountain') continue; const d = Math.hypot(b.door.x - x, b.door.y - y); if (d >= minD && d <= maxD) c.push(b.door); } return c.length ? c[Math.floor(Math.random() * c.length)] : null; }
  parkIter(x, y, r) { const o = this._pk || (this._pk = []); o.length = 0; for (const s of this.parkSpots) o.push(s); const cb = Math.floor(x / 512), cy = Math.floor(y / 512), n = Math.ceil(r / 512); for (let j = cy - n; j <= cy + n; j++) for (let i = cb - n; i <= cb + n; i++) { const b = this.blocks.get(bkey(i, j)); if (b) for (const s of b.park) o.push(s); } return o; }
  poiNear(x, y, r, out) { const cb = Math.floor(x / 512), cy = Math.floor(y / 512), n = Math.ceil(r / 512); for (let j = cy - n; j <= cy + n; j++) for (let i = cb - n; i <= cb + n; i++) { const b = this.blocks.get(bkey(i, j)); if (b && b.poi.length) for (const p of b.poi) out.push(p); } return out; }
  /** keep generated blocks around the player; generate ahead within a time budget; evict far, least-recently-used units */
  stream(px, py) {
    this.tick++; const cb = Math.floor(px / 512), cy = Math.floor(py / 512);
    if (cb !== this._scb || cy !== this._scy) { this._scb = cb; this._scy = cy; this._pend = true; this.markExplored(cb, cy); this.terra.prefetchRoads(cb, cy); }
    if (this._pend) {
      const t0 = performance.now(); let done = true;
      outer: for (let r = 0; r <= 5; r++) for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) {
        if (Math.max(Math.abs(i), Math.abs(j)) !== r) continue; const bx = cb + i, by = cy + j; if (bx >= 0 && by >= 0 && bx < NB && by < NB) continue;
        if (!this.blocks.has(bkey(bx, by))) { this.getBlock(bx, by); if (performance.now() - t0 > 5) { done = false; break outer; } }
      }
      this._pend = !done;
    }
    if (this.blocks.size > 1100 && (this.tick & 31) === 0) this.evict(cb, cy);
  }
  evict(cb, cy) {
    const units = new Map();
    for (const b of this.blocks.values()) { const d = Math.max(Math.abs(b.bx - cb), Math.abs(b.by - cy)); let u = units.get(b.unit); if (!u) { u = { id: b.unit, d: 99999, last: 0, bl: [] }; units.set(b.unit, u); } u.d = Math.min(u.d, d); u.last = Math.max(u.last, b.last); u.bl.push(b); }
    const far = [...units.values()].filter((u) => u.d > 10).sort((a, b) => a.last - b.last);
    for (const u of far) {
      if (this.blocks.size <= 800) break;
      for (const b of u.bl) {
        this.propHash.dropCells(b.bx * 512, b.by * 512, (b.bx + 1) * 512, (b.by + 1) * 512);
        for (const id of b.bld) { const bd = this.buildings[id]; if (bd) { this.unregBuilding(bd); this.buildings[id] = null; if (this.onDropBuilding) this.onDropBuilding(id); } }
        this.blocks.delete(b.key);
      }
    }
    this._lbk = -1; this._lb = null;
  }
  /** 16×16 RGBA for the minimap / world map: exact for loaded blocks, pure-macro approximation for the rest */
  miniRGBA(bx, by) {
    const k = bkey(bx, by), b = this.blocks.get(k), c = this.miniC.get(k); if (c && (c.exact || !b)) return c.px;
    let px;
    if (!b) px = this.terra.mini(bx, by);
    else {
      px = new Uint8ClampedArray(1024);
      for (let i = 0; i < 256; i++) {
        const t = b.t[i]; let col = MINI[t] || MINI[T.GRASS];
        if (t === T.BUILDING) { const bd = this.buildings[b.bid[i]]; col = bd && bd.kind === 'civic' ? [140, 150, 190] : bd && bd.kind === 'mountain' ? (bd.hgt > 100 ? [200, 206, 212] : [112, 104, 94]) : [64, 69, 84]; }
        px[i * 4] = col[0]; px[i * 4 + 1] = col[1]; px[i * 4 + 2] = col[2]; px[i * 4 + 3] = 255;
      }
    }
    if (this.miniC.size > 4000) this.miniC.clear(); this.miniC.set(k, { px, exact: !!b }); return px;
  }
  solid(x, y) { return this.tl(Math.floor(x / TS), Math.floor(y / TS)) === T.BUILDING; }
  isRoad(x, y) { const t = this.tileAt(x, y); return t === T.ROAD || t === T.BRIDGE; }
  solidTile(tx, ty) { return this.tl(tx, ty) === T.BUILDING; }
  tileAt(x, y) { return this.tl(Math.floor(x / TS), Math.floor(y / TS)); }
  metaAt(x, y) { return this.mt(Math.floor(x / TS), Math.floor(y / TS)); }
  buildingAt(x, y) { const tx = Math.floor(x / TS), ty = Math.floor(y / TS); if (this.tl(tx, ty) !== T.BUILDING) return null; const i = this.bidAt(tx, ty); return i >= 0 ? this.buildings[i] : null; }
  /** push a circle out of solid tiles (and solid props). Result in this.res */
  pushCircle(x, y, r, props = true, vault = false) {
    const res = this.res; res.hit = 0; res.nx = 0; res.ny = 0; res.prop = null;
    const tx0 = Math.floor((x - r) / TS), tx1 = Math.floor((x + r) / TS), ty0 = Math.floor((y - r) / TS), ty1 = Math.floor((y + r) / TS);
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      if (!this.solidTile(tx, ty)) continue;
      const cx = clamp(x, tx * TS, tx * TS + TS), cy = clamp(y, ty * TS, ty * TS + TS), dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy;
      if (d2 >= r * r) continue;
      let nx, ny, pen;
      if (d2 > 1e-6) { const d = Math.sqrt(d2); nx = dx / d; ny = dy / d; pen = r - d; }
      else { const l = x - tx * TS, rr = tx * TS + TS - x, t = y - ty * TS, b = ty * TS + TS - y, m = Math.min(l, rr, t, b); if (m === l) { nx = -1; ny = 0; } else if (m === rr) { nx = 1; ny = 0; } else if (m === t) { nx = 0; ny = -1; } else { nx = 0; ny = 1; } pen = r + m; }
      x += nx * pen; y += ny * pen; res.hit++; res.nx = nx; res.ny = ny;
    }
    if (props) {
      const q = this._q; q.length = 0; this.propHash.query(x, y, r + 34, q);
      for (let i = 0; i < q.length; i++) {
        const p = q[i]; if (p.dead || !p.solid || (vault && p.low)) continue;
        const dx = x - p.x, dy = y - p.y, rr = r + p.r, d2 = dx * dx + dy * dy;
        if (d2 >= rr * rr) continue;
        const d = Math.sqrt(d2) || 0.01, nx = dx / d, ny = dy / d; x += nx * (rr - d); y += ny * (rr - d); res.hit++; res.nx = nx; res.ny = ny; res.prop = p;
      }
    }
    res.x = x; res.y = y; return res;
  }
  /** is the straight segment free of solid tiles? */
  lineClear(x0, y0, x1, y1) {
    const d = Math.hypot(x1 - x0, y1 - y0), n = Math.ceil(d / 14);
    for (let i = 1; i < n; i++) { const t = i / n; if (this.solid(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)) return false; }
    return true;
  }
  /** first solid hit along a ray; returns distance or max */
  raycast(x, y, dx, dy, max) { for (let d = 8; d < max; d += 8) if (this.solid(x + dx * d, y + dy * d)) return d; return max; }
  arms(cx, cy) { const ix = cx * 512, iy = cy * 512; return (this.isRoad(ix + 168, iy + 64) ? 1 : 0) + (this.isRoad(ix + 64, iy + 168) ? 1 : 0) + (this.isRoad(ix - 40, iy + 64) ? 1 : 0) + (this.isRoad(ix + 64, iy - 40) ? 1 : 0); }
  trafficLight(cx, cy, t, vertical) {
    const p = (t + ((((cx * 7 + cy * 13) % 24) + 24) % 24)) % 24;
    if (vertical) return p < 9 ? 0 : p < 11 ? 1 : 2;
    return p >= 12 && p < 21 ? 0 : p >= 21 && p < 23 ? 1 : 2;
  }
  randomWalkable(x, y, r, types) {
    for (let k = 0; k < 14; k++) {
      const a = Math.random() * 6.283, d = Math.random() * r, px = x + Math.cos(a) * d, py = y + Math.sin(a) * d;
      const t = this.tileAt(px, py);
      if (types ? types.includes(t) : (t === T.SIDEWALK || t === T.PLAZA || t === T.PARKING || t === T.GRASS || t === T.SAND || t === T.PATH || t === T.DIRT || t === T.WOOD || t === T.QUAY)) return { x: px, y: py };
    }
    return null;
  }

  // ---------- A* (windowed: a 512×512-tile window around the start, so it works anywhere on the infinite plane) ----------
  _costT(x, y, opt) {
    const t = this.tl(x, y);
    switch (t) {
      case T.BUILDING: return Infinity;
      case T.WATER: return opt.swim ? 4 : Infinity;
      case T.ROAD: case T.BRIDGE: return this.mt(x, y) & M.XW ? 2 : (opt.road ? 2.2 : 6);
      case T.GRASS: return 1.15;
      default: return 1;
    }
  }
  nearestWalk(tx, ty, opt) {
    for (let r = 0; r <= 4; r++) for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) if (this._costT(tx + i, ty + j, opt) < Infinity) return { x: tx + i, y: ty + j };
    return null;
  }
  walkPx(x, y, opt) { return this._costT(Math.floor(x / TS), Math.floor(y / TS), opt) < Infinity; }
  path(sx, sy, tx, ty, opt = {}) {
    const WN = 512, N = WN * WN;
    if (!this._g) { this._g = new Float32Array(N); this._cf = new Int32Array(N); this._st = new Uint32Array(N); this._cl = new Uint32Array(N); this._stamp = 0; this._hf = []; this._hi = []; }
    const stamp = ++this._stamp, g = this._g, cf = this._cf, st = this._st, cl = this._cl, hf = this._hf, hi = this._hi;
    hf.length = 0; hi.length = 0;
    let stx = Math.floor(sx / TS), sty = Math.floor(sy / TS), enx = Math.floor(tx / TS), eny = Math.floor(ty / TS);
    const ox = stx - 256, oy = sty - 256, inW = (x, y) => x >= ox && y >= oy && x < ox + WN && y < oy + WN, ix = (x, y) => (y - oy) * WN + (x - ox);
    if (inW(enx, eny) && this._costT(enx, eny, opt) === Infinity) { const n = this.nearestWalk(enx, eny, opt); if (!n) return null; enx = n.x; eny = n.y; }
    if (this._costT(stx, sty, opt) === Infinity) { const n = this.nearestWalk(stx, sty, opt); if (!n) return null; stx = n.x; sty = n.y; }
    const e = inW(enx, eny) ? ix(enx, eny) : -1, s0 = ix(stx, sty);
    const push = (f, i) => { let k = hf.length; hf.push(f); hi.push(i); while (k > 0) { const p = (k - 1) >> 1; if (hf[p] <= f) break; hf[k] = hf[p]; hi[k] = hi[p]; k = p; } hf[k] = f; hi[k] = i; };
    const pop = () => {
      const top = hi[0], lf = hf.pop(), li = hi.pop(), n = hf.length;
      if (n > 0) { let k = 0; for (;;) { let c = 2 * k + 1; if (c >= n) break; if (c + 1 < n && hf[c + 1] < hf[c]) c++; if (hf[c] >= lf) break; hf[k] = hf[c]; hi[k] = hi[c]; k = c; } hf[k] = lf; hi[k] = li; }
      return top;
    };
    const H = (x, y) => { const dx = Math.abs(x - enx), dy = Math.abs(y - eny); return Math.max(dx, dy) + 0.41 * Math.min(dx, dy); };
    g[s0] = 0; st[s0] = stamp; cf[s0] = -1; push(H(stx, sty), s0);
    let best = s0, bestH = H(stx, sty), exp = 0; const max = opt.max || 700; let found = false;
    while (hf.length && exp < max) {
      const cur = pop(); if (cl[cur] === stamp) continue; cl[cur] = stamp; exp++;
      if (cur === e) { found = true; break; }
      const cx = ox + (cur % WN), cy = oy + ((cur / WN) | 0), h = H(cx, cy); if (h < bestH) { bestH = h; best = cur; }
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue; const nx = cx + dx, ny = cy + dy; if (!inW(nx, ny)) continue;
        const ni = ix(nx, ny), c = this._costT(nx, ny, opt); if (c === Infinity || cl[ni] === stamp) continue;
        if (dx && dy && (this._costT(nx, cy, opt) === Infinity || this._costT(cx, ny, opt) === Infinity)) continue;
        const ng = g[cur] + c * (dx && dy ? 1.41 : 1);
        if (st[ni] !== stamp || ng < g[ni]) { st[ni] = stamp; g[ni] = ng; cf[ni] = cur; push(ng + H(nx, ny), ni); }
      }
    }
    let n = found ? e : best; const out = [];
    while (n >= 0 && n !== s0) { out.push({ x: (ox + (n % WN)) * TS + TS / 2, y: (oy + ((n / WN) | 0)) * TS + TS / 2 }); n = cf[n]; }
    out.reverse();
    const sm = []; let ax = sx, ay = sy, i = 0;
    while (i < out.length) {
      let j = out.length - 1; while (j > i && !this._segWalk(ax, ay, out[j].x, out[j].y, opt)) j--;
      sm.push(out[j]); ax = out[j].x; ay = out[j].y; i = j + 1;
    }
    return sm;
  }
  _segWalk(x0, y0, x1, y1, opt) {
    const d = Math.hypot(x1 - x0, y1 - y0), n = Math.ceil(d / 10);
    for (let i = 1; i <= n; i++) { const t = i / n, x = x0 + (x1 - x0) * t, y = y0 + (y1 - y0) * t; if (!this.walkPx(x, y, opt) || !this.walkPx(x + 5, y + 5, opt) || !this.walkPx(x - 5, y - 5, opt) || !this.walkPx(x + 5, y - 5, opt) || !this.walkPx(x - 5, y + 5, opt)) return false; if (!opt.road && this.isRoad(x, y) && !(this.metaAt(x, y) & M.XW)) return false; }
    return true;
  }
  /** lane position helpers for traffic: returns centre of road line and lane offsets */
  hash(x, y) { return hash2(x, y, this.seed); }
}
