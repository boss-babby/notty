// ===== util.js — math, RNG, noise, spatial hash =====
export const TAU = Math.PI * 2;
export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const rnd = (a = 1, b) => (b === undefined ? Math.random() * a : a + Math.random() * (b - a));
export const rndi = (a, b) => Math.floor(rnd(a, b + 1));
export const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
export const chance = (p) => Math.random() < p;
export const dist = (ax, ay, bx, by) => Math.hypot(bx - ax, by - ay);
export const smooth = (t) => t * t * (3 - 2 * t);

/** Seeded RNG (mulberry32) — used by the city generator so the world is reproducible */
export function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function angDiff(a, b) {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU; else if (d < -Math.PI) d += TAU;
  return d;
}
export function rotToward(a, b, max) {
  const d = angDiff(a, b);
  return Math.abs(d) <= max ? b : a + Math.sign(d) * max;
}
export function hash2(x, y, s = 0) {
  let h = (x * 374761393 + y * 668265263 + s * 1442695041) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
export function vnoise(x, y, s = 0) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const u = smooth(xf), v = smooth(yf);
  return lerp(lerp(hash2(xi, yi, s), hash2(xi + 1, yi, s), u), lerp(hash2(xi, yi + 1, s), hash2(xi + 1, yi + 1, s), u), v);
}
export function hexToRgb(h) {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
export function shade(hex, f) {
  const [r, g, b] = hexToRgb(hex);
  const c = (v) => clamp(Math.round(f >= 0 ? v + (255 - v) * f : v * (1 + f)), 0, 255);
  return `rgb(${c(r)},${c(g)},${c(b)})`;
}

/** Uniform-grid spatial hash. Objects are stored in the cell of their centre only,
 *  so queries must pass (radius + max object radius). No duplicates, no GC churn. */
export class SpatialHash {
  constructor(cell = 96) { this.c = cell; this.m = new Map(); }
  clear() { for (const [k, a] of this.m) { if (a.length === 0) this.m.delete(k); else a.length = 0; } }
  _k(cx, cy) { return (cx + 33554432) * 67108864 + (cy + 33554432); } // collision-free for |cell| < 2^25
  /** forget every object whose cell lies in the px rectangle (used when a generated block is evicted) */
  dropCells(x0, y0, x1, y1) { const c = this.c; for (let cy = Math.floor(y0 / c); cy < Math.ceil(y1 / c); cy++) for (let cx = Math.floor(x0 / c); cx < Math.ceil(x1 / c); cx++) this.m.delete(this._k(cx, cy)); }
  insert(o, x, y) {
    const k = this._k(Math.floor(x / this.c), Math.floor(y / this.c));
    let a = this.m.get(k);
    if (!a) { a = []; this.m.set(k, a); }
    a.push(o);
  }
  query(x, y, r, out) {
    const c = this.c;
    const x0 = Math.floor((x - r) / c), x1 = Math.floor((x + r) / c), y0 = Math.floor((y - r) / c), y1 = Math.floor((y + r) / c);
    for (let cy = y0; cy <= y1; cy++) for (let cx = x0; cx <= x1; cx++) {
      const a = this.m.get(this._k(cx, cy));
      if (a) for (let i = 0; i < a.length; i++) out.push(a[i]);
    }
    return out;
  }
}
export const fmtMoney = (n) => '$' + Math.round(n).toLocaleString('en-US');
export const fmtTime = (h) => {
  const hh = Math.floor(h) % 24, mm = Math.floor((h % 1) * 60);
  return String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0');
};
