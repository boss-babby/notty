// ===== terra_sites.js — large set-pieces ("plots") and wilderness landmarks for the infinite world =====
// Every function is a pure function of (seed, node, rng) → placed on the node's jittered, terrain-checked position (organic, never on a
// rigid grid): kits are chosen per biome in terra.js (SPECIAL_KITS) and only land on dry, gently sloped ground that the road router
// then connects.  Large kits own a 2×2-block plot (26×26 tiles); small ones are single-block roadside / wilderness landmarks.
import { shade } from './util.js';

export const EXT_KITS = new Set(['airport', 'fortress', 'casino', 'stadium', 'industrial', 'stunt', 'ghost', 'harbor']);
export const KIT_LABEL = { airstrip: 'Airstrip', military: 'Outpost', resort: 'Resort', port: 'Port', quarry: 'Quarry', airport: 'Regional Airport', fortress: 'Fortress', casino: 'Casino Resort', stadium: 'Stadium', industrial: 'Industrial Park', stunt: 'Stunt Park', ghost: 'Ghost Town', harbor: 'Harbor' };

/** plot kits. ctx = { T, TS, th, PAL, NEON, pk }.  Returns { dk, zone? } */
export function plotKitExt(terra, U, n, rng, biome, ctx) {
  const { T, TS, th, PAL, NEON, pk } = ctx, bx0 = n.bx, by0 = n.by, X = bx0 * 16 + 5, Y = by0 * 16 + 5, TW = 26, NAME = n.name.toUpperCase(), own = U.blkT(X, Y);
  const gnd = { desert: T.DESERT, coast: T.SAND, tundra: T.SNOW, alpine: T.GRAVEL }[biome] || T.GRASS, ground = gnd === T.SNOW ? T.GRAVEL : gnd;
  const K = (s) => 'x' + bx0 + '_' + by0 + s;
  const plane = (tx, ty, ang, type) => { const x = tx * TS, y = ty * TS; U.prop(type, x, y, { a: ang, v: Math.floor(rng() * 4) }); const L = type === 'airliner' ? 100 : type === 'jet' ? 30 : 0; for (let d = -L; d <= L && L; d += 24) U.prop('blocker', x + Math.cos(ang) * d, y + Math.sin(ang) * d); };
  const site = (b, key, name, extra = {}) => { if (b && b.door) U.poi(b, key, name, extra); };
  switch (n.kit) {
    case 'airport': { // regional airport — enterable terminal with a working departures desk, tower, hangars, parked airliners
      U.put(X, Y, TW, TW, ground, true); U.put(X, Y + 1, TW, 4, T.RUNWAY, true); U.put(X, Y + 5, TW, 1, T.TARMAC); U.put(X + 2, Y + 6, 22, 6, T.TARMAC); U.put(X + 8, Y + 12, 4, 3, T.TARMAC);
      const term = U.B(X + 6, Y + 14, 12, 5, { kind: 'terminal', hgt: 34, color: '#c3ccd6', roof: '#7a8ca0', interior: 'terminal', name: NAME + ' AIRPORT', neon: '#4fe0ff' });
      const atc = U.B(X + 20, Y + 14, 3, 3, { kind: 'atc', hgt: 84, color: '#d8dde3', roof: '#4fe0ff', interior: 'atc', door: true, windows: false, name: 'TOWER' });
      U.B(X + 1, Y + 15, 4, 4, { kind: 'hangar', hgt: 26, color: '#8a929a', roof: '#a0a8b0', interior: 'hangar', name: 'HANGAR', neon: '#ffe14a' });
      plane(X + 7, Y + 9, 0, 'airliner'); plane(X + 17, Y + 9, Math.PI, 'jet'); plane(X + 22, Y + 9, 0.3, 'jet');
      U.prop('windsock', (X + 25) * TS, (Y + 6) * TS); U.lot(X + 4, Y + 20, 16, 5); U.scatter('lamp', 4, X + 4, Y + 20, 16, 5, rng); U.prop('helipad', (X + 22) * TS, (Y + 21) * TS); U.scatter('barrel', 3, X + 20, Y + 18, 5, 3, rng);
      if (term && term.door) { const x = term.door.x, y = term.door.y + 40; own.poi.push({ key: K('ap'), x, y, name: n.name + ' Regional Airport', cat: 'airport', fast: true }); }
      site(atc, K('atc'), n.name + ' Control Tower', { cat: 'landmark' }); return { dk: 'x_airport' };
    }
    case 'fortress': { // walled military fortress — keep, curtain wall with corner towers, parade yard, gate, barracks, armory
      U.put(X, Y, TW, TW, ground === T.SAND ? T.DIRT : ground, true); U.put(X + 3, Y + 3, 20, 20, T.CONCRETE); U.put(X + 11, Y + 21, 4, 5, T.CONCRETE);
      const r = [(X + 2) * TS, (Y + 2) * TS, (X + 24) * TS, (Y + 24) * TS];
      U.fence(r[0], r[1], r[2], r[1]); U.fence(r[0], r[1], r[0], r[3]); U.fence(r[2], r[1], r[2], r[3]); U.fence(r[0], r[3], r[2], r[3], (x) => x > (X + 11) * TS && x < (X + 15) * TS);
      for (const [tx, ty] of [[X + 1, Y + 1], [X + 23, Y + 1], [X + 1, Y + 23], [X + 23, Y + 23]]) U.B(tx, ty, 2, 2, { kind: 'silo', hgt: 60, color: '#6b6f58', windows: false });
      const keep = U.B(X + 9, Y + 5, 8, 7, { kind: 'civic', hgt: 46, color: '#5f6650', roof: '#4a523c', interior: 'hq', name: NAME + ' KEEP', neon: '#ffb347' });
      U.B(X + 4, Y + 6, 4, 3, { kind: 'warehouse', hgt: 20, color: '#58604a', interior: 'barracks', name: 'BARRACKS', door: true }); U.B(X + 18, Y + 6, 4, 3, { kind: 'warehouse', hgt: 20, color: '#4f5a3f', interior: 'barracks', name: 'GARRISON', door: true });
      U.B(X + 5, Y + 15, 4, 3, { kind: 'warehouse', hgt: 18, color: '#58604a', interior: 'shop_armory', name: 'ARMORY', door: true });
      for (let i = 0; i < 4; i++) U.prop('sandbag', (X + 9 + i * 2) * TS, (Y + 20) * TS); U.prop('tank', (X + 14) * TS, (Y + 16) * TS, { a: -1.2 }); for (const d of [-26, 0, 26]) U.prop('blocker', (X + 14) * TS + d, (Y + 16) * TS);
      U.prop('tank', (X + 19) * TS, (Y + 17) * TS, { a: -2 }); for (const d of [-26, 0, 26]) U.prop('blocker', (X + 19) * TS + d, (Y + 17) * TS); U.prop('helipad', (X + 6) * TS, (Y + 21) * TS);
      site(keep, K('f'), n.name + ' Fortress', { cat: 'outpost' }); return { dk: 'fortbase', zone: r };
    }
    case 'casino': { // casino resort: neon tower, fountain plaza, valet lot, supercars
      U.put(X, Y, TW, TW, T.PLAZA, true); U.put(X, Y + 20, TW, 6, T.PARKING); U.put(X + 10, Y + 14, 6, 5, T.GRASS);
      const c1 = U.B(X + 5, Y + 2, 16, 10, { kind: 'tower', hgt: 82, color: '#5b2f6b', roof: '#ffd24a', interior: 'casino', name: NAME + ' CASINO', neon: '#ffd24a' });
      U.B(X + 1, Y + 3, 3, 8, { kind: 'tower', hgt: 44, color: pk(rng, th.tower), roof: '#cfd8e0', neon: pk(rng, NEON) }); U.B(X + 22, Y + 3, 3, 8, { kind: 'tower', hgt: 44, color: pk(rng, th.tower), roof: '#cfd8e0', neon: pk(rng, NEON) });
      U.prop('fountain', (X + 13) * TS, (Y + 16.5) * TS); for (let i = 0; i < 6; i++) U.propT('lamp', X + 3 + i * 4, Y + 13); U.scatter('palm', 8, X, Y + 12, TW, 8, rng); U.lot(X + 1, Y + 21, 24, 4);
      site(c1, K('k'), NAME + ' Casino Resort', { cat: 'casino' }); return { dk: 'x_casino' };
    }
    case 'stadium': { // stadium complex: bowl, car parks, fan stalls
      U.put(X, Y, TW, TW, T.PARKING, true); U.put(X + 3, Y + 2, 20, 16, T.GRASS); U.put(X, Y + 18, TW, 8, T.PLAZA);
      const st = U.B(X + 3, Y + 2, 20, 16, { kind: 'stadium', hgt: 52, color: '#c8ccd2', roof: '#3f8f46', name: NAME + ' STADIUM', neon: '#ffe14a', windows: false });
      for (let i = 0; i < 4; i++) { const b = U.B(X + 2 + i * 6, Y + 19, 4, 2, { kind: 'shop', hgt: 14, color: pk(rng, th.shop), name: pk(rng, ['FAN SHOP', 'HOT DOGS', 'TICKETS', 'MERCH']), neon: pk(rng, NEON) }); void b; }
      U.lot(X + 1, Y + 22, 24, 3); U.scatter('lamp', 10, X, Y + 18, TW, 8, rng); U.scatter('bench', 4, X, Y + 18, TW, 8, rng);
      if (st) own.poi.push({ key: K('s'), x: (X + 13) * TS, y: (Y + 18.5) * TS, name: NAME + ' Stadium', cat: 'stadium' }); return { dk: 'x_stadium' };
    }
    case 'industrial': { // industrial park: factory halls, stacks, container yards, tank farm, truck depot
      U.put(X, Y, TW, TW, T.PARKING, true); U.put(X + 1, Y + 14, 24, 11, T.CONCRETE);
      const f1 = U.B(X + 1, Y + 1, 11, 6, { kind: 'warehouse', hgt: 28, color: pk(rng, PAL.ind), door: true, interior: 'garage', name: NAME + ' WORKS', neon: '#ff6a3d' }); U.B(X + 14, Y + 1, 11, 6, { kind: 'warehouse', hgt: 26, color: pk(rng, PAL.ind), door: true });
      for (let i = 0; i < 3; i++) U.B(X + 2 + i * 3, Y + 9, 2, 2, { kind: 'silo', hgt: 74 - i * 10, color: '#9aa0a6', windows: false }); for (let j = 0; j < 2; j++) for (let i = 0; i < 4; i++) if (rng() < 0.85) U.B(X + 14 + i * 3, Y + 9 + j * 2, 2, 1, { kind: 'container', hgt: 14, color: pk(rng, PAL.cont), windows: false });
      for (let i = 0; i < 4; i++) U.prop('truck', (X + 3 + i * 5) * TS, (Y + 17) * TS, { a: rng() * 6.28, v: i & 3 }); U.scatter('barrel', 8, X, Y + 20, TW, 5, rng); U.scatter('crate', 5, X, Y + 20, TW, 5, rng); U.fence(X * TS, (Y + 13) * TS, (X + TW) * TS, (Y + 13) * TS, (x) => x > (X + 11) * TS && x < (X + 15) * TS);
      site(f1, K('i'), NAME + ' Industrial Park', { cat: 'industrial' }); return { dk: 'x_industrial' };
    }
    case 'stunt': { // stunt park: dirt bowl, ramp chains, loops of cones, spectator stand
      U.put(X, Y, TW, TW, ground === T.GRASS ? T.DIRT : ground, true); U.put(X + 2, Y + 2, 22, 20, T.DIRT);
      for (let i = 0; i < 7; i++) { const a = (i / 7) * 6.283 + 0.4, rx = 8 + (i % 2) * 2, ry = 7 + (i % 3); U.prop('ramp', (X + 13 + Math.cos(a) * rx) * TS, (Y + 12 + Math.sin(a) * ry) * TS, { a: a + Math.PI / 2 }); }
      U.prop('ramp', (X + 13) * TS, (Y + 6) * TS, { a: 0 }); U.prop('ramp', (X + 13) * TS, (Y + 18) * TS, { a: Math.PI }); for (let i = 0; i < 14; i++) U.prop('cone', (X + 5 + i * 1.3) * TS, (Y + 12) * TS + (i % 2) * 18);
      U.scatter('barrel', 6, X + 2, Y + 2, 22, 20, rng); U.scatter('crate', 4, X + 2, Y + 2, 22, 20, rng);
      const stand = U.B(X + 20, Y + 22, 5, 3, { kind: 'shop', hgt: 16, color: '#b5442d', name: 'STUNT HQ', neon: '#ff8a4a', door: true, interior: 'shop_mart' }); U.lot(X + 2, Y + 22, 14, 3);
      if (stand && stand.door) own.poi.push({ key: K('st'), x: stand.door.x, y: stand.door.y, name: NAME + ' Stunt Park', cat: 'stunt' }); else own.poi.push({ key: K('st'), x: (X + 13) * TS, y: (Y + 13) * TS, name: NAME + ' Stunt Park', cat: 'stunt' });
      return { dk: 'x_stunt' };
    }
    case 'ghost': { // ghost town: derelict main street, doorless shells, wrecks, tumbleweed and sun-bleached signs
      U.put(X, Y, TW, TW, ground === T.SAND ? T.DESERT : ground, true); U.put(X, Y + 11, TW, 4, T.DIRT);
      const dead = [pk(rng, ['#8b7355', '#7a6548', '#6e5a40']), '#6b5d4a', '#80725c'];
      let first = null;
      for (let i = 0; i < 6; i++) { const w = 3 + (i % 3), b = U.B(X + 1 + i * 4, Y + 6, w, 4, { kind: 'house', hgt: 14 + (i % 3) * 4, color: pk(rng, dead), roof: '#4a3f33', windows: false, door: true }); if (!first && b) first = b; }
      for (let i = 0; i < 5; i++) U.B(X + 2 + i * 5, Y + 16, 3 + (i & 1), 4, { kind: 'house', hgt: 12 + (i % 2) * 6, color: pk(rng, dead), roof: '#3f362c', windows: false, door: true });
      U.B(X + 10, Y + 1, 6, 4, { kind: 'warehouse', hgt: 24, color: '#6b5d4a', windows: false }); U.scatter('cactus', 8, X, Y, TW, TW, rng); U.scatter('rock', 6, X, Y, TW, TW, rng); U.scatter('crate', 4, X, Y + 10, TW, 6, rng); U.scatter('barrel', 3, X, Y + 10, TW, 6, rng);
      for (let i = 0; i < 3; i++) U.prop('sign', (X + 3 + i * 8) * TS, (Y + 11.2) * TS);
      own.poi.push({ key: K('g'), x: (X + 13) * TS, y: (Y + 13) * TS, name: 'Ghost Town of ' + n.name, cat: 'ghost' }); void first; return { dk: 'x_ghost' };
    }
    default: { // harbor — fishing / cargo harbor with quay, piers into the water, cranes, boats and a harbour-master's office
      U.put(X, Y, TW, TW, T.SAND); U.put(X, Y + 12, TW, 14, T.WATER, true); U.put(X, Y + 9, TW, 3, T.QUAY); for (const px of [3, 10, 17, 22]) U.put(X + px, Y + 12, 2, 10, T.WOOD, true);
      const hm = U.B(X + 3, Y + 2, 7, 4, { kind: 'shop', hgt: 20, color: '#c9d4dc', roof: '#3f6f9f', interior: 'bar', name: pk(rng, ['HARBOR MASTER', 'THE SEA DOG', 'FISHERMANS REST']), neon: '#4fe0ff' });
      U.B(X + 12, Y + 2, 6, 4, { kind: 'warehouse', hgt: 24, color: pk(rng, PAL.ind), door: true, interior: 'garage', name: 'COLD STORE', neon: '#7fe0d0' }); U.B(X + 20, Y + 1, 2, 2, { kind: 'crane', hgt: 70, color: '#c0392b', windows: false }); U.B(X + 23, Y + 6, 2, 2, { kind: 'crane', hgt: 64, color: '#c0392b', windows: false });
      for (let i = 0; i < 4; i++) if (rng() < 0.8) U.B(X + 2 + i * 3, Y + 7, 2, 1, { kind: 'container', hgt: 14, color: pk(rng, PAL.cont), windows: false });
      for (const [px, py] of [[1, 15], [8, 18], [15, 14], [20, 19], [24, 16]]) U.prop('boat', (X + px) * TS, (Y + py) * TS, { a: Math.PI / 2 + (rng() - 0.5) * 0.4, v: Math.floor(rng() * 4) });
      U.scatter('barrel', 4, X, Y + 6, TW, 3, rng); U.scatter('crate', 4, X, Y + 6, TW, 3, rng); U.scatter('palm', 4, X, Y, TW, 6, rng, (t) => t === T.SAND);
      own.poi.push({ key: K('hb'), x: (X + 7) * TS, y: (Y + 7) * TS, name: n.name + ' Harbor', cat: 'port' }); void hm; return { dk: 'x_harbor' };
    }
  }
}

/** extra single-block landmark kits (wilderness + roadside).  Returns { door, title, gT } or null when the kit is unknown.  Biome → kit lists are in terra_gen.js */
export const POI_EXT = new Set(['truckstop', 'watch', 'oasis', 'hotspring', 'ruins', 'stones', 'orchard', 'pier', 'geyser', 'bunker']);
export const POI_EXT_GROUND = { truckstop: 'PARKING', oasis: 'DESERT', ruins: 'DESERT', orchard: 'FARM', bunker: 'DIRT' };
export function poiExt(kind, terra, U, blk, rng, ctx) {
  const { T, TS, th, PAL, NEON, pk, x0, y0, bx, by } = ctx; let door = null, title = '';
  switch (kind) {
    case 'truckstop': { // truck stop: big lot with parked rigs, fuel island, diner + motel
      U.put(x0, y0, 10, 10, T.PARKING); door = U.B(x0 + 1, y0 + 1, 6, 3, { kind: 'shop', hgt: 18, color: '#d8d0c0', roof: '#a8322a', interior: 'shop_burger', name: pk(rng, ['TRUCKERS REST', 'BIG RIG DINER', 'ROUTE 66 TRUCK STOP', 'LONG HAUL CAFE']), neon: '#ffe14a' });
      U.B(x0 + 7, y0 + 1, 3, 3, { kind: 'shop', hgt: 16, color: '#cfd8dc', interior: 'shop_mart', name: 'FUEL & GO', neon: '#ff6a3d' }); for (const i of [1, 3, 5]) U.propT('pump', x0 + i, y0 + 5);
      for (let i = 0; i < 3; i++) U.prop('truck', (x0 + 2 + i * 3) * TS, (y0 + 8) * TS, { a: Math.PI / 2, v: i & 3 }); blk.park.push({ x: (x0 + 8) * TS, y: (y0 + 6) * TS, a: Math.PI / 2, type: 'truck' }); U.propT('sign', x0 + 9, y0 + 4); title = 'Truck Stop'; break;
    }
    case 'watch': { // fire watchtower
      door = U.B(x0 + 4, y0 + 4, 2, 2, { kind: 'silo', hgt: 110, color: '#7a5230', windows: false }); U.fence((x0 + 2) * TS, (y0 + 2) * TS, (x0 + 8) * TS, (y0 + 2) * TS); U.fence((x0 + 2) * TS, (y0 + 8) * TS, (x0 + 8) * TS, (y0 + 8) * TS); U.scatter('pine', 8, x0, y0, 10, 10, rng); title = 'Fire Watchtower'; door = null; break;
    }
    case 'oasis': { U.put(x0 + 3, y0 + 3, 4, 4, T.WATER, true); U.scatter('palm', 9, x0 + 1, y0 + 1, 8, 8, rng); U.scatter('rock', 3, x0, y0, 10, 10, rng); for (let i = 0; i < 2; i++) U.prop('tent', (x0 + 8 + i) * TS, (y0 + 2 + i * 5) * TS, { a: rng() * 6.28, v: i }); title = 'Desert Oasis'; break; }
    case 'hotspring': { U.put(x0 + 3, y0 + 3, 4, 3, T.WATER, true); U.scatter('rock', 9, x0, y0, 10, 10, rng); U.scatter('pine', 5, x0, y0, 10, 10, rng); door = U.B(x0 + 7, y0 + 6, 3, 3, { kind: 'house', hgt: 12, color: pk(rng, PAL.log), roof: pk(rng, PAL.darkroofs), door: true, interior: 'cabin' }); title = 'Hot Springs'; break; }
    case 'ruins': { U.put(x0, y0, 10, 10, T.DESERT); for (const [sx, sy, w, h] of [[1, 1, 3, 2], [6, 2, 2, 3], [2, 6, 4, 2], [7, 7, 2, 2]]) U.B(x0 + sx, y0 + sy, w, h, { kind: 'house', hgt: 10 + Math.floor(rng() * 8), color: pk(rng, ['#9c8a6a', '#8a7a5c', '#a8977a']), roof: '#5a4a38', windows: false }); U.scatter('rock', 8, x0, y0, 10, 10, rng); U.scatter('cactus', 3, x0, y0, 10, 10, rng); title = 'Ancient Ruins'; break; }
    case 'stones': { for (let i = 0; i < 8; i++) { const a = (i / 8) * 6.283; U.prop('rock', (x0 + 5 + Math.cos(a) * 3.2) * TS, (y0 + 5 + Math.sin(a) * 3.2) * TS); } U.B(x0 + 4, y0 + 4, 2, 2, { kind: 'mountain', hgt: 44, color: '#756c60', roof: '#9a9186', windows: false }); U.scatter('tree', 4, x0, y0, 10, 10, rng); title = 'Standing Stones'; break; }
    case 'orchard': { U.put(x0, y0, 10, 10, T.FARM); for (let j = 0; j < 4; j++) for (let i = 0; i < 5; i++) U.prop('tree', (x0 + 1 + i * 2) * TS + 16, (y0 + 1 + j * 2) * TS + 16); door = U.B(x0 + 7, y0 + 7, 3, 2, { kind: 'barn', hgt: 18, color: pk(rng, PAL.barn), roof: '#6b2a20', door: true, windows: false }); title = 'Orchard'; break; }
    case 'pier': { U.put(x0 + 4, y0, 2, 10, T.WOOD, true); U.put(x0 + 2, y0 + 7, 6, 2, T.WOOD, true); door = U.B(x0 + 1, y0 + 1, 3, 3, { kind: 'shop', hgt: 16, color: '#f2d28b', interior: 'shop_burger', name: pk(rng, ['PIER FISH BAR', 'BAIT & BITE', 'SEASIDE CAFE']), neon: pk(rng, NEON) }); U.prop('boat', (x0 + 3) * TS, (y0 + 9) * TS, { a: 0, v: Math.floor(rng() * 4) }); U.scatter('palm', 3, x0, y0, 10, 10, rng); title = 'Fishing Pier'; break; }
    case 'geyser': { U.put(x0 + 4, y0 + 4, 2, 2, T.WATER, true); U.scatter('rock', 8, x0, y0, 10, 10, rng); U.B(x0, y0, 3, 3, { kind: 'mountain', hgt: 46, color: '#6b6358', roof: shade('#6b6358', 0.2), windows: false }); title = 'Geyser Field'; break; }
    case 'bunker': { U.put(x0, y0, 10, 10, T.DIRT); door = U.B(x0 + 3, y0 + 3, 4, 3, { kind: 'warehouse', hgt: 12, color: '#4f5a3f', door: true, interior: 'barracks', name: 'BUNKER 7', windows: false }); U.fence(x0 * TS, y0 * TS, (x0 + 10) * TS, y0 * TS); U.fence(x0 * TS, (y0 + 10) * TS, (x0 + 10) * TS, (y0 + 10) * TS); U.scatter('sandbag', 5, x0, y0, 10, 10, rng); U.scatter('barrel', 2, x0, y0, 10, 10, rng); title = 'Abandoned Bunker'; break; }
    default: return null;
  }
  void th; void bx; void by; void terra; return { door, title };
}
