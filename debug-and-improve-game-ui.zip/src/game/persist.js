// ===== persist.js — compact save format for the explored map, the discovered-place atlas and world deltas =====
// Storage itself lives in store.js (IndexedDB + localStorage mirror); this module only encodes / decodes the data.
import { bkey, unkeyX, unkeyY } from './keys.js';
import { saveMap, loadMap } from './store.js';

/** explored block keys → run-length rows  [[by, x0, len, x0, len …], …]  (a 1 M-block exploration is a few hundred KB, not tens of MB) */
export function encodeExplored(set) {
  const rows = new Map();
  for (const k of set) { const x = unkeyX(k), y = unkeyY(k); let r = rows.get(y); if (!r) rows.set(y, (r = [])); r.push(x); }
  const out = [];
  for (const [y, xs] of rows) {
    xs.sort((a, b) => a - b); const row = [y]; let s = xs[0], p = xs[0];
    for (let i = 1; i < xs.length; i++) { if (xs[i] === p + 1) { p = xs[i]; continue; } row.push(s, p - s + 1); s = p = xs[i]; }
    row.push(s, p - s + 1); out.push(row);
  }
  return out;
}
export function decodeExplored(rows, set) {
  if (!Array.isArray(rows)) return set;
  for (const row of rows) { const y = row[0]; for (let i = 1; i + 1 < row.length; i += 2) for (let x = row[i], e = row[i] + row[i + 1]; x < e; x++) set.add(bkey(x, y)); }
  return set;
}

/** everything that is "map knowledge": fog-of-war, every named place generated so far (only inside explored blocks) and the destroyed-prop deltas */
export function collectMapData(W) {
  const sites = W.atlas.toJSON().filter((r) => r[5] || W.explored.has(bkey(Math.floor(r[2] / 512), Math.floor(r[3] / 512))));
  return { v: 3, t: Date.now(), seed: W.seed, ex: encodeExplored(W.explored), atlas: sites, dl: [...W.deltas] };
}
export function applyMapData(W, d) {
  if (!d || d.seed !== W.seed) return false;
  decodeExplored(d.ex, W.explored); W.reindexExplored();
  W.atlas.load(d.atlas); for (const k of d.dl || []) W.deltas.add(k);
  return true;
}

let lastSave = 0;
/** Persist the map when something changed.  Throttled (≥ 12 s) unless `force`.  Returns the data object it stored (or null if nothing new). */
export function saveMapData(W, force) {
  const rev = (W.exploredRev || 0) + '|' + W.atlas.rev + '|' + W.deltas.size + '|' + W.explored.size;
  if (W._mapRev === rev) return W._mapObj || null; // nothing new since the last save → skip the encode
  const now = Date.now(); if (!force && now - lastSave < 12000) return null;
  const d = collectMapData(W); lastSave = now; W._mapRev = rev; W._mapObj = d;
  saveMap(d).then((ok) => { if (!ok) W._mapRev = null; }).catch(() => { W._mapRev = null; });
  return d;
}
export const loadMapData = loadMap;
