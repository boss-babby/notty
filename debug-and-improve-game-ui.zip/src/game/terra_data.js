// ===== terra_data.js — identity tables for the INFINITE world ("Terra") =====
// The authored regions each have an identity (palette, building grammar, traffic, street names, density).
// Terra gives every procedural settlement the same kind of identity by choosing one of these THEMES from the local biome,
// so that a desert town feels like Saguaro Springs, a coastal one like Sol Costa, a metropolis like Aurelia, etc.
import { TRAFFIC_BY, DISTRICT_NAMES } from './data.js';

export const CLS = ['village', 'town', 'city', 'metro'];
export const CLS_LABEL = ['Village', 'Town', 'City', 'Metropolis'];

const PAL = {
  pastel: ['#e8a6b8', '#9fd8d0', '#f2d28b', '#a8c5e8', '#d8b4e8', '#f5b895'],
  glass: ['#3a5a7a', '#2f6b7a', '#4a5a8a', '#5a6a7a', '#2c4a6a', '#6a7a8a', '#4b6a8a'],
  west: ['#b98a5a', '#c9a26a', '#a7774a', '#d3b27a', '#c08a6a'],
  log: ['#7a5230', '#8a6038', '#6a4528', '#935f38'],
  swamp: ['#6a7a5a', '#8a7a5a', '#5a6a4a', '#7a6a50'],
  house: ['#c9b79c', '#a7b8c9', '#c9a7a7', '#b5c9a7', '#d9d0b0'],
  barn: ['#9b3a2a', '#8a3326', '#a8452f'],
  snow: ['#c9d3dc', '#b8c4d0', '#d8dde2', '#a9b6c4'],
  roofs: ['#7a4b3a', '#4a5a6a', '#5a3f3a', '#3f4a3a'],
  redroofs: ['#c26a4a', '#a8573a', '#b9694a', '#8a4a30'],
  darkroofs: ['#3a3f46', '#2f343b', '#46403a'],
  warm: ['#c9b79c', '#a7b8c9', '#c9a7a7', '#b5c9a7', '#d9d0b0', '#b98a5a', '#9fd8d0'],
  ind: ['#6b6f73', '#7a6f5c', '#5f6b73', '#70655a'],
  cont: ['#b5442d', '#2d6fb5', '#d49b2a', '#3a8a5a', '#7a3ab5', '#c2c2c2'],
};
export const NEON = ['#ff4fd8', '#4fe0ff', '#ffe14a', '#7cff4f', '#ff6a3d', '#b36bff'];
export { PAL };

const SHOP = {
  bar: ['SALTY DOG', 'THE LANTERN', 'LAST STOP', 'IRON HORSE', 'RED DOOR', 'THE ANCHOR', 'NIGHT OWL', 'LAST CALL'],
  burger: ['SUNNY DINER', 'ROUTE DINER', 'GRILL & CHILL', 'BURGER BARN', 'LUCKY NOODLE', 'TACO LOCO', 'PIE & COFFEE'],
  mart: ['QUIK-E', 'GENERAL STORE', 'CORNER MARKET', '24/7 MINI', 'PRONTO MART', 'QUICKSTOP'],
  clothes: ['THREADS & CO', 'MAIN ST WEAR', 'URBAN CUT', 'STITCH & CO', 'BOOT BARN'],
};

// Every theme = one of the "identities" the authored world already has.
export const THEMES = {
  prairie: {
    label: 'Prairie', ground: 'GRASS', tree: 'tree', house: PAL.house, roof: PAL.roofs, shop: PAL.warm, tower: PAL.glass, plaza: 'PLAZA',
    names: [['Ash', 'Bram', 'Cor', 'Dun', 'El', 'Fen', 'Gar', 'Hol', 'Iron', 'Jun', 'Kes', 'Lor', 'Mar', 'Nor', 'Oak', 'Red', 'Sil', 'Tor', 'Wyn', 'Gull', 'Stone', 'Clover'], ['ton', 'ford', 'field', 'stead', 'dale', 'ridge', 'view', 'wick', 'mere', 'bury', 'crest', 'gate']],
    streets: ['Harvest', 'County Rd', 'Orchard', 'Furrow', 'Meadow', 'Corn Belt', 'Mill', 'Silo', 'Barley', 'Main St', 'Elm', 'Maple'],
    traffic: ['pickup', 'pickup', 'tractor', 'truck', 'van', 'offroad', 'sedan'], civic: ['SHERIFF', 'COUNTY CLINIC'], shopNames: SHOP,
  },
  west: {
    label: 'Desert', ground: 'DESERT', tree: 'cactus', house: PAL.west, roof: PAL.redroofs, shop: PAL.west, tower: PAL.west, plaza: 'PATH',
    names: [['San', 'Santa', 'Villa', 'El', 'Dos', 'Rio', 'Mesa', 'Cruz', 'Agua', 'Nuevo', 'Los', 'Paso'], ['Verde', 'Blanca', 'Rojo', 'Piedra', 'Cobre', 'Arroyo', 'Seco', 'Hondo', 'Cielo', 'Springs', 'Wells', 'Gulch']],
    streets: ['Route 18', 'Mesquite', 'Cactus', 'Adobe', 'Tumbleweed', 'Sundown', 'Copper', 'Dune', 'Cholla', 'Mission', 'Wagon', 'Arroyo'],
    traffic: ['pickup', 'pickup', 'offroad', 'muscle', 'van', 'truck', 'sedan', 'moto'], civic: ['SHERIFF', 'DESERT CLINIC'],
    shopNames: { ...SHOP, bar: ['THE SALOON', 'BLUE AGAVE', 'DUSTY BOOT', 'RATTLER BAR', 'EL TORO'], burger: ['DUSTY DINER', 'TACO LOCO', 'CHILI QUEEN', 'ROUTE DINER'] },
  },
  timber: {
    label: 'Timber', ground: 'GRASS', tree: 'pine', house: PAL.log, roof: PAL.darkroofs, shop: PAL.log, tower: PAL.glass, plaza: 'PATH',
    names: [['Pine', 'Cedar', 'Elk', 'Bear', 'Timber', 'Raven', 'Spruce', 'Fox', 'Lynx', 'Moose', 'Aspen', 'Birch'], ['Hollow', 'Ridge', 'Falls', 'Lake', 'Camp', 'Crossing', 'Pass', 'Landing', 'Creek', 'Bluff']],
    streets: ['Ridge Rd', 'Timber', 'Lakeview', 'Aspen', 'Cedar', 'Summit', 'Trailhead', 'Spruce', 'Birch', 'Antler'],
    traffic: ['offroad', 'pickup', 'suv', 'pickup', 'van', 'tractor'], civic: ['RANGER STATION', 'FOREST CLINIC'],
    shopNames: { ...SHOP, bar: ['THE ANTLER', 'BEAR CLAW TAVERN', 'LOGGERS REST'], mart: ['TRAILHEAD MART', 'BAIT & TACKLE', 'GENERAL STORE'], burger: ['PANCAKE HOUSE', 'LODGE DINER', 'CAMPFIRE GRILL'] },
  },
  alpine: {
    label: 'Alpine', ground: 'GRASS', tree: 'pine', house: PAL.snow, roof: PAL.darkroofs, shop: PAL.snow, tower: PAL.glass, plaza: 'PLAZA',
    names: [['Sil', 'Fjell', 'Hav', 'Norr', 'Sno', 'Vik', 'Berg', 'Troll', 'Aska', 'Hel', 'Frost', 'Glac'], ['dal', 'berg', 'vik', 'heim', 'stad', 'fjord', 'haven', 'spitz']],
    streets: ['Summit', 'Glacier', 'Avalanche', 'Edelweiss', 'Piste', 'Frost', 'Alpen', 'Chalet', 'Lift', 'Snowline'],
    traffic: ['offroad', 'suv', 'suv', 'pickup', 'van', 'hummer'], civic: ['MOUNTAIN RESCUE', 'ALPINE CLINIC'],
    shopNames: { ...SHOP, bar: ['APRES-SKI', 'THE YETI', 'FIRESIDE'], burger: ['FONDUE HAUS', 'COCOA & CO', 'CHALET CAFE'], clothes: ['SKI & SHRED', 'ALPINE GEAR', 'PARKA SHOP'] },
  },
  bayou: {
    label: 'Bayou', ground: 'GRASS', tree: 'stump', house: PAL.swamp, roof: PAL.roofs, shop: PAL.swamp, tower: PAL.swamp, plaza: 'WOOD',
    names: [['Bayou', 'Cypress', 'Gator', 'Heron', 'Pelican', 'Marais', 'Delta', 'Voodoo', 'Mangrove', 'Egret'], [' Landing', ' Bend', ' Point', 'ville', 'aux', ' Parish', ' Crossing', ' Mire']],
    streets: ['Cypress', 'Gator Alley', 'Mangrove', 'Heron', 'Delta', 'Voodoo', 'Bayou Rd', 'Moss', 'Egret'],
    traffic: ['pickup', 'offroad', 'muscle', 'sedan', 'van', 'cabrio', 'golf'], civic: ['PARISH SHERIFF', 'BAYOU CLINIC'],
    shopNames: { ...SHOP, bar: ['THE GATOR', 'VOODOO LOUNGE', 'LAST RESORT'], burger: ['CAJUN KITCHEN', 'CRAWFISH SHACK', 'BAYOU BITES'], mart: ['BAIT & TACKLE', 'GENERAL STORE'] },
  },
  resort: {
    label: 'Coastal', ground: 'SAND', tree: 'palm', house: PAL.pastel, roof: PAL.redroofs, shop: PAL.pastel, tower: PAL.pastel, plaza: 'PLAZA',
    names: [['Palm', 'Coral', 'Sun', 'Azure', 'Marlin', 'Flamingo', 'Lido', 'Pearl', 'Tropic', 'Mango', 'Opal', 'Pelican'], [' Beach', ' Cove', ' Key', ' Shores', ' Bay', ' Harbor', ' Strand', ' Point']],
    streets: ['Ocean Prom', 'Flamingo', 'Palmetto', 'Coral', 'Biscayne', 'Neon Mile', 'Sunset Strip', 'Marlin', 'Azul', 'Costa', 'Tropic', 'Lido'],
    traffic: ['cabrio', 'cabrio', 'sports', 'supercar', 'limo', 'suv', 'moto', 'taxi', 'sedan', 'golf'], civic: ['COASTAL PD', 'COASTAL MEDICAL'],
    shopNames: { ...SHOP, bar: ['TIKI HUT', 'SALTY DOG', 'THE LIDO', 'BEACH CLUB'], burger: ['BEACH BITES', 'SUNNY DINER', 'SURF & TURF'], clothes: ['SOL WEAR', 'SWIMSUIT CO', 'RESORT WEAR'] },
  },
  metro: {
    label: 'Metro', ground: 'GRASS', tree: 'tree', house: PAL.warm, roof: PAL.darkroofs, shop: PAL.glass, tower: PAL.glass, plaza: 'PLAZA',
    names: [['New ', 'Port ', 'Grand ', 'Fort ', 'Mount ', 'Lake ', 'Saint ', 'North '], ['Aurora', 'Meridian', 'Capital', 'Liberty', 'Hudson', 'Atlas', 'Madison', 'Orion', 'Vega', 'Union', 'Gotham', 'Halcyon']],
    streets: ['Federal', 'Liberty', 'Broadway', 'Wall', 'Union', 'Capitol', 'Madison', 'Gotham', 'Lakeshore', 'Atlas', 'Grand Blvd', 'Market St'],
    traffic: ['sedan', 'taxi', 'taxi', 'taxi', 'suv', 'limo', 'bus', 'van', 'compact', 'sports', 'moto'], civic: ['METRO PD', 'METRO GENERAL'], shopNames: SHOP,
  },
};

// biome → settlement theme
export const THEME_OF_BIOME = { desert: 'west', plains: 'prairie', farm: 'prairie', forest: 'timber', taiga: 'timber', tundra: 'alpine', alpine: 'alpine', marsh: 'bayou', coast: 'resort' };
// biome keys that exist for the wilderness (district = 'x_wild_<biome>')
export const BIOMES = { tundra: 'Frozen Tundra', taiga: 'Taiga', plains: 'Open Plains', farm: 'Farmland', desert: 'Desert Badlands', forest: 'Woodland', marsh: 'Marshland', alpine: 'Highlands', coast: 'Coastline', lake: 'Lakeland', ocean: 'Open Water' };
const BIOME_THEME = { tundra: 'alpine', taiga: 'timber', plains: 'prairie', farm: 'prairie', desert: 'west', forest: 'timber', marsh: 'bayou', alpine: 'alpine', coast: 'resort', lake: 'timber', ocean: 'resort' };

// ===================================================================== CULTURES (cultural provinces)
// A province (≈13×13 blocks, Voronoi) belongs to one culture. The culture decides — independent of biome — how its places are NAMED
// (syllable grammar), how streets & highways are labelled, which building palette its houses use, which shop names appear and which
// vehicles fill its roads. Biome still decides the *theme* (ground, trees, civic buildings) so every combination is distinct.
const P2 = { stucco: ['#e9d3b0', '#f0c9a0', '#d9a679', '#f2e2c4', '#c98f6a'], timber: ['#b9936a', '#cfae84', '#a07850', '#d8c0a0', '#8f6b48'], slate: ['#8e9aa8', '#a9b4c0', '#7c8896', '#c0c8d0', '#6c7886'], brick: ['#a8553b', '#b9684a', '#8f4631', '#c27a58', '#9a5a44'], white: ['#f2efe8', '#e3ded2', '#d6d0c2', '#f8f6f0', '#cfc9bb'], ochre: ['#d6a64c', '#c98d38', '#e0b866', '#b87a2e', '#d9a05a'], teal: ['#5fa8a0', '#7cbfb2', '#4a8f8a', '#9ad0c4', '#6bb0b8'], rose: ['#e2a0a8', '#d98a98', '#efc0c4', '#c97888', '#f0b4b0'], dark: ['#4a4f58', '#5a5f68', '#3c4048', '#686d76', '#52565e'], cream: ['#efe3c0', '#e5d6a8', '#f4ecd2', '#d8c890', '#ead8a4'] };
const R2 = { terra: ['#b9503a', '#a8452f', '#c4684a', '#8f3a28'], slate: ['#4a5560', '#3f4a54', '#59646e', '#333c46'], green: ['#3f6a4a', '#355a40', '#4a7a54'], blue: ['#3a5a8a', '#46699a', '#2f4a74'], dark: ['#33363c', '#2a2d33', '#3d4046'], red: ['#a8322a', '#c0402f', '#8f2a22'] };
export const CULTURES = [
  { id: 'valdric', label: 'Valdric', pre: ['Vel', 'Hor', 'Brun', 'Eis', 'Kald', 'Stor', 'Gren', 'Wolf', 'Fro', 'Dun', 'Ost', 'Hag'], mid: ['en', 'ar', 'ir', 'ol', ''], suf: ['heim', 'burg', 'dorf', 'stein', 'wald', 'berg', 'fjord', 'haven'], prov: ['mark', 'land', 'gau', 'wald'],
    street: (n) => (/ (St|Rd)$/.test(n) ? n : n + ' Straße'), hwy: 'A', house: P2.timber, roof: R2.slate, shop: P2.slate, traffic: ['sedan', 'van', 'suv', 'sports', 'compact'],
    shops: { bar: ['ZUM ADLER', 'BIERHAUS', 'DER KELLER', 'STUBE 9'], burger: ['BRATWURST HAUS', 'KAFFEE & KUCHEN', 'IMBISS ECK'], mart: ['KAUFHAUS', 'SPAR MARKT', 'EDEKA ECK'], clothes: ['MODEHAUS', 'LODEN & CO'] }, districts: ['Altstadt', 'Neustadt', 'Hafenviertel', 'Bergring', 'Marktplatz'] },
  { id: 'marisol', label: 'Marisol', pre: ['Sol', 'Vil', 'Mar', 'Cor', 'Bel', 'Alt', 'Rio', 'Mont', 'Sera', 'Lun', 'Pal', 'Ver'], mid: ['a', 'e', 'o', 'ar', ''], suf: ['ada', 'ona', 'illa', 'eda', 'ero', 'ales', 'anza', 'ejo'], prov: ['Sierra', 'Costa', 'Vega', 'Meseta'],
    street: (n) => 'Calle ' + n.replace(/ (St|Rd)$/, ''), hwy: 'AP-', house: P2.stucco, roof: R2.terra, shop: P2.ochre, traffic: ['compact', 'sedan', 'moto', 'pickup', 'cabrio', 'van'],
    shops: { bar: ['LA BODEGA', 'EL TORO', 'CASA LUNA', 'TAPAS Y VINO'], burger: ['LA COCINA', 'CHURROS Y CAFE', 'TACOS EL SOL'], mart: ['SUPERMERCADO', 'TIENDA MARISOL'], clothes: ['MODA BELLA', 'ZAPATERIA'] }, districts: ['Casco Viejo', 'La Marina', 'Barrio Alto', 'Mercado', 'El Ensanche'] },
  { id: 'orlovic', label: 'Orlovic', pre: ['Ost', 'Bel', 'Chor', 'Dra', 'Mir', 'Vys', 'Zlat', 'Kras', 'Tver', 'Nov', 'Pol', 'Sib'], mid: ['o', 'a', 'av', 'en', ''], suf: ['grad', 'ov', 'sk', 'ice', 'ava', 'pol', 'gorod', 'ino'], prov: ['Oblast', 'Krai', 'Steppe', 'Voivod'],
    street: (n) => n.replace(/ (St|Rd)$/, '') + ' Prospekt', hwy: 'M', house: P2.dark.concat(P2.cream), roof: R2.green, shop: P2.cream, traffic: ['sedan', 'truck', 'van', 'bus', 'pickup', 'compact'],
    shops: { bar: ['KOROVA BAR', 'VODKA CLUB', 'TAVERNA 24'], burger: ['STOLOVAYA', 'BLINI HOUSE', 'PELMENI CAFE'], mart: ['PRODUKTY', 'UNIVERMAG', 'MAGAZIN 24'], clothes: ['ODEZHDA', 'FUR & FELT'] }, districts: ['Staryi Gorod', 'Zavod', 'Novyi Rayon', 'Vokzal', 'Tsentr'] },
  { id: 'anglian', label: 'Anglian', pre: ['Ash', 'Black', 'Cold', 'Wick', 'Ox', 'Thorn', 'Great', 'Brigg', 'Hart', 'Stan', 'Kings', 'Over'], mid: ['', '', 'ing', 'er'], suf: ['ford', 'ton', 'bury', 'ham', 'wick', 'mouth', 'field', 'by', 'chester', 'worth'], prov: ['shire', 'Downs', 'Weald', 'Fens'],
    street: (n) => n.replace(/ (St|Rd)$/, '') + (n.length % 3 === 0 ? ' Lane' : n.length % 3 === 1 ? ' Road' : ' Street'), hwy: 'M', house: P2.brick, roof: R2.slate, shop: P2.brick, traffic: ['sedan', 'compact', 'van', 'taxi', 'suv', 'bus'],
    shops: { bar: ['THE ROYAL OAK', 'THE RED LION', 'THE CROWN', 'THE PLOUGH'], burger: ['FISH & CHIPS', 'TEA ROOMS', 'THE GREASY SPOON'], mart: ['CORNER SHOP', 'THE GROCER', 'COSTCUTTER'], clothes: ['TWEED & CO', 'THE HABERDASHER'] }, districts: ['Old Town', 'The Green', 'Riverside', 'Market Square', 'The Docks'] },
  { id: 'gallic', label: 'Aurelian', pre: ['Beau', 'Mont', 'Saint-', 'Cha', 'Roux', 'Val', 'Ver', 'Lac', 'Clair', 'Fon', 'Pont', 'Mar'], mid: ['re', 'ne', 'ma', 'ti', ''], suf: ['ville', 'mont', 'ac', 'eux', 'fort', 'court', 'mer', 'ay'], prov: ['Marches', 'Vallée', 'Terres', 'Côte'],
    street: (n) => 'Rue ' + n.replace(/ (St|Rd)$/, ''), hwy: 'N', house: P2.white.concat(P2.cream), roof: R2.blue, shop: P2.rose, traffic: ['compact', 'sedan', 'cabrio', 'van', 'moto', 'taxi'],
    shops: { bar: ['LE BISTROT', 'CAFE DE PARIS', 'LA BRASSERIE'], burger: ['BOULANGERIE', 'CREPERIE', 'PATISSERIE LUNE'], mart: ['EPICERIE', 'MARCHE FRAIS'], clothes: ['BOUTIQUE CHIC', 'COUTURE MARIE'] }, districts: ['Vieille Ville', 'Quartier Latin', 'Les Halles', 'Port', 'Boulevard'] },
  { id: 'kairo', label: 'Qasari', pre: ['Al-', 'Qas', 'Ras', 'Tal', 'Nur', 'Dar', 'Zah', 'Bir', 'Wad', 'Sah', 'Kha', 'Amr'], mid: ['a', 'i', 'ar', 'ah'], suf: ['abad', 'ra', 'ir', 'shan', 'ah', 'ur', 'med', 'iya'], prov: ['Emirate', 'Wadi', 'Sands', 'Sahel'],
    street: (n) => 'Shari ' + n.replace(/ (St|Rd)$/, ''), hwy: 'Route', house: P2.ochre.concat(P2.stucco), roof: R2.terra, shop: P2.ochre, traffic: ['pickup', 'offroad', 'sedan', 'truck', 'suv', 'limo'],
    shops: { bar: ['SHISHA LOUNGE', 'OASIS CAFE', 'MAJLIS'], burger: ['KEBAB HOUSE', 'FALAFEL KING', 'SOUQ KITCHEN'], mart: ['SOUQ MART', 'BAZAAR', 'DATES & SPICE'], clothes: ['SOUQ TEXTILES', 'CARPET HOUSE'] }, districts: ['Medina', 'Souq', 'New Quarter', 'Citadel Hill', 'Oasis Gate'] },
  { id: 'hanori', label: 'Hanori', pre: ['Aki', 'Shi', 'Yama', 'Kawa', 'Hoshi', 'Taka', 'Mina', 'Sora', 'Nagi', 'Haru', 'Kita', 'Oto'], mid: ['ma', 'ki', 'no', 'ta', ''], suf: ['hama', 'saki', 'mura', 'shima', 'kawa', 'zawa', 'dai', 'machi'], prov: ['Prefecture', 'Isles', 'Highlands', 'Coast'],
    street: (n) => n.replace(/ (St|Rd)$/, '') + ' Dori', hwy: 'E', house: P2.white.concat(P2.slate), roof: R2.dark, shop: P2.teal, traffic: ['compact', 'compact', 'taxi', 'van', 'moto', 'sports', 'bus'],
    shops: { bar: ['IZAKAYA KOI', 'SAKE HOUSE', 'KARAOKE STAR'], burger: ['RAMEN-YA', 'SUSHI GO', 'MOCHI CAFE', 'UDON BAR'], mart: ['KONBINI 24', 'MIRAI MART'], clothes: ['HARAJUKU STYLE', 'KIMONO ATELIER'] }, districts: ['Old Quarter', 'Neon Ward', 'Harbor Ward', 'Station Square', 'Garden Ward'] },
  { id: 'moana', label: 'Moana', pre: ['Ka', 'Wai', 'Ho', 'Mau', 'Lani', 'Ko', 'Pua', 'Na', 'Hale', 'Ke'], mid: ['la', 'hu', 'ko', 'pa', 'lo'], suf: ['kai', 'lua', 'nui', 'hana', 'mea', 'iki', 'moku', 'wai'], prov: ['Atoll', 'Archipelago', 'Lagoon', 'Reef'],
    street: (n) => n.replace(/ (St|Rd)$/, '') + ' Kaha', hwy: 'Kam Hwy', house: P2.teal.concat(P2.rose), roof: R2.red, shop: P2.rose, traffic: ['golf', 'cabrio', 'pickup', 'moto', 'suv', 'compact'],
    shops: { bar: ['TIKI TORCH', 'KAI BAR', 'LUAU LOUNGE'], burger: ['POKE SHACK', 'SHAVE ICE', 'KONA KITCHEN'], mart: ['ABC STORE', 'ISLAND MART'], clothes: ['ALOHA WEAR', 'SURF SHACK'] }, districts: ['Beachfront', 'The Lagoon', 'Harbor Row', 'Hillside', 'Town Centre'] },
  { id: 'italic', label: 'Tessaro', pre: ['Bor', 'Val', 'Monte', 'Cas', 'Pia', 'Sant', 'Pon', 'Ter', 'Fiu', 'Sas'], mid: ['i', 'a', 'e', 'o'], suf: ['ello', 'ano', 'ata', 'ino', 'ona', 'etto', 'ara', 'ese'], prov: ['Campagna', 'Riviera', 'Colli', 'Lombardia'],
    street: (n) => 'Via ' + n.replace(/ (St|Rd)$/, ''), hwy: 'SS', house: P2.stucco.concat(P2.rose), roof: R2.terra, shop: P2.ochre, traffic: ['compact', 'sports', 'moto', 'sedan', 'cabrio', 'van', 'supercar'],
    shops: { bar: ['OSTERIA', 'ENOTECA', 'BAR CENTRALE'], burger: ['TRATTORIA', 'PIZZERIA DA LUIGI', 'GELATERIA'], mart: ['ALIMENTARI', 'SUPERMERCATO'], clothes: ['SARTORIA', 'MODA ITALIA'] }, districts: ['Centro Storico', 'Il Porto', 'Borgo', 'Piazza Grande', 'Collina'] },
];
const cap = (w) => w.replace(/(^|[ -])([a-zß])/g, (m, a, b) => a + b.toUpperCase());
/** syllable grammar: prefix + optional middle + suffix  (+ occasionally a two-word form for the cultures that use one) */
export function cultureName(c, r) {
  const a = c.pre[Math.floor(r() * c.pre.length)], m = c.mid[Math.floor(r() * c.mid.length)], b = c.suf[Math.floor(r() * c.suf.length)];
  let n = a + m + b; if (/-$/.test(a)) n = a + (m + b).replace(/^./, (x) => x.toUpperCase());
  return cap(n.replace(/([aeiou])\1\1/g, '$1$1').replace(/(.)\1\1/g, '$1$1'));
}
const SF = new Map();
/** the themed street list re-labelled in a culture's street grammar (memoised) */
export function streetsFor(theme, ci) { const k = theme + ci; let a = SF.get(k); if (!a) { const C = CULTURES[ci]; a = THEMES[theme].streets.map((n) => C.street(n)); SF.set(k, a); } return a; }
export function districtName(ci, r, base) { const C = CULTURES[ci]; return (r() < 0.5 ? base.split(' ')[0] + ' ' : '') + C.districts[Math.floor(r() * C.districts.length)]; }
/** a theme with the culture's palette / shop names / roofs mixed in (memoised) */
const TC = new Map();
export function cultureTheme(theme, ci) {
  const k = theme + ci; let t = TC.get(k); if (t) return t; const th = THEMES[theme], C = CULTURES[ci], mix = (a, b) => (b ? a.concat(b, b) : a);
  const sn = {}; for (const kind of Object.keys(th.shopNames)) sn[kind] = (C.shops[kind] || []).concat(th.shopNames[kind].slice(0, 3));
  t = { ...th, house: mix(th.house, C.house), roof: mix(th.roof, C.roof), shop: mix(th.shop, C.shop), shopNames: sn, culture: C };
  if (theme === 'metro' || theme === 'resort') t.tower = th.tower; TC.set(k, t); return t;
}

// ----- register the dynamic districts into the shared tables the engine already reads -----
const CLS_DENS = [0.34, 0.55, 0.85, 1.1], CLS_CROWD = [0.2, 0.35, 0.6, 0.9];
export const XDENS = {}, XCROWD = {};
for (const th of Object.keys(THEMES)) for (let c = 0; c < 4; c++) {
  const k = `x_${th}_${CLS[c]}`; XDENS[k] = CLS_DENS[c]; XCROWD[k] = CLS_CROWD[c]; TRAFFIC_BY[k] = THEMES[th].traffic; DISTRICT_NAMES[k] = `${THEMES[th].label} ${CLS_LABEL[c]}`;
  CULTURES.forEach((C, ci) => { const kc = k + '_' + ci; XDENS[kc] = CLS_DENS[c]; XCROWD[kc] = CLS_CROWD[c]; TRAFFIC_BY[kc] = THEMES[th].traffic.concat(C.traffic, C.traffic); DISTRICT_NAMES[kc] = `${C.label} ${CLS_LABEL[c]}`; });
}
for (const b of Object.keys(BIOMES)) { const k = 'x_wild_' + b; XDENS[k] = b === 'ocean' ? 0 : b === 'lake' ? 0.02 : 0.15; XCROWD[k] = 0.04; TRAFFIC_BY[k] = THEMES[BIOME_THEME[b]].traffic; DISTRICT_NAMES[k] = BIOMES[b]; }
for (const [k, n, d] of [['x_airstrip', 'Private Airstrip', 0.14], ['x_resort', 'Grand Resort', 0.7], ['x_port', 'Industrial Port', 0.3], ['x_quarry', 'Open-Cast Quarry', 0.08], ['x_airport', 'Regional Airport', 0.3], ['x_casino', 'Casino Resort', 0.8], ['x_stadium', 'Stadium Complex', 0.6], ['x_industrial', 'Industrial Park', 0.22], ['x_stunt', 'Stunt Park', 0.12], ['x_ghost', 'Ghost Town', 0.03], ['x_harbor', 'Fishing Harbor', 0.4]]) { XDENS[k] = d; XCROWD[k] = 0.1; DISTRICT_NAMES[k] = n; }
TRAFFIC_BY.x_airport = ['sedan', 'taxi', 'van', 'bus', 'suv', 'limo']; TRAFFIC_BY.x_casino = ['limo', 'sports', 'supercar', 'taxi', 'sedan']; TRAFFIC_BY.x_stadium = ['sedan', 'van', 'bus', 'taxi', 'suv']; TRAFFIC_BY.x_industrial = ['truck', 'truck', 'van', 'pickup']; TRAFFIC_BY.x_stunt = ['muscle', 'sports', 'offroad', 'moto']; TRAFFIC_BY.x_ghost = ['pickup']; TRAFFIC_BY.x_harbor = ['pickup', 'truck', 'van', 'golf'];
TRAFFIC_BY.x_airstrip = ['pickup', 'truck', 'van', 'offroad']; TRAFFIC_BY.x_port = ['truck', 'truck', 'van', 'pickup', 'sedan']; TRAFFIC_BY.x_quarry = ['truck', 'offroad', 'pickup'];
export const xCrowd = (d) => XCROWD[d];

export const nameFor = (theme, rng) => { const [A, B] = THEMES[theme].names; return A[Math.floor(rng() * A.length)] + (theme === 'west' ? ' ' : '') + B[Math.floor(rng() * B.length)]; };
export const PROVINCE_ADJ = ['Amber', 'Ash', 'Cobalt', 'Hollow', 'Iron', 'Jade', 'Lone', 'Misty', 'Pale', 'Quiet', 'Raven', 'Scarlet', 'Silent', 'Tawny', 'Velvet', 'Wild', 'Golden', 'Broken', 'Crimson', 'Ivory'];
export const PROVINCE_NOUN = {
  tundra: ['Tundra', 'Wastes', 'Barrens'], taiga: ['Pines', 'Timberland', 'Hollow'], plains: ['Prairie', 'Downs', 'Plains'], farm: ['Fields', 'Valley', 'Acres'],
  desert: ['Badlands', 'Flats', 'Dunes', 'Mesa'], forest: ['Woods', 'Forest', 'Glen'], marsh: ['Fens', 'Mire', 'Delta', 'Bayou'], alpine: ['Peaks', 'Highlands', 'Range', 'Crown'],
  coast: ['Coast', 'Shore', 'Strand'], lake: ['Lakes', 'Reach', 'Waters'], ocean: ['Sea', 'Deep', 'Channel'],
};
