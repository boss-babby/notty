// ===== zombie.js — v8 ZOMBIE OUTBREAK mode: "DEAD TIDE" campaign + endless survival =====
// Everyone is food. Zombies hunt the nearest living thing (civilians, police, soldiers, you). Police and soldiers shoot the dead, civilians run for cops / doors,
// the bitten turn after a few seconds, noise pulls hordes, the sky is sick-green, the power grid fails and the world burns.
import { T } from './world.js';
import { spawnActor, spawnVehicle, stepActor } from './actors.js';
import { damageActor, damageVehicle, ZM, explode } from './combat.js';
import { civ, combat as aiCombat, routine, goTo, followPath, sepVec, allyFollow } from './ai.js';
import { P } from './fx.js';
import { clamp, rnd, pick, chance, rotToward, TAU } from './util.js';

const hyp = Math.hypot;
const WALKZ = [T.SIDEWALK, T.PLAZA, T.PATH, T.SAND, T.WOOD, T.QUAY, T.DESERT, T.GRAVEL, T.TURF, T.CONCRETE, T.TARMAC, T.FOREST, T.FARM, T.GRASS, T.ROAD, T.DIRT, T.PARKING];
const ZT = {
  walker: { hp: 70, spd: 62, dmg: 12, reach: 16, cd: 1.0, sight: 300, inf: 8, sz: 1, r: 8 },
  runner: { hp: 45, spd: 150, dmg: 9, reach: 16, cd: 0.75, sight: 430, inf: 7, sz: 0.97, r: 8 },
  brute: { hp: 480, spd: 60, dmg: 34, reach: 24, cd: 1.5, sight: 320, inf: 16, sz: 1.5, r: 12, knock: 520 },
  spitter: { hp: 60, spd: 72, dmg: 10, reach: 16, cd: 1.0, sight: 380, inf: 12, sz: 1, r: 8 },
  boomer: { hp: 90, spd: 54, dmg: 10, reach: 16, cd: 1.2, sight: 300, inf: 12, sz: 1.3, r: 10 },
  tyrant: { hp: 3200, spd: 92, dmg: 46, reach: 30, cd: 1.2, sight: 900, inf: 40, sz: 2.0, r: 15, knock: 800 },
};
const SKINS = ['#8aa37a', '#9bb08c', '#7e9a74', '#a6b59a', '#8d9a6e'];
const SHIRTS = ['#4a3b36', '#37424a', '#59463a', '#3d3d45', '#5a2f2f', '#2f4a3a'];

const CHAPTER_TITLES = ['FIRST BITE', 'THIN BLUE LINE', 'PATIENT ZERO', 'DEAD WATER', 'ARMORED RESPONSE', 'WINGS OF MERCY'];

export function zmInit(g) {
  if (g._zmReady) return; g._zmReady = true;
  injectCss(g);
  const prevKill = g.onKill;
  g.onKill = (a, src) => { if (prevKill) prevKill(a, src); if (g.zm) onKill(g, a, src); };
  g.zmMenu = () => menu(g);
  g.zmBegin = (ch) => begin(g, ch);
  g.zmEnd = () => end(g);
  g.zmAI = (a, dt) => zmAI(g, a, dt);
  g.zmPop = (dt) => population(g, dt);
  g.zmStep = (dt) => step(g, dt);
  g.zmDecor = (c, a, x, y, ang) => decor(g, c, a, x, y, ang);
  g.zmDraw = (c, x0, y0, x1, y1) => drawWorld(g, c, x0, y0, x1, y1);
  g.zmPickup = (k) => pickup(g, k);
  g.zmMarkers = (arr) => { const S = g.zm; if (!S) return; for (const m of S.markers) arr.push(m); };
  g.zmHorde = (n) => horde(g, n);
  g.zmSkip = () => { const S = g.zm; if (S && S.cur) { S.cur.done = true; g.toast('Objective skipped', '#9ac'); } };
  g.zmSpawnPoint = () => { const S = g.zm, p = S.respawn || g.world.pois.start; return { x: p.x, y: p.y + 24 }; };
  g.zmInterior = (I) => interior(g, I);
}

// ======================================================= zombies
function setupZombie(g, a, type) {
  const d = ZT[type]; a.z = type; a.zd = d; a.fac = 'zom'; a.type = 'zombie'; a.hp = a.max = d.hp; a.r = d.r; a.noLoot = true; a.st = 'wander'; a.t = rnd(0, 3); a.wid = 'fists'; a.wdef = null;
  a.wdef = g.world && a.wdef; a.speed = d.spd * (0.85 + Math.random() * 0.3); a.vis = d.sight; a.cd2 = 0; a.gT = rnd(2, 12); a.dir = Math.random() * TAU; a.retarget = Math.random() * 0.3; a.target = null; a.inv = null; a.mis = false; a.ally = false; a.surv = null; a.inf = false; a.armedZ = false; a.post = null;
  a.look = Object.assign({}, a.look, { skin: pick(SKINS), shirt: chance(0.5) ? a.look.shirt : pick(SHIRTS), sz: d.sz, build: type === 'brute' || type === 'boomer' ? 1.2 : 1, shades: false });
  if (type === 'runner') a.look.shirt = pick(['#7a2a2a', '#3a3a40']);
  if (type === 'boomer') a.look.skin = '#a8b560'; if (type === 'tyrant') { a.look.skin = '#6f8f5e'; a.look.shirt = '#2a1f1f'; }
  return a;
}
import { WEAPONS } from './data.js';
function spawnZombie(g, type, x, y, o = {}) {
  const a = spawnActor(g, 'zombie', x, y, { fac: 'zom', w: 'fists', inside: o.inside || null }); if (!a) return null;
  setupZombie(g, a, type); a.wdef = WEAPONS.fists; if (o.chase) { a.invest = { x: o.chase.x, y: o.chase.y, t: 25 }; a.st = 'invest'; }
  return a;
}
function turn(g, a, why) {
  if (!a.on) return; const x = a.x, y = a.y, look = a.look, ins = a.inside; const wasSurv = a.surv, S = g.zm;
  if (a.veh) g.exitVehicle(a, true);
  a.init('zombie', x, y, { fac: 'zom', w: 'fists', look, inside: ins }); setupZombie(g, a, chance(0.12) ? 'runner' : 'walker'); a.wdef = WEAPONS.fists; a.dead = false;
  if (wasSurv) S.lost++; S.turned++;
  g.audio.sfx('zscream', x, y, 0.8); g.parts.burst(P.BLOOD, x, y, 12, 120, 0.7, 2.6, '#7d0c14'); g.parts.emit(P.RING, x, y, 0, 0, 0.6, 16, '#9bd36a');
  if (g.hashA) a.invest = null; void why;
}
function nearestZombie(g, a, range, needLos = true) {
  let best = null, bd = range; g._zq = g._zq || []; g._zq.length = 0; g.hashA.query(a.x, a.y, range, g._zq);
  for (const b of g._zq) { if (!b.on || b.dead || b.fac !== 'zom' || b.inside !== a.inside) continue; const d = hyp(b.x - a.x, b.y - a.y); if (d < bd && (!needLos || d < 70 || g.lineClear(a.x, a.y, b.x, b.y))) { bd = d; best = b; } }
  return best;
}
function pickTarget(g, a) {
  const p = g.player, d0 = a.zd, night = g.env.dark > 0.55, sight = d0.sight * (night ? 1.15 : 1);
  let best = null, bs = 1e9; g._zq2 = g._zq2 || []; g._zq2.length = 0; g.hashA.query(a.x, a.y, sight, g._zq2);
  for (const b of g._zq2) {
    if (!b.on || b.dead || b.fac === 'zom' || b.veh || b.inside !== a.inside || b.hidden) continue;
    const d = hyp(b.x - a.x, b.y - a.y), ps = b === p && p.crouch ? 0.55 : 1;
    if (d > 85 && (d > sight * ps || !g.lineClear(a.x, a.y, b.x, b.y))) continue;
    let sc = d * (b === a.target ? 0.7 : 1) * (b === p ? 0.95 : 1); if (sc < bs) { bs = sc; best = b; }
  }
  if (!best && p.inside === a.inside && !p.dead) { // player in a vehicle / on foot hidden from the hash
    const d = hyp(p.x - a.x, p.y - a.y); if (d < sight * 0.9 && (!p.heli || p.heli.alt < 0.12) && (d < 90 || g.lineClear(a.x, a.y, p.x, p.y))) best = p;
  }
  return best;
}
function zombieAI(g, a, dt) {
  const S = g.zm, p = g.player, d0 = a.zd; if (!d0) { setupZombie(g, a, 'walker'); }
  const D = a.zd; a.cd2 -= dt; a.gT -= dt; a.retarget -= dt;
  if (a.gT <= 0) { a.gT = rnd(6, 15); if (hyp(a.x - p.x, a.y - p.y) < 650) g.audio.sfx(a.z === 'tyrant' || a.z === 'brute' ? 'zroar' : 'zgroan', a.x, a.y, a.z === 'brute' ? 0.7 : 0.45); }
  if (a.retarget <= 0) {
    a.retarget = 0.35 + Math.random() * 0.25; a.target = pickTarget(g, a);
    if (!a.target) for (const n of g.noises) { const d = hyp(a.x - n.x, a.y - n.y); if (d < n.r * 0.85) { a.invest = { x: n.x, y: n.y, t: 10 }; a.st = 'invest'; break; } }
  }
  const t = a.target && !a.target.dead && a.target.on ? a.target : null; const night = g.env.dark > 0.55; const spMul = (night ? 1.12 : 1) * (1 + S.ch * 0.03);
  if (t) {
    a.st = 'chase'; const tx = t.x, ty = t.y, dx = tx - a.x, dy = ty - a.y, d = hyp(dx, dy) || 1, ang = Math.atan2(dy, dx);
    a.a = rotToward(a.a, ang, 10 * dt);
    const bigV = t === p && p.veh ? 22 : 0, reach = a.r + D.reach + bigV;
    let sp = a.speed * spMul;
    if (a.z === 'tyrant') { a.chT = (a.chT || 4) - dt; if (a.chT <= 0 && d > 140) { a.chT = 6; a.charge = 0.9; g.audio.sfx('zroar', a.x, a.y, 1); g.cam.shake = Math.max(g.cam.shake, 6); } if (a.charge > 0) { a.charge -= dt; sp *= 3.2; } }
    if (a.z === 'spitter' && d > 90 && d < 390 && g.lineClear(a.x, a.y, tx, ty)) {
      stepActor(g, a, dt, 0, 0, 0); a.aim = ang; if (a.cd2 <= 0) { a.cd2 = 2.1; const sa = ang + (Math.random() - 0.5) * 0.12; g.bullets.spawn({ x: a.x + Math.cos(ang) * 10, y: a.y + Math.sin(ang) * 10, vx: Math.cos(sa) * 540, vy: Math.sin(sa) * 540, dmg: 13, owner: a, ownerV: null, fac: 'zom', life: 420, kind: 'b', rad: 0 }); g.parts.burst(P.SMOKE, a.x + Math.cos(ang) * 10, a.y + Math.sin(ang) * 10, 4, 40, 0.5, 4, '#9bd36a'); a.swing = 1; }
    } else if (d > reach) {
      let mx = dx / d, my = dy / d;
      if (d > 60 && !g.lineClear(a.x, a.y, tx, ty)) {
        a.repath = (a.repath || 0) - dt; if ((!a.path || a.repath <= 0) && S.pathBudget > 0) { S.pathBudget--; goTo(g, a, tx, ty, { max: 380 }); a.repath = 1 + Math.random() * 0.6; }
        if (a.path && a.pi < a.path.length) { followPath(g, a, dt, sp); a.swing = 0.25; return; }
      } else a.path = null;
      const [sx, sy] = sepVec(g, a); mx += sx * 0.5; my += sy * 0.5; const l = hyp(mx, my) || 1;
      stepActor(g, a, dt, mx / l, my / l, sp); a.swing = 0.25;
    } else {
      stepActor(g, a, dt, 0, 0, 0); a.swing = Math.max(a.swing, 0.2);
      if (a.cd2 <= 0) {
        a.cd2 = D.cd * (0.9 + Math.random() * 0.3); a.swing = 1; g.audio.sfx('zbite', a.x, a.y, 0.7);
        if (a.z === 'boomer' && chance(0.5)) { damageActor(g, a, 9999, { kind: 'self' }); return; }
        if (t === p) {
          if (p.veh) { damageVehicle(g, p.veh, D.dmg * 0.8, { by: a }); g.cam.shake = Math.max(g.cam.shake, 2); }
          else if (!p.heli) { damageActor(g, p, D.dmg, { by: a, fac: 'zom', kind: 'melee', dx, dy }); S.inf = Math.min(100, S.inf + D.inf); S.lastBite = g.time; if (D.knock) { p.kx += dx / d * D.knock; p.ky += dy / d * D.knock; } g.fx.hurt = Math.min(1, g.fx.hurt + 0.3); }
        } else {
          damageActor(g, t, D.dmg * (t.fac === 'pd' ? 0.7 : 1), { by: a, fac: 'zom', kind: 'melee', dx, dy }); if (D.knock) { t.kx += dx / d * D.knock; t.ky += dy / d * D.knock; }
          if (t.hp > 0 && !t.inf && t.fac !== 'zom') { t.inf = true; t.infT = rnd(6, 11); }
        }
      }
    }
    return;
  }
  // no target: investigate noise, otherwise shamble
  if (a.invest) {
    a.invest.t -= dt; const dx = a.invest.x - a.x, dy = a.invest.y - a.y, d = hyp(dx, dy);
    if (d < 40 || a.invest.t <= 0) { a.invest = null; a.st = 'wander'; }
    else { a.a = rotToward(a.a, Math.atan2(dy, dx), 6 * dt); if (!g.lineClear(a.x, a.y, a.invest.x, a.invest.y)) { a.repath = (a.repath || 0) - dt; if ((!a.path || a.repath <= 0) && S.pathBudget > 0) { S.pathBudget--; goTo(g, a, a.invest.x, a.invest.y, { max: 400 }); a.repath = 1.2; } if (a.path && a.pi < a.path.length) { followPath(g, a, dt, a.speed * 0.8); return; } } stepActor(g, a, dt, dx / d, dy / d, a.speed * 0.85); a.swing = 0.2; return; }
  }
  a.t -= dt;
  if (a.t <= 0) { a.t = rnd(2, 6); a.dir += rnd(-1.6, 1.6); if (chance(0.3)) a.moving = false; else a.moving = true; }
  if (a.moving !== false) {
    let mx = Math.cos(a.dir), my = Math.sin(a.dir);
    if (!g.lineClear(a.x, a.y, a.x + mx * 36, a.y + my * 36) || (!a.inside && g.world.tileAt(a.x + mx * 30, a.y + my * 30) === T.WATER)) { a.dir += rnd(1.2, 2.4); a.t = 1; mx = 0; my = 0; }
    a.a = rotToward(a.a, a.dir, 3 * dt); stepActor(g, a, dt, mx, my, a.speed * 0.4);
  } else stepActor(g, a, dt, 0, 0, 0);
  a.swing = 0.1;
}

// ======================================================= humans
function say(a, text, t = 2) { a.say = { text, t }; }
function turnTimer(g, a, dt) {
  if (!a.inf) return false; a.infT -= dt; a.moveAmt = Math.min(a.moveAmt, 0.5); if (Math.random() < dt * 0.6) { say(a, pick(['I feel…', '*cough*', "don't leave me", 'it burns']), 1.5); }
  if (a.infT <= 0) { turn(g, a, 'bite'); return true; } return false;
}
function refuge(g, a) {
  const S = g.zm; let best = null, bd = 700;
  g._rq = g._rq || []; g._rq.length = 0; g.hashA.query(a.x, a.y, 600, g._rq);
  for (const b of g._rq) { if (!b.on || b.dead || b.fac !== 'pd' || b.inside !== a.inside) continue; const d = hyp(b.x - a.x, b.y - a.y); if (d < bd) { bd = d; best = b; } }
  if (best) return { x: best.x, y: best.y, cop: true };
  if (S.safe && hyp(S.safe.x - a.x, S.safe.y - a.y) < 1400) return { x: S.safe.x, y: S.safe.y };
  return a.home ? { x: a.home.x || a.home.door?.x, y: a.home.y || a.home.door?.y, door: true } : null;
}
function civZ(g, a, dt) {
  const S = g.zm;
  if (a.say) { a.say.t -= dt; if (a.say.t <= 0) a.say = null; }
  if (turnTimer(g, a, dt)) return;
  if (a.surv) return survivorAI(g, a, dt);
  a.scanT = (a.scanT || 0) - dt;
  if (a.scanT <= 0) { a.scanT = 0.3 + Math.random() * 0.15; a.thr = nearestZombie(g, a, a.armedZ ? 320 : 280, true); }
  const z = a.thr && !a.thr.dead && a.thr.on ? a.thr : null;
  if (z) {
    if (a.armedZ && hyp(z.x - a.x, z.y - a.y) > 60) { a.st = 'zfight'; aiCombat(g, a, dt, z, true); return; }
    a.st = 'zflee'; a.calm = 4; if (Math.random() < dt * 0.5) say(a, pick(['Help!', 'RUN!', 'They’re everywhere!', 'Oh god—', 'Get back!']), 2);
    const dx = a.x - z.x, dy = a.y - z.y, d = hyp(dx, dy) || 1; let mx = dx / d, my = dy / d; const rf = refuge(g, a);
    if (rf) { const rx = rf.x - a.x, ry = rf.y - a.y, rd = hyp(rx, ry) || 1; mx += (rx / rd) * 0.9; my += (ry / rd) * 0.9;
      if (rf.door && rd < 30 && d > 40) { a.on = false; S.sheltered++; return; } }
    const [sx, sy] = sepVec(g, a); mx += sx * 0.5; my += sy * 0.5; const l = hyp(mx, my) || 1; mx /= l; my /= l;
    if (!g.lineClear(a.x, a.y, a.x + mx * 40, a.y + my * 40)) { const pa = Math.atan2(my, mx) + (a.strafe || 1) * 1.1; mx = Math.cos(pa); my = Math.sin(pa); }
    a.a = rotToward(a.a, Math.atan2(my, mx), 12 * dt); stepActor(g, a, dt, mx, my, (a.role === 'jogger' ? 190 : 150) * (a.hp < 40 ? 0.8 : 1)); a.moveAmt = 1; return;
  }
  if (a.st === 'zflee' || a.st === 'zfight') { a.calm -= dt; if (a.calm > 0) { stepActor(g, a, dt, 0, 0, 0); return; } a.st = 'idle'; a.t = 1; }
  if (a.st === 'idle' || a.st === 'walk' || a.st === 'stay' || a.st === 'chat' || a.st === 'smoke' || a.st === 'photo' || a.st === 'fight') civ(g, a, dt); else { a.st = 'idle'; }
}
function survivorAI(g, a, dt) {
  const p = g.player, S = g.zm;
  if (a.surv === 'safe') { stepActor(g, a, dt, 0, 0, 0); a.safeT = (a.safeT || 0) + dt; if (a.safeT > 10) a.on = false; return; }
  const d = hyp(p.x - a.x, p.y - a.y);
  a.scanT = (a.scanT || 0) - dt; if (a.scanT <= 0) { a.scanT = 0.25; a.thr = nearestZombie(g, a, 170, true); }
  const z = a.thr && !a.thr.dead && a.thr.on ? a.thr : null;
  if (a.surv === 'wait') {
    if (d < 150 || (z && d < 500)) { a.surv = 'follow'; say(a, 'Thank god! Don’t leave me!', 3); g.audio.sfx('pickup'); S.followed++; }
    else { // cower & wave
      a.a += Math.sin(g.time * 2 + a.i) * dt * 2; stepActor(g, a, dt, 0, 0, 0); if (z) { const dx = a.x - z.x, dy = a.y - z.y, dd = hyp(dx, dy) || 1; stepActor(g, a, dt, dx / dd, dy / dd, 120); }
      if (Math.random() < dt * 0.4) say(a, pick(['Over here!', 'Help us!', 'Please!']), 1.5); return;
    }
  }
  // follow the player, keep a gap, bolt away from zombies
  let tx = p.x, ty = p.y; const gap = 60 + (a.i % 4) * 14; let sp = clamp((d - gap) * 2.2, 0, 175);
  if (z && d > 50) { const dx = a.x - z.x, dy = a.y - z.y, dd = hyp(dx, dy) || 1; tx = a.x + dx / dd * 120 + (p.x - a.x) * 0.5; ty = a.y + dy / dd * 120 + (p.y - a.y) * 0.5; sp = 170; }
  if (d > gap || z) {
    const dx = tx - a.x, dy = ty - a.y, dd = hyp(dx, dy) || 1;
    if (!g.lineClear(a.x, a.y, p.x, p.y) && !z) { a.repath = (a.repath || 0) - dt; if (!a.path || a.repath <= 0) { goTo(g, a, p.x, p.y, { max: 420 }); a.repath = 1.1; } if (a.path && a.pi < a.path.length) { followPath(g, a, dt, Math.max(90, sp)); return; } }
    a.a = rotToward(a.a, Math.atan2(dy, dx), 10 * dt); stepActor(g, a, dt, dx / dd, dy / dd, sp); a.moveAmt = 1;
  } else stepActor(g, a, dt, 0, 0, 0);
}
function copZ(g, a, dt) {
  const S = g.zm, p = g.player;
  if (a.say) { a.say.t -= dt; if (a.say.t <= 0) a.say = null; }
  if (turnTimer(g, a, dt)) return;
  a.scanT = (a.scanT || 0) - dt;
  if (a.scanT <= 0) { a.scanT = 0.3 + Math.random() * 0.15; a.tz = nearestZombie(g, a, a.soldier ? 560 : 460, true); a.nz = 0; if (a.tz) { g._zq3 = g._zq3 || []; g._zq3.length = 0; g.hashA.query(a.x, a.y, 120, g._zq3); for (const b of g._zq3) if (b.fac === 'zom' && !b.dead) a.nz++; } }
  const z = a.tz && !a.tz.dead && a.tz.on ? a.tz : null;
  if (z) {
    a.st = 'combat'; a.target = z; a.dmgMul = a.soldier ? 1.5 : 1.15;
    if (a.nz >= 5 && !a.ally && !a.soldier) { // overrun: fall back
      const dx = a.x - z.x, dy = a.y - z.y, d = hyp(dx, dy) || 1; a.a = rotToward(a.a, Math.atan2(dy, dx), 10 * dt); stepActor(g, a, dt, dx / d, dy / d, 140); if (Math.random() < dt * 0.4) say(a, pick(['Fall back!', 'Too many!', 'Cover me!']), 1.6); return;
    }
    if (Math.random() < dt * 0.15) say(a, pick(['Contact!', 'Put them down!', 'Stay behind me!', 'Reloading!']), 1.4);
    aiCombat(g, a, dt, z, true); return;
  }
  a.st = 'idle'; a.target = null;
  if (a.ally) { allyFollow(g, a, dt); return; }
  if (a.post) { const dx = a.post.x - a.x, dy = a.post.y - a.y, d = hyp(dx, dy); if (d > 50) { a.a = rotToward(a.a, Math.atan2(dy, dx), 8 * dt); stepActor(g, a, dt, dx / d, dy / d, 90); } else { stepActor(g, a, dt, 0, 0, 0); a.a += Math.sin(g.time * 0.6 + a.i) * dt * 0.7; } return; }
  routine(g, a, dt); void p;
}
function zmAI(g, a, dt) {
  if (a.fac === 'zom') { zombieAI(g, a, dt); return true; }
  if (a.dead) return false;
  if (a.fac === 'civ') { civZ(g, a, dt); return true; }
  if (a.fac === 'pd') { copZ(g, a, dt); return true; }
  return false;
}
function onKill(g, a, src) {
  const S = g.zm, by = src && src.by;
  if (a.fac === 'zom') {
    S.kills++; S.stepKills++; if (a.z === 'boomer') { explode(g, a.x, a.y, 95, 55, { by: null, fac: 'zom' }, false); g.parts.burst(P.SMOKE, a.x, a.y, 14, 90, 1.4, 12, '#a8b560'); g.noise(a.x, a.y, 600, { by: null }); }
    if (a.z === 'tyrant') { S.bossDead = true; g.toast('PATIENT ZERO IS DOWN', '#7cff4f'); }
    const r = Math.random(); if (r < 0.2 + (g.inv.ammo['9mm'] < 20 ? 0.15 : 0)) g.pickups.push({ type: 'ammo', x: a.x + rnd(-8, 8), y: a.y + rnd(-8, 8), v: 1, life: 90, inside: a.inside });
    else if (r < 0.25) g.pickups.push({ type: 'heal', v: 35, x: a.x, y: a.y, life: 90, inside: a.inside }); else if (r < 0.265 + S.ch * 0.004) g.pickups.push({ type: 'heal', serum: true, x: a.x, y: a.y, life: 120, inside: a.inside });
    return;
  }
  if (a === g.player) return;
  if (a.surv && a.surv !== 'safe') S.lost++;
  if (a.fac === 'civ' && !a.surv) S.civDead++;
  if (a.inf || (src && src.fac === 'zom') || (by && by.fac === 'zom')) { // the dead get back up
    const id = (a.riseId = g.time + Math.random());
    g.later(rnd(2.5, 5), () => { if (g.zm && a.on && a.dead && a.riseId === id) { a.dead = false; turn(g, a, 'rise'); S.turned--; S.risen++; } });
  }
}
function interior(g, I) {
  const S = g.zm; let n = 0;
  for (const a of g.actors) if (a.on && a !== g.player && a.inside === I.id && !a.dead && chance(0.5)) { turn(g, a, 'int'); S.turned--; n++; }
  const pts = I.npcs && I.npcs.length ? I.npcs : [I.pts.entry];
  for (const n2 of pts) if (chance(0.55)) g.pickups.push({ type: chance(0.45) ? 'ammo' : 'heal', v: 30, x: n2.x + rnd(-30, 30), y: n2.y + rnd(-30, 30), life: 600, inside: I.id });
  if (n) g.toast('You hear something shuffling inside…', '#9bd36a');
}
function pickup(g, k) {
  const p = g.player, S = g.zm;
  if (k.type === 'heal') { if (k.serum) { S.serum++; g.toast('Antiserum  (press T to inject)', '#7cff4f'); g.audio.sfx('levelup'); } else { p.hp = Math.min(p.max, p.hp + (k.v || 30)); g.toast('+' + (k.v || 30) + ' health', '#7cff4f'); g.audio.sfx('pickup'); } return true; }
  return false;
}

// ======================================================= population / events
const inView = (g, x, y, pad = 80) => Math.abs(x - g.cam.x) < g.viewW / 2 + pad && Math.abs(y - g.cam.y) < g.viewH / 2 + pad;
function spot(g, minD, maxD) {
  const p = g.player, w = g.world;
  for (let k = 0; k < 6; k++) { const s = w.randomWalkable(p.x, p.y, maxD, WALKZ); if (s && hyp(s.x - p.x, s.y - p.y) > minD && !inView(g, s.x, s.y, 50) && w.tileAt(s.x, s.y) !== T.WATER) return s; }
  return null;
}
function pickZType(g) {
  const S = g.zm, night = g.env.dark > 0.55, r = Math.random(), ch = S.ch;
  if (ch >= 2 && r < 0.05) return 'brute'; if (ch >= 2 && r < 0.09) return 'boomer'; if (ch >= 3 && r < 0.13) return 'spitter';
  if (r < 0.16 + ch * 0.02 + (night ? 0.14 : 0)) return 'runner'; return 'walker';
}
function population(g, dt) {
  const S = g.zm, p = g.player, q = g.settings.quality; if (g.scene || S.paused) return;
  const maxZ = (q === 'low' ? 24 : q === 'medium' ? 34 : 44), night = g.env.dark > 0.55;
  let nz = 0, ncv = 0, ncop = 0; for (const a of g.actors) if (a.on && !a.dead && a !== p) { if (a.fac === 'zom') nz++; else if (a.fac === 'civ' && !a.surv) ncv++; else if (a.fac === 'pd') ncop++; }
  for (const a of g.actors) if (a.on && a.mis && a !== p && !a.ally && (a.fac === 'pd' || a.surv === 'safe' || a.surv === 'wait') && hyp(a.x - p.x, a.y - p.y) > 2000) a.on = false;
  const district = g.world.districtAt(p.x, p.y), hot = /downtown|aurelia|solcosta|airport|beach/.test(String(district)) ? 1.25 : /pine|valley|saguaro|ocean|frontier/.test(String(district)) ? 0.6 : 1;
  const want = Math.min(maxZ, Math.round((9 + S.ch * 2.5 + (night ? 7 : 0) + S.heat * 6) * hot));
  if (nz < want) { const s = spot(g, 480, 900); if (s) { const n = 1 + (chance(0.35) ? Math.floor(Math.random() * 3) : 0); for (let i = 0; i < n; i++) spawnZombie(g, pickZType(g), s.x + rnd(-30, 30), s.y + rnd(-30, 30), { chase: chance(0.25) ? p : null }); } }
  if (ncv < (night ? 3 : 6) && chance(0.5)) {
    const s = spot(g, 450, 850); if (s) { const a = spawnActor(g, 'civ', s.x, s.y, { fac: 'civ', w: 'fists' }); if (a) { a.st = chance(0.5) ? 'zflee' : 'idle'; a.calm = 3; a.t = rnd(0, 3); a.home = g.world.randomDoor(s.x, s.y, 0, 900) || undefined; a.armedZ = chance(0.1 + S.ch * 0.02); if (a.armedZ) { a.wid = chance(0.6) ? 'pistol' : 'bat'; a.wdef = WEAPONS[a.wid]; a.dmgMul = 1; } a.speed = 70 + Math.random() * 30; a.strafe = chance(0.5) ? 1 : -1; } }
  }
  if (ncop < 3 + (S.ch >= 3 ? 2 : 0) && chance(0.35)) {
    const s = spot(g, 520, 900); if (s) {
      const sold = S.ch >= 3 && chance(0.5), n = 2 + (chance(0.4) ? 1 : 0);
      for (let i = 0; i < n; i++) { const a = spawnActor(g, 'cop', s.x + rnd(-26, 26), s.y + rnd(-26, 26), { fac: 'pd', w: sold ? 'rifle' : pick(['pistol', 'pistol', 'shotgun', 'smg']) }); if (a) { a.st = 'idle'; a.post = { x: s.x, y: s.y }; a.dmgMul = 1.2; if (sold) { a.soldier = true; a.look.shirt = '#4f5a3f'; a.look.pants = '#3d4630'; a.look.hair = '#2b2b2b'; } } }
      if (chance(0.5) && !g.vehicles.some((v) => v.on && hyp(v.x - s.x, v.y - s.y) < 120)) { const v = spawnVehicle(g, sold ? 'army' : 'police', s.x + 40, s.y + 20, Math.random() * TAU, { ai: 'none', cop: !sold }); if (v) { v.burning = false; } }
    }
  }
  // burning wrecks & fires: the world is on fire
  S.fireT -= 0.25; if (S.fireT <= 0 && g.fires.length < 6) { S.fireT = rnd(4, 9); const s = spot(g, 300, 800); if (s) { g.fires.push({ x: s.x, y: s.y, r: rnd(40, 66), life: rnd(40, 100), by: null }); if (chance(0.5)) { const v = spawnVehicle(g, pick(['sedan', 'compact', 'van', 'pickup', 'taxi']), s.x + 50, s.y, Math.random() * TAU, { ai: 'none' }); if (v) { v.hp = v.def.hp * 0.18; v.burning = true; v.vx = v.vy = 0; } } } }
}
function horde(g, n) {
  const p = g.player; g.toast('A HORDE is coming!', '#ff5566'); g.audio.sfx('zroar', p.x, p.y, 1);
  const ang = Math.random() * TAU; let c = 0;
  for (let i = 0; i < 40 && c < n; i++) { const a = ang + rnd(-0.6, 0.6), d = rnd(560, 760), x = p.x + Math.cos(a) * d, y = p.y + Math.sin(a) * d; if (g.world.tileAt(x, y) === T.WATER || g.world.solid(x, y)) continue; if (spawnZombie(g, chance(0.25) ? 'runner' : chance(0.08) ? 'brute' : 'walker', x, y, { chase: p })) c++; }
}
function say2(g, who, text, dur = 5) { const S = g.zm; S.radio.push({ who, text, dur }); }
function circleDraw(S, x, y, r, col, label) { S.rings.push({ x, y, r, col, label }); }
const COPS = (g, x, y, n, o = {}) => { for (let i = 0; i < n; i++) { const a = spawnActor(g, 'cop', x + rnd(-60, 60), y + rnd(-60, 60), { fac: 'pd', w: o.w || pick(['rifle', 'pistol', 'shotgun', 'smg']) }); if (a) { a.post = { x: a.x, y: a.y }; a.st = 'idle'; a.dmgMul = 1.3; a.mis = !!o.keep; if (o.soldier) { a.soldier = true; a.look.shirt = '#4f5a3f'; a.look.pants = '#3d4630'; a.look.hair = '#2b2b2b'; } if (o.ally) { a.ally = true; a.mis = true; } } } };
function walkNear(g, x, y, minD, maxD, tries = 30) {
  const w = g.world; for (let k = 0; k < tries; k++) { const a = Math.random() * TAU, d = rnd(minD, maxD), px = x + Math.cos(a) * d, py = y + Math.sin(a) * d, t = w.tileAt(px, py); if (WALKZ.includes(t) && !w.solid(px, py) && !w.pushCircle(px, py, 12, true).hit) return { x: px, y: py }; }
  return { x: x + minD, y: y };
}
function waterPoint(g, from, minD, maxD, used) {
  const w = g.world, dl = w.landDist, NT = 768; if (!dl) return null;
  for (let k = 0; k < 200; k++) {
    const a = Math.random() * TAU, d = rnd(minD, maxD), x = from.x + Math.cos(a) * d, y = from.y + Math.sin(a) * d, tx = Math.floor(x / 32), ty = Math.floor(y / 32);
    if (tx < 2 || ty < 2 || tx >= NT - 2 || ty >= NT - 2 || dl[ty * NT + tx] < 3 || used.some((u) => hyp(u.x - x, u.y - y) < 260)) continue;
    let ok = true; for (let s = 1; s <= 12 && ok; s++) { const sx = from.x + (x - from.x) * s / 12, sy = from.y + (y - from.y) * s / 12; if (w.tileAt(sx, sy) !== T.WATER) ok = false; }
    if (ok) return { x, y };
  }
  return null;
}

// ======================================================= campaign
function mk(text, o) { return Object.assign({ done: false, t: 0 }, o, { text }); }
const speakStep = (g, who, text, dur = 6) => mk('Listen…', { init() { say2(g, who, text, dur); this.wait = dur; }, tick(g2, dt) { this.wait -= dt; return this.wait <= 0; }, hidden: true });
function reachStep(text, getPos, r = 140, extra = {}) { return mk(text, Object.assign({ init(g) { this.pos = getPos(g); this.set && this.set(g); }, tick(g) { const p = g.player; return hyp(p.x - this.pos.x, p.y - this.pos.y) < r && !g.scene; }, marker() { return this.pos; }, ring: r }, extra)); }
function killStep(text, n, extra = {}) { return mk(text, Object.assign({ init(g) { g.zm.stepKills = 0; this.n = n; }, tick(g) { return g.zm.stepKills >= this.n; }, prog(g) { return `${Math.min(g.zm.stepKills, this.n)} / ${this.n} infected down`; } }, extra)); }
function rescueStep(text, n, getFrom, getTo, r = 150, extra = {}) {
  return mk(text, Object.assign({
    init(g) {
      const S = g.zm, from = getFrom(g); this.to = getTo(g); this.n = n; this.saved = 0; S.surv = []; S.lost = 0; S.followed = 0;
      for (let i = 0; i < n; i++) { const s = walkNear(g, from.x, from.y, 380 + i * 60, 700 + i * 90); const a = spawnActor(g, 'civ', s.x, s.y, { fac: 'civ', w: 'fists', mis: true }); if (!a) continue; a.surv = 'wait'; a.mis = true; a.noLoot = true; a.st = 'stay'; a.hp = a.max = 60; S.surv.push(a); for (let k = 0; k < 2 + (i % 2); k++) { const q = walkNear(g, s.x, s.y, 120, 220); spawnZombie(g, k && S.ch > 1 ? 'runner' : 'walker', q.x, q.y, { chase: s }); } }
    },
    tick(g) {
      const S = g.zm; for (const a of S.surv) { if (a.on && !a.dead && a.surv === 'follow' && hyp(a.x - this.to.x, a.y - this.to.y) < r) { a.surv = 'safe'; this.saved++; S.saved++; g.toast(`Survivor safe  ${this.saved}/${this.n}`, '#7cff4f'); g.audio.sfx('cash'); g.cash += 60; } }
      const alive = S.surv.filter((a) => a.on && !a.dead && a.surv !== 'safe').length;
      if (alive === 0) { if (this.saved >= Math.ceil(this.n / 2)) return true; g.toast('Too many lost — more survivors are calling for help!', '#ff7788'); this.init(g); }
      return this.saved >= this.n;
    },
    markers(g) { const S = g.zm, out = []; let anyFollow = false; for (const a of S.surv) if (a.on && !a.dead && a.surv === 'follow') anyFollow = true; for (const a of S.surv) if (a.on && !a.dead && a.surv === 'wait') out.push({ x: a.x, y: a.y, label: 'Survivor' }); if (anyFollow) out.push({ x: this.to.x, y: this.to.y, label: 'Safe zone' }); return out; },
    prog() { return `${this.saved} / ${this.n} survivors delivered`; }, ring: r, ringAt(g) { return this.to; }, onEnd(g) { for (const a of g.zm.surv) if (a.on && a.surv === 'follow') a.surv = 'safe'; },
  }, extra));
}
function chapter(g, ch) {
  const w = g.world, P = w.pois, S = g.zm;
  const cops = (key, n, o) => () => COPS(g, P[key].x, P[key].y + 40, n, o);
  if (ch === 0) return {
    title: 'FIRST BITE', intro: 'Harbor Road · 18:40', start: () => P.start, hour: 18.6,
    steps: [
      speakStep(g, 'EMERGENCY BROADCAST', 'All residents of Port Meridian: remain indoors. Do NOT approach the infected. Do not— *static* —they are inside the— *screaming*', 7),
      mk('Survive. Take down 4 of the infected', Object.assign(killStep('', 4), { init(g2) { g2.zm.stepKills = 0; this.n = 4; g2.giveWeapon('bat', 0); g2.giveWeapon('pistol', 48); g2.switchWeapon('pistol'); g2.player.hp = g2.player.max; for (let i = 0; i < 4; i++) { const q = walkNear(g2, g2.player.x, g2.player.y, 380, 560); spawnZombie(g2, 'walker', q.x, q.y, { chase: i < 2 ? g2.player : null }); } say2(g2, 'RADIO · NINA ZHAO', 'Rook? It’s Nina. Whatever you do — headshots don’t matter, but NOISE does. Gunfire draws them. The bat is quiet.', 8); }, prog(g2) { return `${Math.min(g2.zm.stepKills, 4)} / 4 infected down · gunfire attracts hordes`; } })),
      reachStep('Reach the Police HQ — it is the last holdout', (g2) => P.police, 150, { set(g2) { g2.zm.safe = { x: P.police.x, y: P.police.y, r: 220, name: 'POLICE HQ' }; g2.zm.respawn = P.police; COPS(g2, P.police.x, P.police.y + 60, 5, { keep: true }); if (g2.vehicles.filter((v) => v.on).length < 80) for (const dx of [-120, 120]) spawnVehicle(g2, 'police', P.police.x + dx, P.police.y + 130, Math.PI / 2, { ai: 'none', cop: true }); } }),
      speakStep(g, 'SGT. OKAFOR', 'You made it. Door’s sealed behind you. Rest up — the bitten turn in seconds and the dead get back up. Stay near us when you’re hurt: the safe zone cures infection.', 7),
    ],
  };
  if (ch === 1) return {
    title: 'THIN BLUE LINE', intro: 'Police HQ · The streets', start: () => P.police, hour: 19.6,
    steps: [
      speakStep(g, 'SGT. OKAFOR', 'Four civilians are pinned down in the blocks around HQ. We can’t spare the squads. You’re mobile — bring them back. They’ll follow you. Don’t let them get bitten.', 7),
      rescueStep('Find 4 survivors and lead them to the Police HQ', 4, () => P.police, () => P.police, 170, { init2: true }),
      mk('Reinforce the line', { init(g2) { g2.giveWeapon('rifle', 120); g2.giveWeapon('shotgun', 24); g2.player.armor = 100; g2.zm.serum += 1; COPS(g2, P.police.x, P.police.y + 80, 2, { ally: true, w: 'rifle' }); g2.toast('Okafor lends you two officers, a rifle and an antiserum', '#7cff4f'); g2.audio.sfx('levelup'); this.w = 4; say2(g2, 'SGT. OKAFOR', 'Good work. Take Daniels and Cho — they’ll follow you. Nina says the source is Meridian General. Go.', 6); }, tick(g2, dt) { this.w -= dt; return this.w <= 0; }, hidden: true }),
    ],
  };
  if (ch === 2) return {
    title: 'PATIENT ZERO', intro: 'Meridian General Hospital', start: () => P.police, hour: 20.4,
    steps: [
      speakStep(g, 'NINA ZHAO', 'Meridian General ran a BioGen trial — "Project Tide". The first bite came from there. Find 3 viral samples in the grounds. Expect brutes. Keep your people close.', 7),
      reachStep('Reach Meridian General Hospital', () => P.hosp, 200, { set(g2) { g2.zm.respawn = P.police; g2.zm.heat = 0.6; } }),
      mk('Collect 3 viral samples around the hospital', {
        init(g2) { const S2 = g2.zm; S2.items = []; this.got = 0; for (let i = 0; i < 3; i++) { const s = walkNear(g2, P.hosp.x, P.hosp.y, 140 + i * 40, 320 + i * 60); S2.items.push({ type: 'vial', x: s.x, y: s.y }); for (let k = 0; k < 4; k++) { const q = walkNear(g2, s.x, s.y, 60, 180); spawnZombie(g2, k === 0 ? 'brute' : 'walker', q.x, q.y); } } },
        tick(g2) { return this.got >= 3; }, markers(g2) { return g2.zm.items.filter((i) => i.type === 'vial').map((i) => ({ x: i.x, y: i.y, label: 'Sample' })); }, prog() { return `${this.got} / 3 samples`; }, onItem(g2) { this.got++; },
      }),
      mk('Hold the lab while Nina decrypts the samples', {
        init(g2) { this.t = 0; this.need = 70; this.wave = 0; this.zone = { x: P.hosp.x, y: P.hosp.y, r: 240 }; g2.zm.defend = this.zone; g2.zm.safe = { x: P.hosp.x, y: P.hosp.y, r: 200, name: 'LAB' }; COPS(g2, P.hosp.x, P.hosp.y + 100, 4, { keep: true, w: 'rifle' }); say2(g2, 'NINA ZHAO', 'Uploading… 70 seconds. They can hear the machines — they’re coming. HOLD THE LAB!', 6); },
        tick(g2, dt) { const p = g2.player; if (hyp(p.x - this.zone.x, p.y - this.zone.y) < this.zone.r) this.t += dt; else if (!this.warn || g2.time - this.warn > 5) { this.warn = g2.time; g2.toast('Get back to the lab!', '#ff9a3c'); }
          this.wave -= dt; if (this.wave <= 0) { this.wave = 9; const n = 5 + Math.floor(this.t / 14) * 2; const ang = Math.random() * TAU; for (let i = 0; i < n; i++) { const a = ang + rnd(-0.9, 0.9), d = rnd(380, 520); const x = this.zone.x + Math.cos(a) * d, y = this.zone.y + Math.sin(a) * d; if (!g2.world.solid(x, y) && g2.world.tileAt(x, y) !== T.WATER) spawnZombie(g2, chance(0.2) ? 'runner' : chance(0.06) ? 'brute' : 'walker', x, y, { chase: this.zone }); } if (this.t > 30) g2.audio.sfx('zscream', this.zone.x, this.zone.y, 0.8); }
          if (this.t >= this.need) { g2.zm.defend = null; return true; } return false; },
        prog() { return `Upload ${Math.min(100, Math.round(this.t / this.need * 100))}%  (stay in the lab ring)`; }, ring: 240, ringAt() { return this.zone; },
      }),
      speakStep(g, 'NINA ZHAO', 'Got it. The strain is airborne-resistant but sensitive to a compound the Army has at Fort Granite. The bridges are gone — the only way out is the bay. Survivors are stranded out there; the Navy will airlift them from the pier if you bring them in by boat.', 9),
    ],
  };
  if (ch === 3) return {
    title: 'DEAD WATER', intro: 'Port Meridian · The Bay · Storm', start: () => P.start, hour: 21.5, storm: true,
    steps: [
      mk('Get to the pier and board a boat', {
        init(g2) { const sp = g2.world.aircraftSpots.filter((s) => ['speedboat', 'cruiser', 'gunboat', 'jetski'].includes(s.kind)).sort((a, b) => hyp(a.x - P.start.x, a.y - P.start.y) - hyp(b.x - P.start.x, b.y - P.start.y)); this.boat = sp[0] || P.start; g2.zm.dock = { x: this.boat.x, y: this.boat.y }; g2.zm.safe = { x: P.start.x, y: P.start.y, r: 200, name: 'PIER' }; g2.zm.respawn = P.start; COPS(g2, P.start.x, P.start.y + 40, 3, { keep: true }); say2(g2, 'NINA ZHAO', 'Take a boat — jet ski, speedboat, whatever floats. Walk to it and press E. Four rafts are out in the bay. The storm’s getting worse.', 7); },
        tick(g2) { const h = g2.player.heli; return !!(h && h.def.hull); }, marker() { return this.boat; },
      }),
      mk('Sail to the 4 stranded rafts', {
        init(g2) { const S2 = g2.zm; this.rafts = []; const used = []; const from = S2.dock; for (let i = 0; i < 4; i++) { const pt = waterPoint(g2, from, 500 + i * 120, 1200 + i * 220, used) || waterPoint(g2, from, 300, 2000, used); if (pt) { used.push(pt); this.rafts.push({ x: pt.x, y: pt.y, got: false }); } } if (!this.rafts.length) this.rafts.push({ x: from.x + 400, y: from.y, got: false }); S2.rafts = this.rafts; this.board = 0; },
        tick(g2) { const h = g2.player.heli; if (h && h.def.hull) for (const r of this.rafts) if (!r.got && hyp(h.x - r.x, h.y - r.y) < 110 + h.def.len * 0.3) { r.got = true; this.board++; g2.toast(`Survivor aboard  ${this.board}/${this.rafts.length}`, '#7cff4f'); g2.audio.sfx('cash'); g2.cash += 80; }
          if (this.board >= this.rafts.length) return true; if (!h || !h.def.hull) { if (!this.noBoat || g2.time - this.noBoat > 12) { this.noBoat = g2.time; g2.toast('Get back in a boat!', '#ff9a3c'); } } return false; },
        markers() { return this.rafts.filter((r) => !r.got).map((r) => ({ x: r.x, y: r.y, label: 'Raft' })); }, prog() { return `${this.board} / ${this.rafts.length} rescued · storm: sail carefully`; },
      }),
      mk('Return the survivors to the pier', {
        init(g2) { this.dock = g2.zm.dock; this.n = g2.zm.rafts.length; },
        tick(g2) { const h = g2.player.heli, p = g2.player; const d = h ? hyp(h.x - this.dock.x, h.y - this.dock.y) : hyp(p.x - this.dock.x, p.y - this.dock.y); if (d < 260 && (!h || Math.hypot(h.vx, h.vy) < 200)) { g2.zm.saved += this.n; g2.cash += 200; g2.zm.serum += 2; g2.toast('Survivors landed. +2 antiserum', '#7cff4f'); return true; } return false; },
        marker() { return this.dock; }, ring: 260, ringAt() { return this.dock; },
      }),
      speakStep(g, 'NINA ZHAO', 'The Navy chopper is taking them. You’re cleared to Fort Granite — Colonel Reyes has the counter-agent. Hold on, we’re sending a transport.', 6),
      mk('Transport to Fort Granite', { init(g2) { g2.zm.respawn = P.fort_hq || P.fort; g2.ui.fade(() => { const f = P.fort_hq || P.fort; teleportTo(g2, f.x, f.y + 50); g2.toast('Arrived: Fort Granite', '#4fe0ff'); this.arr = true; }, 700); this.arr = false; }, tick() { return this.arr; }, hidden: true }),
    ],
  };
  if (ch === 4) { const F = P.fort_hq || P.fort; return {
    title: 'ARMORED RESPONSE', intro: 'Fort Granite', start: () => F, hour: 22.5,
    steps: [
      mk('Reach the Fort Granite command post', { init(g2) { this.pos = F; g2.zm.safe = { x: F.x, y: F.y, r: 260, name: 'FORT GRANITE' }; g2.zm.respawn = F; g2.zm.defendPos = P.fort || F; COPS(g2, F.x, F.y + 60, 6, { keep: true, soldier: true, w: 'rifle' }); }, tick(g2) { return hyp(g2.player.x - F.x, g2.player.y - F.y) < 200; }, marker() { return F; } }),
      speakStep(g, 'COL. REYES', 'Rook. We’ve got a horde the size of a stadium at the gate and my men are out of heavy ordnance. The motor pool has Bulldog tanks. Climb into one and clear the approach. The counter-agent is yours when the gate holds.', 8),
      mk('Board a Bulldog tank at the motor pool', {
        init(g2) { const sp = g2.world.aircraftSpots.filter((s) => s.kind === 'bulldog').sort((a, b) => hyp(a.x - g2.player.x, a.y - g2.player.y) - hyp(b.x - g2.player.x, b.y - g2.player.y)); this.t0 = sp[0] || F; },
        tick(g2) { const h = g2.player.heli; return !!(h && h.def.ground === 'tank'); }, marker() { return this.t0; },
      }),
      mk('Clear the gate: destroy 60 of the dead (tank crushes them!)', {
        init(g2) { g2.zm.stepKills = 0; this.n = 60; this.wave = 0; this.gate = g2.zm.defendPos; g2.zm.heat = 1.5; const h = g2.choppers.filter((c) => c.def.ground === 'tank' && c !== g2.player.heli); for (const c of h) c.ai = 'army'; say2(g2, 'COL. REYES', 'Here they come! Use the cannon on packs, the machine gun on strays. Run them over — the Bulldog doesn’t mind!', 6); },
        tick(g2, dt) { this.wave -= dt; const p = g2.player; if (this.wave <= 0) { this.wave = 5.5; const ang = Math.random() * TAU; for (let i = 0; i < 9; i++) { const a = ang + rnd(-0.8, 0.8), d = rnd(500, 700), x = p.x + Math.cos(a) * d, y = p.y + Math.sin(a) * d; if (!g2.world.solid(x, y) && g2.world.tileAt(x, y) !== T.WATER) spawnZombie(g2, chance(0.25) ? 'runner' : chance(0.1) ? 'brute' : chance(0.08) ? 'boomer' : 'walker', x, y, { chase: p }); } }
          if (!p.heli && (!this.nt || g2.time - this.nt > 15)) { this.nt = g2.time; g2.toast('Climb back into the tank!', '#ff9a3c'); }
          if (g2.zm.stepKills >= this.n) { g2.zm.heat = 0.4; return true; } return false; },
        prog(g2) { return `${Math.min(g2.zm.stepKills, 60)} / 60 · cannon LMB · MG RMB`; },
      }),
      speakStep(g, 'COL. REYES', 'The gate holds! Counter-agent loaded. Skyline International is the last evac point — an Atlas airlifter is fuelled on the apron and there are six survivors in the terminal. My transport will drop you there.', 8),
      mk('Transport to Skyline International Airport', { init(g2) { const a = P.apron || P.atc || P.airport; g2.zm.respawn = a; g2.zm.serum += 2; g2.ui.fade(() => { const q = walkNear(g2, a.x, a.y, 60, 200); if (g2.player.heli) { const c = g2.player.heli; c.driver = null; g2.player.heli = null; g2.chopper = null; } teleportTo(g2, q.x, q.y); g2.toast('Arrived: Skyline International', '#4fe0ff'); this.arr = true; }, 700); this.arr = false; }, tick() { return this.arr; }, hidden: true }),
    ],
  }; }
  if (ch === 5) { const A = P.apron || P.atc || P.airport, T0 = P.atc || A; return {
    title: 'WINGS OF MERCY', intro: 'Skyline International · Midnight', start: () => A, hour: 23.5,
    steps: [
      speakStep(g, 'PILOT DANA REYES', 'Rook! Atlas is on the apron, engines warm. Six survivors are holed up near the terminal — get them to the plane. The runway is crawling, so keep your head down.', 7),
      rescueStep('Escort 6 survivors from the terminal to the Atlas airlifter', 6, () => T0, (g2) => { const sp = g2.world.aircraftSpots.filter((s) => s.kind === 'atlas').sort((a, b) => hyp(a.x - A.x, a.y - A.y) - hyp(b.x - A.x, b.y - A.y)); const s = sp[0] || A; return { x: s.x, y: s.y }; }, 220, { set: 1 }),
      mk('PATIENT ZERO is on the runway — put him down', {
        init(g2) { const q = walkNear(g2, A.x, A.y, 520, 700); const b = spawnZombie(g2, 'tyrant', q.x, q.y, { chase: g2.player }); this.b = b; g2.zm.bossDead = false; g2.zm.boss = b; g2.zm.heat = 1; g2.audio.sfx('zroar', q.x, q.y, 1); say2(g2, 'PILOT DANA REYES', 'That thing is… the first infected! It’s coming for the plane! Tank, rifle, anything — kill it!', 6); },
        tick(g2) { return g2.zm.bossDead || (this.b && !this.b.on); }, marker() { return this.b && this.b.on && !this.b.dead ? this.b : null; }, prog() { return this.b ? `Patient Zero: ${Math.max(0, Math.round(this.b.hp / this.b.max * 100))}%` : ''; },
      }),
      mk('Board the Atlas airlifter', {
        init(g2) { g2.zm.heat = 0.5; const sp = g2.world.aircraftSpots.filter((s) => s.kind === 'atlas').sort((a, b) => hyp(a.x - g2.player.x, a.y - g2.player.y) - hyp(b.x - g2.player.x, b.y - g2.player.y)); this.s = sp[0] || A; },
        tick(g2) { const h = g2.player.heli; return !!(h && h.def.plane); }, marker() { return this.s; },
      }),
      mk('Take off! Hold W for throttle, then hold Space after rotate speed', { init(g2) { say2(g2, 'PILOT DANA REYES', 'Throttle up, point down the runway, rotate at 230 and climb. Keep her steady — we’re carrying everyone.', 6); this.s = null; }, tick(g2) { const h = g2.player.heli; return !!(h && h.alt > 0.3); }, prog(g2) { const h = g2.player.heli; return h ? `speed ${Math.round(h.sp)} · altitude ${Math.round(h.alt * 100)}%` : 'Board a plane'; } }),
      mk('Fly to the evacuation carrier — follow the marker', {
        init(g2) { const h = g2.player.heli, a = h ? h.a : 0; this.pos = { x: g2.player.x + Math.cos(a) * 6500, y: g2.player.y + Math.sin(a) * 6500 }; this.pt = 0; },
        tick(g2) { const h = g2.player.heli; if (h && h.alt > 0.15 && hyp(h.x - this.pos.x, h.y - this.pos.y) < 450) return true; if (!h && g2.time - (this.pt || 0) > 10) { this.pt = g2.time; g2.toast('Get back in the Atlas!', '#ff9a3c'); } return false; },
        marker() { return this.pos; }, prog(g2) { const h = g2.player.heli; return h ? `${Math.round(hyp(h.x - this.pos.x, h.y - this.pos.y) / 32)} tiles to go` : ''; },
      }),
    ],
    end: true,
  }; }
  return { title: 'ENDLESS OUTBREAK', intro: 'Survive.', start: () => P.start, hour: 19, steps: [], endless: true };
}
function teleportTo(g, x, y) {
  if (g.scene) { for (const a of g.actors) if (a !== g.player && a.on && a.inside === g.scene.id) a.on = false; g.scene = null; g.insideId = null; g.player.inside = null; }
  const p = g.player; if (p.veh) { p.veh.driver = null; p.veh = null; } p.x = p.px = x; p.y = p.py = y; p.vx = p.vy = 0; g.cam.x = g.cam.px = x; g.cam.y = g.cam.py = y;
  for (const a of g.actors) if (a.on && a !== p && !a.mis && hyp(a.x - x, a.y - y) > 700) a.on = false;
}
function startChapter(g, ch) {
  const S = g.zm; S.ch = ch; const C = chapter(g, ch); S.C = C; S.steps = C.steps; S.si = 0; S.cur = null; S.items = []; S.rafts = null; S.defend = null; S.markers = []; S.rings = []; S.heat = 0.2; S.stepKills = 0; S.surv = [];
  const e = g.env; if (C.hour != null && ch !== 4 && ch !== 5) e.hour = C.hour; else if (C.hour != null) e.hour = C.hour;
  if (C.storm) { e.weather = 'storm'; e.rainT = 1; e.fogT = 0.3; e.windT = 0.9; } else { e.weather = 'fog'; e.rainT = 0; e.fogT = 0.32; e.windT = 0.15; }
  e.wtimer = 1e9;
  try { localStorage.setItem('nt_zm', JSON.stringify({ ch: Math.min(ch, 5), max: Math.max(ch, S.maxCh || 0), kills: S.kills, saved: S.saved })); S.maxCh = Math.max(ch, S.maxCh || 0); } catch (err) { /* ignore */ }
  S.banner = { t: 5, title: `CHAPTER ${ch + 1} — ${C.title}`, sub: C.intro };
  const sp = C.start(); S.respawn = S.respawn || sp;
  if (S.placed) { /* player already there */ }
}
function advance(g) {
  const S = g.zm; if (S.cur && S.cur.onEnd) S.cur.onEnd(g);
  S.si++; S.cur = null; S.markers = []; S.rings = [];
  if (S.si >= S.steps.length) {
    if (S.C.end) return epilogue(g);
    if (S.C.endless) return; g.audio.sfx('complete'); startChapter(g, S.ch + 1); const C = S.C; if (S.ch >= 1 && S.ch !== 3 && S.ch !== 4 && S.ch !== 5) { /* same region */ }
  }
}
function epilogue(g) {
  const S = g.zm; S.ended = true; S.paused = false; g.audio.sfx('complete'); showCard(g, `<h1 style="color:#7cff4f">THE SKY IS CLEAR</h1><p>The Atlas climbs through the smoke with ${S.saved + 6} souls aboard. Behind you Port Meridian burns, but somewhere ahead there is a carrier, a cure, and a chance.</p><p style="opacity:.8">Infected put down: <b>${S.kills}</b> · Survivors saved: <b>${S.saved}</b> · Deaths: <b>${S.deaths}</b></p><p><b>OUTBREAK SURVIVED.</b> Keep playing in Endless Outbreak, or return to the menu.</p><div class="zb"><button data-z="endless">Continue — endless outbreak</button><button data-z="menu">Main menu</button></div>`, (a) => { if (a === 'endless') { hideCard(); S.steps = []; S.C = { endless: true, title: 'ENDLESS OUTBREAK', steps: [] }; S.ch = 5; S.cur = null; S.si = 0; S.endless = true; S.heat = 1.2; g.toast('Endless outbreak — the horde never ends', '#9bd36a'); } else { hideCard(); g.toMenu(); } });
}

// ======================================================= per-tick
function begin(g, ch) {
  const w = g.world, p = g.player;
  ZM.on = true;
  g.zm = { ch, kills: 0, stepKills: 0, saved: 0, lost: 0, turned: 0, risen: 0, sheltered: 0, civDead: 0, deaths: 0, followed: 0, inf: 0, serum: 0, lastBite: -99, noise: 0, safe: null, respawn: null, items: [], markers: [], rings: [], radio: [], rad: null, banner: null, heat: 0.2, fireT: 3, evT: 50, pathBudget: 4, atT: 0, maxCh: 0, hudT: 0, flick: 0, ambT: 8, strike: [], paused: false, endless: false };
  try { const sv = JSON.parse(localStorage.getItem('nt_zm') || 'null'); if (sv) g.zm.maxCh = sv.max || 0; } catch (err) { /* ignore */ }
  g.zm.kills = 0; g.inv.have.bat = true; g.giveWeapon('bat', 0); g.giveWeapon('pistol', 36); g.switchWeapon('pistol'); g.cash = 0;
  for (const a of g.actors) if (a !== p) a.on = false; for (const v of g.vehicles) v.on = false; g.pickups = []; g.fires = [];
  const C0 = chapter(g, ch); const sp = C0.start(); const q = walkNear(g, sp.x, sp.y, 30, 120);
  p.x = p.px = q.x; p.y = p.py = q.y; p.hp = p.max = 100; p.armor = ch >= 1 ? 60 : 0; g.cam.x = g.cam.px = p.x; g.cam.y = g.cam.py = p.y; g.wanted.stars = 0; g.wanted.heat = 0;
  if (ch >= 1) { g.giveWeapon('rifle', 120); g.giveWeapon('shotgun', 24); g.zm.serum = 2; }
  makeHud(g); g.zm.respawn = null; startChapter(g, ch); g.zm.respawn = g.zm.respawn || sp;
  g.toast('☣ ZOMBIE OUTBREAK — everyone is a target. Stay alive.', '#9bd36a');
  seed(g);
}
function seed(g) {
  const p = g.player; for (let i = 0; i < 9; i++) { const s = spot(g, 420, 800); if (s) spawnZombie(g, 'walker', s.x, s.y, { chase: chance(0.3) ? p : null }); }
  for (let i = 0; i < 6; i++) { const s = spot(g, 400, 800); if (s) { const a = spawnActor(g, 'civ', s.x, s.y, { fac: 'civ', w: 'fists' }); if (a) { a.st = chance(0.6) ? 'zflee' : 'idle'; a.calm = 4; a.home = g.world.randomDoor(s.x, s.y, 0, 900) || undefined; } } }
  const s = spot(g, 450, 750); if (s) COPS(g, s.x, s.y, 3);
}
function end(g) {
  if (!g.zm) return; ZM.on = false; g.zm = null; const h = document.getElementById('zhud'); if (h) h.remove(); const f = document.getElementById('zfx'); if (f) f.remove(); hideCard();
  for (const a of g.actors) if (a !== g.player && a.on && (a.fac === 'zom' || a.surv)) a.on = false;
  g.env.weather = 'clear'; g.env.fogT = 0; g.env.rainT = 0; g.env.wtimer = 60; g.cheats.god = false;
}
function step(g, dt) {
  const S = g.zm; if (!S) return; const p = g.player, e = g.env, inp = g.input;
  S.pathBudget = 4; S.hudT -= dt; S.noise = Math.max(0, S.noise - dt * 0.15);
  // environment: sickly light, failing power grid, distant chaos
  e.fogT = Math.max(e.fogT, S.C && S.C.storm ? 0.3 : 0.3); e.wtimer = 1e9;
  const am = e.amb; e.amb = [Math.round(am[0] * 0.82), Math.round(am[1] * 0.97), Math.round(am[2] * 0.8)];
  e.tint = [e.tint[0] * 0.5, e.tint[1] + 14, e.tint[2] * 0.6];
  S.flick -= dt; if (S.flick <= 0) { S.flick = rnd(0.05, 4); S.flickOn = Math.random() < 0.3; }
  const grid = 1 - 0.55 * clamp(S.ch / 5, 0, 1) - (S.flickOn && Math.sin(g.time * 40) > 0 ? 0.5 : 0); e.lamp = clamp((e.lamp || 0), 0, 1) * clamp(grid, 0.12, 1); if (g.settings.lamps === 'on') e.lamp = Math.max(e.lamp, 0.6);
  S.ambT -= dt; if (S.ambT <= 0 && !g.scene) { S.ambT = rnd(6, 14); const a = Math.random() * TAU, d = rnd(500, 1100); g.audio.sfx(pick(['pistol', 'rifle', 'zscream', 'explosion', 'caralarm', 'zgroan', 'smg']), p.x + Math.cos(a) * d, p.y + Math.sin(a) * d, 0.5); }
  // noise → player gunfire builds noise level
  if (g.lastViolence > 20) S.noise = Math.min(1, S.noise + dt * 0.5);
  // events
  if (!S.endless || true) { S.evT -= dt; if (S.evT <= 0 && !g.scene && !S.paused) { S.evT = rnd(45, 80); randomEvent(g); } }
  for (const s of S.strike) { s.t -= dt; if (s.t <= 0 && !s.done) { s.done = true; explode(g, s.x, s.y, 130, 220, { by: null, fac: 'pd' }, true); g.noise(s.x, s.y, 1200, { by: null }); } } S.strike = S.strike.filter((s) => !s.done);
  // safe zone: cure & heal
  const sz = S.safe, inSafe = sz && !g.scene && hyp(p.x - sz.x, p.y - sz.y) < sz.r; S.inSafe = !!inSafe;
  if (inSafe && !p.dead) { S.inf = Math.max(0, S.inf - 7 * dt); p.hp = Math.min(p.max, p.hp + 3 * dt); }
  else if (S.inf > 0) { if (S.inf >= 45) S.inf = Math.min(100, S.inf + 0.4 * dt); else S.inf = Math.max(0, S.inf - 0.7 * dt); }
  if (S.inf > 60 && !p.dead && !g.cheats.god && p.hp > 5) p.hp -= (S.inf - 60) / 40 * 1.6 * dt;
  if ((inp.pr.has('KeyT') || (S.inf > 85 && g.input.touch)) && S.serum > 0 && S.inf > 3 && !p.dead) { S.serum--; S.inf = 0; p.hp = Math.min(p.max, p.hp + 35); g.toast('Antiserum injected — infection purged', '#7cff4f'); g.audio.sfx('levelup'); g.parts.burst(P.RING, p.x, p.y, 3, 10, 0.6, 24, '#9bd36a'); }
  else if (inp.pr.has('KeyT') && S.serum <= 0) { g.toast('No antiserum left', '#ff7788'); }
  if (S.inf >= 100 && !p.dead && !g.cheats.god) { S.inf = 0; S.deaths++; damageActor(g, p, 9999, { kind: 'infection' }); if (g.deathCard) g.deathCard.text = 'The infection took you…'; }
  if (p.dead && !S.wasDead) { S.wasDead = true; S.deaths++; } if (!p.dead) { if (S.wasDead) { S.inf = 0; } S.wasDead = false; }
  // vials (collectibles)
  for (let i = S.items.length - 1; i >= 0; i--) { const it = S.items[i]; if (!g.scene && hyp(it.x - p.x, it.y - p.y) < 28) { S.items.splice(i, 1); g.audio.sfx('pickup'); if (it.type === 'supply') { g.toast('Supply crate: ammo, medkits and antiserum!', '#ffd24a'); for (const w of ['pistol', 'smg', 'shotgun', 'rifle']) if (g.inv.have[w]) g.giveWeapon(w, 30); g.inv.have.rifle || g.giveWeapon('rifle', 60); S.serum += chance(0.6) ? 1 : 0; p.hp = p.max; p.armor = Math.max(p.armor, 60); S.evMark = null; S.noise = 1; g.noise(it.x, it.y, 700, { by: null }); } else { g.toast('Viral sample secured', '#7cff4f'); if (S.cur && S.cur.onItem) S.cur.onItem(g); } } }
  // story
  if (!S.ended && S.steps) {
    if (!S.cur && S.si < S.steps.length) { S.cur = S.steps[S.si]; S.cur.init && S.cur.init(g); S.cur.t = 0; S.hudT = 0; if (!S.cur.hidden) g.audio.sfx('ui'); }
    const c = S.cur; if (c) { c.t += dt; let done = c.done; if (!done && c.tick) done = c.tick(g, dt); if (done) { if (!c.hidden) { g.toast('✔ ' + (c.text || 'Objective complete'), '#7cff4f'); g.audio.sfx('complete'); } advance(g); } }
    if (S.si >= S.steps.length && S.C && S.C.endless && !S.endlessMsg) { S.endlessMsg = true; }
  }
  S.markers = []; S.rings = []; const c = S.cur;
  if (c) { const ms = []; if (c.marker) { const m = c.marker(g); if (m) ms.push({ x: m.x, y: m.y, label: c.text }); } if (c.markers) for (const m of c.markers(g)) ms.push(m); for (const m of ms) S.markers.push({ x: m.x, y: m.y, kind: 'obj', color: '#9bff6a', label: m.label || '' }); if (c.ring) { const rp = c.ringAt ? c.ringAt(g) : c.pos; if (rp) S.rings.push({ x: rp.x, y: rp.y, r: c.ring, col: '#9bff6a' }); } }
  // radio
  if (S.rad) { S.rad.t -= dt; if (S.rad.t <= 0) S.rad = null; } if (!S.rad && S.radio.length) { const r = S.radio.shift(); S.rad = { who: r.who, text: r.text, t: r.dur, t0: g.time }; g.audio.sfx('beep'); }
  if (S.banner) { S.banner.t -= dt; if (S.banner.t <= 0) S.banner = null; }
  hud(g, dt);
}
function randomEvent(g) {
  const S = g.zm, p = g.player; const kinds = ['horde', 'survivors', 'laststand', 'supply']; if (S.ch >= 2) kinds.push('strike'); const k = pick(kinds);
  if (k === 'horde') { horde(g, 14 + S.ch * 3); }
  else if (k === 'supply') {
    const s = spot(g, 300, 600); if (!s) return; g.toast('📦 Supply drop inbound — marked on your map. The noise will draw the dead!', '#ffd24a'); g.audio.sfx('beep');
    const box = { type: 'supply', x: s.x, y: s.y }; S.items.push(box); g.noise(s.x, s.y, 900, { by: null }); for (let i = 0; i < 6; i++) { const q = walkNear(g, s.x, s.y, 200, 360); spawnZombie(g, 'walker', q.x, q.y, { chase: s }); }
    S.evMark = { x: s.x, y: s.y, t: 120, label: 'Supply drop' };
  } else if (k === 'laststand') {
    const s = spot(g, 380, 700); if (!s) return; g.toast('📻 Officers pinned down nearby — help them!', '#4fb0ff'); const soldier = S.ch >= 3;
    COPS(g, s.x, s.y, 4, { soldier, keep: true, w: soldier ? 'rifle' : undefined }); for (let i = 0; i < 12 + S.ch * 2; i++) { const q = walkNear(g, s.x, s.y, 160, 300); spawnZombie(g, chance(0.15) ? 'runner' : 'walker', q.x, q.y, { chase: s }); }
    S.evMark = { x: s.x, y: s.y, t: 100, label: 'Squad under attack', ls: true };
  } else if (k === 'survivors') {
    const s = spot(g, 380, 700); if (!s) return; g.toast('🆘 Civilians are being chased — save them!', '#7cff4f');
    for (let i = 0; i < 3; i++) { const a = spawnActor(g, 'civ', s.x + rnd(-30, 30), s.y + rnd(-30, 30), { fac: 'civ', w: 'fists' }); if (a) { a.st = 'zflee'; a.calm = 6; } } for (let i = 0; i < 6; i++) { const q = walkNear(g, s.x, s.y, 120, 240); spawnZombie(g, chance(0.3) ? 'runner' : 'walker', q.x, q.y, { chase: s }); }
    S.evMark = { x: s.x, y: s.y, t: 60, label: 'Civilians in trouble' };
  } else if (k === 'strike') {
    let best = null, bn = 0; for (const a of g.actors) if (a.on && !a.dead && a.fac === 'zom' && hyp(a.x - p.x, a.y - p.y) < 800 && hyp(a.x - p.x, a.y - p.y) > 220) { let n = 0; for (const b of g.actors) if (b.on && !b.dead && b.fac === 'zom' && hyp(a.x - b.x, a.y - b.y) < 110) n++; if (n > bn) { bn = n; best = a; } }
    if (best && bn >= 4) { g.toast('🚀 Artillery barrage incoming — keep clear of the marked zone!', '#ff9a3c'); for (let i = 0; i < 6; i++) S.strike.push({ x: best.x + rnd(-90, 90), y: best.y + rnd(-90, 90), t: 3 + i * 0.5, w: 3 }); }
  }
}
function evUpdate(g, dt) { const S = g.zm, m = S.evMark; if (!m) return; m.t -= dt; const p = g.player; if (m.ls) { let cops = 0, zs = 0; for (const a of g.actors) if (a.on && !a.dead && hyp(a.x - m.x, a.y - m.y) < 380) { if (a.fac === 'pd') cops++; else if (a.fac === 'zom') zs++; } if (zs <= 2 && cops > 0 && hyp(p.x - m.x, p.y - m.y) < 700) { S.evMark = null; g.toast('Squad saved! They hand you supplies.', '#7cff4f'); g.pickups.push({ type: 'ammo', x: m.x, y: m.y, v: 1, life: 90 }, { type: 'heal', v: 50, x: m.x + 14, y: m.y, life: 90 }, { type: 'armor', v: 40, x: m.x - 14, y: m.y, life: 90 }); g.cash += 150; g.audio.sfx('cash'); S.saved += 0; if (chance(0.5)) g.pickups.push({ type: 'heal', serum: true, x: m.x, y: m.y + 14, life: 120 }); return; } } if (m.t <= 0) S.evMark = null; }

// ======================================================= HUD / drawing
function injectCss(g) {
  const st = document.createElement('style'); st.textContent = `
#zhud{position:fixed;inset:0;pointer-events:none;z-index:30;font-family:system-ui,Segoe UI,sans-serif;color:#e8f5e0}
#zhud .obj{position:absolute;left:14px;top:14px;max-width:min(380px,56vw);background:linear-gradient(180deg,rgba(8,18,10,.78),rgba(8,14,10,.6));border:1px solid rgba(155,255,106,.35);border-left:4px solid #9bff6a;border-radius:10px;padding:9px 12px;backdrop-filter:blur(3px)}
#zhud .obj small{display:block;letter-spacing:.14em;font-size:10px;color:#9bd36a;opacity:.9}
#zhud .obj b{display:block;font-size:14px;margin:2px 0}
#zhud .obj i{display:block;font-style:normal;font-size:12px;color:#c8f0b0;opacity:.85}
#zhud .bars{position:absolute;left:14px;bottom:14px;display:flex;flex-direction:column;gap:5px;width:210px;background:rgba(8,12,10,.62);border-radius:10px;padding:8px 10px;border:1px solid rgba(255,255,255,.12);font-size:11px}
#zhud .bar{height:7px;background:rgba(255,255,255,.14);border-radius:5px;overflow:hidden}#zhud .bar u{display:block;height:100%;text-decoration:none;transition:width .2s}
#zhud .row{display:flex;justify-content:space-between;gap:8px;opacity:.95}
#zhud .stat{position:absolute;right:14px;top:14px;background:rgba(8,12,10,.6);border:1px solid rgba(255,255,255,.12);border-radius:10px;padding:7px 11px;font-size:11px;line-height:1.5;text-align:right}
#zhud .rad{position:absolute;left:50%;bottom:92px;transform:translateX(-50%);max-width:min(620px,86vw);background:rgba(6,10,14,.82);border:1px solid rgba(120,200,255,.4);border-radius:10px;padding:8px 14px;font-size:13px;display:none}
#zhud .rad em{display:block;font-style:normal;font-size:10px;letter-spacing:.14em;color:#7fd0ff;margin-bottom:2px}
#zhud .ban{position:absolute;left:0;right:0;top:30%;text-align:center;opacity:0;transition:opacity .8s;text-shadow:0 0 18px #3c8a2a,0 2px 4px #000}
#zhud .ban h1{margin:0;font-size:clamp(26px,5vw,54px);letter-spacing:.2em;color:#b8ff8a}#zhud .ban p{margin:6px 0 0;letter-spacing:.3em;font-size:12px;opacity:.85}
#zhud .zone{position:absolute;top:14px;left:50%;transform:translateX(-50%);padding:4px 14px;border-radius:20px;background:rgba(40,120,50,.55);border:1px solid #9bff6a;font-size:11px;letter-spacing:.2em;display:none}
#zfx{position:fixed;inset:0;pointer-events:none;z-index:29;transition:opacity .3s}
#zcard{position:fixed;inset:0;z-index:60;background:radial-gradient(ellipse at center,rgba(10,26,12,.88),rgba(2,6,3,.96));display:flex;align-items:center;justify-content:center;color:#e8f5e0;font-family:system-ui,sans-serif}
#zcard .in{max-width:640px;padding:28px 34px;text-align:center;border:1px solid rgba(155,255,106,.35);border-radius:14px;background:rgba(8,16,10,.7);max-height:92vh;overflow:auto}
#zcard h1{letter-spacing:.18em;margin:0 0 10px}#zcard p{line-height:1.55;font-size:14px}
.zb{display:flex;flex-direction:column;gap:8px;margin-top:14px}.zb button{background:#16301c;color:#c9ffb0;border:1px solid #6fcf4a;border-radius:8px;padding:10px 14px;font-size:14px;cursor:pointer;letter-spacing:.06em}.zb button:hover{background:#235a2c}.zb .row2{display:flex;gap:6px;flex-wrap:wrap;justify-content:center}.zb .row2 button{font-size:12px;padding:6px 10px}`;
  document.head.appendChild(st); void g;
}
function showCard(g, html, cb) { hideCard(); const d = document.createElement('div'); d.id = 'zcard'; d.innerHTML = `<div class="in">${html}</div>`; (g.root || document.body).appendChild(d); d.addEventListener('click', (e) => { const a = e.target.dataset && e.target.dataset.z; if (!a) return; g.audio.init(); g.audio.resume(); g.audio.sfx('ui'); cb(a, e.target.dataset); }); g.uiOpen = true; d._g = g; }
function hideCard() { const d = document.getElementById('zcard'); if (d) { if (d._g) d._g.uiOpen = false; d.remove(); } }
function menu(g) {
  let sv = null; try { sv = JSON.parse(localStorage.getItem('nt_zm') || 'null'); } catch (e) { /* ignore */ }
  const max = sv ? sv.max || 0 : 0;
  showCard(g, `<h1 style="color:#b8ff8a">☣ DEAD TIDE</h1><p style="opacity:.7;letter-spacing:.2em;font-size:11px">THE MERIDIAN OUTBREAK</p>
  <p>Patient Zero walked out of Meridian General at 18:40. By nightfall the dead own Port Meridian. They don’t care who you are — <b>they eat everyone</b>: civilians, cops, soldiers, you. The police fight back, civilians run for cover, the bitten turn, noise draws hordes, the power grid is dying and the city burns.</p>
  <p style="font-size:12px;opacity:.8">Six chapters: the streets · the police line · the hospital lab · the stormy bay (boats) · Fort Granite (tanks) · the airport escape (heavy aircraft). Then endless survival.<br>Bitten? Fever climbs until you reach a <b>safe zone</b> or inject <b>antiserum [T]</b>.</p>
  <div class="zb"><button data-z="new">Begin the outbreak — Chapter 1</button>${sv && max > 0 ? `<div class="row2">${Array.from({ length: Math.min(6, max + 1) }, (_, i) => `<button data-z="ch" data-ch="${i}">Ch ${i + 1}: ${CHAPTER_TITLES[i]}</button>`).join('')}</div>` : ''}<button data-z="back">← Back</button></div>`,
  (a, d) => { if (a === 'new') { hideCard(); g.startZombie(0); } else if (a === 'ch') { hideCard(); g.startZombie(+d.ch); } else { hideCard(); g.ui.showMenu(); } });
}
function makeHud(g) {
  let h = document.getElementById('zhud'); if (h) h.remove(); h = document.createElement('div'); h.id = 'zhud';
  h.innerHTML = `<div class="obj"><small id="zch"></small><b id="zob"></b><i id="zpr"></i></div><div class="zone" id="zzone">SAFE ZONE</div><div class="stat" id="zst"></div>
  <div class="bars"><div class="row"><span>☣ INFECTION</span><span id="zinf">0%</span></div><div class="bar"><u id="zib" style="background:#9bff6a;width:0"></u></div><div class="row"><span>NOISE</span><span>antiserum <b id="zser">0</b> [T]</span></div><div class="bar"><u id="znb" style="background:#ffb347;width:0"></u></div></div>
  <div class="rad" id="zrad"><em id="zwho"></em><span id="ztxt"></span></div><div class="ban" id="zban"><h1></h1><p></p></div>`;
  (g.root || document.body).appendChild(h);
  let f = document.getElementById('zfx'); if (f) f.remove(); f = document.createElement('div'); f.id = 'zfx'; (g.root || document.body).appendChild(f);
}
function hud(g, dt) {
  const S = g.zm, h = document.getElementById('zhud'); if (!h) return; const q = (id) => document.getElementById(id), p = g.player;
  h.style.display = g.state === 'play' ? 'block' : 'none'; evUpdate(g, dt);
  if (S.hudT <= 0) {
    S.hudT = 0.2; const c = S.cur;
    q('zch').textContent = S.C ? `CHAPTER ${Math.min(6, S.ch + 1)} · ${S.C.title}` : ''; q('zob').textContent = c && !c.hidden ? c.text : c ? '…' : S.endless ? 'Survive the endless outbreak' : '';
    q('zpr').textContent = c && c.prog && !c.hidden ? c.prog(g) : S.evMark ? '◉ ' + S.evMark.label : '';
    q('zst').innerHTML = `☠ ${S.kills} down · 🧍 ${S.saved} saved · 💀 ${S.deaths}<br>${g.env.dark > 0.55 ? '🌙 night — runners roam' : '🌆 dusk'} · threat ${'▮'.repeat(Math.min(6, 1 + Math.round(S.heat * 2 + S.ch * 0.6)))}`;
    q('zinf').textContent = Math.round(S.inf) + '%'; q('zser').textContent = S.serum; q('zzone').style.display = S.inSafe ? 'block' : 'none';
  }
  q('zib').style.width = Math.min(100, S.inf) + '%'; q('zib').style.background = S.inf > 60 ? '#ff5a4a' : S.inf > 30 ? '#ffd24a' : '#9bff6a'; q('znb').style.width = S.noise * 100 + '%';
  const r = q('zrad'); if (S.rad) { r.style.display = 'block'; q('zwho').textContent = S.rad.who; const n = Math.floor((g.time - S.rad.t0) * 55); q('ztxt').textContent = S.rad.text.slice(0, n); } else r.style.display = 'none';
  const b = q('zban'); if (S.banner) { b.style.opacity = S.banner.t > 0.9 && S.banner.t < 4.3 ? 1 : 0; b.firstChild.textContent = S.banner.title; b.lastChild.textContent = S.banner.sub.toUpperCase(); } else b.style.opacity = 0;
  const f = q('zfx'); if (f) { const inf = S.inf / 100, hurt = g.fx.hurt, pulse = 0.5 + 0.5 * Math.sin(g.time * (2 + inf * 6)); f.style.background = `radial-gradient(ellipse at center, rgba(0,0,0,0) ${55 - inf * 25}%, rgba(${Math.round(90 + 120 * inf)},${Math.round(30 - 20 * inf)},20,${0.25 + inf * 0.4 * pulse + hurt * 0.5}) 100%), radial-gradient(ellipse at center, rgba(70,120,50,0) 40%, rgba(40,90,40,.22) 100%)`; }
  void p;
}
function decor(g, c, a, x, y, ang) {
  const t = g.time;
  if (a.fac === 'zom' && !a.dead) {
    const sz = a.zd ? a.zd.sz : 1, ca = Math.cos(ang), sa = Math.sin(ang), er = 5.5 * sz;
    c.fillStyle = a.z === 'tyrant' ? '#ff3030' : '#ff2a1a'; c.shadowColor = '#f00'; c.shadowBlur = 6; for (const s of [-1, 1]) { c.beginPath(); c.arc(x + ca * er - sa * s * 2 * sz, y + sa * er + ca * s * 2 * sz, 1.05 * Math.min(1.6, sz), 0, TAU); c.fill(); } c.shadowBlur = 0;
    if (a.z === 'boomer') { c.fillStyle = 'rgba(170,190,60,.35)'; c.beginPath(); c.arc(x, y, 12 + Math.sin(t * 5 + a.i) * 1.5, 0, TAU); c.fill(); }
    if (a.z === 'spitter') { c.fillStyle = 'rgba(155,255,90,.5)'; c.beginPath(); c.arc(x + ca * 8, y + sa * 8, 2.6, 0, TAU); c.fill(); }
    if (a.z === 'tyrant' && a.charge > 0) { c.strokeStyle = 'rgba(255,60,40,.5)'; c.lineWidth = 3; c.beginPath(); c.arc(x, y, 26, 0, TAU); c.stroke(); }
    if ((a.z === 'brute' || a.z === 'tyrant') && a.hp < a.max) { const w = a.z === 'tyrant' ? 60 : 30; c.fillStyle = 'rgba(0,0,0,.6)'; c.fillRect(x - w / 2, y - 26 * sz, w, 4); c.fillStyle = '#ff4a3a'; c.fillRect(x - w / 2, y - 26 * sz, w * Math.max(0, a.hp / a.max), 4); }
  }
  if (a.inf && !a.dead) { c.fillStyle = `rgba(120,200,70,${0.2 + 0.15 * Math.sin(t * 8)})`; c.beginPath(); c.arc(x, y, 11, 0, TAU); c.fill(); c.strokeStyle = 'rgba(150,255,90,.6)'; c.lineWidth = 1.2; c.beginPath(); c.arc(x, y, 12, 0, TAU); c.stroke(); }
  if (a.surv && a.surv !== 'safe' && !a.dead) { const bob = Math.sin(t * 4 + a.i) * 2; c.fillStyle = a.surv === 'wait' ? '#ffd24a' : '#7cff4f'; c.beginPath(); c.moveTo(x, y - 20 + bob); c.lineTo(x + 5, y - 28 + bob); c.lineTo(x - 5, y - 28 + bob); c.closePath(); c.fill(); if (a.surv === 'wait') { c.strokeStyle = 'rgba(255,210,74,.5)'; c.lineWidth = 1.5; c.beginPath(); c.arc(x, y, 14 + Math.sin(t * 3) * 3, 0, TAU); c.stroke(); } }
  if (a.say && !a.dead) { c.font = 'bold 10px sans-serif'; c.textAlign = 'center'; const w = c.measureText(a.say.text).width + 8; c.fillStyle = 'rgba(0,0,0,.65)'; c.fillRect(x - w / 2, y - 40, w, 14); c.fillStyle = a.fac === 'pd' ? '#9fd0ff' : a.inf ? '#9bff6a' : '#fff'; c.fillText(a.say.text, x, y - 30); }
  if (a.fac === 'pd' && a.ally && !a.dead) { c.fillStyle = '#4fb0ff'; c.beginPath(); c.moveTo(x, y - 18); c.lineTo(x + 4, y - 24); c.lineTo(x - 4, y - 24); c.fill(); }
}
function drawWorld(g, c, x0, y0, x1, y1) {
  const S = g.zm, t = g.time;
  const sz = S.safe; if (sz && sz.x > x0 - sz.r && sz.x < x1 + sz.r && sz.y > y0 - sz.r && sz.y < y1 + sz.r) {
    c.save(); c.strokeStyle = 'rgba(120,255,110,.55)'; c.lineWidth = 3; c.setLineDash([18, 12]); c.lineDashOffset = -t * 20; c.beginPath(); c.arc(sz.x, sz.y, sz.r, 0, TAU); c.stroke(); c.setLineDash([]); c.fillStyle = 'rgba(80,220,90,.06)'; c.beginPath(); c.arc(sz.x, sz.y, sz.r, 0, TAU); c.fill(); c.font = 'bold 13px sans-serif'; c.textAlign = 'center'; c.fillStyle = 'rgba(160,255,140,.8)'; c.fillText('☣ SAFE ZONE · ' + sz.name, sz.x, sz.y - sz.r + 18); c.restore();
  }
  for (const r of S.rings) { c.save(); c.strokeStyle = r.col; c.globalAlpha = 0.5 + 0.3 * Math.sin(t * 4); c.lineWidth = 3; c.beginPath(); c.arc(r.x, r.y, r.r, 0, TAU); c.stroke(); c.restore(); }
  for (const it of S.items) {
    if (it.x < x0 - 30 || it.x > x1 + 30 || it.y < y0 - 30 || it.y > y1 + 30) continue; const bob = Math.sin(t * 3 + it.x) * 2;
    if (it.type === 'vial') { c.save(); c.translate(it.x, it.y + bob); c.shadowColor = '#7cff4f'; c.shadowBlur = 16; c.fillStyle = 'rgba(170,255,120,.9)'; c.beginPath(); c.roundRect(-3.5, -9, 7, 16, 3); c.fill(); c.fillStyle = '#ddd'; c.fillRect(-4.5, -11, 9, 3); c.restore(); }
    else { c.save(); c.translate(it.x, it.y); c.fillStyle = 'rgba(255,210,60,.18)'; c.fillRect(-3, -200, 6, 200); c.fillStyle = '#6b5a2a'; c.fillRect(-11, -9 + bob, 22, 18); c.strokeStyle = '#ffd24a'; c.lineWidth = 2; c.strokeRect(-11, -9 + bob, 22, 18); c.fillStyle = '#ffd24a'; c.fillRect(-2, -9 + bob, 4, 18); c.restore(); }
  }
  if (S.rafts) for (const r of S.rafts) { if (r.got || r.x < x0 - 60 || r.x > x1 + 60 || r.y < y0 - 60 || r.y > y1 + 60) continue; c.save(); c.translate(r.x, r.y); c.rotate(Math.sin(t * 1.3 + r.x) * 0.1); c.fillStyle = '#e8742a'; c.beginPath(); c.ellipse(0, 0, 22, 15, 0, 0, TAU); c.fill(); c.fillStyle = '#3a4a5a'; c.beginPath(); c.ellipse(0, 0, 14, 8, 0, 0, TAU); c.fill(); c.fillStyle = '#e9c9a0'; c.beginPath(); c.arc(0, 0, 4, 0, TAU); c.fill(); c.strokeStyle = '#e9c9a0'; c.lineWidth = 2; c.beginPath(); c.moveTo(2, -2); c.lineTo(8, -10 + Math.sin(t * 8) * 4); c.stroke(); c.strokeStyle = 'rgba(255,255,255,.4)'; c.lineWidth = 1.5; c.beginPath(); c.arc(0, 0, 26 + Math.sin(t * 3) * 3, 0, TAU); c.stroke(); c.restore(); }
  for (const s of S.strike) { c.save(); c.strokeStyle = `rgba(255,70,40,${0.5 + 0.4 * Math.sin(t * 14)})`; c.lineWidth = 3; c.beginPath(); c.arc(s.x, s.y, 130, 0, TAU); c.stroke(); c.fillStyle = 'rgba(255,60,30,.12)'; c.fill(); c.restore(); }
  if (S.evMark) { const m = S.evMark; c.save(); c.strokeStyle = m.ls ? 'rgba(80,170,255,.6)' : 'rgba(255,210,70,.6)'; c.lineWidth = 2; c.setLineDash([8, 8]); c.beginPath(); c.arc(m.x, m.y, 60 + Math.sin(t * 3) * 5, 0, TAU); c.stroke(); c.restore(); }
}
