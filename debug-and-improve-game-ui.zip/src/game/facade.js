// ===== facade.js — paints a building genome (see genome.js) onto the building sprite: wall material, window grammar, details, roof forms =====
import { shade } from './util.js';
import { stream, GENOME_KINDS } from './genome.js';

export const hasGenome = (b) => !!b.g && GENOME_KINDS.has(b.kind) && b.kind !== 'mountain';
const rr = (c, x, y, w, h, r) => { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); };
const lines = (c, col, a, lw, fn) => { c.strokeStyle = col; c.globalAlpha = a; c.lineWidth = lw; c.beginPath(); fn(); c.stroke(); c.globalAlpha = 1; };

/** wall material texture on the south face (y0 .. y0+H) */
function material(c, g, b, w, y0, H, r) {
  const col = b.color, dark = 'rgba(0,0,0,', light = 'rgba(255,255,255,';
  switch (g.f) {
    case 'brick': lines(c, '#000', 0.2, 1, () => { for (let y = 4; y < H; y += 4) { c.moveTo(0, y0 + y); c.lineTo(w, y0 + y); } for (let y = 0, k = 0; y < H; y += 4, k++) for (let x = (k % 2) * 5; x < w; x += 10) { c.moveTo(x, y0 + y); c.lineTo(x, y0 + y + 4); } }); break;
    case 'stucco': for (let i = 0, n = (w * H) / 70; i < n; i++) { c.fillStyle = r() < 0.5 ? dark + '.07)' : light + '.07)'; c.fillRect(r() * w, y0 + r() * H, 2 + r() * 3, 2); } break;
    case 'glass': { const gr = c.createLinearGradient(0, y0, w, y0 + H); gr.addColorStop(0, light + '.28)'); gr.addColorStop(0.45, light + '.02)'); gr.addColorStop(1, dark + '.18)'); c.fillStyle = gr; c.fillRect(0, y0, w, H); lines(c, g.trim, 0.35, 1, () => { for (let x = 0; x < w; x += 10) { c.moveTo(x, y0); c.lineTo(x, y0 + H); } for (let y = 6; y < H; y += 9) { c.moveTo(0, y0 + y); c.lineTo(w, y0 + y); } }); break; }
    case 'concrete': lines(c, '#000', 0.16, 1, () => { for (let x = 24; x < w; x += 24) { c.moveTo(x, y0); c.lineTo(x, y0 + H); } for (let y = 18; y < H; y += 18) { c.moveTo(0, y0 + y); c.lineTo(w, y0 + y); } }); break;
    case 'panel': for (let y = 0, k = 0; y < H; y += 8, k++) { c.fillStyle = k % 2 ? dark + '.1)' : light + '.07)'; c.fillRect(0, y0 + y, w, 8); } break;
    case 'stone': lines(c, '#000', 0.22, 1, () => { for (let y = 7, k = 0; y < H; y += 7, k++) { c.moveTo(0, y0 + y); c.lineTo(w, y0 + y); for (let x = (k % 2) * 7; x < w; x += 14) { c.moveTo(x, y0 + y - 7); c.lineTo(x, y0 + y); } } }); break;
    case 'wood': lines(c, '#000', 0.25, 1, () => { for (let x = 5; x < w; x += 5) { c.moveTo(x, y0); c.lineTo(x, y0 + H); } }); for (let i = 0; i < w / 6; i++) { c.fillStyle = light + '.06)'; c.fillRect(r() * w, y0 + r() * H, 1, 6 + r() * 10); } break;
    case 'mosaic': for (let y = 0; y < H; y += 4) for (let x = 0; x < w; x += 4) { const v = r(); if (v < 0.4) { c.fillStyle = v < 0.2 ? dark + '.12)' : light + '.1)'; c.fillRect(x, y0 + y, 4, 4); } } break;
    case 'metal': for (let x = 0; x < w; x += 4) { c.fillStyle = (x / 4) % 2 ? dark + '.14)' : light + '.1)'; c.fillRect(x, y0, 2, H); } break;
    case 'adobe': for (let i = 0, n = (w * H) / 160; i < n; i++) { c.fillStyle = r() < 0.5 ? dark + '.06)' : light + '.08)'; c.beginPath(); c.ellipse(r() * w, y0 + r() * H, 5 + r() * 9, 3 + r() * 5, 0, 0, 6.3); c.fill(); } break;
    case 'deco': for (let x = 8; x < w; x += 16) { c.fillStyle = light + '.14)'; c.fillRect(x, y0, 3, H); c.fillStyle = dark + '.14)'; c.fillRect(x + 3, y0, 1, H); } lines(c, g.trim, 0.7, 1.5, () => { c.moveTo(0, y0 + 3); c.lineTo(w, y0 + 3); }); break;
    case 'shingle': lines(c, '#000', 0.2, 1, () => { for (let y = 4, k = 0; y < H; y += 4, k++) for (let x = (k % 2) * 3; x < w; x += 6) { c.moveTo(x, y0 + y); c.arc(x + 3, y0 + y, 3, Math.PI, 0, true); } }); break;
    default: break;
  }
  void col;
}

function windowShape(c, gl, g, st, x, y, cw, ch, lit, warm) {
  const glass = '#25384a', hl = 'rgba(140,190,220,.25)';
  const body = (ww, hh, shapeFn) => { c.fillStyle = g.wear > 0.7 ? '#202e3b' : glass; shapeFn(); c.fill(); };
  const glow = (shapeFn) => { if (!lit) return; gl.globalAlpha = 0.85; gl.fillStyle = warm; shapeFn(gl); gl.fill(); gl.globalAlpha = 1; };
  switch (st) {
    case 'tall': c.fillStyle = g.trim; c.globalAlpha = g.cornice ? 0.9 : 0.35; c.fillRect(x - 1, y - 1, 8, 13); c.globalAlpha = 1; body(0, 0, () => { c.beginPath(); c.rect(x, y, 6, 11); }); c.fillStyle = hl; c.fillRect(x, y, 6, 3); glow((q) => { q.beginPath(); q.rect(x, y, 6, 11); }); break;
    case 'arch': body(0, 0, () => { c.beginPath(); c.moveTo(x, y + 11); c.lineTo(x, y + 4); c.arc(x + 3.5, y + 4, 3.5, Math.PI, 0); c.lineTo(x + 7, y + 11); c.closePath(); }); c.strokeStyle = g.trim; c.lineWidth = 1; c.stroke(); glow((q) => { q.beginPath(); q.moveTo(x, y + 11); q.lineTo(x, y + 4); q.arc(x + 3.5, y + 4, 3.5, Math.PI, 0); q.lineTo(x + 7, y + 11); q.closePath(); }); break;
    case 'round': body(0, 0, () => { c.beginPath(); c.arc(x + 4, y + 4, 4.2, 0, 6.3); }); c.strokeStyle = g.trim; c.lineWidth = 1.4; c.stroke(); glow((q) => { q.beginPath(); q.arc(x + 4, y + 4, 4.2, 0, 6.3); }); break;
    case 'slit': body(0, 0, () => { c.beginPath(); c.rect(x + 2, y - 1, 3, 11); }); glow((q) => { q.beginPath(); q.rect(x + 2, y - 1, 3, 11); }); break;
    case 'bay': c.fillStyle = g.trim; c.fillRect(x - 2, y - 1, 14, 12); body(0, 0, () => { c.beginPath(); c.rect(x - 1, y, 12, 9); }); c.fillStyle = hl; c.fillRect(x - 1, y, 12, 3); c.fillStyle = 'rgba(0,0,0,.4)'; c.fillRect(x - 2, y + 11, 14, 1.5); c.fillStyle = g.trim; c.fillRect(x + 4.5, y, 1, 9); glow((q) => { q.beginPath(); q.rect(x - 1, y, 12, 9); }); break;
    case 'shutter': body(0, 0, () => { c.beginPath(); c.rect(x, y, 7, 9); }); c.fillStyle = g.accent; c.fillRect(x - 3, y, 3, 9); c.fillRect(x + 7, y, 3, 9); c.fillStyle = 'rgba(0,0,0,.25)'; for (let k = 1; k < 9; k += 2) { c.fillRect(x - 3, y + k, 3, 0.8); c.fillRect(x + 7, y + k, 3, 0.8); } glow((q) => { q.beginPath(); q.rect(x, y, 7, 9); }); break;
    case 'cross': body(0, 0, () => { c.beginPath(); c.rect(x, y, 8, 9); }); c.strokeStyle = g.trim; c.lineWidth = 1; c.beginPath(); c.moveTo(x + 4, y); c.lineTo(x + 4, y + 9); c.moveTo(x, y + 4.5); c.lineTo(x + 8, y + 4.5); c.stroke(); glow((q) => { q.beginPath(); q.rect(x, y, 8, 9); }); break;
    default: body(0, 0, () => { c.beginPath(); c.rect(x, y, 8, 8); }); c.fillStyle = hl; c.fillRect(x, y, 8, 3); glow((q) => { q.beginPath(); q.rect(x, y, 8, 8); }); break;
  }
}

/** wall + windows + details; returns nothing (the caller then draws door / sign) */
export function paintFacade(c, gl, b, w, h, H, rndSeed) {
  const g = b.g, r = stream(rndSeed, 11, w, H), y0 = h;
  material(c, g, b, w, y0, H, r);
  const st = g.w, warm = r() < 0.8 ? '#ffd98a' : '#9fe3ff';
  const stepX = { tall: 12, arch: 13, round: 12, slit: 8, bay: 20, shutter: 18, cross: 13, grid: 14, band: 14, blind: 26 }[st] || 14;
  const stepY = st === 'band' ? 12 : st === 'round' ? 12 : st === 'tall' || st === 'arch' ? 15 : st === 'bay' ? 16 : 12;
  const cols = Math.max(1, Math.floor((w - 8) / stepX)), rows = Math.max(1, Math.floor((H - 10) / stepY)), dx = (w - cols * stepX) / 2 + 2;
  const doorCol = (x) => b.door && Math.abs(x + 4 - w / 2) < 15;
  if (st === 'band') { // continuous ribbon windows
    for (let k = 0; k < rows; k++) { const y = y0 + 4 + k * stepY; if (b.door && k === rows - 1) continue; c.fillStyle = '#243649'; c.fillRect(4, y, w - 8, 6); c.fillStyle = 'rgba(140,190,220,.28)'; c.fillRect(4, y, w - 8, 2); c.fillStyle = g.trim; c.globalAlpha = 0.5; for (let x = 4; x < w - 4; x += 16) c.fillRect(x, y, 1, 6); c.globalAlpha = 1; for (let x = 6; x < w - 10; x += 16) if (r() < g.lit) { gl.globalAlpha = 0.8; gl.fillStyle = r() < 0.8 ? '#ffd98a' : '#9fe3ff'; gl.fillRect(x, y, 14, 6); gl.globalAlpha = 1; } }
  } else if (st !== 'blind' || H > 24) {
    for (let k = 0; k < rows; k++) for (let i = 0; i < cols; i++) {
      const x = dx + i * stepX, y = y0 + 4 + k * stepY; if (b.door && k === rows - 1 && doorCol(x)) continue;
      if (st === 'blind' && r() < 0.6) continue;
      windowShape(c, gl, g, st, x, y, stepX, stepY, r() < g.lit, warm);
      if (g.balc && k > 0 && (i + k) % 2 === 0 && st !== 'band') { c.fillStyle = 'rgba(0,0,0,.45)'; c.fillRect(x - 3, y + stepY - 3, 14, 2); c.strokeStyle = g.trim; c.globalAlpha = 0.7; c.lineWidth = 0.8; c.beginPath(); for (let q = 0; q < 5; q++) { c.moveTo(x - 3 + q * 3.4, y + stepY - 7); c.lineTo(x - 3 + q * 3.4, y + stepY - 3); } c.stroke(); c.globalAlpha = 1; }
    }
  }
  // wear: rain streaks, grime at the base
  if (g.wear > 0.35) { c.fillStyle = 'rgba(20,16,10,.10)'; for (let i = 0, n = Math.floor(g.wear * w / 9); i < n; i++) c.fillRect(r() * w, y0 + r() * H * 0.4, 2 + r() * 2, H * (0.3 + r() * 0.7)); const gr = c.createLinearGradient(0, y0 + H - 12, 0, y0 + H); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, `rgba(0,0,0,${0.12 + g.wear * 0.25})`); c.fillStyle = gr; c.fillRect(0, y0 + H - 12, w, 12); }
  if (g.graf) { const col = ['#ff4fd8', '#2fd0ff', '#ffe14a', '#7cff4f'][Math.floor(r() * 4)]; c.strokeStyle = col; c.globalAlpha = 0.8; c.lineWidth = 2; c.lineCap = 'round'; const gx = 6 + r() * (w - 40); c.beginPath(); c.moveTo(gx, y0 + H - 12); c.bezierCurveTo(gx + 8, y0 + H - 22, gx + 14, y0 + H - 4, gx + 26, y0 + H - 14); c.stroke(); c.globalAlpha = 1; }
  if (g.ac && H > 22) for (let i = 0; i < Math.min(3, g.ac); i++) { const x = 4 + r() * (w - 16), y = y0 + 8 + r() * (H - 26); c.fillStyle = '#9aa3ad'; c.fillRect(x, y, 9, 6); c.fillStyle = '#5b6168'; c.fillRect(x + 1, y + 1, 4, 4); c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(x, y + 6, 9, 1.5); }
  if (g.plants) { for (let i = 0, n = Math.floor(w / 18); i < n; i++) { const x = 6 + r() * (w - 12); if (b.door && Math.abs(x - w / 2) < 14) continue; c.fillStyle = '#2f6b3a'; c.beginPath(); c.arc(x, y0 + H - 3, 3.2 + r() * 2, 0, 6.3); c.fill(); c.fillStyle = r() < 0.4 ? '#ff6f91' : '#4f9a52'; c.beginPath(); c.arc(x + 1, y0 + H - 5, 1.6, 0, 6.3); c.fill(); } }
  if (g.cornice) { c.fillStyle = g.trim; c.globalAlpha = 0.85; c.fillRect(0, y0, w, 3); c.globalAlpha = 1; c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(0, y0 + 3, w, 1.5); }
  // shop awning
  if (b.kind === 'shop' && g.awn && b.door && H >= 16) { const ax = (b.w >> 1) * 32 + 16, aw = Math.min(w - 8, 54), ay = y0 + H - Math.min(H - 2, 22) - 3; for (let i = 0; i < aw / 6; i++) { c.fillStyle = g.stripe && i % 2 ? '#f4f4f4' : g.accent; c.fillRect(ax - aw / 2 + i * 6, ay, 6, 7); } c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(ax - aw / 2, ay + 7, aw, 2); }
}

const ROOF_GREEN = ['#4d7a45', '#5a8a4a', '#42703d'];
/** roof forms drawn over the flat roof rectangle (0,0,w,h).  Flat roofs only get props. */
export function paintRoof(c, gl, b, w, h, rndSeed) {
  const g = b.g, r = stream(rndSeed, 23, w, h), base = b.roof || shade(b.color, 0.14), dk = shade(b.color, -0.5);
  const keep = b.interior === 'hospital' || b.interior === 'police' || b.kind === 'civic' && g.r === 'flat';
  const horiz = w >= h, ox = 2, oy = 2, ww = w - 4, hh = h - 4;
  const form = keep ? 'flat' : g.r;
  const shadeP = (col, f) => shade(col, f);
  const poly = (pts, col) => { c.fillStyle = col; c.beginPath(); c.moveTo(pts[0], pts[1]); for (let i = 2; i < pts.length; i += 2) c.lineTo(pts[i], pts[i + 1]); c.closePath(); c.fill(); };
  const roofBase = b.roof && b.roof[0] === '#' ? b.roof : '#7a6a60';
  if (form === 'gable') {
    c.fillStyle = shadeP(roofBase, 0.1); c.fillRect(ox, oy, ww, hh);
    if (horiz) { c.fillStyle = shadeP(roofBase, -0.28); c.fillRect(ox, oy + hh / 2, ww, hh / 2); lines(c, '#000', 0.17, 1, () => { for (let y = oy + 5; y < oy + hh; y += 5) { c.moveTo(ox, y); c.lineTo(ox + ww, y); } }); lines(c, '#fff', 0.5, 1.6, () => { c.moveTo(ox, oy + hh / 2); c.lineTo(ox + ww, oy + hh / 2); }); }
    else { c.fillStyle = shadeP(roofBase, -0.28); c.fillRect(ox + ww / 2, oy, ww / 2, hh); lines(c, '#000', 0.17, 1, () => { for (let x = ox + 5; x < ox + ww; x += 5) { c.moveTo(x, oy); c.lineTo(x, oy + hh); } }); lines(c, '#fff', 0.5, 1.6, () => { c.moveTo(ox + ww / 2, oy); c.lineTo(ox + ww / 2, oy + hh); }); }
    if (r() < 0.6) { c.fillStyle = '#4b4038'; const cx = ox + 8 + r() * (ww - 20), cy = oy + 6 + r() * (hh - 18); c.fillRect(cx, cy, 7, 9); c.fillStyle = '#1a1512'; c.fillRect(cx + 1.5, cy + 1.5, 4, 4); }
  } else if (form === 'hip' || form === 'pyramid') {
    const k = form === 'pyramid' ? 0.5 : Math.min(0.38, 18 / Math.max(ww, hh) + 0.2), rx0 = ox + ww * (horiz ? k : 0.5), rx1 = ox + ww * (horiz ? 1 - k : 0.5), ry0 = oy + hh * (horiz ? 0.5 : k), ry1 = oy + hh * (horiz ? 0.5 : 1 - k);
    poly([ox, oy, ox + ww, oy, rx1, ry0, rx0, ry0], shadeP(roofBase, 0.16)); poly([ox + ww, oy, ox + ww, oy + hh, rx1, ry1, rx1, ry0], shadeP(roofBase, -0.12)); poly([ox + ww, oy + hh, ox, oy + hh, rx0, ry1, rx1, ry1], shadeP(roofBase, -0.34)); poly([ox, oy + hh, ox, oy, rx0, ry0, rx0, ry1], shadeP(roofBase, 0.02));
    lines(c, '#fff', 0.35, 1.2, () => { c.moveTo(ox, oy); c.lineTo(rx0, ry0); c.moveTo(ox + ww, oy); c.lineTo(rx1, ry0); c.moveTo(ox + ww, oy + hh); c.lineTo(rx1, ry1); c.moveTo(ox, oy + hh); c.lineTo(rx0, ry1); c.moveTo(rx0, ry0); c.lineTo(rx1, ry0); c.lineTo(rx1, ry1); c.lineTo(rx0, ry1); c.closePath(); });
  } else if (form === 'saw') {
    for (let x = 0, k = 0; x < w; x += 14, k++) { c.fillStyle = shadeP(roofBase, 0.1); c.fillRect(x, 0, 9, h); c.fillStyle = 'rgba(150,210,235,.55)'; c.fillRect(x + 9, 2, 5, h - 4); c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(x + 8, 0, 1.5, h); }
  } else if (form === 'dome' && Math.min(ww, hh) >= 44) {
    const rad = Math.min(ww, hh) / 2 - 3, gr = c.createRadialGradient(w / 2 - rad * 0.3, h / 2 - rad * 0.3, rad * 0.1, w / 2, h / 2, rad); gr.addColorStop(0, shadeP(g.trim, 0.2)); gr.addColorStop(0.55, shadeP(roofBase, 0.05)); gr.addColorStop(1, shadeP(roofBase, -0.45));
    c.fillStyle = gr; c.beginPath(); c.arc(w / 2, h / 2, rad, 0, 6.3); c.fill(); lines(c, '#fff', 0.25, 1, () => { for (let k = 0; k < 8; k++) { c.moveTo(w / 2, h / 2); c.lineTo(w / 2 + Math.cos(k * 0.785) * rad, h / 2 + Math.sin(k * 0.785) * rad); } }); c.fillStyle = g.accent; c.beginPath(); c.arc(w / 2, h / 2, 4, 0, 6.3); c.fill();
  } else if (form === 'green') {
    c.fillStyle = ROOF_GREEN[Math.floor(r() * 3)]; c.fillRect(ox, oy, ww, hh); for (let i = 0, n = (ww * hh) / 60; i < n; i++) { c.fillStyle = r() < 0.5 ? 'rgba(20,60,20,.3)' : 'rgba(150,220,120,.25)'; c.beginPath(); c.arc(ox + r() * ww, oy + r() * hh, 2 + r() * 4, 0, 6.3); c.fill(); } c.strokeStyle = g.trim; c.lineWidth = 2; c.strokeRect(ox, oy, ww, hh);
    if (r() < 0.6) { c.fillStyle = '#c9b88a'; c.fillRect(ox + ww * 0.2, oy + hh * 0.4, ww * 0.6, 4); }
  } else if (form === 'solar') {
    c.fillStyle = shadeP(roofBase, 0.05); c.fillRect(ox, oy, ww, hh);
    for (let y = oy + 4; y < oy + hh - 8; y += 12) for (let x = ox + 4; x < ox + ww - 10; x += 14) { c.fillStyle = '#1f3a63'; c.fillRect(x, y, 12, 9); lines(c, '#9fc4ff', 0.5, 0.7, () => { c.moveTo(x + 4, y); c.lineTo(x + 4, y + 9); c.moveTo(x + 8, y); c.lineTo(x + 8, y + 9); c.moveTo(x, y + 4.5); c.lineTo(x + 12, y + 4.5); }); }
  } else if (form === 'barrel') {
    const n = horiz ? ww : hh; for (let k = 0; k < n; k += 3) { const t = k / n, v = Math.sin(t * Math.PI); c.fillStyle = shadeP(roofBase, -0.35 + v * 0.5); if (horiz) c.fillRect(ox + k, oy, 3, hh); else c.fillRect(ox, oy + k, ww, 3); }
  } else if (form === 'terrace') {
    let a = ox, bb = oy, cw = ww, ch = hh; for (let k = 0; k < 3 && cw > 22 && ch > 22; k++) { c.fillStyle = shadeP(roofBase, 0.05 + k * 0.1); c.fillRect(a, bb, cw, ch); c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 1.5; c.strokeRect(a, bb, cw, ch); a += 9; bb += 9; cw -= 18; ch -= 18; }
    for (let i = 0; i < 4; i++) { c.fillStyle = '#4f9a52'; c.beginPath(); c.arc(ox + 6 + r() * (ww - 12), oy + 6 + r() * (hh - 12), 3, 0, 6.3); c.fill(); }
  }
  // props on top of any roof form
  if (form === 'flat' || form === 'terrace' || form === 'saw' || form === 'green') {
    const area = ww * hh;
    if (form === 'flat' && !keep) { c.strokeStyle = shadeP(g.trim, -0.1); c.lineWidth = 2; c.strokeRect(2, 2, w - 4, h - 4);  }
    for (let i = 0; i < Math.min(4, g.ac) && area > 700; i++) { const x = 10 + r() * (w - 36), y = 10 + r() * (h - 30); c.fillStyle = '#aab2bb'; c.fillRect(x, y, 16, 12); c.fillStyle = '#6b737c'; c.beginPath(); c.arc(x + 8, y + 6, 4.5, 0, 6.3); c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(x + 4, y + 6); c.lineTo(x + 12, y + 6); c.moveTo(x + 8, y + 2); c.lineTo(x + 8, y + 10); c.stroke(); }
    if (g.tank && area > 1200) { const x = w * 0.7, y = h * 0.3; const gr = c.createRadialGradient(x - 3, y - 3, 1, x, y, 11); gr.addColorStop(0, '#c9a77c'); gr.addColorStop(1, '#6b4a2a'); c.fillStyle = gr; c.beginPath(); c.arc(x, y, 11, 0, 6.3); c.fill(); c.strokeStyle = '#3a2a1a'; c.lineWidth = 1; c.stroke(); }
    if (g.bill && w > 90) { c.fillStyle = '#16181d'; c.fillRect(w * 0.15, h - 14, w * 0.45, 8); c.fillStyle = g.accent; c.fillRect(w * 0.15 + 2, h - 12, w * 0.45 - 4, 4); }
  }
  if (g.ant && w * h > 1500) { const x = r() * (w - 20) + 10, y = r() * (h - 20) + 10; c.strokeStyle = '#555'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(x, y); c.lineTo(x + 3, y - 12); c.stroke(); c.fillStyle = '#ff3355'; c.beginPath(); c.arc(x + 3, y - 12, 1.8, 0, 6.3); c.fill(); gl.fillStyle = '#ff3355'; gl.globalAlpha = 0.7; gl.beginPath(); gl.arc(x + 3, y - 12, 3, 0, 6.3); gl.fill(); gl.globalAlpha = 1; }
  void rr; void dk;
}
