// ===== keys.js — collision-free integer keys for (x, y) cell coordinates =====
// A 2-D integer coordinate is packed into ONE safe-integer Number (< 2^52):  (x + OFF) * MUL + (y + OFF).
// |x|,|y| < 2^24 (16.7 M blocks ≈ 8.6 billion px each way) → no wrap-around / aliasing for negative or huge coordinates.
export const OFF = 1 << 24, MUL = 1 << 25;
export const bkey = (x, y) => (x + OFF) * MUL + (y + OFF);
export const unkeyX = (k) => Math.floor(k / MUL) - OFF;
export const unkeyY = (k) => (k % MUL) - OFF;
export const chunkKey = (cx, cy) => (cx + OFF) * MUL + (cy + OFF);
