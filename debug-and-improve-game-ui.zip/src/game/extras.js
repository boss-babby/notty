// ===== extras.js — v7 world dressing: new prop types, deterministic scatter rules and flyable-aircraft spots =====
// Everything here is a pure function of (seed, tile) so a refresh regenerates the identical dressing (no Math.random).
import { genFleet } from './fleetgen.js';
export const PLUS_PROPDEF = {
  radar: { r: 12, hp: 1e9, solid: 1 }, container: { r: 15, hp: 1e9, solid: 1 }, billboard: { r: 9, hp: 1e9, solid: 1 }, busstop: { r: 10, hp: 90, solid: 1, low: 1 },
  scarecrow: { r: 5, hp: 20, solid: 1 }, campfire: { r: 7, hp: 1e9, solid: 0 }, windpump: { r: 7, hp: 1e9, solid: 1 }, picnic: { r: 14, hp: 70, solid: 1, low: 1 },
};
export const PLUS_PSIZE = { radar: 60, container: 54, billboard: 64, busstop: 48, scarecrow: 36, campfire: 32, windpump: 52, picnic: 48 };
export const PLUS_ROT = ['container', 'billboard', 'busstop', 'picnic', 'radar'];

export function genExtras(W, K) {
  const { T, TS, NT, mulberry32 } = K, rng = mulberry32(((W.seed || 1337) * 2654435761 + 977) >>> 0), tiles = W.tiles, NT0 = 576;
  const tl = (tx, ty) => (tx < 0 || ty < 0 || tx >= NT || ty >= NT ? -1 : tiles[ty * NT + tx]);
  const roomy = (tx, ty) => { for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) { const t = tl(tx + i, ty + j); if (t === T.BUILDING || t === T.WATER || t < 0) return false; } return true; };
  const crowded = (x, y, r) => { const l = W.propHash.query(x, y, r, []); for (const p of l) if (!p.dead && p.t !== 'blocker' && Math.hypot(p.x - x, p.y - y) < r) return true; return false; };
  const stat = {};
  const put = (type, x, y, o) => { const tx = Math.floor(x / TS), ty = Math.floor(y / TS); if (!W.free(tx, ty) || !roomy(tx, ty) || crowded(x, y, 26)) return null; stat[type] = (stat[type] || 0) + 1; return W.addProp(type, x, y, o); };
  const spaced = new Set(); const spacedOk = (key, tx, ty, cell) => { const k = key + ':' + Math.floor(tx / cell) + ',' + Math.floor(ty / cell); if (spaced.has(k)) return false; spaced.add(k); return true; };
  const near = (tx, ty, t, r) => { for (let d = 1; d <= r; d++) for (const [dx, dy] of [[d, 0], [-d, 0], [0, d], [0, -d]]) if (tl(tx + dx, ty + dy) === t) return [dx, dy]; return null; };
  const sample = (n, f) => { for (let i = 0; i < n; i++) { const tx = 8 + Math.floor(rng() * (NT0 - 16)), ty = 8 + Math.floor(rng() * (NT0 - 16)); f(tx, ty, tl(tx, ty)); } };
  const reg = (tx, ty) => Math.floor(tx / 192) + Math.floor(ty / 192) * 3; // 0 PM · 1 SC · 2 FG · 3 SS · 4 AU · 5 SK · 6 PR · 7 AV · 8 BR
  const face = (dx, dy) => Math.atan2(dy, dx);

  // --- military radar domes beside the Fort Granite pads, airport radar by the tower
  for (const s of W.aircraftSpots || []) if (s.home === 'Fort Granite' && s.kind === 'reaper') { put('radar', s.x + 190, s.y - 40, { a: rng() * 6.28 }); put('radar', s.x - 150, s.y - 60, { a: rng() * 6.28 }); }
  if (W.pois.atc) for (const [dx, dy] of [[90, 10], [-90, 20], [30, 100]]) if (put('radar', W.pois.atc.x + dx, W.pois.atc.y + dy, { a: 0.5 })) break;
  // --- container yards at the docks and the air-cargo terminal
  for (const key of ['cranes', 'cargo']) { const p = W.pois[key]; if (!p) continue; for (let j = 0; j < 4; j++) for (let i = 0; i < 6; i++) { const ang = (i + j) % 3 === 0 ? 0 : Math.PI / 2; put('container', p.x + 70 + i * 44, p.y - 30 + j * 20 + (key === 'cargo' ? 60 : 0), { a: ang, v: Math.floor(rng() * 4) }); } }
  // --- roadside billboards (face the road), bus stops in the cities, farm scarecrows, camp fires, desert windpumps, picnic tables
  let nb = 0; sample(9000, (tx, ty, t) => { if (nb >= 70 || (t !== T.GRASS && t !== T.DESERT && t !== T.SAND && t !== T.DIRT && t !== T.TURF && t !== T.GRAVEL)) return; const r = near(tx, ty, T.ROAD, 3); if (!r || !spacedOk('bb', tx, ty, 22)) return; if (put('billboard', tx * TS + 16, ty * TS + 16, { a: face(r[0], r[1]) + Math.PI / 2, v: Math.floor(rng() * 4) })) nb++; });
  let ns = 0; sample(26000, (tx, ty, t) => { if (ns >= 110 || t !== T.SIDEWALK) return; const g = reg(tx, ty); if (g !== 0 && g !== 1 && g !== 4 && g !== 5) return; const r = near(tx, ty, T.ROAD, 1); if (!r || !spacedOk('bs', tx, ty, 11)) return; if (put('busstop', tx * TS + 16, ty * TS + 16, { a: face(r[0], r[1]) + Math.PI / 2, v: Math.floor(rng() * 3) })) ns++; });
  let nf = 0; sample(14000, (tx, ty, t) => { if (nf >= 60 || t !== T.FARM || !spacedOk('sc', tx, ty, 7)) return; if (put('scarecrow', tx * TS + 16, ty * TS + 16, { a: rng() * 6.28 })) nf++; });
  let nc = 0; sample(14000, (tx, ty, t) => { if (nc >= 16 || reg(tx, ty) !== 6 || (t !== T.FOREST && t !== T.GRASS) || !spacedOk('cf', tx, ty, 16)) return; if (put('campfire', tx * TS + 16, ty * TS + 16, { v: Math.floor(rng() * 4) })) nc++; });
  let nw = 0; sample(14000, (tx, ty, t) => { if (nw >= 30 || reg(tx, ty) !== 3 || t !== T.DESERT || !spacedOk('wp', tx, ty, 13)) return; if (put('windpump', tx * TS + 16, ty * TS + 16, { a: rng() * 6.28 })) nw++; });
  let np = 0; sample(16000, (tx, ty, t) => { if (np >= 50 || t !== T.GRASS || !near(tx, ty, T.PATH, 2) || !spacedOk('pt', tx, ty, 14)) return; if (put('picnic', tx * TS + 16, ty * TS + 16, { a: rng() < 0.5 ? 0 : Math.PI / 2 })) np++; });

  // --- flyable aircraft: apron planes on the Skyline runway (west end, nose east), the crop-duster strip at Ambrose, plus the existing helicopter pads
  const A = (W.aircraftSpots || (W.aircraftSpots = [])), air = (kind, tx, ty, a, home, col) => A.push({ kind, x: tx * TS, y: ty * TS, a, home, col });
  air('sparrow', 402, 217.6, 0, 'Skyline Runway 09'); air('sparrow', 402, 220.4, 0, 'Skyline Runway 09', '#e8453c');
  air('falcon', 411, 217.6, 0, 'Skyline Runway 09', '#8a929a'); air('falcon', 411, 220.4, 0, 'Skyline Runway 09', '#3c4a5c'); air('cropmaster', 420, 219, 0, 'Skyline Runway 09');
  air('cropmaster', 204, 426.5, 0, 'Ambrose Airstrip'); air('sparrow', 213, 426.5, 0, 'Ambrose Airstrip', '#2f7bd9');
  try { genFleet(W, K); } catch (err) { console.warn('fleet', err); }
  W.extraStats = stat;
}
