// ===== ui.js — HUD, minimap, map, menus, phone, shops, settings, mini-games (DOM overlay) =====
import { WEAPONS, WEAPON_ORDER, SHOP_ITEMS, PROPERTIES, BUYABLE, VEHICLES, SKINS, HAIR_COLORS, SHIRTS, PANTS, HAIR_STYLES, SKILLS, SKILL_XP, ABILITIES, GANGS, MISSIONS, STATIONS, ADS, DJ_LINES, DISTRICT_NAMES, TIPS, THEFT_LIST, TITLE } from './data.js';
import { ACTIONS } from './input.js';
import { drawPreview } from './gfx.js';
import { missionAvailable, startSide } from './missions.js';
import { fmtMoney, fmtTime, clamp, pick } from './util.js';
import { TS, NT, NB } from './world.js';
import { mountMap } from './worldmap.js';
import { bkey } from './keys.js';
import { extendUI, touchText } from './ui2.js';

const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const MAP_POIS = { safe: ['⌂', 'Safehouse'], gus: ['🔧', "Gus's Garage"], bank: ['$', 'Meridian Savings'], police: ['★', 'Police HQ'], hosp: ['+', 'Hospital'], gun: ['⚔', 'Gun Den'], clothes: ['👕', 'Threads'], casino: ['♦', 'Casino'], arena: ['✊', 'The Pit'], nina: ['✎', 'Ledger Tower'], viper: ['☠', 'The Rusted Eel'], pier: ['⚓', 'Sunset Pier'], hotel: ['🏨', 'Sunset Hotel'], light: ['⚑', 'Lighthouse'], p_club: ['♪', 'Club Tide'], p_wh: ['▣', 'Warehouse'], p_apt: ['⌂', 'Apartments'], p_shop: ['🍜', 'Lucky Noodle'], cranes: ['⚒', 'The Cranes'], park: ['♣', 'Central Park'], raceStart: ['⚑', 'Street Race'], kess: ['!', 'Kessler Freight'] };
const PAINTS = ['#d50000', '#ff6d00', '#ffd600', '#00c853', '#00b8d4', '#2962ff', '#aa00ff', '#f5f5f5', '#212121', '#795548', '#ff4081', '#78909c'];

export function createUI(g) {
  const root = g.root; const U = { stack: [], endingOpen: false, hot: null };
  g.uiOpen = false;
  root.insertAdjacentHTML('beforeend', `
  <div id="ui">
    <div id="hud">
      <div class="hud-tl"><canvas id="mm"></canvas><div id="loc"></div><div id="clock"></div></div>
      <div class="hud-tr"><div id="cash"></div><div id="stars"></div><div id="evade"><i></i></div></div>
      <div class="hud-bl"><div class="bar hp"><i></i><span></span></div><div class="bar ar"><i></i></div><div class="bar st"><i></i></div><div class="bar sf" title="Tidal Focus (F)"><i></i></div></div>
      <div class="hud-br"><div id="weapon"></div><div id="veh"></div><div id="radio"></div></div>
      <div id="obj"></div><div id="boss"></div><div id="toasts"></div><div id="prompt"></div><div id="tut"></div><div id="banter"></div>
      <div id="cards"></div><div id="dbg"></div>
    </div>
    <div id="cut"><div class="lb top"></div><div class="lb bot"></div><div class="dlg"><b></b><p></p><small>E / Click — continue</small></div></div>
    <div id="hotwire"><h3>HOTWIRING…</h3><div class="hw-keys"></div><div class="hw-bar"><i></i></div></div>
    <div id="wheel"></div>
    <div id="fade"></div>
    <div id="photoui">PHOTO MODE — WASD move · wheel zoom · 1-4 filters · Enter capture · Esc exit</div>
  </div>`);
  const hud = $('#hud'), mm = $('#mm'), mctx = mm.getContext('2d');
  const q = (s) => $(s, root);
  const cache = {};
  const set = (k, el, v, html) => { if (cache[k] !== v) { cache[k] = v; if (html) el.innerHTML = v; else el.textContent = v; } };

  g.toast = (text, color = '#fff') => {
    const t = document.createElement('div'); t.className = 'toast'; t.textContent = text; t.style.borderColor = color; t.style.color = color; q('#toasts').appendChild(t);
    while (q('#toasts').children.length > 5) q('#toasts').firstChild.remove();
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 500); }, 3200);
  };
  U.fade = (cb, ms = 260) => { if (g.fading) return; g.fading = true; const f = q('#fade'); f.style.opacity = 1; setTimeout(() => { try { cb(); } catch (e) { console.error(e); } f.style.opacity = 0; g.fading = false; }, ms); };

  // ---------- modal helper ----------
  function modal(title, body, o = {}) {
    const back = document.createElement('div'); back.className = 'modal-back';
    back.innerHTML = `<div class="modal ${o.wide ? 'wide' : ''}"><div class="mh"><h2>${title}</h2><button class="x" data-x>✕</button></div><div class="mb">${body}</div></div>`;
    q('#ui').appendChild(back); const m = { el: back, onClose: o.onClose, noEsc: o.noEsc };
    U.stack.push(m); g.uiOpen = true; g.audio.sfx('ui');
    back.addEventListener('click', (e) => { if (e.target.hasAttribute && e.target.hasAttribute('data-x')) U.close(); });
    return back;
  }
  U.close = () => { const m = U.stack.pop(); if (!m) return; m.el.remove(); if (m.onClose) m.onClose(); g.uiOpen = U.stack.length > 0; g.audio.sfx('click'); };
  U.closeAll = () => { while (U.stack.length) U.close(); };
  U.escape = () => { if (g.state === 'photo') { g.exitPhoto(); return true; } if (U.stack.length) { const t = U.stack[U.stack.length - 1]; if (!t.noEsc) U.close(); return true; } return false; };

  // ---------- main menu / loading ----------
  U.loading = (p, text) => {
    let l = q('#loading'); if (!l) { root.insertAdjacentHTML('beforeend', `<div id="loading"><h1>${TITLE}</h1><div class="lbar"><i></i></div><p id="ltext"></p><p id="ltip"></p></div>`); l = q('#loading'); $('#ltip', l).textContent = 'TIP: ' + pick(TIPS); }
    $('.lbar i', l).style.width = Math.round(p * 100) + '%'; $('#ltext', l).textContent = text; if (p >= 1) setTimeout(() => l.remove(), 250);
  };
  U.showMenu = () => {
    g.state = 'menu'; U.closeAll(); hud.style.display = 'none'; const has = !!localStorage.getItem('nt_save');
    let m = q('#menu'); if (m) m.remove();
    root.insertAdjacentHTML('beforeend', `<div id="menu"><div class="logo"><span>NEON</span><span class="b">TIDE</span></div><div class="tag">PORT MERIDIAN · 1986 · RAIN FALLS ON EVERYONE</div>
      <div class="mbtns">${has ? '<button data-a="continue">Continue</button>' : ''}<button data-a="new">New Game</button><button data-a="zombie" style="border-color:#7cff4f;color:#b6ff9a">☣ Zombie Outbreak</button><button data-a="settings">Settings</button><button data-a="controls">Controls</button><button data-a="about">How to Play</button></div>
      <div class="seedrow" style="margin-top:14px;font-size:13px;color:#9fb0d0">World seed <input id="seed" type="text" size="10" value="${g.world.seed}" style="width:110px"> <button data-a="rseed" title="random seed">🎲</button> <span style="opacity:.7">— seeds the procedural Frontier &amp; scatter on New Game</span></div>
      <div class="foot">WASD move · Mouse aim/fire · E interact · F3 debug · \` cheats</div></div>`);
    q('#menu').addEventListener('click', (e) => { const a = e.target.dataset && e.target.dataset.a; if (!a) return; g.audio.init(); g.audio.resume(); g.audio.sfx('ui');
      if (a === 'zombie') { q('#menu').remove(); g.zmMenu(); } else if (a === 'continue') { q('#menu').remove(); g.loadGame(); } else if (a === 'rseed') { q('#seed').value = String(1 + Math.floor(Math.random() * 999999)); } else if (a === 'new') { g.pendingSeed = q('#seed') ? q('#seed').value.trim() : ''; q('#menu').remove(); U.openWardrobe(0, true); } else if (a === 'settings') U.openSettings(); else if (a === 'controls') U.openSettings(true); else if (a === 'about') U.openHelp(); });
  };
  U.openHelp = () => modal('How to Play', `<div class="help"><p><b>Move</b> WASD · <b>Sprint</b> Shift · <b>Roll</b> V · <b>Vault</b> Space · <b>Cover</b> C</p><p><b>Aim</b> Mouse (hold Right Click to scope) · <b>Fire</b> Left Click · <b>Reload</b> R · <b>Weapon wheel</b> hold Q / mouse wheel</p>
    <p><b>Interact / enter car / doors</b> E (hold on a parked car to hotwire) · <b>Horn</b> H · <b>Handbrake</b> Space · <b>Radio</b> X · <b>Siren</b> G</p><p><b>Sniper</b> hold Right Click: magnifying scope follows your cursor, mouse wheel zooms. <b>Street lights</b> L (auto / on / off). <b>Helicopter</b> (cheat menu) E board · WASD fly · Space climb · Shift descend · land to exit; gunship: LMB minigun, RMB rockets. <b>Tidal Focus</b> F — slow time. Fill the Style meter with drifts, near-misses, headshots and kills.</p>
    <p><b>Phone</b> Tab (jobs, news, properties) · <b>Map</b> M (click to set a waypoint) · <b>Pause</b> Esc · <b>Debug</b> F3 · <b>Cheats</b> backquote · <b>Photo mode</b> from the pause menu.</p><p>Gamepad: sticks move/aim, RT fire, A interact, B roll, X reload, Y focus, LB/RB weapons.</p></div>`);

  // ---------- settings ----------
  U.openSettings = (controls) => {
    const s = g.settings, a = g.audio.vol;
    const body = `<div class="set">
      <h4>Graphics</h4><label>Quality <select data-s="quality">${['low', 'medium', 'high'].map((x) => `<option ${s.quality === x ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
      <label>Street lights <select data-s="lamps">${[['auto', 'Auto (dusk → dawn)'], ['on', 'Always on'], ['off', 'Always off']].map(([v, n]) => `<option value="${v}" ${s.lamps === v ? 'selected' : ''}>${n}</option>`).join('')}</select> <small style="opacity:.6">(key L)</small></label><label>Light glow &amp; evening grade <input type="range" min="0" max="1.5" step="0.1" value="${s.glow === undefined ? 1 : s.glow}" data-s="glow"></label>
      <label><input type="checkbox" data-s="bloom" ${s.bloom ? 'checked' : ''}> Bloom glow</label><label><input type="checkbox" data-s="crt" ${s.crt ? 'checked' : ''}> CRT scanlines</label><label><input type="checkbox" data-s="aberration" ${s.aberration ? 'checked' : ''}> Chromatic aberration on damage</label><label><input type="checkbox" data-s="rotMap" ${s.rotMap ? 'checked' : ''}> Rotating minimap</label>
      <h4>Audio</h4>${['master', 'music', 'sfx'].map((k) => `<label>${k} <input type="range" min="0" max="1" step="0.05" value="${a[k]}" data-v="${k}"></label>`).join('')}
      <h4>Touch &amp; mobile</h4><label>Touch control size <input type="range" min="0.8" max="1.3" step="0.05" value="${s.touchScale || 1}" data-s="touchScale"></label>
      <label>Portrait layout <select data-s="dock">${[['auto', 'Docked controls (scene stays clear)'], ['off', 'Full-screen overlay']].map(([v, n]) => `<option value="${v}" ${s.dock === v ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <label><input type="checkbox" data-s="autoAim" ${s.autoAim !== false ? 'checked' : ''}> Aim assist for the FIRE button</label><label><input type="checkbox" data-s="autoQuality" ${s.autoQuality !== false ? 'checked' : ''}> Auto-lower graphics if the frame rate drops</label>
      <h4>Accessibility</h4><label>Colour-blind mode <select data-s="colorblind">${['off', 'protanopia', 'deuteranopia', 'tritanopia'].map((x) => `<option ${s.colorblind === x ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
      <label><input type="checkbox" data-s="shake" ${s.shake ? 'checked' : ''}> Screen shake</label><label><input type="checkbox" data-s="flashes" ${s.flashes ? 'checked' : ''}> Lightning flashes</label><label>HUD scale <input type="range" min="0.8" max="1.4" step="0.1" value="${s.hud}" data-s="hud"></label>
      <h4>Controls <button data-reset>Reset</button></h4><div class="binds">${ACTIONS.map(([k, n]) => `<div class="bind"><span>${n}</span><button data-bind="${k}">${g.input.bind[k].map((c) => c.replace('Key', '').replace('Mouse0', 'LMB').replace('Mouse2', 'RMB').replace('Arrow', '↑'.slice(0, 0))).join(' / ')}</button></div>`).join('')}</div></div>`;
    const m = modal('Settings', body, { wide: true });
    m.addEventListener('input', (e) => { const t = e.target; if (t.dataset.s) { const v = t.type === 'checkbox' ? t.checked : t.type === 'range' ? +t.value : t.value; s[t.dataset.s] = v; g.applySettings(); if (g.refreshEnv && (t.dataset.s === 'lamps' || t.dataset.s === 'glow')) g.refreshEnv(); } if (t.dataset.v) g.audio.setVol(t.dataset.v, +t.value); });
    m.addEventListener('change', (e) => { if (e.target.dataset.s || e.target.dataset.v) g.saveSettings(); });
    m.addEventListener('click', (e) => {
      const b = e.target.dataset;
      if (b.bind) { g.input.rebinding = b.bind; e.target.textContent = 'press a key…'; g.input.onRebind = () => { g.input.onRebind = null; U.close(); U.openSettings(); }; }
      if ('reset' in b) { g.input.resetBinds(); U.close(); U.openSettings(); }
    });
    if (controls) setTimeout(() => $('.binds', m).scrollIntoView(), 0);
  };

  // ---------- pause / stats ----------
  U.openPause = () => {
    const m = modal('PAUSED', `<div class="mbtns col"><button data-a="resume">Resume</button><button data-a="map">Map</button><button data-a="phone">Phone</button><button data-a="stats">Stats & Skills</button><button data-a="save">Save Game</button><button data-a="photo">Photo Mode</button><button data-a="settings">Settings</button><button data-a="cheats">Cheat Menu</button><button data-a="quit">Quit to Menu</button></div>`);
    m.addEventListener('click', (e) => { const a = e.target.dataset.a; if (!a) return; if (a === 'resume') U.close(); else if (a === 'map') { U.close(); U.openMap(); } else if (a === 'phone') { U.close(); U.openPhone(); } else if (a === 'stats') U.openStats(); else if (a === 'save') { g.saveGame(true); } else if (a === 'photo') { U.closeAll(); g.enterPhoto(); } else if (a === 'settings') U.openSettings(); else if (a === 'cheats') { U.close(); U.openCheats(); } else if (a === 'quit') { g.saveGame(false); U.closeAll(); g.toMenu(); } });
  };
  const lvl = (xp) => { let l = 0; for (let i = 0; i < SKILL_XP.length; i++) if (xp >= SKILL_XP[i]) l = i; return l; };
  U.openStats = () => {
    const s = g.stats, t = Math.floor(s.playTime / 60);
    const rows = [['Play time', t + ' min'], ['Missions passed', s.missions + '/12'], ['Cash earned', fmtMoney(s.cashEarned)], ['Kills', s.kills], ['Civilians killed', s.civKills], ['Crimes', s.crimes], ['Distance driven', Math.round(s.distance / 10) + ' m'], ['Drift time', Math.round(s.drift) + ' s'], ['Stunt jumps', s.stunts], ['Tide Shards', g.shardsGot + '/24'], ['Vehicles destroyed', s.vehiclesDestroyed], ['Carjackings', s.carjacks], ['Props broken', s.propsBroken], ['Damage taken', Math.round(s.damageTaken)], ['Busted / Wasted', s.busted + ' / ' + s.wasted]];
    const sk = Object.keys(SKILLS).map((k) => { const x = g.skills[k], l = lvl(x), nx = SKILL_XP[Math.min(5, l + 1)], pr = l >= 5 ? 1 : (x - SKILL_XP[l]) / (nx - SKILL_XP[l]); return `<div class="skill"><span>${SKILLS[k].n} <b>Lv ${l}</b></span><div class="bar2"><i style="width:${pr * 100}%"></i></div><small>${SKILLS[k].d}</small></div>`; }).join('');
    const rep = GANGS.map((x) => `<div class="skill"><span style="color:${x.color}">${x.name}</span><div class="bar2 rep"><i style="width:${(g.rep[x.id] + 100) / 2}%;background:${x.color}"></i></div></div>`).join('');
    const tot = g.totalSkill(), ab = ABILITIES.map((a) => `<li class="${tot >= a.lvl ? 'on' : ''}">${a.n} (total lvl ${a.lvl}) — ${a.d}</li>`).join('');
    modal('Stats & Progression', `<div class="cols"><div><table>${rows.map((r) => `<tr><td>${r[0]}</td><td>${r[1]}</td></tr>`).join('')}</table></div><div><h4>Skills</h4>${sk}<h4>Reputation</h4>${rep}<h4>Abilities</h4><ul class="ab">${ab}</ul></div></div>`, { wide: true });
  };

  // ---------- map ----------
  // 16×16 block bitmaps for the minimap (the world map uses baked macro tiles instead, see worldmap.js)
  const miniCv = new Map();
  function miniCanvas(bx, by) {
    const px = g.world.miniRGBA(bx, by), k = bkey(bx, by); let e = miniCv.get(k);
    if (!e || e.px !== px) { const cv = document.createElement('canvas'); cv.width = cv.height = 16; cv.getContext('2d').putImageData(new ImageData(px, 16, 16), 0, 0); e = { px, cv }; if (miniCv.size > 900) miniCv.clear(); miniCv.set(k, e); }
    return e.cv;
  }
  U.openMap = () => {
    const nPlaces = g.world.atlas.sites.size, hide = new Set(g.mapHide || []);
    const chips = [['cities', '★ Cities'], ['transport', '✈ Transport'], ['services', '+ Services'], ['industry', '⚙ Industry'], ['fun', '♦ Fun'], ['nature', '♣ Nature'], ['pins', '📌 Pins']];
    const m = modal('WORLD MAP', `<div class="mapwrap2"><div class="maptop"><div class="msearch"><input id="msearch" type="search" placeholder="Search known places…" autocomplete="off"><div id="mres" class="mres"></div></div>
      <button class="mfbtn" data-mp="tog" aria-label="Layers">⚙ Layers</button><div class="chips">${chips.map(([k, n]) => `<button data-mf="${k}" class="${hide.has(k) ? 'off' : ''}">${n}</button>`).join('')}</div></div>
      <div class="mapbody"><canvas id="bigmap"></canvas><div class="mapbtns"><button data-mp="me" title="Centre on me">⌖</button><button data-mp="in">＋</button><button data-mp="out2">－</button><button data-mp="core" title="Port Meridian">⌂</button><button data-mp="out" class="mhide" title="Overview">⤢</button><button data-mp="wp" title="Waypoint at centre">⚑</button><button data-mp="pin" class="mhide" title="Pin at centre">📌</button><button data-mp="clearwp" title="Clear waypoint">✕</button></div></div>
      <div class="legend"><div><i style="background:#ffe14a"></i>Mission</div><div><i style="background:#ff3b5c"></i>Heat</div><div><i style="background:#7cff4f"></i>Waypoint</div><div><i style="background:#ffd24a"></i>Pin</div>${GANGS.map((x) => `<div><i style="background:${x.color}"></i>${x.name}</div>`).join('')}<span>Tap = waypoint · long-press = pin · drag / pinch to move &amp; zoom · ${nPlaces} known sites · ${g.world.explored.size} blocks explored · ${Object.keys(g.disc).length} discovered</span></div>
      <p id="mcoord"></p></div>`, { wide: true });
    m.classList.add('mapmodal');
    mountMap(g, m, { $, GANGS, MAP_POIS, NT, NB, TS });
  };

  // ---------- phone ----------
  U.openPhone = (tab = 'contacts') => {
    const tabs = [['contacts', 'Contacts'], ['msgs', 'Messages'], ['news', 'News'], ['jobs', 'Jobs'], ['props', 'Market'], ['map', 'Map']];
    const m = modal('☎ PHONE', `<div class="phone"><div class="tabs">${tabs.map(([k, n]) => `<button data-tab="${k}" class="${k === tab ? 'on' : ''}">${n}</button>`).join('')}</div><div class="pbody"></div></div>`, { wide: true });
    const body = $('.pbody', m);
    const render = (t) => {
      let h = '';
      if (t === 'contacts') {
        const next = MISSIONS.find((d) => missionAvailable(g, d));
        h = `<div class="contact"><b>Gus</b> — garage owner, mentor.<button data-call="gus">Call</button></div><div class="contact"><b>Nina Zhao</b> — Ledger crime desk.<button data-call="nina">Call</button></div><div class="contact"><b>Juno</b> — Chrome Vipers.<button data-call="viper">Call</button></div><div class="contact"><b>Yellow Cab dispatch</b><button data-job="taxi">Call</button></div>`;
        h += next ? `<p class="hint">Next job: <b>${next.title}</b> — meet at ${esc(g.world.pois[next.at]?.name || next.at)}. <button data-wp="${next.at}">Set waypoint</button></p>` : '<p class="hint">Story complete. The city is yours.</p>';
      } else if (t === 'msgs') h = g.messages.length ? g.messages.slice().reverse().map((x) => `<div class="msg"><b>${esc(x.from)}</b><span>${esc(x.text)}</span></div>`).join('') : '<p>No messages.</p>';
      else if (t === 'news') h = '<div class="news"><h3>THE MERIDIAN LEDGER</h3>' + makeHeadlines(g).map((x) => `<article>${esc(x)}</article>`).join('') + '</div>';
      else if (t === 'jobs') {
        h = `<div class="jobs"><button data-job="taxi">🚕 Taxi shift <small>(sit in a Yellow Cab)</small></button><button data-job="delivery">📦 Delivery run <small>(van, pickup or bike)</small></button><button data-job="vigilante">👮 Vigilante <small>(police cruiser)</small></button><button data-job="race">🏁 Street race <small>(any vehicle)</small></button><button data-job="theft">🚗 Car-theft list</button><h4 class="jobh">✈ Aviation &amp; trials <small>(new)</small></h4><button data-job="skyrings">🛩 Sky rings <small>(any aircraft · time trial)</small></button><button data-job="aircourier">📦 Air courier <small>(land · load · land)</small></button><button data-job="medevac">🚑 Heli medevac <small>(helicopter)</small></button><button data-job="streettrial">🏁 Street trial <small>(checkpoints · any car)</small></button><p>Theft list: ${THEFT_LIST.map((x) => `<span class="${g.theft.done.includes(x) ? 'done' : ''}">${VEHICLES[x].n}</span>`).join(', ')}</p><p>Arena fights at The Pit · Casino slots · Stunt ramps ${g.stats.stunts} · Shards ${g.shardsGot}/24</p></div>`;
      } else if (t === 'props') {
        h = '<h4>Properties</h4>' + PROPERTIES.map((p) => `<div class="contact"><b>${p.n}</b> ${fmtMoney(p.price)} · +${fmtMoney(p.income)}/day ${g.props[p.id] ? '<span class="own">OWNED</span>' : `<button data-prop="${p.id}">Buy</button>`}</div>`).join('') +
          '<h4>AutoTrader (delivered to your safehouse)</h4>' + BUYABLE.map((k) => `<div class="contact"><b>${VEHICLES[k].n}</b> ${fmtMoney(VEHICLES[k].price)}<button data-car="${k}">Buy</button></div>`).join('');
      } else if (t === 'map') { U.close(); U.openMap(); return; }
      body.innerHTML = h;
    };
    render(tab);
    m.addEventListener('click', (e) => {
      const d = e.target.dataset; if (d.tab) { m.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === d.tab)); render(d.tab); g.audio.sfx('click'); }
      if (d.call) { const mi = MISSIONS.find((x) => missionAvailable(g, x) && x.at === d.call); g.toast(mi ? 'Next: ' + mi.title + ' — marked on the map' : 'No work right now.', '#ffe14a'); if (mi) g.waypoint = { ...g.world.pois[mi.at] }; }
      if (d.wp) { g.waypoint = { ...g.world.pois[d.wp] }; g.toast('Waypoint set', '#7cff4f'); }
      if (d.job) { U.close(); if (d.job === 'theft') startSide(g, 'theft'); else startSide(g, d.job); }
      if (d.prop) { const p = PROPERTIES.find((x) => x.id === d.prop); if (g.cash >= p.price) { g.cash -= p.price; g.props[p.id] = true; g.toast('Purchased ' + p.n, '#7cff4f'); g.audio.sfx('cash'); render('props'); } else g.toast('Not enough cash', '#ff7788'); }
      if (d.car) { const v = VEHICLES[d.car]; if (g.cash >= v.price) { if (g.deliverCar(d.car)) { g.cash -= v.price; g.toast(v.n + ' delivered to your safehouse', '#7cff4f'); g.audio.sfx('cash'); } } else g.toast('Not enough cash', '#ff7788'); }
    });
  };

  // ---------- shop ----------
  U.openShop = (type) => {
    const def = SHOP_ITEMS[type]; if (!def) return;
    const mul = g.priceMul();
    const items = def.items.map((it, i) => ({ ...it, i, price: Math.round(it.price * mul) }));
    const m = modal(def.title, `<p class="cash">Cash: <b></b> <small>Street cred discount ${(Math.round((1 - mul) * 100))}%</small></p><div class="shop">${items.map((it) => `<div class="item"><b>${it.n}</b><small>${it.d || ''}</small><button data-i="${it.i}">${fmtMoney(it.price)}</button></div>`).join('')}</div>`, { wide: true });
    const cash = $('.cash b', m); const upd = () => (cash.textContent = fmtMoney(g.cash)); upd();
    m.addEventListener('click', (e) => { const i = e.target.dataset.i; if (i === undefined) return; const it = items[+i]; if (g.cash < it.price) { g.toast('Not enough cash', '#ff7788'); g.audio.sfx('error'); return; } if (g.applyItem(it)) { g.cash -= it.price; g.audio.sfx('cash'); upd(); } });
  };

  // ---------- wardrobe / character ----------
  U.openWardrobe = (cost, isNew) => {
    const L = { ...g.look };
    const sw = (arr, key) => arr.map((c, i) => `<i class="sw ${L[key] === c ? 'on' : ''}" style="background:${c}" data-k="${key}" data-v="${c}"></i>`).join('');
    const body = `<div class="ward"><canvas id="prev" width="200" height="200"></canvas><div><h4>Skin</h4>${sw(SKINS, 'skin')}<h4>Hairstyle</h4>${HAIR_STYLES.map((s, i) => `<button class="${L.style === i ? 'on' : ''}" data-k="style" data-v="${i}">${s}</button>`).join('')}<h4>Hair colour</h4>${sw(HAIR_COLORS, 'hair')}<h4>Shirt</h4>${sw(SHIRTS, 'shirt')}<h4>Trousers</h4>${sw(PANTS, 'pants')}<h4>Accessories</h4><button class="${L.shades ? 'on' : ''}" data-k="shades" data-v="t">Sunglasses</button></div></div><div class="mbtns"><button data-ok>${isNew ? 'Start Game' : cost ? 'Buy for ' + fmtMoney(cost) : 'Confirm'}</button></div>`;
    const m = modal(isNew ? 'CREATE YOUR RUNNER' : 'WARDROBE', body, { noEsc: !!isNew, onClose: () => {} });
    const pv = $('#prev', m), redraw = () => drawPreview(pv, L); redraw();
    m.addEventListener('click', (e) => {
      const d = e.target.dataset;
      if (d.k) { if (d.k === 'shades') L.shades = !L.shades; else L[d.k] = d.k === 'style' ? +d.v : d.v; m.querySelectorAll(`[data-k="${d.k}"]`).forEach((n) => n.classList.toggle('on', d.k === 'shades' ? L.shades : String(L[d.k]) === n.dataset.v)); redraw(); g.audio.sfx('click'); }
      if ('ok' in d) { if (cost && g.cash < cost) { g.toast('Not enough cash', '#ff7788'); return; } g.cash -= cost || 0; Object.assign(g.look, L); Object.assign(g.player.look, L); U.close(); if (isNew) g.newGame(); }
    });
  };

  // ---------- garage ----------
  U.openGarage = (v) => {
    const row = (k, n, costs) => `<div class="contact"><b>${n}</b> Lv ${v.upg[k]}/3 ${v.upg[k] < 3 ? `<button data-up="${k}">${fmtMoney(costs[v.upg[k]])}</button>` : '<span class="own">MAX</span>'}</div>`;
    const m = modal("GUS'S GARAGE — " + v.def.n, `<h4>Paint ($150)</h4><div>${PAINTS.map((c) => `<i class="sw ${v.color === c ? 'on' : ''}" style="background:${c}" data-paint="${c}"></i>`).join('')}</div><h4>Upgrades</h4>${row('engine', 'Engine', [800, 1800, 3200])}${row('tires', 'Tyres & suspension', [500, 1200, 2400])}${row('armor', 'Armour plating', [900, 2000, 3500])}<h4>Plate ($50)</h4><input id="plate" maxlength="8" value="${esc(v.plate)}"><button data-plate>Fit plate</button><div class="mbtns"><button data-keep>${v.owned ? 'Vehicle is yours' : 'Register as my vehicle (free)'}</button><button data-fix>Repair ($${Math.round((1 - v.hp / v.def.hp) * 400)})</button></div>`);
    m.addEventListener('click', (e) => {
      const d = e.target.dataset, pay = (c) => { if (g.cash < c) { g.toast('Not enough cash', '#ff7788'); g.audio.sfx('error'); return false; } g.cash -= c; g.audio.sfx('cash'); return true; };
      if (d.paint && pay(150)) { v.color = d.paint; v.owned = true; U.close(); U.openGarage(v); g.clearWanted(); }
      if (d.up && v.upg[d.up] < 3 && pay({ engine: [800, 1800, 3200], tires: [500, 1200, 2400], armor: [900, 2000, 3500] }[d.up][v.upg[d.up]])) { v.upg[d.up]++; v.owned = true; U.close(); U.openGarage(v); }
      if ('plate' in d && pay(50)) { v.plate = $('#plate', m).value.toUpperCase() || v.plate; v.owned = true; g.toast('Plate fitted: ' + v.plate, '#7cff4f'); }
      if ('keep' in d) { v.owned = true; g.toast('Vehicle registered — it will be saved.', '#7cff4f'); }
      if ('fix' in d) { const c = Math.round((1 - v.hp / v.def.hp) * 400); if (c && pay(c)) { v.hp = v.def.hp; v.burning = false; v.flat = false; U.close(); } }
    });
  };

  // ---------- cheats ----------
  U.openCheats = () => {
    const pp = g.world.pois, keys = Object.keys(pp).filter((k) => pp[k] && pp[k].name && !/^(x|v_|c_x|c_ap)/.test(k)).sort((x, y) => (y.startsWith('c_') ? 1 : 0) - (x.startsWith('c_') ? 1 : 0) || pp[x].name.localeCompare(pp[y].name));
    const dests = g.world.destinationsNear(g.player.x, g.player.y);
    const GROUPS = [['Everyday', ['compact', 'sedan', 'suv', 'taxi', 'van', 'pickup', 'moto', 'golf']], ['Sport & luxury', ['sports', 'muscle', 'cabrio', 'supercar', 'limo']], ['Off-road & work', ['offroad', 'tractor', 'truck', 'bus', 'hummer']], ['Emergency & military', ['police', 'ambulance', 'fire', 'swat', 'army']]];
    const vb = (k) => VEHICLES[k] ? `<button data-veh="${k}">${esc(VEHICLES[k].n)}</button>` : '';
    const m = modal('CHEAT / DEBUG MENU', `<div class="cheat"><div><button data-c="cash">+ $10,000</button><button data-c="heal">Heal + armor</button><button data-c="guns">All weapons + ammo</button><button data-c="god">Toggle invincible</button><button data-c="skip">Skip current mission</button><button data-c="shards">Collect all shards</button><button data-c="fixcar">Repair nearest vehicle</button><button data-c="ownall">Deliver every car to my garage</button></div>
      <div><h4>Summon vehicle (appears next to you)</h4>${GROUPS.map(([n, l]) => `<small style="opacity:.7;display:block;margin:4px 0 2px">${n}</small>${l.map(vb).join('')}`).join('')}</div>
      <div><h4>Aircraft (spawn next to you — press E to board)</h4><small style=\"opacity:.7;display:block;margin:4px 0 2px\">General aviation — WASD move · Space climb · Shift descend</small><button data-heli=\"skylark\">Skylark charter (random colour)</button><button data-heli=\"skylark\" data-col=\"#e8eaf0\">Skylark white</button><button data-heli=\"skylark\" data-col=\"#d9462f\">Skylark red</button><button data-heli=\"skylark\" data-col=\"#2a2f3a\">Skylark black</button>
        <small style=\"opacity:.7;display:block;margin:6px 0 2px\">Combat — mouse aims nose · LMB minigun · RMB / R rocket pods</small><button data-heli=\"reaper\" data-col=\"#4a5a35\">Reaper gunship (olive)</button><button data-heli=\"reaper\" data-col=\"#17191f\">Reaper gunship (black)</button><button data-heli=\"reaper\" data-col=\"#8a7a55\">Reaper gunship (desert)</button><small style=\"opacity:.7;display:block;margin:8px 0 2px\">Aeroplanes — spawn, build speed on the ground, then climb. Land gently, ideally on a runway</small><button data-heli=\"sparrow\">Sparrow SR-2 (prop plane)</button><button data-heli=\"sparrow\" data-col=\"#e8453c\">Sparrow red</button><button data-heli=\"cropmaster\">Cropmaster duster</button><button data-heli=\"falcon\" data-col=\"#8a929a\">Falcon F-12 jet (grey)</button><button data-heli=\"falcon\" data-col=\"#3c4a5c\">Falcon F-12 jet (navy)</button></div>
      <div><h4>Armour, boats &amp; ships (spawn next to you / on nearby water — press E to board)</h4><small style=\"opacity:.7;display:block;margin:4px 0 2px\">Tanks — W/S drive · A/D steer · mouse aims turret · LMB cannon · RMB machine gun. Crushes everything</small><button data-heli=\"bulldog\">Bulldog M-1 tank</button><button data-heli=\"bulldog\" data-col=\"#8a7a55\">Bulldog (desert)</button><button data-heli=\"hornet\">Hornet APC</button>
        <small style=\"opacity:.7;display:block;margin:6px 0 2px\">Water — go to the coast first. W/S throttle · A/D rudder · Space brake · E at a dock to get out</small><button data-heli=\"jetski\">Jet ski</button><button data-heli=\"speedboat\">Barracuda speedboat</button><button data-heli=\"speedboat\" data-col=\"#e53935\">Speedboat (red)</button><button data-heli=\"cruiser\">Marlin sea cruiser</button><button data-heli=\"gunboat\">Sentinel gunboat (armed)</button><button data-heli=\"freighter\">Titan container ship</button><button data-heli=\"liner\">Aurora cruise liner</button>
        <small style=\"opacity:.7;display:block;margin:6px 0 2px\">Heavy aircraft — long runway needed. Hold W for throttle, hold Space after rotate speed. Airport aprons now hold real flyable airliners</small><button data-heli=\"airliner\">Meridian A320 airliner</button><button data-heli=\"jumbo\">Titan 7X jumbo jet</button><button data-heli=\"atlas\">Atlas C-9 heavy airlifter</button></div>
      <div><h4>Zombie outbreak</h4><button data-c=\"zstart\">Start the outbreak campaign now</button><button data-c=\"zhorde\">Spawn a horde near me</button><button data-c=\"zskip\">Skip zombie objective</button></div>
      <div><h4>Street lights (key L)</h4>${[['auto', 'Auto — on at dusk, off at dawn'], ['on', 'Always on'], ['off', 'Always off']].map(([v, n]) => `<button data-lamp=\"${v}\" class=\"${g.settings.lamps === v ? 'on' : ''}\">${n}</button>`).join('')}</div>
      <div><h4>Wanted level</h4>${[0, 1, 2, 3, 4, 5].map((n) => `<button data-w="${n}">${n}★</button>`).join('')}</div>
      <div><h4>Time</h4>${[[5.6, 'Pre-dawn'], [6.4, 'Dawn'], [9, 'Morning'], [12, 'Noon'], [17.3, 'Golden hr'], [18.3, 'Dusk'], [19, 'Sunset'], [23, 'Night'], [3, 'Late']].map(([h, n]) => `<button data-t="${h}">${n}</button>`).join('')}</div>
      <div><h4>Weather</h4>${['clear', 'rain', 'fog', 'storm'].map((w) => `<button data-wx="${w}">${w}</button>`).join('')}</div>
      <div><h4>Fast travel — discovered cities &amp; airports (nearest first)</h4>${dests.map(({ c, d }) => `<button data-c="tp" data-tp="c_${c.key}" title="${Math.round(d / 32)} tiles away">${c.airport || c.key === 'airport' ? '✈ ' : ''}${esc(c.name)}</button>`).join('')}</div>
      <div><h4>Teleport to any place</h4><select id="tp">${keys.map((k) => `<option value="${k}">${esc(g.world.pois[k].name)}</option>`).join('')}</select><button data-c="tp">Go</button><button data-c="wp">To waypoint</button></div>
      <div><h4>Events</h4><button data-c="war">Gang war</button><button data-c="event">Random event</button><button data-c="story">Unlock all missions</button></div></div>`, { wide: true });
    m.addEventListener('click', (e) => { const d = e.target.dataset; if (!d || !Object.keys(d).length) return; const r = g.cheat(d, $('#tp', m) && $('#tp', m).value); if (d.veh || d.heli || d.c === 'tp' || d.c === 'wp') U.close(); else if (d.lamp) { m.querySelectorAll('[data-lamp]').forEach((b) => b.classList.toggle('on', b.dataset.lamp === d.lamp)); } return r; });
  };
  U.openFlights = (deskName = '') => {
    const p = g.player, rows = g.world.destinationsNear(p.x, p.y).filter((r) => r.d > 900).map((r, i) => ({ c: r.c, i, d: r.d, fare: Math.round(40 + r.d / 45) }));
    const m = modal('✈ ' + esc(deskName || 'SKYLINE INTERNATIONAL') + ' — DEPARTURES', `<p>Pick a destination (nearest first). Newly discovered cities and regional airports are added automatically. Flights are instant — nobody wants to watch a forty-minute taxi.</p><div class="mbtns col">${rows.map((r) => `<button data-f="${r.i}" ${g.cash < r.fare ? 'disabled' : ''}>${r.c.airport || r.c.key === 'airport' ? '✈' : '🏙'} ${esc(r.c.name)} — ${Math.round(r.d / 32)} tiles — ${fmtMoney(r.fare)}</button>`).join('')}</div>`);
    m.addEventListener('click', (e) => { const i = e.target.dataset.f; if (i === undefined) return; const r = rows.find((x) => x.i === +i); if (!r || g.cash < r.fare) return; g.cash -= r.fare; U.close(); g.travel(r.c.x, r.c.y, r.c.name); });
  };

  // ---------- gambling ----------
  U.openSlots = (bet) => {
    const SYM = ['🍒', '🍋', '🔔', '⭐', '7️⃣', '💎'];
    const m = modal('SLOT MACHINE', `<div class="slots"><div class="reels"><span>7️⃣</span><span>7️⃣</span><span>7️⃣</span></div><p class="res">Bet ${fmtMoney(bet)} — three of a kind pays big.</p><button data-spin>SPIN</button></div>`);
    let busy = false; const rs = m.querySelectorAll('.reels span'), res = $('.res', m);
    m.addEventListener('click', (e) => {
      if (!('spin' in e.target.dataset) || busy) return; if (g.cash < bet) { res.textContent = 'Not enough cash.'; g.audio.sfx('error'); return; }
      g.cash -= bet; busy = true; g.audio.sfx('click'); const out = [0, 1, 2].map(() => Math.floor(Math.random() * SYM.length)); let t = 0;
      const iv = setInterval(() => { t++; rs.forEach((r, i) => { if (t < 10 + i * 6) r.textContent = pick(SYM); else r.textContent = SYM[out[i]]; }); g.audio.sfx('beep'); if (t > 28) { clearInterval(iv); busy = false; const [a, b, c] = out; let pay = 0; if (a === b && b === c) pay = bet * ({ 4: 25, 5: 15, 3: 8, 2: 5 }[a] || 3); else if (a === b || b === c || a === c) pay = Math.round(bet * 0.9); if (pay > 0) { g.cash += pay; g.stats.cashEarned += pay; res.textContent = 'WIN ' + fmtMoney(pay) + '!'; g.audio.sfx('cash'); } else res.textContent = 'No luck.'; } }, 70);
    });
  };
  U.openCoin = (bet) => {
    const m = modal('DOUBLE OR NOTHING', `<div class="slots"><div class="coin">🪙</div><p class="res">Bet ${fmtMoney(bet)}. Call it.</p><button data-c="h">HEADS</button><button data-c="t">TAILS</button></div>`);
    m.addEventListener('click', (e) => { const c = e.target.dataset.c; if (!c) return; if (g.cash < bet) { $('.res', m).textContent = 'Not enough cash.'; return; } g.cash -= bet; const win = Math.random() < 0.48; $('.coin', m).textContent = win ? (c === 'h' ? 'HEADS' : 'TAILS') : (c === 'h' ? 'TAILS' : 'HEADS'); if (win) { g.cash += bet * 2; g.stats.cashEarned += bet; $('.res', m).textContent = 'You win ' + fmtMoney(bet) + '!'; g.audio.sfx('cash'); } else { $('.res', m).textContent = 'The house wins.'; g.audio.sfx('error'); } });
  };
  U.openBank = () => {
    const m = modal('ATM — MERIDIAN SAVINGS', `<p class="cash">Cash <b id="bc"></b> · Account <b id="bb"></b> <small>(2% interest per day)</small></p><div class="mbtns"><button data-d="500">Deposit 500</button><button data-d="5000">Deposit 5,000</button><button data-d="all">Deposit all</button><button data-w="500">Withdraw 500</button><button data-w="5000">Withdraw 5,000</button><button data-w="all">Withdraw all</button></div>`);
    const upd = () => { $('#bc', m).textContent = fmtMoney(g.cash); $('#bb', m).textContent = fmtMoney(g.bank); }; upd();
    m.addEventListener('click', (e) => { const d = e.target.dataset; if (d.d) { const n = d.d === 'all' ? g.cash : Math.min(+d.d, g.cash); g.cash -= n; g.bank += n; } if (d.w) { const n = d.w === 'all' ? g.bank : Math.min(+d.w, g.bank); g.bank -= n; g.cash += n; } if (d.d || d.w) { g.audio.sfx('cash'); upd(); } });
  };
  U.openPolice = () => {
    const stars = g.wanted.stars, bribe = stars * 1200, fine = 300;
    const m = modal('PMPD — DESK SERGEANT', `<p>"What can I do for you, citizen?"</p><div class="mbtns col"><button data-b="b" ${stars ? '' : 'disabled'}>Bribe the sergeant — drop heat (${fmtMoney(bribe)})</button><button data-b="f">Pay your parking tickets (${fmtMoney(fine)}) — +street cred</button></div>`);
    m.addEventListener('click', (e) => { const b = e.target.dataset.b; if (b === 'b' && stars) { if (g.cash >= bribe) { g.cash -= bribe; g.setStars(stars - 1); g.audio.sfx('cash'); g.toast('The sergeant lost your file.', '#7cff4f'); U.close(); } else g.toast('Not enough cash', '#ff7788'); } if (b === 'f') { if (g.cash >= fine) { g.cash -= fine; g.rep.pd = Math.min(100, g.rep.pd + 5); g.toast('Tickets paid.', '#7cff4f'); } else g.toast('Not enough cash', '#ff7788'); } });
  };
  U.choice = (prompt, opts, cb) => {
    const m = modal(esc(prompt), `<div class="mbtns col">${opts.map((o, i) => `<button data-o="${i}">${esc(o.label)}</button>`).join('')}</div>`, { noEsc: true });
    m.addEventListener('click', (e) => { const i = e.target.dataset.o; if (i === undefined) return; U.close(); cb(opts[+i]); });
  };
  U.info = (title, text) => modal(esc(title), `<p>${esc(text)}</p>`);
  U.ending = (e) => { U.endingOpen = true; const m = modal(e.t, `<p class="end">${esc(e.x)}</p><div class="mbtns"><button data-ok>Continue in free roam</button></div>`, { noEsc: true, onClose: () => { U.endingOpen = false; } }); m.addEventListener('click', (ev) => { if ('ok' in ev.target.dataset) U.close(); }); g.audio.sfx('complete'); };

  // ---------- hotwire mini-game ----------
  U.hotwire = (v, cb) => {
    const arrows = ['↑', '→', '↓', '←'], codes = [['ArrowUp', 'KeyW'], ['ArrowRight', 'KeyD'], ['ArrowDown', 'KeyS'], ['ArrowLeft', 'KeyA']];
    const seq = Array.from({ length: 4 }, () => Math.floor(Math.random() * 4)); U.hotKeys.length = 0; U.hot = { seq, i: 0, t: 4.2 + g.skillLvl('stealth') * 0.3, cb, v };
    const h = q('#hotwire'); h.style.display = 'block'; $('.hw-keys', h).innerHTML = seq.map((s, i) => `<span>${arrows[s]}</span>`).join(''); g.hotwiring = true;
    U.hot.codes = codes; g.audio.sfx('beep');
  };
  U.hotKeys = []; window.addEventListener('keydown', (e) => { if (U.hot && !e.repeat) U.hotKeys.push(e.code); });
  function hotUpdate(dt) {
    const H = U.hot; if (!H) return; H.t -= dt; const h = q('#hotwire');
    $('.hw-bar i', h).style.width = Math.max(0, H.t / 4.5 * 100) + '%'; h.querySelectorAll('.hw-keys span').forEach((s, i) => s.className = i < H.i ? 'ok' : i === H.i ? 'cur' : '');
    for (const code of U.hotKeys.splice(0)) { const k = H.codes.findIndex((cs) => cs.includes(code)); if (k < 0) continue; if (k === H.seq[H.i]) { H.i++; g.audio.sfx('beep'); } else { H.i = 0; H.t -= 0.6; g.audio.sfx('error'); } if (H.i >= H.seq.length) break; }
    if (H.i >= H.seq.length) { end(true); } else if (H.t <= 0) end(false);
    function end(ok) { const cb = H.cb; U.hot = null; h.style.display = 'none'; g.hotwiring = false; if (ok) g.xp('stealth', 8); cb(ok); }
  }

  // ---------- weapon wheel ----------
  function wheelUpdate() {
    const w = q('#wheel'), inp = g.input;
    const want = g.state === 'play' && !g.uiOpen && !g.player.veh && !g.cut && inp.down('wheel');
    if (want && !g.wheelOpen) { g.wheelOpen = true; const list = WEAPON_ORDER.filter((k) => g.inv.have[k]); w.style.display = 'block'; w.innerHTML = list.map((k, i) => { const a = (i / list.length) * Math.PI * 2 - Math.PI / 2; return `<div class="wi" data-k="${k}" style="left:calc(50% + ${Math.cos(a) * 150}px);top:calc(50% + ${Math.sin(a) * 150}px)"><b>${WEAPONS[k].n}</b><small>${WEAPONS[k].type === 'melee' ? '—' : (g.inv.mag[k] ?? '∞') + '/' + (g.inv.ammo[WEAPONS[k].ammo] | 0)}</small></div>`; }).join(''); U.wlist = list; }
    if (g.wheelOpen) {
      const dx = inp.mx - innerWidth / 2, dy = inp.my - innerHeight / 2; let sel = null;
      if (Math.hypot(dx, dy) > 40 && U.wlist.length) { let a = Math.atan2(dy, dx) + Math.PI / 2; if (a < 0) a += Math.PI * 2; sel = U.wlist[Math.round(a / (Math.PI * 2) * U.wlist.length) % U.wlist.length]; }
      w.querySelectorAll('.wi').forEach((n) => n.classList.toggle('sel', n.dataset.k === sel)); U.wsel = sel;
      if (!want) { g.wheelOpen = false; w.style.display = 'none'; if (U.wsel) g.switchWeapon(U.wsel); }
    }
  }

  // ---------- HUD update ----------
  U.update = (dt) => {
    const p = g.player, W = g.wanted, env = g.env;
    hotUpdate(dt); wheelUpdate();
    const show = g.state === 'play' || g.state === 'pause' || g.state === 'cut' || g.state === 'ui';
    hud.style.display = show && g.state !== 'photo' ? 'block' : 'none'; if (!show) return;
    hud.style.transform = `scale(${g.settings.hud})`; hud.style.transformOrigin = 'top left'; hud.style.width = 100 / g.settings.hud + '%'; hud.style.height = 100 / g.settings.hud + '%';
    set('cash', q('#cash'), fmtMoney(g.cash));
    const hp = $('.hp i', hud); hp.style.width = clamp(p.hp / p.max * 100, 0, 100) + '%'; $('.hp span', hud).textContent = Math.ceil(p.hp);
    $('.ar', hud).style.display = p.armor > 0 ? 'block' : 'none'; $('.ar i', hud).style.width = clamp(p.armor, 0, 100) + '%';
    $('.st i', hud).style.width = clamp(p.stam / (100 + 12 * g.skillLvl('stamina')) * 100, 0, 100) + '%'; $('.sf i', hud).style.width = clamp(g.styleM * 100, 0, 100) + '%'; $('.sf', hud).classList.toggle('ready', g.styleM >= 0.5 && g.totalSkill() >= 3);
    $('.sf', hud).style.display = g.totalSkill() >= 3 ? 'block' : 'none';
    // stars
    let st = ''; for (let i = 1; i <= 5; i++) st += `<i class="${i <= W.stars ? 'on' : ''} ${W.stars && !W.seen && Math.floor(g.time * 3) % 2 ? 'blink' : ''}">★</i>`; set('stars', q('#stars'), st, true);
    q('#evade').style.display = W.stars ? 'block' : 'none'; $('#evade i', hud).style.width = W.evade * 100 + '%';
    const wp = g.scene ? g.scene.building.door : p; set('loc', q('#loc'), g.scene ? g.scene.building.name || 'Interior' : `${g.world.streetAt(wp.x, wp.y)} · ${g.world.areaName(wp.x, wp.y)}`);
    set('clock', q('#clock'), `${fmtTime(env.hour)} · ${env.weather.toUpperCase()}${g.focusT > 0 ? ' · FOCUS' : ''}`);
    // weapon / vehicle
    const wd = p.wdef, v = p.veh;
    set('wpn', q('#weapon'), p.veh ? '' : `<b>${wd.n}</b><span>${wd.type === 'melee' ? '' : p.reload > 0 ? 'RELOADING' : wd.type === 'throw' ? 'x' + (g.inv.ammo[wd.ammo] | 0) : g.inv.mag[p.wid] + ' / ' + (g.inv.ammo[wd.ammo] | 0)}</span>`, true);
    if (v) { const sp = Math.round(Math.hypot(v.vx, v.vy) * 0.22), station = g.audio.radioOn && g.audio.station >= 0 ? STATIONS[g.audio.station] : null; set('veh', q('#veh'), `<b>${sp}</b> km/h<small>${v.def.n} · ${v.plate}${v.flat ? ' · FLAT TYRE' : ''}</small><div class="bar"><i style="width:${v.hp / v.def.hp * 100}%;background:${v.hp < v.def.hp * 0.3 ? '#ff4444' : '#7cff4f'}"></i></div>`, true); set('radio', q('#radio'), station ? `<span style="color:${station.color}">♪ ${station.n}</span> <small>${station.genre}</small>` : '<small>Radio off (X)</small>', true); } else { set('veh', q('#veh'), '', true); set('radio', q('#radio'), '', true); }
    // objective
    const o = g.obj; let oh = ''; if (g.mission) oh = `<small>${esc(g.mission.def.title)}</small><b>${esc(o?.text || '')}</b>${o?.sub ? `<span>${esc(o.sub)}</span>` : ''}`; else if (g.side && o) oh = `<small>SIDE JOB</small><b>${esc(o.text)}</b>${o.sub ? `<span>${esc(o.sub)}</span>` : ''}`; else if (g.arena) oh = '<small>THE PIT</small><b>Win the fights</b>';
    set('obj', q('#obj'), oh, true); q('#obj').style.display = oh ? 'block' : 'none';
    const bs = g.boss && !g.boss.dead ? g.boss : null; set('boss', q('#boss'), bs ? `<b>${esc(bs.name || 'BOSS')}</b><div class="bar"><i style="width:${bs.hp / bs.max * 100}%"></i></div>` : '', true);
    set('prompt', q('#prompt'), g.input.touch ? touchText(esc(g.promptText || '')) : g.promptText || '', true); q('#prompt').style.display = g.promptText && !g.uiOpen ? 'block' : 'none';
    set('tut', q('#tut'), g.player.heli ? '' : g.input.touch ? touchText(g.tutText || '') : g.tutText || '', true);
    // cards
    let cards = ''; if (g.titleCard) cards += `<div class="card title"><small>${g.titleCard.sub}</small><h1>${esc(g.titleCard.text)}</h1></div>`; if (g.completeCard) cards += `<div class="card ok"><small>MISSION PASSED</small><h1>${esc(g.completeCard.title)}</h1><p>+${fmtMoney(g.completeCard.cash)}</p></div>`; if (g.failCard) cards += `<div class="card bad"><small>MISSION FAILED</small><h1>${esc(g.failCard.title)}</h1><p>${esc(g.failCard.why)}</p></div>`; if (g.deathCard) cards += `<div class="card ${g.deathCard.kind}"><h1>${g.deathCard.kind === 'wasted' ? 'WASTED' : 'BUSTED'}</h1><p>${esc(g.deathCard.text || '')}</p></div>`;
    set('cards', q('#cards'), cards, true);
    // banter
    const bn = q('#banter'); if (g.banter && g.banter.t > 0) { g.banter.t -= dt; set('ban', bn, `<b style="color:${g.banter.color}">${esc(g.banter.who)}</b> ${esc(g.banter.text)}`, true); bn.style.display = 'block'; } else bn.style.display = 'none';
    // dialogue
    const cut = q('#cut'); if (g.cut && g.state !== 'menu') {
      cut.style.display = 'block'; const L = g.cut.lines[g.cut.i]; g.cut.t += dt; const n = Math.floor(g.cut.t * 55); $('.dlg b', cut).textContent = L[0]; $('.dlg p', cut).textContent = L[1].slice(0, n); g.cut.typed = n >= L[1].length;
    } else cut.style.display = 'none';
    // dbg
    const dbg = q('#dbg'); if (g.settings.debug) { dbg.style.display = 'block'; dbg.textContent = `${g.fps} fps · ent ${g.actors.filter((a) => a.on).length}A ${g.vehicles.filter((v) => v.on).length}V · chunks ${g.world.chunks.size} · parts ${g.parts.a.filter((x) => x.on).length} · pos ${p.x | 0},${p.y | 0} · q ${g.settings.quality}`; } else dbg.style.display = 'none';
    drawMinimap();
  };
  q('#photoui').style.display = 'none';
  U.photoUI = (on) => { q('#photoui').style.display = on ? 'block' : 'none'; };

  function drawMinimap() {
    const css = mm.clientWidth || 180, S = Math.round(css * Math.min(2, g.dpr)), c = mctx; if (mm.width !== S) { mm.width = S; mm.height = S; }
    const p = g.scene ? { x: g.scene.building.door.x, y: g.scene.building.door.y, a: g.player.a } : g.player, R = S / 2, sc = S / 200 * 2.4; c.clearRect(0, 0, S, S); c.save(); c.beginPath(); c.arc(R, R, R - 2, 0, 6.3); c.clip(); c.fillStyle = '#0a1018'; c.fillRect(0, 0, S, S);
    c.translate(R, R); const rot = g.settings.rotMap ? -p.a - Math.PI / 2 : 0; c.rotate(rot); c.scale(sc, sc); c.imageSmoothingEnabled = false;
    c.drawImage(g.overview, -p.x / TS, -p.y / TS);
    { const ptx = p.x / TS, pty = p.y / TS, bxa = Math.floor((ptx - 105) / 16), bxb = Math.floor((ptx + 105) / 16), bya = Math.floor((pty - 105) / 16), byb = Math.floor((pty + 105) / 16);
      for (let by = bya; by <= byb; by++) for (let bx = bxa; bx <= bxb; bx++) { if (bx >= 0 && by >= 0 && bx < NB && by < NB) continue; c.drawImage(miniCanvas(bx, by), bx * 16 - ptx, by * 16 - pty); } }
    const M = (x, y) => [(x - p.x) / TS, (y - p.y) / TS];
    for (const m of g.markers) { const [x, y] = M(m.x, m.y); c.fillStyle = m.color; c.beginPath(); c.arc(x, y, m.kind === 'foe' ? 1.4 : 2.4, 0, 6.3); c.fill(); }
    if (g.waypoint) { const [x, y] = M(g.waypoint.x, g.waypoint.y); c.strokeStyle = '#7cff4f'; c.lineWidth = 0.8; c.beginPath(); c.arc(x, y, 2.5, 0, 6.3); c.stroke(); }
    const flash = Math.floor(g.time * 4) % 2;
    for (const v of g.vehicles) if (v.on && v.siren && v.def.siren) { const [x, y] = M(v.x, v.y); c.fillStyle = flash ? '#ff3344' : '#3a7bff'; c.beginPath(); c.arc(x, y, 1.6, 0, 6.3); c.fill(); }
    for (const a of g.actors) if (a.on && !a.dead && (a.st === 'combat' && a.fac !== 'civ') && a.inside === null) { const [x, y] = M(a.x, a.y); c.fillStyle = a.fac === 'pd' ? '#4aa8ff' : '#ff3b5c'; c.fillRect(x - 0.7, y - 0.7, 1.4, 1.4); }
    if (g.blipEvent && g.blipEvent.t > 0) { const [x, y] = M(g.blipEvent.x, g.blipEvent.y); c.strokeStyle = '#ffb347'; c.lineWidth = 0.7; c.beginPath(); c.arc(x, y, 3 + flash, 0, 6.3); c.stroke(); }
    if (g.heli.on) { const [x, y] = M(g.heli.x, g.heli.y); c.fillStyle = '#fff'; c.fillRect(x - 1.5, y - 1.5, 3, 3); }
    c.restore(); c.save(); c.translate(R, R); c.rotate(g.settings.rotMap ? -Math.PI / 2 : p.a); c.fillStyle = '#4fe0ff'; c.strokeStyle = '#fff'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(9, 0); c.lineTo(-6, 6); c.lineTo(-3, 0); c.lineTo(-6, -6); c.closePath(); c.fill(); c.stroke(); c.restore();
    c.strokeStyle = '#4fe0ff88'; c.lineWidth = 3; c.beginPath(); c.arc(R, R, R - 2, 0, 6.3); c.stroke();
  }
  extendUI(g, U, { modal, q, $, esc, hud });
  const baseUpdate = U.update; U.update = (dt) => { baseUpdate(dt); if (U.tick) U.tick(dt); };
  U.hud = hud; return U;
}

// ---------- procedural news ----------
export function makeHeadlines(g) {
  const out = [], w = g.world, p = g.player, dn = (x, y) => DISTRICT_NAMES[w.districtAt(x, y)];
  for (const n of g.newsLog.slice(-6).reverse()) {
    if (n.k === 'crime') out.push(pick([`Gunfire rattles ${DISTRICT_NAMES[n.d] || 'the city'}; witnesses describe a lone figure in a ${g.look.shirt === '#d32f2f' ? 'red' : 'dark'} jacket`, `Police hunt suspect after "${n.arg}" in ${DISTRICT_NAMES[n.d] || 'Meridian'}`]));
    else if (n.k === 'carjack') out.push(`Carjacker terrorises ${DISTRICT_NAMES[n.d] || 'the streets'}; victim calls thief "weirdly polite"`);
    else if (n.k === 'mission') out.push(`Daring "${n.arg}" job leaves detectives baffled — Ledger sources point to a ghost with a pistol`);
    else if (n.k === 'turf') out.push(`${(GANGS.find((x) => x.id === n.arg) || {}).name || 'A gang'} seize another block as turf war reshapes the map`);
    else if (n.k === 'war') out.push('Gang tensions boil over: residents told to stay indoors');
  }
  if (g.stats.civKills > 0) out.push(`Pedestrian toll climbs to ${g.stats.civKills} as drivers ignore crosswalks`);
  if (g.stats.vehiclesDestroyed > 0) out.push(`Insurers report ${g.stats.vehiclesDestroyed} wrecked vehicles — "Port Meridian is a stress test," says actuary`);
  if (g.wanted.stars >= 3) out.push('Helicopters over the city as manhunt enters its most intense hour');
  if (g.env.weather === 'rain' || g.env.weather === 'storm') out.push('Storm warning: lightning over the harbor, roads slick — drive like your car is borrowed');
  if (g.env.weather === 'fog') out.push('Dense fog blankets the docks; cranes reported "missing" by the harbor authority');
  let hi = 0, hb = -1; for (let i = 0; i < 121; i++) if (w.heat[i] > hi) { hi = w.heat[i]; hb = i; }
  if (hb >= 0 && hi > 10) out.push(`${DISTRICT_NAMES[w.districtOf(Math.floor(hb / NB), hb % NB)]} named Meridian's most dangerous district`);
  if (g.story.done.m7) out.push('Meridian Savings vault cracked for the second time in three years; manager "legitimately offended"');
  if (g.story.complete) out.push('Port Meridian exhales: the waterfront war is over');
  out.push(`Cranes at the docks hit record shipments; mayor ${dn(p.x, p.y) ? 'cuts ribbon, ribbon cuts back' : ''}`, 'Local man builds ten-foot sculpture of a burger; neighbours "concerned, but hungry"', 'Weather: neon with a chance of more neon');
  return out.slice(0, 8);
}
export function pickBanter(g) {
  const st = STATIONS[g.audio.station]; if (!st) return null;
  const r = Math.random();
  if (r < 0.35) return { who: 'AD', text: pick(ADS), color: '#ffe14a', jingle: true };
  const heads = makeHeadlines(g);
  return { who: st.dj, text: r < 0.7 ? pick(DJ_LINES) : 'Breaking: ' + heads[0], color: st.color };
}
