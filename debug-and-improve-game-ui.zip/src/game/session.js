// ===== session.js — everything that makes a refresh invisible =====
// snapshotExtras(g)  : live state that the basic save never had — vehicles around you (incl. the one you are driving), interior position,
//                      wanted level, waypoint, custom map pins, radio, camera zoom, per-block heat, destroyed authored props,
//                      the visited-places log and the journal.
// restoreExtras(g,d) : puts all of it back.  Everything else (terrain, buildings, names, people's looks…) is a pure function of the
//                      seed and is therefore regenerated bit-identically (see genome.js / terra*.js).
import { spawnVehicle, seat } from './actors.js';
import { setStars } from './wanted.js';
import { MISSIONS } from './data.js';
import { startMission } from './missions.js';

const r1 = (v) => Math.round(v * 10) / 10;
const stamp = (g) => `Day ${g.env.day} · ${String(Math.floor(g.env.hour)).padStart(2, '0')}:${String(Math.floor((g.env.hour % 1) * 60)).padStart(2, '0')}`;

export function snapshotExtras(g) {
  const p = g.player, w = g.world;
  const list = g.vehicles.filter((v) => v.on && !v.wreck && !v.mis && (v === p.veh || v.owned || (!v.driver && v.ai === 'none' && Math.hypot(v.x - p.x, v.y - p.y) < 1100)));
  list.sort((a, b) => (b === p.veh) - (a === p.veh) || b.owned - a.owned || Math.hypot(a.x - p.x, a.y - p.y) - Math.hypot(b.x - p.x, b.y - p.y));
  const vl = list.slice(0, 32);
  const heat = []; for (let i = 0; i < w.heat.length; i++) if (w.heat[i] > 4) heat.push([i, Math.round(w.heat[i])]);
  const heatS = []; for (const [k, v] of w.heatS) if (v > 4) heatS.push([k, Math.round(v)]);
  const cdead = []; for (const q of w.props) if (q.dead && q.t !== 'shard') cdead.push(q.id);
  const b = g.scene ? g.scene.building : null;
  return {
    veh: vl.map((v) => ({ t: v.type, c: v.color, u: v.upg, pl: v.plate, x: r1(v.x), y: r1(v.y), a: Math.round(v.a * 1000) / 1000, hp: Math.round(v.hp), o: v.owned ? 1 : 0, h: v.hot ? 1 : 0, vx: r1(v.vx), vy: r1(v.vy), fl: v.flat ? 1 : 0 })),
    inVeh: p.veh ? vl.indexOf(p.veh) : -1,
    inside: b && b.door ? { dx: b.door.x, dy: b.door.y, ix: r1(p.x), iy: r1(p.y) } : null,
    wanted: { s: g.wanted.stars, e: Math.round(g.wanted.evade * 100) / 100 },
    wp: g.waypoint ? { x: Math.round(g.waypoint.x), y: Math.round(g.waypoint.y) } : null,
    pins: g.pins || [], radio: { s: g.audio.station, on: !!g.audio.radioOn }, zoom: g.cam.zoom, stam: Math.round(p.stam), pa: Math.round(p.a * 100) / 100,
    heat, heatS, cdead, visited: g.visited || {}, journal: (g.journal || []).slice(-250), curArea: g.curArea || '', loc: g.curArea || '', mv: g.mapView || null, mission: g.mission ? g.mission.def.id : null, newsLog: g.newsLog.slice(-14),
  };
}

/** called by loadGame after the base state has been restored and the player placed at (x,y) */
export function restoreExtras(g, d) {
  const p = g.player, w = g.world;
  g.pins = Array.isArray(d.pins) ? d.pins : []; g.visited = d.visited && typeof d.visited === 'object' ? d.visited : {}; g.journal = Array.isArray(d.journal) ? d.journal : []; g.curArea = d.curArea || ''; g.mapView = d.mv || null;
  if (Array.isArray(d.newsLog)) g.newsLog = d.newsLog;
  if (d.wp && Number.isFinite(d.wp.x)) g.waypoint = { x: d.wp.x, y: d.wp.y };
  if (Array.isArray(d.cdead)) for (const id of d.cdead) { const q = w.props[id]; if (q) q.dead = true; }
  for (const [i, v] of d.heat || []) if (i >= 0 && i < w.heat.length) w.heat[i] = v; for (const [k, v] of d.heatS || []) w.heatS.set(k, v);
  if (d.radio && g.audio) { g.audio.station = d.radio.s; g.audio.radioOn = !!d.radio.on && d.radio.s >= 0; }
  if (Number.isFinite(d.zoom)) g.cam.zoom = Math.min(2.2, Math.max(0.45, d.zoom));
  if (Number.isFinite(d.stam)) p.stam = d.stam;
  // vehicles (parked cars nearby, owned cars, and the one you were driving)
  const spawned = [];
  for (const o of (d.veh || d.owned || [])) {
    const v = spawnVehicle(g, o.t, o.x, o.y, o.a, { owned: !!(o.o || d.owned), hot: o.h !== undefined ? !!o.h : true, color: o.c, upg: o.u, plate: o.pl, ai: 'none' });
    if (v) { v.hp = o.hp; if (o.vx) { v.vx = o.vx; v.vy = o.vy; } if (o.fl) v.flat = true; if (!(o.o || d.owned) && o.h === 0) v.hot = false; }
    spawned.push(v || null);
  }
  const drive = d.inVeh >= 0 ? spawned[d.inVeh] : null;
  if (drive) { p.x = p.px = drive.x; p.y = p.py = drive.y; p.a = drive.a; seat(g, p, drive); }
  else if (Number.isFinite(d.pa)) p.a = d.pa;
  // wanted level
  if (d.wanted && d.wanted.s > 0) { setStars(g, d.wanted.s); g.wanted.seen = false; g.wanted.unseen = (d.wanted.e || 0) * 6; }
  // interior
  if (d.inside && !drive) {
    const q = []; w.buildingsNear(d.inside.dx - 48, d.inside.dy - 48, d.inside.dx + 48, d.inside.dy + 48, q);
    const b = q.find((z) => z.door && Math.abs(z.door.x - d.inside.dx) < 6 && Math.abs(z.door.y - d.inside.dy) < 6 && z.interior);
    if (b && g.enterBuilding) {
      g.enterBuilding(b);
      setTimeout(() => { if (g.scene && g.scene.building === b) { const sx = d.inside.ix, sy = d.inside.iy; if (!g.scene.solidAt(sx, sy)) { p.x = p.px = sx; p.y = p.py = sy; g.cam.x = g.cam.px = sx; g.cam.y = g.cam.py = sy; } } }, 420);
    }
  }
  // active story mission: restart it from its beginning (its entity graph cannot be serialised safely)
  const def = d.mission ? MISSIONS.find((m) => m.id === d.mission) : null;
  if (def && !g.story.done[def.id]) { startMission(g, def); g.toast('Checkpoint — mission restarted: ' + def.title, '#ffe14a'); }
  else if (!g.story.done.m1) startMission(g, MISSIONS[0]);
}

/** area tracking → visited log, journal and the "entering …" banner.  Call ~once per second while playing. */
export function trackVisit(g) {
  const p = g.player; if (g.scene || p.dead) return;
  let name = ''; try { name = g.world.areaName(p.x, p.y); } catch (e) { return; }
  if (!name || name === g.curArea) return;
  g.curArea = name; g.visited = g.visited || {}; g.journal = g.journal || [];
  let e = g.visited[name];
  if (!e) {
    e = g.visited[name] = { c: 0, f: stamp(g), x: Math.round(p.x), y: Math.round(p.y) };
    g.journal.push({ t: stamp(g), k: 'area', text: 'Discovered ' + name, x: e.x, y: e.y });
    const keys = Object.keys(g.visited); if (keys.length > 600) { keys.sort((a, b) => g.visited[a].c - g.visited[b].c); for (let i = 0; i < 80; i++) delete g.visited[keys[i]]; }
  }
  e.c++; e.l = stamp(g); g.areaBanner = { text: name, sub: e.c === 1 ? 'NEW AREA DISCOVERED' : 'VISIT #' + e.c, t: 3.6 };
}
export function journalAdd(g, k, text, x, y) { g.journal = g.journal || []; g.journal.push({ t: stamp(g), k, text, x: x === undefined ? Math.round(g.player.x) : x, y: y === undefined ? Math.round(g.player.y) : y }); if (g.journal.length > 300) g.journal.splice(0, g.journal.length - 300); }
