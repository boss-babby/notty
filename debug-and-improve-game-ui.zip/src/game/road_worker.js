// ===== road_worker.js — background routing of the procedural road network =====
// Runs the same pure Terra code as the main thread (seed + the authored core's tiles are the only inputs), so the roads that come back are
// bit-identical to what a synchronous call would produce.  Cells are computed one at a time and posted as they finish, so the main thread
// never pays the 10–20 ms A* spike while streaming.
import { Terra } from './terra.js';

let terra = null, queue = [], busy = false;
function pump() {
  if (busy) return; busy = true;
  const step = () => {
    const job = queue.shift();
    if (!job || !terra) { busy = false; return; }
    const m = terra.computeCell(job[0], job[1]);
    postMessage({ t: 'cell', ci: job[0], cj: job[1], ent: [...m] });
    if (terra.routes.size > 6000) terra.routes.clear();
    setTimeout(step, 0); // yield so newer 'cells' requests (the player moved) can re-prioritise the queue
  };
  step();
}
self.onmessage = (e) => {
  const m = e.data;
  if (m.t === 'init') { terra = new Terra(m.seed, m.K); terra.core = { tiles: m.tiles, meta: m.meta }; }
  else if (m.t === 'cells') { queue = m.list; pump(); }
};
