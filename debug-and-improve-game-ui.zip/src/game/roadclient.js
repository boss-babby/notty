// Vite inlines the worker as a blob (the build is a single self-contained index.html).
import RoadWorker from './road_worker.js?worker&inline';
export const makeRoadWorker = () => new RoadWorker();
