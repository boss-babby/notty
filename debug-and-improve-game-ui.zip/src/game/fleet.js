// ===== fleet.js — v8: drivable TANKS / APCs and WATER vehicles (jet ski, speedboat, sea cruiser, gunboat, container ship, cruise liner) =====
// They live in the same entity list as aircraft (g.choppers / p.heli) so boarding (E), camera, damage, crashes, HUD, lights and parking spots are shared.
//   def.ground === 'tank'  → tracked / wheeled armour: W/S drive, A/D steer, turret follows the mouse, LMB = main gun (APC: machine gun), RMB = coax MG. Crushes peds, props and cars.
//   def.ground === 'boat'  → hulls that only float on water: W/S throttle, A/D rudder (heavier hulls turn slowly), gunboat has deck gun + MG.
import { T } from './world.js';
import { P } from './fx.js';
import { clamp, rnd, rotToward, TAU } from './util.js';
import { crime } from './wanted.js';
import { damageActor, damageVehicle, damageProp } from './combat.js';
import { FLEET, hullPoints } from './fleetgen.js';

export { FLEET };

export function groundState(def) { return { sp: 0, thr: 0, tur: 0, tread: 0, recoil: 0, mcool: 0, bank: 0, wk: 0, hintT: 8, ai: null, aiT: 0 }; }

const shade = (hex, k) => { const n = parseInt(hex.slice(1), 16), f = (v) => Math.max(0, Math.min(255, Math.round(v + (k < 0 ? v * k : (255 - v) * k)))); return '#' + [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => f(v).toString(16).padStart(2, '0')).join(''); };
const rr = (c, x, y, w, h, r) => { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); };

// ---------- placement helpers ----------
export function hullClear(g, def, x, y, a, margin = 0) {
  const w = g.world;
  if (def.hull) { for (const [px, py] of hullPoints(def, x, y, a, margin)) if (w.tileAt(px, py) !== T.WATER) return false; return true; }
  for (const [px, py] of hullPoints(def, x, y, a, 0)) { const t = w.tileAt(px, py); if (t === T.BUILDING || t === T.WATER) return false; }
  return !w.pushCircle(x, y, def.wid * 0.5, true).hit;
}
/** find a free patch near the player where a ground/water vehicle can be placed (boats need open water) */
export function findGroundSpot(g, def) {
  const p = g.player, base = p.veh ? p.veh.a : p.a, big = def.len > 200;
  const rings = big ? [260, 420, 600, 800, 1000, 1300, 1700] : [90, 120, 160, 220, 300, 400, 520, 700, 950, 1250];
  for (const r of rings) for (let k = 0; k < 20; k++) {
    const a = base + (k % 2 ? 1 : -1) * Math.ceil(k / 2) * (TAU / 20), x = p.x + Math.cos(a) * r, y = p.y + Math.sin(a) * r;
    for (let h = 0; h < 8; h++) { const ha = a + h * Math.PI / 4; if (hullClear(g, def, x, y, ha, def.hull ? 10 : 0)) return { x, y, a: ha }; }
  }
  return null;
}

// ---------- control ----------
function aimAngle(g, c) {
  const inp = g.input, p = g.player, pad = inp.pad;
  if (pad.aimActive) return Math.atan2(pad.ay, pad.ax);
  if (inp.touch && !(performance.now() - (inp.moveT || 0) < 2500)) {
    let best = null, bd = 760; for (const a of g.actors) { if (!a.on || a.dead || a.fac === 'civ' || a.fac === 'pl' || a === p || a.inside) continue; if (g.zm ? a.fac !== 'zom' : a.st !== 'combat') continue; const d = Math.hypot(a.x - c.x, a.y - c.y); if (d < bd) { bd = d; best = a; } }
    return best ? Math.atan2(best.y - c.y, best.x - c.x) : c.a;
  }
  const mw = g.mouseWorld(); return Math.atan2(mw.y - c.y, mw.x - c.x);
}
function fireGuns(g, c, dt, ang, own) {
  const d = c.def, inp = g.input; c.mcool -= dt; c.cool -= dt; c.recoil = Math.max(0, c.recoil - dt * 4);
  if (g.uiOpen) return;
  const ca = Math.cos(ang), sa = Math.sin(ang), muz = d.len * (d.apc ? 0.34 : d.hull ? 0.2 : 0.55);
  if (d.cannon && inp.down('fire') && c.cool <= 0) {
    c.cool = d.hull ? 1.6 : 2.0; c.recoil = 1; c.flash = 0.1;
    g.bullets.spawn({ x: c.x + ca * muz, y: c.y + sa * muz, vx: ca * 1150, vy: sa * 1150, dmg: 330, owner: own, ownerV: null, fac: 'pl', life: 1500, kind: 'rk', rad: 120 });
    g.audio.sfx('rocket', c.x, c.y, 0.9); g.audio.sfx('explosion', c.x, c.y, 0.25); g.noise(c.x, c.y, 1500, { by: own }); g.combatT = 8; crime(g, 'shots', c.x, c.y); g.cam.shake = Math.max(g.cam.shake, 9);
    g.cam.kx -= ca * 16; g.cam.ky -= sa * 16; g.parts.burst(P.SMOKE, c.x + ca * muz, c.y + sa * muz, 8, 90, 0.9, 7, '#bbb'); g.tmpLights.push({ x: c.x + ca * muz, y: c.y + sa * muz, r: 220, col: '#ffd27a', life: 0.1, max: 0.1, i: 1 });
  }
  const mgKey = d.cannon ? (inp.down('aim') || inp.down('rocket')) : inp.down('fire');
  if (d.mg && mgKey && c.mcool <= 0) {
    c.mcool = 0.075; c.mgT = (c.mgT || 0) + 1; c.flash = Math.max(c.flash, 0.04); const aa = ang + (Math.random() - 0.5) * 0.06, mz = d.cannon ? 22 : muz;
    g.bullets.spawn({ x: c.x + Math.cos(aa) * mz, y: c.y + Math.sin(aa) * mz, vx: Math.cos(aa) * 2100, vy: Math.sin(aa) * 2100, dmg: 24, owner: own, ownerV: null, fac: 'pl', life: 900, kind: 'b', rad: 0 });
    if (c.mgT % 2 === 0) { g.audio.sfx('rifle', c.x, c.y, 0.55); g.noise(c.x, c.y, 1000, { by: own }); g.combatT = 6; crime(g, 'shots', c.x, c.y); }
    g.parts.emit(P.SHELL, c.x, c.y, Math.cos(aa + 1.6) * 80, Math.sin(aa + 1.6) * 80, 0.6, 3, '#d9b34a'); g.cam.shake = Math.max(g.cam.shake, 1.6);
  }
}
export function controlGround(g, c, dt, H) { if (c.def.ground === 'tank') controlTank(g, c, dt); else controlBoat(g, c, dt, H); }

function controlTank(g, c, dt) {
  const p = g.player, inp = g.input, d = c.def, mv = inp.move();
  g.aiming = false; p.x = c.x; p.y = c.y; p.inside = null; c.hintT = Math.max(0, c.hintT - dt); c.flash = Math.max(0, c.flash - dt);
  const fwd = -mv.y, tgt = fwd * d.vmax * (fwd < 0 ? 0.5 : 1);
  c.sp += (tgt - c.sp) * (1 - Math.exp(-(d.acc / d.vmax) * (Math.abs(fwd) > 0.05 ? 1.6 : 2.6) * dt)); if (inp.down('hbrake') || inp.down('jump')) c.sp *= Math.exp(-5 * dt);
  const turnK = 0.55 + 0.45 * clamp(Math.abs(c.sp) / 60, 0, 1);
  c.a += mv.x * d.turn * turnK * dt * (c.sp < -5 ? -1 : 1); c.bank += (mv.x * 0.2 - c.bank) * Math.min(1, dt * 4);
  c.rpm = 0; c.thr = Math.abs(fwd);
  moveTank(g, c, dt);
  const aim = aimAngle(g, c); c.tur = rotToward(c.tur, aim, (d.apc ? 3.2 : 2.3) * dt);
  fireGuns(g, c, dt, c.tur, p);
  c.tread += c.sp * dt * 0.09;
  engineFx(g, c, dt);
}
function moveTank(g, c, dt) {
  const d = c.def, w = g.world, ca = Math.cos(c.a), sa = Math.sin(c.a), sp = c.sp;
  c.vx = ca * sp; c.vy = sa * sp; let nx = c.x + c.vx * dt, ny = c.y + c.vy * dt;
  const lead = (sp >= 0 ? 1 : -1) * d.len * 0.5, wt = w.tileAt(nx + ca * lead, ny + sa * lead);
  if (wt !== T.WATER) {
    let cx = 0, cy = 0; for (const o of [-d.len * 0.3, 0, d.len * 0.3]) { const px = nx + ca * o, py = ny + sa * o, r = g.pushCircle(px, py, d.wid * 0.42, false); cx += r.x - px; cy += r.y - py; }
    if (Math.hypot(cx, cy) > 0.8) { nx += cx; ny += cy; if (Math.hypot(cx, cy) > 2.5) c.sp *= Math.exp(-4 * dt); }
  }
  if (wt === T.WATER) c.sp *= Math.exp(-8 * dt); else { c.x = nx; c.y = ny; }
  if (d.crush && Math.abs(c.sp) > 18) crushStuff(g, c, dt);
}
function crushStuff(g, c, dt) {
  const d = c.def, p = g.player, ca = Math.cos(c.a), sa = Math.sin(c.a), driven = c.driver === p;
  g._cq = g._cq || []; g._cq.length = 0; g.hashA.query(c.x, c.y, d.len * 0.62 + 30, g._cq);
  for (const a of g._cq) {
    if (!a.on || a.dead || a === p || a.veh || a.heli || a.inside !== null) continue;
    const dx = a.x - c.x, dy = a.y - c.y, f = dx * ca + dy * sa, l = -dx * sa + dy * ca;
    if (Math.abs(f) < d.len * 0.5 + 4 && Math.abs(l) < d.wid * 0.5 + 6) { damageActor(g, a, 260, { by: driven ? p : null, kind: 'crush', dx: ca * c.sp, dy: sa * c.sp }); a.kx += ca * c.sp * 1.2; a.ky += sa * c.sp * 1.2; g.audio.sfx('thud', a.x, a.y, 0.6); }
  }
  g._cv = g._cv || []; g._cv.length = 0; g.hashV.query(c.x, c.y, d.len * 0.7 + 50, g._cv);
  for (const v of g._cv) {
    if (!v.on || v.wreck) continue; const dx = v.x - c.x, dy = v.y - c.y, f = dx * ca + dy * sa, l = -dx * sa + dy * ca;
    if (Math.abs(f) < d.len * 0.5 + v.def.len * 0.45 && Math.abs(l) < d.wid * 0.5 + v.def.wid * 0.5) {
      damageVehicle(g, v, Math.abs(c.sp) * dt * (d.hull ? 6 : 14) + 6, { by: driven ? p : null, fac: 'pl' }); const s = Math.abs(c.sp) * dt * 6.6; v.vx += ca * Math.sign(c.sp) * s + (l >= 0 ? -sa : sa) * s * 0.6; v.vy += sa * Math.sign(c.sp) * s + (l >= 0 ? ca : -ca) * s * 0.6;
      if (!v._cr || g.time - v._cr > 0.5) { v._cr = g.time; g.audio.sfx('crash', v.x, v.y, 0.6); g.cam.shake = Math.max(g.cam.shake, 5); g.parts.burst(P.SPARK, v.x, v.y, 4, 180, 0.3, 2, '#ffd27a'); }
    }
  }
  if (!d.hull) {
    g._cp = g._cp || []; g._cp.length = 0; g.world.propHash.query(c.x + ca * d.len * 0.3, c.y + sa * d.len * 0.3, d.len * 0.5 + 20, g._cp);
    for (const q of g._cp) if (!q.dead && q.solid && q.hp < 1e8 && Math.hypot(q.x - c.x, q.y - c.y) < d.len * 0.55 + q.r) damageProp(g, q, 400, { by: driven ? p : null });
  }
}
function engineFx(g, c, dt) {
  const d = c.def, ca = Math.cos(c.a), sa = Math.sin(c.a), sp = Math.abs(c.sp);
  if (sp > 20 && Math.random() < dt * 14) { const t = g.world.tileAt(c.x, c.y), col = t === T.SAND || t === T.DESERT ? '#d8c08a' : t === T.GRASS || t === T.FOREST || t === T.FARM || t === T.DIRT ? '#7c8561' : '#9a9a9a'; g.parts.emit(P.SMOKE, c.x - ca * d.len * 0.5 + rnd(-6, 6), c.y - sa * d.len * 0.5 + rnd(-6, 6), -ca * 20 + rnd(-12, 12), -sa * 20 + rnd(-12, 12), 0.7, 5, col); }
  if (Math.random() < dt * (3 + sp / 40)) g.parts.emit(P.SMOKE, c.x - ca * d.len * 0.46 - sa * 14, c.y - sa * d.len * 0.46 + ca * 14, rnd(-6, 6), -14, 0.9, 3.5, '#444');
  if (sp > 120 && Math.random() < 0.08) g.cam.shake = Math.max(g.cam.shake, 0.8);
}

function controlBoat(g, c, dt, H) {
  const p = g.player, inp = g.input, d = c.def, mv = inp.move();
  g.aiming = false; p.x = c.x; p.y = c.y; p.inside = null; c.hintT = Math.max(0, c.hintT - dt); c.flash = Math.max(0, c.flash - dt);
  const big = d.len > 200, fwd = -mv.y; c.thr += (fwd - c.thr) * Math.min(1, dt * (big ? 0.9 : 2.5)); if (Math.abs(fwd) < 0.05 && !big) c.thr *= Math.exp(-1.5 * dt);
  const tgt = c.thr * d.vmax * (c.thr < 0 ? 0.35 : 1);
  c.sp += (tgt - c.sp) * (1 - Math.exp(-(d.acc / d.vmax) * dt));
  if (inp.down('hbrake') || inp.down('jump')) c.sp *= Math.exp(-(big ? 0.6 : 2.2) * dt);
  const steer = mv.x * d.turn * clamp(Math.abs(c.sp) / (d.vmax * 0.22), 0.12, 1) * (c.sp < -4 ? -1 : 1);
  c.a += steer * dt; c.bank += (mv.x * clamp(c.sp / d.vmax, 0, 1) - c.bank) * Math.min(1, dt * 3); c.rpm = 0;
  sailStep(g, c, dt, H);
  if (d.cannon || d.mg) { const aim = aimAngle(g, c); c.tur = rotToward(c.tur, aim, 2.4 * dt); fireGuns(g, c, dt, c.tur, p); }
}
function sailStep(g, c, dt, H) {
  const d = c.def, ca = Math.cos(c.a), sa = Math.sin(c.a), grip = 1 - Math.exp(-(d.grip || 1.5) * dt);
  c.vx += (ca * c.sp - c.vx) * grip; c.vy += (sa * c.sp - c.vy) * grip;
  let nx = c.x + c.vx * dt, ny = c.y + c.vy * dt;
  if (!hullClear(g, d, nx, ny, c.a)) {
    const sx = hullClear(g, d, nx, c.y, c.a), sy = hullClear(g, d, c.x, ny, c.a), impact = Math.hypot(c.vx, c.vy);
    if (sx) { ny = c.y; c.vy *= -0.2; } else if (sy) { nx = c.x; c.vx *= -0.2; } else { nx = c.x; ny = c.y; c.vx *= -0.25; c.vy *= -0.25; }
    c.sp *= 0.35;
    if (impact > 50 && (!c._bumpT || g.time - c._bumpT > 0.4)) {
      c._bumpT = g.time; c.hp -= impact * (d.len > 200 ? 0.08 : 0.28); c.hitT = 0.3; g.cam.shake = Math.max(g.cam.shake, clamp(impact / 25, 3, 12)); g.audio.sfx('crash', c.x, c.y, clamp(impact / 300, 0.3, 0.9));
      g.parts.burst(P.SPARK, c.x + ca * d.len * 0.5, c.y + sa * d.len * 0.5, 6, 160, 0.3, 2, '#ffd27a'); if (c.driver) g.toast('Hull scraped the shore!', '#ff9a3c');
      if (c.hp <= 0 && !g.cheats.god && H) { H.crash(g, c); return; }
    }
  }
  c.x = nx; c.y = ny;
  const sp = Math.hypot(c.vx, c.vy); c.tread += sp * dt * 0.04;
  if (d.crush && sp > 30) crushStuff(g, c, dt);
  c.wk += (clamp(sp / d.vmax, 0, 1) - c.wk) * Math.min(1, dt * 3);
  if (sp > 40 && Math.random() < dt * (10 + sp / 12)) {
    for (const s of [-1, 1]) g.parts.emit(P.WATER, c.x + ca * d.len * 0.38 - sa * s * d.wid * 0.3, c.y + sa * d.len * 0.38 + ca * s * d.wid * 0.3, -sa * s * 60 + ca * 20 + rnd(-15, 15), ca * s * 60 + sa * 20 + rnd(-15, 15), 0.45, 2 + sp / 220, '#e6f4ff');
    g.parts.emit(P.WATER, c.x - ca * d.len * 0.5 + rnd(-8, 8), c.y - sa * d.len * 0.5 + rnd(-8, 8), -ca * 30 + rnd(-20, 20), -sa * 30 + rnd(-20, 20), 0.7, 3 + sp / 160, '#f4fbff');
  }
  if (sp > 20 && Math.random() < dt * 3) g.parts.emit(P.RING, c.x - ca * d.len * 0.3 + rnd(-d.wid, d.wid) * 0.4, c.y - sa * d.len * 0.3 + rnd(-d.wid, d.wid) * 0.4, 0, 0, 1.2, 8 + d.wid * 0.2, '#cfe8ff');
}
export function groundIdle(g, c, dt, H) {
  const d = c.def; c.flash = Math.max(0, c.flash - dt); c.sp *= Math.exp(-(d.hull ? 0.35 : 4) * dt); c.rpm = 0; c.thr = 0;
  if (d.hull) { if (Math.hypot(c.vx, c.vy) > 3 || Math.abs(c.sp) > 3) sailStep(g, c, dt, H); else { c.vx = c.vy = 0; } }
  else if (Math.abs(c.sp) > 3) { moveTank(g, c, dt); c.tread += c.sp * dt * 0.09; } else { c.vx = c.vy = 0; }
  c.recoil = Math.max(0, c.recoil - dt * 4); c.mcool -= dt; c.cool -= dt;
  // army-controlled armour fires at the infected on its own
  if (c.ai === 'army' && g.zm && !c.dead) {
    c.aiT -= dt; if (c.aiT <= 0) {
      c.aiT = 0.3; let best = null, bd = 760, near = 0;
      for (const a of g.actors) { if (!a.on || a.dead || a.fac !== 'zom' || a.inside) continue; const dd = Math.hypot(a.x - c.x, a.y - c.y); if (dd < bd) { bd = dd; best = a; } }
      c.tgt = best; if (best) for (const a of g.actors) if (a.on && !a.dead && a.fac === 'zom' && Math.hypot(a.x - best.x, a.y - best.y) < 90) near++; c.nearT = near;
    }
    if (c.tgt && !c.tgt.dead && c.tgt.on) {
      const ang = Math.atan2(c.tgt.y - c.y, c.tgt.x - c.x); c.tur = rotToward(c.tur, ang, 2 * dt); const dd = Math.abs(Math.atan2(Math.sin(c.tur - ang), Math.cos(c.tur - ang))), ok = dd < 0.2, ca = Math.cos(c.tur), sa = Math.sin(c.tur), muz = d.len * 0.5;
      if (ok && d.cannon && c.cool <= 0 && c.nearT >= 3) { c.cool = 3.4; c.recoil = 1; c.flash = 0.1; g.bullets.spawn({ x: c.x + ca * muz, y: c.y + sa * muz, vx: ca * 1100, vy: sa * 1100, dmg: 330, owner: null, ownerV: null, fac: 'pd', life: 1000, kind: 'rk', rad: 120 }); g.audio.sfx('rocket', c.x, c.y, 0.8); }
      if (ok && d.mg && c.mcool <= 0) { c.mcool = 0.12; c.flash = Math.max(c.flash, 0.04); const aa = c.tur + (Math.random() - 0.5) * 0.07; g.bullets.spawn({ x: c.x + Math.cos(aa) * 26, y: c.y + Math.sin(aa) * 26, vx: Math.cos(aa) * 2000, vy: Math.sin(aa) * 2000, dmg: 22, owner: null, ownerV: null, fac: 'pd', life: 800, kind: 'b', rad: 0 }); if (Math.random() < 0.4) g.audio.sfx('rifle', c.x, c.y, 0.45); }
    }
  }
}

// ---------- boarding / exit ----------
export function exitGround(g, c) {
  const p = g.player, d = c.def, w = g.world;
  if (Math.hypot(c.vx, c.vy) > (d.hull ? 170 : 90)) { g.toast('Slow down before getting out', '#ff9a3c'); g.audio.sfx('error'); return false; }
  const ca = Math.cos(c.a), sa = Math.sin(c.a); let pos = null;
  const radii = [d.wid / 2 + 16, d.wid / 2 + 36, d.wid / 2 + 70, d.wid / 2 + 110, d.exitR || 130];
  for (const r of radii) for (const off of [0, 0.3, -0.3, 0.45, -0.45, 0.15, -0.15]) for (let k = 0; k < 16 && !pos; k++) {
    const a = c.a + (k % 2 ? 1 : -1) * Math.ceil(k / 2) * (TAU / 16), x = c.x + ca * off * d.len + Math.cos(a) * r, y = c.y + sa * off * d.len + Math.sin(a) * r, t = w.tileAt(x, y);
    if (t !== T.BUILDING && t !== T.WATER && !w.solid(x, y) && !w.pushCircle(x, y, 9, true).hit) pos = { x, y };
  }
  if (!pos) { g.toast(d.hull ? 'No dock or shore in reach — sail closer to land' : 'No room to get out here', '#ff7788'); g.audio.sfx('error'); return false; }
  p.heli = null; c.driver = null; g.chopper = null; p.x = p.px = pos.x; p.y = p.py = pos.y; p.vx = p.vy = 0; p.a = Math.atan2(pos.y - c.y, pos.x - c.x); g.audio.sfx('door', c.x, c.y, 0.6);
  return true;
}

// ---------- drawing ----------
export function drawGround(g, c, h) {
  c.save(); c.translate(h.x, h.y);
  if (h.def.ground === 'tank') drawTank(g, c, h); else drawBoat(g, c, h);
  c.restore();
}
function drawTank(g, c, h) {
  const d = h.def, L = d.len, Wd = d.wid, body = h.color, dark = '#1b1d19', apc = !!d.apc;
  c.save(); c.rotate(h.a + h.bank * 0.1);
  c.fillStyle = 'rgba(0,0,0,.28)'; rr(c, -L / 2 + 5, -Wd / 2 + 5, L, Wd, 8); c.fill();
  if (!apc) {
    for (const s of [-1, 1]) { const y = s * (Wd / 2 - 7) - 7; c.fillStyle = dark; rr(c, -L / 2, y, L, 14, 5); c.fill(); c.fillStyle = '#34372f'; rr(c, -L / 2 + 3, y + 2, L - 6, 10, 3); c.fill(); c.strokeStyle = '#55584d'; c.lineWidth = 1.4; for (let i = 0; i < 12; i++) { const x = -L / 2 + 4 + ((((i * 7.6 + h.tread) % (L - 8)) + (L - 8)) % (L - 8)); c.beginPath(); c.moveTo(x, y + 2); c.lineTo(x, y + 12); c.stroke(); } c.fillStyle = '#25271f'; for (const x of [-0.36, -0.12, 0.12, 0.36]) { c.beginPath(); c.arc(x * L, y + 7, 4.4, 0, TAU); c.fill(); } }
    c.fillStyle = body; rr(c, -L / 2 + 5, -Wd / 2 + 11, L - 9, Wd - 22, 6); c.fill(); c.fillStyle = shade(body, -0.2); c.beginPath(); c.moveTo(L / 2 - 4, -Wd / 2 + 13); c.lineTo(L / 2 + 2, -Wd / 2 + 17); c.lineTo(L / 2 + 2, Wd / 2 - 17); c.lineTo(L / 2 - 4, Wd / 2 - 13); c.closePath(); c.fill();
    c.fillStyle = shade(body, -0.28); for (let i = 0; i < 5; i++) c.fillRect(-L / 2 + 8, -Wd / 2 + 14 + i * 4.6, 12, 2.2); c.fillStyle = shade(body, 0.12); for (let i = 0; i < 4; i++) { c.beginPath(); c.ellipse(-L * 0.18 + i * 13, ((i * 37) % 7) - 3, 7, 4, i, 0, TAU); c.fill(); }
  } else {
    c.fillStyle = dark; for (const s of [-1, 1]) for (let i = 0; i < 4; i++) { const x = -L * 0.36 + i * L * 0.24; rr(c, x - 6, s * (Wd / 2 - 3) - 4, 12, 8, 3); c.fill(); c.fillStyle = '#3a3d34'; c.beginPath(); c.arc(x, s * (Wd / 2 - 3), 2.4, 0, TAU); c.fill(); c.fillStyle = dark; }
    c.fillStyle = body; rr(c, -L / 2 + 2, -Wd / 2 + 5, L - 4, Wd - 10, 7); c.fill(); c.fillStyle = shade(body, -0.18); c.beginPath(); c.moveTo(L / 2 - 14, -Wd / 2 + 6); c.lineTo(L / 2 - 2, -Wd / 2 + 11); c.lineTo(L / 2 - 2, Wd / 2 - 11); c.lineTo(L / 2 - 14, Wd / 2 - 6); c.closePath(); c.fill();
    c.fillStyle = '#26323a'; rr(c, L / 2 - 20, -Wd / 2 + 11, 9, 5, 2); c.fill(); rr(c, L / 2 - 20, Wd / 2 - 16, 9, 5, 2); c.fill(); c.fillStyle = shade(body, 0.12); rr(c, -L / 2 + 8, -Wd / 2 + 9, L * 0.34, Wd - 18, 3); c.fill(); c.fillStyle = shade(body, -0.3); c.fillRect(-L / 2 + 6, -3, 3, 6);
  }
  c.restore();
  c.save(); c.rotate(h.tur); const rc = h.recoil * 7;
  if (!apc) {
    c.fillStyle = '#23251f'; c.fillRect(8 - rc, -2.8, L * 0.5 - 8, 5.6); c.fillStyle = '#15160f'; c.fillRect(L * 0.5 - 7 - rc, -4, 9, 8); c.fillStyle = shade(body, -0.1); c.beginPath(); c.moveTo(24, -9); c.lineTo(28, -3); c.lineTo(28, 3); c.lineTo(24, 9); c.lineTo(-4, 15); c.lineTo(-17, 11); c.lineTo(-17, -11); c.lineTo(-4, -15); c.closePath(); c.fill(); c.strokeStyle = 'rgba(0,0,0,.45)'; c.lineWidth = 1.3; c.stroke();
    c.fillStyle = shade(body, 0.15); c.beginPath(); c.arc(-6, -4, 5.4, 0, TAU); c.fill(); c.fillStyle = '#16171a'; c.beginPath(); c.arc(-6, -4, 3, 0, TAU); c.fill(); c.fillStyle = '#2b2d27'; c.fillRect(-10, 5, 9, 3); c.fillStyle = '#16171a'; c.fillRect(2, 6, 12, 2.2);
    if (h.flash > 0) { c.fillStyle = '#ffe9a0'; c.beginPath(); for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5, r = i % 2 ? 6 : 17; c.lineTo(L * 0.5 + 4 + Math.cos(a) * r, Math.sin(a) * r * 0.8); } c.closePath(); c.fill(); }
  } else {
    c.fillStyle = '#1c1e1a'; c.fillRect(6, -1.8, L * 0.34, 3.6); c.fillStyle = shade(body, -0.12); c.beginPath(); c.arc(0, 0, 11, 0, TAU); c.fill(); c.strokeStyle = 'rgba(0,0,0,.45)'; c.lineWidth = 1.2; c.stroke(); c.fillStyle = '#1b2227'; rr(c, 3, -5, 8, 10, 2); c.fill(); c.fillStyle = shade(body, 0.15); c.beginPath(); c.arc(-4, 0, 4, 0, TAU); c.fill();
    if (h.flash > 0) { c.fillStyle = '#ffe9a0'; c.beginPath(); c.arc(L * 0.34 + 8, 0, 5, 0, TAU); c.fill(); }
  }
  c.restore();
  if (h.hitT > 0) { c.fillStyle = `rgba(255,80,60,${h.hitT * 2})`; c.beginPath(); c.ellipse(0, 0, L * 0.45, Wd * 0.45, h.a, 0, TAU); c.fill(); }
}
function hullPath(c, L, W, sharp) {
  c.beginPath(); c.moveTo(L / 2, 0); c.bezierCurveTo(L * (0.5 - sharp * 0.12), W * 0.3, L * 0.22, W / 2, 0, W / 2); c.lineTo(-L / 2 + 3, W / 2 * 0.92); c.quadraticCurveTo(-L / 2 - 1, 0, -L / 2 + 3, -W / 2 * 0.92); c.lineTo(0, -W / 2); c.bezierCurveTo(L * 0.22, -W / 2, L * (0.5 - sharp * 0.12), -W * 0.3, L / 2, 0); c.closePath();
}
function drawBoat(g, c, h) {
  const d = h.def, L = d.len, W = d.wid, col = h.color, wk = h.wk || 0, bob = Math.sin(g.time * 2.2 + h.x * 0.01) * 0.6 * (1 - wk), t = d.hull;
  c.save(); c.rotate(h.a);
  if (wk > 0.04) {
    c.fillStyle = `rgba(235,248,255,${0.10 + 0.24 * wk})`;
    for (const s of [-1, 1]) { c.beginPath(); c.moveTo(L * 0.34, s * W * 0.42); c.lineTo(-L * 0.5 - wk * L * 1.1, s * (W * 0.7 + wk * W * 1.2)); c.lineTo(-L * 0.5 - wk * L * 0.5, s * W * 0.25); c.closePath(); c.fill(); }
    c.fillStyle = `rgba(245,252,255,${0.2 + 0.3 * wk})`; c.beginPath(); c.ellipse(-L * 0.5 - wk * L * 0.35, 0, wk * L * 0.5 + 6, W * 0.3, 0, 0, TAU); c.fill();
  }
  c.fillStyle = 'rgba(0,20,40,.28)'; c.save(); c.translate(3, 4 + bob); hullPath(c, L, W, t === 'jetski' ? 1 : 0.8); c.fill(); c.restore();
  if (t === 'jetski') {
    hullPath(c, L, W, 1); c.fillStyle = col; c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 1; c.stroke(); c.fillStyle = '#f5f7fa'; c.fillRect(-L * 0.4, -2, L * 0.7, 4); c.fillStyle = '#1c1f26'; rr(c, -L * 0.34, -W * 0.28, L * 0.38, W * 0.56, 3); c.fill(); c.strokeStyle = '#111'; c.lineWidth = 2; c.beginPath(); c.moveTo(L * 0.1, -W * 0.45); c.lineTo(L * 0.1, W * 0.45); c.stroke(); c.fillStyle = '#8fd0ff'; c.beginPath(); c.ellipse(L * 0.2, 0, 3, 2.6, 0, 0, TAU); c.fill();
  } else if (t === 'speed') {
    hullPath(c, L, W, 1); c.fillStyle = col; c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 1.2; c.stroke(); const ac = col === '#f5f7fa' ? '#e53935' : '#f5f7fa';
    c.fillStyle = ac; c.beginPath(); c.moveTo(L * 0.42, 0); c.lineTo(L * 0.05, -W * 0.14); c.lineTo(-L * 0.45, -W * 0.14); c.lineTo(-L * 0.45, W * 0.14); c.lineTo(L * 0.05, W * 0.14); c.closePath(); c.fill();
    c.fillStyle = '#2a2f38'; rr(c, -L * 0.3, -W * 0.3, L * 0.34, W * 0.6, 5); c.fill(); c.fillStyle = '#b7e1ff'; c.beginPath(); c.moveTo(L * 0.08, -W * 0.3); c.lineTo(L * 0.2, -W * 0.14); c.lineTo(L * 0.2, W * 0.14); c.lineTo(L * 0.08, W * 0.3); c.closePath(); c.fill(); c.fillStyle = '#d8dde6'; rr(c, -L * 0.46, -W * 0.28, 8, W * 0.56, 2); c.fill();
    c.fillStyle = '#16181d'; for (const s of [-1, 1]) { rr(c, -L / 2 - 4, s * W * 0.2 - 3, 9, 6, 2); c.fill(); }
  } else if (t === 'cruiser') {
    hullPath(c, L, W, 0.7); c.fillStyle = '#f5f7fa'; c.fill(); c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 1.3; c.stroke(); c.fillStyle = '#1d4f91'; for (const s of [-1, 1]) { c.beginPath(); c.moveTo(L * 0.3, s * W * 0.38); c.lineTo(-L * 0.46, s * W * 0.38); c.lineTo(-L * 0.46, s * W * 0.3); c.lineTo(L * 0.34, s * W * 0.3); c.fill(); }
    c.fillStyle = '#b08968'; rr(c, -L * 0.48, -W * 0.28, L * 0.2, W * 0.56, 2); c.fill(); c.fillStyle = '#e9edf2'; rr(c, -L * 0.24, -W * 0.3, L * 0.4, W * 0.6, 6); c.fill(); c.strokeStyle = 'rgba(0,0,0,.3)'; c.stroke(); c.fillStyle = '#35566f'; rr(c, L * 0.06, -W * 0.24, L * 0.08, W * 0.48, 2); c.fill(); c.fillStyle = '#c9d2dc'; rr(c, -L * 0.18, -W * 0.2, L * 0.22, W * 0.4, 4); c.fill(); c.fillStyle = '#243240'; for (const s of [-1, 1]) c.fillRect(-L * 0.2, s * W * 0.26 - 1, L * 0.34, 2);
    c.strokeStyle = '#333'; c.lineWidth = 1.2; for (const s of [-1, 1]) { c.beginPath(); c.moveTo(-L * 0.46, s * W * 0.2); c.lineTo(-L * 0.62, s * W * 0.55); c.stroke(); }
  } else if (t === 'gun') {
    hullPath(c, L, W, 0.9); c.fillStyle = col; c.fill(); c.strokeStyle = 'rgba(0,0,0,.45)'; c.lineWidth = 1.4; c.stroke(); c.fillStyle = shade(col, -0.18); c.beginPath(); c.moveTo(L * 0.42, 0); c.lineTo(L * 0.1, -W * 0.34); c.lineTo(-L * 0.46, -W * 0.34); c.lineTo(-L * 0.46, W * 0.34); c.lineTo(L * 0.1, W * 0.34); c.closePath(); c.fill();
    c.fillStyle = '#3a444e'; rr(c, -L * 0.1, -W * 0.26, L * 0.26, W * 0.52, 4); c.fill(); c.fillStyle = '#9bd0f0'; c.fillRect(L * 0.1, -W * 0.2, 3, W * 0.4); c.fillStyle = '#566472'; rr(c, -L * 0.04, -W * 0.18, L * 0.14, W * 0.36, 3); c.fill(); c.strokeStyle = '#1d2227'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(-L * 0.02, -W * 0.5); c.lineTo(-L * 0.02, W * 0.5); c.stroke();
    c.fillStyle = '#d33'; c.fillRect(-L * 0.46, -W * 0.16, 4, W * 0.32);
    c.save(); c.translate(L * 0.26, 0); c.rotate(h.tur - h.a); const rc = h.recoil * 6; c.fillStyle = '#20262c'; c.fillRect(2 - rc, -2.4, 36, 4.8); c.fillStyle = '#4b5663'; c.beginPath(); c.arc(0, 0, 10, 0, TAU); c.fill(); c.strokeStyle = 'rgba(0,0,0,.5)'; c.stroke(); if (h.flash > 0) { c.fillStyle = '#ffe9a0'; c.beginPath(); c.arc(40, 0, 7, 0, TAU); c.fill(); } c.restore();
    c.save(); c.translate(-L * 0.3, 0); c.fillStyle = '#20262c'; c.beginPath(); c.arc(0, 0, 5, 0, TAU); c.fill(); c.restore();
  } else if (t === 'ship') {
    hullPath(c, L, W, 0.35); c.fillStyle = col; c.fill(); c.strokeStyle = 'rgba(0,0,0,.5)'; c.lineWidth = 2; c.stroke(); c.fillStyle = 'rgba(255,255,255,.12)'; c.beginPath(); c.moveTo(L * 0.46, 0); c.lineTo(L * 0.2, -W * 0.5); c.lineTo(-L * 0.46, -W * 0.46); c.lineTo(-L * 0.46, W * 0.46); c.lineTo(L * 0.2, W * 0.5); c.closePath(); c.fill();
    c.fillStyle = '#4a4f55'; rr(c, -L * 0.3, -W * 0.38, L * 0.7, W * 0.76, 4); c.fill();
    const pal = ['#c0392b', '#2980b9', '#e67e22', '#27ae60', '#f1c40f', '#8e44ad', '#95a5a6', '#16a085'];
    for (let i = 0; i < 12; i++) for (let j = 0; j < 4; j++) { const x = L * 0.38 - (i + 1) * (L * 0.055), y = -W * 0.36 + j * W * 0.18; c.fillStyle = pal[(i * 3 + j * 5 + (i % 3)) % pal.length]; c.fillRect(x, y + 1, L * 0.05, W * 0.16); c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(x, y + 1, L * 0.05, 2); }
    c.fillStyle = '#e9edf2'; rr(c, -L * 0.45, -W * 0.34, L * 0.15, W * 0.68, 3); c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 1.2; c.stroke(); c.fillStyle = '#24323f'; c.fillRect(-L * 0.31, -W * 0.28, 3, W * 0.56); c.fillStyle = '#b33'; c.fillRect(-L * 0.4, -W * 0.1, 14, W * 0.2); c.fillStyle = '#16181d'; c.fillRect(-L * 0.4, -W * 0.1, 14, 4);
  } else if (t === 'liner') {
    hullPath(c, L, W, 0.5); c.fillStyle = '#f3f5f8'; c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 2; c.stroke(); c.fillStyle = '#17426e'; for (const s of [-1, 1]) { c.beginPath(); c.moveTo(L * 0.46, 0); c.lineTo(L * 0.2, s * W * 0.5); c.lineTo(-L * 0.46, s * W * 0.46); c.lineTo(-L * 0.46, s * W * 0.4); c.lineTo(L * 0.22, s * W * 0.44); c.lineTo(L * 0.4, 0); c.closePath(); c.fill(); }
    for (const [x0, w0, hh, k] of [[-0.42, 0.78, 0.38, 0], [-0.36, 0.62, 0.3, 0.12], [-0.28, 0.4, 0.22, 0.2]]) { c.fillStyle = shade('#eef1f5', -k * 0.35); rr(c, L * x0, -W * hh, L * w0 * 0.95, W * hh * 2, 6); c.fill(); c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = 1; c.stroke(); c.fillStyle = 'rgba(40,70,100,.55)'; for (let i = 0; i < 26; i++) { const x = L * x0 + 6 + i * (L * w0 * 0.95 - 12) / 26; c.fillRect(x, -W * hh + 2, 3, 2); c.fillRect(x, W * hh - 4, 3, 2); } }
    c.fillStyle = '#2aa3c9'; rr(c, -L * 0.1, -W * 0.14, L * 0.12, W * 0.28, 4); c.fill(); c.fillStyle = '#e8c28a'; c.fillRect(L * 0.04, -W * 0.18, 8, 8);
    for (const x of [-0.22, 0.02]) { c.fillStyle = '#d6a21c'; c.beginPath(); c.ellipse(L * x, 0, 13, 11, 0, 0, TAU); c.fill(); c.fillStyle = '#16181d'; c.beginPath(); c.ellipse(L * x, 0, 11, 8.5, 0, 0, TAU); c.fill(); }
    c.fillStyle = '#9fd3ee'; c.fillRect(L * 0.3, -W * 0.14, 6, W * 0.28);
  }
  const bx = t === 'ship' || t === 'liner' ? L * 0.3 : L * 0.2; c.fillStyle = '#ff2a2a'; c.beginPath(); c.arc(bx, -W * 0.42, 1.8, 0, TAU); c.fill(); c.fillStyle = '#2aff6a'; c.beginPath(); c.arc(bx, W * 0.42, 1.8, 0, TAU); c.fill();
  if (h.hitT > 0) { c.fillStyle = `rgba(255,80,60,${h.hitT * 2})`; hullPath(c, L, W, 0.8); c.fill(); }
  c.restore(); void bob;
}
export function groundLights(g, L, vis, h) {
  const d = h.def, ca = Math.cos(h.a), sa = Math.sin(h.a);
  if (h.dead) { L.add(h.x, h.y, 120, '#ff8a3a', 0.6); return; }
  if (vis > 0.03 && (h.driver || Math.abs(h.sp) > 5)) { const f = d.len * 0.5 + 90; L.add(h.x + ca * f, h.y + sa * f, 120 + d.len * 0.5, '#fff4d6', 0.8 * Math.min(1, vis + 0.2)); L.add(h.x + ca * d.len * 0.45, h.y + sa * d.len * 0.45, 46, '#ffffff', 0.5 * vis); }
  if (d.hull) { L.add(h.x + ca * d.len * 0.2 - sa * d.wid * 0.42, h.y + sa * d.len * 0.2 + ca * d.wid * 0.42, 26, '#2aff6a', 0.4); L.add(h.x + ca * d.len * 0.2 + sa * d.wid * 0.42, h.y + sa * d.len * 0.2 - ca * d.wid * 0.42, 26, '#ff2a2a', 0.4); if (d.len > 200) for (let i = -4; i <= 4; i++) L.add(h.x + ca * i * d.len * 0.1, h.y + sa * i * d.len * 0.1, 40, '#ffe9b0', 0.22 * vis); }
  if (h.flash > 0) L.add(h.x + Math.cos(h.tur) * d.len * 0.5, h.y + Math.sin(h.tur) * d.len * 0.5, 130, '#ffd27a', 0.9);
}
export function groundHud(g, c, h) {
  const W = g.W, H = g.H, k = g.dpr, d = h.def, touch = g.input.touch, pw = (touch ? 214 : 270) * k, ph = 24 * k, x = W / 2 - pw / 2, y = H - (touch ? 32 : 42) * k;
  const spd = Math.round(Math.hypot(h.vx, h.vy) * (d.hull ? 0.12 : 0.2)), hp = clamp(h.hp / d.hp, 0, 1);
  c.save(); c.globalAlpha = 0.9; c.fillStyle = 'rgba(6,10,18,.55)'; rr(c, x, y, pw, ph, 12 * k); c.fill(); c.strokeStyle = 'rgba(255,255,255,.16)'; c.lineWidth = k; c.stroke();
  c.textBaseline = 'middle'; c.font = `bold ${11 * k}px sans-serif`; c.textAlign = 'left'; c.fillStyle = '#e8ecf5'; c.fillText(d.n.replace(/ (Battle Tank|Patrol Gunboat|Container Ship|Cruise Liner|Sea Cruiser|Speedboat)/, ''), x + 10 * k, y + ph / 2);
  c.textAlign = 'center'; c.fillStyle = '#7fe8ff'; c.fillText(`${spd} ${d.hull ? 'kt' : 'km/h'}`, x + pw * 0.5, y + ph / 2);
  const bx = x + pw - 60 * k; c.fillStyle = 'rgba(255,255,255,.14)'; c.fillRect(bx, y + ph / 2 - 3 * k, 50 * k, 6 * k); c.fillStyle = hp > 0.35 ? '#7cff4f' : '#ff4f5f'; c.fillRect(bx, y + ph / 2 - 3 * k, 50 * k * hp, 6 * k);
  if (d.cannon) { const rl = clamp(1 - Math.max(0, h.cool) / (d.hull ? 1.6 : 2.0), 0, 1); c.fillStyle = 'rgba(255,255,255,.14)'; c.fillRect(x + 10 * k, y + ph + 4 * k, pw - 20 * k, 3 * k); c.fillStyle = rl >= 1 ? '#ffd24a' : '#ff8a3a'; c.fillRect(x + 10 * k, y + ph + 4 * k, (pw - 20 * k) * rl, 3 * k); }
  c.restore();
  if (h.hintT > 0 && !touch) { c.save(); c.globalAlpha = Math.min(1, h.hintT) * 0.9; c.font = `bold ${12 * k}px sans-serif`; c.textAlign = 'center'; c.fillStyle = '#fff'; c.shadowColor = '#000'; c.shadowBlur = 4 * k; c.fillText(d.hull ? '[W/S] throttle · [A/D] rudder · [Space] brake' + (d.mg ? ' · mouse aims · LMB/RMB guns' : '') + ' · [E] disembark at a dock' : '[W/S] drive · [A/D] steer · mouse aims turret · ' + (d.cannon ? 'LMB cannon · RMB machine gun' : 'LMB machine gun') + ' · [E] exit', W / 2, y - 14 * k); c.restore(); }
}
export function engineLevel(g) { const h = g.player.heli; if (!h || !h.def.ground) return null; return { rpm: 0.18 + 0.7 * clamp(Math.hypot(h.vx, h.vy) / h.def.vmax, 0, 1), thr: Math.abs(h.thr || 0), vol: h.def.vol || 1 }; }
