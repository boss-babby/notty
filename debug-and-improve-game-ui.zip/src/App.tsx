import { useEffect, useRef } from "react";
// @ts-ignore — the game engine is plain ES-module JavaScript
import { boot } from "./game/main.js";

export default function App() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    const dispose = boot(ref.current);
    return () => dispose();
  }, []);
  return <div ref={ref} id="game-root" />;
}
