import { createRoot } from "react-dom/client";
import "./index.css";
import "./mobile.css";
import "./zombie.css";
import "./menu.css";
import App from "./App";

// The game engine owns its own lifecycle (canvas, audio, save loop), so we mount without <StrictMode>
// to avoid booting — and generating — the world twice in development.
createRoot(document.getElementById("root")!).render(<App />);
