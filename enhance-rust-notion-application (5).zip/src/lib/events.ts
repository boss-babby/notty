import { count, eq } from "drizzle-orm";

import { db } from "@/db";
import { appEvents } from "@/db/schema";

export type EventKind = "download_windows_zip" | "download_windows_exe" | "web_launch";

/** Records a usage event. Never throws: counters must not break downloads or the app page. */
export async function logEvent(kind: EventKind, userAgent: string | null): Promise<void> {
  try {
    await db.insert(appEvents).values({ kind, userAgent: (userAgent ?? "").slice(0, 300) });
  } catch (e) {
    console.error("logEvent failed", e);
  }
}

export async function countEvents(kind: EventKind): Promise<number> {
  try {
    const rows = await db.select({ n: count() }).from(appEvents).where(eq(appEvents.kind, kind));
    return Number(rows[0]?.n ?? 0);
  } catch {
    return 0;
  }
}
