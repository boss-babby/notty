import { promises as fs } from "node:fs";
import path from "node:path";

export type BuildInfo = {
  version: string;
  wasmBytes: number | null;
  wasmReady: boolean;
  exeBytes: number | null;
  zipBytes: number | null;
  windowsReady: boolean;
  sha256: Record<string, string>;
};

const PUBLIC = path.join(process.cwd(), "public");

async function size(rel: string): Promise<number | null> {
  try {
    return (await fs.stat(path.join(PUBLIC, rel))).size;
  } catch {
    return null;
  }
}

async function readSums(): Promise<Record<string, string>> {
  try {
    const text = await fs.readFile(path.join(PUBLIC, "downloads", "SHA256SUMS.txt"), "utf8");
    const out: Record<string, string> = {};
    for (const line of text.split("\n")) {
      const m = line.trim().match(/^([0-9a-f]{64})\s+\*?(.+)$/i);
      if (m) out[m[2]] = m[1];
    }
    return out;
  } catch {
    return {};
  }
}

async function readVersion(): Promise<string> {
  try {
    const j = JSON.parse(await fs.readFile(path.join(PUBLIC, "webapp", "version.json"), "utf8"));
    return String(j.version ?? "5.0.0");
  } catch {
    return "5.0.0";
  }
}

/** Reads what the Rust build scripts delivered into `public/` (WebAssembly app + Windows download). */
export async function getBuildInfo(): Promise<BuildInfo> {
  const [wasmBytes, exeBytes, zipBytes, sha256, version] = await Promise.all([
    size("webapp/lumen_bg.wasm"),
    size("downloads/Lumen-windows-x64.exe"),
    size("downloads/Lumen-windows-x64.zip"),
    readSums(),
    readVersion(),
  ]);
  const js = await size("webapp/lumen.js");
  const html = await size("webapp/index.html");
  return {
    version,
    wasmBytes,
    wasmReady: Boolean(wasmBytes && js && html),
    exeBytes,
    zipBytes,
    windowsReady: Boolean(zipBytes),
    sha256,
  };
}

export function fmtBytes(n: number | null): string {
  if (n === null) return "—";
  if (n > 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  return `${Math.max(1, Math.round(n / 1024))} KB`;
}
