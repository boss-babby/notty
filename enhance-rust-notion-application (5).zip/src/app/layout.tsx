import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Lumen — a Notion-style workspace written entirely in Rust",
  description:
    "Lumen is a free Notion + Obsidian alternative written 100% in Rust (egui). One codebase: a native Windows app and a WebAssembly app that runs right here in your browser.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-white text-slate-900 antialiased">{children}</body>
    </html>
  );
}
