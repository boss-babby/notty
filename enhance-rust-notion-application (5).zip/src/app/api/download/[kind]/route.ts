import { logEvent, type EventKind } from "@/lib/events";

export const dynamic = "force-dynamic";

const FILES: Record<string, { event: EventKind; file: string }> = {
  zip: { event: "download_windows_zip", file: "/downloads/Lumen-windows-x64.zip" },
  exe: { event: "download_windows_exe", file: "/downloads/Lumen-windows-x64.exe" },
};

/** Counts the download, then redirects to the static file in /public/downloads. */
export async function GET(req: Request, ctx: { params: Promise<{ kind: string }> }) {
  const { kind } = await ctx.params;
  const entry = FILES[kind];
  if (!entry) return new Response("Unknown download", { status: 404 });
  await logEvent(entry.event, req.headers.get("user-agent"));
  return new Response(null, { status: 302, headers: { Location: entry.file, "Cache-Control": "no-store" } });
}
