import Link from "next/link";

import { fmtBytes, getBuildInfo } from "@/lib/build-info";
import { countEvents } from "@/lib/events";

export const dynamic = "force-dynamic";

const WIDGETS: { group: string; items: string[] }[] = [
  { group: "Workspace", items: ["Workspace stats", "My tasks", "Upcoming & overdue", "Recently edited", "Favorites", "Activity"] },
  {
    group: "Charts",
    items: ["Number + trend", "Gauge", "Bar", "Horizontal bars", "Stacked bars", "Line", "Area", "Pie", "Donut", "Funnel", "Radar", "Histogram", "Scatter", "Heat-map"],
  },
  { group: "Records", items: ["Table", "List", "Kanban board", "Calendar", "Progress bars"] },
  { group: "Personal", items: ["Sticky note", "Checklist", "Countdown", "Focus timer", "Today", "Quick links", "Page preview", "Quick add"] },
];

const SNIPPET = `// src/dashwidgets.rs — a future feature adds a widget in one call
register(Def {
    kind: "invoices", name: "Open invoices",
    desc: "Unpaid invoices by customer", cat: Cat::Data,
    glyph: l::WALLET, span: 6, rows: 3,
    opts: &[Opt::Db, Opt::Filters, Opt::Value, Opt::Range],  // inspector form
    draw: draw_invoices,                                     // fn(&mut Cx, &mut Widget, &mut Ui)
});
// gallery entry, settings panel, drag & drop, resize, pinning and
// persistence now work for it — nothing else to wire up.`;

export default async function HomePage() {
  const [info, launches, zips, exes] = await Promise.all([
    getBuildInfo(),
    countEvents("web_launch"),
    countEvents("download_windows_zip"),
    countEvents("download_windows_exe"),
  ]);
  const downloads = zips + exes;
  const exeSha = info.sha256["Lumen-windows-x64.exe"];
  const zipSha = info.sha256["Lumen-windows-x64.zip"];

  return (
    <div className="min-h-screen bg-[radial-gradient(1200px_500px_at_50%_-100px,#e8f1fd,transparent)]">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#2383e2] text-lg font-bold text-white shadow-sm">L</span>
          <span className="text-lg font-semibold tracking-tight">Lumen</span>
          <span className="ml-1 rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600">v{info.version}</span>
        </div>
        <nav className="flex items-center gap-1 text-sm font-medium text-slate-600">
          <a href="#new" className="hidden rounded-lg px-3 py-2 hover:bg-slate-100 sm:block">What&apos;s new</a>
          <a href="#widgets" className="hidden rounded-lg px-3 py-2 hover:bg-slate-100 sm:block">Widgets</a>
          <a href="#download" className="hidden rounded-lg px-3 py-2 hover:bg-slate-100 sm:block">Download</a>
          <Link href="/app" className="rounded-lg bg-slate-900 px-4 py-2 text-white hover:bg-slate-700">Open app</Link>
        </nav>
      </header>

      <main>
        <section className="mx-auto max-w-4xl px-6 pb-14 pt-12 text-center">
          <p className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-medium text-slate-600 shadow-sm">
            <span className="h-2 w-2 rounded-full bg-emerald-500" /> 100% Rust · no JavaScript UI · Windows + WebAssembly
          </p>
          <h1 className="text-balance text-4xl font-semibold leading-[1.05] tracking-tight sm:text-6xl">
            Your whole workspace.<br />
            <span className="text-[#2383e2]">Written entirely in Rust.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-600">
            Notes, databases, a PDF reader with annotations, graph view and now a fully customisable dashboard with 33 interactive widgets —
            one codebase that runs as a native Windows app and right here in your browser.
          </p>
          <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
            <Link
              href="/app"
              className="inline-flex items-center gap-2 rounded-xl bg-[#2383e2] px-6 py-3.5 text-base font-semibold text-white shadow-lg shadow-blue-500/25 transition hover:bg-[#1b6fc2]"
            >
              ▶ Open in your browser
            </Link>
            <a
              href="/api/download/zip"
              className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-6 py-3.5 text-base font-semibold text-slate-800 shadow-sm transition hover:bg-slate-50"
            >
              ⬇ Download for Windows
              <span className="text-sm font-normal text-slate-500">{fmtBytes(info.zipBytes)}</span>
            </a>
          </div>
          <p className="mt-4 text-sm text-slate-500">
            {info.wasmReady ? `WebAssembly build ${fmtBytes(info.wasmBytes)} · ` : ""}
            {launches.toLocaleString()} launches · {downloads.toLocaleString()} downloads
          </p>
        </section>

        <section id="new" className="mx-auto max-w-6xl px-6 py-10">
          <h2 className="text-2xl font-semibold tracking-tight">What&apos;s new in 5.0</h2>
          <div className="mt-6 grid gap-5 md:grid-cols-3">
            <article className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm md:col-span-2">
              <span className="rounded-full bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-700">Dashboard</span>
              <h3 className="mt-3 text-xl font-semibold">Pin anything. Build any dashboard.</h3>
              <ul className="mt-4 grid gap-x-6 gap-y-2 text-sm text-slate-600 sm:grid-cols-2">
                <li>📌 Pin a chart, a filtered view or a number straight from a database (<em>⋯ → Pin to dashboard</em>)</li>
                <li>📈 14 chart types: line, area, bar, stacked, pie, donut, funnel, radar, scatter, gauge, heat-map …</li>
                <li>🖱 Interactive: hover tooltips, click a bar or slice to drill into the records, toggle legend entries</li>
                <li>🧩 Tables you can sort and page, kanban boards you can drag cards across, calendars, checklists, timers</li>
                <li>✋ Customise mode: drag to reorder, drag the corner to resize, live settings panel</li>
                <li>🗂 Multiple boards, presets, dashboard-wide time window, previous-period trends and goals</li>
                <li>🔌 Built for growth: a widget registry — new features plug in with one <code>register()</code> call</li>
                <li>💾 Everything is saved with the workspace and forward-compatible</li>
              </ul>
            </article>
            <article className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700">Fix</span>
              <h3 className="mt-3 text-xl font-semibold">PDF reader keeps your place</h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-600">
                Opening the thumbnail panel or the notes panel narrows the page area, which re-scales every page. The scroll position
                used to stay in pixels, so the view jumped several pages (7–8 in long documents). The reader now re-bases the offset to the same
                spot on the same page whenever the width changes — covered by a regression test.
              </p>
            </article>
          </div>
        </section>

        <section id="widgets" className="mx-auto max-w-6xl px-6 py-10">
          <h2 className="text-2xl font-semibold tracking-tight">33 widgets, ready to arrange</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {WIDGETS.map((g) => (
              <div key={g.group} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-500">{g.group}</h3>
                <ul className="mt-3 flex flex-wrap gap-1.5">
                  {g.items.map((w) => (
                    <li key={w} className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-700">{w}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        <section id="download" className="mx-auto max-w-6xl px-6 py-10">
          <h2 className="text-2xl font-semibold tracking-tight">Get Lumen</h2>
          <div className="mt-6 grid gap-5 md:grid-cols-2">
            <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <h3 className="text-lg font-semibold">🪟 Windows (x64)</h3>
              <p className="mt-2 text-sm text-slate-600">Single portable executable, no installer. Your data stays on your machine. Windows 10 / 11.</p>
              {info.windowsReady ? (
                <div className="mt-4 flex flex-wrap gap-2">
                  <a href="/api/download/zip" className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-700">
                    Download .zip · {fmtBytes(info.zipBytes)}
                  </a>
                  <a href="/api/download/exe" className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold hover:bg-slate-50">
                    .exe · {fmtBytes(info.exeBytes)}
                  </a>
                </div>
              ) : (
                <p className="mt-4 text-sm text-amber-700">The Windows build is not available on this server yet.</p>
              )}
              {(zipSha || exeSha) && (
                <dl className="mt-4 space-y-1 break-all font-mono text-[11px] text-slate-500">
                  {zipSha && <div><dt className="inline font-semibold">SHA-256 zip </dt><dd className="inline">{zipSha}</dd></div>}
                  {exeSha && <div><dt className="inline font-semibold">SHA-256 exe </dt><dd className="inline">{exeSha}</dd></div>}
                </dl>
              )}
              <p className="mt-3 text-xs text-slate-500">Unsigned build: Windows SmartScreen may ask you to choose “More info → Run anyway”.</p>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <h3 className="text-lg font-semibold">🌐 WebAssembly</h3>
              <p className="mt-2 text-sm text-slate-600">
                The same Rust code compiled to WebAssembly and drawn on a canvas with WebGL. Data is saved in your browser (localStorage).
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Link href="/app" className="rounded-lg bg-[#2383e2] px-4 py-2 text-sm font-semibold text-white hover:bg-[#1b6fc2]">Open embedded</Link>
                <a href="/webapp/index.html" className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold hover:bg-slate-50">Full screen ↗</a>
              </div>
              <p className="mt-4 text-sm text-slate-500">
                {info.wasmReady ? `Delivered: lumen_bg.wasm (${fmtBytes(info.wasmBytes)}) + lumen.js + index.html` : "The WebAssembly build is not available on this server yet."}
              </p>
              <p className="mt-2 text-xs text-slate-500">Tip: press <kbd className="rounded border px-1">Ctrl</kbd>+<kbd className="rounded border px-1">D</kbd> inside Lumen for the dashboard.</p>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 py-10">
          <h2 className="text-2xl font-semibold tracking-tight">Built to be extended</h2>
          <p className="mt-2 max-w-3xl text-sm text-slate-600">
            Dashboard widgets are described by a small registry entry: a stable id, the settings the widget understands and a draw function.
            Features that come later register their own widgets and immediately get the gallery, the inspector, drag &amp; drop, resizing, persistence and pinning.
          </p>
          <pre className="mt-5 overflow-x-auto rounded-2xl bg-slate-950 p-5 text-[12.5px] leading-relaxed text-slate-200">{SNIPPET}</pre>
        </section>
      </main>

      <footer className="mx-auto max-w-6xl px-6 py-10 text-sm text-slate-500">
        Lumen {info.version} · MIT licence · Rust, egui, hayro · <Link href="/app" className="underline">open the app</Link>
      </footer>
    </div>
  );
}
