import Link from "next/link";

import { getBuildInfo } from "@/lib/build-info";
import { logEvent } from "@/lib/events";
import { headers } from "next/headers";

export const dynamic = "force-dynamic";

export const metadata = { title: "Lumen — workspace" };

export default async function AppPage() {
  const info = await getBuildInfo();
  const h = await headers();
  if (info.wasmReady) await logEvent("web_launch", h.get("user-agent"));

  return (
    <div className="flex h-screen flex-col bg-white">
      <div className="flex h-10 shrink-0 items-center justify-between border-b border-slate-200 bg-white px-3 text-sm">
        <div className="flex items-center gap-3">
          <Link href="/" className="rounded-md px-2 py-1 font-medium text-slate-600 hover:bg-slate-100">← Lumen</Link>
          <span className="hidden text-slate-400 sm:inline">WebAssembly build · v{info.version}</span>
        </div>
        <div className="flex items-center gap-1">
          <a href="/webapp/index.html" className="rounded-md px-2 py-1 text-slate-600 hover:bg-slate-100">Full screen ↗</a>
          <a href="/api/download/zip" className="rounded-md bg-slate-900 px-3 py-1 font-medium text-white hover:bg-slate-700">Windows app</a>
        </div>
      </div>
      {info.wasmReady ? (
        <iframe
          title="Lumen workspace (WebAssembly)"
          src="/webapp/index.html"
          className="min-h-0 w-full flex-1 border-0"
          allow="clipboard-read; clipboard-write; fullscreen; autoplay"
        />
      ) : (
        <div className="grid flex-1 place-items-center px-6 text-center text-slate-600">
          <div>
            <p className="text-lg font-semibold">The WebAssembly build has not been delivered to this server.</p>
            <p className="mt-2 text-sm">Run <code className="rounded bg-slate-100 px-1.5 py-0.5">lumen/build-web.sh</code> to build it into <code>public/webapp</code>.</p>
          </div>
        </div>
      )}
    </div>
  );
}
