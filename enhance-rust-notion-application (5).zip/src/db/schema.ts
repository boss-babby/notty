import { index, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

/**
 * Lightweight usage log for the Lumen site: Windows downloads, WebAssembly launches and
 * the SHA-256 of the build that was served. Used for the counters on the landing page.
 */
export const appEvents = pgTable(
  "app_events",
  {
    id: serial("id").primaryKey(),
    /** "download_windows_zip" | "download_windows_exe" | "web_launch" */
    kind: text("kind").notNull(),
    userAgent: text("user_agent").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("app_events_kind_idx").on(t.kind)],
);

export type AppEvent = typeof appEvents.$inferSelect;
